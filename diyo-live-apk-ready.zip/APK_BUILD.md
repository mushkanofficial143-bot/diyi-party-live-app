# DIYO LIVE — APK-ready project

The `android/` folder is a native Android WebView shell for DIYO LIVE. It requests camera/microphone permissions needed by Video Live and Party Live and loads the real deployed web application.

## Build
- Install Node.js 18+ and Android Studio with SDK 35 + JDK 17.
- `npm install`
- `npm run build`
- `cd android`
- `./gradlew assembleDebug -PdiyoWebUrl=https://YOUR-DIYO-LIVE-DOMAIN/`
- APK: `android/app/build/outputs/apk/debug/app-debug.apk`

Do not remove the backend/server deployment: the web UI calls `/api/...` endpoints on the same deployed origin.
