# SR LIVE — Final Production & Android APK Build Guide

## 1. Overview & Branding
**SR LIVE** is a high-performance, real-time live streaming platform and creator economy app with emerald & gold accents, 8-tier VIP hierarchy, PK Battles, 26 virtual arcade/slot mini-games, dynamic Lucky Gift Box delivery, and a comprehensive Owner Management Panel.

---

## 2. Android APK Generation Instructions

### Prerequisites
- Node.js (v18+) & npm
- Android Studio (Electric Eel or newer) with Android SDK 34+
- Java Development Kit (JDK 17)

### Step-by-Step APK Build Flow

1. **Install Dependencies & Build Static Web Assets**
   ```bash
   npm install
   npm run build
   ```

2. **Add Capacitor Android Platform**
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "SR LIVE" live.sr.app --web-dir dist
   npx cap add android
   ```

3. **Sync Web Build with Android Project**
   ```bash
   npx cap sync android
   ```

4. **Open in Android Studio & Generate APK**
   ```bash
   npx cap open android
   ```
   - In Android Studio, go to **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
   - The compiled test APK will be located at:
     `android/app/build/outputs/apk/debug/app-debug.apk`

---

## 3. Environment & Security Configuration

Copy the sample environment variables:
```bash
cp .env.example .env
```

| Variable | Description |
| :--- | :--- |
| `GEMINI_API_KEY` | Server-side Gemini API key (optional for AI assistants). |
| `APP_URL` | Public base endpoint URL of the application. |
| `STREAM_INGEST_KEY` | Secret ingest key for RTMP / WebRTC broadcasters. |
| `JWT_SECRET` | Secret key for signing session tokens and verifying Owner claims. |

> **Security Mandate**: Owner privileges are verified strictly on the backend. No secret credentials, Firebase private keys, or Owner secrets are exposed to the client APK bundle.

---

## 4. Role Hierarchy & Granular Access Control
```
OWNER (Super-authority over all systems, platform rules, and finances)
 ↓
SUPER ADMIN (Operational management, role assignments, audit logs)
 ↓
ADMIN (Room moderation, ban/unban users, report resolution)
 ↓
MANAGER (Assigned host and agency performance monitoring)
 ↓
AGENCY (Assigned creator rosters, commissions, live analytics)
 ↓
HOST (Live room studio, PK battles, diamond revenue, fan chat)
 ↓
USER (Viewing, commenting, sending gifts, playing test games, VIP progression)
```

---

## 5. 26 Integrated Catalog Games (TEST MODE)
1. **OlympusSlot** (Slots, 5000x)
2. **TeenPattiPro** (Cards, 500x)
3. **Lucky77Pro** (Slots, 777x)
4. **RoyalTeenPatti** (Cards, 1000x)
5. **GreedyLion** (Arcade, 888x)
6. **FightSlot** (Slots, 1500x)
7. **BeeSlot** (Slots, 600x)
8. **PiggyBank** (Casual, 2000x)
9. **DiceRolling** (Dice, 36x)
10. **HiLo** (Casual, 100x)
11. **LuxuryCar** (Roulette, 40x)
12. **GoldFishing** (Arcade, 888x)
13. **GreedyGenie** (Slots, 2500x)
14. **GreedyKitty** (Casual, 500x)
15. **FruitSlot** (Slots, 1000x)
16. **FruitParty** (Slots, 5000x)
17. **Rocket** (Crash, 10000x)
18. **BoxingFighting** (Arcade, 800x)
19. **SuperRotating** (Roulette, 500x)
20. **GreedyBox** (Casual, 1000x)
21. **GreedyStar** (Arcade, 777x)
22. **SuperFootball** (Casual, 300x)
23. **PirateKing** (Slots, 2000x)
24. **PirateFishingMulti** (Arcade, 1200x)
25. **Delicious** (Casual, 500x)
26. **GatesofOlympus** (Slots, 5000x)

---

## 6. TEST MODE Rules
- **Initial Test Balance**: 100,000,000 virtual test coins automatically seeded.
- **Transactions**: All transactions logged with immutable IDs, previous balances, new balances, timestamps, and `TEST_MODE` tags.
- **Withdrawals**: Disabled in Test Mode to prevent real-money actions during testing.
