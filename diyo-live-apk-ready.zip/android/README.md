# DIYO LIVE Android APK

This is the Android wrapper prepared for the DIYO LIVE web application. It preserves camera/microphone permissions and loads the deployed DIYO LIVE web URL.

## Build APK
1. Build the web app from the project root: `npm install` then `npm run build`.
2. Set your deployed web URL when building:
   `cd android && ./gradlew assembleDebug -PdiyoWebUrl=https://YOUR-DIYO-LIVE-DOMAIN/`
3. APK: `android/app/build/outputs/apk/debug/app-debug.apk`

Android Studio can open the `android/` folder directly. The project uses Android Gradle Plugin 8.7.3 and compile/target SDK 35.

**Important:** the current ZIP cannot contain a final APK because this build environment has no Android SDK/Gradle toolchain and no deployed production URL. The Android source project is included so Android Studio/CI can build it.
