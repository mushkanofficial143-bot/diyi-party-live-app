package live.diyo.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PERM_REQ = 4101;
    private WebView webView;
    private PermissionRequest pendingRequest;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setDatabaseEnabled(true);
        s.setUserAgentString(s.getUserAgentString() + " DIYO-LIVE-Android/1.0");
        webView.setWebViewClient(new WebViewClient() { @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; } });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    pendingRequest = request;
                    requestRuntimePermissions();
                });
            }
        });
        requestRuntimePermissions();
        loadApp();
    }

    private void requestRuntimePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            boolean cam = checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED;
            boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED;
            if (cam || mic) requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, PERM_REQ);
        }
    }

    private void loadApp() {
        String url = BuildConfig.DIYO_WEB_URL;
        if (url.startsWith("https://YOUR-")) {
            webView.loadDataWithBaseURL(null, "<html><body style='background:#0a0a0c;color:white;font-family:sans-serif;padding:32px'><h2>DIYO LIVE APK READY</h2><p>Set <b>diyoWebUrl</b> to your deployed DIYO LIVE URL and rebuild.</p></body></html>", "text/html", "UTF-8", null);
        } else webView.loadUrl(url);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == PERM_REQ && pendingRequest != null) {
            boolean ok = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            if (ok) pendingRequest.grant(pendingRequest.getResources()); else pendingRequest.deny();
            pendingRequest = null;
        }
    }

    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
