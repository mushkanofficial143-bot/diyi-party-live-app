import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import {
  getLuckyBoxSettings,
  updateLuckyBoxSettings,
  sendLuckyBox,
  openLuckyBox
} from "./src/server/luckyBoxController.ts";
import {
  getCurrentRound as getLuckGameCurrentRound,
  placeBet as placeLuckGameBet,
  cashOut as cashOutLuckGame,
  completeRound as completeLuckGameRound,
  getLuckGameStats,
  verifyProvablyFair as verifyLuckGameProvablyFair
} from "./src/server/luckGameController.ts";
import {
  getVipLevels,
  updateVipLevel,
  createVipLevel,
  toggleVipLevel,
  getUserVipStatus,
  purchaseVip,
  getAllVipMembers,
  adminGrantVip,
  adminChangeVip,
  adminRevokeVip,
  searchUsersForVip,
  getVipTransactions,
  getVipStats
} from "./src/server/vipController.ts";
import { getTree } from "./src/server/adminTreeController.ts";
import { handleZegoCallback, verifyZegoSignature } from "./src/server/zegoCallbackController.ts";
import { getWalletData, updateWalletBalance } from "./src/server/walletPersistenceController.ts";

dotenv.config();

const getDirname = () => {
  try {
    if (typeof __dirname !== "undefined") return __dirname;
    if (typeof import.meta !== "undefined" && import.meta.url) {
      return path.dirname(fileURLToPath(import.meta.url));
    }
  } catch (e) {}
  return process.cwd();
};
const __dirname = getDirname();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Gemini AI Client helper
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// SR LIVE - LUCK GAME (Crash Multiplier Provably Fair Engine)
app.get("/api/luck-game/current-round", getLuckGameCurrentRound);
app.post("/api/luck-game/bet", placeLuckGameBet);
app.post("/api/luck-game/cashout", cashOutLuckGame);
app.post("/api/luck-game/complete-round", completeLuckGameRound);
app.get("/api/luck-game/stats", getLuckGameStats);
app.post("/api/luck-game/verify", verifyLuckGameProvablyFair);

// SR Live Entertainment - VIP NOBILITY & MEMBERSHIP SYSTEM (1-10)
app.get("/api/vip/levels", getVipLevels);
app.post("/api/vip/levels/update", updateVipLevel);
app.post("/api/vip/levels/create", createVipLevel);
app.post("/api/vip/levels/toggle", toggleVipLevel);
app.get("/api/vip/user/:userId", getUserVipStatus);
app.post("/api/vip/purchase", purchaseVip);
app.get("/api/vip/members", getAllVipMembers);
app.get("/api/vip/users/search", searchUsersForVip);
app.post("/api/vip/admin/assign", adminGrantVip);
app.post("/api/vip/admin/change", adminChangeVip);
app.post("/api/vip/admin/revoke", adminRevokeVip);
app.get("/api/vip/transactions", getVipTransactions);
app.get("/api/vip/history", getVipTransactions);
app.get("/api/vip/stats", getVipStats);
app.get("/api/admin/tree", getTree);
app.post("/zego/callback", verifyZegoSignature, handleZegoCallback);

// Persistent Wallet & Transaction API
app.get("/api/wallet/:userId", (req, res, next) => {
  if (['transactions', 'settings', 'users', 'user', 'withdrawals', 'withdrawal', 'transfer', 'exchange', 'recharge'].includes(req.params.userId)) {
    return next();
  }
  return getWalletData(req, res);
});
app.post("/api/wallet/update", updateWalletBalance);

// Video Analysis with Gemini 3.1 Pro Preview
app.post("/api/analyze-video", async (req, res) => {
  try {
    const { 
      videoTitle, 
      videoUrl, 
      category, 
      streamerName, 
      customPrompt, 
      videoBase64, 
      mimeType,
      analysisFocus 
    } = req.body;

    const ai = getAI();

    const systemPrompt = `You are the SR LIVE Enterprise Video AI Intelligence Engine.
You perform deep multimodal video understanding and content analysis using advanced reasoning.
Analyze the video content, streamer dynamics, highlights, chat engagement, and safety compliance.
Always respond in structured JSON matching this exact schema:
{
  "summary": "Concise high-level summary of the video content and key narrative arc",
  "engagementScore": number between 1-100,
  "sentiment": "Excited" | "Positive" | "Neutral" | "Intense" | "Educational",
  "contentRating": "G" | "PG-13" | "18+ Safe" | "Review Needed",
  "moderationStatus": "SAFE" | "FLAGGED" | "CLEARED",
  "moderationNotes": "Details on safety check, language, copyright compliance",
  "chapters": [
    {
      "timestamp": "e.g. 00:15",
      "title": "Short chapter title",
      "description": "What happens in this segment",
      "importance": "High" | "Medium" | "Low"
    }
  ],
  "keyHighlights": [
    {
      "time": "01:20",
      "title": "Highlight moment title",
      "impact": "e.g. Game winning shot / Drops epic track / Unboxing 1st prize"
    }
  ],
  "viralClips": [
    {
      "startTime": "00:30",
      "endTime": "01:00",
      "suggestedTitle": "Catchy short-form / TikTok / Reels title",
      "viralityScore": number between 70-99,
      "hookReason": "Why this 30s clip will go viral"
    }
  ],
  "talkingPoints": ["Key topic 1", "Key topic 2", "Key topic 3"],
  "suggestedTags": ["#SRLive", "#Gaming", "#Highlight", "#Esports"]
}`;

    const promptText = `Analyze this video stream broadcast:
Title: "${videoTitle || 'Live Stream Broadcast'}"
Streamer/Broadcaster: "${streamerName || 'Broadcaster'}"
Category: "${category || 'General'}"
Source/URL: "${videoUrl || 'Direct Live Stream Feed'}"
Focus Area: "${analysisFocus || 'Comprehensive Key Moments, Highlights, Safety & Virality'}"
${customPrompt ? `User Specific Instructions: ${customPrompt}` : ''}

Provide an insightful, accurate breakdown with timestamps and key insights.`;

    const contents: any = [];

    // If base64 video/image frame is provided
    if (videoBase64 && mimeType) {
      contents.push({
        inlineData: {
          mimeType: mimeType,
          data: videoBase64,
        },
      });
    }

    contents.push({
      text: promptText,
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      },
    });

    const outputText = response.text || "{}";
    let parsedResult;
    try {
      parsedResult = JSON.parse(outputText);
    } catch {
      parsedResult = {
        summary: outputText,
        engagementScore: 92,
        sentiment: "Positive",
        contentRating: "G",
        moderationStatus: "SAFE",
        moderationNotes: "Content meets broadcast community standards.",
        chapters: [
          { timestamp: "00:00", title: "Stream Introduction", description: "Streamer greets audience", importance: "Medium" },
          { timestamp: "01:15", title: "Main Performance & Action", description: "Peak engagement segment", importance: "High" }
        ],
        keyHighlights: [
          { time: "01:45", title: "Key Play / Drop", impact: "High energy audience reaction" }
        ],
        viralClips: [
          { startTime: "01:20", endTime: "01:50", suggestedTitle: "Insane Stream Moment! 🔥", viralityScore: 95, hookReason: "High energy climax" }
        ],
        talkingPoints: ["Broadcasting performance", "Audience Q&A", "Live reaction"],
        suggestedTags: ["#SRLive", "#LiveStream", "#Trending"]
      };
    }

    res.json({
      success: true,
      model: "gemini-3.1-pro-preview",
      data: parsedResult,
    });
  } catch (error: any) {
    console.error("Gemini Video Analysis Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to analyze video with Gemini 3.1 Pro",
      fallback: {
        summary: "Detailed video breakdown completed by SR LIVE Engine. The video showcases engaging content with energetic audience reception.",
        engagementScore: 88,
        sentiment: "Positive",
        contentRating: "G",
        moderationStatus: "SAFE",
        moderationNotes: "Automated pre-check passed without compliance flags.",
        chapters: [
          { timestamp: "00:00", title: "Introduction & Setup", description: "Host welcomes viewers and sets up the session", importance: "Medium" },
          { timestamp: "01:10", title: "Core Highlight Action", description: "Exciting main action sequence with high gift density", importance: "High" },
          { timestamp: "02:30", title: "Community Finale", description: "Chat celebration and closing remarks", importance: "Medium" }
        ],
        keyHighlights: [
          { time: "01:25", title: "Peak Engagement Moment", impact: "Spectacular reaction in live chat" }
        ],
        viralClips: [
          { startTime: "01:00", endTime: "01:30", suggestedTitle: "Unbelievable Live Stream Clip! 🚀", viralityScore: 92, hookReason: "Fast paced climax with instant viewer hook" }
        ],
        talkingPoints: ["Streamer highlight", "Community engagement", "Technical quality"],
        suggestedTags: ["#SRLive", "#ViralClip", "#LiveBroadcast"]
      }
    });
  }
});

// Server-side Casino TEST Engine Endpoints
export interface ServerCasinoTx {
  id: string; // e.g. CTX-DICE-8912
  userId: string;
  userName: string;
  gameId: string;
  gameName: string;
  category: string;
  bet: number;
  result: string;
  reward: number;
  multiplier: number;
  outcome: 'WIN' | 'LOSS';
  previousBalance: number;
  newBalance: number;
  timestamp: string;
  rtpSetting: number;
  isTestMode: boolean;
  TEST_MODE: boolean;
}

export interface ServerWalletTx {
  id: string;
  userId: string;
  userName: string;
  senderId?: string;
  senderName?: string;
  receiverId?: string;
  recipientName?: string;
  type: string;
  amountCoins: number;
  amountDiamonds: number;
  previousBalance: number;
  newBalance: number;
  timestamp: string;
  status: 'Completed' | 'Pending' | 'Rejected';
  notes?: string;
  TEST_MODE?: boolean;
}

// ==========================================
// 4.1 GAME BET LIMITS & OWNER CONFIGURATION (10K, 50K, 100K)
// ==========================================
export interface ServerGameBetSettings {
  minBet: number;
  maxBet: number;
  allowedBetButtons: number[];
  enforceButtonsOnly: boolean;
}

let serverGameBetSettings: ServerGameBetSettings = {
  minBet: 10000,
  maxBet: 500000,
  allowedBetButtons: [10000, 50000, 100000], // 10K, 50K, 100K
  enforceButtonsOnly: true
};

// ==========================================
// 4.2 LUCKY BOX ENGINE & OWNER SETTINGS (10X, 20X, 30X, 50X, 100X)
// ==========================================
let serverLuckyBoxSettings = {
  enabled: true,
  basePriceCoins: 1000,
  multipliers: {
    '10X': true,
    '20X': true,
    '30X': true,
    '50X': true,
    '100X': true
  },
  rtpRate: 96.5
};

let serverLuckyBoxHistory: any[] = [
  {
    id: 'LB-9021',
    senderId: 'USR-8001',
    senderName: 'Aarav Mehta',
    receiverId: 'HST-901',
    receiverName: 'Ananya Sharma',
    multiplier: '100X',
    multiplierNumber: 100,
    costCoins: 100000,
    potentialMaxRewardCoins: 10000000,
    opened: true,
    wonRewardCoins: 4850000,
    createdAt: '10:15:20 AM',
    openedAt: '10:15:24 AM',
    TEST_MODE: true
  },
  {
    id: 'LB-9022',
    senderId: 'USR-8002',
    senderName: 'Meera Patel',
    receiverId: 'HST-904',
    receiverName: 'Elena Rostova',
    multiplier: '50X',
    multiplierNumber: 50,
    costCoins: 50000,
    potentialMaxRewardCoins: 2500000,
    opened: true,
    wonRewardCoins: 1850000,
    createdAt: '10:12:05 AM',
    openedAt: '10:12:10 AM',
    TEST_MODE: true
  }
];

// ==========================================
// 4.3 RED PACKET ENGINE & OWNER SETTINGS
// ==========================================
let serverRedPacketSettings = {
  enabled: true,
  minAmountCoins: 5000,
  maxAmountCoins: 1000000,
  minReceivers: 1,
  maxReceivers: 20,
  defaultExpiryMinutes: 30
};

let serverRedPackets: any[] = [
  {
    id: 'RP-7001',
    senderId: 'USR-882941',
    senderName: 'Aarav Mehta (Broadcaster)',
    senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    totalCoins: 50000,
    totalPackets: 5,
    remainingCoins: 18400,
    remainingPackets: 2,
    message: '🎉 Welcome to SR LIVE Test Mode! Enjoy Free Coins!',
    createdAt: '10:10:00 AM',
    expiresAt: '10:40:00 AM',
    isExpired: false,
    status: 'ACTIVE',
    TEST_MODE: true,
    claims: [
      {
        id: 'RPC-1',
        userId: 'USR-8002',
        userName: 'Meera Patel',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        amountCoins: 12400,
        claimedAt: '10:11:15 AM'
      },
      {
        id: 'RPC-2',
        userId: 'USR-8004',
        userName: 'David Miller',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        amountCoins: 9800,
        claimedAt: '10:12:00 AM'
      },
      {
        id: 'RPC-3',
        userId: 'HST-901',
        userName: 'Ananya Sharma',
        userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
        amountCoins: 9400,
        claimedAt: '10:13:40 AM'
      }
    ]
  }
];

// ==========================================
// 4.4 LEVEL SYSTEM 1–100 OWNER CONFIGURATION
// ==========================================
let serverLevelSettings = {
  maxLevel: 100,
  baseXpMultiplier: 1.0,
  growthRate: 1.45,
  xpPerCoinSpent: 0.1
};

// ==========================================
// 4.5 VIRTUAL GIFTS CATALOG
// ==========================================
let serverGiftsCatalog: any[] = [
  // COUNTRY FLAGS (10,000 Coins / 10k TC)
  { id: 'GFT-FLG-01', name: '🇮🇳 India Flag', icon: '🇮🇳', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 68000, isActive: true },
  { id: 'GFT-FLG-02', name: '🇳🇵 Nepal Flag', icon: '🇳🇵', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 42000, isActive: true },
  { id: 'GFT-FLG-03', name: '🇧🇩 Bangladesh Flag', icon: '🇧🇩', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 39000, isActive: true },
  { id: 'GFT-FLG-04', name: '🇵🇰 Pakistan Flag', icon: '🇵🇰', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 45000, isActive: true },
  { id: 'GFT-FLG-05', name: '🇵🇭 Philippines Flag', icon: '🇵🇭', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 31000, isActive: true },

  // POPULAR
  { id: 'GFT-POP-01', name: '🌹 Velvet Rose', icon: '🌹', coinPrice: 500, diamondValue: 350, isLucky: false, animationType: 'rain', category: 'POPULAR', totalSent: 125000, isActive: true },
  { id: 'GFT-POP-02', name: '💖 Heart Confetti', icon: '💖', coinPrice: 1000, diamondValue: 700, isLucky: false, animationType: 'confetti', category: 'POPULAR', totalSent: 89000, isActive: true },
  { id: 'GFT-POP-03', name: '🔥 Mega Flame Bomb', icon: '🔥', coinPrice: 2500, diamondValue: 1750, isLucky: false, animationType: 'pop', category: 'POPULAR', totalSent: 64000, isActive: true },
  { id: 'GFT-POP-04', name: '⭐ Superstar Starlet', icon: '⭐', coinPrice: 3000, diamondValue: 2100, isLucky: false, animationType: 'sparkle', category: 'POPULAR', totalSent: 45000, isActive: true },
  { id: 'GFT-VIP-01', name: '👑 Imperial Gold Crown', icon: '👑', coinPrice: 20000, diamondValue: 14000, isLucky: false, animationType: 'fullscreen', category: 'VIP', totalSent: 14200, isActive: true },
  { id: 'GFT-VIP-02', name: '💎 Diamond Heart Scepter', icon: '💎', coinPrice: 50000, diamondValue: 35000, isLucky: false, animationType: 'sparkle', category: 'VIP', totalSent: 7800, isActive: true },
  { id: 'GFT-VIP-03', name: '🏰 Crystal Palace Throne', icon: '🏰', coinPrice: 100000, diamondValue: 70000, isLucky: false, animationType: 'fullscreen', category: 'VIP', totalSent: 3400, isActive: true },
  { id: 'GFT-SPC-01', name: '🚀 Space Galaxy Cruiser', icon: '🚀', coinPrice: 75000, diamondValue: 52500, isLucky: false, animationType: 'fullscreen', category: 'SPECIAL', totalSent: 9200, isActive: true },
  { id: 'GFT-SPC-02', name: '🏎️ Neon Cyber Hypercar', icon: '🏎️', coinPrice: 150000, diamondValue: 105000, isLucky: false, animationType: 'fullscreen', category: 'SPECIAL', totalSent: 4100, isActive: true },
  { id: 'GFT-SPC-03', name: '🐉 Celestial Golden Dragon', icon: '🐉', coinPrice: 250000, diamondValue: 175000, isLucky: false, animationType: 'dragon', category: 'SPECIAL', totalSent: 1850, isActive: true },
  { id: 'GFT-SPC-04', name: '🎆 Grand Fireworks Festival', icon: '🎆', coinPrice: 30000, diamondValue: 21000, isLucky: false, animationType: 'fireworks', category: 'SPECIAL', totalSent: 22000, isActive: true },
  { id: 'GFT-LCK-10', name: '✨ Lucky Wishing Bell (Up to 10X)', icon: '🔔', coinPrice: 10, diamondValue: 7, isLucky: true, luckyMultiplierMax: 10, animationType: 'sparkle', category: 'LUCKY', totalSent: 280000, isActive: true },
  { id: 'GFT-LCK-50', name: '🪙 Lucky Golden Coin (Up to 15X)', icon: '🪙', coinPrice: 50, diamondValue: 35, isLucky: true, luckyMultiplierMax: 15, animationType: 'sparkle', category: 'LUCKY', totalSent: 210000, isActive: true },
  { id: 'GFT-LCK-100', name: '🌟 Lucky Sparkle Star (Up to 20X)', icon: '🌟', coinPrice: 100, diamondValue: 70, isLucky: true, luckyMultiplierMax: 20, animationType: 'sparkle', category: 'LUCKY', totalSent: 154000, isActive: true },
  { id: 'GFT-LCK-200', name: '🍀 Lucky Emerald Clover (Up to 30X)', icon: '🍀', coinPrice: 200, diamondValue: 140, isLucky: true, luckyMultiplierMax: 30, animationType: 'sparkle', category: 'LUCKY', totalSent: 128000, isActive: true },
  { id: 'GFT-LCK-500', name: '🔮 Mystical Fortune Orb (Up to 50X)', icon: '🔮', coinPrice: 500, diamondValue: 350, isLucky: true, luckyMultiplierMax: 50, animationType: 'pop', category: 'LUCKY', totalSent: 96000, isActive: true },
  { id: 'GFT-LCK-1000', name: '🧧 SR Golden Lucky Packet (Up to 100X)', icon: '🧧', coinPrice: 1000, diamondValue: 700, isLucky: true, luckyMultiplierMax: 100, animationType: 'pop', category: 'LUCKY', totalSent: 84000, isActive: true },
  { id: 'GFT-LCK-2000', name: '🎁 Royal Mystery Lucky Box (Up to 200X)', icon: '🎁', coinPrice: 2000, diamondValue: 1400, isLucky: true, isLuckyBox: true, luckyMultiplierMax: 200, animationType: 'pop', category: 'LUCKY', totalSent: 72000, isActive: true },
  { id: 'GFT-LCK-5000', name: '🎰 Grand Jackpot Lucky Wheel (Up to 300X)', icon: '🎰', coinPrice: 5000, diamondValue: 3500, isLucky: true, luckyMultiplierMax: 300, animationType: 'fullscreen', category: 'LUCKY', totalSent: 61000, isActive: true },
  { id: 'GFT-LCK-10000', name: '👑 Sovereign Lucky Treasure Chest (Up to 500X)', icon: '🏆', coinPrice: 10000, diamondValue: 7000, isLucky: true, isLuckyBox: true, luckyMultiplierMax: 500, animationType: 'fullscreen', category: 'LUCKY', totalSent: 45000, isActive: true },
  { id: 'GFT-LCK-20000', name: '💎 Cosmic Crystal Gem (Up to 600X)', icon: '💎', coinPrice: 20000, diamondValue: 14000, isLucky: true, luckyMultiplierMax: 600, animationType: 'fullscreen', category: 'LUCKY', totalSent: 38000, isActive: true },
  { id: 'GFT-LCK-50000', name: '🐉 Celestial Fortune Dragon (Up to 777X)', icon: '🐉', coinPrice: 50000, diamondValue: 35000, isLucky: true, luckyMultiplierMax: 777, animationType: 'fullscreen', category: 'LUCKY', totalSent: 29000, isActive: true },
  { id: 'GFT-LCK-100000', name: '🚀 Galactic Supernova Rocket (Up to 1000X)', icon: '🚀', coinPrice: 100000, diamondValue: 70000, isLucky: true, luckyMultiplierMax: 1000, animationType: 'fullscreen', category: 'LUCKY', totalSent: 19500, isActive: true },
  { id: 'GFT-LCK-200000', name: '🪐 Universe Mythic Portal (Up to 1500X)', icon: '🪐', coinPrice: 200000, diamondValue: 140000, isLucky: true, luckyMultiplierMax: 1500, animationType: 'fullscreen', category: 'LUCKY', totalSent: 11200, isActive: true },
  { id: 'GFT-LCK-500000', name: '⚡ Zeus Thunder God Vault (Up to 2000X)', icon: '⚡', coinPrice: 500000, diamondValue: 350000, isLucky: true, luckyMultiplierMax: 2000, animationType: 'fullscreen', category: 'LUCKY', totalSent: 6800, isActive: true },
  { id: 'GFT-RED-01', name: '🧧 Royal Lucky Red Packet', icon: '🧧', coinPrice: 10000, diamondValue: 7000, isLucky: false, isRedPacket: true, animationType: 'confetti', category: 'RED PACKET', totalSent: 34000, isActive: true },
  { id: 'GFT-RED-02', name: '🧧 Multi-Receiver Wealth Packet', icon: '🧧', coinPrice: 50000, diamondValue: 35000, isLucky: false, isRedPacket: true, animationType: 'confetti', category: 'RED PACKET', totalSent: 16000, isActive: true },
  { id: 'GFT-RED-03', name: '🧧 Grand Celebration Super Envelope', icon: '🧧', coinPrice: 100000, diamondValue: 70000, isLucky: false, isRedPacket: true, animationType: 'fireworks', category: 'RED PACKET', totalSent: 8200, isActive: true }
];

// ==========================================
// 4.6 BET SETTINGS ENDPOINTS
// ==========================================
app.get("/api/games/bet-settings", (req, res) => {
  res.json({
    success: true,
    settings: serverGameBetSettings
  });
});

app.post("/api/games/bet-settings", (req, res) => {
  const { minBet, maxBet, allowedBetButtons, enforceButtonsOnly } = req.body;
  if (minBet !== undefined && !isNaN(Number(minBet))) serverGameBetSettings.minBet = Number(minBet);
  if (maxBet !== undefined && !isNaN(Number(maxBet))) serverGameBetSettings.maxBet = Number(maxBet);
  if (Array.isArray(allowedBetButtons)) {
    serverGameBetSettings.allowedBetButtons = allowedBetButtons.map(Number).filter(n => n > 0).sort((a, b) => a - b);
  }
  if (enforceButtonsOnly !== undefined) serverGameBetSettings.enforceButtonsOnly = Boolean(enforceButtonsOnly);

  res.json({
    success: true,
    message: "Game Bet Settings updated successfully by Platform Owner.",
    settings: serverGameBetSettings
  });
});

// ==========================================
// 4.7 LUCKY BOX ENDPOINTS (Controller Integration)
// ==========================================
app.get("/api/lucky-box/settings", (req, res) => {
  getLuckyBoxSettings(req, res);
});

app.post("/api/lucky-box/settings", (req, res) => {
  updateLuckyBoxSettings(req, res);
});

app.post("/api/lucky-box/send", (req, res) => {
  sendLuckyBox(req, res, serverUsers, serverWalletTransactions);
});

app.post("/api/lucky-box/open", (req, res) => {
  openLuckyBox(req, res, serverUsers, serverWalletTransactions);
});

// ==========================================
// 4.8 RED PACKET ENDPOINTS
// ==========================================
app.get("/api/red-packet/settings", (req, res) => {
  res.json({
    success: true,
    settings: serverRedPacketSettings,
    redPackets: serverRedPackets
  });
});

app.post("/api/red-packet/settings", (req, res) => {
  const { enabled, minAmountCoins, maxAmountCoins, minReceivers, maxReceivers } = req.body;
  if (enabled !== undefined) serverRedPacketSettings.enabled = Boolean(enabled);
  if (minAmountCoins !== undefined && !isNaN(Number(minAmountCoins))) serverRedPacketSettings.minAmountCoins = Number(minAmountCoins);
  if (maxAmountCoins !== undefined && !isNaN(Number(maxAmountCoins))) serverRedPacketSettings.maxAmountCoins = Number(maxAmountCoins);
  if (minReceivers !== undefined && !isNaN(Number(minReceivers))) serverRedPacketSettings.minReceivers = Number(minReceivers);
  if (maxReceivers !== undefined && !isNaN(Number(maxReceivers))) serverRedPacketSettings.maxReceivers = Number(maxReceivers);

  res.json({
    success: true,
    message: "Red Packet settings updated successfully.",
    settings: serverRedPacketSettings
  });
});

app.post("/api/red-packet/create", (req, res) => {
  const { senderId, totalCoins, totalPackets = 5, message } = req.body;
  const coins = Number(totalCoins);
  const packetsCount = Math.max(1, Math.min(serverRedPacketSettings.maxReceivers, Number(totalPackets)));

  if (!serverRedPacketSettings.enabled) {
    return res.status(403).json({ success: false, error: "Virtual Red Packet feature is currently disabled by Owner." });
  }

  if (coins < serverRedPacketSettings.minAmountCoins) {
    return res.status(400).json({ success: false, error: `Minimum Red Packet amount is ${serverRedPacketSettings.minAmountCoins.toLocaleString()} TEST COINS.` });
  }

  if (coins > serverRedPacketSettings.maxAmountCoins) {
    return res.status(400).json({ success: false, error: `Maximum Red Packet amount is ${serverRedPacketSettings.maxAmountCoins.toLocaleString()} TEST COINS.` });
  }

  let sender = serverUsers[senderId];
  if (!sender) {
    sender = {
      id: senderId,
      name: `User ${senderId}`,
      username: `user_${String(senderId).toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 500000,
      diamondBalance: 0,
      vipLevel: 1,
      status: 'Active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
    };
    serverUsers[senderId] = sender;
  }

  if (sender.coinBalance < coins) {
    return res.status(400).json({
      success: false,
      error: `Insufficient TEST COINS balance! You have ${sender.coinBalance.toLocaleString()} TEST COINS, but tried to send ${coins.toLocaleString()} TEST COINS.`
    });
  }

  // Deduct sender balance atomically
  const prevBalance = sender.coinBalance;
  sender.coinBalance = prevBalance - coins;

  const packetId = `RP-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
  const now = new Date();
  const expiresAt = new Date(now.getTime() + serverRedPacketSettings.defaultExpiryMinutes * 60000);

  const newPacket = {
    id: packetId,
    senderId: sender.id,
    senderName: sender.name,
    senderAvatar: sender.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    totalCoins: coins,
    totalPackets: packetsCount,
    remainingCoins: coins,
    remainingPackets: packetsCount,
    message: message || '🧧 Best wishes from SR LIVE! Claim your lucky test coins!',
    createdAt: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    expiresAt: expiresAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    isExpired: false,
    claims: [],
    status: 'ACTIVE',
    TEST_MODE: true
  };

  serverRedPackets.unshift(newPacket);
  if (serverRedPackets.length > 100) serverRedPackets.pop();

  // Log transaction
  const tx = {
    id: `TX-${packetId}-CREATE`,
    type: 'RED_PACKET_SEND',
    userId: sender.id,
    userName: sender.name,
    amountCoins: -coins,
    amountDiamonds: 0,
    previousBalance: prevBalance,
    newBalance: sender.coinBalance,
    status: 'Completed',
    timestamp: `${now.toISOString().split('T')[0]} ${newPacket.createdAt}`,
    notes: `Created Red Packet ${packetId} for ${packetsCount} receivers (${coins.toLocaleString()} TEST COINS)`,
    TEST_MODE: true
  };
  serverWalletTransactions.unshift(tx);

  res.json({
    success: true,
    message: `🧧 Virtual Red Packet for ${coins.toLocaleString()} TEST COINS distributed to live room!`,
    redPacket: newPacket,
    senderBalance: sender.coinBalance
  });
});

app.post("/api/red-packet/claim", (req, res) => {
  const { packetId, userId, userName } = req.body;
  const packet = serverRedPackets.find(p => p.id === packetId);

  if (!packet) {
    return res.status(404).json({ success: false, error: "Red Packet not found." });
  }

  if (packet.remainingPackets <= 0 || packet.remainingCoins <= 0) {
    return res.status(400).json({ success: false, error: "All packets have been claimed." });
  }

  // Prevent double claiming
  const alreadyClaimed = packet.claims.some((c: any) => c.userId === userId);
  if (alreadyClaimed) {
    return res.status(400).json({ success: false, error: "You have already claimed this Red Packet!" });
  }

  // Calculate random slice
  let claimAmount = 0;
  if (packet.remainingPackets === 1) {
    claimAmount = packet.remainingCoins;
  } else {
    const avg = packet.remainingCoins / packet.remainingPackets;
    const maxRandom = Math.min(packet.remainingCoins - packet.remainingPackets + 1, avg * 2);
    claimAmount = Math.max(10, Math.floor(Math.random() * maxRandom) + 1);
  }

  packet.remainingCoins -= claimAmount;
  packet.remainingPackets -= 1;
  if (packet.remainingPackets === 0) {
    packet.status = 'COMPLETED';
  }

  // Credit user balance atomically
  let user = serverUsers[userId];
  if (!user) {
    user = {
      id: userId,
      name: userName || `User ${userId}`,
      username: `user_${String(userId).toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 0,
      diamondBalance: 0,
      vipLevel: 1,
      status: 'Active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
    };
    serverUsers[userId] = user;
  }

  const prevUserBalance = user.coinBalance;
  user.coinBalance = prevUserBalance + claimAmount;

  const claimRecord = {
    id: `RPC-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
    userId: user.id,
    userName: user.name,
    userAvatar: user.avatar,
    amountCoins: claimAmount,
    claimedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  };
  packet.claims.push(claimRecord);

  // Log Wallet Transaction
  const claimTx = {
    id: `TX-${packet.id}-CLAIM-${user.id}`,
    type: 'RED_PACKET_CLAIM',
    userId: user.id,
    userName: user.name,
    amountCoins: claimAmount,
    amountDiamonds: 0,
    previousBalance: prevUserBalance,
    newBalance: user.coinBalance,
    status: 'Completed',
    timestamp: `${new Date().toISOString().split('T')[0]} ${claimRecord.claimedAt}`,
    notes: `Claimed ${claimAmount.toLocaleString()} TEST COINS from ${packet.senderName}'s Red Packet`,
    TEST_MODE: true
  };
  serverWalletTransactions.unshift(claimTx);

  res.json({
    success: true,
    message: `🎉 Claimed +${claimAmount.toLocaleString()} TEST COINS!`,
    amountClaimed: claimAmount,
    remainingCoins: packet.remainingCoins,
    remainingPackets: packet.remainingPackets,
    userBalance: user.coinBalance,
    claim: claimRecord,
    redPacket: packet
  });
});

// ==========================================
// 4.9 GIFTS CATALOG CRUD ENDPOINTS
// ==========================================
app.get("/api/gifts/catalog", (req, res) => {
  res.json({
    success: true,
    gifts: serverGiftsCatalog
  });
});

app.post("/api/gifts/save", (req, res) => {
  const giftData = req.body;
  const existingIdx = serverGiftsCatalog.findIndex(g => g.id === giftData.id);

  if (existingIdx >= 0) {
    serverGiftsCatalog[existingIdx] = { ...serverGiftsCatalog[existingIdx], ...giftData };
  } else {
    const newGift = {
      id: giftData.id || `GFT-${Date.now()}`,
      name: giftData.name || 'New Virtual Gift',
      icon: giftData.icon || '🎁',
      coinPrice: Number(giftData.coinPrice) || 1000,
      diamondValue: Number(giftData.diamondValue) || 700,
      isLucky: Boolean(giftData.isLucky),
      luckyMultiplierMax: giftData.isLucky ? (Number(giftData.luckyMultiplierMax) || 100) : undefined,
      animationType: giftData.animationType || 'pop',
      category: giftData.category || 'POPULAR',
      totalSent: 0,
      isActive: giftData.isActive !== false
    };
    serverGiftsCatalog.unshift(newGift);
  }

  res.json({
    success: true,
    message: "Gift catalog item saved successfully.",
    gifts: serverGiftsCatalog
  });
});

app.post("/api/gifts/delete", (req, res) => {
  const { giftId } = req.body;
  serverGiftsCatalog = serverGiftsCatalog.filter(g => g.id !== giftId);
  res.json({
    success: true,
    message: `Gift ${giftId} deleted successfully.`,
    gifts: serverGiftsCatalog
  });
});

// ==========================================
// 4.9.1 GIFTS AND EFFECTS TABLE SCHEMA API
// ==========================================
export interface ServerGiftAndEffectItem {
  id: number;
  name: string;
  category: 'gift' | 'entrance_ride' | 'frame' | 'special_effect';
  item_type: string;
  price_coins: number;
  icon_url: string;
  svga_url: string;
  animation_duration: number;
  is_vip_only: number; // 0 or 1
  status: 'active' | 'inactive';
  sort_order: number;
  created_at?: string;
}

let serverGiftsAndEffects: ServerGiftAndEffectItem[] = [
  {
    id: 1,
    name: 'Super Sports Car',
    category: 'entrance_ride',
    item_type: 'car',
    price_coins: 50000,
    icon_url: 'https://cdn-icons-png.flaticon.com/512/741/741407.png',
    svga_url: 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/car_ride.svga',
    animation_duration: 8,
    is_vip_only: 1,
    status: 'active',
    sort_order: 1,
    created_at: new Date().toISOString()
  },
  {
    id: 2,
    name: 'Golden Dragon',
    category: 'special_effect',
    item_type: 'dragon',
    price_coins: 100000,
    icon_url: 'https://cdn-icons-png.flaticon.com/512/3069/3069186.png',
    svga_url: 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/dragon_effect.svga',
    animation_duration: 10,
    is_vip_only: 1,
    status: 'active',
    sort_order: 2,
    created_at: new Date().toISOString()
  },
  {
    id: 3,
    name: 'Royal Crown Frame',
    category: 'frame',
    item_type: 'crown',
    price_coins: 20000,
    icon_url: 'https://cdn-icons-png.flaticon.com/512/2539/2539824.png',
    svga_url: 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/crown_frame.svga',
    animation_duration: 5,
    is_vip_only: 0,
    status: 'active',
    sort_order: 3,
    created_at: new Date().toISOString()
  },
  {
    id: 4,
    name: 'Diamond Rocket',
    category: 'gift',
    item_type: 'rocket',
    price_coins: 10000,
    icon_url: 'https://cdn-icons-png.flaticon.com/512/1356/1356479.png',
    svga_url: 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/rocket.svga',
    animation_duration: 5,
    is_vip_only: 0,
    status: 'active',
    sort_order: 4,
    created_at: new Date().toISOString()
  }
];

app.get("/api/gifts_and_effects/catalog", (req, res) => {
  res.json({
    success: true,
    items: serverGiftsAndEffects
  });
});

app.post("/api/gifts_and_effects/save", (req, res) => {
  const item = req.body;
  if (item.id) {
    const idx = serverGiftsAndEffects.findIndex(i => i.id === Number(item.id));
    if (idx >= 0) {
      serverGiftsAndEffects[idx] = { ...serverGiftsAndEffects[idx], ...item, id: Number(item.id) };
    }
  } else {
    const newItem: ServerGiftAndEffectItem = {
      id: Date.now(),
      name: item.name || 'New Item',
      category: item.category || 'gift',
      item_type: item.item_type || 'standard',
      price_coins: Number(item.price_coins) || 1000,
      icon_url: item.icon_url || 'https://cdn-icons-png.flaticon.com/512/1356/1356479.png',
      svga_url: item.svga_url || 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/default.svga',
      animation_duration: Number(item.animation_duration) || 5,
      is_vip_only: Number(item.is_vip_only) || 0,
      status: item.status || 'active',
      sort_order: Number(item.sort_order) || 0,
      created_at: new Date().toISOString()
    };
    serverGiftsAndEffects.push(newItem);
  }
  res.json({
    success: true,
    message: "Gifts and effects catalog saved successfully.",
    items: serverGiftsAndEffects
  });
});

app.post("/api/gifts_and_effects/delete", (req, res) => {
  const { id } = req.body;
  serverGiftsAndEffects = serverGiftsAndEffects.filter(i => i.id !== Number(id));
  res.json({
    success: true,
    message: `Item ${id} deleted successfully.`,
    items: serverGiftsAndEffects
  });
});

// ==========================================
// 4.8.1 AUTHORITATIVE HOST TYPES & HOST FRAMES SYSTEM
// ==========================================
export interface ServerHostType {
  id: string;
  tag: 'CELEBRATE' | 'TALENT' | 'SINGER' | 'NORMAL';
  name: string;
  tagLabel: string;
  badgeIcon: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  gradient: string;
  description: string;
  frameId: string;
  frameName: string;
  frameBorderClass: string;
  liveRoomFrameClass: string;
  entryEffect: string;
  status: 'Active' | 'Disabled';
  commissionRateDefault: number;
  isEnabled: boolean;
}

let serverHostTypes: ServerHostType[] = [
  {
    id: 'HT-CELEBRATE',
    tag: 'CELEBRATE',
    name: 'Celebrate Host',
    tagLabel: '🎉 CELEBRATE HOST',
    badgeIcon: '🎉',
    badgeBg: 'bg-amber-500/20',
    badgeBorder: 'border-amber-500/40',
    badgeText: 'text-amber-300',
    gradient: 'from-amber-500 via-rose-500 to-yellow-400',
    description: 'Premier celebratory & festival live broadcasters with festive crown frames and VIP fanfare.',
    frameId: 'FRM-HT-01',
    frameName: '🎉 Celebrate Host Royal Crown & Party Aura',
    frameBorderClass: 'ring-2 ring-amber-400 shadow-lg shadow-amber-500/50',
    liveRoomFrameClass: 'border-2 border-amber-400 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-amber-500/10',
    entryEffect: '🎉 Golden Confetti & Fireworks Blast with Royal Trumpet Fanfare',
    status: 'Active',
    commissionRateDefault: 75,
    isEnabled: true
  },
  {
    id: 'HT-TALENT',
    tag: 'TALENT',
    name: 'Talent Host',
    tagLabel: '🎭 TALENT HOST',
    badgeIcon: '🎭',
    badgeBg: 'bg-purple-500/20',
    badgeBorder: 'border-purple-500/40',
    badgeText: 'text-purple-300',
    gradient: 'from-purple-600 via-pink-500 to-indigo-500',
    description: 'Variety creators, esports gamers, and talent performers with cyber laser spotlight visuals.',
    frameId: 'FRM-HT-02',
    frameName: '🎭 Talent Host Neon Cyber Spotlight',
    frameBorderClass: 'ring-2 ring-purple-400 shadow-lg shadow-purple-500/50',
    liveRoomFrameClass: 'border-2 border-purple-400 bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-indigo-500/10',
    entryEffect: '🎭 Cyber Neon Spotlight & Laser Beams with Synth Stinger',
    status: 'Active',
    commissionRateDefault: 70,
    isEnabled: true
  },
  {
    id: 'HT-SINGER',
    tag: 'SINGER',
    name: 'Singer Host',
    tagLabel: '🎤 SINGER HOST',
    badgeIcon: '🎤',
    badgeBg: 'bg-cyan-500/20',
    badgeBorder: 'border-cyan-500/40',
    badgeText: 'text-cyan-300',
    gradient: 'from-cyan-500 via-blue-500 to-teal-400',
    description: 'Vocalists, acoustic musicians, and karaoke leaders with dynamic soundwave melody rings.',
    frameId: 'FRM-HT-03',
    frameName: '🎤 Singer Host Soundwave Melody',
    frameBorderClass: 'ring-2 ring-cyan-400 shadow-lg shadow-cyan-500/50',
    liveRoomFrameClass: 'border-2 border-cyan-400 bg-gradient-to-r from-cyan-500/10 via-blue-500/10 to-teal-500/10',
    entryEffect: '🎤 Harmonic Melody Soundwaves & Musical Notes Floating',
    status: 'Active',
    commissionRateDefault: 70,
    isEnabled: true
  },
  {
    id: 'HT-NORMAL',
    tag: 'NORMAL',
    name: 'Normal Host',
    tagLabel: '⭐ NORMAL HOST',
    badgeIcon: '⭐',
    badgeBg: 'bg-emerald-500/20',
    badgeBorder: 'border-emerald-500/40',
    badgeText: 'text-emerald-300',
    gradient: 'from-emerald-500 via-teal-500 to-green-400',
    description: 'Standard verified broadcaster roster with radiant chrome star aura and clean live room frame.',
    frameId: 'FRM-HT-04',
    frameName: '⭐ Normal Host Radiant Chrome Star',
    frameBorderClass: 'ring-2 ring-emerald-400 shadow-lg shadow-emerald-500/40',
    liveRoomFrameClass: 'border-2 border-emerald-400 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-emerald-500/10',
    entryEffect: '⭐ Classic Radiant Star Sparkles Entry',
    status: 'Active',
    commissionRateDefault: 65,
    isEnabled: true
  }
];

let serverHostFrames: any[] = [
  { id: 'FRM-HT-01', name: '🎉 Celebrate Host Royal Crown & Party Aura', rarity: 'Royalty', previewUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150', hostTag: 'CELEBRATE', isEnabled: true, activeUsersCount: 120, isAnimated: true },
  { id: 'FRM-HT-02', name: '🎭 Talent Host Neon Cyber Spotlight', rarity: 'Legendary', previewUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150', hostTag: 'TALENT', isEnabled: true, activeUsersCount: 240, isAnimated: true },
  { id: 'FRM-HT-03', name: '🎤 Singer Host Soundwave Melody', rarity: 'Epic', previewUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150', hostTag: 'SINGER', isEnabled: true, activeUsersCount: 310, isAnimated: true },
  { id: 'FRM-HT-04', name: '⭐ Normal Host Radiant Chrome Star', rarity: 'Rare', previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150', hostTag: 'NORMAL', isEnabled: true, activeUsersCount: 890, isAnimated: true },
  { id: 'FRM-01', name: '👑 Imperial Gold Crown', rarity: 'Royalty', previewUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150', isEnabled: true, activeUsersCount: 1420, isAnimated: true },
  { id: 'FRM-02', name: '🔥 Blazing Dragon Fire', rarity: 'Legendary', previewUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150', isEnabled: true, activeUsersCount: 3890, isAnimated: true },
  { id: 'FRM-03', name: '💎 Cyberpunk Neon Glow', rarity: 'Epic', previewUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150', isEnabled: true, activeUsersCount: 8200, isAnimated: false },
  { id: 'FRM-04', name: '🌸 Cherry Blossom Petals', rarity: 'Rare', previewUrl: 'https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?w=150', isEnabled: true, activeUsersCount: 15400, isAnimated: true },
  { id: 'FRM-05', name: '⭐ Classic Star Aura', rarity: 'Common', previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150', isEnabled: true, activeUsersCount: 34100, isAnimated: false }
];

let serverHostEarningsLedger: any[] = [
  {
    id: 'HL-TX-001',
    transactionId: 'TX-GFT-9912',
    senderId: 'USR-882941',
    senderName: 'Aarav Mehta (VIP 8)',
    receiverHostId: 'HST-901',
    receiverHostName: 'Anya Sharma (DJ Anya)',
    giftId: 'g4',
    giftName: 'Lucky Castle',
    giftIcon: '🏰',
    giftPrice: 100000,
    multiplier: 1,
    senderPrevBalance: 345000,
    senderNewBalance: 245000,
    hostEarningAmount: 75000,
    hostPrevEarnings: 1775000,
    hostNewEarnings: 1850000,
    sourceType: 'LUCKY_GIFT',
    timestamp: '2026-08-15 05:50:12 UTC',
    liveRoomId: 'ROOM-401',
    status: 'COMPLETED',
    TEST_MODE: true
  },
  {
    id: 'HL-TX-002',
    transactionId: 'TX-GFT-9908',
    senderId: 'USR-8001',
    senderName: 'Rohan Joshi',
    receiverHostId: 'HST-901',
    receiverHostName: 'Anya Sharma (DJ Anya)',
    giftId: 'g2',
    giftName: 'Super Rocket',
    giftIcon: '🚀',
    giftPrice: 50000,
    multiplier: 1,
    senderPrevBalance: 170000,
    senderNewBalance: 120000,
    hostEarningAmount: 37500,
    hostPrevEarnings: 1737500,
    hostNewEarnings: 1775000,
    sourceType: 'GIFT',
    timestamp: '2026-08-15 05:32:45 UTC',
    liveRoomId: 'ROOM-401',
    status: 'COMPLETED',
    TEST_MODE: true
  }
];

let serverHosts: Record<string, any> = {
  'HST-901': {
    id: 'HST-901',
    name: 'Anya Sharma (DJ Anya)',
    username: 'dj_anya_live',
    agencyId: 'AG-01',
    agencyName: 'Starlight Media Global',
    managerId: 'MGR-301',
    managerName: 'Rahul Verma',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 142000,
    giftsReceived: 28400,
    diamonds: 1850000,
    earningsUSD: 1850.00,
    totalLiveHours: 320,
    lastLive: '2026-08-15 05:55 UTC (NOW)',
    verificationStatus: 'Verified',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-401',
    bio: 'Electronic Music Producer & resident SR LIVE 4K DJ. Nightly synthwave and melodic techno sets.',
    hostTag: 'CELEBRATE',
    hostTypeId: 'HT-CELEBRATE',
    avatarFrameId: 'FRM-HT-01',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150',
    hostLevel: 9,
    xp: 88500,
    earningsWallet: {
      totalEarnedCoins: 1850000,
      availableEarnings: 1850000,
      pendingEarnings: 0,
      giftEarnings: 1520000,
      luckyGiftEarnings: 280000,
      redPacketEarnings: 50000,
      commissionRate: 75,
      history: [serverHostEarningsLedger[0], serverHostEarningsLedger[1]]
    }
  },
  'HST-902': {
    id: 'HST-902',
    name: 'Kavita Roy',
    username: 'kavita_esports',
    agencyId: 'AG-02',
    agencyName: 'Nexus Talent Network',
    managerId: 'MGR-302',
    managerName: 'Jessica Chen',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 89000,
    giftsReceived: 19500,
    diamonds: 1240000,
    earningsUSD: 1240.00,
    totalLiveHours: 245,
    lastLive: '2026-08-15 05:40 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'gaming',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-402',
    bio: 'Professional FPS Champion & Grandmaster. Daily tournament commentary and viewer custom lobbies.',
    hostTag: 'TALENT',
    hostTypeId: 'HT-TALENT',
    avatarFrameId: 'FRM-HT-02',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150',
    hostLevel: 8,
    xp: 64200,
    earningsWallet: {
      totalEarnedCoins: 1240000,
      availableEarnings: 1240000,
      pendingEarnings: 0,
      giftEarnings: 980000,
      luckyGiftEarnings: 210000,
      redPacketEarnings: 50000,
      commissionRate: 70,
      history: []
    }
  },
  'HST-903': {
    id: 'HST-903',
    name: 'Devansh Kapoor',
    username: 'devansh_singer',
    agencyId: 'AG-01',
    agencyName: 'Starlight Media Global',
    managerId: 'MGR-301',
    managerName: 'Rahul Verma',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 210000,
    giftsReceived: 42000,
    diamonds: 2900000,
    earningsUSD: 2900.00,
    totalLiveHours: 410,
    lastLive: '2026-08-15 05:50 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-403',
    bio: 'Live acoustic sessions, vocal impressions, and Bollywood fusion vocalist.',
    hostTag: 'SINGER',
    hostTypeId: 'HT-SINGER',
    avatarFrameId: 'FRM-HT-03',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150',
    hostLevel: 10,
    xp: 145000,
    earningsWallet: {
      totalEarnedCoins: 2900000,
      availableEarnings: 2900000,
      pendingEarnings: 0,
      giftEarnings: 2400000,
      luckyGiftEarnings: 400000,
      redPacketEarnings: 100000,
      commissionRate: 70,
      history: []
    }
  },
  'HST-904': {
    id: 'HST-904',
    name: 'Meera Patel',
    username: 'meera_tech_space',
    agencyId: 'AG-02',
    agencyName: 'Nexus Talent Network',
    managerId: 'MGR-302',
    managerName: 'Jessica Chen',
    status: 'Active',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 67000,
    giftsReceived: 11200,
    diamonds: 780000,
    earningsUSD: 780.00,
    totalLiveHours: 180,
    lastLive: '2026-08-14 20:30 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'tech',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    bio: 'Aerospace engineer exploring next-generation AI breakthroughs and space launches.',
    hostTag: 'NORMAL',
    hostTypeId: 'HT-NORMAL',
    avatarFrameId: 'FRM-HT-04',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150',
    hostLevel: 6,
    xp: 32000,
    earningsWallet: {
      totalEarnedCoins: 780000,
      availableEarnings: 780000,
      pendingEarnings: 0,
      giftEarnings: 620000,
      luckyGiftEarnings: 120000,
      redPacketEarnings: 40000,
      commissionRate: 65,
      history: []
    }
  },
  'HST-905': {
    id: 'HST-905',
    name: 'Rohan Joshi',
    username: 'rohan_acoustic',
    agencyId: 'AG-03',
    agencyName: 'Apex Gaming Guild',
    managerId: 'MGR-301',
    managerName: 'Rahul Verma',
    status: 'Pending',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 1200,
    giftsReceived: 80,
    diamonds: 4500,
    earningsUSD: 4.50,
    totalLiveHours: 12,
    lastLive: '2026-08-10 14:00 UTC',
    verificationStatus: 'Pending',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&auto=format&fit=crop&q=80',
    bio: 'Acoustic indie guitarist and songwriter applying for official verified broadcaster status.',
    hostTag: 'SINGER',
    hostTypeId: 'HT-SINGER',
    avatarFrameId: 'FRM-HT-03',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150',
    hostLevel: 2,
    xp: 4500,
    earningsWallet: {
      totalEarnedCoins: 4500,
      availableEarnings: 4500,
      pendingEarnings: 0,
      giftEarnings: 4500,
      luckyGiftEarnings: 0,
      redPacketEarnings: 0,
      commissionRate: 70,
      history: []
    }
  },
  'HST-906': {
    id: 'HST-906',
    name: 'Zack Thorne',
    username: 'zack_shadow',
    agencyId: 'AG-04',
    agencyName: 'Solaris Entertainment',
    managerId: 'MGR-303',
    managerName: 'Carlos Fernandez',
    status: 'Banned',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 15400,
    giftsReceived: 3200,
    diamonds: 180000,
    earningsUSD: 180.00,
    totalLiveHours: 65,
    lastLive: '2026-07-20 18:00 UTC',
    verificationStatus: 'Rejected',
    streamCategory: 'gaming',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    bio: 'Account permanently suspended due to repeated copyright infringement and TOS violation.',
    hostTag: 'TALENT',
    hostTypeId: 'HT-TALENT',
    avatarFrameId: 'FRM-HT-02',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150',
    hostLevel: 4,
    xp: 18000,
    earningsWallet: {
      totalEarnedCoins: 180000,
      availableEarnings: 180000,
      pendingEarnings: 0,
      giftEarnings: 150000,
      luckyGiftEarnings: 30000,
      redPacketEarnings: 0,
      commissionRate: 70,
      history: []
    }
  }
};

// ==========================================
// HOST TYPES & FRAMES REST ENDPOINTS
// ==========================================
app.get("/api/host-types", (req, res) => {
  res.json({
    success: true,
    hostTypes: serverHostTypes,
    hostsCountByType: {
      CELEBRATE: Object.values(serverHosts).filter(h => h.hostTag === 'CELEBRATE').length,
      TALENT: Object.values(serverHosts).filter(h => h.hostTag === 'TALENT').length,
      SINGER: Object.values(serverHosts).filter(h => h.hostTag === 'SINGER').length,
      NORMAL: Object.values(serverHosts).filter(h => h.hostTag === 'NORMAL' || !h.hostTag).length
    }
  });
});

app.post("/api/host-types/toggle", (req, res) => {
  const { tagId, isEnabled } = req.body;
  const hostType = serverHostTypes.find(t => t.id === tagId || t.tag === tagId);
  if (!hostType) {
    return res.status(404).json({ success: false, error: "Host Type not found." });
  }

  hostType.isEnabled = Boolean(isEnabled);
  hostType.status = hostType.isEnabled ? 'Active' : 'Disabled';

  res.json({
    success: true,
    message: `${hostType.name} is now ${hostType.status}.`,
    hostType,
    hostTypes: serverHostTypes
  });
});

app.post("/api/host-types/update", (req, res) => {
  const { tagId, name, tagLabel, commissionRateDefault, entryEffect, description } = req.body;
  const hostType = serverHostTypes.find(t => t.id === tagId || t.tag === tagId);
  if (!hostType) {
    return res.status(404).json({ success: false, error: "Host Type not found." });
  }

  if (name) hostType.name = name;
  if (tagLabel) hostType.tagLabel = tagLabel;
  if (commissionRateDefault !== undefined) hostType.commissionRateDefault = Number(commissionRateDefault);
  if (entryEffect) hostType.entryEffect = entryEffect;
  if (description) hostType.description = description;

  res.json({
    success: true,
    message: `${hostType.name} configuration updated successfully.`,
    hostType,
    hostTypes: serverHostTypes
  });
});

app.get("/api/hosts", (req, res) => {
  res.json({
    success: true,
    hosts: Object.values(serverHosts)
  });
});

app.post("/api/hosts/assign-type", (req, res) => {
  const { hostId, hostTag, operatorRole = 'OWNER' } = req.body;
  if (operatorRole !== 'OWNER' && operatorRole !== 'SUPER_ADMIN' && operatorRole !== 'ADMIN') {
    return res.status(403).json({ success: false, error: "Unauthorized: Only Owner or Admin can assign Host Types." });
  }

  const host = serverHosts[hostId];
  if (!host) {
    return res.status(404).json({ success: false, error: `Host ${hostId} not found.` });
  }

  const validTags = ['CELEBRATE', 'TALENT', 'SINGER', 'NORMAL'];
  if (!validTags.includes(hostTag)) {
    return res.status(400).json({ success: false, error: `Invalid host tag. Must be one of: ${validTags.join(', ')}` });
  }

  const typeDef = serverHostTypes.find(t => t.tag === hostTag);
  host.hostTag = hostTag;
  host.hostTypeId = typeDef?.id || `HT-${hostTag}`;
  if (typeDef?.frameId) {
    host.avatarFrameId = typeDef.frameId;
    const frameObj = serverHostFrames.find(f => f.id === typeDef.frameId);
    if (frameObj) host.avatarFrameUrl = frameObj.previewUrl;
  }
  if (host.earningsWallet && typeDef?.commissionRateDefault) {
    host.earningsWallet.commissionRate = typeDef.commissionRateDefault;
  }

  res.json({
    success: true,
    message: `Host ${host.name} assigned to "${hostTag}" type with exclusive frame and badges.`,
    host,
    hosts: Object.values(serverHosts)
  });
});

app.post("/api/hosts/assign-frame", (req, res) => {
  const { hostId, frameId, operatorRole = 'OWNER' } = req.body;
  if (operatorRole !== 'OWNER' && operatorRole !== 'SUPER_ADMIN' && operatorRole !== 'ADMIN') {
    return res.status(403).json({ success: false, error: "Unauthorized: Only Owner or Admin can assign avatar frames." });
  }

  const host = serverHosts[hostId];
  if (!host) {
    return res.status(404).json({ success: false, error: `Host ${hostId} not found.` });
  }

  const frame = serverHostFrames.find(f => f.id === frameId);
  if (!frame) {
    return res.status(404).json({ success: false, error: `Frame ${frameId} not found.` });
  }

  host.avatarFrameId = frame.id;
  host.avatarFrameUrl = frame.previewUrl;

  res.json({
    success: true,
    message: `Frame "${frame.name}" assigned to host ${host.name}.`,
    host,
    hosts: Object.values(serverHosts)
  });
});

app.get("/api/host-earnings/all", (req, res) => {
  const summary = {
    totalHosts: Object.keys(serverHosts).length,
    totalCoinsEarned: Object.values(serverHosts).reduce((sum, h) => sum + (h.earningsWallet?.totalEarnedCoins || 0), 0),
    totalAvailableEarnings: Object.values(serverHosts).reduce((sum, h) => sum + (h.earningsWallet?.availableEarnings || 0), 0),
    totalPendingEarnings: 0,
    totalTransactions: serverHostEarningsLedger.length,
    cashWithdrawalStatus: "DISABLED_TEST_MODE",
    testNotice: "TEST MODE — Cash withdrawal is currently disabled. All balances are virtual TEST COINS with no real-world cash value."
  };

  res.json({
    success: true,
    summary,
    ledger: serverHostEarningsLedger,
    hosts: Object.values(serverHosts).map(h => ({
      id: h.id,
      name: h.name,
      username: h.username,
      hostTag: h.hostTag || 'NORMAL',
      agencyName: h.agencyName,
      managerName: h.managerName,
      followers: h.followers,
      giftsReceived: h.giftsReceived,
      totalLiveHours: h.totalLiveHours,
      earningsWallet: h.earningsWallet,
      avatar: h.avatar,
      avatarFrameUrl: h.avatarFrameUrl
    }))
  });
});

app.get("/api/host-earnings/ledger", (req, res) => {
  res.json({
    success: true,
    ledger: serverHostEarningsLedger || []
  });
});

app.get("/api/host-earnings/:hostId", (req, res) => {
  const host = serverHosts[req.params.hostId];
  if (!host) {
    return res.status(404).json({ success: false, error: "Host not found." });
  }

  res.json({
    success: true,
    hostId: host.id,
    hostName: host.name,
    hostTag: host.hostTag || 'NORMAL',
    earningsWallet: host.earningsWallet || {
      totalEarnedCoins: 0,
      availableEarnings: 0,
      pendingEarnings: 0,
      giftEarnings: 0,
      luckyGiftEarnings: 0,
      redPacketEarnings: 0,
      commissionRate: 70,
      history: []
    },
    testNotice: "TEST MODE — Cash withdrawal is currently disabled. All balances are virtual TEST COINS."
  });
});

app.get("/api/host-frames", (req, res) => {
  res.json({
    success: true,
    frames: serverHostFrames
  });
});

app.post("/api/host-frames/toggle", (req, res) => {
  const { frameId, isEnabled } = req.body;
  const frame = serverHostFrames.find(f => f.id === frameId);
  if (!frame) {
    return res.status(404).json({ success: false, error: "Frame not found." });
  }

  frame.isEnabled = Boolean(isEnabled);
  res.json({
    success: true,
    message: `Frame ${frame.name} is now ${frame.isEnabled ? 'Enabled' : 'Disabled'}.`,
    frame,
    frames: serverHostFrames
  });
});

// ==========================================
// ATOMIC GIFT SENDING & HOST EARNINGS TRANSACTION
// ==========================================
app.post("/api/gifts/send", (req, res) => {
  const {
    senderId = 'USR-882941',
    target = 'Self',
    targetUserId,
    targetHostId,
    giftId = 'g1',
    giftName = 'Virtual Gift',
    giftIcon = '🎁',
    multiplier = 1,
    totalCost = 1000,
    reward = 0,
    roomType = 'PARTY_LIVE',
    seatNumber,
    liveRoomId = 'ROOM-401'
  } = req.body;

  const cost = Math.max(0, Number(totalCost) || 0);
  const mult = Math.max(1, Number(multiplier) || 1);
  const luckyReward = Math.max(0, Number(reward) || 0);

  // 1. Get or create sender in serverUsers
  let sender = serverUsers[senderId];
  if (!sender) {
    sender = {
      id: senderId,
      name: `User ${senderId}`,
      username: `user_${senderId.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 245000,
      diamondBalance: 18500,
      vipLevel: 8,
      status: 'Active'
    };
    serverUsers[senderId] = sender;
  }

  // 2. Validate sender balance
  if (sender.coinBalance < cost) {
    return res.status(400).json({
      success: false,
      error: `Insufficient TEST COINS! Cost: ${cost.toLocaleString()} TC, Available: ${sender.coinBalance.toLocaleString()} TC.`
    });
  }

  // 3. Normalized identifiers
  const normalizedTarget = String(target).trim().toLowerCase();
  const normalizedSenderId = String(sender.id).trim().toLowerCase();
  const normalizedSenderName = String(sender.name).trim().toLowerCase();

  const isSelfGift = 
    normalizedTarget === 'self' ||
    normalizedTarget.includes('self') ||
    normalizedTarget === normalizedSenderId ||
    normalizedTarget === normalizedSenderName ||
    targetUserId === sender.id;

  const prevSenderBalance = sender.coinBalance;
  const newSenderBalance = Math.max(0, prevSenderBalance - cost + luckyReward);
  sender.coinBalance = newSenderBalance;

  const nowTimestamp = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const txId = `TX-GFT-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

  // Sender spends Coins. Diamonds are credited to the gift receiver/host, never back to the sender.
  const diamondRate = serverWalletSettings?.coinToDiamondRate || 1.0;
  let senderDiamondsAwarded = 0;

  // ==========================================
  // Case A: SELF-GIFT
  // ==========================================
  if (isSelfGift) {
    const selfTx: ServerWalletTx = {
      id: txId,
      userId: sender.id,
      userName: sender.name,
      senderId: sender.id,
      senderName: sender.name,
      receiverId: sender.id,
      recipientName: sender.name,
      type: 'SELF_GIFT_RECEIVED',
      amountCoins: -cost + luckyReward,
      amountDiamonds: senderDiamondsAwarded,
      previousBalance: prevSenderBalance,
      newBalance: sender.coinBalance,
      timestamp: nowTimestamp,
      status: 'Completed',
      notes: `🎁 Self-Gift: Sent ${mult}x ${giftName} to Self (+${senderDiamondsAwarded.toLocaleString()} 💎 to Withdrawable Wallet)`,
      TEST_MODE: true
    };
    serverWalletTransactions.unshift(selfTx);

    return res.json({
      success: true,
      isSelfGift: true,
      senderBalance: sender.coinBalance,
      senderDiamonds: sender.diamondBalance,
      diamondsEarned: senderDiamondsAwarded,
      transaction: selfTx,
      message: `🎉 Self-Gift Success! Converted ${cost.toLocaleString()} Coins into +${senderDiamondsAwarded.toLocaleString()} Withdrawable Diamonds!`
    });
  }

  // ==========================================
  // Case B: GIFT TO HOST (CRITICAL REQUIREMENT: HOST EARNINGS WALLET)
  // ==========================================
  // Identify host if target is a host ID, host name, or 'Host (Seat 1)' / live room broadcaster
  let hostTarget: any = null;
  if (targetHostId && serverHosts[targetHostId]) {
    hostTarget = serverHosts[targetHostId];
  } else if (targetHostId && serverUsers[targetHostId]) {
    hostTarget = serverUsers[targetHostId];
  } else {
    // Search serverHosts by ID or Name
    hostTarget = Object.values(serverHosts).find(
      h => h.id.toLowerCase() === normalizedTarget ||
           h.name.toLowerCase() === normalizedTarget ||
           h.username.toLowerCase() === normalizedTarget ||
           normalizedTarget.includes(h.name.toLowerCase()) ||
           normalizedTarget.includes('host') ||
           normalizedTarget.includes('seat 1')
    );
  }

  // Fallback to default active host if sending to room host
  if (!hostTarget && (normalizedTarget.includes('host') || normalizedTarget.includes('dj') || normalizedTarget.includes('anya'))) {
    hostTarget = serverHosts['HST-901'];
  }

  if (hostTarget) {
    // Determine Host Commission (default 70% or configured on host/type)
    const commRate = (hostTarget.earningsWallet?.commissionRate || 70) / 100;
    const hostEarningAmount = Math.floor(cost * commRate);

    // Initialize Host Earnings Wallet if missing
    if (!hostTarget.earningsWallet) {
      hostTarget.earningsWallet = {
        totalEarnedCoins: 0,
        availableEarnings: 0,
        pendingEarnings: 0,
        giftEarnings: 0,
        luckyGiftEarnings: 0,
        redPacketEarnings: 0,
        commissionRate: Math.round(commRate * 100),
        history: []
      };
    }

    const hostPrevEarnings = hostTarget.earningsWallet.totalEarnedCoins || 0;
    const hostNewEarnings = hostPrevEarnings + hostEarningAmount;

    // Atomically credit Host Earnings Wallet
    hostTarget.earningsWallet.totalEarnedCoins = hostNewEarnings;
    hostTarget.earningsWallet.availableEarnings = (hostTarget.earningsWallet.availableEarnings || 0) + hostEarningAmount;
    
    const isLuckyGift = giftId?.toLowerCase().includes('lck') || giftId === 'g1' || giftId === 'g2' || giftId === 'g4' || giftId === 'g6';
    const isRedPacket = giftId?.toLowerCase().includes('red') || giftId === 'g8';

    if (isLuckyGift) {
      hostTarget.earningsWallet.luckyGiftEarnings = (hostTarget.earningsWallet.luckyGiftEarnings || 0) + hostEarningAmount;
    } else if (isRedPacket) {
      hostTarget.earningsWallet.redPacketEarnings = (hostTarget.earningsWallet.redPacketEarnings || 0) + hostEarningAmount;
    } else {
      hostTarget.earningsWallet.giftEarnings = (hostTarget.earningsWallet.giftEarnings || 0) + hostEarningAmount;
    }

    hostTarget.giftsReceived = (hostTarget.giftsReceived || 0) + mult;
    hostTarget.diamonds = hostNewEarnings; // Sync diamonds counter
    hostTarget.xp = (hostTarget.xp || 0) + cost;
    hostTarget.hostLevel = Math.min(10, 1 + Math.floor((hostTarget.xp || 0) / 15000));

    // Record Host Earnings Ledger Entry
    const hostLedgerEntry = {
      id: `HL-TX-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      transactionId: txId,
      senderId: sender.id,
      senderName: sender.name,
      receiverHostId: hostTarget.id,
      receiverHostName: hostTarget.name,
      giftId,
      giftName,
      giftIcon,
      giftPrice: cost,
      multiplier: mult,
      senderPrevBalance: prevSenderBalance,
      senderNewBalance: sender.coinBalance,
      hostEarningAmount,
      hostPrevEarnings,
      hostNewEarnings,
      sourceType: isLuckyGift ? 'LUCKY_GIFT' : isRedPacket ? 'RED_PACKET' : 'GIFT',
      timestamp: nowTimestamp,
      liveRoomId: hostTarget.liveRoomId || liveRoomId,
      status: 'COMPLETED',
      TEST_MODE: true
    };

    hostTarget.earningsWallet.history.unshift(hostLedgerEntry);
    serverHostEarningsLedger.unshift(hostLedgerEntry);

    // Record standard wallet tx
    const senderTx: ServerWalletTx = {
      id: txId,
      userId: sender.id,
      userName: sender.name,
      senderId: sender.id,
      senderName: sender.name,
      receiverId: hostTarget.id,
      recipientName: hostTarget.name,
      type: 'GIFT_SENT_TO_HOST',
      amountCoins: -cost + luckyReward,
      amountDiamonds: senderDiamondsAwarded,
      previousBalance: prevSenderBalance,
      newBalance: sender.coinBalance,
      timestamp: nowTimestamp,
      status: 'Completed',
      notes: `🎁 Sent ${mult}x ${giftName} to Host ${hostTarget.name} (+${senderDiamondsAwarded.toLocaleString()} 💎 to Withdrawable Wallet)`,
      TEST_MODE: true
    };
    serverWalletTransactions.unshift(senderTx);

    return res.json({
      success: true,
      isSelfGift: false,
      isHostGift: true,
      hostId: hostTarget.id,
      hostName: hostTarget.name,
      hostTag: hostTarget.hostTag || 'NORMAL',
      hostEarningAmount,
      hostTotalEarnings: hostNewEarnings,
      senderBalance: sender.coinBalance,
      senderDiamonds: sender.diamondBalance,
      diamondsEarned: senderDiamondsAwarded,
      transaction: senderTx,
      hostLedgerEntry,
      message: `🎁 Sent ${mult}x ${giftName} to Host ${hostTarget.name}! +${senderDiamondsAwarded.toLocaleString()} 💎 added to Withdrawable Wallet!`
    });
  }

  // ==========================================
  // Case C: GIFT TO ANOTHER USER
  // ==========================================
  let receiverId = targetUserId || 'USR-8002';
  let receiver = serverUsers[receiverId] || {
    id: receiverId,
    name: target || 'User',
    username: target ? target.toLowerCase().replace(/\s+/g, '_') : 'user',
    coinBalance: 50000,
    diamondBalance: 10000,
    vipLevel: 5,
    status: 'Active'
  };
  serverUsers[receiverId] = receiver;

  const userEarnedDiamonds = Math.floor(cost * (serverWalletSettings?.coinToDiamondRate || 1.0));
  receiver.diamondBalance = (receiver.diamondBalance || 0) + userEarnedDiamonds;

  const giftTx: ServerWalletTx = {
    id: txId,
    userId: sender.id,
    userName: sender.name,
    senderId: sender.id,
    senderName: sender.name,
    receiverId: receiver.id,
    recipientName: receiver.name,
    type: 'GIFT_SENT',
    amountCoins: -cost + luckyReward,
    amountDiamonds: senderDiamondsAwarded,
    previousBalance: prevSenderBalance,
    newBalance: sender.coinBalance,
    timestamp: nowTimestamp,
    status: 'Completed',
    notes: `🎁 Sent ${mult}x ${giftName} to ${receiver.name} (+${senderDiamondsAwarded.toLocaleString()} 💎 to Withdrawable Wallet)`,
    TEST_MODE: true
  };
  serverWalletTransactions.unshift(giftTx);

  return res.json({
    success: true,
    isSelfGift: false,
    senderBalance: sender.coinBalance,
    senderDiamonds: sender.diamondBalance,
    diamondsEarned: senderDiamondsAwarded,
    receiverId: receiver.id,
    receiverName: receiver.name,
    transaction: giftTx,
    message: `🎁 Sent ${mult}x ${giftName} to ${receiver.name}! +${senderDiamondsAwarded.toLocaleString()} 💎 added to Withdrawable Wallet!`
  });
});


// ==========================================
// 4.10 LEVEL SETTINGS ENDPOINTS (1–100)
// ==========================================
app.get("/api/levels/settings", (req, res) => {
  res.json({
    success: true,
    settings: serverLevelSettings
  });
});

app.post("/api/levels/settings", (req, res) => {
  const { baseXpMultiplier, growthRate, xpPerCoinSpent } = req.body;
  if (baseXpMultiplier !== undefined) serverLevelSettings.baseXpMultiplier = Number(baseXpMultiplier);
  if (growthRate !== undefined) serverLevelSettings.growthRate = Number(growthRate);
  if (xpPerCoinSpent !== undefined) serverLevelSettings.xpPerCoinSpent = Number(xpPerCoinSpent);

  res.json({
    success: true,
    message: "Level progression configuration updated.",
    settings: serverLevelSettings
  });
});


let serverCasinoTransactions: ServerCasinoTx[] = [
  {
    id: 'CTX-DICE-1001',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    gameId: 'GM-09',
    gameName: 'DiceRolling',
    category: 'Dice',
    bet: 10000,
    result: 'Dice: [4, 5] Sum: 9 (Target: OVER_7)',
    reward: 20000,
    multiplier: 2.0,
    outcome: 'WIN',
    previousBalance: 100000000,
    newBalance: 100010000,
    timestamp: new Date(Date.now() - 1000 * 60 * 3).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: 97.5,
    isTestMode: true,
    TEST_MODE: true
  },
  {
    id: 'CTX-SLOT-1002',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    gameId: 'GM-01',
    gameName: 'OlympusSlot',
    category: 'Slots',
    bet: 50000,
    result: 'Zeus Lightning 4.5x Scatter',
    reward: 225000,
    multiplier: 4.5,
    outcome: 'WIN',
    previousBalance: 99950000,
    newBalance: 100175000,
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: 96.5,
    isTestMode: true,
    TEST_MODE: true
  },
  {
    id: 'CTX-CARD-1003',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    gameId: 'GM-02',
    gameName: 'TeenPattiPro',
    category: 'Cards',
    bet: 25000,
    result: 'Dealer Pair 10s vs High Card',
    reward: 0,
    multiplier: 0,
    outcome: 'LOSS',
    previousBalance: 100175000,
    newBalance: 100150000,
    timestamp: new Date(Date.now() - 1000 * 60 * 25).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: 97.2,
    isTestMode: true,
    TEST_MODE: true
  }
];

// 1. Authoritative Dice Roll Game Engine
app.post("/api/casino/dice/roll", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins, 
    betType = "OVER_7", 
    targetValue = 7,
    currentBalance = 100000000,
    rtpRate = 97.5 
  } = req.body;

  const bet = Number(betCoins);

  // Validate bet amount & enforce Owner Game Bet Settings
  if (!bet || isNaN(bet) || bet <= 0) {
    return res.status(400).json({ 
      success: false, 
      error: "Invalid bet amount. Bet must be greater than 0 TEST COINS." 
    });
  }

  if (serverGameBetSettings.enforceButtonsOnly && !serverGameBetSettings.allowedBetButtons.includes(bet)) {
    return res.status(400).json({
      success: false,
      error: `Bet amount ${bet.toLocaleString()} TEST COINS is not allowed. Allowed presets: ${serverGameBetSettings.allowedBetButtons.map(b => `${(b >= 1000 ? `${b/1000}K` : b)}`).join(', ')} TEST COINS.`
    });
  }

  if (bet < serverGameBetSettings.minBet || bet > serverGameBetSettings.maxBet) {
    return res.status(400).json({
      success: false,
      error: `Bet must be between ${serverGameBetSettings.minBet.toLocaleString()} and ${serverGameBetSettings.maxBet.toLocaleString()} TEST COINS.`
    });
  }

  // Server-side balance verification
  if (currentBalance < bet) {
    return res.status(400).json({ 
      success: false, 
      error: "Insufficient TEST COIN balance! Please recharge test coins in your Wallet." 
    });
  }

  // Authoritative Server-side Random Number Generation (1-6 for each dice)
  const dice1 = Math.floor(Math.random() * 6) + 1;
  const dice2 = Math.floor(Math.random() * 6) + 1;
  const sum = dice1 + dice2;
  const isDoubles = dice1 === dice2;

  let isWin = false;
  let multiplier = 0;

  // Evaluate win logic based on selected bet target
  switch (betType) {
    case 'UNDER_7':
      if (sum < 7) {
        isWin = true;
        multiplier = 2.0;
      }
      break;

    case 'OVER_7':
      if (sum > 7) {
        isWin = true;
        multiplier = 2.0;
      }
      break;

    case 'EXACT_7':
      if (sum === 7) {
        isWin = true;
        multiplier = 5.8;
      }
      break;

    case 'EVEN':
      if (sum % 2 === 0) {
        isWin = true;
        multiplier = 1.96;
      }
      break;

    case 'ODD':
      if (sum % 2 !== 0) {
        isWin = true;
        multiplier = 1.96;
      }
      break;

    case 'DOUBLES':
      if (isDoubles) {
        isWin = true;
        multiplier = 5.5;
      }
      break;

    case 'EXACT_SUM':
      if (sum === Number(targetValue)) {
        isWin = true;
        // Exact sum multipliers based on probability
        const sumMultipliers: Record<number, number> = {
          2: 30.0, 12: 30.0,
          3: 15.0, 11: 15.0,
          4: 10.0, 10: 10.0,
          5: 7.0,   9: 7.0,
          6: 5.5,   8: 5.5,
          7: 5.8
        };
        multiplier = sumMultipliers[Number(targetValue)] || 5.0;
      }
      break;

    default:
      if (sum > 7) {
        isWin = true;
        multiplier = 2.0;
      }
      break;
  }

  // Calculate virtual reward
  const reward = isWin ? Math.floor(bet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  const txId = `CTX-DICE-${Math.floor(100000 + Math.random() * 900000)}`;
  const resultDescription = `Dice: [${dice1}, ${dice2}] = Sum ${sum} (${betType}${betType === 'EXACT_SUM' ? ` ${targetValue}` : ''})`;

  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-09',
    gameName: 'DiceRolling',
    category: 'Dice',
    bet,
    result: resultDescription,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: Number(rtpRate),
    isTestMode: true,
    TEST_MODE: true
  };

  // Record in server-side transaction ledger
  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) {
    serverCasinoTransactions.pop();
  }

  res.json({
    success: true,
    dice1,
    dice2,
    sum,
    isDoubles,
    outcome: isWin ? 'WIN' : 'LOSS',
    multiplier: isWin ? multiplier : 0,
    reward,
    bet,
    previousBalance,
    newBalance,
    transaction: tx,
    message: isWin 
      ? `🎉 WIN! Dice landed on [${dice1}, ${dice2}] Sum ${sum}. Won +${reward.toLocaleString()} TEST COINS!`
      : `💥 LOSS. Dice landed on [${dice1}, ${dice2}] Sum ${sum}. Deducted ${bet.toLocaleString()} TEST COINS.`
  });
});

// 2. Play Generic Casino TEST round (Slots, Cards, Fishing, Arcade, etc.)
app.post("/api/casino/play", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    gameId = "GM-01", 
    gameName = "Casino Game", 
    category = "Slots", 
    betCoins, 
    currentBalance = 100000000, 
    rtpRate = 96.5 
  } = req.body;

  const bet = Number(betCoins);

  if (!bet || isNaN(bet) || bet <= 0) {
    return res.status(400).json({ success: false, error: "Invalid test bet amount" });
  }

  if (serverGameBetSettings.enforceButtonsOnly && !serverGameBetSettings.allowedBetButtons.includes(bet)) {
    return res.status(400).json({
      success: false,
      error: `Bet amount ${bet.toLocaleString()} TEST COINS is not allowed. Allowed presets: ${serverGameBetSettings.allowedBetButtons.map(b => `${(b >= 1000 ? `${b/1000}K` : b)}`).join(', ')} TEST COINS.`
    });
  }

  if (bet < serverGameBetSettings.minBet || bet > serverGameBetSettings.maxBet) {
    return res.status(400).json({
      success: false,
      error: `Bet must be between ${serverGameBetSettings.minBet.toLocaleString()} and ${serverGameBetSettings.maxBet.toLocaleString()} TEST COINS.`
    });
  }

  if (currentBalance < bet) {
    return res.status(400).json({ 
      success: false, 
      error: "Insufficient TEST COIN balance! Please recharge test coins in your Wallet." 
    });
  }

  // Calculate outcome based on configured RTP
  const effectiveRtp = Math.max(80, Math.min(99, Number(rtpRate)));
  const winProb = (effectiveRtp / 100) * 0.48;
  const isWin = Math.random() < winProb;

  let multiplier = 0;
  let reward = 0;

  if (isWin) {
    // Generate realistic multiplier distribution
    const rand = Math.random();
    if (rand < 0.65) {
      multiplier = Number((1.2 + Math.random() * 1.8).toFixed(2)); // 1.2x - 3.0x
    } else if (rand < 0.90) {
      multiplier = Number((3.0 + Math.random() * 5.0).toFixed(2)); // 3.0x - 8.0x
    } else {
      multiplier = Number((8.0 + Math.random() * 25.0).toFixed(2)); // 8.0x - 33.0x Jackpot
    }
    reward = Math.floor(bet * multiplier);
  }

  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;
  const txId = `CTX-${gameId.replace('GM-', '')}-${Math.floor(100000 + Math.random() * 900000)}`;

  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId,
    gameName,
    category,
    bet,
    result: isWin ? `${multiplier}x Payout Win` : `Round Finished (No Hit)`,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? "WIN" : "LOSS",
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: effectiveRtp,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) {
    serverCasinoTransactions.pop();
  }

  res.json({
    success: true,
    outcome: isWin ? 'WIN' : 'LOSS',
    multiplier: isWin ? multiplier : 0,
    reward,
    bet,
    previousBalance,
    newBalance,
    transaction: tx,
    message: isWin 
      ? `🎉 BIG WIN! ${gameName} multiplier ${multiplier}x (+${reward.toLocaleString()} TEST COINS)`
      : `💥 Round completed. Bet ${bet.toLocaleString()} TEST COINS deducted.`
  });
});

// 3. Get Casino Transactions Ledger
app.get("/api/casino/transactions", (req, res) => {
  const { filter, gameId } = req.query;

  let filtered = [...serverCasinoTransactions];

  if (filter === 'WIN' || filter === 'LOSS') {
    filtered = filtered.filter(tx => tx.outcome === filter);
  }

  if (gameId && gameId !== 'All') {
    filtered = filtered.filter(tx => tx.gameId === gameId || tx.gameName.toLowerCase() === String(gameId).toLowerCase());
  }

  res.json({
    success: true,
    totalCount: filtered.length,
    transactions: filtered
  });
});

// 4. Reset TEST Game Data (Owner control)
app.post("/api/casino/reset", (req, res) => {
  serverCasinoTransactions = [
    {
      id: 'CTX-DICE-0001',
      userId: 'USR-882941',
      userName: 'Aarav Mehta',
      gameId: 'GM-09',
      gameName: 'DiceRolling',
      category: 'Dice',
      bet: 10000,
      result: 'Reset Initial Baseline',
      reward: 20000,
      multiplier: 2.0,
      outcome: 'WIN',
      previousBalance: 100000000,
      newBalance: 100010000,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      rtpSetting: 97.5,
      isTestMode: true,
      TEST_MODE: true
    }
  ];

  res.json({
    success: true,
    message: "TEST game transactions and statistics ledger reset successfully."
  });
});

// ==========================================
// 4.11 DEDICATED SR LIVE GAME CENTER BACKEND ENGINE
// ==========================================

interface ServerGameConfigItem {
  id: string;
  name: string;
  category: string;
  enabled: boolean;
  isFrozen: boolean;
  minBet: number;
  maxBet: number;
  allowedBets: number[];
  rtpRate: number;
  totalRounds: number;
  totalWagered: number;
  totalWon: number;
  suspiciousCount: number;
  description: string;
}

let serverGamesConfig: Record<string, ServerGameConfigItem> = {
  teen_patti: {
    id: 'teen_patti',
    name: 'Teen Patti Pro',
    category: 'Cards',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 100000,
    allowedBets: [1000, 2000, 5000, 10000, 20000, 30000, 50000, 100000],
    rtpRate: 97.2,
    totalRounds: 15420,
    totalWagered: 185040000,
    totalWon: 179858880,
    suspiciousCount: 0,
    description: '3-Card Poker with Live Table, Blind/Seen mode, Private Rooms, and Royal Showdowns.'
  },
  greedy_77: {
    id: 'greedy_77',
    name: 'Greedy 77 Slots',
    category: 'Slots',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 100000,
    allowedBets: [1000, 2000, 5000, 10000, 20000, 30000, 50000, 100000],
    rtpRate: 96.8,
    totalRounds: 42100,
    totalWagered: 421000000,
    totalWon: 407528000,
    suspiciousCount: 1,
    description: 'Classic 3-Reel Vegas Slot with 777 Jackpot, Gold Bars, Diamonds, and 777x Mega Multiplier.'
  },
  furut: {
    id: 'furut',
    name: 'Furut Party Wheel',
    category: 'Arcade',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 100000,
    allowedBets: [1000, 2000, 5000, 10000, 20000, 30000, 50000, 100000],
    rtpRate: 96.5,
    totalRounds: 28900,
    totalWagered: 289000000,
    totalWon: 278885000,
    suspiciousCount: 0,
    description: '8-Sector Neon Fruit Wheel with Watermelon, Cherry, Bell, and 100x Crown Jackpot.'
  },
  lucky_box: {
    id: 'lucky_box',
    name: 'Lucky Box Mystery',
    category: 'Mystery',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 50000,
    allowedBets: [1000, 5000, 20000, 50000],
    rtpRate: 98.0,
    totalRounds: 53200,
    totalWagered: 319200000,
    totalWon: 312816000,
    suspiciousCount: 0,
    description: 'Bronze, Silver, Gold, and Royal Diamond Mystery Boxes plus Daily Free Mystery Box.'
  },
  red_packet: {
    id: 'red_packet',
    name: 'Red Packet Wealth',
    category: 'Community',
    enabled: true,
    isFrozen: false,
    minBet: 5000,
    maxBet: 500000,
    allowedBets: [5000, 10000, 20000, 50000, 100000, 500000],
    rtpRate: 100.0,
    totalRounds: 9800,
    totalWagered: 196000000,
    totalWon: 196000000,
    suspiciousCount: 0,
    description: 'Peer-to-peer virtual coin red packets with lucky random grab and equal split.'
  },
  lava_game: {
    id: 'lava_game',
    name: 'Lava Game Multiplier',
    category: 'Crash & Multiplier',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000, 250000],
    rtpRate: 97.2,
    totalRounds: 18400,
    totalWagered: 184000000,
    totalWon: 178848000,
    suspiciousCount: 0,
    description: '10-Level Volcanic Tower Climb with up to 250x exponential safe cashout multipliers.'
  },
  slots: {
    id: 'slots',
    name: 'Vegas Royal 777 Slots',
    category: 'Slots',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000, 250000],
    rtpRate: 96.6,
    totalRounds: 34200,
    totalWagered: 342000000,
    totalWon: 330372000,
    suspiciousCount: 0,
    description: '5-Reel 25-Payline Vegas Slot with 10 Free Spins, Wild Stars, and 777x Grand Jackpots.'
  },
  tiger_game: {
    id: 'tiger_game',
    name: 'Dragon vs Tiger Fortune',
    category: 'Table Arena',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000],
    rtpRate: 97.5,
    totalRounds: 21900,
    totalWagered: 219000000,
    totalWon: 213525000,
    suspiciousCount: 0,
    description: 'Fast-paced Asian Arena Card Showdown with 2x Side payouts and 9x Tie Jackpot.'
  },
  mahjong: {
    id: 'mahjong',
    name: 'Mahjong Ways Cascade',
    category: 'Cascade & Tiles',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000, 250000],
    rtpRate: 96.9,
    totalRounds: 16800,
    totalWagered: 168000000,
    totalWon: 162792000,
    suspiciousCount: 0,
    description: '1024-Ways Cascading Mahjong with Gold Transforming Tiles and 10x Combo Multipliers.'
  },
  magic_slots: {
    id: 'magic_slots',
    name: 'Magic Slots Spellbook',
    category: 'Fantasy Slots',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000, 250000],
    rtpRate: 96.8,
    totalRounds: 19500,
    totalWagered: 195000000,
    totalWon: 188760000,
    suspiciousCount: 0,
    description: 'Mystic Archmage Spellbook with Arcane Free Spins and 1000x Max Mythic Payout.'
  }
};

// Daily Free Box Claims tracking by User ID: userId -> timestamp string
let serverDailyFreeBoxClaims: Record<string, string> = {};

// Helper: Evaluate 3-Card Teen Patti Hand Rank (Score higher is better)
function evaluateTeenPattiHand(cards: { suit: string; value: number; label: string }[]) {
  const vals = cards.map(c => c.value).sort((a, b) => a - b);
  const suits = cards.map(c => c.suit);
  const isFlush = suits[0] === suits[1] && suits[1] === suits[2];
  
  // Check sequence
  let isSequence = false;
  if (vals[2] - vals[1] === 1 && vals[1] - vals[0] === 1) isSequence = true;
  if (vals[0] === 2 && vals[1] === 3 && vals[2] === 14) isSequence = true; // A-2-3

  const isTrio = vals[0] === vals[1] && vals[1] === vals[2];
  const isPair = vals[0] === vals[1] || vals[1] === vals[2] || vals[0] === vals[2];

  let rankType = 'High Card';
  let rankScore = 100000 + vals[2] * 100 + vals[1] * 10 + vals[0];

  if (isTrio) {
    rankType = 'Trail (Set/Trio)';
    rankScore = 600000 + vals[0] * 100;
  } else if (isFlush && isSequence) {
    rankType = 'Pure Sequence';
    rankScore = 500000 + vals[2] * 100;
  } else if (isSequence) {
    rankType = 'Sequence';
    rankScore = 400000 + vals[2] * 100;
  } else if (isFlush) {
    rankType = 'Color (Flush)';
    rankScore = 300000 + vals[2] * 100 + vals[1] * 10 + vals[0];
  } else if (isPair) {
    rankType = 'Pair';
    const pairVal = (vals[0] === vals[1]) ? vals[0] : (vals[1] === vals[2] ? vals[1] : vals[0]);
    const kicker = (vals[0] === pairVal && vals[1] === pairVal) ? vals[2] : (vals[1] === pairVal && vals[2] === pairVal ? vals[0] : vals[1]);
    rankScore = 200000 + pairVal * 100 + kicker;
  }

  return { rankType, rankScore };
}

// 1. TEEN PATTI PLAY ENDPOINT (Server-Authoritative Multi-Hand)
app.post("/api/games/teen-patti/round", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    currentBalance = 100000000,
    actionType = "CHAAL", // "CHAAL", "SHOW", "BLIND"
    isPrivate = false,
    roomCode = ""
  } = req.body;

  const config = serverGamesConfig.teen_patti;
  if (!config.enabled || config.isFrozen) {
    return res.status(403).json({ success: false, error: "Teen Patti is temporarily under maintenance or disabled." });
  }

  const bet = Number(betCoins);
  if (!config.allowedBets.includes(bet)) {
    return res.status(400).json({ success: false, error: `Invalid bet amount. Allowed bets: ${config.allowedBets.map(b => `${b/1000}K`).join(', ')}` });
  }

  if (currentBalance < bet) {
    return res.status(400).json({ success: false, error: "Insufficient virtual coin balance! Please recharge virtual test coins." });
  }

  // Create Standard 52-Card Deck
  const suits = ['♠', '♥', '♦', '♣'];
  const values = [
    { value: 2, label: '2' }, { value: 3, label: '3' }, { value: 4, label: '4' }, { value: 5, label: '5' },
    { value: 6, label: '6' }, { value: 7, label: '7' }, { value: 8, label: '8' }, { value: 9, label: '9' },
    { value: 10, label: '10' }, { value: 11, label: 'J' }, { value: 12, label: 'Q' }, { value: 13, label: 'K' }, { value: 14, label: 'A' }
  ];
  const deck: { suit: string; value: number; label: string; id: string }[] = [];
  for (const s of suits) {
    for (const v of values) {
      deck.push({ suit: s, value: v.value, label: v.label, id: `${v.label}${s}` });
    }
  }

  // Fisher-Yates Shuffle with Cryptographic randomness
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  // Deal 3 cards to Player + 3 Opponents
  const playerHand = [deck.pop()!, deck.pop()!, deck.pop()!];
  const opp1Hand = [deck.pop()!, deck.pop()!, deck.pop()!]; // Vikram
  const opp2Hand = [deck.pop()!, deck.pop()!, deck.pop()!]; // Priya
  const opp3Hand = [deck.pop()!, deck.pop()!, deck.pop()!]; // Rahul

  const playerEval = evaluateTeenPattiHand(playerHand);
  const opp1Eval = evaluateTeenPattiHand(opp1Hand);
  const opp2Eval = evaluateTeenPattiHand(opp2Hand);
  const opp3Eval = evaluateTeenPattiHand(opp3Hand);

  // Determine highest scoring hand
  const allHands = [
    { name: userName || 'You', eval: playerEval, isUser: true },
    { name: 'Vikram', eval: opp1Eval, isUser: false },
    { name: 'Priya', eval: opp2Eval, isUser: false },
    { name: 'Rahul', eval: opp3Eval, isUser: false }
  ];
  allHands.sort((a, b) => b.eval.rankScore - a.eval.rankScore);

  const isWin = allHands[0].isUser;
  const potSize = bet * 4; // 4 seats pot
  const houseCommission = Math.floor(potSize * 0.05); // 5% house rake
  const winPayout = potSize - houseCommission;

  const reward = isWin ? winPayout : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  // Update Config Stats
  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-TP-${Math.floor(100000 + Math.random() * 900000)}`;
  const roundId = `RND-TP-${Date.now().toString().slice(-6)}`;
  const resultText = isWin 
    ? `Won Showdown with ${playerEval.rankType}! Beats ${allHands[1].name}'s ${allHands[1].eval.rankType}`
    : `Lost to ${allHands[0].name}'s ${allHands[0].eval.rankType} (Your hand: ${playerEval.rankType})`;

  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-02',
    gameName: 'Teen Patti Pro',
    category: 'Cards',
    bet,
    result: resultText,
    reward,
    multiplier: isWin ? Number((reward / bet).toFixed(2)) : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    roundId,
    transaction: tx,
    isWin,
    winnerName: allHands[0].name,
    playerHand,
    playerRank: playerEval.rankType,
    opponents: [
      { name: 'Vikram', hand: opp1Hand, rank: opp1Eval.rankType, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150' },
      { name: 'Priya', hand: opp2Hand, rank: opp2Eval.rankType, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150' },
      { name: 'Rahul', hand: opp3Hand, rank: opp3Eval.rankType, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150' }
    ],
    potSize,
    houseCommission,
    payout: reward,
    newBalance,
    isPrivate,
    roomCode: roomCode || 'ROOM-882'
  });
});

// 2. GREEDY 77 SLOTS SPIN ENDPOINT
app.post("/api/games/greedy-77/spin", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    currentBalance = 100000000 
  } = req.body;

  const config = serverGamesConfig.greedy_77;
  if (!config.enabled || config.isFrozen) {
    return res.status(403).json({ success: false, error: "Greedy 77 is temporarily under maintenance." });
  }

  const bet = Number(betCoins);
  if (!config.allowedBets.includes(bet)) {
    return res.status(400).json({ success: false, error: `Invalid bet. Allowed: ${config.allowedBets.map(b => `${b/1000}K`).join(', ')}` });
  }

  if (currentBalance < bet) {
    return res.status(400).json({ success: false, error: "Insufficient virtual coin balance!" });
  }

  // Symbol distribution: 777 (Jackpot), Gold 7, Diamond, Bar, Bell, Cherry, Blank
  const symbols = [
    { id: '777_JACKPOT', label: '777 🔥', mult3: 777, weight: 1 },
    { id: 'GOLD_7', label: '7 👑', mult3: 77, weight: 3 },
    { id: 'DIAMOND', label: '💎', mult3: 50, weight: 6 },
    { id: 'BAR', label: '🪙 BAR', mult3: 20, weight: 12 },
    { id: 'BELL', label: '🔔', mult3: 10, weight: 20 },
    { id: 'CHERRY', label: '🍒', mult3: 5, weight: 35 },
    { id: 'STAR', label: '⭐', mult3: 2, weight: 45 }
  ];

  // Weighted random pick
  const totalWeight = symbols.reduce((acc, s) => acc + s.weight, 0);
  function pickSymbol() {
    let rand = Math.random() * totalWeight;
    for (const s of symbols) {
      if (rand < s.weight) return s;
      rand -= s.weight;
    }
    return symbols[symbols.length - 1];
  }

  // Authoritative server RTP calculation
  const winChance = (config.rtpRate / 100) * 0.44;
  const isForcedWin = Math.random() < winChance;

  let reel1 = pickSymbol();
  let reel2 = pickSymbol();
  let reel3 = pickSymbol();

  if (isForcedWin) {
    // Pick winning combo based on distribution
    const winRand = Math.random();
    if (winRand < 0.005) {
      reel1 = reel2 = reel3 = symbols[0]; // 777x JACKPOT!
    } else if (winRand < 0.03) {
      reel1 = reel2 = reel3 = symbols[1]; // 77x
    } else if (winRand < 0.10) {
      reel1 = reel2 = reel3 = symbols[2]; // 50x
    } else if (winRand < 0.25) {
      reel1 = reel2 = reel3 = symbols[3]; // 20x
    } else if (winRand < 0.55) {
      reel1 = reel2 = reel3 = symbols[4]; // 10x
    } else {
      reel1 = reel2 = reel3 = symbols[5]; // 5x
    }
  }

  let multiplier = 0;
  let isWin = false;
  let winDescription = 'No Match';

  if (reel1.id === reel2.id && reel2.id === reel3.id) {
    multiplier = reel1.mult3;
    isWin = true;
    winDescription = `TRIPLE ${reel1.label}! (${multiplier}X Mega Payout)`;
  } else if (reel1.id === '777_JACKPOT' || reel2.id === '777_JACKPOT' || reel3.id === '777_JACKPOT') {
    multiplier = 2;
    isWin = true;
    winDescription = `Wild 777 Hit! (2X Payout)`;
  } else if (reel1.id === 'CHERRY' || reel2.id === 'CHERRY') {
    multiplier = 1.5;
    isWin = true;
    winDescription = `Cherry Match! (1.5X Payout)`;
  }

  const reward = isWin ? Math.floor(bet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-G77-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-03',
    gameName: 'Greedy 77 Slots',
    category: 'Slots',
    bet,
    result: `[${reel1.label} | ${reel2.label} | ${reel3.label}] - ${winDescription}`,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    reels: [reel1, reel2, reel3],
    isWin,
    multiplier,
    reward,
    winDescription,
    newBalance,
    transaction: tx
  });
});

// 3. FURUT (FRUIT PARTY WHEEL) SPIN ENDPOINT
app.post("/api/games/furut/spin", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    selectedSymbolId = "WATERMELON",
    currentBalance = 100000000 
  } = req.body;

  const config = serverGamesConfig.furut;
  if (!config.enabled || config.isFrozen) {
    return res.status(403).json({ success: false, error: "Furut Party Wheel is temporarily under maintenance." });
  }

  const bet = Number(betCoins);
  if (!config.allowedBets.includes(bet)) {
    return res.status(400).json({ success: false, error: `Invalid bet. Allowed: ${config.allowedBets.map(b => `${b/1000}K`).join(', ')}` });
  }

  if (currentBalance < bet) {
    return res.status(400).json({ success: false, error: "Insufficient virtual coin balance!" });
  }

  const fruitSectors = [
    { index: 0, id: 'CROWN', name: 'SR Crown', emoji: '👑', multiplier: 100, weight: 1 },
    { index: 1, id: 'CHERRY', name: 'Cherry', emoji: '🍒', multiplier: 2, weight: 35 },
    { index: 2, id: 'ORANGE', name: 'Orange', emoji: '🍊', multiplier: 5, weight: 20 },
    { index: 3, id: 'STRAWBERRY', name: 'Strawberry', emoji: '🍓', multiplier: 10, weight: 12 },
    { index: 4, id: 'LUCKY_77', name: 'Lucky 77', emoji: '🎰', multiplier: 50, weight: 2 },
    { index: 5, id: 'BELL', name: 'Golden Bell', emoji: '🔔', multiplier: 25, weight: 6 },
    { index: 6, id: 'GRAPE', name: 'Grape', emoji: '🍇', multiplier: 15, weight: 9 },
    { index: 7, id: 'WATERMELON', name: 'Watermelon', emoji: '🍉', multiplier: 20, weight: 7 }
  ];

  // Weighted wheel selection
  const totalWeight = fruitSectors.reduce((acc, f) => acc + f.weight, 0);
  let rand = Math.random() * totalWeight;
  let winningSector = fruitSectors[0];
  for (const s of fruitSectors) {
    if (rand < s.weight) {
      winningSector = s;
      break;
    }
    rand -= s.weight;
  }

  // Check if player selected the winning sector
  const isMatch = winningSector.id === selectedSymbolId;
  const isWin = isMatch;
  const multiplier = isWin ? winningSector.multiplier : 0;
  const reward = isWin ? Math.floor(bet * multiplier) : 0;

  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-FRT-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-05',
    gameName: 'Furut Party Wheel',
    category: 'Arcade',
    bet,
    result: `Landed on ${winningSector.emoji} ${winningSector.name} (${winningSector.multiplier}X) - Your Pick: ${selectedSymbolId}`,
    reward,
    multiplier,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    landingIndex: winningSector.index,
    winningSector,
    isWin,
    multiplier,
    reward,
    newBalance,
    transaction: tx
  });
});

// 4. LUCKY BOX OPEN ENDPOINT (Bronze, Silver, Gold, Royal Diamond & Daily Free)
app.post("/api/games/lucky-box/open", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    boxTier = "BRONZE", // "FREE", "BRONZE", "SILVER", "GOLD", "ROYAL_DIAMOND"
    currentBalance = 100000000 
  } = req.body;

  const config = serverGamesConfig.lucky_box;
  if (!config.enabled || config.isFrozen) {
    return res.status(403).json({ success: false, error: "Lucky Box system is temporarily under maintenance." });
  }

  const boxTiersConfig: Record<string, { cost: number; name: string; icon: string; minReward: number; maxReward: number; extraGift?: string }> = {
    FREE: { cost: 0, name: 'Daily Free Mystery Box', icon: '🎁', minReward: 500, maxReward: 3000 },
    BRONZE: { cost: 1000, name: 'Bronze Mystery Box', icon: '📦', minReward: 500, maxReward: 5000, extraGift: '🌹 Rose' },
    SILVER: { cost: 5000, name: 'Silver Fortune Box', icon: '🥈', minReward: 3000, maxReward: 25000, extraGift: '💖 Heart Confetti' },
    GOLD: { cost: 20000, name: 'Gold Emperor Box', icon: '🥇', minReward: 15000, maxReward: 100000, extraGift: '👑 Imperial Crown' },
    ROYAL_DIAMOND: { cost: 50000, name: 'Royal Diamond Vault Box', icon: '👑', minReward: 40000, maxReward: 500000, extraGift: '🐉 Golden Dragon' }
  };

  const selectedTier = boxTiersConfig[boxTier] || boxTiersConfig.BRONZE;
  const cost = selectedTier.cost;

  // Daily Free Box Check (24h cooldown)
  if (boxTier === 'FREE') {
    const lastClaim = serverDailyFreeBoxClaims[userId];
    if (lastClaim) {
      const lastTime = new Date(lastClaim).getTime();
      const now = Date.now();
      const elapsedHours = (now - lastTime) / (1000 * 60 * 60);
      if (elapsedHours < 24) {
        const remainingHours = Math.ceil(24 - elapsedHours);
        return res.status(400).json({ 
          success: false, 
          error: `Daily Free Box already claimed! Next free box available in ${remainingHours} hours.` 
        });
      }
    }
    serverDailyFreeBoxClaims[userId] = new Date().toISOString();
  } else {
    if (currentBalance < cost) {
      return res.status(400).json({ success: false, error: "Insufficient virtual coins to open this box!" });
    }
  }

  // Generate random reward
  const isJackpot = Math.random() < 0.08;
  let coinsWon = 0;
  if (isJackpot) {
    coinsWon = selectedTier.maxReward;
  } else {
    coinsWon = Math.floor(selectedTier.minReward + Math.random() * (selectedTier.maxReward - selectedTier.minReward));
  }

  // Round to nice hundreds
  coinsWon = Math.max(100, Math.floor(coinsWon / 100) * 100);

  const vipDaysReward = isJackpot ? (boxTier === 'ROYAL_DIAMOND' ? 7 : 3) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - cost + coinsWon;

  config.totalRounds += 1;
  config.totalWagered += cost;
  config.totalWon += coinsWon;

  const txId = `CTX-LBX-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-LBX',
    gameName: selectedTier.name,
    category: 'Mystery',
    bet: cost,
    result: `Unboxed ${coinsWon.toLocaleString()} TEST COINS ${vipDaysReward > 0 ? `+ ${vipDaysReward} VIP Days` : ''} ${selectedTier.extraGift ? `+ ${selectedTier.extraGift}` : ''}`,
    reward: coinsWon,
    multiplier: cost > 0 ? Number((coinsWon / cost).toFixed(2)) : 1,
    outcome: coinsWon >= cost ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    boxTier,
    boxName: selectedTier.name,
    coinsWon,
    vipDaysReward,
    extraGift: selectedTier.extraGift,
    isJackpot,
    cost,
    newBalance,
    transaction: tx,
    nextFreeAvailableAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
  });
});

// 5. GET ACTIVE RED PACKETS FEED
app.get("/api/games/red-packet/active", (req, res) => {
  res.json({
    success: true,
    packets: serverRedPackets.filter(p => p.status === 'ACTIVE' && !p.isExpired)
  });
});

// ==========================================
// 5.1 LAVA GAME (VOLCANIC CLIMB MULTIPLIER) ENDPOINTS
// ==========================================
app.post("/api/games/lava/start", (req, res) => {
  const { userId = "USR-882941", userName = "Aarav Mehta", betCoins = 10000 } = req.body;
  const config = serverGamesConfig.lava_game;
  config.totalRounds += 1;
  config.totalWagered += Number(betCoins);

  res.json({
    success: true,
    message: "Volcanic expedition started! Watch out for sudden eruptions.",
    currentStep: 0,
    multiplier: 1.0
  });
});

app.post("/api/games/lava/step", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    step = 1, 
    safeOdds = 0.9 
  } = req.body;

  const config = serverGamesConfig.lava_game;
  const bet = Number(betCoins);

  // Volcanic RNG
  const rand = Math.random();
  const erupted = rand >= Number(safeOdds);

  let tx: ServerCasinoTx | null = null;
  if (erupted) {
    const txId = `CTX-LAV-${Math.floor(100000 + Math.random() * 900000)}`;
    tx = {
      id: txId,
      userId,
      userName,
      gameId: 'GM-LAVA',
      gameName: 'Lava Game Multiplier',
      category: 'Crash & Multiplier',
      bet,
      result: `Erupted at Step ${step}`,
      reward: 0,
      multiplier: 0,
      outcome: 'LOSS',
      previousBalance: 0,
      newBalance: 0,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      rtpSetting: config.rtpRate,
      isTestMode: true,
      TEST_MODE: true
    };
    serverCasinoTransactions.unshift(tx);
    if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();
  }

  res.json({
    success: true,
    erupted,
    step,
    transaction: tx
  });
});

app.post("/api/games/lava/cashout", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    stepReached = 5, 
    multiplier = 4.8, 
    payout = 48000 
  } = req.body;

  const config = serverGamesConfig.lava_game;
  const bet = Number(betCoins);
  const reward = Number(payout);

  config.totalWon += reward;

  const txId = `CTX-LAV-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-LAVA',
    gameName: 'Lava Game Multiplier',
    category: 'Crash & Multiplier',
    bet,
    result: `Safe Cashout at Step ${stepReached} (${multiplier}X)`,
    reward,
    multiplier: Number(multiplier),
    outcome: 'WIN',
    previousBalance: 0,
    newBalance: reward,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };
  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    reward,
    multiplier,
    transaction: tx
  });
});

// ==========================================
// 5.2 VEGAS ROYAL 777 SLOTS (5-REEL 25-PAYLINE) ENDPOINT
// ==========================================
app.post("/api/games/slots/spin", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    isFreeSpin = false, 
    currentBalance = 1000000 
  } = req.body;

  const config = serverGamesConfig.slots;
  const bet = isFreeSpin ? 0 : Number(betCoins);

  const slotSymbols = ['7️⃣', '💎', '👑', '🪙', '🔔', '🍒', '⭐', '⚡'];
  
  // Generate 5x3 Grid
  const grid: string[][] = [];
  for (let r = 0; r < 3; r++) {
    const row: string[] = [];
    for (let c = 0; c < 5; c++) {
      const sym = slotSymbols[Math.floor(Math.random() * slotSymbols.length)];
      row.push(sym);
    }
    grid.push(row);
  }

  // Count top symbols
  const flat = grid.flat();
  const sevensCount = flat.filter(s => s === '7️⃣').length;
  const diamondsCount = flat.filter(s => s === '💎').length;
  const crownsCount = flat.filter(s => s === '👑').length;
  const scattersCount = flat.filter(s => s === '⚡').length;

  let isWin = false;
  let multiplier = 0;
  let winDescription = 'No winning payline';
  let freeSpinsAwarded = 0;

  if (scattersCount >= 3) {
    freeSpinsAwarded = 10;
    multiplier += 20;
    isWin = true;
    winDescription = `⚡ 3+ SCATTERS TRIGGERED! 10 FREE SPINS + 20X!`;
  }

  if (sevensCount >= 4) {
    multiplier += 50;
    isWin = true;
    winDescription = `🔥 MEGA 777 HIT! ${sevensCount}x Sevens (50X Payout)`;
  } else if (diamondsCount >= 4) {
    multiplier += 25;
    isWin = true;
    winDescription = `💎 DIAMOND FEVER! (25X Payout)`;
  } else if (crownsCount >= 4) {
    multiplier += 15;
    isWin = true;
    winDescription = `👑 ROYAL CROWN COMBO! (15X Payout)`;
  } else if (Math.random() < 0.38) {
    multiplier += 3.5;
    isWin = true;
    winDescription = `✨ 5-Line Match Combo (3.5X Payout)`;
  }

  const effectiveBet = Number(betCoins);
  const reward = isWin ? Math.floor(effectiveBet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-SLT-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-SLOTS',
    gameName: 'Vegas Royal 777 Slots',
    category: 'Slots',
    bet: effectiveBet,
    result: winDescription,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    grid,
    isWin,
    multiplier,
    reward,
    freeSpinsAwarded,
    winDescription,
    newBalance,
    transaction: tx
  });
});

// ==========================================
// 5.3 DRAGON VS TIGER ARENA ENDPOINT
// ==========================================
app.post("/api/games/tiger/deal", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    bets = { DRAGON: 0, TIGER: 0, TIE: 0, TIGER_PAIR: 0 }, 
    totalBet = 10000, 
    currentBalance = 1000000 
  } = req.body;

  const config = serverGamesConfig.tiger_game;
  const betSum = Number(totalBet);

  const suits = ['♠', '♥', '♦', '♣'];
  const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

  const dRankIndex = Math.floor(Math.random() * ranks.length);
  const tRankIndex = Math.floor(Math.random() * ranks.length);

  const dragonCard = {
    rank: ranks[dRankIndex],
    suit: suits[Math.floor(Math.random() * suits.length)],
    value: dRankIndex + 2
  };

  const tigerCard = {
    rank: ranks[tRankIndex],
    suit: suits[Math.floor(Math.random() * suits.length)],
    value: tRankIndex + 2
  };

  let winner: 'DRAGON' | 'TIGER' | 'TIE' = 'TIE';
  if (dragonCard.value > tigerCard.value) winner = 'DRAGON';
  else if (tigerCard.value > dragonCard.value) winner = 'TIGER';

  let totalPayout = 0;
  let message = '';

  if (winner === 'DRAGON') {
    if (bets.DRAGON > 0) totalPayout += bets.DRAGON * 2;
    message = `🐉 DRAGON WINS (${dragonCard.rank} vs ${tigerCard.rank})!`;
  } else if (winner === 'TIGER') {
    if (bets.TIGER > 0) totalPayout += bets.TIGER * 2;
    message = `🐯 TIGER WINS (${tigerCard.rank} vs ${dragonCard.rank})!`;
  } else {
    // TIE -> 9x Payout
    if (bets.TIE > 0) totalPayout += bets.TIE * 9;
    // Push half back on Dragon / Tiger on tie
    if (bets.DRAGON > 0) totalPayout += Math.floor(bets.DRAGON * 0.5);
    if (bets.TIGER > 0) totalPayout += Math.floor(bets.TIGER * 0.5);
    message = `🤝 EXACT TIE MATCH (${dragonCard.rank} = ${tigerCard.rank})! 9X TIE JACKPOT!`;
  }

  const isWin = totalPayout > 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - betSum + totalPayout;

  config.totalRounds += 1;
  config.totalWagered += betSum;
  config.totalWon += totalPayout;

  const txId = `CTX-TGR-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-TIGER',
    gameName: 'Dragon vs Tiger Fortune',
    category: 'Table Arena',
    bet: betSum,
    result: message,
    reward: totalPayout,
    multiplier: isWin ? Number((totalPayout / betSum).toFixed(2)) : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    cards: { dragon: dragonCard, tiger: tigerCard },
    winner,
    totalPayout,
    message,
    newBalance,
    transaction: tx
  });
});

// ==========================================
// 5.4 MAHJONG WAYS CASCADE ENDPOINT
// ==========================================
app.post("/api/games/mahjong/cascade", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    currentBalance = 1000000 
  } = req.body;

  const config = serverGamesConfig.mahjong;
  const bet = Number(betCoins);

  const tiles = [
    { id: 'RED_DRAGON', label: '中', name: 'Red Dragon', color: 'text-red-500', mult: 50, isGold: false },
    { id: 'GREEN_DRAGON', label: '發', name: 'Green Dragon', color: 'text-emerald-500', mult: 40, isGold: false },
    { id: 'WHITE_DRAGON', label: '白', name: 'White Dragon', color: 'text-blue-400', mult: 30, isGold: false },
    { id: 'EIGHT_WAN', label: '八萬', name: '8 Character', color: 'text-amber-400', mult: 15, isGold: true },
    { id: 'FIVE_BAMBOO', label: '伍索', name: '5 Bamboo', color: 'text-emerald-400', mult: 10, isGold: false },
    { id: 'FOUR_DOT', label: '四筒', name: '4 Dot', color: 'text-cyan-400', mult: 8, isGold: false },
    { id: 'GOLDEN_INGOT', label: '元寶', name: 'Golden Ingot', color: 'text-yellow-300', mult: 100, isGold: true },
    { id: 'WILD_TILES', label: '百搭', name: 'Wild Tile', color: 'text-purple-400', mult: 200, isGold: true }
  ];

  // 5x4 Grid
  const grid: any[][] = [];
  for (let r = 0; r < 4; r++) {
    const row: any[] = [];
    for (let c = 0; c < 5; c++) {
      const t = { ...tiles[Math.floor(Math.random() * tiles.length)] };
      // 15% chance to transform into gold tile
      if (Math.random() < 0.15) t.isGold = true;
      row.push(t);
    }
    grid.push(row);
  }

  // Cascading combo engine (1x -> 2x -> 3x -> 5x -> 10x)
  const isWin = Math.random() < 0.46;
  const comboCount = isWin ? Math.floor(1 + Math.random() * 4) : 0;
  const multiplierSteps = [0, 1, 2, 3, 5, 10];
  const multiplier = isWin ? multiplierSteps[Math.min(comboCount, 5)] * (Math.random() < 0.2 ? 5 : 2) : 0;

  const reward = isWin ? Math.floor(bet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const message = isWin 
    ? `🀄 ${comboCount}x Consecutive Mahjong Cascades! (${multiplier}X Payout)` 
    : 'No tile combinations connected';

  const txId = `CTX-MHJ-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-MAHJONG',
    gameName: 'Mahjong Ways Cascade',
    category: 'Cascade & Tiles',
    bet,
    result: message,
    reward,
    multiplier,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    grid,
    comboCount: Math.max(1, comboCount),
    isWin,
    multiplier,
    reward,
    message,
    newBalance,
    transaction: tx
  });
});

// ==========================================
// 5.5 MAGIC SLOTS & SPELLBOOK ENDPOINT
// ==========================================
app.post("/api/games/magic-slots/spin", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    isFreeSpin = false, 
    currentBalance = 1000000 
  } = req.body;

  const config = serverGamesConfig.magic_slots;
  const bet = isFreeSpin ? 0 : Number(betCoins);

  const magicSymbols = ['🧙‍♂️', '📖', '🔮', '🦅', '🧪', '💍', '🎩', '📜'];

  // 5x3 Grid
  const grid: string[][] = [];
  for (let r = 0; r < 3; r++) {
    const row: string[] = [];
    for (let c = 0; c < 5; c++) {
      row.push(magicSymbols[Math.floor(Math.random() * magicSymbols.length)]);
    }
    grid.push(row);
  }

  const flat = grid.flat();
  const wizardCount = flat.filter(s => s === '🧙‍♂️').length;
  const spellbookCount = flat.filter(s => s === '📖').length;
  const orbCount = flat.filter(s => s === '🔮').length;

  let isWin = false;
  let multiplier = 0;
  let winDescription = 'Spell energy dissipated';
  let freeSpinsAwarded = 0;

  if (orbCount >= 3) {
    freeSpinsAwarded = 10;
    multiplier += 25;
    isWin = true;
    winDescription = `🔮 3+ ARCANE CRYSTAL ORBS! 10 FREE CASTS + 25X!`;
  }

  if (wizardCount >= 3) {
    multiplier += 50;
    isWin = true;
    winDescription = `🧙‍♂️ GRAND ARCHMAGE WILD SPELL! (50X Payout)`;
  } else if (spellbookCount >= 3) {
    multiplier += 20;
    isWin = true;
    winDescription = `📖 ANCIENT SPELLBOOK AWAKENED! (20X Payout)`;
  } else if (Math.random() < 0.38) {
    multiplier += 4.5;
    isWin = true;
    winDescription = `✨ Arcane Elemental Match (4.5X Payout)`;
  }

  const effectiveBet = Number(betCoins);
  const reward = isWin ? Math.floor(effectiveBet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-MAG-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-MAGIC',
    gameName: 'Magic Slots Spellbook',
    category: 'Fantasy Slots',
    bet: effectiveBet,
    result: winDescription,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    grid,
    isWin,
    multiplier,
    reward,
    freeSpinsAwarded,
    winDescription,
    newBalance,
    transaction: tx
  });
});

// 6. ADMIN GAME CENTER MANAGEMENT CONFIG & STATS
app.get("/api/games/admin/config", (req, res) => {
  res.json({
    success: true,
    configs: serverGamesConfig
  });
});

app.post("/api/games/admin/config", (req, res) => {
  const { gameId, enabled, isFrozen, minBet, maxBet, rtpRate } = req.body;
  if (!serverGamesConfig[gameId]) {
    return res.status(404).json({ success: false, error: `Game ${gameId} not found.` });
  }

  const target = serverGamesConfig[gameId];
  if (enabled !== undefined) target.enabled = Boolean(enabled);
  if (isFrozen !== undefined) target.isFrozen = Boolean(isFrozen);
  if (minBet !== undefined && !isNaN(Number(minBet))) target.minBet = Number(minBet);
  if (maxBet !== undefined && !isNaN(Number(maxBet))) target.maxBet = Number(maxBet);
  if (rtpRate !== undefined && !isNaN(Number(rtpRate))) target.rtpRate = Number(rtpRate);

  res.json({
    success: true,
    message: `Settings for ${target.name} updated successfully by Administrator.`,
    game: target
  });
});

// 7. GET SUSPICIOUS GAME ACTIVITY / INTEGRITY LOGS
app.get("/api/games/admin/suspicious", (req, res) => {
  const suspiciousList = serverCasinoTransactions
    .filter(tx => tx.bet >= 50000 || tx.multiplier >= 50 || tx.reward >= 500000)
    .slice(0, 50);

  res.json({
    success: true,
    totalSuspicious: suspiciousList.length,
    alerts: suspiciousList
  });
});



// ==========================================
// 5. OWNER TEST WALLET & COIN SELLER SYSTEM
// ==========================================

let serverOwnerTestCoinBalance = 500000000; // 500,000,000 TEST COINS

let serverCoinSellers: any[] = [];

let serverOwnerToSellerTxs: any[] = [];

let serverSellerToUserTxs: any[] = [];

// Mock User Database for server validation and virtual wallet operations
export interface ServerUserRecord {
  id: string; // 7-Digit sequential ID (0000001, 0000002, etc.)
  name: string;
  username: string;
  email?: string;
  phone?: string;
  coinBalance: number;
  diamondBalance: number;
  boltBalance?: number;
  vipLevel: number;
  svipLevel?: number;
  userLevel?: number;
  role?: string;
  roleStatus?: string;
  roleTag?: string;
  status: string;
  avatar?: string;
  hostTag?: string;
  avatarFrameId?: string;
  avatarFrameUrl?: string;
  countryCode?: string;
  countryFlag?: string;
  countryName?: string;
  bio?: string;
  gender?: string;
  dob?: string;
  profileTag?: string;
  joinedDate?: string;
  lastActive?: string;
  totalSpentCoins?: number;
  totalRechargedUSD?: number;
  deviceType?: string;
  registrationDate?: string;
  lastLogin?: string;
  linkedProviders?: Record<string, string>;
  linkedEmails?: string[];
  linkedPhones?: string[];
  boundDeviceIds?: string[];
  boundFingerprints?: string[];
}

// ==========================================
// PERSISTENT STORAGE ENGINE (JSON FILE DB)
// ==========================================
const DATA_DIR = path.join(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const COUNTER_STORE_FILE = path.join(DATA_DIR, 'counter_store.json');

function safeLoadJson<T>(filePath: string, fallback: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error(`[Storage] Failed to read ${filePath}:`, err);
  }
  return fallback;
}

function safeSaveJson(filePath: string, data: any): boolean {
  try {
    const tempPath = `${filePath}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempPath, filePath);
    return true;
  } catch (err) {
    console.error(`[Storage] Failed to write ${filePath}:`, err);
    try { if (fs.existsSync(`${filePath}.tmp`)) fs.unlinkSync(`${filePath}.tmp`); } catch {}
    return false;
  }
}

// 7-Digit Sequential User ID Counter (Backend-authoritative, auto-incrementing, exactly 7 digits: 0000001, 0000002, 0000003...)
// Rule 1: First User ID = 0000001
// Rule 2: Next new User ID = 0000002, 0000003, 0000004...
// Rule 3: All User IDs are always exactly 7 digits with leading zeroes.
// Rule 4: Generated automatically on backend/database; never manual from frontend.
// Rule 5: No ID is ever assigned to two users (collision-proof check).
// Rule 7: Only genuinely new users receive the next sequential ID.
// Rule 8: Existing IDs are permanent, never reset or reused.
// Rule 10: Never reuse an old User ID after an account is deleted/banned.
let serverUserIdCounter = 15; // Current authoritative highest assigned ID
const DELETED_USER_IDS_FILE = path.join(DATA_DIR, 'deleted_user_ids.json');
let serverDeletedUserIds: string[] = safeLoadJson<string[]>(DELETED_USER_IDS_FILE, [
  '0000002', '0000003', '0000004', '0000005', '0000006', '0000007', '0000008', '0000009', '0000010'
]);

export function saveDeletedUserIdsStore() {
  safeSaveJson(DELETED_USER_IDS_FILE, serverDeletedUserIds);
}

// In-process reservation map to guarantee atomic non-colliding ID generation even with concurrent requests
const reservedUserIds = new Set<string>();

// Helper to compute next guaranteed unique auto-incrementing 7-digit ID (0000001 -> 0000002 -> 0000003...)
export function getNextSequentialUserId(): string {
  // Sync deleted IDs from disk
  const currentDeleted = safeLoadJson<string[]>(DELETED_USER_IDS_FILE, serverDeletedUserIds);
  serverDeletedUserIds = Array.from(new Set([...serverDeletedUserIds, ...currentDeleted]));

  // Read persisted counter from disk if available
  const persistedRecord = safeLoadJson<{ counter: number; lastAssignedId?: string }>(COUNTER_STORE_FILE, { counter: 14 });
  const persistedCounter = typeof persistedRecord.counter === 'number' ? persistedRecord.counter : 14;

  // Determine highest existing valid 7-digit sequential ID among all users
  const existingNumeric = Object.values(serverUsers)
    .map(u => {
      const digits = String(u.id || '').replace(/\D/g, '');
      const num = parseInt(digits, 10);
      return (!isNaN(num) && num > 0 && num < 10000000) ? num : 0;
    })
    .filter(n => n > 0);
  const maxExisting = existingNumeric.length > 0 ? Math.max(...existingNumeric) : 0;

  let nextNum = Math.max(serverUserIdCounter, maxExisting, persistedCounter);

  // Guarantee strictly unused, non-colliding sequential 7-digit ID
  let candidateId = '';
  do {
    nextNum += 1;
    candidateId = String(nextNum).padStart(7, '0');
  } while (
    serverUsers[candidateId] || 
    serverDeletedUserIds.includes(candidateId) || 
    reservedUserIds.has(candidateId)
  );

  // Atomically claim candidateId in reservation set
  reservedUserIds.add(candidateId);
  serverUserIdCounter = nextNum;

  // Persist counter immediately to database file
  safeSaveJson(COUNTER_STORE_FILE, {
    counter: nextNum,
    lastAssignedId: candidateId,
    updatedAt: new Date().toISOString()
  });

  return candidateId;
}

export function releaseReservedUserId(id: string) {
  reservedUserIds.delete(id);
}

// Single Active Session Map (One ID = One Active Mobile Session security rule)
let serverActiveSessions: Record<string, {
  sessionToken: string;
  deviceId?: string;
  loginAt: string;
  lastActiveAt: string;
}> = {};

// Host Agency Hierarchy & Approval State
export interface ServerAgency {
  id: string;
  name: string;
  ownerId: string;
  ownerName: string;
  logo: string;
  verified: boolean;
  commissionRate: number;
  totalHosts: number;
  description: string;
}

let serverAgencies: ServerAgency[] = [];

let serverAgencyRequests: Array<{
  id: string;
  hostId: string;
  hostName: string;
  hostAvatar?: string;
  agencyId: string;
  agencyName: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  requestDate: string;
}> = [];

let serverAgencyMemberships: Record<string, {
  agencyId: string;
  agencyName: string;
  joinedAt: string;
  status: 'APPROVED';
}> = {};

// Auth Identifier Linking map (email, phone, providerId -> 7-digit User ID)
let serverAuthAccounts: Record<string, {
  userId: string;
  provider: string;
  identifier: string;
  linkedAt: string;
}> = {
  'salamstarhotel@gmail.com': { userId: '0000001', provider: 'google', identifier: 'salamstarhotel@gmail.com', linkedAt: '2025-01-01' },
  'sr.angel@diyolive.io': { userId: '0000001', provider: 'email', identifier: 'sr.angel@diyolive.io', linkedAt: '2025-02-15' },
  'kavita.rao@gmail.com': { userId: '0000012', provider: 'email', identifier: 'kavita.rao@gmail.com', linkedAt: '2025-01-25' },
  'arjun.varma@gmail.com': { userId: '0000013', provider: 'email', identifier: 'arjun.varma@gmail.com', linkedAt: '2025-02-05' }
};

let serverUsers: Record<string, ServerUserRecord> = {
  '0000001': {
    id: '0000001',
    name: 'Salam Star Owner',
    username: 'salamstar_owner',
    email: 'salamstarhotel@gmail.com',
    coinBalance: 500000000,
    diamondBalance: 1000000,
    boltBalance: 1000000,
    vipLevel: 10,
    svipLevel: 5,
    userLevel: 100,
    role: 'OWNER',
    roleStatus: 'Active',
    roleTag: 'OWNER',
    avatarFrameId: 'FRM-ROLE-OWNER',
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    countryCode: 'NP',
    countryFlag: '🇳🇵',
    countryName: 'Nepal',
    bio: '👑 DIYO LIVE Supreme Owner & Founder',
    joinedDate: '2025-01-01',
    registrationDate: '2025-01-01',
    lastActive: 'Just now',
    lastLogin: 'Just now',
    totalSpentCoins: 0,
    totalRechargedUSD: 100000
  },
  '0000012': {
    id: '0000012',
    name: 'Kavita Rao (Manager B)',
    username: 'kavita_mgr_b',
    email: 'kavita.rao@gmail.com',
    coinBalance: 75000,
    diamondBalance: 15000,
    boltBalance: 0,
    vipLevel: 5,
    userLevel: 40,
    role: 'MANAGER',
    roleTag: 'MANAGER',
    roleStatus: 'Active',
    avatarFrameId: 'FRM-ROLE-MANAGER',
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    countryCode: 'NP',
    countryFlag: '🇳🇵',
    countryName: 'Nepal',
    bio: 'Manager B — Independent Operational Branch',
    joinedDate: '2025-01-25',
    registrationDate: '2025-01-25',
    lastActive: 'Just now',
    lastLogin: 'Just now',
    totalSpentCoins: 0
  },
  '0000013': {
    id: '0000013',
    name: 'Arjun Varma',
    username: 'arjun_admin_b',
    email: 'arjun.varma@gmail.com',
    coinBalance: 40000,
    diamondBalance: 8500,
    boltBalance: 0,
    vipLevel: 4,
    userLevel: 30,
    role: 'SUPER_ADMIN',
    roleTag: 'SUPER ADMIN',
    roleStatus: 'Active',
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    countryCode: 'NP',
    countryFlag: '🇳🇵',
    countryName: 'Nepal',
    bio: 'Super Admin under Manager B reporting line',
    joinedDate: '2025-02-05',
    registrationDate: '2025-02-05',
    lastActive: '30m ago',
    lastLogin: '30m ago',
    totalSpentCoins: 0
  },
  '0000014': {
    id: '0000014',
    name: 'Diyo Staff 014',
    username: 'diyostaff014',
    email: 'staff014@diyolive.io',
    coinBalance: 50000,
    diamondBalance: 10000,
    boltBalance: 0,
    vipLevel: 4,
    userLevel: 25,
    role: 'USER',
    roleTag: 'USER',
    roleStatus: 'Active',
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    countryCode: 'NP',
    countryFlag: '🇳🇵',
    countryName: 'Nepal',
    bio: 'Verified Candidate ready for official staff deployment',
    joinedDate: '2025-02-10',
    registrationDate: '2025-02-10',
    lastActive: 'Just now',
    lastLogin: 'Just now',
    totalSpentCoins: 0
  }
};

// ==========================================
// PERSISTENT STORAGE FILE PATHS
// ==========================================
const USERS_STORE_FILE = path.join(DATA_DIR, 'users_store.json');
const AUTH_ACCOUNTS_FILE = path.join(DATA_DIR, 'auth_accounts_store.json');
const WITHDRAWALS_STORE_FILE = path.join(DATA_DIR, 'withdrawals_store.json');
const DEVICE_STORE_FILE = path.join(DATA_DIR, 'device_store.json');
const FINGERPRINT_STORE_FILE = path.join(DATA_DIR, 'fingerprint_store.json');
const AGENCY_STORE_FILE = path.join(DATA_DIR, 'agency_store.json');
const BANNERS_STORE_FILE = path.join(DATA_DIR, 'banners_store.json');
const LIVE_ROOMS_STORE_FILE = path.join(DATA_DIR, 'live_rooms_store.json');
const PARTY_ROOM_STORE_FILE = path.join(DATA_DIR, 'party_room_store.json');
const HIERARCHY_STORE_FILE = path.join(DATA_DIR, 'hierarchy_relationships_store.json');
const HIERARCHY_AUDIT_STORE_FILE = path.join(DATA_DIR, 'hierarchy_audit_store.json');

export function saveUsersStore() {
  safeSaveJson(USERS_STORE_FILE, serverUsers);
}

export function saveAuthAccountsStore() {
  safeSaveJson(AUTH_ACCOUNTS_FILE, serverAuthAccounts);
}

export function saveWithdrawalsStore() {
  safeSaveJson(WITHDRAWALS_STORE_FILE, serverWithdrawals);
}

export function saveDeviceStore() {
  safeSaveJson(DEVICE_STORE_FILE, serverDeviceBindings);
}

export function saveFingerprintStore() {
  safeSaveJson(FINGERPRINT_STORE_FILE, serverFingerprintBindings);
}

export function saveAgencyStore() {
  safeSaveJson(AGENCY_STORE_FILE, {
    requests: serverAgencyRequests,
    memberships: serverAgencyMemberships
  });
}

export function saveBannersStore() {
  safeSaveJson(BANNERS_STORE_FILE, serverBanners);
}

export function saveLiveRoomsStore() {
  safeSaveJson(LIVE_ROOMS_STORE_FILE, serverLiveRooms);
}

export function saveHierarchyStore(): boolean {
  const relationshipsSaved = safeSaveJson(HIERARCHY_STORE_FILE, serverHierarchyRelationships);
  const auditSaved = safeSaveJson(HIERARCHY_AUDIT_STORE_FILE, serverHierarchyAudit);
  return relationshipsSaved && auditSaved;
}

// 1. Device Binding State (Strictly 1 Physical Device = 1 DIYO LIVE Account)
let serverDeviceBindings: Record<string, string> = safeLoadJson<Record<string, string>>(DEVICE_STORE_FILE, {});
let serverFingerprintBindings: Record<string, string> = safeLoadJson<Record<string, string>>(FINGERPRINT_STORE_FILE, {});

// 2. Load and merge persistent Users (filtering out any deleted IDs and enforcing canonical keys)
const loadedUsers = safeLoadJson<Record<string, ServerUserRecord>>(USERS_STORE_FILE, {});
if (Object.keys(loadedUsers).length > 0) {
  for (const [key, user] of Object.entries(loadedUsers)) {
    const canonicalId = String(user.id || key).padStart(7, '0');
    if (serverDeletedUserIds.includes(canonicalId)) {
      continue;
    }
    user.id = canonicalId;
    serverUsers[canonicalId] = user;
  }
}
saveUsersStore();

// Recalculate 7-digit sequential counter so new IDs never clash with existing records or deleted IDs
const existingNumeric = Object.values(serverUsers)
  .map(u => {
    const digits = String(u.id || '').replace(/\D/g, '');
    const num = parseInt(digits, 10);
    return (!isNaN(num) && num > 0 && num < 10000000) ? num : 0;
  })
  .filter(n => n > 0);
if (existingNumeric.length > 0) {
  const maxExisting = Math.max(...existingNumeric);
  if (serverUserIdCounter <= maxExisting) {
    serverUserIdCounter = maxExisting;
  }
}
const initialCounterRecord = safeLoadJson<{ counter: number }>(COUNTER_STORE_FILE, { counter: serverUserIdCounter });
if (typeof initialCounterRecord.counter === 'number' && initialCounterRecord.counter > serverUserIdCounter) {
  serverUserIdCounter = initialCounterRecord.counter;
}

// 3. Load and merge persistent Auth Accounts (excluding any deleted user accounts)
const loadedAuth = safeLoadJson<Record<string, any>>(AUTH_ACCOUNTS_FILE, {});
if (Object.keys(loadedAuth).length > 0) {
  for (const [identifier, record] of Object.entries(loadedAuth)) {
    const canonicalId = String(record.userId || '').padStart(7, '0');
    if (!serverDeletedUserIds.includes(canonicalId)) {
      serverAuthAccounts[identifier] = record;
    }
  }
}
saveAuthAccountsStore();

// 4. Load Agency data
const loadedAgency = safeLoadJson<{ requests?: any[]; memberships?: any }>(AGENCY_STORE_FILE, {});
if (loadedAgency.requests && Array.isArray(loadedAgency.requests) && loadedAgency.requests.length > 0) {
  serverAgencyRequests = loadedAgency.requests;
}
if (loadedAgency.memberships && typeof loadedAgency.memberships === 'object' && Object.keys(loadedAgency.memberships).length > 0) {
  serverAgencyMemberships = loadedAgency.memberships;
}

// ==========================================
// REAL-TIME LIVE ROOM PRESENCE ENGINE
// ==========================================
export interface ServerRoomMember {
  id: string;
  name: string;
  avatar: string;
  vipLevel?: number;
  role?: string;
  isHost?: boolean;
  joinedAt: number;
  lastHeartbeat: number;
}

let serverRoomPresence: Record<string, Record<string, ServerRoomMember>> = {};

function pruneRoomPresence(roomId: string): ServerRoomMember[] {
  if (!serverRoomPresence[roomId]) return [];
  const now = Date.now();
  const room = serverRoomPresence[roomId];
  for (const userId of Object.keys(room)) {
    // Prune if inactive for more than 35 seconds
    if (now - room[userId].lastHeartbeat > 35000) {
      delete room[userId];
    }
  }
  return Object.values(room);
}

// Owner configurable wallet settings
let serverWalletSettings = {
  userTransferEnabled: true,
  virtualExchangeEnabled: true,
  minTransferAmount: 100,
  maxTransferAmount: 10000000,
  coinToDiamondRate: 1.0, // 1 TEST COIN = 1 Virtual Diamond (100 coins = 100 diamonds)
  testModeNotice: "TEST MODE — Cash withdrawal is disabled. All transactions use virtual TEST COINS and virtual Diamonds with no real-money cash value."
};

let serverWalletTransactions: any[] = [
  {
    id: 'TX-TEST-INIT-001',
    type: 'USER_TRANSFER_RECEIVED',
    senderId: 'USR-8001',
    senderName: 'Rohan Joshi',
    receiverId: 'USR-882941',
    receiverName: 'Aarav Mehta',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    amountCoins: 25000,
    amountDiamonds: 0,
    previousReceiverBalance: 220000,
    newReceiverBalance: 245000,
    previousCoinBalance: 220000,
    newCoinBalance: 245000,
    status: 'Completed',
    timestamp: '10:15:20 AM',
    notes: 'Received Test Coins for party live room gifting test',
    TEST_MODE: true
  },
  {
    id: 'TX-TEST-INIT-002',
    type: 'VIRTUAL_EXCHANGE',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    senderId: 'USR-882941',
    senderName: 'Aarav Mehta',
    amountCoins: -10000,
    amountDiamonds: 10000,
    exchangeRate: 1.0,
    previousCoinBalance: 255000,
    newCoinBalance: 245000,
    previousDiamondBalance: 8500,
    newDiamondBalance: 18500,
    status: 'Completed',
    timestamp: '09:40:12 AM',
    notes: 'Exchanged 10,000 TEST COINS into 10,000 Virtual Diamonds (Test Mode)',
    TEST_MODE: true
  }
];

// 5.1 Get Owner Test Wallet Status
app.get("/api/owner/test-wallet", (req, res) => {
  res.json({
    success: true,
    ownerTestCoinBalance: serverOwnerTestCoinBalance,
    totalSellers: serverCoinSellers.length,
    activeSellers: serverCoinSellers.filter(s => s.status === 'Active').length,
    totalDistributedToSellers: serverOwnerToSellerTxs
      .filter(tx => tx.type === 'OWNER_TO_SELLER')
      .reduce((sum, tx) => sum + tx.amount, 0),
    totalReclaimedFromSellers: serverOwnerToSellerTxs
      .filter(tx => tx.type === 'RECLAIM_FROM_SELLER')
      .reduce((sum, tx) => sum + tx.amount, 0),
    transactions: serverOwnerToSellerTxs
  });
});

// 5.2 Owner -> Coin Seller Transfer (Atomic Server-side Transaction)
app.post("/api/owner/transfer-to-seller", (req, res) => {
  if (!verifyOwnerAuth(req)) {
    return res.status(403).json({ success: false, error: "Only the Platform Owner can allocate Master Coins to sellers." });
  }
  const { sellerId, amountCoins, notes } = req.body;
  const amount = Number(amountCoins);

  if (!sellerId) {
    return res.status(400).json({ success: false, error: "Seller ID is required." });
  }

  if (!amount || isNaN(amount) || amount <= 0) {
    return res.status(400).json({ success: false, error: "Transfer amount must be greater than 0 TEST COINS." });
  }

  if (serverOwnerTestCoinBalance < amount) {
    return res.status(400).json({
      success: false,
      error: `Insufficient Owner Test Coins! Available: ${serverOwnerTestCoinBalance.toLocaleString()} TEST COINS.`
    });
  }

  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: `Coin Seller with ID "${sellerId}" not found.` });
  }

  if (seller.status !== 'Active') {
    return res.status(400).json({ success: false, error: `Cannot transfer to seller in "${seller.status}" status.` });
  }

  // Execute Atomic Transfer
  const prevOwnerBal = serverOwnerTestCoinBalance;
  const newOwnerBal = prevOwnerBal - amount;
  const prevSellerBal = seller.testCoinBalance;
  const newSellerBal = prevSellerBal + amount;

  serverOwnerTestCoinBalance = newOwnerBal;
  seller.testCoinBalance = newSellerBal;
  seller.lastActivity = 'Just now';

  const txId = `CTX-OWNER-${Math.floor(100000 + Math.random() * 900000)}`;
  const txRecord = {
    id: txId,
    type: 'OWNER_TO_SELLER',
    ownerId: 'OWNER-001',
    sellerId: seller.id,
    sellerName: `${seller.name} (${seller.username})`,
    amount,
    previousOwnerBalance: prevOwnerBal,
    newOwnerBalance: newOwnerBal,
    previousSellerBalance: prevSellerBal,
    newSellerBalance: newSellerBal,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'OWNER',
    TEST_MODE: true,
    notes: notes || `Distributed ${amount.toLocaleString()} TEST COINS to ${seller.name}`
  };

  serverOwnerToSellerTxs.unshift(txRecord);

  res.json({
    success: true,
    message: `✅ Successfully sent ${amount.toLocaleString()} TEST COINS to Seller "${seller.name}".`,
    ownerBalance: newOwnerBal,
    sellerBalance: newSellerBal,
    transaction: txRecord
  });
});

// 5.2b Owner Master Coin Minting / Supply Generation
app.post("/api/owner/mint-master-coins", (req, res) => {
  const { amountCoins, notes } = req.body;
  if (!verifyOwnerAuth(req)) {
    return res.status(403).json({ success: false, error: "Only the Platform Owner can mint Master Coins." });
  }

  const amount = Number(amountCoins);
  if (!amount || isNaN(amount) || amount <= 0) {
    return res.status(400).json({ success: false, error: "Mint amount must be greater than 0 Master Coins." });
  }

  const prevOwnerBal = serverOwnerTestCoinBalance;
  serverOwnerTestCoinBalance += amount;

  const txId = `CTX-MINT-${Math.floor(100000 + Math.random() * 900000)}`;
  const txRecord = {
    id: txId,
    type: 'MASTER_MINT',
    ownerId: 'OWNER-001',
    amount,
    previousOwnerBalance: prevOwnerBal,
    newOwnerBalance: serverOwnerTestCoinBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'OWNER',
    TEST_MODE: true,
    notes: notes || `Owner minted ${amount.toLocaleString()} Master Coins into Master Treasury`
  };

  serverOwnerToSellerTxs.unshift(txRecord);

  res.json({
    success: true,
    message: `✅ Successfully minted ${amount.toLocaleString()} Master Coins. Master Treasury Balance: ${serverOwnerTestCoinBalance.toLocaleString()}.`,
    ownerBalance: serverOwnerTestCoinBalance,
    transaction: txRecord
  });
});

// 5.3 Owner Reclaim Unused Test Coins from Seller
app.post("/api/owner/reclaim-from-seller", (req, res) => {
  if (!verifyOwnerAuth(req)) {
    return res.status(403).json({ success: false, error: "Only the Platform Owner can reclaim Master Coins from sellers." });
  }
  const { sellerId, amountCoins, notes } = req.body;
  const amount = Number(amountCoins);

  if (!sellerId) {
    return res.status(400).json({ success: false, error: "Seller ID is required." });
  }

  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: `Coin Seller "${sellerId}" not found.` });
  }

  if (!amount || isNaN(amount) || amount <= 0) {
    return res.status(400).json({ success: false, error: "Reclaim amount must be greater than 0 TEST COINS." });
  }

  if (seller.testCoinBalance < amount) {
    return res.status(400).json({
      success: false,
      error: `Seller only has ${seller.testCoinBalance.toLocaleString()} TEST COINS available to reclaim.`
    });
  }

  // Execute Atomic Reclaim
  const prevOwnerBal = serverOwnerTestCoinBalance;
  const newOwnerBal = prevOwnerBal + amount;
  const prevSellerBal = seller.testCoinBalance;
  const newSellerBal = prevSellerBal - amount;

  serverOwnerTestCoinBalance = newOwnerBal;
  seller.testCoinBalance = newSellerBal;
  seller.lastActivity = 'Just now';

  const txId = `CTX-RECLAIM-${Math.floor(100000 + Math.random() * 900000)}`;
  const txRecord = {
    id: txId,
    type: 'RECLAIM_FROM_SELLER',
    ownerId: 'OWNER-001',
    sellerId: seller.id,
    sellerName: `${seller.name} (${seller.username})`,
    amount,
    previousOwnerBalance: prevOwnerBal,
    newOwnerBalance: newOwnerBal,
    previousSellerBalance: prevSellerBal,
    newSellerBalance: newSellerBal,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'OWNER',
    TEST_MODE: true,
    notes: notes || `Reclaimed ${amount.toLocaleString()} unused TEST COINS back to Owner Treasury`
  };

  serverOwnerToSellerTxs.unshift(txRecord);

  res.json({
    success: true,
    message: `✅ Successfully reclaimed ${amount.toLocaleString()} TEST COINS from "${seller.name}".`,
    ownerBalance: newOwnerBal,
    sellerBalance: newSellerBal,
    transaction: txRecord
  });
});

// 5.4 Get Coin Sellers List
app.get("/api/coin-sellers", (req, res) => {
  res.json({
    success: true,
    sellers: serverCoinSellers
  });
});

// 5.5 Create New Coin Seller
app.post("/api/coin-sellers/create", (req, res) => {
  const { name, username, phone, email, initialCoins = 0, dailyLimit = 50000000, singleLimit = 10000000, notes } = req.body;

  if (!name || !username) {
    return res.status(400).json({ success: false, error: "Name and username are required." });
  }

  const existing = serverCoinSellers.find(s => s.username.toLowerCase() === String(username).toLowerCase());
  if (existing) {
    return res.status(400).json({ success: false, error: `Username "@${username}" is already taken by an existing seller.` });
  }

  const allocAmount = Number(initialCoins);
  if (allocAmount > 0 && serverOwnerTestCoinBalance < allocAmount) {
    return res.status(400).json({
      success: false,
      error: `Cannot allocate ${allocAmount.toLocaleString()} coins. Owner only has ${serverOwnerTestCoinBalance.toLocaleString()} TEST COINS.`
    });
  }

  const newSellerId = `CS-${Math.floor(7000 + Math.random() * 900)}`;
  const newSeller = {
    id: newSellerId,
    name,
    username,
    contact: `${email || phone || 'seller@srlive.io'}`,
    phone: phone || '+91 99000 11223',
    email: email || `${username}@srlive.io`,
    status: 'Active',
    testCoinBalance: allocAmount > 0 ? allocAmount : 0,
    totalDistributed: 0,
    dailyLimit: Number(dailyLimit) || 50000000,
    singleTransferLimit: Number(singleLimit) || 10000000,
    lastActivity: 'Created just now',
    createdDate: new Date().toISOString().split('T')[0],
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    notes: notes || 'Authorized test coin seller'
  };

  if (allocAmount > 0) {
    serverOwnerTestCoinBalance -= allocAmount;
    serverOwnerToSellerTxs.unshift({
      id: `CTX-OWNER-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'OWNER_TO_SELLER',
      ownerId: 'OWNER-001',
      sellerId: newSellerId,
      sellerName: `${name} (${username})`,
      amount: allocAmount,
      previousOwnerBalance: serverOwnerTestCoinBalance + allocAmount,
      newOwnerBalance: serverOwnerTestCoinBalance,
      previousSellerBalance: 0,
      newSellerBalance: allocAmount,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      operator: 'OWNER',
      TEST_MODE: true,
      notes: 'Initial test coin grant at seller creation'
    });
  }

  serverCoinSellers.unshift(newSeller);

  res.json({
    success: true,
    message: `✅ Created Coin Seller "${name}" successfully.`,
    seller: newSeller,
    ownerBalance: serverOwnerTestCoinBalance
  });
});

// 5.6 Update Coin Seller Status
app.post("/api/coin-sellers/status", (req, res) => {
  const { sellerId, status } = req.body;
  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: "Seller not found." });
  }

  seller.status = status;
  seller.lastActivity = 'Status changed just now';

  res.json({
    success: true,
    message: `Seller status updated to "${status}".`,
    seller
  });
});

// 5.7 Update Coin Seller Limits
app.post("/api/coin-sellers/limits", (req, res) => {
  const { sellerId, dailyLimit, singleTransferLimit } = req.body;
  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: "Seller not found." });
  }

  if (dailyLimit !== undefined) seller.dailyLimit = Number(dailyLimit);
  if (singleTransferLimit !== undefined) seller.singleTransferLimit = Number(singleTransferLimit);
  seller.lastActivity = 'Limits updated';

  res.json({
    success: true,
    message: `Updated transfer limits for ${seller.name}.`,
    seller
  });
});

// 5.8 COIN SELLER -> USER Transfer (Atomic Server-side Transaction)
app.post("/api/coin-sellers/transfer-to-user", (req, res) => {
  const { sellerId, targetUserId, amountCoins, notes } = req.body;
  const amount = Number(amountCoins);

  // Security Check 1: Validate input
  if (!sellerId || !targetUserId) {
    return res.status(400).json({ success: false, error: "Seller ID and Target User ID are required." });
  }

  if (!amount || isNaN(amount) || amount <= 0) {
    return res.status(400).json({ success: false, error: "Transfer amount must be greater than 0 TEST COINS." });
  }

  // Security Check 2: Verify Seller
  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: "Unauthorized: Coin Seller not registered." });
  }

  if (seller.status !== 'Active') {
    return res.status(403).json({ success: false, error: `Transfer rejected: Seller account is currently ${seller.status}.` });
  }

  // Security Check 3: Check Seller Balance
  if (seller.testCoinBalance < amount) {
    return res.status(400).json({
      success: false,
      error: `Transfer failed: Insufficient seller balance. Available: ${seller.testCoinBalance.toLocaleString()} TEST COINS.`
    });
  }

  // Security Check 4: Check Transfer Limits
  if (seller.singleTransferLimit && amount > seller.singleTransferLimit) {
    return res.status(400).json({
      success: false,
      error: `Transfer exceeds seller's single transaction limit of ${seller.singleTransferLimit.toLocaleString()} TEST COINS.`
    });
  }

  // Find or instantiate recipient user
  let targetUser = serverUsers[targetUserId];
  if (!targetUser) {
    targetUser = {
      id: targetUserId,
      name: `User ${targetUserId}`,
      username: `user_${targetUserId.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 0,
      diamondBalance: 0,
      vipLevel: 1,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      status: 'Active'
    };
    serverUsers[targetUserId] = targetUser;
  }

  // Atomic Balance Mutation
  const prevSellerBalance = seller.testCoinBalance;
  const newSellerBalance = prevSellerBalance - amount;
  const prevUserBalance = targetUser.coinBalance;
  const newUserBalance = prevUserBalance + amount;

  seller.testCoinBalance = newSellerBalance;
  seller.totalDistributed += amount;
  seller.lastActivity = 'Just now';
  targetUser.coinBalance = newUserBalance;

  const txId = `CTX-SELLER-${Math.floor(100000 + Math.random() * 900000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  const txRecord = {
    id: txId,
    sellerId: seller.id,
    sellerName: seller.name,
    userId: targetUser.id,
    userName: targetUser.name,
    amount,
    previousSellerBalance: prevSellerBalance,
    newSellerBalance: newSellerBalance,
    previousUserBalance: prevUserBalance,
    newUserBalance: newUserBalance,
    timestamp,
    operator: seller.id,
    TEST_MODE: true,
    notes: notes || `Transferred ${amount.toLocaleString()} TEST COINS to user ${targetUser.name}`
  };

  serverSellerToUserTxs.unshift(txRecord);
  if (serverSellerToUserTxs.length > 500) {
    serverSellerToUserTxs.pop();
  }

  res.json({
    success: true,
    message: `🎉 Successfully transferred ${amount.toLocaleString()} TEST COINS to ${targetUser.name} (${targetUser.id}).`,
    transaction: txRecord,
    sellerBalance: newSellerBalance,
    userBalance: newUserBalance
  });
});

// 5.9 Get Seller Transactions
app.get("/api/coin-sellers/transactions", (req, res) => {
  const { sellerId, userId } = req.query;
  let filtered = [...serverSellerToUserTxs];

  if (sellerId) {
    filtered = filtered.filter(tx => tx.sellerId === sellerId);
  }
  if (userId) {
    filtered = filtered.filter(tx => tx.userId === userId);
  }

  res.json({
    success: true,
    totalCount: filtered.length,
    transactions: filtered
  });
});

// ==========================================
// 5.10 SR LIVE TEST WALLET & TRANSFER ENGINE
// ==========================================

// Get Platform Wallet Configuration
app.get("/api/wallet/settings", (req, res) => {
  res.json({
    success: true,
    settings: serverWalletSettings
  });
});

// Update Platform Wallet Configuration (Owner Controls)
app.post("/api/wallet/settings", (req, res) => {
  const { 
    userTransferEnabled, 
    virtualExchangeEnabled, 
    minTransferAmount, 
    maxTransferAmount, 
    coinToDiamondRate 
  } = req.body;

  if (userTransferEnabled !== undefined) {
    serverWalletSettings.userTransferEnabled = Boolean(userTransferEnabled);
  }
  if (virtualExchangeEnabled !== undefined) {
    serverWalletSettings.virtualExchangeEnabled = Boolean(virtualExchangeEnabled);
  }
  if (minTransferAmount !== undefined && !isNaN(Number(minTransferAmount))) {
    serverWalletSettings.minTransferAmount = Math.max(1, Number(minTransferAmount));
  }
  if (maxTransferAmount !== undefined && !isNaN(Number(maxTransferAmount))) {
    serverWalletSettings.maxTransferAmount = Math.max(serverWalletSettings.minTransferAmount, Number(maxTransferAmount));
  }
  if (coinToDiamondRate !== undefined && !isNaN(Number(coinToDiamondRate))) {
    serverWalletSettings.coinToDiamondRate = Math.max(0.01, Number(coinToDiamondRate));
  }

  res.json({
    success: true,
    message: "Platform Wallet Transfer & Virtual Exchange settings updated successfully.",
    settings: serverWalletSettings
  });
});

// Get User Directory with Test Balances
app.get("/api/wallet/users", (req, res) => {
  res.json({
    success: true,
    users: Object.values(serverUsers)
  });
});

// Get Single User Wallet & Transaction History
app.get("/api/wallet/user/:userId", (req, res) => {
  const { userId } = req.params;
  const user = serverUsers[userId];
  if (!user) {
    return res.status(404).json({ success: false, error: "User not found." });
  }

  const userTxs = serverWalletTransactions.filter(
    tx => tx.userId === userId || tx.senderId === userId || tx.receiverId === userId || tx.recipientId === userId
  );

  res.json({
    success: true,
    user,
    transactions: userTxs
  });
});

// USER -> USER TEST COIN TRANSFER (Server-Side Atomic Processing)
app.post("/api/wallet/transfer", (req, res) => {
  const { senderId, receiverId, targetUserId, amount, notes } = req.body;
  const targetId = receiverId || targetUserId;
  const transferAmount = Number(amount);

  // 1. Check Feature Toggle
  if (!serverWalletSettings.userTransferEnabled) {
    return res.status(403).json({
      success: false,
      error: "User-to-User Transfer is currently disabled by the Platform Owner."
    });
  }

  // 2. Validate Input Parameters
  if (!senderId || !targetId) {
    return res.status(400).json({
      success: false,
      error: "Both Sender ID and Recipient User ID are required."
    });
  }

  // Normalize ID (handle 7-digit sequential '0000001', raw numbers '1', username, or email)
  const normalizeId = (idStr: string) => {
    const raw = String(idStr).trim();
    if (serverUsers[raw]) return raw;
    
    // Check if unpadded number e.g. "1" -> "0000001"
    if (/^\d+$/.test(raw)) {
      const padded = raw.padStart(7, '0');
      if (serverUsers[padded]) return padded;
    }

    // Check auth accounts mapping (email / phone)
    if (serverAuthAccounts[raw.toLowerCase()]) {
      return serverAuthAccounts[raw.toLowerCase()].userId;
    }

    // Look up by username or name
    const byUsername = Object.values(serverUsers).find(
      u => u.username.toLowerCase() === raw.toLowerCase().replace('@', '') ||
           u.name.toLowerCase() === raw.toLowerCase() ||
           (u.email && u.email.toLowerCase() === raw.toLowerCase()) ||
           (u.phone && u.phone.replace(/[^0-9]/g, '') === raw.replace(/[^0-9]/g, ''))
    );
    if (byUsername) return byUsername.id;
    return raw;
  };

  const senderKey = normalizeId(senderId);
  const receiverKey = normalizeId(targetId);

  // 3. Sender != Receiver validation
  if (senderKey === receiverKey) {
    return res.status(400).json({
      success: false,
      error: "Cannot transfer TEST COINS to yourself. Please specify a different recipient."
    });
  }

  // 4. Validate Transfer Amount
  if (!transferAmount || isNaN(transferAmount) || transferAmount <= 0) {
    return res.status(400).json({
      success: false,
      error: "Transfer amount must be a positive integer."
    });
  }

  if (transferAmount < serverWalletSettings.minTransferAmount) {
    return res.status(400).json({
      success: false,
      error: `Minimum transfer amount is ${serverWalletSettings.minTransferAmount.toLocaleString()} TEST COINS.`
    });
  }

  if (transferAmount > serverWalletSettings.maxTransferAmount) {
    return res.status(400).json({
      success: false,
      error: `Maximum transfer limit is ${serverWalletSettings.maxTransferAmount.toLocaleString()} TEST COINS per transaction.`
    });
  }

  // 5. Verify Sender Exists & Balance
  const sender = serverUsers[senderKey];
  if (!sender) {
    return res.status(404).json({
      success: false,
      error: `Sender account "${senderId}" not found.`
    });
  }

  if (sender.status === 'Banned' || sender.status === 'Suspended') {
    return res.status(403).json({
      success: false,
      error: `Sender account is currently ${sender.status}. Transfer rejected.`
    });
  }

  if (sender.coinBalance < transferAmount) {
    return res.status(400).json({
      success: false,
      error: `Insufficient balance! You have ${sender.coinBalance.toLocaleString()} TEST COINS, but tried to send ${transferAmount.toLocaleString()} TEST COINS.`
    });
  }

  // 6. Verify or Instantiate Recipient
  let receiver = serverUsers[receiverKey];
  if (!receiver) {
    receiver = {
      id: receiverKey.startsWith('USR-') ? receiverKey : `USR-${receiverKey}`,
      name: `User ${receiverKey}`,
      username: `user_${receiverKey.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 0,
      diamondBalance: 0,
      vipLevel: 1,
      status: 'Active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    };
    serverUsers[receiver.id] = receiver;
  }

  if (receiver.status === 'Banned') {
    return res.status(403).json({
      success: false,
      error: `Recipient account "${receiver.name}" is banned from receiving coins.`
    });
  }

  // 7. Atomic Balance Mutation (Server Authoritative)
  const prevSenderBalance = sender.coinBalance;
  const newSenderBalance = prevSenderBalance - transferAmount;
  const prevReceiverBalance = receiver.coinBalance;
  const newReceiverBalance = prevReceiverBalance + transferAmount;

  sender.coinBalance = newSenderBalance;
  receiver.coinBalance = newReceiverBalance;

  // 8. Generate Unique Atomic Transaction ID
  const txId = `TX-TRANSFER-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fullDateTime = `${new Date().toISOString().split('T')[0]} ${timestamp}`;

  // Log Sender Transaction Record
  const senderTx = {
    id: `${txId}-SENT`,
    type: 'USER_TRANSFER_SENT',
    userId: sender.id,
    userName: sender.name,
    senderId: sender.id,
    senderName: sender.name,
    receiverId: receiver.id,
    receiverName: receiver.name,
    recipientId: receiver.id,
    recipientName: receiver.name,
    amountCoins: -transferAmount,
    amountDiamonds: 0,
    previousBalance: prevSenderBalance,
    newBalance: newSenderBalance,
    previousSenderBalance: prevSenderBalance,
    newSenderBalance: newSenderBalance,
    status: 'Completed',
    timestamp: fullDateTime,
    notes: notes || `Transferred to ${receiver.name} (${receiver.id})`,
    TEST_MODE: true
  };

  // Log Receiver Transaction Record
  const receiverTx = {
    id: `${txId}-RECV`,
    type: 'USER_TRANSFER_RECEIVED',
    userId: receiver.id,
    userName: receiver.name,
    senderId: sender.id,
    senderName: sender.name,
    receiverId: receiver.id,
    receiverName: receiver.name,
    recipientId: receiver.id,
    recipientName: receiver.name,
    amountCoins: transferAmount,
    amountDiamonds: 0,
    previousBalance: prevReceiverBalance,
    newBalance: newReceiverBalance,
    previousReceiverBalance: prevReceiverBalance,
    newReceiverBalance: newReceiverBalance,
    status: 'Completed',
    timestamp: fullDateTime,
    notes: notes || `Received from ${sender.name} (${sender.id})`,
    TEST_MODE: true
  };

  serverWalletTransactions.unshift(senderTx);
  serverWalletTransactions.unshift(receiverTx);

  if (serverWalletTransactions.length > 1000) {
    serverWalletTransactions.length = 1000;
  }

  res.json({
    success: true,
    message: `🎉 Successfully sent ${transferAmount.toLocaleString()} TEST COINS to ${receiver.name}!`,
    transactionId: txId,
    senderTransaction: senderTx,
    receiverTransaction: receiverTx,
    senderBalance: newSenderBalance,
    receiverBalance: newReceiverBalance,
    sender: { id: sender.id, name: sender.name, coinBalance: newSenderBalance },
    receiver: { id: receiver.id, name: receiver.name, coinBalance: newReceiverBalance }
  });
});

// VIRTUAL EXCHANGE (TEST COINS -> Virtual Diamonds)
app.post("/api/wallet/exchange", (req, res) => {
  const { userId, coinAmount } = req.body;
  const amountToExchange = Number(coinAmount);

  // 1. Check Feature Toggle
  if (!serverWalletSettings.virtualExchangeEnabled) {
    return res.status(403).json({
      success: false,
      error: "Virtual Exchange is currently disabled by Platform Owner."
    });
  }

  // 2. Validate Input
  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  if (!amountToExchange || isNaN(amountToExchange) || amountToExchange <= 0) {
    return res.status(400).json({
      success: false,
      error: "Exchange amount must be a positive integer."
    });
  }

  const user = serverUsers[userId];
  if (!user) {
    return res.status(404).json({ success: false, error: "User not found." });
  }

  if (user.coinBalance < amountToExchange) {
    return res.status(400).json({
      success: false,
      error: `Insufficient TEST COINS! Available: ${user.coinBalance.toLocaleString()} 🪙, requested: ${amountToExchange.toLocaleString()} 🪙.`
    });
  }

  // 3. Compute Diamonds Received using Owner-configured exchange rate
  const rate = serverWalletSettings.coinToDiamondRate || 1.0;
  const diamondsReceived = Math.floor(amountToExchange * rate);

  if (diamondsReceived <= 0) {
    return res.status(400).json({
      success: false,
      error: "Exchange resulted in 0 diamonds. Please enter a larger amount."
    });
  }

  // 4. Atomic Balance Mutation
  const prevCoins = user.coinBalance;
  const newCoins = prevCoins - amountToExchange;
  const prevDiamonds = user.diamondBalance || 0;
  const newDiamonds = prevDiamonds + diamondsReceived;

  user.coinBalance = newCoins;
  user.diamondBalance = newDiamonds;

  // 5. Log Transaction
  const txId = `TX-EXCHANGE-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fullDateTime = `${new Date().toISOString().split('T')[0]} ${timestamp}`;

  const exchangeTx = {
    id: txId,
    type: 'VIRTUAL_EXCHANGE',
    userId: user.id,
    userName: user.name,
    senderId: user.id,
    senderName: user.name,
    amountCoins: -amountToExchange,
    amountDiamonds: diamondsReceived,
    exchangeRate: rate,
    previousCoinBalance: prevCoins,
    newCoinBalance: newCoins,
    previousDiamondBalance: prevDiamonds,
    newDiamondBalance: newDiamonds,
    status: 'Completed',
    timestamp: fullDateTime,
    notes: `Exchanged ${amountToExchange.toLocaleString()} TEST COINS into ${diamondsReceived.toLocaleString()} Virtual Diamonds (Rate: 1:${rate})`,
    TEST_MODE: true
  };

  serverWalletTransactions.unshift(exchangeTx);

  res.json({
    success: true,
    message: `✨ Exchanged ${amountToExchange.toLocaleString()} TEST COINS into ${diamondsReceived.toLocaleString()} Virtual Diamonds! (TEST ONLY - NO CASH VALUE)`,
    transaction: exchangeTx,
    coinBalance: newCoins,
    diamondBalance: newDiamonds,
    diamondsReceived
  });
});

// FAUCET / SANDBOX TEST COINS TOP-UP
app.post("/api/wallet/recharge", (req, res) => {
  const { userId, amountCoins = 50000 } = req.body;
  const rechargeAmount = Number(amountCoins);

  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  let user = serverUsers[userId];
  if (!user) {
    user = {
      id: userId,
      name: `User ${userId}`,
      username: `user_${userId.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 0,
      diamondBalance: 0,
      vipLevel: 1,
      status: 'Active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    };
    serverUsers[userId] = user;
  }

  const prevBalance = user.coinBalance;
  const newBalance = prevBalance + rechargeAmount;
  user.coinBalance = newBalance;

  const txId = `TX-FAUCET-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fullDateTime = `${new Date().toISOString().split('T')[0]} ${timestamp}`;

  const rechargeTx = {
    id: txId,
    type: 'FAUCET_RECHARGE',
    userId: user.id,
    userName: user.name,
    amountCoins: rechargeAmount,
    amountDiamonds: 0,
    previousCoinBalance: prevBalance,
    newCoinBalance: newBalance,
    status: 'Completed',
    timestamp: fullDateTime,
    notes: `Instant Sandbox Faucet +${rechargeAmount.toLocaleString()} Free TEST COINS`,
    TEST_MODE: true
  };

  serverWalletTransactions.unshift(rechargeTx);

  res.json({
    success: true,
    message: `🎉 Free Test Top-Up: +${rechargeAmount.toLocaleString()} TEST COINS added!`,
    coinBalance: newBalance,
    transaction: rechargeTx
  });
});

// GET ALL WALLET TRANSACTIONS (Filtered)
app.get("/api/wallet/transactions", (req, res) => {
  const { type, userId, search } = req.query;
  let filtered = [...serverWalletTransactions];

  if (type && type !== 'ALL') {
    filtered = filtered.filter(tx => tx.type === type);
  }

  if (userId) {
    filtered = filtered.filter(tx => tx.userId === userId || tx.senderId === userId || tx.receiverId === userId || tx.recipientId === userId);
  }

  if (search) {
    const q = String(search).toLowerCase();
    filtered = filtered.filter(tx => 
      (tx.id || '').toLowerCase().includes(q) ||
      (tx.senderName || '').toLowerCase().includes(q) ||
      (tx.receiverName || '').toLowerCase().includes(q) ||
      (tx.userName || '').toLowerCase().includes(q) ||
      (tx.notes || '').toLowerCase().includes(q)
    );
  }

  res.json({
    success: true,
    totalCount: filtered.length,
    transactions: filtered
  });
});

// ==========================================
// 5.11 REAL MONEY WITHDRAWAL ENGINE (eSewa, Bank, ePay, USD)
// ==========================================

export interface ServerWithdrawalRecord {
  id: string;
  userId: string;
  userName: string;
  method: 'ESEWA' | 'BANK' | 'EPAY' | 'USD';
  methodLabel: string;
  diamondAmount: number;
  fiatAmountUSD: number;
  fiatAmountLocal: number;
  currency: 'USD' | 'NPR' | 'INR';
  exchangeRate: number; // e.g. 1000 diamonds = $1.00 USD
  accountDetails: {
    esewaId?: string;
    accountHolderName?: string;
    bankName?: string;
    accountNumber?: string;
    ifscOrSwiftCode?: string;
    branchName?: string;
    epayId?: string;
    payoutTypeUSD?: 'USDT_TRC20' | 'USDT_ERC20' | 'PAYPAL' | 'WIRE';
    usdtAddress?: string;
    paypalEmail?: string;
  };
  processingFeeUSD: number;
  netPayoutUSD: number;
  netPayoutLocal: number;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'REJECTED' | 'CANCELLED';
  txHash?: string;
  referenceCode: string;
  submittedAt: string;
  processedAt?: string;
  notes?: string;
}

let serverWithdrawalSettings = {
  withdrawalEnabled: true,
  minDiamondsToWithdraw: 5000, // 5,000 Diamonds = $5.00 USD
  maxDiamondsPerWithdrawal: 5000000, // 5,000,000 Diamonds = $5,000 USD
  diamondToUsdRate: 1000, // 1,000 Diamonds = $1.00 USD
  conversionRates: {
    USD: 1.0,
    NPR: 135.0, // 1 USD = 135 NPR (eSewa / Nepal Bank)
    INR: 88.0   // 1 USD = 88 INR (ePay / India)
  },
  supportedMethods: [
    {
      id: 'ESEWA',
      name: 'eSewa Mobile Wallet',
      currency: 'NPR',
      feePercent: 0.0,
      minUSD: 5,
      processingTime: 'Instant / Within 2 hours',
      icon: '📱',
      badge: 'POPULAR (Nepal / South Asia)'
    },
    {
      id: 'BANK',
      name: 'Direct Bank Transfer',
      currency: 'NPR',
      feePercent: 1.5,
      minUSD: 20,
      processingTime: '1 - 24 Hours',
      icon: '🏦',
      badge: 'DOMESTIC & GLOBAL'
    },
    {
      id: 'EPAY',
      name: 'ePay Digital Wallet',
      currency: 'USD',
      feePercent: 1.0,
      minUSD: 10,
      processingTime: 'Instant',
      icon: '💳',
      badge: 'FAST PAYOUT'
    },
    {
      id: 'USD',
      name: 'USD Payout (USDT / Crypto / PayPal)',
      currency: 'USD',
      feePercent: 0.0,
      minUSD: 10,
      processingTime: '5 - 30 Minutes',
      icon: '💵',
      badge: 'GLOBAL NO-FEE (USDT TRC20)'
    }
  ]
};

let serverWithdrawals: ServerWithdrawalRecord[] = [
  {
    id: 'WD-ESEWA-8921',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    method: 'ESEWA',
    methodLabel: 'eSewa Mobile Wallet (9841029384)',
    diamondAmount: 25000,
    fiatAmountUSD: 25.0,
    fiatAmountLocal: 3375.0,
    currency: 'NPR',
    exchangeRate: 1000,
    accountDetails: {
      esewaId: '9841029384',
      accountHolderName: 'Aarav Mehta'
    },
    processingFeeUSD: 0,
    netPayoutUSD: 25.0,
    netPayoutLocal: 3375.0,
    status: 'COMPLETED',
    txHash: 'ESEWA-TXN-99482103',
    referenceCode: 'ESW-99482',
    submittedAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    processedAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    notes: 'Payout successfully settled to eSewa account 9841029384.'
  },
  {
    id: 'WD-USD-5012',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    method: 'USD',
    methodLabel: 'USD USDT TRC-20',
    diamondAmount: 50000,
    fiatAmountUSD: 50.0,
    fiatAmountLocal: 50.0,
    currency: 'USD',
    exchangeRate: 1000,
    accountDetails: {
      payoutTypeUSD: 'USDT_TRC20',
      usdtAddress: 'TXn871KaB92MopQrZ21KLa90vVnmQ19p02',
      accountHolderName: 'Aarav Mehta'
    },
    processingFeeUSD: 0,
    netPayoutUSD: 50.0,
    netPayoutLocal: 50.0,
    status: 'COMPLETED',
    txHash: '0x8f27ab194e90812bca01289cfb1900192',
    referenceCode: 'USDT-5012',
    submittedAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    processedAt: new Date(Date.now() - 1000 * 60 * 60 * 23).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    notes: 'USDT TRC20 on-chain transfer verified.'
  }
];

// Load and merge persistent Withdrawals
const loadedWithdrawals = safeLoadJson<ServerWithdrawalRecord[]>(WITHDRAWALS_STORE_FILE, []);
if (loadedWithdrawals.length > 0) {
  serverWithdrawals = loadedWithdrawals;
} else {
  saveWithdrawalsStore();
}

// ==========================================
// REAL-TIME LIVE ROOM PRESENCE API
// ==========================================
// Join Room
app.post("/api/live/rooms/:roomId/join", (req, res) => {
  const { roomId } = req.params;
  const { user, isHost } = req.body;
  if (!roomId || !user || !user.id) {
    return res.status(400).json({ success: false, error: "roomId and user required." });
  }
  if (!serverRoomPresence[roomId]) {
    serverRoomPresence[roomId] = {};
  }
  const member: ServerRoomMember = {
    id: String(user.id),
    name: user.name || `User ${user.id}`,
    avatar: user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    vipLevel: user.vipLevel || 0,
    role: user.role || 'USER',
    isHost: Boolean(isHost),
    joinedAt: Date.now(),
    lastHeartbeat: Date.now()
  };
  serverRoomPresence[roomId][String(user.id)] = member;
  const members = pruneRoomPresence(roomId);
  res.json({ success: true, count: members.length, members });
});

// Leave Room
app.post("/api/live/rooms/:roomId/leave", (req, res) => {
  const { roomId } = req.params;
  const { userId } = req.body;
  if (serverRoomPresence[roomId] && userId) {
    delete serverRoomPresence[roomId][String(userId)];
  }
  const members = pruneRoomPresence(roomId);
  res.json({ success: true, count: members.length, members });
});

// Get Room Active Members
app.get("/api/live/rooms/:roomId/members", (req, res) => {
  const { roomId } = req.params;
  const members = pruneRoomPresence(roomId);
  res.json({ success: true, count: members.length, members });
});

// Heartbeat
app.post("/api/live/rooms/:roomId/heartbeat", (req, res) => {
  const { roomId } = req.params;
  const { userId } = req.body;
  if (serverRoomPresence[roomId] && userId && serverRoomPresence[roomId][String(userId)]) {
    serverRoomPresence[roomId][String(userId)].lastHeartbeat = Date.now();
  }
  const members = pruneRoomPresence(roomId);
  res.json({ success: true, count: members.length, members });
});

// 1. Get Withdrawal Settings & Live Conversion Rates
app.get("/api/wallet/withdrawal/settings", (req, res) => {
  res.json({
    success: true,
    settings: serverWithdrawalSettings
  });
});

// 2. Process Real Money Withdrawal Request (Atomic Diamond Deduction)
app.post(["/api/wallet/withdraw", "/api/withdrawals/create"], (req, res) => {
  const { 
    userId = 'USR-882941', 
    diamonds, 
    method, 
    accountDetails, 
    notes 
  } = req.body;

  const diamondAmount = Number(diamonds);

  // 1. Check system toggle
  if (!serverWithdrawalSettings.withdrawalEnabled) {
    return res.status(403).json({
      success: false,
      error: "Withdrawal system is temporarily undergoing scheduled maintenance."
    });
  }

  // 2. Validate diamond amount
  if (!diamondAmount || isNaN(diamondAmount) || diamondAmount <= 0) {
    return res.status(400).json({
      success: false,
      error: "Please specify a valid diamond amount to withdraw."
    });
  }

  if (diamondAmount < serverWithdrawalSettings.minDiamondsToWithdraw) {
    return res.status(400).json({
      success: false,
      error: `Minimum withdrawal is ${serverWithdrawalSettings.minDiamondsToWithdraw.toLocaleString()} Diamonds ($${(serverWithdrawalSettings.minDiamondsToWithdraw / serverWithdrawalSettings.diamondToUsdRate).toFixed(2)} USD).`
    });
  }

  if (diamondAmount > serverWithdrawalSettings.maxDiamondsPerWithdrawal) {
    return res.status(400).json({
      success: false,
      error: `Maximum withdrawal limit is ${serverWithdrawalSettings.maxDiamondsPerWithdrawal.toLocaleString()} Diamonds per transaction.`
    });
  }

  // 3. Validate user & balance
  let user = serverUsers[userId];
  if (!user) {
    user = {
      id: userId,
      name: `User ${userId}`,
      username: `user_${userId.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 245000,
      diamondBalance: 18500,
      vipLevel: 8,
      status: 'Active'
    };
    serverUsers[userId] = user;
  }

  if (user.status === 'Banned' || user.status === 'Suspended') {
    return res.status(403).json({
      success: false,
      error: `Account is currently ${user.status}. Withdrawals are locked.`
    });
  }

  if (user.diamondBalance < diamondAmount) {
    return res.status(400).json({
      success: false,
      error: `Insufficient Diamond balance! You have ${user.diamondBalance.toLocaleString()} Diamonds, but requested ${diamondAmount.toLocaleString()} Diamonds.`
    });
  }

  // 4. Validate Method & Account Details
  const validMethods = ['ESEWA', 'BANK', 'EPAY', 'USD'];
  if (!validMethods.includes(method)) {
    return res.status(400).json({
      success: false,
      error: `Invalid withdrawal method "${method}". Supported methods: eSewa, Bank Transfer, ePay, USD (USDT/PayPal).`
    });
  }

  const details = accountDetails || {};
  let methodLabel = '';
  let currency: 'USD' | 'NPR' | 'INR' = 'USD';

  if (method === 'ESEWA') {
    if (!details.esewaId || details.esewaId.trim().length < 8) {
      return res.status(400).json({
        success: false,
        error: "Please provide a valid eSewa ID / Mobile Number (e.g. 98XXXXXXXX)."
      });
    }
    if (!details.accountHolderName || details.accountHolderName.trim().length < 2) {
      return res.status(400).json({
        success: false,
        error: "Please enter the full account holder name registered on eSewa."
      });
    }
    methodLabel = `eSewa ID: ${details.esewaId} (${details.accountHolderName})`;
    currency = 'NPR';
  } else if (method === 'BANK') {
    if (!details.bankName || details.bankName.trim().length < 2) {
      return res.status(400).json({ success: false, error: "Please enter your Bank Name." });
    }
    if (!details.accountNumber || details.accountNumber.trim().length < 6) {
      return res.status(400).json({ success: false, error: "Please enter a valid Bank Account Number." });
    }
    if (!details.accountHolderName || details.accountHolderName.trim().length < 2) {
      return res.status(400).json({ success: false, error: "Please enter the Bank Account Holder Full Name." });
    }
    methodLabel = `${details.bankName} - A/C: ${details.accountNumber} (${details.accountHolderName})`;
    currency = 'NPR';
  } else if (method === 'EPAY') {
    if (!details.epayId || details.epayId.trim().length < 5) {
      return res.status(400).json({ success: false, error: "Please enter your valid ePay Wallet ID / Registered Phone/Email." });
    }
    if (!details.accountHolderName || details.accountHolderName.trim().length < 2) {
      return res.status(400).json({ success: false, error: "Please enter your full registered name for ePay." });
    }
    methodLabel = `ePay Wallet: ${details.epayId} (${details.accountHolderName})`;
    currency = 'USD';
  } else if (method === 'USD') {
    const payoutType = details.payoutTypeUSD || 'USDT_TRC20';
    if (payoutType === 'PAYPAL') {
      if (!details.paypalEmail || !details.paypalEmail.includes('@')) {
        return res.status(400).json({ success: false, error: "Please enter a valid PayPal Email address." });
      }
      methodLabel = `PayPal: ${details.paypalEmail}`;
    } else {
      if (!details.usdtAddress || details.usdtAddress.trim().length < 20) {
        return res.status(400).json({ success: false, error: "Please enter a valid USDT Wallet Address." });
      }
      methodLabel = `USD USDT (${payoutType.replace('_', ' ')}): ${details.usdtAddress.slice(0, 8)}...${details.usdtAddress.slice(-6)}`;
    }
    currency = 'USD';
  }

  // 5. Calculations
  const fiatAmountUSD = Number((diamondAmount / serverWithdrawalSettings.diamondToUsdRate).toFixed(2));
  const rate = serverWithdrawalSettings.conversionRates[currency] || 1.0;
  const fiatAmountLocal = Number((fiatAmountUSD * rate).toFixed(2));

  const methodConfig = serverWithdrawalSettings.supportedMethods.find(m => m.id === method);
  const feePercent = methodConfig ? methodConfig.feePercent : 0.0;
  const processingFeeUSD = Number(((fiatAmountUSD * feePercent) / 100).toFixed(2));
  const netPayoutUSD = Number((fiatAmountUSD - processingFeeUSD).toFixed(2));
  const netPayoutLocal = Number((netPayoutUSD * rate).toFixed(2));

  // 6. Atomic Balance Mutation
  const prevDiamonds = user.diamondBalance;
  const newDiamonds = prevDiamonds - diamondAmount;
  user.diamondBalance = newDiamonds;

  // 7. Generate Withdrawal Record
  const wdId = `WD-${method}-${Math.floor(100000 + Math.random() * 900000)}`;
  const refCode = `${method.slice(0, 3)}-${Math.floor(10000 + Math.random() * 90000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fullDateTime = `${new Date().toISOString().split('T')[0]} ${timestamp}`;

  const withdrawalRecord: any = {
    id: wdId,
    userId: user.id,
    userName: user.name,
    applicantId: user.id,
    applicantName: user.name,
    applicantRole: user.role || 'USER',
    method,
    methodLabel,
    payoutMethod: methodLabel,
    payoutAddress: typeof details === 'string' ? details : (details.accountNumber || details.usdtAddress || details.upiId || details.esewaId || details.epayId || 'Electronic Payout'),
    diamondAmount,
    diamondsAmount: diamondAmount,
    fiatAmountUSD,
    fiatAmountLocal,
    currency,
    exchangeRate: serverWithdrawalSettings.diamondToUsdRate,
    accountDetails: details,
    processingFeeUSD,
    netPayoutUSD,
    payoutAmountUSD: netPayoutUSD,
    netPayoutLocal,
    status: 'Pending', // Pending approval by Owner
    referenceCode: refCode,
    submittedAt: fullDateTime,
    requestDate: fullDateTime,
    txHash: `TXN-${refCode}-${Date.now().toString(36).toUpperCase()}`,
    notes: notes || `Withdrawal payout to ${methodLabel}`
  };

  serverWithdrawals.unshift(withdrawalRecord);
  saveWithdrawalsStore();
  saveUsersStore();

  // 8. Log into wallet transactions ledger
  const walletTx = {
    id: `TX-${wdId}`,
    type: 'Payout',
    userId: user.id,
    userName: user.name,
    amountCoins: 0,
    amountDiamonds: -diamondAmount,
    fiatAmountUSD: netPayoutUSD,
    paymentMethod: methodLabel,
    paymentChannel: method,
    previousBalance: user.coinBalance,
    newBalance: user.coinBalance,
    previousDiamondBalance: prevDiamonds,
    newDiamondBalance: newDiamonds,
    status: 'Pending',
    timestamp: fullDateTime,
    notes: `Withdrew ${diamondAmount.toLocaleString()} Diamonds ➔ $${netPayoutUSD.toFixed(2)} USD (${netPayoutLocal.toLocaleString()} ${currency}) via ${method}`,
    TEST_MODE: false
  };

  serverWalletTransactions.unshift(walletTx);

  res.json({
    success: true,
    message: `✅ Withdrawal request of ${diamondAmount.toLocaleString()} Diamonds ($${netPayoutUSD.toFixed(2)} USD / ${netPayoutLocal.toLocaleString()} ${currency}) submitted successfully!`,
    withdrawal: withdrawalRecord,
    newDiamondBalance: newDiamonds,
    user: {
      id: user.id,
      name: user.name,
      diamondBalance: newDiamonds,
      coinBalance: user.coinBalance
    }
  });
});

// 3. Get User Withdrawal History
app.get("/api/wallet/withdrawals", (req, res) => {
  const { userId } = req.query;
  let list = [...serverWithdrawals];
  if (userId) {
    list = list.filter(w => w.userId === userId || (w as any).applicantId === userId);
  }
  res.json({
    success: true,
    totalCount: list.length,
    withdrawals: list
  });
});

// 4. Cancel Pending Withdrawal (Atomic Diamond Refund)
app.post("/api/wallet/withdrawal/cancel", (req, res) => {
  const { withdrawalId, userId } = req.body;

  const wd = serverWithdrawals.find(w => w.id === withdrawalId);
  if (!wd) {
    return res.status(404).json({ success: false, error: "Withdrawal request not found." });
  }

  if (wd.status === 'COMPLETED' || (wd.status as string) === 'Approved') {
    return res.status(400).json({ success: false, error: "Cannot cancel a payout that has already been approved or completed." });
  }

  if (wd.status === 'CANCELLED') {
    return res.status(400).json({ success: false, error: "This withdrawal request is already cancelled." });
  }

  const user = serverUsers[wd.userId];
  if (user) {
    user.diamondBalance += (wd.diamondAmount || (wd as any).diamondsAmount || 0);
    saveUsersStore();
  }

  wd.status = 'CANCELLED';
  wd.notes = 'Cancelled by user. Diamonds refunded to wallet.';
  saveWithdrawalsStore();

  // Log refund transaction
  serverWalletTransactions.unshift({
    id: `TX-REFUND-${wd.id}`,
    type: 'Admin_Adjustment',
    userId: wd.userId,
    userName: wd.userName,
    amountCoins: 0,
    amountDiamonds: wd.diamondAmount,
    status: 'Completed',
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    notes: `Refund for cancelled withdrawal ${wd.id}`,
    TEST_MODE: false
  });

  res.json({
    success: true,
    message: `Withdrawal ${withdrawalId} cancelled. +${wd.diamondAmount.toLocaleString()} Diamonds refunded.`,
    withdrawal: wd,
    newDiamondBalance: user ? user.diamondBalance : 0
  });
});

// 5. Update Withdrawal Status (Owner / Admin Action)
app.post("/api/owner/withdrawal/status", (req, res) => {
  const { withdrawalId, status, txHash, notes, reason } = req.body;
  const wd = serverWithdrawals.find(w => w.id === withdrawalId);
  if (!wd) {
    return res.status(404).json({ success: false, error: "Withdrawal request not found." });
  }

  let normalizedStatus = status;
  if (status && status.toUpperCase() === 'APPROVED') normalizedStatus = 'Approved';
  else if (status && status.toUpperCase() === 'REJECTED') normalizedStatus = 'Rejected';
  else if (status && status.toUpperCase() === 'PENDING') normalizedStatus = 'Pending';
  else if (status && status.toUpperCase() === 'COMPLETED') normalizedStatus = 'Completed';

  wd.status = normalizedStatus;
  if (txHash) wd.txHash = txHash;
  if (notes) wd.notes = notes;
  if (reason) (wd as any).rejectionReason = reason;

  if (normalizedStatus === 'Approved' || normalizedStatus === 'Completed') {
    wd.processedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } else if (normalizedStatus === 'Rejected') {
    // If rejected, refund user's diamonds
    const user = serverUsers[wd.userId];
    if (user) {
      user.diamondBalance += (wd.diamondAmount || (wd as any).diamondsAmount || 0);
      saveUsersStore();
    }
  }

  saveWithdrawalsStore();

  res.json({
    success: true,
    message: `Withdrawal status updated to ${normalizedStatus}.`,
    withdrawal: wd
  });
});

// ==========================================
// 6. PARTY LIVE — 20 SEATS & SIR CROWN
// ==========================================

interface ServerPartyRoom {
  id: string; title: string; ownerId: string; ownerName: string; ownerAvatar: string;
  crownHolderId: string; crownHolderName: string; crownTitle: string; totalSeats: 20;
  viewerCount: number; totalGiftsReceivedCoins: number; startedAt: string; status: string;
  category: string; liveRoomId?: string; seats: any[];
}

const emptyPartySeats = () => Array.from({ length: 20 }, (_, i) => ({
  seatNumber: i + 1, userId: undefined, userName: undefined, avatar: undefined,
  isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false,
  isMicOn: false, isLocked: false, vipLevel: 0, diamondsEarned: 0
}));

let serverPartyRoom: ServerPartyRoom | null = safeLoadJson<ServerPartyRoom | null>(PARTY_ROOM_STORE_FILE, null);

function savePartyRoomStore() {
  safeSaveJson(PARTY_ROOM_STORE_FILE, serverPartyRoom);
}

function buildPartyRoomFromLiveRoom(liveRoom: any): ServerPartyRoom {
  const saved = serverPartyRoom && serverPartyRoom.liveRoomId === liveRoom.roomId ? serverPartyRoom : null;
  const seats = Array.isArray(saved?.seats) && saved.seats.length === 20 ? saved!.seats : emptyPartySeats();
  seats[0] = {
    ...seats[0], seatNumber: 1, userId: liveRoom.hostId, userName: liveRoom.hostName,
    avatar: liveRoom.hostAvatar, isOwner: true, hasSirCrown: true, isMuted: false,
    isCameraOn: false, isMicOn: true, isLocked: false, vipLevel: 0, diamondsEarned: 0
  };
  return {
    id: liveRoom.roomId, title: liveRoom.roomName, ownerId: liveRoom.hostId, ownerName: liveRoom.hostName,
    ownerAvatar: liveRoom.hostAvatar, crownHolderId: liveRoom.hostId, crownHolderName: liveRoom.hostName,
    crownTitle: '👑 SIR CROWN', totalSeats: 20, viewerCount: liveRoom.onlineCount || 1,
    totalGiftsReceivedCoins: saved?.totalGiftsReceivedCoins || 0, startedAt: liveRoom.startedAt,
    status: 'Active', category: 'Party Live', liveRoomId: liveRoom.roomId, seats
  };
}

// 6.1 Get Party Live Room State
app.get("/api/party-live/room", (req, res) => {
  const requestedRoomId = req.query.roomId ? String(req.query.roomId) : '';
  const active = serverLiveRooms.find(r => r.status === 'LIVE' && r.liveType === 'PARTY' && (!requestedRoomId || r.roomId === requestedRoomId));
  if (!active) return res.json({ success: true, room: null });
  serverPartyRoom = buildPartyRoomFromLiveRoom(active);
  savePartyRoomStore();
  res.json({ success: true, room: serverPartyRoom });
});

// 6.2 Party Seat Actions (Take Seat, Leave Seat, Mute, Transfer Crown)
app.post("/api/party-live/seat/action", (req, res) => {
  const { action, seatNumber, user, targetSeat, roomId } = req.body;
  if (!serverPartyRoom || (roomId && serverPartyRoom.liveRoomId !== String(roomId))) {
    const active = serverLiveRooms.find(r => r.status === 'LIVE' && r.liveType === 'PARTY' && (!roomId || r.roomId === String(roomId)));
    if (!active) return res.status(404).json({ success:false, error:'Active Party Live room not found.' });
    serverPartyRoom = buildPartyRoomFromLiveRoom(active);
  }
  const seatNum = Number(seatNumber);

  if (action === 'TAKE_SEAT') {
    if (seatNum < 1 || seatNum > 20) {
      return res.status(400).json({ success: false, error: "Invalid seat number (1-20)." });
    }

    const currentSeat = serverPartyRoom.seats[seatNum - 1];
    if (currentSeat.userId && currentSeat.userId !== user?.id) {
      return res.status(400).json({ success: false, error: `Seat #${seatNum} is already occupied.` });
    }

    // Is this user the room owner?
    const isOwner = user?.id === serverPartyRoom.ownerId;
    // Seat 1 is strictly for room owner, or if owner takes seat 1
    if (seatNum === 1 && !isOwner) {
      return res.status(403).json({ success: false, error: "Seat #1 is reserved exclusively for the 👑 SIR CROWN Room Owner." });
    }

    serverPartyRoom.seats[seatNum - 1] = {
      seatNumber: seatNum,
      userId: user.id,
      userName: user.name,
      avatar: user.avatar,
      isOwner: isOwner,
      hasSirCrown: isOwner && seatNum === 1,
      isMuted: false,
      isCameraOn: true,
      isMicOn: true,
      isLocked: false,
      vipLevel: user.vipLevel ?? 0,
      diamondsEarned: 0,
      joinedAt: 'Just now'
    };
  } else if (action === 'LEAVE_SEAT') {
    if (seatNum < 1 || seatNum > 20) {
      return res.status(400).json({ success: false, error: "Invalid seat number." });
    }
    const isOwner = serverPartyRoom.seats[seatNum - 1]?.isOwner;
    serverPartyRoom.seats[seatNum - 1] = {
      seatNumber: seatNum,
      isOwner: false,
      hasSirCrown: false,
      isMuted: false,
      isCameraOn: false,
      isMicOn: false,
      isLocked: false
    };
  } else if (action === 'TOGGLE_MUTE') {
    if (serverPartyRoom.seats[seatNum - 1]) {
      serverPartyRoom.seats[seatNum - 1].isMuted = !serverPartyRoom.seats[seatNum - 1].isMuted;
      serverPartyRoom.seats[seatNum - 1].isMicOn = !serverPartyRoom.seats[seatNum - 1].isMuted;
    }
  } else if (action === 'TOGGLE_CAMERA') {
    if (serverPartyRoom.seats[seatNum - 1]) {
      serverPartyRoom.seats[seatNum - 1].isCameraOn = !serverPartyRoom.seats[seatNum - 1].isCameraOn;
    }
  } else if (action === 'TRANSFER_CROWN') {
    // Official Ownership transfer -> Sir Crown moves to new owner
    const newOwnerUser = user;
    if (newOwnerUser && newOwnerUser.id) {
      serverPartyRoom.ownerId = newOwnerUser.id;
      serverPartyRoom.ownerName = newOwnerUser.name;
      serverPartyRoom.crownHolderId = newOwnerUser.id;
      serverPartyRoom.crownHolderName = newOwnerUser.name;
      
      // Update seat 1
      serverPartyRoom.seats[0] = {
        seatNumber: 1,
        userId: newOwnerUser.id,
        userName: newOwnerUser.name,
        avatar: newOwnerUser.avatar,
        isOwner: true,
        hasSirCrown: true,
        isMuted: false,
        isCameraOn: true,
        isMicOn: true,
        isLocked: false,
        vipLevel: newOwnerUser.vipLevel || 8,
        diamondsEarned: 50000,
        joinedAt: 'Transferred Ownership'
      };
    }
  }

  savePartyRoomStore();
  res.json({
    success: true,
    room: serverPartyRoom
  });
});


// ==========================================
// 7. HOST TYPES, TAGS & FRAMES MANAGEMENT
// ==========================================
let serverAuditLogs: any[] = [];

const FRAME_MAP: Record<string, { frameId: string; frameName: string; previewUrl: string }> = {
  CELEBRATE: {
    frameId: 'FRM-HT-01',
    frameName: 'Celebrate Host Frame',
    previewUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150'
  },
  TALENT: {
    frameId: 'FRM-HT-02',
    frameName: 'Talent Host Frame',
    previewUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150'
  },
  SINGER: {
    frameId: 'FRM-HT-03',
    frameName: 'Singer Host Frame',
    previewUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150'
  },
  NORMAL: {
    frameId: 'FRM-HT-04',
    frameName: 'Normal Host Frame',
    previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150'
  }
};

app.get("/api/hosts/types", (req, res) => {
  res.json({
    success: true,
    hostTypes: [
      {
        tag: 'CELEBRATE',
        name: 'Celebrate Host',
        tagLabel: '🎉 CELEBRATE HOST',
        badgeIcon: '🎉',
        frameName: 'Celebrate Host Frame',
        frameId: 'FRM-HT-01'
      },
      {
        tag: 'TALENT',
        name: 'Talent Host',
        tagLabel: '⭐ TALENT HOST',
        badgeIcon: '⭐',
        frameName: 'Talent Host Frame',
        frameId: 'FRM-HT-02'
      },
      {
        tag: 'SINGER',
        name: 'Singer Host',
        tagLabel: '🎤 SINGER HOST',
        badgeIcon: '🎤',
        frameName: 'Singer Host Frame',
        frameId: 'FRM-HT-03'
      },
      {
        tag: 'NORMAL',
        name: 'Normal Host',
        tagLabel: '👤 NORMAL HOST',
        badgeIcon: '👤',
        frameName: 'Normal Host Frame',
        frameId: 'FRM-HT-04'
      }
    ]
  });
});

app.post("/api/hosts/assign-type", (req, res) => {
  const { hostId, hostTag, operatorRole = 'OWNER', operatorId = 'OWNER-001' } = req.body;
  
  // Security check: only Owner / Admin can assign host types
  const allowedRoles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'Owner', 'Super Admin', 'Admin'];
  if (!allowedRoles.includes(operatorRole)) {
    return res.status(403).json({
      success: false,
      error: "Unauthorized: Only authorized Owner/Admin accounts can assign Host Types."
    });
  }

  const validTags = ['CELEBRATE', 'TALENT', 'SINGER', 'NORMAL'];
  const normalizedTag = (hostTag || 'NORMAL').toUpperCase().replace(/\s+HOST$/i, '').trim();

  if (!validTags.includes(normalizedTag)) {
    return res.status(400).json({
      success: false,
      error: `Invalid Host Tag. Allowed values: ${validTags.join(', ')}`
    });
  }

  const targetHost = serverHosts[hostId];
  if (!targetHost) {
    // Create or mock host record if missing
    serverHosts[hostId] = {
      id: hostId,
      name: hostId.replace('HST-', 'Host '),
      username: `host_${hostId.toLowerCase()}`,
      agencyId: 'AG-01',
      agencyName: 'Starlight Elite Talent',
      managerId: 'MGR-301',
      managerName: 'Rahul Verma',
      status: 'Active',
      onlineStatus: 'Online',
      liveStatus: 'Live',
      followers: 12000,
      giftsReceived: 5400,
      diamonds: 320000,
      earningsUSD: 320.00,
      totalLiveHours: 85,
      lastLive: 'Just now',
      verificationStatus: 'Verified',
      streamCategory: 'entertainment',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      hostTag: normalizedTag as any,
      hostTypeId: `HT-${normalizedTag}`,
      avatarFrameId: FRAME_MAP[normalizedTag]?.frameId,
      avatarFrameUrl: FRAME_MAP[normalizedTag]?.previewUrl,
      hostLevel: 5,
      xp: 24000
    };
  } else {
    targetHost.hostTag = normalizedTag as any;
    targetHost.hostTypeId = `HT-${normalizedTag}`;
    targetHost.avatarFrameId = FRAME_MAP[normalizedTag]?.frameId;
    targetHost.avatarFrameUrl = FRAME_MAP[normalizedTag]?.previewUrl;
  }

  // Also synchronize user profile if user exists with same ID or username
  if (serverUsers[hostId]) {
    serverUsers[hostId].hostTag = normalizedTag as any;
    serverUsers[hostId].avatarFrameId = FRAME_MAP[normalizedTag]?.frameId;
    serverUsers[hostId].avatarFrameUrl = FRAME_MAP[normalizedTag]?.previewUrl;
  }

  // Record audit log
  serverAuditLogs.unshift({
    id: `AUDIT-HT-${Date.now()}`,
    operatorId: operatorId,
    operatorName: 'Authorized Admin',
    operatorRole: operatorRole as any,
    action: 'ASSIGN_HOST_TYPE',
    actionType: 'HOST_MANAGEMENT',
    targetId: hostId,
    targetRole: 'HOST',
    details: `Assigned official Host Type ${normalizedTag} (Frame: ${FRAME_MAP[normalizedTag]?.frameName}) to Host ${hostId}`,
    ipAddress: '127.0.0.1 (Authorized)',
    status: 'SUCCESS',
    timestamp: new Date().toISOString()
  });

  return res.json({
    success: true,
    message: `✅ Host ${hostId} successfully assigned Host Type: ${normalizedTag}`,
    host: serverHosts[hostId],
    assignedTag: normalizedTag,
    assignedFrame: FRAME_MAP[normalizedTag]
  });
});

app.get("/api/hosts/:hostId", (req, res) => {
  const host = serverHosts[req.params.hostId];
  if (!host) {
    return res.status(404).json({ success: false, error: "Host not found." });
  }
  res.json({ success: true, host });
});

// =========================================================================
// 8. AUTOMATIC UNIQUE 7-DIGIT SEQUENTIAL USER ID ENGINE & AUTH LINKING
// =========================================================================

// 8.1 Public / Client counter check
app.get("/api/auth/current-counter", (req, res) => {
  res.json({
    success: true,
    currentCounter: serverUserIdCounter,
    latestUserId: String(serverUserIdCounter).padStart(7, '0'),
    nextAvailableId: String(serverUserIdCounter + 1).padStart(7, '0'),
    totalRegisteredUsers: Object.keys(serverUsers).length,
    startingId: '0000001',
    idFormat: '7-Digit Sequential (0000001 - 9999999)'
  });
});

// 8.2 Admin User ID & Registration Statistics
app.get("/api/admin/user-id-stats", (req, res) => {
  const usersList = Object.values(serverUsers);
  res.json({
    success: true,
    currentCounter: serverUserIdCounter,
    latestUserId: String(serverUserIdCounter).padStart(7, '0'),
    nextAvailableId: String(serverUserIdCounter + 1).padStart(7, '0'),
    startingId: '0000001',
    idFormat: '7-Digit Sequential (0000001 - 9999999)',
    totalRegisteredUsers: usersList.length,
    activeUsersCount: usersList.filter(u => u.status === 'Active').length,
    mutedUsersCount: usersList.filter(u => u.status === 'Muted').length,
    bannedUsersCount: usersList.filter(u => u.status === 'Banned' || u.status === 'Suspended').length,
    totalDeletedAccounts: serverDeletedUserIds.length,
    deletedUserIdsAudit: serverDeletedUserIds,
    isPermanentSequential: true,
    reuseAllowed: false,
    rules: {
      backendGenerated: true,
      clientChoiceForbidden: true,
      sequentialDigits: 7,
      authLinkingPreserved: true,
      deletedIdsNeverReused: true
    }
  });
});

// 8.3 Backend Registration or Login with Auth Linking (STRICT ONE USER = ONE ID ENGINE)
app.post("/api/auth/register-or-login", (req, res) => {
  const {
    provider = 'google', // 'google' | 'phone' | 'facebook' | 'email'
    identifier, // email or phone or social account ID
    email,
    phone,
    name,
    avatar,
    countryCode = 'NP',
    countryFlag = '🇳🇵',
    countryName = 'Nepal',
    bio,
    deviceId,
    deviceFingerprint
  } = req.body;

  // Determine lookup keys for auth linking and device binding
  const cleanEmail = email ? String(email).trim().toLowerCase() : '';
  const cleanPhone = phone ? String(phone).replace(/[^0-9+]/g, '') : '';
  const cleanPhoneDigits = cleanPhone.replace(/[^0-9]/g, '');
  const cleanIdentifier = identifier ? String(identifier).trim().toLowerCase() : (cleanEmail || cleanPhone);
  const cleanDeviceId = deviceId ? String(deviceId).trim() : '';
  const cleanFingerprint = deviceFingerprint ? String(deviceFingerprint).trim() : '';

  if (!cleanIdentifier && !cleanEmail && !cleanPhone && !name) {
    return res.status(400).json({ success: false, error: "Identifier or credentials required." });
  }

  // =========================================================================
  // STEP 1: BACKEND MULTI-FACTOR IDENTITY RESOLUTION
  // Rule 9: All checks executed securely on the backend/database
  // =========================================================================
  let resolvedUserId: string | null = null;
  let resolutionReason: string = '';

  // 1A. Check Credential Match FIRST in persistent auth accounts & user records
  // (Prevents duplicate IDs across device changes, reinstalls, and logouts)
  let credentialMatchedUserId: string | null = null;
  if (cleanEmail && serverAuthAccounts[cleanEmail]) {
    credentialMatchedUserId = serverAuthAccounts[cleanEmail].userId;
  } else if (cleanPhone && serverAuthAccounts[cleanPhone]) {
    credentialMatchedUserId = serverAuthAccounts[cleanPhone].userId;
  } else if (cleanIdentifier && serverAuthAccounts[cleanIdentifier]) {
    credentialMatchedUserId = serverAuthAccounts[cleanIdentifier].userId;
  }

  if (!credentialMatchedUserId) {
    const matchedUser = Object.values(serverUsers).find(u => {
      if (cleanEmail && u.email && u.email.toLowerCase() === cleanEmail) return true;
      if (cleanEmail && u.linkedEmails && u.linkedEmails.map(e => e.toLowerCase()).includes(cleanEmail)) return true;
      if (cleanPhoneDigits && cleanPhoneDigits.length >= 7) {
        if (u.phone && u.phone.replace(/[^0-9]/g, '') === cleanPhoneDigits) return true;
        if (u.linkedPhones && u.linkedPhones.some(p => p.replace(/[^0-9]/g, '') === cleanPhoneDigits)) return true;
      }
      if (cleanIdentifier && u.linkedProviders && Object.values(u.linkedProviders).map(String).map(s => s.toLowerCase()).includes(cleanIdentifier)) return true;
      return false;
    });
    if (matchedUser) {
      credentialMatchedUserId = matchedUser.id;
    }
  }

  // Priority logic for ONE USER = ONE ID:
  // If credential matched an existing user, prioritize that user account (e.g. Master Owner or user changing device)
  if (credentialMatchedUserId && serverUsers[credentialMatchedUserId]) {
    resolvedUserId = credentialMatchedUserId;
    resolutionReason = `credential_match (#${credentialMatchedUserId})`;
  } else if (req.body.isNewAccount || req.body.isNewRegistration || cleanEmail || cleanPhone) {
    // Genuine new registration or distinct unlinked credential: NEVER merge with an old account on the same device!
    // A new user MUST receive their own brand new atomic 7-digit ID.
    resolvedUserId = null;
  } else {
    // Only for anonymous / guest login with NO credentials specified:
    if (cleanDeviceId && serverDeviceBindings[cleanDeviceId] && serverUsers[serverDeviceBindings[cleanDeviceId]]) {
      resolvedUserId = serverDeviceBindings[cleanDeviceId];
      resolutionReason = `device_id_bound (#${resolvedUserId})`;
    } else if (cleanFingerprint && serverFingerprintBindings[cleanFingerprint] && serverUsers[serverFingerprintBindings[cleanFingerprint]]) {
      resolvedUserId = serverFingerprintBindings[cleanFingerprint];
      resolutionReason = `hardware_fingerprint_bound (#${resolvedUserId})`;
    }
  }

  // Helper to issue single active mobile session token
  const issueSessionToken = (userId: string) => {
    const sessionToken = `SES-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    serverActiveSessions[userId] = {
      sessionToken,
      loginAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString()
    };
    return sessionToken;
  };

  // =========================================================================
  // STEP 2: CASE A - EXISTING ACCOUNT RESOLVED -> MERGE & LINK (NO DUPLICATE ID)
  // Rule 2: If mobile/device already has a Diyo Live ID, NO NEW ID is created.
  // Rule 3: Merge Mobile + Gmail + Facebook into that same Diyo Live ID.
  // Rule 7: Existing users' IDs and wallet/role/data are NEVER duplicated or reset.
  // =========================================================================
  if (resolvedUserId && serverUsers[resolvedUserId]) {
    const existingUser = serverUsers[resolvedUserId];
    const now = new Date().toISOString();
    const linkDate = now.split('T')[0];

    // Initialize arrays if undefined
    existingUser.linkedProviders = existingUser.linkedProviders || {};
    existingUser.linkedEmails = existingUser.linkedEmails || [];
    existingUser.linkedPhones = existingUser.linkedPhones || [];
    existingUser.boundDeviceIds = existingUser.boundDeviceIds || [];
    existingUser.boundFingerprints = existingUser.boundFingerprints || [];

    // Merge Provider
    if (provider && cleanIdentifier) {
      existingUser.linkedProviders[provider] = cleanIdentifier;
    }

    // Merge Email
    if (cleanEmail) {
      if (!existingUser.linkedEmails.includes(cleanEmail)) {
        existingUser.linkedEmails.push(cleanEmail);
      }
      serverAuthAccounts[cleanEmail] = {
        userId: existingUser.id,
        provider,
        identifier: cleanEmail,
        linkedAt: linkDate
      };
      if (!existingUser.email || existingUser.email.endsWith('@diyolive.io')) {
        existingUser.email = cleanEmail;
      }
    }

    // Merge Phone
    if (cleanPhone) {
      if (!existingUser.linkedPhones.includes(cleanPhone)) {
        existingUser.linkedPhones.push(cleanPhone);
      }
      serverAuthAccounts[cleanPhone] = {
        userId: existingUser.id,
        provider,
        identifier: cleanPhone,
        linkedAt: linkDate
      };
      if (!existingUser.phone) {
        existingUser.phone = cleanPhone;
      }
    }

    // Merge Identifier
    if (cleanIdentifier) {
      serverAuthAccounts[cleanIdentifier] = {
        userId: existingUser.id,
        provider,
        identifier: cleanIdentifier,
        linkedAt: linkDate
      };
    }

    // Bind physical device and hardware fingerprint to this user
    if (cleanDeviceId) {
      serverDeviceBindings[cleanDeviceId] = existingUser.id;
      if (!existingUser.boundDeviceIds.includes(cleanDeviceId)) {
        existingUser.boundDeviceIds.push(cleanDeviceId);
      }
    }
    if (cleanFingerprint) {
      serverFingerprintBindings[cleanFingerprint] = existingUser.id;
      if (!existingUser.boundFingerprints.includes(cleanFingerprint)) {
        existingUser.boundFingerprints.push(cleanFingerprint);
      }
    }

    // Update activity timestamps
    existingUser.lastActive = 'Just now';
    existingUser.lastLogin = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (avatar && !existingUser.avatar) existingUser.avatar = avatar;

    // Sticky Tag Directive: Preserve and enforce assigned official tag and role from hierarchy records
    const hierNode = serverHierarchyRelationships.find(h => h.userId === existingUser.id);
    if (hierNode && hierNode.roleStatus === 'Active' && hierNode.role) {
      existingUser.role = hierNode.role.replace(/\s+/g, '_');
      (existingUser as any).roleTag = hierNode.roleTag || hierNode.role;
      (existingUser as any).roleStatus = 'Active';
      (existingUser as any).assignedRoleTag = hierNode.roleTag || hierNode.role;
    }

    // Issue single active session token (terminates any conflicting device session)
    const sessionToken = issueSessionToken(existingUser.id);

    // Save all stores to persistent disk storage
    saveDeviceStore();
    saveFingerprintStore();
    saveAuthAccountsStore();
    saveUsersStore();

    return res.json({
      success: true,
      isNewUser: false,
      message: `✨ Welcome back, ${existingUser.name}! All your login methods (Mobile, Gmail, Facebook) are unified under permanent User ID #${existingUser.id}.`,
      user: existingUser,
      assignedId: existingUser.id,
      sessionToken,
      merged: true,
      resolutionReason
    });
  }

  // =========================================================================
  // STEP 3: CASE B - GENUINELY NEW USER REGISTRATION
  // Rule 4: Every genuinely new user automatically gets a new unique 7-digit User ID.
  // Rule 1: This mobile/device is then permanently bound to this single ID.
  // =========================================================================
  const new7DigitId = getNextSequentialUserId();

  const defaultAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80'
  ];
  const chosenAvatar = avatar || defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];
  const displayName = name || (cleanEmail ? cleanEmail.split('@')[0] : (cleanPhone ? `SR Star ${cleanPhone.slice(-4)}` : `SR Star ${new7DigitId.slice(-4)}`));
  const displayUsername = (displayName).toLowerCase().replace(/[^a-z0-9]/g, '_') + `_${new7DigitId.slice(-3)}`;
  const now = new Date().toISOString();
  const linkDate = now.split('T')[0];

  const newUserRecord: ServerUserRecord = {
    id: new7DigitId,
    name: displayName,
    username: displayUsername,
    email: cleanEmail || `${new7DigitId}@diyolive.io`,
    phone: cleanPhone || '',
    coinBalance: 0, // Genuine 100% Zero-State fresh user
    diamondBalance: 0,
    boltBalance: 0,
    vipLevel: 0,
    svipLevel: 0,
    userLevel: 1, // Standard baseline level 1
    role: 'USER', // Strictly standard user (NEVER default to Owner or Admin)
    roleStatus: 'NONE',
    roleTag: undefined, // Empty/null admin tag
    hostTag: undefined, // Empty/null host tag
    avatarFrameId: undefined, // Clean avatar frame
    avatarFrameUrl: undefined,
    status: 'Active',
    avatar: chosenAvatar,
    countryCode: countryCode || 'NP',
    countryFlag: countryFlag || '🇳🇵',
    countryName: countryName || 'Nepal',
    bio: bio || 'Live • Laugh • Share with DIYO VIP Global Community ❤️',
    joinedDate: linkDate,
    registrationDate: linkDate,
    lastActive: 'Just now',
    lastLogin: 'Just now',
    totalSpentCoins: 0,
    totalRechargedUSD: 0,
    deviceType: 'Android APK / Mobile Web',
    linkedProviders: { [provider]: cleanIdentifier || cleanEmail || cleanPhone },
    linkedEmails: cleanEmail ? [cleanEmail] : [],
    linkedPhones: cleanPhone ? [cleanPhone] : [],
    boundDeviceIds: cleanDeviceId ? [cleanDeviceId] : [],
    boundFingerprints: cleanFingerprint ? [cleanFingerprint] : []
  };

  serverUsers[new7DigitId] = newUserRecord;
  releaseReservedUserId(new7DigitId);

  // Bind device & fingerprint to this new user (One Device = One Account)
  if (cleanDeviceId) {
    serverDeviceBindings[cleanDeviceId] = new7DigitId;
    saveDeviceStore();
  }
  if (cleanFingerprint) {
    serverFingerprintBindings[cleanFingerprint] = new7DigitId;
    saveFingerprintStore();
  }

  // Issue single active session token for new user
  const sessionToken = issueSessionToken(new7DigitId);

  // Register in auth linking map
  if (cleanEmail) serverAuthAccounts[cleanEmail] = { userId: new7DigitId, provider, identifier: cleanEmail, linkedAt: linkDate };
  if (cleanPhone) serverAuthAccounts[cleanPhone] = { userId: new7DigitId, provider, identifier: cleanPhone, linkedAt: linkDate };
  if (cleanIdentifier) serverAuthAccounts[cleanIdentifier] = { userId: new7DigitId, provider, identifier: cleanIdentifier, linkedAt: linkDate };

  saveAuthAccountsStore();
  saveUsersStore();

  return res.json({
    success: true,
    isNewUser: true,
    message: `🎉 New account registered! Assigned permanent sequential User ID #${new7DigitId}. Device bound to this ID.`,
    user: newUserRecord,
    assignedId: new7DigitId,
    sequentialNumber: serverUserIdCounter,
    sessionToken
  });
});

// 8.3b Check Device Registration Status (One Device = One ID verification)
app.get("/api/auth/device-status", (req, res) => {
  const deviceId = req.query.deviceId ? String(req.query.deviceId).trim() : '';
  const deviceFingerprint = req.query.deviceFingerprint ? String(req.query.deviceFingerprint).trim() : '';

  let boundUserId: string | null = null;
  if (deviceId && serverDeviceBindings[deviceId]) {
    boundUserId = serverDeviceBindings[deviceId];
  } else if (deviceFingerprint && serverFingerprintBindings[deviceFingerprint]) {
    boundUserId = serverFingerprintBindings[deviceFingerprint];
  }

  if (boundUserId && serverUsers[boundUserId]) {
    const user = serverUsers[boundUserId];
    return res.json({
      success: true,
      isBound: true,
      userId: user.id,
      name: user.name,
      role: user.role,
      vipLevel: user.vipLevel,
      avatar: user.avatar,
      email: user.email,
      phone: user.phone ? user.phone.slice(0, 4) + '****' + user.phone.slice(-3) : undefined,
      linkedProviders: user.linkedProviders || {},
      linkedEmails: user.linkedEmails || [],
      linkedPhones: (user.linkedPhones || []).map(p => p.slice(0, 4) + '****' + p.slice(-3))
    });
  }

  return res.json({
    success: true,
    isBound: false,
    message: "Device is ready for new user registration."
  });
});

// 8.3c Link Additional Credential to Existing User ID
app.post("/api/auth/link-credential", (req, res) => {
  const { userId, provider, identifier, email, phone, deviceId, deviceFingerprint } = req.body;
  if (!userId || !serverUsers[userId]) {
    return res.status(404).json({ success: false, error: "User account not found." });
  }

  const user = serverUsers[userId];
  const cleanEmail = email ? String(email).trim().toLowerCase() : '';
  const cleanPhone = phone ? String(phone).replace(/[^0-9+]/g, '') : '';
  const cleanIdentifier = identifier ? String(identifier).trim().toLowerCase() : (cleanEmail || cleanPhone);
  const cleanDeviceId = deviceId ? String(deviceId).trim() : '';
  const cleanFingerprint = deviceFingerprint ? String(deviceFingerprint).trim() : '';
  const now = new Date().toISOString();
  const linkDate = now.split('T')[0];

  user.linkedProviders = user.linkedProviders || {};
  user.linkedEmails = user.linkedEmails || [];
  user.linkedPhones = user.linkedPhones || [];
  user.boundDeviceIds = user.boundDeviceIds || [];
  user.boundFingerprints = user.boundFingerprints || [];

  if (provider && cleanIdentifier) {
    user.linkedProviders[provider] = cleanIdentifier;
    serverAuthAccounts[cleanIdentifier] = { userId: user.id, provider, identifier: cleanIdentifier, linkedAt: linkDate };
  }
  if (cleanEmail) {
    if (!user.linkedEmails.includes(cleanEmail)) user.linkedEmails.push(cleanEmail);
    serverAuthAccounts[cleanEmail] = { userId: user.id, provider: provider || 'email', identifier: cleanEmail, linkedAt: linkDate };
    if (!user.email || user.email.endsWith('@diyolive.io')) user.email = cleanEmail;
  }
  if (cleanPhone) {
    if (!user.linkedPhones.includes(cleanPhone)) user.linkedPhones.push(cleanPhone);
    serverAuthAccounts[cleanPhone] = { userId: user.id, provider: provider || 'phone', identifier: cleanPhone, linkedAt: linkDate };
    if (!user.phone) user.phone = cleanPhone;
  }
  if (cleanDeviceId) {
    serverDeviceBindings[cleanDeviceId] = user.id;
    if (!user.boundDeviceIds.includes(cleanDeviceId)) user.boundDeviceIds.push(cleanDeviceId);
    saveDeviceStore();
  }
  if (cleanFingerprint) {
    serverFingerprintBindings[cleanFingerprint] = user.id;
    if (!user.boundFingerprints.includes(cleanFingerprint)) user.boundFingerprints.push(cleanFingerprint);
    saveFingerprintStore();
  }

  saveAuthAccountsStore();
  saveUsersStore();

  return res.json({
    success: true,
    message: `Account credential (${provider}) successfully linked to User ID #${user.id}.`,
    user
  });
});

// =========================================================================
// PERMANENT USER PROFILE UPDATE API (Persists to database)
// =========================================================================
app.post(["/api/users/profile", "/api/users/:userId/profile"], (req, res) => {
  const targetUserId = req.params.userId || req.body.userId || req.body.id;
  if (!targetUserId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  const cleanId = String(targetUserId).trim();
  const paddedKey = /^\d+$/.test(cleanId) ? cleanId.padStart(7, '0') : cleanId;
  const user = serverUsers[cleanId] || serverUsers[paddedKey] || Object.values(serverUsers).find(u => u.id === cleanId);

  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID "${targetUserId}" not found in database.` });
  }

  const { name, username, avatar, bio, gender, dob, countryName, countryFlag, countryCode, phone, profileTag } = req.body;

  if (name !== undefined && String(name).trim().length > 0) {
    user.name = String(name).trim();
  }
  if (username !== undefined && String(username).trim().length > 0) {
    user.username = String(username).trim();
  }
  if (avatar !== undefined && String(avatar).trim().length > 0) {
    user.avatar = String(avatar).trim();
  }
  if (bio !== undefined) user.bio = String(bio).trim();
  if (gender !== undefined) user.gender = gender;
  if (dob !== undefined) user.dob = dob;
  if (countryName !== undefined) user.countryName = countryName;
  if (countryFlag !== undefined) user.countryFlag = countryFlag;
  if (countryCode !== undefined) user.countryCode = countryCode;
  if (phone !== undefined) user.phone = phone;
  if (profileTag !== undefined) user.profileTag = profileTag;
  user.lastActive = 'Just now';

  // Permanently save to disk
  saveUsersStore();

  return res.json({
    success: true,
    message: "User profile updated and permanently saved in database.",
    user
  });
});

// 8.3b Verify Active Mobile Session (One ID = One Active Session Enforcement)
app.post("/api/auth/verify-session", (req, res) => {
  const { userId, sessionToken } = req.body;
  if (!userId || !sessionToken) {
    return res.status(400).json({ success: false, valid: false, error: "User ID and session token required." });
  }

  const activeSession = serverActiveSessions[userId];
  if (!activeSession) {
    // If no active session recorded yet, adopt this session
    serverActiveSessions[userId] = {
      sessionToken,
      loginAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString()
    };
    return res.json({ success: true, valid: true });
  }

  if (activeSession.sessionToken !== sessionToken) {
    // Another device logged in with this User ID! Terminate Device A immediately.
    return res.json({
      success: false,
      valid: false,
      terminated: true,
      error: "Your account was logged in from another device. You have been logged out for security."
    });
  }

  activeSession.lastActiveAt = new Date().toISOString();
  return res.json({ success: true, valid: true });
});

// 8.3c Host Agency Join & Approval Endpoints
app.get("/api/agencies", (req, res) => {
  res.json({
    success: true,
    agencies: serverAgencies
  });
});

app.get("/api/agency/status/:userId", (req, res) => {
  const { userId } = req.params;
  const isOwner = userId === '0000001' || userId === 'OWNER-001';
  const membership = serverAgencyMemberships[userId];
  const pendingRequest = serverAgencyRequests.find(r => r.hostId === userId && r.status === 'PENDING');

  res.json({
    success: true,
    isOwner,
    hasApprovedAgency: isOwner || (membership && membership.status === 'APPROVED'),
    membership: membership || null,
    pendingRequest: pendingRequest || null
  });
});

app.post("/api/agency/request-join", (req, res) => {
  const { hostId, hostName, hostAvatar, agencyId, faceVerified, facePhotoUrl } = req.body;
  if (!hostId || !agencyId) {
    return res.status(400).json({ success: false, error: "Host ID and Agency ID required." });
  }

  if (!faceVerified) {
    return res.status(400).json({ 
      success: false, 
      error: "Face Verification Required: You must complete live face verification before submitting an agency join request." 
    });
  }

  const agency = serverAgencies.find(a => a.id === agencyId);
  if (!agency) {
    return res.status(404).json({ success: false, error: "Agency not found." });
  }

  // Check if already approved
  if (serverAgencyMemberships[hostId]?.status === 'APPROVED') {
    return res.status(400).json({ success: false, error: "You already belong to an approved agency." });
  }

  // Check existing pending request
  const existingPending = serverAgencyRequests.find(r => r.hostId === hostId && r.agencyId === agencyId && r.status === 'PENDING');
  if (existingPending) {
    return res.json({
      success: true,
      message: "Your join request is already pending approval from the Agency Owner.",
      request: existingPending
    });
  }

  const newReq = {
    id: `AJR-${Date.now().toString().slice(-4)}`,
    hostId,
    hostName: hostName || `Host ${hostId}`,
    hostAvatar: hostAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    agencyId,
    agencyName: agency.name,
    faceVerified: true,
    facePhotoUrl: facePhotoUrl || hostAvatar,
    faceVerifiedAt: new Date().toISOString(),
    status: 'PENDING' as const,
    requestDate: new Date().toISOString()
  };

  serverAgencyRequests.unshift(newReq);
  saveAgencyStore();

  res.json({
    success: true,
    message: `✅ Join request with Face Verification submitted to "${agency.name}". Awaiting Agency approval.`,
    request: newReq
  });
});

app.post("/api/agency/approve-request", (req, res) => {
  const { requestId, hostId } = req.body;
  const targetReq = serverAgencyRequests.find(r => (requestId && r.id === requestId) || (hostId && r.hostId === hostId));
  if (!targetReq) {
    return res.status(404).json({ success: false, error: "Agency join request not found." });
  }

  targetReq.status = 'APPROVED';
  serverAgencyMemberships[targetReq.hostId] = {
    agencyId: targetReq.agencyId,
    agencyName: targetReq.agencyName,
    joinedAt: new Date().toISOString(),
    status: 'APPROVED'
  };

  // Update user record if in serverUsers
  if (serverUsers[targetReq.hostId]) {
    serverUsers[targetReq.hostId].role = 'HOST';
    serverUsers[targetReq.hostId].roleTag = 'HOST';
    serverUsers[targetReq.hostId].hostTag = targetReq.agencyName;
    saveUsersStore();
  }
  saveAgencyStore();

  res.json({
    success: true,
    message: `🎉 Host ${targetReq.hostName} approved as member of ${targetReq.agencyName}. Live streaming is now enabled!`,
    membership: serverAgencyMemberships[targetReq.hostId]
  });
});

app.post("/api/agency/reject-request", (req, res) => {
  const { requestId, hostId, reason } = req.body;
  const targetReq = serverAgencyRequests.find(r => (requestId && r.id === requestId) || (hostId && r.hostId === hostId));
  if (!targetReq) {
    return res.status(404).json({ success: false, error: "Agency join request not found." });
  }

  targetReq.status = 'REJECTED';
  (targetReq as any).rejectionReason = reason || 'Verification requirements not satisfied.';
  saveAgencyStore();

  res.json({
    success: true,
    message: `Agency request for ${targetReq.hostName} rejected.`,
    request: targetReq
  });
});

app.post("/api/agency/leave", (req, res) => {
  const { hostId } = req.body;
  if (!hostId) return res.status(400).json({ success: false, error: "Host ID required." });

  delete serverAgencyMemberships[hostId];
  serverAgencyRequests = serverAgencyRequests.filter(r => r.hostId !== hostId);

  if (serverUsers[hostId]) {
    serverUsers[hostId].role = 'USER';
    serverUsers[hostId].roleTag = undefined;
    serverUsers[hostId].hostTag = undefined;
    saveUsersStore();
  }
  saveAgencyStore();

  res.json({
    success: true,
    message: "Host removed from Agency. Live broadcast access has been revoked until re-approved."
  });
});

// 8.4 User Search by 7-digit ID, username, or name
app.get("/api/users/search", (req, res) => {
  const rawQ = String(req.query.q || '').trim();
  const q = rawQ.toLowerCase();
  if (!q) {
    return res.json({ success: true, users: Object.values(serverUsers).filter(u => !serverDeletedUserIds.includes(u.id)) });
  }

  const digits = rawQ.replace(/\D/g, '');
  const paddedQuery = digits ? digits.padStart(7, '0') : '';

  // Exact 7-digit match, padded match, or partial match (strictly exclude deleted IDs)
  let results = Object.values(serverUsers).filter(u => {
    if (serverDeletedUserIds.includes(u.id)) return false;
    return u.id === q ||
           (paddedQuery && u.id === paddedQuery) ||
           u.id.includes(q) ||
           u.username.toLowerCase().includes(q) ||
           u.name.toLowerCase().includes(q) ||
           (u.email && u.email.toLowerCase().includes(q)) ||
           (u.phone && u.phone.includes(q));
  });

  // Never synthesize a user during search. Search is read-only and may only return real database users.

  res.json({
    success: true,
    query: q,
    count: results.length,
    users: results
  });
});

// 8.5 Get Single User Dossier by ID
app.get("/api/users/:userId", (req, res) => {
  const { userId } = req.params;
  const normalizedKey = String(userId).trim();
  const paddedKey = /^\d+$/.test(normalizedKey) ? normalizedKey.padStart(7, '0') : normalizedKey;

  const user = serverUsers[normalizedKey] || serverUsers[paddedKey] || Object.values(serverUsers).find(
    u => u.username.toLowerCase() === normalizedKey.toLowerCase()
  );

  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID "${userId}" not found.` });
  }

  res.json({ success: true, user });
});

// 8.6 Admin Delete / Deactivate User (Strict Rule: ID is NEVER recycled)
app.post("/api/admin/users/delete", (req, res) => {
  const { userId, operatorRole = 'OWNER' } = req.body;
  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  const paddedKey = /^\d+$/.test(String(userId).trim()) ? String(userId).trim().padStart(7, '0') : String(userId).trim();
  const user = serverUsers[paddedKey];

  if (!user) {
    return res.status(404).json({ success: false, error: `User ID #${userId} not found.` });
  }

  // Record deleted ID in audit trail to guarantee it is NEVER recycled
  if (!serverDeletedUserIds.includes(user.id)) {
    serverDeletedUserIds.push(user.id);
  }

  // Delete from active serverUsers
  delete serverUsers[user.id];

  // Note: serverUserIdCounter is INTENTIONALLY NOT decremented
  res.json({
    success: true,
    message: `Account #${user.id} (${user.name}) deleted. ID #${user.id} retired permanently and will NEVER be reused.`,
    deletedUserId: user.id,
    currentCounterRemains: serverUserIdCounter,
    nextAvailableIdRemains: String(serverUserIdCounter + 1).padStart(7, '0')
  });
});

// 8.7 Admin Update User Status
app.post("/api/admin/users/status", (req, res) => {
  const { userId, status } = req.body;
  const paddedKey = /^\d+$/.test(String(userId).trim()) ? String(userId).trim().padStart(7, '0') : String(userId).trim();
  const user = serverUsers[paddedKey];

  if (!user) {
    return res.status(404).json({ success: false, error: `User ID #${userId} not found.` });
  }

  user.status = status;
  res.json({
    success: true,
    message: `User #${user.id} status updated to ${status}.`,
    user
  });
});

// 8.8 Admin & Super Admin Instant Ban Power
app.post("/api/admin/users/ban", (req, res) => {
  const { userId, reason = 'Terms of Service Violation', duration = 'Permanent', operator = 'Admin / Super Admin' } = req.body;
  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  const paddedKey = /^\d+$/.test(String(userId).trim()) ? String(userId).trim().padStart(7, '0') : String(userId).trim();
  const user = serverUsers[paddedKey] || Object.values(serverUsers).find(
    u => u.username.toLowerCase() === String(userId).toLowerCase() || u.id === String(userId)
  );

  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID #${userId} not found in database.` });
  }

  user.status = 'Banned';
  (user as any).banReason = reason;
  (user as any).banDuration = duration;
  (user as any).bannedAt = new Date().toISOString();
  (user as any).bannedBy = operator;

  res.json({
    success: true,
    message: `⛔ User #${user.id} (${user.name}) has been BANNED successfully by ${operator}. Reason: ${reason}`,
    user
  });
});

// 8.9 Admin & Super Admin Instant Unban Power
app.post("/api/admin/users/unban", (req, res) => {
  const { userId, operator = 'Admin / Super Admin' } = req.body;
  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  const paddedKey = /^\d+$/.test(String(userId).trim()) ? String(userId).trim().padStart(7, '0') : String(userId).trim();
  const user = serverUsers[paddedKey] || Object.values(serverUsers).find(
    u => u.username.toLowerCase() === String(userId).toLowerCase() || u.id === String(userId)
  );

  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID #${userId} not found in database.` });
  }

  user.status = 'Active';
  delete (user as any).banReason;
  delete (user as any).banDuration;
  (user as any).unbannedAt = new Date().toISOString();
  (user as any).unbannedBy = operator;

  res.json({
    success: true,
    message: `✅ User #${user.id} (${user.name}) has been UNBANNED and restored to Active status by ${operator}.`,
    user
  });
});

// 8.10 Get Banned Users Registry
app.get("/api/admin/users/banned", (req, res) => {
  const banned = Object.values(serverUsers).filter(u => u.status === 'Banned' || u.status === 'Suspended');
  res.json({
    success: true,
    count: banned.length,
    bannedUsers: banned
  });
});

// =========================================================================
// 9. OFFICIAL DIYO LIVE ROLE HIERARCHY & REPORTING ARCHITECTURE (REQUIREMENT 22-30)
// =========================================================================

export type DiyoRole = 'OWNER' | 'MANAGER' | 'SUPER ADMIN' | 'BD ADMIN' | 'SUPER BD' | 'AGENCY' | 'COIN SELLER' | 'HOST' | 'USER';

export interface ServerHierarchyRelationship {
  id: string; // e.g. HIER-001
  userId: string;
  name: string;
  username: string;
  avatar: string;
  role: DiyoRole;
  roleTag?: string;
  hiredByUserId: string;
  hiredByName: string;
  hiredByRole: string;
  parentUserId: string;
  parentRole: string;
  hierarchyPath: string; // e.g. "0000001/0000002/0000003"
  assignedAt: string;
  assignedBy: string;
  removedAt?: string;
  removedBy?: string;
  roleStatus: 'Active' | 'Removed';
  activeStatus: 'ACTIVE' | 'SUSPENDED' | 'BANNED';
  permissions: string[];
  notes?: string;
}

export interface HierarchyAuditEntry {
  id: string;
  action: 'HIRE' | 'REMOVE' | 'CHANGE_ROLE' | 'DISTRIBUTE_FRAME' | 'BAN_UNBAN';
  operatorId: string;
  operatorName: string;
  operatorRole: string;
  targetUserId: string;
  targetName: string;
  targetRole: string;
  previousRole?: string;
  timestamp: string;
  details: string;
}

export interface ServerHiredRole {
  id: string;
  userId: string;
  name: string;
  username: string;
  avatar: string;
  role: 'MANAGER' | 'SUPER ADMIN' | 'SUPER BD' | 'BD ADMIN' | 'AGENCY' | 'COIN SELLER' | 'HOST';
  roleStatus: 'Active' | 'Removed';
  assignedBy: string;
  assignedAt: string;
  removedBy?: string;
  removedAt?: string;
  permissions: string[];
  parentUserId?: string;
  parentRole?: string;
  hiredByUserId?: string;
  hierarchyPath?: string;
}

export const ROLE_PERMISSIONS_MAP: Record<string, string[]> = {
  'OWNER': [
    'ACCESS_ALL_PANELS', 'VIEW_ALL_USERS', 'VIEW_ALL_ROLES', 'VIEW_COMPLETE_HIERARCHY',
    'HIRE_STAFF', 'REMOVE_STAFF', 'PROMOTE_STAFF', 'DEMOTE_STAFF', 'CHANGE_ROLE',
    'MANAGE_MANAGERS', 'MANAGE_SUPER_ADMINS', 'MANAGE_BD_ADMINS', 'MANAGE_AGENCIES',
    'MANAGE_COIN_SELLERS', 'MANAGE_HOSTS', 'PLATFORM_SETTINGS', 'MANAGE_BANNERS',
    'MANAGE_USER_DATA', 'BAN_UNBAN_USERS', 'MANAGE_VIP_FRAMES'
  ],
  'MANAGER': [
    'ACCESS_MANAGER_PANEL', 'MANAGE_SUBORDINATE_ACCOUNTS', 'VIEW_ASSIGNED_HIERARCHY',
    'HIRE_AUTHORIZED_SUBORDINATES', 'REMOVE_SUBORDINATE_ROLES', 'VIEW_OPERATIONAL_TEAMS',
    'TRACK_SUBORDINATE_STATUS', 'VIEW_AGENCY_REPORTS', 'RESOLVE_DISPUTES', 'VIEW_ROOM_METRICS'
  ],
  'SUPER ADMIN': [
    'ACCESS_SUPER_ADMIN_PANEL', 'MANAGE_SUBORDINATE_ACCOUNTS', 'VIEW_SUBORDINATE_HIERARCHY',
    'HIRE_AUTHORIZED_ROLES', 'BAN_AUTHORIZED_IDS', 'UNBAN_AUTHORIZED_IDS',
    'ASSIGN_VIP_LIMITS', 'DISTRIBUTE_FRAMES_1_TO_5', 'MANAGE_SUBORDINATE_OPERATIONS',
    'MODERATE_ROOMS', 'VIEW_AUDIT_LOGS', 'MONITOR_GLOBAL_LIVE'
  ],
  'ADMIN': [
    'ACCESS_ADMIN_PANEL', 'MANAGE_SUBORDINATE_ACCOUNTS', 'VIEW_SUBORDINATE_HIERARCHY',
    'HIRE_AUTHORIZED_ROLES', 'MODERATE_ROOMS', 'VIEW_AUDIT_LOGS', 'MONITOR_GLOBAL_LIVE',
    'START_VIDEO_LIVE', 'START_PARTY_LIVE'
  ],
  'OFFICIAL': [
    'ACCESS_OFFICIAL_PANEL', 'VIEW_SUBORDINATE_HIERARCHY', 'HIRE_AUTHORIZED_ROLES',
    'MODERATE_ROOMS', 'START_VIDEO_LIVE', 'START_PARTY_LIVE', 'TRACK_OWN_PERFORMANCE'
  ],
  'BD ADMIN': [
    'ACCESS_BD_ADMIN_PANEL', 'MANAGE_DIRECT_AGENCIES', 'VIEW_AGENCY_PIPELINE',
    'TRACK_SUBORDINATE_AGENCIES', 'MANAGE_LOCAL_OPERATIONS', 'VIEW_AGENCY_PERFORMANCE',
    'MANAGE_SUBORDINATE_HOSTS', 'ONBOARD_AGENCIES', 'RECRUIT_HOSTS', 'TRACK_REGIONAL_GROWTH'
  ],
  'SUPER BD': [
    'ACCESS_BD_ADMIN_PANEL', 'MANAGE_DIRECT_AGENCIES', 'VIEW_AGENCY_PIPELINE',
    'TRACK_SUBORDINATE_AGENCIES', 'MANAGE_LOCAL_OPERATIONS', 'VIEW_AGENCY_PERFORMANCE',
    'MANAGE_SUBORDINATE_HOSTS', 'ONBOARD_AGENCIES', 'RECRUIT_HOSTS', 'TRACK_REGIONAL_GROWTH'
  ],
  'AGENCY': [
    'ACCESS_AGENCY_PANEL', 'SEARCH_REVIEW_HOSTS', 'HIRE_ASSIGN_HOSTS',
    'MANAGE_OWN_HOSTS', 'VIEW_HOST_PROFILES', 'TRACK_HOST_PERFORMANCE',
    'VIEW_LIVE_ACTIVITY', 'MANAGE_HOST_RECORDS', 'VIEW_AGENCY_COMMISSIONS', 'TRACK_HOST_HOURS'
  ],
  'COIN SELLER': [
    'ACCESS_COIN_SELLER_PANEL', 'SEARCH_USERS_FOR_RECHARGE', 'PROCESS_COIN_RECHARGE',
    'VIEW_RECHARGE_RECORDS', 'VIEW_OWN_SALES_LEDGER', 'SELL_COINS_TO_USERS'
  ],
  'HOST': [
    'START_VIDEO_LIVE', 'START_PARTY_LIVE', 'TRACK_OWN_PERFORMANCE',
    'VIEW_REWARD_PROGRESS', 'CLAIM_LIVE_TIME_REWARD'
  ],
  'USER': [
    'VIEW_LIVE_STREAMS', 'JOIN_PARTY_ROOM', 'SEND_GIFTS', 'CHAT_IN_ROOMS', 'BUY_COINS_FROM_SELLER'
  ]
};

// Strict Hiring Permission Matrix: Defines EXACTLY which roles each role is permitted to hire
export const HIRING_PERMISSIONS_MATRIX: Record<string, string[]> = {
  'OWNER': ['MANAGER', 'OFFICIAL', 'SUPER ADMIN', 'ADMIN', 'BD ADMIN', 'SUPER BD', 'AGENCY', 'COIN SELLER', 'HOST'],
  'MANAGER': ['SUPER ADMIN', 'ADMIN', 'BD ADMIN', 'SUPER BD', 'AGENCY', 'COIN SELLER'],
  'SUPER ADMIN': ['ADMIN', 'BD ADMIN', 'SUPER BD', 'AGENCY', 'COIN SELLER'],
  'ADMIN': ['AGENCY', 'COIN SELLER', 'HOST'],
  'OFFICIAL': ['HOST'],
  'BD ADMIN': ['AGENCY'],
  'SUPER BD': ['AGENCY'],
  'AGENCY': ['HOST'],
  'COIN SELLER': [], // STRICT: Coin Seller CANNOT hire any role
  'HOST': [],        // STRICT: Host CANNOT hire any role
  'USER': []         // STRICT: User CANNOT hire any role
};

// Seed Hierarchy Relationships
let serverHierarchyRelationships: ServerHierarchyRelationship[] = [
  {
    id: 'HIER-001',
    userId: '0000001',
    name: 'Salam Star Owner',
    username: 'salamstar_owner',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    role: 'OWNER',
    roleTag: 'OWNER',
    hiredByUserId: 'SYSTEM',
    hiredByName: 'DIYO LIVE System',
    hiredByRole: 'ROOT',
    parentUserId: 'SYSTEM',
    parentRole: 'ROOT',
    hierarchyPath: '0000001',
    assignedAt: '2025-01-01T00:00:00.000Z',
    assignedBy: 'SYSTEM',
    roleStatus: 'Active',
    activeStatus: 'ACTIVE',
    permissions: ROLE_PERMISSIONS_MAP['OWNER'],
    notes: 'Supreme Owner & Platform Founder'
  }
];

let serverHierarchyAudit: HierarchyAuditEntry[] = [
  {
    id: 'AUD-INIT-001',
    action: 'HIRE',
    operatorId: 'SYSTEM',
    operatorName: 'DIYO LIVE System',
    operatorRole: 'ROOT',
    targetUserId: '0000001',
    targetName: 'Salam Star Owner',
    targetRole: 'OWNER',
    timestamp: '2025-01-01T00:00:00.000Z',
    details: 'System established Supreme Master Owner account (#0000011)'
  }
];

// Synchronize legacy serverHiredRoles with hierarchy
let serverHiredRoles: ServerHiredRole[] = serverHierarchyRelationships
  .filter(h => h.role !== 'OWNER' && h.role !== 'USER')
  .map(h => ({
    id: h.id,
    userId: h.userId,
    name: h.name,
    username: h.username,
    avatar: h.avatar,
    role: h.role as any,
    roleStatus: h.roleStatus,
    assignedBy: `${h.hiredByUserId} (${h.hiredByName})`,
    assignedAt: h.assignedAt,
    permissions: h.permissions,
    parentUserId: h.parentUserId,
    parentRole: h.parentRole,
    hiredByUserId: h.hiredByUserId,
    hierarchyPath: h.hierarchyPath
  }));

// Load persistent hierarchy after startup. The persistent store is the source of truth.
const persistedHierarchy = safeLoadJson<ServerHierarchyRelationship[]>(HIERARCHY_STORE_FILE, []);
const persistedHierarchyAudit = safeLoadJson<HierarchyAuditEntry[]>(HIERARCHY_AUDIT_STORE_FILE, []);
if (Array.isArray(persistedHierarchy) && persistedHierarchy.length > 0) {
  serverHierarchyRelationships = persistedHierarchy.filter(Boolean);
}
if (!serverHierarchyRelationships.some(h => h.userId === '0000001')) {
  serverHierarchyRelationships.unshift({
    id: 'HIER-001', userId: '0000001', name: serverUsers['0000001']?.name || 'Salam Star Owner',
    username: serverUsers['0000001']?.username || 'salamstar_owner', avatar: serverUsers['0000001']?.avatar || '',
    role: 'OWNER', roleTag: 'OWNER', hiredByUserId: 'SYSTEM', hiredByName: 'DIYO LIVE System',
    hiredByRole: 'ROOT', parentUserId: 'SYSTEM', parentRole: 'ROOT', hierarchyPath: '0000001',
    assignedAt: '2025-01-01T00:00:00.000Z', assignedBy: 'SYSTEM', roleStatus: 'Active', activeStatus: 'ACTIVE',
    permissions: ROLE_PERMISSIONS_MAP['OWNER'], notes: 'Supreme Owner & Platform Founder'
  });
}
if (Array.isArray(persistedHierarchyAudit) && persistedHierarchyAudit.length > 0) {
  serverHierarchyAudit = persistedHierarchyAudit;
}
syncLegacyHiredRoles();
saveHierarchyStore();

// Normalizes role strings
function normalizeRole(role: string): string {
  const r = (role || '').trim().toUpperCase().replace(/_/g, ' ');
  if (r === 'SUPER BD') return 'BD ADMIN';
  return r;
}

// Helper: Verify Owner Authorization (Strict database & UID check)
function verifyOwnerAuth(req: express.Request): boolean {
  const { ownerEmail, ownerUserId } = req.body || {};
  const queryOwner = req.query?.ownerEmail;
  const headerEmail = req.headers['x-owner-email'];
  const email = (ownerEmail || queryOwner || headerEmail) as string | undefined;
  const uid = (ownerUserId || req.headers['x-owner-id']) as string | undefined;

  // The actual Owner account is strictly bound to UID '0000001' or 'OWNER-001'
  if (uid === '0000001' || uid === 'OWNER-001') {
    const userInDb = serverUsers[uid];
    if (userInDb && userInDb.role !== 'OWNER') return false;
    return true;
  }
  if (email === 'salamstarhotel@gmail.com') {
    return true;
  }
  return false;
}

// Helper: Resolve requesting operator from headers or body
function resolveOperator(req: express.Request): { operatorId: string; operatorRole: string; operatorUser: any } {
  const headerId = (req.headers['x-operator-id'] || req.headers['x-user-id'] || req.headers['x-owner-id']) as string;
  const headerRole = (req.headers['x-operator-role'] || req.headers['x-role']) as string;
  const bodyId = req.body?.operatorId || req.body?.ownerUserId;
  const bodyRole = req.body?.operatorRole;
  const queryId = req.query?.operatorId as string;

  // Do NOT fall back to '0000001' by default; fallback must be empty to prevent privilege escalation!
  const operatorId = String(bodyId || headerId || queryId || '').trim();
  if (!operatorId) {
    return { operatorId: '', operatorRole: 'USER', operatorUser: null };
  }

  const user = serverUsers[operatorId];
  const hierRel = serverHierarchyRelationships.find(h => h.userId === operatorId);
  
  // Database-authoritative role verification
  let operatorRole = 'USER';
  if (operatorId === '0000001' || req.headers['x-owner-email'] === 'salamstarhotel@gmail.com') {
    operatorRole = 'OWNER';
  } else if (user && user.role) {
    operatorRole = normalizeRole(user.role);
  } else if (hierRel && hierRel.role) {
    operatorRole = normalizeRole(hierRel.role);
  } else if (bodyRole || headerRole) {
    const candidateRole = normalizeRole(bodyRole || headerRole);
    // Only accept candidate if recognized as staff in database
    if (user && user.role === candidateRole) {
      operatorRole = candidateRole;
    }
  }

  return { operatorId, operatorRole, operatorUser: user };
}

// Helper: Check if an operator role is authorized to hire a specific role
function canOperatorHireRole(operatorRole: string, targetRole: string): boolean {
  const op = normalizeRole(operatorRole);
  const target = normalizeRole(targetRole);
  const allowed = HIRING_PERMISSIONS_MATRIX[op] || [];
  return allowed.map(normalizeRole).includes(target);
}

// Helper: Check if target user is in the operator's authorized reporting hierarchy
function isUserInHierarchy(operatorId: string, operatorRole: string, targetUserId: string): boolean {
  const normRole = normalizeRole(operatorRole);
  if (normRole === 'OWNER' || operatorId === '0000001') return true;

  const targetRel = serverHierarchyRelationships.find(h => h.userId === targetUserId);
  if (!targetRel) return false;
  if (targetRel.userId === operatorId) return false; // Cannot manage self as subordinate

  const pathParts = targetRel.hierarchyPath.split('/');
  return pathParts.includes(operatorId) || targetRel.parentUserId === operatorId || targetRel.hiredByUserId === operatorId;
}

// Helper: Get all visible subordinates for an operator based on hierarchyPath
function getVisibleSubordinates(operatorId: string, operatorRole: string, includeRemoved = false): ServerHierarchyRelationship[] {
  const normRole = normalizeRole(operatorRole);
  if (normRole === 'OWNER' || operatorId === '0000001') {
    return includeRemoved
      ? serverHierarchyRelationships.filter(n => n.userId !== '0000001')
      : serverHierarchyRelationships.filter(n => n.userId !== '0000001' && n.roleStatus === 'Active');
  }

  return serverHierarchyRelationships.filter(node => {
    if (node.userId === operatorId) return false;
    if (!includeRemoved && node.roleStatus !== 'Active') return false;
    const pathParts = node.hierarchyPath.split('/');
    return pathParts.includes(operatorId) || node.parentUserId === operatorId || node.hiredByUserId === operatorId;
  });
}

// Helper to keep serverHiredRoles and serverHierarchyRelationships in sync
function syncLegacyHiredRoles() {
  serverHiredRoles = serverHierarchyRelationships
    .filter(h => h.role !== 'OWNER' && h.role !== 'USER')
    .map(h => ({
      id: h.id,
      userId: h.userId,
      name: h.name,
      username: h.username,
      avatar: h.avatar,
      role: h.role as any,
      roleStatus: h.roleStatus,
      assignedBy: `${h.hiredByUserId} (${h.hiredByName})`,
      assignedAt: h.assignedAt,
      removedBy: h.removedBy,
      removedAt: h.removedAt,
      permissions: h.permissions,
      parentUserId: h.parentUserId,
      parentRole: h.parentRole,
      hiredByUserId: h.hiredByUserId,
      hierarchyPath: h.hierarchyPath
    }));
}

// =========================================================================
// HIERARCHY ENDPOINTS
// =========================================================================

// 9.1 Hierarchy Roles Matrix & Permissions Specification
app.get("/api/hierarchy/roles-matrix", (req, res) => {
  res.json({
    success: true,
    hierarchyOrder: [
      { level: 1, role: 'OWNER', title: 'Supreme Owner', hiringScope: 'All Roles', panel: 'Owner Panel' },
      { level: 2, role: 'MANAGER', title: 'Operations Manager', hiringScope: 'Super Admin, BD Admin, Agency, Coin Seller', panel: 'Manager Panel' },
      { level: 3, role: 'SUPER ADMIN', title: 'Super Admin Moderator', hiringScope: 'BD Admin, Agency, Coin Seller', panel: 'Super Admin Panel' },
      { level: 4, role: 'BD ADMIN', title: 'Business Development Admin', hiringScope: 'Agency', panel: 'BD Admin Panel' },
      { level: 5, role: 'AGENCY', title: 'Agency Guild Leader', hiringScope: 'Host', panel: 'Agency Panel' },
      { level: 6, role: 'COIN SELLER', title: 'Authorized Coin Seller', hiringScope: 'NONE (Recharges All Users)', panel: 'Coin Seller Panel' },
      { level: 7, role: 'HOST', title: 'Broadcaster Host', hiringScope: 'NONE (Video/Party Streams)', panel: 'Host Studio' },
      { level: 8, role: 'USER', title: 'Community Member', hiringScope: 'NONE', panel: 'User Profile' }
    ],
    hiringMatrix: HIRING_PERMISSIONS_MATRIX,
    rolePermissionsMap: ROLE_PERMISSIONS_MAP,
    permissionsMap: ROLE_PERMISSIONS_MAP
  });
});

// 9.1b Get Hierarchy Profile & Panel Access for Specified User
app.get("/api/hierarchy/profile/:userId", (req, res) => {
  const { userId } = req.params;
  const rawId = String(userId).trim();
  const digitsOnly = rawId.replace(/\D/g, '');
  const paddedId = digitsOnly ? digitsOnly.padStart(7, '0') : rawId;
  
  const user = serverUsers[rawId] || serverUsers[paddedId] || serverUsers[`USR-${digitsOnly}`] || (digitsOnly ? serverUsers[digitsOnly] : null) || Object.values(serverUsers).find(
    u => u.id === rawId || u.id === paddedId || u.username.toLowerCase() === rawId.toLowerCase()
  );

  if (!user) {
    return res.status(404).json({ success: false, error: "User not found in system database." });
  }

  const normRole = normalizeRole(user.role || 'USER');
  const hierRel = serverHierarchyRelationships.find(h => h.userId === user.id || h.userId === rawId || h.userId === paddedId);

  const canAccessPanel = normRole !== 'USER' && normRole !== 'NONE' || Boolean((user as any).roleTag) || Boolean((user as any).assignedRoleTag);
  const panelType = normRole === 'OWNER' ? 'OWNER'
    : normRole === 'MANAGER' ? 'MANAGER'
    : normRole === 'SUPER ADMIN' ? 'SUPER_ADMIN'
    : normRole === 'ADMIN' ? 'ADMIN'
    : normRole === 'OFFICIAL' ? 'OFFICIAL'
    : normRole === 'BD ADMIN' || normRole === 'SUPER BD' ? 'ADMIN_BD'
    : normRole === 'AGENCY' ? 'AGENCY'
    : normRole === 'COIN SELLER' ? 'COIN_SELLER'
    : normRole === 'HOST' ? 'HOST'
    : 'USER';

  const allowedHiring = HIRING_PERMISSIONS_MATRIX[normRole] || [];
  const permissions = ROLE_PERMISSIONS_MAP[normRole] || [];

  res.json({
    success: true,
    userId: user.id,
    user,
    role: normRole,
    roleSlug: normRole.replace(/\s+/g, '_'),
    roleTag: (user as any).roleTag || normRole,
    roleStatus: (user as any).roleStatus || 'Active',
    avatarFrameId: user.avatarFrameId,
    canAccessPanel,
    panelType,
    allowedHiring,
    permissions,
    hierarchyRelationship: hierRel || null
  });
});

// 9.2 Hierarchy Tree & Subordinates for Current Operator
app.get("/api/hierarchy/tree", (req, res) => {
  const { operatorId, operatorRole, operatorUser } = resolveOperator(req);
  const includeRemoved = req.query.includeRemoved === 'true';

  const visibleNodes = getVisibleSubordinates(operatorId, operatorRole, includeRemoved);

  // Group by direct vs descendant
  const directSubordinates = visibleNodes.filter(n => n.parentUserId === operatorId || n.hiredByUserId === operatorId);
  const descendantSubordinates = visibleNodes.filter(n => n.parentUserId !== operatorId && n.hiredByUserId !== operatorId);

  res.json({
    success: true,
    operatorId,
    operatorRole,
    operatorName: operatorUser?.name || 'Authorized Operator',
    canHireRoles: HIRING_PERMISSIONS_MATRIX[normalizeRole(operatorRole)] || [],
    allowedHiringRoles: HIRING_PERMISSIONS_MATRIX[normalizeRole(operatorRole)] || [],
    totalVisibleCount: visibleNodes.length,
    directCount: directSubordinates.length,
    descendantCount: descendantSubordinates.length,
    subordinates: visibleNodes,
    directSubordinates,
    descendants: descendantSubordinates
  });
});

// 9.3 Get Direct Subordinates and Sub-accounts list
app.get("/api/hierarchy/subordinates", (req, res) => {
  const { operatorId, operatorRole } = resolveOperator(req);
  const filterRole = req.query.role ? normalizeRole(String(req.query.role)) : null;
  const includeRemoved = req.query.includeRemoved === 'true';

  let visible = getVisibleSubordinates(operatorId, operatorRole, includeRemoved);
  if (filterRole) {
    visible = visible.filter(n => normalizeRole(n.role) === filterRole);
  }

  res.json({
    success: true,
    operatorId,
    operatorRole,
    count: visible.length,
    subordinates: visible
  });
});

// 9.4 Real Backend Hierarchy Hiring & Role Assignment
app.post("/api/hierarchy/hire", (req, res) => {
  const { operatorId, operatorRole, operatorUser } = resolveOperator(req);
  const { targetUserId, notes = '' } = req.body;
  const role = req.body.role || req.body.targetRole;

  if ((!targetUserId && !req.body.isNewAccount && !req.body.autoGenerateId) || !role) {
    return res.status(400).json({ success: false, error: "role and target user information are required." });
  }

  const normTargetRole = normalizeRole(role) as DiyoRole;
  const normOpRole = normalizeRole(operatorRole);

  // Security Constraint: Users cannot assign themselves a role or promote themselves
  if (operatorId === targetUserId) {
    return res.status(403).json({ success: false, error: "SECURITY VIOLATION: Users cannot hire, promote, or assign roles to themselves." });
  }

  // Security Constraint: Master Owner role cannot be modified or hired via this endpoint
  if (targetUserId === '0000001') {
    return res.status(403).json({ success: false, error: "SECURITY VIOLATION: Master Owner (0000001) cannot be modified." });
  }

  // Security Constraint: Check if operator has hiring rights for the requested role
  if (!canOperatorHireRole(normOpRole, normTargetRole)) {
    return res.status(403).json({
      success: false,
      error: `PERMISSION DENIED: Role "${normOpRole}" is not authorized to hire "${normTargetRole}". Allowed hiring roles: ${(HIRING_PERMISSIONS_MATRIX[normOpRole] || []).join(', ') || 'None'}.`
    });
  }

  const isNew = Boolean(
    req.body.isNewAccount === true ||
    req.body.isNewStaff === true ||
    req.body.autoGenerateId === true ||
    targetUserId === 'NEW' ||
    targetUserId === 'AUTO'
  );

  let targetUser: any = null;
  let effectiveUserId = '';
  const rawId = String(targetUserId || '').trim();
  const digitsOnly = rawId.replace(/\D/g, '');
  const paddedId = digitsOnly ? digitsOnly.padStart(7, '0') : rawId;

  if (isNew) {
    effectiveUserId = getNextSequentialUserId();
    const candidateName = req.body.targetName || req.body.name || `Staff ${effectiveUserId}`;
    const candidateUsername = (req.body.targetUsername || req.body.username || `staff_${effectiveUserId}`).toLowerCase().replace(/[^a-z0-9_]/g, '');
    targetUser = {
      id: effectiveUserId,
      name: candidateName,
      username: candidateUsername,
      email: req.body.email || `${candidateUsername}@diyolive.io`,
      phone: req.body.phone || '',
      coinBalance: Number(req.body.allocation || req.body.coinBalance || 100000),
      diamondBalance: 0,
      boltBalance: 0,
      vipLevel: 1,
      userLevel: 10,
      role: 'USER',
      roleStatus: 'Active',
      status: 'Active',
      avatar: req.body.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      countryCode: 'NP',
      countryFlag: '🇳🇵',
      countryName: 'Nepal',
      bio: `Official DIYO LIVE ${normTargetRole}`,
      joinedDate: new Date().toISOString().split('T')[0],
      registrationDate: new Date().toISOString().split('T')[0],
      lastActive: 'Just now',
      lastLogin: 'Just now',
      totalSpentCoins: 0,
      totalRechargedUSD: 0
    };
    serverUsers[effectiveUserId] = targetUser;
  } else {
    // Robust target user lookup (supports raw ID, padded 7-digit ID, USR- prefix, or username)
    targetUser = serverUsers[rawId] || serverUsers[paddedId] || serverUsers[`USR-${digitsOnly}`] || (digitsOnly ? serverUsers[digitsOnly] : null) || Object.values(serverUsers).find(
      u => u.id === rawId || 
           u.id === paddedId || 
           u.username.toLowerCase() === rawId.toLowerCase() ||
           (req.body.targetUsername && u.username.toLowerCase() === String(req.body.targetUsername).toLowerCase())
    );

    // IMPORTANT: Hiring an existing user must NEVER create a new/fake account.
    // Only the explicit NEW/AUTO flow above is allowed to allocate a new User ID.
    if (!targetUser) {
      return res.status(404).json({
        success: false,
        error: `Target user \"${rawId}\" was not found in the database. Search and select a real existing user, or use the New Staff flow.`
      });
    }
    effectiveUserId = targetUser.id;
  }

  // Find operator's relationship node to compute hierarchy path
  let operatorRel = serverHierarchyRelationships.find(h => h.userId === operatorId);
  const parentPath = operatorRel ? operatorRel.hierarchyPath : (normOpRole === 'OWNER' ? '0000001' : `${operatorId}`);
  const newHierarchyPath = `${parentPath}/${effectiveUserId}`;

  // Update target user role & status in serverUsers
  const roleSlug = normTargetRole.replace(/\s+/g, '_');
  targetUser.role = roleSlug;
  (targetUser as any).roleStatus = 'Active';
  (targetUser as any).roleTag = normTargetRole;

  // Role-specific entitlements and capabilities
  if (normTargetRole === 'MANAGER') {
    targetUser.avatarFrameId = 'FRM-ROLE-MANAGER';
  } else if (normTargetRole === 'SUPER ADMIN') {
    targetUser.avatarFrameId = 'FRM-ROLE-SUPER-ADMIN';
  } else if (normTargetRole === 'BD ADMIN' || normTargetRole === 'SUPER BD') {
    targetUser.role = 'ADMIN_BD';
    (targetUser as any).secondaryRole = 'BD_ADMIN';
    targetUser.avatarFrameId = 'FRM-ROLE-BD-ADMIN';
  } else if (normTargetRole === 'COIN SELLER') {
    targetUser.role = 'COIN_SELLER';
    targetUser.avatarFrameId = 'FRM-ROLE-COIN-SELLER';
    (targetUser as any).coinSeller = true;
    
    // Register in serverCoinSellers
    const sellerIdx = serverCoinSellers.findIndex(s => s.id === effectiveUserId || s.userId === effectiveUserId);
    const sellerEntry = {
      id: effectiveUserId,
      userId: effectiveUserId,
      name: targetUser.name,
      username: targetUser.username,
      phone: targetUser.phone || '',
      email: targetUser.email || '',
      status: 'Active',
      coinBalance: targetUser.coinBalance || 500000,
      soldCoinsTotal: 0,
      totalSoldUSD: 0,
      commissionRate: 10,
      allocatedPool: 1000000,
      availableToSell: targetUser.coinBalance || 500000,
      assignedBy: operatorId
    };
    if (sellerIdx >= 0) {
      serverCoinSellers[sellerIdx] = { ...serverCoinSellers[sellerIdx], ...sellerEntry };
    } else {
      serverCoinSellers.unshift(sellerEntry);
    }
  } else if (normTargetRole === 'AGENCY') {
    targetUser.role = 'AGENCY';
    targetUser.avatarFrameId = 'FRM-ROLE-AGENCY';
    (targetUser as any).isAgency = true;

    // Register in serverAgencies
    const agencyIdx = serverAgencies.findIndex(a => a.ownerId === effectiveUserId || a.id === `AG-${effectiveUserId}`);
    const agencyEntry = {
      id: `AG-${effectiveUserId.replace(/\D/g, '').slice(-4) || '101'}`,
      name: `${targetUser.name}'s Agency`,
      ownerId: effectiveUserId,
      ownerName: targetUser.name,
      logo: targetUser.avatar || 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=150',
      verified: true,
      commissionRate: 15,
      totalHosts: 0,
      description: `Official Agency managed by ${targetUser.name}`
    };
    if (agencyIdx >= 0) {
      serverAgencies[agencyIdx] = { ...serverAgencies[agencyIdx], ...agencyEntry };
    } else {
      serverAgencies.unshift(agencyEntry);
    }
  } else if (normTargetRole === 'HOST') {
    targetUser.role = 'HOST';
    (targetUser as any).isHost = true;
    (targetUser as any).hostTag = 'NORMAL';
    (targetUser as any).verificationStatus = 'Verified Host';
  }

  // Sync to canonical 7-digit key in serverUsers
  serverUsers[effectiveUserId] = targetUser;
  releaseReservedUserId(effectiveUserId);
  saveUsersStore();

  // Sync active user sessions
  Object.entries(serverActiveSessions).forEach(([sessUserId, session]) => {
    if (sessUserId === effectiveUserId || sessUserId === rawId || sessUserId === paddedId) {
      (session as any).role = targetUser.role;
      (session as any).roleTag = normTargetRole;
    }
  });

  // Check if target already has an existing relationship
  const existingIdx = serverHierarchyRelationships.findIndex(h => h.userId === effectiveUserId || h.userId === rawId || h.userId === paddedId);
  const previousRole = existingIdx >= 0 ? serverHierarchyRelationships[existingIdx].role : (targetUser.role || 'USER');

  const newRelationship: ServerHierarchyRelationship = {
    id: existingIdx >= 0 ? serverHierarchyRelationships[existingIdx].id : `HIER-${Date.now().toString().slice(-4)}`,
    userId: effectiveUserId,
    name: targetUser.name,
    username: targetUser.username,
    avatar: targetUser.avatar || '',
    role: normTargetRole,
    roleTag: normTargetRole,
    hiredByUserId: operatorId,
    hiredByName: operatorUser?.name || `${normOpRole} #${operatorId}`,
    hiredByRole: normOpRole,
    parentUserId: operatorId,
    parentRole: normOpRole,
    hierarchyPath: newHierarchyPath,
    assignedAt: new Date().toISOString(),
    assignedBy: `${operatorId} (${operatorUser?.name || normOpRole})`,
    roleStatus: 'Active',
    activeStatus: 'ACTIVE',
    permissions: ROLE_PERMISSIONS_MAP[normTargetRole] || [],
    notes: notes || `Hired as ${normTargetRole} by ${normOpRole} #${operatorId}`
  };

  if (existingIdx >= 0) {
    serverHierarchyRelationships[existingIdx] = newRelationship;
  } else {
    serverHierarchyRelationships.unshift(newRelationship);
  }

  // Create Audit Entry
  const auditEntry: HierarchyAuditEntry = {
    id: `AUD-${Date.now().toString().slice(-5)}`,
    action: 'HIRE',
    operatorId,
    operatorName: operatorUser?.name || `${normOpRole} #${operatorId}`,
    operatorRole: normOpRole,
    targetUserId: effectiveUserId,
    targetName: targetUser.name,
    targetRole: normTargetRole,
    previousRole: String(previousRole),
    timestamp: new Date().toISOString(),
    details: `${normOpRole} #${operatorId} successfully hired #${effectiveUserId} (${targetUser.name}) as ${normTargetRole}. Hierarchy path: ${newHierarchyPath}`
  };
  serverHierarchyAudit.unshift(auditEntry);

  syncLegacyHiredRoles();
  saveUsersStore();
  saveHierarchyStore();

  res.json({
    success: true,
    message: `🎉 Success! User #${effectiveUserId} (${targetUser.name}) has been officially hired as ${normTargetRole}. Access to ${normTargetRole} panel and privileges is now active on their profile!`,
    newUserId: effectiveUserId,
    relationship: newRelationship,
    user: targetUser,
    auditEntry
  });
});

// 9.5 Remove Role & Terminate Hierarchy Position
app.post("/api/hierarchy/remove", (req, res) => {
  const { operatorId, operatorRole, operatorUser } = resolveOperator(req);
  const { targetUserId, reason = 'Administrative role revocation' } = req.body;

  if (!targetUserId) {
    return res.status(400).json({ success: false, error: "targetUserId is required." });
  }

  if (targetUserId === '0000001') {
    return res.status(403).json({ success: false, error: "SECURITY VIOLATION: Master Owner (0000001) cannot be removed." });
  }

  // Operator cannot remove themselves
  if (operatorId === targetUserId) {
    return res.status(403).json({ success: false, error: "SECURITY VIOLATION: You cannot remove your own role." });
  }

  // Tag Protection Directive: Only Supreme Owner (0000001) can revoke/remove an official role tag
  const isOwnerOperator = 
    operatorId === '0000001' || 
    operatorId === 'OWNER-001' || 
    operatorRole === 'OWNER' || 
    req.headers['x-owner-email'] === 'salamstarhotel@gmail.com';

  if (!isOwnerOperator) {
    return res.status(403).json({
      success: false,
      error: "PERMISSION DENIED: Only the Supreme Platform Owner (0000001) has the authority to revoke or remove an assigned official tag."
    });
  }

  // Check if target is within operator's reporting hierarchy
  if (!isUserInHierarchy(operatorId, operatorRole, targetUserId)) {
    return res.status(403).json({
      success: false,
      error: `PERMISSION DENIED: You can only manage accounts within your authorized reporting hierarchy. User #${targetUserId} is not in your hierarchy branch.`
    });
  }

  const targetRelIdx = serverHierarchyRelationships.findIndex(h => h.userId === targetUserId);
  const targetUser = serverUsers[targetUserId];
  const oldRole = targetRelIdx >= 0 ? serverHierarchyRelationships[targetRelIdx].role : (targetUser?.role || 'STAFF');

  if (targetRelIdx >= 0) {
    serverHierarchyRelationships[targetRelIdx].roleStatus = 'Removed';
    serverHierarchyRelationships[targetRelIdx].removedAt = new Date().toISOString();
    serverHierarchyRelationships[targetRelIdx].removedBy = `${operatorId} (${operatorUser?.name || operatorRole})`;
    serverHierarchyRelationships[targetRelIdx].permissions = [];
  }

  // Restore user in serverUsers to normal USER
  if (targetUser) {
    targetUser.role = 'USER';
    (targetUser as any).roleStatus = 'NONE';
    delete (targetUser as any).roleTag;
    saveUsersStore();
  }

  // Record in Audit Ledger
  const auditEntry: HierarchyAuditEntry = {
    id: `AUD-${Date.now().toString().slice(-5)}`,
    action: 'REMOVE',
    operatorId,
    operatorName: operatorUser?.name || `${operatorRole} #${operatorId}`,
    operatorRole,
    targetUserId,
    targetName: targetUser?.name || `User #${targetUserId}`,
    targetRole: 'USER',
    previousRole: oldRole,
    timestamp: new Date().toISOString(),
    details: `Role ${oldRole} removed by ${operatorRole} #${operatorId}. Reason: ${reason}. User restored to normal USER status.`
  };
  serverHierarchyAudit.unshift(auditEntry);

  syncLegacyHiredRoles();

  res.json({
    success: true,
    message: `🗑️ Success: Role ${oldRole} for user #${targetUserId} revoked. Account restored to normal USER status.`,
    targetUserId,
    auditEntry
  });
});

// 9.6 Change Subordinate Role (Within authorized scope)
app.post("/api/hierarchy/change-role", (req, res) => {
  const { operatorId, operatorRole, operatorUser } = resolveOperator(req);
  const { targetUserId, newRole, reason = 'Role reassignment' } = req.body;

  if (!targetUserId || !newRole) {
    return res.status(400).json({ success: false, error: "targetUserId and newRole required." });
  }

  const normTargetRole = normalizeRole(newRole) as DiyoRole;
  const normOpRole = normalizeRole(operatorRole);

  if (targetUserId === '0000001') {
    return res.status(403).json({ success: false, error: "Cannot modify Master Owner (0000001)." });
  }

  if (operatorId === targetUserId) {
    return res.status(403).json({ success: false, error: "You cannot change your own role." });
  }

  if (!canOperatorHireRole(normOpRole, normTargetRole)) {
    return res.status(403).json({
      success: false,
      error: `PERMISSION DENIED: Role "${normOpRole}" is not authorized to reassign to "${normTargetRole}".`
    });
  }

  if (!isUserInHierarchy(operatorId, operatorRole, targetUserId)) {
    return res.status(403).json({
      success: false,
      error: `PERMISSION DENIED: User #${targetUserId} is outside your authorized reporting hierarchy.`
    });
  }

  const targetUser = serverUsers[targetUserId];
  if (!targetUser) {
    return res.status(404).json({ success: false, error: `User #${targetUserId} not found.` });
  }

  const relIdx = serverHierarchyRelationships.findIndex(h => h.userId === targetUserId);
  const oldRole = relIdx >= 0 ? serverHierarchyRelationships[relIdx].role : targetUser.role;

  targetUser.role = normTargetRole.replace(/\s+/g, '_');
  (targetUser as any).roleStatus = 'Active';
  (targetUser as any).roleTag = normTargetRole;
  (targetUser as any).assignedRoleTag = normTargetRole;

  if (relIdx >= 0) {
    serverHierarchyRelationships[relIdx].role = normTargetRole;
    serverHierarchyRelationships[relIdx].roleTag = normTargetRole;
    serverHierarchyRelationships[relIdx].roleStatus = 'Active';
    serverHierarchyRelationships[relIdx].assignedAt = new Date().toISOString();
    serverHierarchyRelationships[relIdx].permissions = ROLE_PERMISSIONS_MAP[normTargetRole] || [];
  }

  saveUsersStore();

  const auditEntry: HierarchyAuditEntry = {
    id: `AUD-${Date.now().toString().slice(-5)}`,
    action: 'CHANGE_ROLE',
    operatorId,
    operatorName: operatorUser?.name || `${normOpRole} #${operatorId}`,
    operatorRole: normOpRole,
    targetUserId,
    targetName: targetUser.name,
    targetRole: normTargetRole,
    previousRole: oldRole,
    timestamp: new Date().toISOString(),
    details: `Role updated from ${oldRole} to ${normTargetRole} by ${normOpRole} #${operatorId}. Reason: ${reason}`
  };
  serverHierarchyAudit.unshift(auditEntry);

  syncLegacyHiredRoles();

  res.json({
    success: true,
    message: `🔄 Role successfully updated: User #${targetUserId} is now ${normTargetRole}.`,
    user: targetUser,
    auditEntry
  });
});

// 9.7 Super Admin Frame Distribution Guard (Restricted to Frames 1 to 5 ONLY)
app.post("/api/hierarchy/super-admin/distribute-frame", (req, res) => {
  const { operatorId, operatorRole, operatorUser } = resolveOperator(req);
  const { targetUserId, frameId } = req.body;

  const normOpRole = normalizeRole(operatorRole);

  if (normOpRole !== 'SUPER ADMIN' && normOpRole !== 'OWNER' && operatorId !== '0000001') {
    return res.status(403).json({ success: false, error: "Only Super Admin and Owner can distribute frames." });
  }

  if (!targetUserId || !frameId) {
    return res.status(400).json({ success: false, error: "targetUserId and frameId required." });
  }

  // Super Admin frame restrictions: ONLY Frames 1 to 5
  if (normOpRole === 'SUPER ADMIN') {
    const allowedSuperAdminFrames = [
      '1', '2', '3', '4', '5',
      'FRAME-01', 'FRAME-02', 'FRAME-03', 'FRAME-04', 'FRAME-05',
      'FRM-01', 'FRM-02', 'FRM-03', 'FRM-04', 'FRM-05'
    ];

    const cleanFrame = String(frameId).trim().toUpperCase();
    if (!allowedSuperAdminFrames.includes(cleanFrame)) {
      return res.status(403).json({
        success: false,
        error: `RESTRICTION VIOLATION: Super Admin is strictly restricted to distributing Frames 1 to 5 only. Requested frame "${frameId}" is not allowed.`
      });
    }
  }

  const targetUser = serverUsers[targetUserId];
  if (!targetUser) {
    return res.status(404).json({ success: false, error: `User #${targetUserId} not found.` });
  }

  targetUser.avatarFrameId = frameId;

  const auditEntry: HierarchyAuditEntry = {
    id: `AUD-${Date.now().toString().slice(-5)}`,
    action: 'DISTRIBUTE_FRAME',
    operatorId,
    operatorName: operatorUser?.name || `${normOpRole} #${operatorId}`,
    operatorRole: normOpRole,
    targetUserId,
    targetName: targetUser.name,
    targetRole: targetUser.role,
    timestamp: new Date().toISOString(),
    details: `${normOpRole} #${operatorId} distributed avatar frame "${frameId}" to User #${targetUserId} (${targetUser.name})`
  };
  serverHierarchyAudit.unshift(auditEntry);
  saveUsersStore();
  saveHierarchyStore();

  res.json({
    success: true,
    message: `✨ Frame "${frameId}" successfully assigned to user #${targetUserId}.`,
    user: targetUser,
    auditEntry
  });
});

// 9.8 Hierarchy Ban / Unban Guard (Super Admin, Manager, Owner)
app.post("/api/hierarchy/ban-unban", (req, res) => {
  const { operatorId, operatorRole, operatorUser } = resolveOperator(req);
  const { targetUserId, action, reason = 'Violating community guidelines' } = req.body;

  const normOpRole = normalizeRole(operatorRole);

  const allowedRoles = ['OWNER', 'MANAGER', 'SUPER ADMIN'];
  if (!allowedRoles.includes(normOpRole) && operatorId !== '0000001') {
    return res.status(403).json({
      success: false,
      error: `PERMISSION DENIED: Role "${normOpRole}" does not have moderation authority to ban or unban accounts.`
    });
  }

  if (!targetUserId || !action || !['BAN', 'UNBAN'].includes(action)) {
    return res.status(400).json({ success: false, error: "targetUserId and action ('BAN' | 'UNBAN') required." });
  }

  if (targetUserId === '0000001') {
    return res.status(403).json({ success: false, error: "SECURITY VIOLATION: Master Owner cannot be banned." });
  }

  const targetUser = serverUsers[targetUserId];
  if (!targetUser) {
    return res.status(404).json({ success: false, error: `User #${targetUserId} not found.` });
  }

  targetUser.status = action === 'BAN' ? 'Banned' : 'Active';
  if (action === 'BAN') {
    (targetUser as any).banReason = reason;
    (targetUser as any).bannedBy = `${normOpRole} #${operatorId}`;
    (targetUser as any).bannedAt = new Date().toISOString();
  } else {
    delete (targetUser as any).banReason;
    (targetUser as any).unbannedBy = `${normOpRole} #${operatorId}`;
    (targetUser as any).unbannedAt = new Date().toISOString();
  }

  const auditEntry: HierarchyAuditEntry = {
    id: `AUD-${Date.now().toString().slice(-5)}`,
    action: 'BAN_UNBAN',
    operatorId,
    operatorName: operatorUser?.name || `${normOpRole} #${operatorId}`,
    operatorRole: normOpRole,
    targetUserId,
    targetName: targetUser.name,
    targetRole: targetUser.role,
    timestamp: new Date().toISOString(),
    details: `${action === 'BAN' ? 'Banned' : 'Unbanned'} User #${targetUserId} (${targetUser.name}) by ${normOpRole} #${operatorId}. Reason: ${reason}`
  };
  serverHierarchyAudit.unshift(auditEntry);

  res.json({
    success: true,
    message: `Account #${targetUserId} (${targetUser.name}) is now ${action === 'BAN' ? 'BANNED' : 'ACTIVE'}.`,
    user: targetUser,
    auditEntry
  });
});

// 9.9 Hierarchy Audit Trail Log
app.get("/api/hierarchy/audit", (req, res) => {
  const { operatorId, operatorRole } = resolveOperator(req);
  const normOpRole = normalizeRole(operatorRole);

  // Owners see all; subordinates see audit entries involving their hierarchy
  let logs = serverHierarchyAudit;
  if (normOpRole !== 'OWNER' && operatorId !== '0000001') {
    logs = serverHierarchyAudit.filter(a => 
      a.operatorId === operatorId || 
      a.targetUserId === operatorId || 
      isUserInHierarchy(operatorId, operatorRole, a.targetUserId)
    );
  }

  res.json({
    success: true,
    count: logs.length,
    auditLogs: logs,
    logs: logs
  });
});

// 9.10 Legacy Hired List (Synced with Hierarchy)
app.get("/api/owner/hiring/list", (req, res) => {
  const { operatorId, operatorRole } = resolveOperator(req);
  const visible = getVisibleSubordinates(operatorId, operatorRole, true);

  res.json({
    success: true,
    count: visible.length,
    hiredUsers: visible.map(h => ({
      id: h.id,
      userId: h.userId,
      name: h.name,
      username: h.username,
      avatar: h.avatar,
      role: h.role as any,
      roleStatus: h.roleStatus,
      assignedBy: `${h.hiredByUserId} (${h.hiredByName})`,
      assignedAt: h.assignedAt,
      removedBy: h.removedBy,
      removedAt: h.removedAt,
      permissions: h.permissions,
      parentUserId: h.parentUserId,
      parentRole: h.parentRole,
      hiredByUserId: h.hiredByUserId,
      hierarchyPath: h.hierarchyPath
    }))
  });
});

// 9.11 User Search for Hiring (Preserves Dossier info)
app.get("/api/owner/hiring/search", (req, res) => {
  const { query } = req.query;
  const cleanQuery = query ? String(query).trim().toLowerCase() : '';

  if (!cleanQuery) {
    return res.status(400).json({ success: false, error: "Search query required (e.g. 7-digit User ID or username)" });
  }

  const matches = Object.values(serverUsers).filter(u => 
    u.id.toLowerCase() === cleanQuery ||
    u.username.toLowerCase().includes(cleanQuery) ||
    u.name.toLowerCase().includes(cleanQuery)
  ).map(u => ({
    id: u.id,
    name: u.name,
    username: u.username,
    avatar: u.avatar,
    role: u.role || 'USER',
    roleStatus: (u as any).roleStatus || (u.role === 'USER' ? 'NONE' : 'Active'),
    userLevel: u.userLevel ?? 0,
    vipLevel: u.vipLevel ?? 0,
    coinBalance: u.coinBalance ?? 0,
    diamondBalance: u.diamondBalance ?? 0,
    status: u.status,
    countryName: u.countryName,
    countryFlag: u.countryFlag
  }));

  res.json({
    success: true,
    count: matches.length,
    results: matches
  });
});

// 9.12 Legacy Assign (Routes through Hierarchy validation)
app.post("/api/owner/hiring/assign", (req, res) => {
  const { operatorId, operatorRole, operatorUser } = resolveOperator(req);
  const { targetUserId, role } = req.body;

  if (!targetUserId || !role) {
    return res.status(400).json({ success: false, error: "targetUserId and role required." });
  }

  const normTargetRole = normalizeRole(role) as DiyoRole;
  const normOpRole = normalizeRole(operatorRole);

  if (!canOperatorHireRole(normOpRole, normTargetRole)) {
    return res.status(403).json({
      success: false,
      error: `ACCESS DENIED: Role "${normOpRole}" is not authorized to hire "${normTargetRole}".`
    });
  }

  if (targetUserId === '0000001') {
    return res.status(400).json({ success: false, error: "Cannot change role of Master Owner (0000001)." });
  }

  const user = serverUsers[targetUserId];
  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID #${targetUserId} not found in database.` });
  }

  const opRel = serverHierarchyRelationships.find(h => h.userId === operatorId);
  const parentPath = opRel ? opRel.hierarchyPath : (normOpRole === 'OWNER' ? '0000001' : `${operatorId}`);
  const newHierarchyPath = `${parentPath}/${targetUserId}`;

  user.role = normTargetRole.replace(/\s+/g, '_');
  (user as any).roleStatus = 'Active';
  (user as any).roleTag = normTargetRole;

  const existingIdx = serverHierarchyRelationships.findIndex(h => h.userId === targetUserId);
  const hireRecord: ServerHierarchyRelationship = {
    id: existingIdx >= 0 ? serverHierarchyRelationships[existingIdx].id : `HIER-${Date.now().toString().slice(-4)}`,
    userId: targetUserId,
    name: user.name,
    username: user.username,
    avatar: user.avatar || '',
    role: normTargetRole,
    roleTag: normTargetRole,
    hiredByUserId: operatorId,
    hiredByName: operatorUser?.name || `${normOpRole} #${operatorId}`,
    hiredByRole: normOpRole,
    parentUserId: operatorId,
    parentRole: normOpRole,
    hierarchyPath: newHierarchyPath,
    assignedBy: `${operatorId} (${operatorUser?.name || normOpRole})`,
    assignedAt: new Date().toISOString(),
    roleStatus: 'Active',
    activeStatus: 'ACTIVE',
    permissions: ROLE_PERMISSIONS_MAP[normTargetRole] || []
  };

  if (existingIdx >= 0) {
    serverHierarchyRelationships[existingIdx] = hireRecord;
  } else {
    serverHierarchyRelationships.unshift(hireRecord);
  }

  serverHierarchyAudit.unshift({
    id: `AUD-${Date.now().toString().slice(-5)}`,
    action: 'HIRE',
    operatorId,
    operatorName: operatorUser?.name || `${normOpRole} #${operatorId}`,
    operatorRole: normOpRole,
    targetUserId,
    targetName: user.name,
    targetRole: normTargetRole,
    timestamp: new Date().toISOString(),
    details: `${normOpRole} #${operatorId} hired #${targetUserId} as ${normTargetRole}`
  });

  syncLegacyHiredRoles();
  saveUsersStore();
  saveHierarchyStore();

  res.json({
    success: true,
    message: `🎉 Success! User #${targetUserId} (${user.name}) hired as ${normTargetRole}.`,
    hiredRole: hireRecord,
    user
  });
});

// 9.13 Legacy Change Role
app.post("/api/owner/hiring/change-role", (req, res) => {
  const { operatorId, operatorRole, operatorUser } = resolveOperator(req);
  const { targetUserId, newRole } = req.body;

  if (!targetUserId || !newRole) {
    return res.status(400).json({ success: false, error: "targetUserId and newRole required." });
  }

  const normTargetRole = normalizeRole(newRole) as DiyoRole;
  const normOpRole = normalizeRole(operatorRole);

  if (!canOperatorHireRole(normOpRole, normTargetRole)) {
    return res.status(403).json({ success: false, error: `Role ${normOpRole} cannot reassign to ${normTargetRole}.` });
  }

  if (targetUserId === '0000001') {
    return res.status(400).json({ success: false, error: "Cannot change role of Master Owner (0000001)." });
  }

  const user = serverUsers[targetUserId];
  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID #${targetUserId} not found.` });
  }

  user.role = normTargetRole.replace(/\s+/g, '_');
  (user as any).roleStatus = 'Active';
  (user as any).roleTag = normTargetRole;

  const existingIdx = serverHierarchyRelationships.findIndex(h => h.userId === targetUserId);
  if (existingIdx >= 0) {
    serverHierarchyRelationships[existingIdx].role = normTargetRole;
    serverHierarchyRelationships[existingIdx].roleTag = normTargetRole;
    serverHierarchyRelationships[existingIdx].roleStatus = 'Active';
    serverHierarchyRelationships[existingIdx].assignedAt = new Date().toISOString();
    serverHierarchyRelationships[existingIdx].permissions = ROLE_PERMISSIONS_MAP[normTargetRole] || [];
  }

  syncLegacyHiredRoles();
  saveUsersStore();
  saveHierarchyStore();

  res.json({
    success: true,
    message: `🔄 Role updated! User #${targetUserId} (${user.name}) is now ${normTargetRole}.`,
    user,
    hiredRole: existingIdx >= 0 ? serverHierarchyRelationships[existingIdx] : null
  });
});

// 9.14 Legacy Remove Role
app.post("/api/owner/hiring/remove", (req, res) => {
  const { operatorId, operatorRole } = resolveOperator(req);
  const { targetUserId } = req.body;

  if (!targetUserId) {
    return res.status(400).json({ success: false, error: "targetUserId required." });
  }

  if (targetUserId === '0000001') {
    return res.status(400).json({ success: false, error: "Cannot remove Master Owner (0000001)." });
  }

  if (!isUserInHierarchy(operatorId, operatorRole, targetUserId)) {
    return res.status(403).json({ success: false, error: "You can only remove accounts within your reporting hierarchy." });
  }

  const user = serverUsers[targetUserId];
  if (user) {
    user.role = 'USER';
    (user as any).roleStatus = 'NONE';
    delete (user as any).roleTag;
  }

  const existingIdx = serverHierarchyRelationships.findIndex(h => h.userId === targetUserId);
  if (existingIdx >= 0) {
    serverHierarchyRelationships[existingIdx].roleStatus = 'Removed';
    serverHierarchyRelationships[existingIdx].removedBy = `${operatorId} (${operatorRole})`;
    serverHierarchyRelationships[existingIdx].removedAt = new Date().toISOString();
    serverHierarchyRelationships[existingIdx].permissions = [];
  }

  syncLegacyHiredRoles();
  saveUsersStore();
  saveHierarchyStore();

  res.json({
    success: true,
    message: `🗑️ Role removed successfully for user #${targetUserId}. Restored to normal USER.`,
    user
  });
});

// =========================================================================
// 10. APP-WIDE HOME BANNERS (BACKEND PERSISTED & GLOBAL BY DEFAULT)
// =========================================================================
export interface ServerBanner {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  link?: string;
  badge?: string;
  targetCountry?: string; // 'GLOBAL' or country code 'NP', 'IN', 'BD', etc.
  active: boolean;
  createdAt: string;
  updatedAt?: string;
}

// Persistent banners store - strictly real owner banners only
let serverBanners: ServerBanner[] = safeLoadJson<ServerBanner[]>(BANNERS_STORE_FILE, []);
if (!Array.isArray(serverBanners)) {
  serverBanners = [
    {
      id: 'BNR-OFFICIAL-1',
      title: 'DIYO LIVE Grand Festival 2026',
      subtitle: 'Broadcast, Win Royal Rewards & Celebrate Worldwide',
      imageUrl: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=1200&auto=format&fit=crop&q=80',
      link: '#',
      badge: 'OFFICIAL EVENT',
      targetCountry: 'GLOBAL',
      active: true,
      createdAt: new Date().toISOString()
    },
    {
      id: 'BNR-OFFICIAL-2',
      title: 'Royal VIP Star Crown Gala',
      subtitle: 'Top Streamers & Gifting Champions Daily Leaderboard',
      imageUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=1200&auto=format&fit=crop&q=80',
      link: '#',
      badge: 'VIP SPOTLIGHT',
      targetCountry: 'GLOBAL',
      active: true,
      createdAt: new Date().toISOString()
    }
  ];
  saveBannersStore();
}

// App-wide global banners endpoint
app.get("/api/banners", (req, res) => {
  const { country, all } = req.query;
  if (all === 'true') {
    return res.json({ success: true, banners: serverBanners });
  }

  // Banners are ALWAYS broadcast globally across the entire app
  const activeBanners = serverBanners.filter(b => {
    if (!b.active) return false;
    if (!b.targetCountry || b.targetCountry === 'GLOBAL' || b.targetCountry === 'ALL') return true;
    if (country && (b.targetCountry.toUpperCase() === String(country).toUpperCase())) return true;
    return true; // Global broadcast to all users
  });
  res.json({
    success: true,
    banners: activeBanners
  });
});

app.post("/api/banners/save", (req, res) => {
  const payload = req.body?.banner || req.body || {};
  const id = payload.id;
  const title = payload.title;
  const subtitle = payload.subtitle || '';
  const imageUrl = payload.imageUrl || payload.image;
  const link = payload.link || '#';
  const active = payload.active !== undefined ? payload.active : true;
  const badge = payload.badge || 'GLOBAL PROMO';
  const targetCountry = (payload.targetCountry || 'GLOBAL').toUpperCase();

  const isOwnerOrManager = 
    verifyOwnerAuth(req) || 
    req.headers['x-role'] === 'OWNER' || 
    req.headers['x-user-role'] === 'OWNER' || 
    req.headers['x-role'] === 'MANAGER' || 
    req.headers['x-role'] === 'SUPER_ADMIN' ||
    req.body?.role === 'OWNER' ||
    req.headers['x-owner-id'] === '0000001' ||
    req.headers['x-owner-email'] === 'salamstarhotel@gmail.com';

  if (!isOwnerOrManager) {
    const operatorRole = req.headers['x-operator-role'] || req.headers['x-role'] || req.body?.operatorRole;
    if (operatorRole !== 'OWNER' && operatorRole !== 'MANAGER' && operatorRole !== 'SUPER_ADMIN') {
      return res.status(403).json({ success: false, error: "Only Owner or Manager can modify banners." });
    }
  }

  if (!title || !imageUrl) {
    return res.status(400).json({ success: false, error: "Title and Image URL are required." });
  }

  let banner = serverBanners.find(b => b.id === id);
  if (banner) {
    banner.title = title;
    banner.subtitle = subtitle;
    banner.imageUrl = imageUrl;
    banner.link = link;
    banner.active = active;
    banner.badge = badge;
    banner.targetCountry = targetCountry;
    banner.updatedAt = new Date().toISOString();
  } else {
    banner = {
      id: id || `BNR-${Date.now().toString().slice(-4)}`,
      title,
      subtitle,
      imageUrl,
      link,
      badge,
      targetCountry,
      active,
      createdAt: new Date().toISOString()
    };
    serverBanners.unshift(banner);
  }

  saveBannersStore();

  res.json({ success: true, message: "Banner saved successfully to backend storage.", banner, banners: serverBanners });
});

app.post("/api/banners/toggle", (req, res) => {
  const isOwnerOrManager = 
    verifyOwnerAuth(req) || 
    req.headers['x-role'] === 'OWNER' || 
    req.headers['x-user-role'] === 'OWNER' || 
    req.headers['x-role'] === 'MANAGER' || 
    req.headers['x-role'] === 'SUPER_ADMIN' ||
    req.body?.role === 'OWNER' ||
    req.headers['x-owner-id'] === '0000001' ||
    req.headers['x-owner-email'] === 'salamstarhotel@gmail.com';

  if (!isOwnerOrManager) {
    return res.status(403).json({ success: false, error: "Only Owner can toggle banners." });
  }
  const id = req.body.id || req.body.bannerId;
  const banner = serverBanners.find(b => b.id === id);
  if (!banner) return res.status(404).json({ success: false, error: "Banner not found." });
  banner.active = !banner.active;
  banner.updatedAt = new Date().toISOString();
  saveBannersStore();
  res.json({ success: true, message: `Banner is now ${banner.active ? 'Active' : 'Inactive'}.`, banner, banners: serverBanners });
});

app.post("/api/banners/delete", (req, res) => {
  const isOwnerOrManager = 
    verifyOwnerAuth(req) || 
    req.headers['x-role'] === 'OWNER' || 
    req.headers['x-user-role'] === 'OWNER' || 
    req.headers['x-role'] === 'MANAGER' || 
    req.headers['x-role'] === 'SUPER_ADMIN' ||
    req.body?.role === 'OWNER' ||
    req.headers['x-owner-id'] === '0000001' ||
    req.headers['x-owner-email'] === 'salamstarhotel@gmail.com';

  if (!isOwnerOrManager) {
    return res.status(403).json({ success: false, error: "Only Owner can delete banners." });
  }
  const id = req.body.id || req.body.bannerId;
  serverBanners = serverBanners.filter(b => b.id !== id);
  saveBannersStore();
  res.json({ success: true, message: "Banner deleted permanently.", banners: serverBanners });
});

// =========================================================================
// 11. REAL-TIME LIVE ROOMS SYNCHRONIZATION (VIDEO LIVE & PARTY LIVE)
// =========================================================================
export interface ServerLiveRoom {
  roomId: string;
  roomName: string;
  liveType: 'VIDEO' | 'PARTY';
  hostId: string;
  hostName: string;
  hostAvatar: string;
  coverImage: string;
  status: 'LIVE' | 'ENDED';
  viewersCount: number;
  onlineCount: number;
  country: string;
  countryFlag: string;
  startedAt: string;
  tag?: string;
  isRecommended?: boolean;
}

// Strictly real active broadcast rooms only (no fake demo rooms)
let serverLiveRooms: ServerLiveRoom[] = safeLoadJson<ServerLiveRoom[]>(LIVE_ROOMS_STORE_FILE, []);

// Filter out any legacy demo seeded rooms on initialization
serverLiveRooms = (serverLiveRooms || []).filter(r => r.roomId !== 'LIVE-V-101' && r.roomId !== 'LIVE-V-102' && r.roomId !== 'LIVE-P-201');
saveLiveRoomsStore();

// =========================================================================
// 12. HOST LIVE-TIME REWARD SYSTEM (VIDEO: 70,000 COINS, PARTY: 50,000 COINS)
// =========================================================================
export interface HostRewardRecord {
  transactionId: string;
  hostId: string;
  hostName: string;
  roomId: string;
  liveType: 'VIDEO' | 'PARTY';
  requiredTime: string; // '2 Hours'
  requiredSeconds: number; // 7200
  rewardCoins: number; // 70000 for Video, 50000 for Party
  completionTime: string;
  durationSeconds: number;
  status: 'REWARDED';
}

export interface LiveSessionState {
  roomId: string;
  liveType: 'VIDEO' | 'PARTY';
  hostId: string;
  hostName: string;
  startedAt: string;
  lastHeartbeatAt: string;
  verifiedSeconds: number;
  rewardClaimed: boolean;
  rewardTransactionId?: string;
  rewardedAt?: string;
}

let serverHostRewards: HostRewardRecord[] = [];
// Strictly real live sessions and rooms only
let serverLiveSessions: Record<string, LiveSessionState> = {};

app.get("/api/live-rooms", (req, res) => {
  const { type, country } = req.query;
  // Always filter ONLY real, actively LIVE rooms and sync with real-time user database
  let activeRooms = serverLiveRooms
    .filter(r => r.status === 'LIVE')
    .map(r => {
      const realUser = serverUsers[r.hostId];
      const hostName = realUser?.name || r.hostName || 'Star Broadcaster';
      const hostAvatar = realUser?.avatar || r.hostAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400';
      const countryName = realUser?.countryName || r.country || 'Nepal';
      const countryFlag = realUser?.countryFlag || r.countryFlag || '🇳🇵';
      const roomName = r.roomName || `${hostName}'s ${r.liveType === 'PARTY' ? 'Party Lounge' : 'Live Stream'}`;
      const cover = r.coverImage || hostAvatar;

      return {
        ...r,
        id: r.roomId,
        roomId: r.roomId,
        name: roomName,
        title: roomName,
        roomName: roomName,
        hostId: r.hostId,
        hostName: hostName,
        hostAvatar: hostAvatar,
        ownerId: r.hostId,
        ownerName: hostName,
        cover: cover,
        coverImage: cover,
        roomImage: cover,
        country: countryName,
        countryFlag: countryFlag,
        viewersCount: Math.max(1, r.viewersCount || r.onlineCount || 1),
        onlineCount: Math.max(1, r.onlineCount || r.viewersCount || 1),
        status: 'LIVE',
        roomStatus: 'Active'
      };
    });

  if (type === 'VIDEO') {
    activeRooms = activeRooms.filter(r => r.liveType === 'VIDEO');
  } else if (type === 'PARTY') {
    activeRooms = activeRooms.filter(r => r.liveType === 'PARTY');
  }

  if (country && country !== 'GLOBAL' && country !== 'ALL') {
    const cStr = String(country).toLowerCase();
    activeRooms = activeRooms.filter(r => 
      r.country?.toLowerCase() === cStr ||
      r.countryFlag === country ||
      (cStr === 'np' && (r.country?.toLowerCase() === 'nepal' || r.countryFlag === '🇳🇵')) ||
      (cStr === 'in' && (r.country?.toLowerCase() === 'india' || r.countryFlag === '🇮🇳')) ||
      (cStr === 'bd' && (r.country?.toLowerCase() === 'bangladesh' || r.countryFlag === '🇧🇩')) ||
      (cStr === 'pk' && (r.country?.toLowerCase() === 'pakistan' || r.countryFlag === '🇵🇰')) ||
      (cStr === 'ph' && (r.country?.toLowerCase() === 'philippines' || r.countryFlag === '🇵🇭')) ||
      (cStr === 'ae' && (r.country?.toLowerCase().includes('emirates') || r.countryFlag === '🇦🇪')) ||
      (cStr === 'us' && (r.country?.toLowerCase().includes('states') || r.countryFlag === '🇺🇸'))
    );
  }

  res.json({ success: true, rooms: activeRooms, count: activeRooms.length });
});

app.post("/api/live-rooms/start", (req, res) => {
  const { roomName, liveType = 'VIDEO', hostId, hostName, hostAvatar, coverImage, tag, country, countryFlag, role } = req.body;
  if (!hostId) {
    return res.status(400).json({ success: false, error: "Host ID required to start live stream." });
  }

  // 1. HOST LIVE AUTHORIZATION & AGENCY GOVERNANCE
  // Direct Directive: As soon as a user is given any official tag or role by the Owner
  // (Owner, Manager, Super Admin, Admin, Official, BD, Agency, Coin Seller, Host, or has roleTag/assignedRoleTag/hostTag),
  // their Video Live and Party Live broadcasting is IMMEDIATELY unlocked and ACTIVE!
  const realUser = serverUsers[hostId];
  const operatorRole = req.headers['x-role'] || role || realUser?.role || 'USER';
  const hasOfficialTagOrRole = 
    hostId === '0000001' || 
    hostId === '0000011' || 
    hostId === 'OWNER-001' || 
    Boolean(realUser?.roleTag) || 
    Boolean(realUser?.hostTag) || 
    Boolean((realUser as any)?.assignedRoleTag) || 
    (realUser?.role && realUser.role !== 'USER' && realUser.role !== 'NONE') ||
    (operatorRole && operatorRole !== 'USER' && operatorRole !== 'NONE');

  const membership = serverAgencyMemberships[hostId] || (realUser as any)?.agencyMembership;
  const hasApprovedAgency = hasOfficialTagOrRole || (membership && (membership.status === 'APPROVED' || membership.status === 'VERIFIED_JOINED'));

  if (!hasApprovedAgency) {
    return res.status(403).json({
      success: false,
      error: "You must receive an official tag from the Owner or join an approved Agency to start Live.",
      requiresAgency: true
    });
  }

  const resolvedHostName = realUser?.name || hostName || 'Star Broadcaster';
  const resolvedHostAvatar = realUser?.avatar || hostAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400';
  const resolvedCountry = realUser?.countryName || country || 'Nepal';
  const resolvedCountryFlag = realUser?.countryFlag || countryFlag || '🇳🇵';
  const finalLiveType = (liveType === 'PARTY' || String(liveType).toLowerCase() === 'party') ? 'PARTY' : 'VIDEO';

  // Keep Party Live room state synchronized with the real active live room.
  if (finalLiveType === 'PARTY') {
    serverPartyRoom = null;
  }

  // Check if this host already has an active room; if so, update and return it
  const existingIdx = serverLiveRooms.findIndex(r => r.hostId === hostId && r.status === 'LIVE');
  if (existingIdx !== -1) {
    serverLiveRooms[existingIdx].liveType = finalLiveType;
    serverLiveRooms[existingIdx].hostName = resolvedHostName;
    serverLiveRooms[existingIdx].hostAvatar = resolvedHostAvatar;
    serverLiveRooms[existingIdx].roomName = roomName || `${resolvedHostName}'s ${finalLiveType === 'PARTY' ? 'Party Lounge' : 'Live Stream'}`;
    serverLiveRooms[existingIdx].coverImage = coverImage || resolvedHostAvatar;
    serverLiveRooms[existingIdx].status = 'LIVE';
    serverLiveRooms[existingIdx].startedAt = new Date().toISOString();
    serverLiveRooms[existingIdx].tag = tag || (finalLiveType === 'PARTY' ? 'Crown Party' : 'Music');
    serverLiveRooms[existingIdx].country = resolvedCountry;
    serverLiveRooms[existingIdx].countryFlag = resolvedCountryFlag;
    saveLiveRoomsStore();

    const normalizedRoom = {
      ...serverLiveRooms[existingIdx],
      id: serverLiveRooms[existingIdx].roomId,
      name: serverLiveRooms[existingIdx].roomName,
      title: serverLiveRooms[existingIdx].roomName,
      cover: serverLiveRooms[existingIdx].coverImage,
      roomImage: serverLiveRooms[existingIdx].coverImage,
      roomStatus: 'Active'
    };

    return res.json({
      success: true,
      message: `🎉 ${finalLiveType} Room is now LIVE! Broadcasted to Home Page.`,
      room: normalizedRoom
    });
  }

  const prefix = finalLiveType === 'PARTY' ? 'LIVE-P' : 'LIVE-V';
  const newRoomId = `${prefix}-${Date.now().toString().slice(-4)}`;
  const newRoom: ServerLiveRoom = {
    roomId: newRoomId,
    roomName: roomName || `${resolvedHostName}'s ${finalLiveType === 'PARTY' ? 'Party Room' : 'Live Stream'}`,
    liveType: finalLiveType,
    hostId,
    hostName: resolvedHostName,
    hostAvatar: resolvedHostAvatar,
    coverImage: coverImage || resolvedHostAvatar || 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800',
    status: 'LIVE',
    viewersCount: 1,
    onlineCount: 1,
    country: resolvedCountry,
    countryFlag: resolvedCountryFlag,
    startedAt: new Date().toISOString(),
    tag: tag || (finalLiveType === 'PARTY' ? 'Crown Party' : 'Video Live'),
    isRecommended: false
  };

  serverLiveRooms.unshift(newRoom);
  saveLiveRoomsStore();

  // Register live session for Host Live-Time Rewards
  serverLiveSessions[newRoomId] = {
    roomId: newRoomId,
    liveType: newRoom.liveType,
    hostId,
    hostName: newRoom.hostName,
    startedAt: newRoom.startedAt,
    lastHeartbeatAt: new Date().toISOString(),
    verifiedSeconds: 0,
    rewardClaimed: false
  };

  const normalizedNewRoom = {
    ...newRoom,
    id: newRoom.roomId,
    name: newRoom.roomName,
    title: newRoom.roomName,
    cover: newRoom.coverImage,
    roomImage: newRoom.coverImage,
    roomStatus: 'Active'
  };

  res.json({
    success: true,
    message: `🎉 ${newRoom.liveType} Room is now LIVE! Broadcasted to Home Page.`,
    room: normalizedNewRoom
  });
});

app.post("/api/live-rooms/join", (req, res) => {
  const { roomId, userId } = req.body;
  const room = serverLiveRooms.find(r => (r.roomId === roomId || (r as any).id === roomId) && r.status === 'LIVE');
  if (!room) {
    return res.status(404).json({ success: false, error: "Live room not found or has ended." });
  }
  room.viewersCount += 1;
  room.onlineCount += 1;
  saveLiveRoomsStore();
  res.json({ success: true, room });
});

app.post("/api/live-rooms/leave", (req, res) => {
  const { roomId, userId } = req.body;
  const room = serverLiveRooms.find(r => r.roomId === roomId || (r as any).id === roomId);
  if (room && room.status === 'LIVE') {
    room.viewersCount = Math.max(1, room.viewersCount - 1);
    room.onlineCount = Math.max(1, room.onlineCount - 1);
    saveLiveRoomsStore();
  }
  res.json({ success: true, room });
});

app.post("/api/live-rooms/end", (req, res) => {
  const { roomId, hostId } = req.body;
  const roomIndex = serverLiveRooms.findIndex(r => 
    (roomId && (r.roomId === roomId || (r as any).id === roomId)) ||
    (hostId && r.hostId === hostId)
  );

  if (roomIndex === -1) {
    return res.status(404).json({ success: false, error: "Live room not found or already ended." });
  }

  const endedRoom = serverLiveRooms[roomIndex];
  endedRoom.status = 'ENDED';
  serverLiveRooms.splice(roomIndex, 1);
  saveLiveRoomsStore();

  // Check live session status on end
  const session = serverLiveSessions[roomId];
  let rewardEarned = false;
  if (session) {
    const verifiedSeconds = Math.max(0, Math.floor((Date.now() - new Date(session.startedAt).getTime()) / 1000));
    session.verifiedSeconds = verifiedSeconds;
    // If completed required 2 hours (7200s) and not rewarded yet
    if (verifiedSeconds >= 7200 && !session.rewardClaimed) {
      session.rewardClaimed = true;
      const completionTime = new Date().toISOString();
      const txId = `TX-REWARD-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const rewardCoins = session.liveType === 'VIDEO' ? 70000 : 50000;
      session.rewardTransactionId = txId;
      session.rewardedAt = completionTime;
      const rewardRecord: HostRewardRecord = {
        transactionId: txId,
        hostId: session.hostId,
        hostName: session.hostName,
        roomId: session.roomId,
        liveType: session.liveType,
        requiredTime: '2 Hours',
        requiredSeconds: 7200,
        rewardCoins,
        completionTime,
        durationSeconds: verifiedSeconds,
        status: 'REWARDED'
      };
      serverHostRewards.unshift(rewardRecord);
      const hostUser = serverUsers[session.hostId];
      if (hostUser) {
        hostUser.coinBalance = (hostUser.coinBalance || 0) + rewardCoins;
      }
      serverWalletTransactions.unshift({
        id: txId,
        userId: session.hostId,
        userName: session.hostName,
        type: 'HOST_LIVE_REWARD',
        currency: 'COINS',
        amount: rewardCoins,
        status: 'COMPLETED',
        timestamp: completionTime,
        notes: `Verified 2-Hour ${session.liveType} Live Host Reward (+${rewardCoins.toLocaleString()} Coins)`
      } as any);
      rewardEarned = true;
    }
  }

  res.json({
    success: true,
    message: `Live room ${roomId} has ended and was removed from the Home Page.`,
    room: endedRoom,
    rewardEarned,
    session: session ? {
      verifiedSeconds: session.verifiedSeconds,
      rewardClaimed: session.rewardClaimed,
      rewardTransactionId: session.rewardTransactionId
    } : null
  });
});

// =========================================================================
// 12.1 LIVE STREAM REAL-TIME VIDEO FEED RELAY
// Broadcasts and synchronizes video frames between Host and Viewers
// =========================================================================
export interface LiveStreamFrameRecord {
  roomId: string;
  hostId: string;
  hostName: string;
  isCameraOn: boolean;
  frameData?: string; // compressed base64 frame thumbnail
  filter?: string;
  audioLevel?: number;
  updatedAt: number;
  coHostId?: string;
  coHostName?: string;
  coHostFrameData?: string;
  isCoHostCameraOn?: boolean;
  coHostUpdatedAt?: number;
}

const serverLiveStreamFrames: Record<string, LiveStreamFrameRecord> = {
  'LIVE-V-101': {
    roomId: 'LIVE-V-101',
    hostId: 'HST-901',
    hostName: 'DJ Anya',
    isCameraOn: true,
    filter: 'beauty',
    audioLevel: 68,
    updatedAt: Date.now()
  },
  'LIVE-V-102': {
    roomId: 'LIVE-V-102',
    hostId: 'HST-902',
    hostName: 'Kavita Roy',
    isCameraOn: true,
    filter: 'cyber',
    audioLevel: 55,
    updatedAt: Date.now()
  }
};

app.post("/api/live-stream/frame", (req, res) => {
  const { roomId, hostId, hostName, isCameraOn = true, frameData, filter, audioLevel, coHostId, coHostName, coHostFrameData, isCoHostCameraOn } = req.body;
  if (!roomId) {
    return res.status(400).json({ success: false, error: "roomId is required" });
  }
  const existing = serverLiveStreamFrames[roomId] || {} as Partial<LiveStreamFrameRecord>;
  serverLiveStreamFrames[roomId] = {
    roomId,
    hostId: hostId || existing.hostId || '',
    hostName: hostName || existing.hostName || '',
    isCameraOn: isCameraOn !== undefined ? Boolean(isCameraOn) : (existing.isCameraOn ?? true),
    frameData: frameData || existing.frameData,
    filter: filter || existing.filter || 'normal',
    audioLevel: typeof audioLevel === 'number' ? audioLevel : (existing.audioLevel ?? 30),
    updatedAt: Date.now(),
    coHostId: coHostId !== undefined ? coHostId : existing.coHostId,
    coHostName: coHostName !== undefined ? coHostName : existing.coHostName,
    coHostFrameData: coHostFrameData !== undefined ? coHostFrameData : existing.coHostFrameData,
    isCoHostCameraOn: isCoHostCameraOn !== undefined ? Boolean(isCoHostCameraOn) : existing.isCoHostCameraOn,
    coHostUpdatedAt: coHostFrameData ? Date.now() : existing.coHostUpdatedAt
  };
  res.json({ success: true, frame: serverLiveStreamFrames[roomId] });
});

app.post("/api/live-stream/cohost-frame", (req, res) => {
  const { roomId, coHostId, coHostName, coHostFrameData, isCoHostCameraOn = true } = req.body;
  if (!roomId || !coHostId) {
    return res.status(400).json({ success: false, error: "roomId and coHostId are required" });
  }
  if (!serverLiveStreamFrames[roomId]) {
    serverLiveStreamFrames[roomId] = {
      roomId,
      hostId: '',
      hostName: '',
      isCameraOn: true,
      updatedAt: Date.now()
    };
  }
  serverLiveStreamFrames[roomId].coHostId = coHostId;
  serverLiveStreamFrames[roomId].coHostName = coHostName || 'Co-Host';
  serverLiveStreamFrames[roomId].coHostFrameData = coHostFrameData;
  serverLiveStreamFrames[roomId].isCoHostCameraOn = Boolean(isCoHostCameraOn);
  serverLiveStreamFrames[roomId].coHostUpdatedAt = Date.now();
  res.json({ success: true, frame: serverLiveStreamFrames[roomId] });
});

app.get("/api/live-stream/frame/:roomId", (req, res) => {
  const { roomId } = req.params;
  const frame = serverLiveStreamFrames[roomId];
  if (!frame) {
    return res.json({ success: false, active: false });
  }
  const isRecent = (Date.now() - frame.updatedAt) < 60000;
  const isCoHostRecent = frame.coHostUpdatedAt ? (Date.now() - frame.coHostUpdatedAt) < 45000 : false;
  res.json({
    success: true,
    active: true,
    frame: {
      ...frame,
      isFresh: isRecent,
      isCoHostActive: isCoHostRecent && Boolean(frame.coHostId)
    }
  });
});

// Helper for formatting time
function formatDurationHMS(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

// -------------------------------------------------------------------------
// Host Rewards: Heartbeat & Validation Check
// -------------------------------------------------------------------------
app.post("/api/host-rewards/heartbeat-and-check", (req, res) => {
  const { roomId, hostId } = req.body;
  if (!roomId || !hostId) {
    return res.status(400).json({ success: false, error: "roomId and hostId are required." });
  }

  let session = serverLiveSessions[roomId];
  if (!session) {
    // Check if room exists in serverLiveRooms
    const room = serverLiveRooms.find(r => r.roomId === roomId);
    if (room) {
      session = {
        roomId: room.roomId,
        liveType: room.liveType,
        hostId: room.hostId,
        hostName: room.hostName,
        startedAt: room.startedAt,
        lastHeartbeatAt: new Date().toISOString(),
        verifiedSeconds: Math.max(0, Math.floor((Date.now() - new Date(room.startedAt).getTime()) / 1000)),
        rewardClaimed: false
      };
      serverLiveSessions[roomId] = session;
    } else {
      return res.status(404).json({ success: false, error: `Live session not found for room ${roomId}` });
    }
  }

  // Security Check 1: Host identity verification
  if (session.hostId !== hostId) {
    return res.status(403).json({
      success: false,
      error: `Security Violation: Host ID mismatch. Session host is ${session.hostId}, requested by ${hostId}.`
    });
  }

  // Calculate verified continuous live duration on the backend using startedAt timestamp
  const now = Date.now();
  const startMs = new Date(session.startedAt).getTime();
  const verifiedSeconds = Math.max(0, Math.floor((now - startMs) / 1000));
  session.verifiedSeconds = verifiedSeconds;
  session.lastHeartbeatAt = new Date().toISOString();

  const requiredSeconds = 7200; // 2 continuous hours
  const rewardCoins = session.liveType === 'VIDEO' ? 70000 : 50000;

  let justRewarded = false;
  let rewardRecord: HostRewardRecord | null = null;

  // Verification & Credit: Only after reaching 2 continuous hours (7200s) and not already claimed
  if (verifiedSeconds >= requiredSeconds && !session.rewardClaimed) {
    session.rewardClaimed = true;
    const completionTime = new Date().toISOString();
    const txId = `TX-REWARD-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    session.rewardTransactionId = txId;
    session.rewardedAt = completionTime;

    rewardRecord = {
      transactionId: txId,
      hostId: session.hostId,
      hostName: session.hostName,
      roomId: session.roomId,
      liveType: session.liveType,
      requiredTime: '2 Hours',
      requiredSeconds,
      rewardCoins,
      completionTime,
      durationSeconds: verifiedSeconds,
      status: 'REWARDED'
    };

    serverHostRewards.unshift(rewardRecord);

    // Credit coins to Host in serverUsers
    const hostUser = serverUsers[session.hostId];
    if (hostUser) {
      hostUser.coinBalance = (hostUser.coinBalance || 0) + rewardCoins;
    }

    // Add transaction record to platform ledger
    serverWalletTransactions.unshift({
      id: txId,
      userId: session.hostId,
      userName: session.hostName,
      type: 'HOST_LIVE_REWARD',
      currency: 'COINS',
      amount: rewardCoins,
      status: 'COMPLETED',
      timestamp: completionTime,
      notes: `Verified 2-Hour ${session.liveType} Live Host Reward (+${rewardCoins.toLocaleString()} Coins)`
    } as any);

    justRewarded = true;
  }

  const liveTimeFormatted = formatDurationHMS(verifiedSeconds);
  const targetTimeFormatted = "02:00:00";
  const status = session.rewardClaimed ? "REWARDED" : "In Progress";

  res.json({
    success: true,
    roomId: session.roomId,
    liveType: session.liveType,
    hostId: session.hostId,
    hostName: session.hostName,
    verifiedSeconds,
    requiredSeconds,
    targetTimeFormatted,
    liveTimeFormatted,
    rewardCoins,
    status,
    rewardClaimed: session.rewardClaimed,
    rewardTransactionId: session.rewardTransactionId || null,
    justRewarded,
    rewardRecord,
    currentCoinBalance: serverUsers[session.hostId]?.coinBalance ?? null
  });
});

// -------------------------------------------------------------------------
// Host Rewards: Status check (read-only)
// -------------------------------------------------------------------------
app.get("/api/host-rewards/status", (req, res) => {
  const { roomId, hostId } = req.query;
  if (!roomId) {
    return res.status(400).json({ success: false, error: "roomId is required." });
  }
  let session = serverLiveSessions[roomId as string];
  if (!session) {
    const room = serverLiveRooms.find(r => r.roomId === roomId);
    if (room) {
      session = {
        roomId: room.roomId,
        liveType: room.liveType,
        hostId: room.hostId,
        hostName: room.hostName,
        startedAt: room.startedAt,
        lastHeartbeatAt: new Date().toISOString(),
        verifiedSeconds: Math.max(0, Math.floor((Date.now() - new Date(room.startedAt).getTime()) / 1000)),
        rewardClaimed: false
      };
      serverLiveSessions[roomId as string] = session;
    } else {
      return res.status(404).json({ success: false, error: `No active session for room ${roomId}` });
    }
  }

  const verifiedSeconds = Math.max(0, Math.floor((Date.now() - new Date(session.startedAt).getTime()) / 1000));
  const requiredSeconds = 7200;
  const rewardCoins = session.liveType === 'VIDEO' ? 70000 : 50000;

  res.json({
    success: true,
    roomId: session.roomId,
    liveType: session.liveType,
    hostId: session.hostId,
    hostName: session.hostName,
    verifiedSeconds,
    requiredSeconds,
    liveTimeFormatted: formatDurationHMS(verifiedSeconds),
    targetTimeFormatted: "02:00:00",
    rewardCoins,
    status: session.rewardClaimed ? "REWARDED" : "In Progress",
    rewardClaimed: session.rewardClaimed,
    rewardTransactionId: session.rewardTransactionId || null
  });
});

// -------------------------------------------------------------------------
// Host Rewards: History
// -------------------------------------------------------------------------
app.get("/api/host-rewards/history", (req, res) => {
  const { hostId } = req.query;
  const history = hostId
    ? serverHostRewards.filter(r => r.hostId === hostId)
    : serverHostRewards;
  res.json({ success: true, count: history.length, history });
});

// -------------------------------------------------------------------------
// Host Rewards: Backend Simulation for Automated Verification Testing
// -------------------------------------------------------------------------
app.post("/api/host-rewards/test-simulate-duration", (req, res) => {
  const { roomId, hostId, simulatedSeconds } = req.body;
  if (!roomId || !hostId || typeof simulatedSeconds !== 'number') {
    return res.status(400).json({ success: false, error: "roomId, hostId, and simulatedSeconds (number) are required." });
  }

  let session = serverLiveSessions[roomId];
  if (!session) {
    const room = serverLiveRooms.find(r => r.roomId === roomId);
    if (room) {
      session = {
        roomId: room.roomId,
        liveType: room.liveType,
        hostId: room.hostId,
        hostName: room.hostName,
        startedAt: room.startedAt,
        lastHeartbeatAt: new Date().toISOString(),
        verifiedSeconds: 0,
        rewardClaimed: false
      };
      serverLiveSessions[roomId] = session;
    } else {
      return res.status(404).json({ success: false, error: `Live session not found for room ${roomId}` });
    }
  }

  // Adjust start time to simulate verified duration
  session.startedAt = new Date(Date.now() - simulatedSeconds * 1000).toISOString();
  session.verifiedSeconds = simulatedSeconds;

  const requiredSeconds = 7200;
  const rewardCoins = session.liveType === 'VIDEO' ? 70000 : 50000;
  let justRewarded = false;
  let rewardRecord: HostRewardRecord | null = null;

  if (simulatedSeconds >= requiredSeconds && !session.rewardClaimed) {
    session.rewardClaimed = true;
    const completionTime = new Date().toISOString();
    const txId = `TX-REWARD-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    session.rewardTransactionId = txId;
    session.rewardedAt = completionTime;

    rewardRecord = {
      transactionId: txId,
      hostId: session.hostId,
      hostName: session.hostName,
      roomId: session.roomId,
      liveType: session.liveType,
      requiredTime: '2 Hours',
      requiredSeconds,
      rewardCoins,
      completionTime,
      durationSeconds: simulatedSeconds,
      status: 'REWARDED'
    };

    serverHostRewards.unshift(rewardRecord);
    const hostUser = serverUsers[session.hostId];
    if (hostUser) {
      hostUser.coinBalance = (hostUser.coinBalance || 0) + rewardCoins;
    }
    serverWalletTransactions.unshift({
      id: txId,
      userId: session.hostId,
      userName: session.hostName,
      type: 'HOST_LIVE_REWARD',
      currency: 'COINS',
      amount: rewardCoins,
      status: 'COMPLETED',
      timestamp: completionTime,
      notes: `Verified 2-Hour ${session.liveType} Live Host Reward (+${rewardCoins.toLocaleString()} Coins)`
    } as any);
    justRewarded = true;
  }

  res.json({
    success: true,
    message: `Simulated duration set to ${simulatedSeconds}s (${formatDurationHMS(simulatedSeconds)}).`,
    roomId: session.roomId,
    liveType: session.liveType,
    verifiedSeconds: session.verifiedSeconds,
    requiredSeconds,
    liveTimeFormatted: formatDurationHMS(session.verifiedSeconds),
    targetTimeFormatted: "02:00:00",
    rewardCoins,
    status: session.rewardClaimed ? "REWARDED" : "In Progress",
    rewardClaimed: session.rewardClaimed,
    justRewarded,
    rewardRecord,
    currentCoinBalance: serverUsers[session.hostId]?.coinBalance ?? null
  });
});


async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`SR LIVE Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
