import React, { useState, useEffect } from 'react';
import { Navbar, MainNavTab } from './components/Navbar';
import { StreamPlayer } from './components/StreamPlayer';
import { LiveChat } from './components/LiveChat';
import { BroadcastStudio } from './components/BroadcastStudio';
import { MultiViewGrid } from './components/MultiViewGrid';
import { AudioRadioLounge } from './components/AudioRadioLounge';
import { ScheduleAndHighlights } from './components/ScheduleAndHighlights';
import { CustomStreamModal } from './components/CustomStreamModal';
import { ClipMakerModal } from './components/ClipMakerModal';
import { VideoAnalyzerModal } from './components/ai/VideoAnalyzerModal';
import { OwnerDashboard } from './components/owner/OwnerDashboard';
import { ProfileScreen } from './components/profile/ProfileScreen';
import { MomentsScreen } from './components/moments/MomentsScreen';
import { MessagesScreen } from './components/messages/MessagesScreen';
import { ChooseLiveTypeModal } from './components/live/ChooseLiveTypeModal';
import { ExploreScreen } from './components/explore/ExploreScreen';
import { VideoLiveScreen } from './components/live/VideoLiveScreen';
import { FloatingLiveMiniPlayer, MinimizedLiveSessionData } from './components/live/FloatingLiveMiniPlayer';
import { androidLiveStreamService } from './services/androidLiveStreamService';
import { PartyLiveScreen } from './components/party/PartyLiveScreen';
import { WalletScreen } from './components/wallet/WalletScreen';
import { BottomNavigation } from './components/navigation/BottomNavigation';
import { SRGameCenterHub } from './components/games/SRGameCenterHub';
import { SplashScreen } from './components/common/SplashScreen';
import { LoginSignupModal } from './components/auth/LoginSignupModal';
import { AuthScreen } from './components/auth/AuthScreen';
import { AgencyJoinRequiredModal } from './components/agency/AgencyJoinRequiredModal';
import { AgencyModal } from './components/profile/AgencyModal';

import { INITIAL_STREAMS, MOCK_SCHEDULE, MOCK_HIGHLIGHTS } from './data/mockStreams';
import { 
  MOCK_OWNER_STATS,
  MOCK_SUPER_ADMINS,
  MOCK_ADMINS,
  MOCK_MANAGERS,
  MOCK_AGENCIES,
  MOCK_HOSTS,
  MOCK_USERS,
  MOCK_LIVE_ROOMS,
  MOCK_GIFTS,
  MOCK_WALLET_TRANSACTIONS,
  MOCK_VIP_CONFIGS,
  MOCK_WITHDRAWALS,
  MOCK_REPORTS,
  MOCK_NOTIFICATIONS,
  MOCK_AUDIT_LOGS,
  MOCK_PLATFORM_SETTINGS,
  MOCK_COIN_SELLERS,
  MOCK_OWNER_TO_SELLER_TRANSACTIONS,
  MOCK_SELLER_TO_USER_TRANSACTIONS,
  MOCK_AVATAR_FRAMES,
  MOCK_PK_BATTLES,
  MOCK_CASINO_TRANSACTIONS
} from './data/mockOwnerData';
import { StreamChannel, StreamCategory, ScheduledEvent, VideoHighlight } from './types';
import { 
  UserRole,
  AdminAccount,
  ManagerAccount,
  AgencyAccount,
  UserAccount,
  LiveRoomAccount,
  GiftItem,
  WalletTransaction,
  VipTierConfig,
  WithdrawalRequest,
  ModerationReport,
  NotificationItem,
  AuditLogEntry,
  PlatformSettings,
  AgencyJoinRequest,
  OwnerDashboardStats,
  CoinSellerAccount,
  OwnerToSellerTransaction,
  CoinSellerTransaction,
  PartyLiveRoomSession,
  AvatarFrameItem,
  PkBattleItem,
  CasinoTestTransaction,
  PlatformWalletSettings
} from './types/ownerTypes';
import { 
  Flame, 
  Trophy, 
  Music, 
  Tv, 
  Gamepad2, 
  Radio, 
  Sparkles, 
  Cpu, 
  BellRing,
  Globe,
  Plus
} from 'lucide-react';
import { playSoundFX } from './utils/audioSynth';

export default function App() {
  const [activeTab, setActiveTab] = useState<MainNavTab>('browse');
  const [isChooseLiveTypeOpen, setIsChooseLiveTypeOpen] = useState<boolean>(false);
  const [channels, setChannels] = useState<StreamChannel[]>([]);
  const [selectedChannel, setSelectedChannel] = useState<StreamChannel>(INITIAL_STREAMS[0] || {} as any);
  const [selectedCategory, setSelectedCategory] = useState<StreamCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [schedule, setSchedule] = useState<ScheduledEvent[]>(MOCK_SCHEDULE);
  const [highlights, setHighlights] = useState<VideoHighlight[]>(MOCK_HIGHLIGHTS);
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [isLoginSignupOpen, setIsLoginSignupOpen] = useState<boolean>(false);
  const [minimizedLiveSession, setMinimizedLiveSession] = useState<MinimizedLiveSessionData | null>(null);

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    const session = localStorage.getItem('srlive_auth_session');
    return !!session;
  });

  // CURRENT LOGGED-IN VIP USER STATE
  const [currentUser, setCurrentUser] = useState<UserAccount>(() => {
    let baseUser: UserAccount = {
      id: '0000001',
      name: 'Salam Star Owner',
      username: 'salamstar_owner',
      email: 'salamstarhotel@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      role: 'OWNER',
      roleTag: 'OWNER',
      avatarFrameId: 'FRM-ROLE-OWNER',
      vipLevel: 10,
      svipLevel: 5,
      coinBalance: 500000000,
      diamondBalance: 1000000,
      boltBalance: 1000000,
      userLevel: 100,
      followersCount: 15400,
      followingCount: 12,
      countryCode: 'NP',
      countryFlag: '🇳🇵',
      countryName: 'Nepal',
      bio: '👑 DIYO LIVE Supreme Owner & Founder',
      totalRechargedUSD: 100000,
      totalSpentCoins: 0,
      status: 'ACTIVE',
      deviceType: 'Mobile App',
      registrationDate: '2025-01-01',
      lastLogin: 'Just now',
      joinedDate: '2025-01-01',
      lastActive: 'Just now'
    };
    if (typeof window !== 'undefined') {
      try {
        const session = localStorage.getItem('srlive_auth_session');
        if (session) {
          const parsed = JSON.parse(session);
          if (parsed && parsed.id) {
            const isOwner = parsed.email === 'salamstarhotel@gmail.com' || parsed.id === '0000001' || parsed.id === '0000011' || parsed.id === 'OWNER-001';
            const determinedRole = isOwner ? 'OWNER' : (parsed.role || 'USER');
            baseUser = { 
              ...parsed, 
              id: isOwner ? '0000001' : parsed.id,
              role: determinedRole, 
              roleTag: isOwner ? 'OWNER' : (parsed.roleTag || parsed.role),
              avatarFrameId: determinedRole === 'OWNER' ? 'FRM-ROLE-OWNER' : (parsed.avatarFrameId || undefined) 
            };
          }
        }
      } catch (e) {}
    }
    return baseUser;
  });

  // Keep session synced to localStorage and fetch persistent backend wallet balance
  useEffect(() => {
    if (isAuthenticated && currentUser) {
      try {
        localStorage.setItem('srlive_auth_session', JSON.stringify(currentUser));
      } catch (e) {}
    }
  }, [currentUser, isAuthenticated]);

  useEffect(() => {
    if (currentUser?.id) {
      fetch(`/api/wallet/${currentUser.id}`)
        .then(res => {
          if (!res.ok) throw new Error('Network response was not ok');
          return res.json();
        })
        .then(data => {
          if (data && data.success && data.wallet) {
            setCurrentUser(prev => ({
              ...prev,
              coinBalance: data.wallet.coinBalance,
              diamondBalance: data.wallet.diamondBalance
            }));
          }
        })
        .catch(e => {
          // Silent fallback for transient network errors
        });
    }
  }, [currentUser.id]);

  // OWNER PANEL & BACKEND STATE LAYER
  const [currentRole, setCurrentRole] = useState<UserRole>(() => (currentUser.role as UserRole) || 'USER');
  const [ownerStats, setOwnerStats] = useState<OwnerDashboardStats>(MOCK_OWNER_STATS);
  const [admins, setAdmins] = useState<AdminAccount[]>(MOCK_ADMINS);
  const [managers, setManagers] = useState<ManagerAccount[]>(MOCK_MANAGERS);
  const [agencies, setAgencies] = useState<AgencyAccount[]>(MOCK_AGENCIES);
  const [users, setUsers] = useState<UserAccount[]>(() => {
    try {
      const saved = localStorage.getItem('sr_live_persistent_users_registry_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return MOCK_USERS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('sr_live_persistent_users_registry_v1', JSON.stringify(users));
    } catch (e) {}
  }, [users]);
  const [liveRooms, setLiveRooms] = useState<LiveRoomAccount[]>([]);
  const [selectedLiveRoomId, setSelectedLiveRoomId] = useState<string>('LIVE-V-101');
  const [gifts, setGifts] = useState<GiftItem[]>(MOCK_GIFTS);
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(MOCK_WALLET_TRANSACTIONS);
  const [vipConfigs, setVipConfigs] = useState<VipTierConfig[]>(MOCK_VIP_CONFIGS);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(MOCK_WITHDRAWALS);
  const [reports, setReports] = useState<ModerationReport[]>(MOCK_REPORTS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(MOCK_NOTIFICATIONS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(MOCK_AUDIT_LOGS);
  const [platformSettings, setPlatformSettings] = useState<PlatformSettings>(MOCK_PLATFORM_SETTINGS);
  const [agencyJoinRequests, setAgencyJoinRequests] = useState<AgencyJoinRequest[]>([
    {
      id: 'AJR-1001',
      hostId: 'HST-5001',
      hostName: 'Rahul Sharma',
      hostAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      hostLevel: 25,
      hostVipLevel: 3,
      agencyId: 'AG-01',
      agencyName: 'Apex Royalty Guild',
      ownerId: 'MGR-301',
      status: 'PENDING',
      requestDate: '2026-09-08 10:15 UTC'
    }
  ]);
  const [platformBanners, setPlatformBanners] = useState<any[]>([]);

  const handleUpdatePlatformBanners = (updated: any[]) => {
    setPlatformBanners(updated);
    try {
      localStorage.setItem('diyo_home_banners_persistent', JSON.stringify(updated));
    } catch (e) {}
  };
  const [isAgencyJoinRequiredOpen, setIsAgencyJoinRequiredOpen] = useState<boolean>(false);
  const [isAgencyModalOpen, setIsAgencyModalOpen] = useState<boolean>(false);

  // Tag & Live Governance: Direct Directive
  // As soon as a user is given ANY official tag or role by the Owner
  // (Owner, Manager, Official, Super Admin, Admin, BD Admin, Agency, Coin Seller, Host, or has roleTag/assignedRoleTag/hostTag),
  // their Video Live and Party Live are IMMEDIATELY ACTIVE and UNLOCKED!
  const hasOfficialTagOrRole = Boolean(
    currentUser.id === '0000001' ||
    currentUser.id === 'OWNER-001' ||
    currentUser.roleTag ||
    currentUser.hostTag ||
    currentUser.assignedRoleTag ||
    (currentUser as any).roleStatus === 'Active' ||
    (currentUser.role && currentUser.role !== 'USER' && currentUser.role !== 'NONE')
  );

  const hasApprovedAgency = Boolean(
    hasOfficialTagOrRole ||
    currentUser.agencyMembership?.status === 'APPROVED' ||
    currentUser.agencyMembership?.status === 'VERIFIED_JOINED'
  );

  // Sync agency status from backend
  useEffect(() => {
    if (currentUser?.id) {
      fetch(`/api/agency/status/${currentUser.id}`)
        .then(res => res.json())
        .then(data => {
          if (data && data.success && data.membership) {
            setCurrentUser(prev => ({
              ...prev,
              agencyMembership: data.membership
            }));
          }
        })
        .catch(() => {});
    }
  }, [currentUser?.id]);

  const handleStartLiveStream = async (type: 'VIDEO' | 'PARTY', details?: { title?: string; tag?: string }) => {
    playSoundFX('live_start');
    const finalTag = details?.tag || (type === 'PARTY' ? 'Crown Party' : 'Video Live');
    const finalTitle = details?.title || `${currentUser.name}'s ${type === 'PARTY' ? 'Party Lounge' : 'Live Stream'}`;

    try {
      const res = await fetch('/api/live-rooms/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-role': currentUser.role || 'USER'
        },
        body: JSON.stringify({
          roomName: finalTitle,
          liveType: type,
          hostId: currentUser.id,
          hostName: currentUser.name,
          hostAvatar: currentUser.avatar,
          coverImage: currentUser.avatar,
          tag: finalTag,
          country: currentUser.countryName || currentUser.country || 'Nepal',
          countryFlag: currentUser.countryFlag || '🇳🇵',
          role: currentUser.role
        })
      });
      const data = await res.json();
      if (data && data.success && data.room) {
        setLiveRooms(prev => {
          const filtered = prev.filter(r => (r.roomId !== data.room.roomId && r.id !== data.room.id && r.hostId !== currentUser.id));
          return [data.room, ...filtered];
        });
        setSelectedLiveRoomId(data.room.roomId || data.room.id);
      } else {
        const optimisticId = `${type === 'PARTY' ? 'LIVE-P' : 'LIVE-V'}-${Date.now().toString().slice(-4)}`;
        const optimisticRoom: any = {
          roomId: optimisticId,
          id: optimisticId,
          roomName: finalTitle,
          liveType: type,
          hostId: currentUser.id,
          hostName: currentUser.name,
          hostAvatar: currentUser.avatar,
          coverImage: currentUser.avatar,
          status: 'LIVE',
          roomStatus: 'Active',
          viewersCount: 1,
          onlineCount: 1,
          country: currentUser.countryName || 'Nepal',
          countryFlag: currentUser.countryFlag || '🇳🇵',
          tag: finalTag,
          startedAt: new Date().toISOString()
        };
        setLiveRooms(prev => [optimisticRoom, ...prev.filter(r => r.hostId !== currentUser.id)]);
        setSelectedLiveRoomId(optimisticId);
      }
    } catch (e) {
      console.error('Error starting live room:', e);
      const fallbackId = type === 'PARTY' ? 'LIVE-P-201' : 'LIVE-V-101';
      setSelectedLiveRoomId(fallbackId);
    }

    if (type === 'PARTY') {
      setActiveTab('party_live');
    } else {
      setActiveTab('video_live');
    }
  };

  const handleCloseOrEndLive = async () => {
    const activeRoom = liveRooms.find((r: any) => (r.roomId === selectedLiveRoomId || r.id === selectedLiveRoomId));
    const isHost = activeRoom && (
      activeRoom.hostId === currentUser.id || 
      activeRoom.hostId === currentUser.username || 
      (currentUser.id && activeRoom.hostId?.includes(currentUser.id))
    );

    if (isHost && selectedLiveRoomId) {
      try {
        await fetch('/api/live-rooms/end', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            roomId: selectedLiveRoomId,
            hostId: currentUser.id
          })
        });
      } catch (e) {
        console.error('Error ending live room:', e);
      }
      setLiveRooms(prev => prev.filter(r => r.roomId !== selectedLiveRoomId && r.id !== selectedLiveRoomId && r.hostId !== currentUser.id));
    }

    setActiveTab('browse');

    fetch('/api/live-rooms')
      .then(r => r.json())
      .then(d => {
        if (d?.success && Array.isArray(d.rooms)) {
          setLiveRooms(d.rooms);
        }
      })
      .catch(() => {});
  };

  const handleAttemptGoLive = (liveType?: 'video' | 'party') => {
    playSoundFX('live_start');
    if (!hasApprovedAgency) {
      setIsAgencyJoinRequiredOpen(true);
      return;
    }
    if (liveType === 'video') {
      handleStartLiveStream('VIDEO');
    } else if (liveType === 'party') {
      handleStartLiveStream('PARTY');
    } else {
      setIsChooseLiveTypeOpen(true);
    }
  };

  // Real-time polling for live rooms to stay updated on home page
  useEffect(() => {
    const fetchRooms = () => {
      fetch('/api/live-rooms')
        .then(res => res.json())
        .then(data => {
          if (data?.success && Array.isArray(data.rooms)) {
            setLiveRooms(prev => {
              const myRoom = prev.find(r => r.hostId === currentUser.id && (r.status === 'LIVE' || !r.status));
              if (myRoom && !data.rooms.some((r: any) => r.hostId === currentUser.id)) {
                return [myRoom, ...data.rooms];
              }
              return data.rooms;
            });
          }
        })
        .catch(() => {});
    };
    fetchRooms(); // fetch immediately on mount
    const interval = setInterval(fetchRooms, 3000);
    return () => clearInterval(interval);
  }, [currentUser.id]);

  // COIN SELLERS & OWNER TEST WALLET (500M INITIAL)
  const [coinSellers, setCoinSellers] = useState<CoinSellerAccount[]>(MOCK_COIN_SELLERS);
  const [ownerTestCoinBalance, setOwnerTestCoinBalance] = useState<number>(500000000);
  const [ownerToSellerTxs, setOwnerToSellerTxs] = useState<OwnerToSellerTransaction[]>(MOCK_OWNER_TO_SELLER_TRANSACTIONS);
  const [sellerToUserTxs, setSellerToUserTxs] = useState<CoinSellerTransaction[]>(MOCK_SELLER_TO_USER_TRANSACTIONS);
  const [partyLiveRoom, setPartyLiveRoom] = useState<PartyLiveRoomSession | null>(null);
  const [avatarFrames, setAvatarFrames] = useState<AvatarFrameItem[]>(MOCK_AVATAR_FRAMES);
  const [pkBattles, setPkBattles] = useState<PkBattleItem[]>(MOCK_PK_BATTLES);
  const [casinoTransactions, setCasinoTransactions] = useState<CasinoTestTransaction[]>(MOCK_CASINO_TRANSACTIONS);

  // DIYO LIVE TEST WALLET PLATFORM SETTINGS & USER DIRECTORY
  const [walletSettings, setWalletSettings] = useState<PlatformWalletSettings>({
    userTransferEnabled: true,
    virtualExchangeEnabled: true,
    minTransferAmount: 100,
    maxTransferAmount: 10000000,
    coinToDiamondRate: 1.0,
    testModeNotice: "TEST MODE — Cash withdrawal is disabled. All transactions use virtual TEST COINS and virtual Diamonds only."
  });
  const [platformWalletUsers, setPlatformWalletUsers] = useState<any[]>(MOCK_USERS);

  // Sync with server if backend is active
  React.useEffect(() => {
    const fetchBackendState = async () => {
      try {
        const [walletRes, sellersRes, partyRes, settingsRes, usersRes, txsRes, bannersRes, roomsRes] = await Promise.all([
          fetch('/api/owner/test-wallet').then(r => r.json()).catch(() => null),
          fetch('/api/coin-sellers').then(r => r.json()).catch(() => null),
          fetch('/api/party-live/room').then(r => r.json()).catch(() => null),
          fetch('/api/wallet/settings').then(r => r.json()).catch(() => null),
          fetch('/api/wallet/users').then(r => r.json()).catch(() => null),
          fetch('/api/wallet/transactions').then(r => r.json()).catch(() => null),
          fetch('/api/banners').then(r => r.json()).catch(() => null),
          fetch('/api/live-rooms').then(r => r.json()).catch(() => null)
        ]);
        if (bannersRes?.success && Array.isArray(bannersRes.banners)) {
          setPlatformBanners(bannersRes.banners);
          try {
            localStorage.setItem('diyo_home_banners_persistent', JSON.stringify(bannersRes.banners));
          } catch (e) {}
        }
        if (roomsRes?.success && Array.isArray(roomsRes.rooms)) {
          setLiveRooms(roomsRes.rooms);
        }
        if (walletRes?.success) {
          if (typeof walletRes.ownerBalance === 'number') setOwnerTestCoinBalance(walletRes.ownerBalance);
          if (Array.isArray(walletRes.coinSellers)) setCoinSellers(walletRes.coinSellers);
          if (Array.isArray(walletRes.ownerToSellerTransactions)) setOwnerToSellerTxs(walletRes.ownerToSellerTransactions);
          if (Array.isArray(walletRes.coinSellerTransactions)) setSellerToUserTxs(walletRes.coinSellerTransactions);
        }
        if (partyRes?.success) {
          setPartyLiveRoom(partyRes.room || null);
        }
        if (settingsRes?.success && settingsRes.settings) {
          setWalletSettings(settingsRes.settings);
        }
        if (usersRes?.success && Array.isArray(usersRes.users)) {
          setPlatformWalletUsers(usersRes.users);
          const rawId = currentUser.id || '';
          const digitsOnly = rawId.replace(/\D/g, '');
          const me = usersRes.users.find((u: any) => 
            u && (u.id === currentUser.id || 
                 u.id === digitsOnly || 
                 u.username === currentUser.username ||
                 (digitsOnly && u.id.replace(/\D/g, '') === digitsOnly))
          );
          if (me) {
            setCurrentUser(prev => {
              const updated = {
                ...prev,
                ...me,
                role: me.role || prev.role || 'USER',
                hostTag: me.hostTag || prev.hostTag,
                avatarFrameId: me.avatarFrameId || prev.avatarFrameId,
                coinBalance: me.coinBalance ?? prev.coinBalance,
                diamondBalance: me.diamondBalance ?? prev.diamondBalance
              };
              try {
                localStorage.setItem('srlive_auth_session', JSON.stringify(updated));
              } catch (e) {}
              return updated;
            });
            if (me.role) {
              setCurrentRole(me.role as UserRole);
            }
          }
        }
        if (txsRes?.success && Array.isArray(txsRes.transactions)) {
          setWalletTransactions(txsRes.transactions);
        }
      } catch (err) {
        console.log('Using robust client memory persistence layer');
      }
    };
    fetchBackendState();

    // Listen to real-time role updates from hiring hub
    const handleGlobalRoleUpdate = (e: any) => {
      const { userId, newRole } = e.detail || {};
      const myId = currentUser?.id || '3456789';
      const myDigits = myId.replace(/\D/g, '');
      const targetDigits = (userId || '').replace(/\D/g, '');

      if (!userId || userId === myId || (myDigits && targetDigits && myDigits === targetDigits)) {
        fetch(`/api/hierarchy/profile/${myId}`)
          .then(r => r.json())
          .then(data => {
            if (data?.success && data.user) {
              const u = data.user;
              setCurrentUser(prev => {
                const updated = {
                  ...prev,
                  ...u,
                  role: u.role || prev.role,
                  roleTag: u.roleTag || prev.roleTag,
                  avatarFrameId: u.avatarFrameId || prev.avatarFrameId
                };
                try {
                  localStorage.setItem('srlive_auth_session', JSON.stringify(updated));
                } catch (err) {}
                return updated;
              });
              if (u.role) {
                setCurrentRole(u.role as UserRole);
              }
            }
          })
          .catch(() => {});
      }
    };
    window.addEventListener('diyo_role_updated', handleGlobalRoleUpdate);
    return () => window.removeEventListener('diyo_role_updated', handleGlobalRoleUpdate);
  }, []);

  // Update Platform Wallet Settings Handler
  const handleUpdateWalletSettings = async (newSettings: PlatformWalletSettings) => {
    try {
      const res = await fetch('/api/wallet/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings)
      });
      const data = await res.json();
      if (data.success && data.settings) {
        setWalletSettings(data.settings);
        showToast('⚙️ Wallet platform settings saved!');
        return true;
      }
    } catch (e) {}
    setWalletSettings(newSettings);
    showToast('⚙️ Wallet platform settings saved!');
    return true;
  };

  // User-to-User Coin Transfer Handler
  const handleUserTransferCoins = async (
    recipientId: string, 
    amount: number, 
    notes?: string
  ): Promise<{ success: boolean; error?: string; message?: string }> => {
    try {
      const res = await fetch('/api/wallet/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: currentUser.id,
          receiverId: recipientId,
          amount,
          notes
        })
      });
      const data = await res.json();
      if (data.success) {
        if (data.sender) {
          setCurrentUser(prev => ({
            ...prev,
            coinBalance: data.sender.coinBalance,
            diamondBalance: data.sender.diamondBalance
          }));
        }
        if (data.transaction) {
          setWalletTransactions(prev => [data.transaction, ...prev]);
        }
        // Refresh users
        try {
          const uRes = await fetch('/api/wallet/users').then(r => r.json());
          if (uRes.success) setPlatformWalletUsers(uRes.users);
        } catch (_) {}

        showToast(`🎉 Sent ${(amount ?? 0).toLocaleString()} TEST COINS!`);
        return { success: true, message: `Successfully sent ${(amount ?? 0).toLocaleString()} TEST COINS` };
      } else {
        return { success: false, error: data.error || 'Transfer failed' };
      }
    } catch (err: any) {
      // Local client fallback
      if (currentUser.coinBalance < amount) {
        return { success: false, error: 'Insufficient TEST COINS' };
      }
      const nextCoins = currentUser.coinBalance - amount;
      setCurrentUser(prev => ({ ...prev, coinBalance: nextCoins }));
      const tx: WalletTransaction = {
        id: `WTX-${Date.now()}`,
        userId: currentUser.id,
        userName: currentUser.name,
        senderId: currentUser.id,
        senderName: currentUser.name,
        receiverId: recipientId,
        recipientName: recipientId,
        type: 'USER_TRANSFER_SENT',
        amountCoins: -amount,
        amountDiamonds: 0,
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
        status: 'Completed',
        TEST_MODE: true,
        notes: notes || 'User-to-User Transfer'
      };
      setWalletTransactions(prev => [tx, ...prev]);
      showToast(`🎉 Sent ${(amount ?? 0).toLocaleString()} TEST COINS!`);
      return { success: true };
    }
  };

  // Virtual Exchange Handler (TEST COINS -> Virtual Diamonds)
  const handleUserExchangeCoins = async (
    amount: number
  ): Promise<{ success: boolean; error?: string; message?: string }> => {
    try {
      const res = await fetch('/api/wallet/exchange', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          amountCoins: amount
        })
      });
      const data = await res.json();
      if (data.success) {
        if (data.user) {
          setCurrentUser(prev => ({
            ...prev,
            coinBalance: data.user.coinBalance,
            diamondBalance: data.user.diamondBalance
          }));
        }
        if (data.transaction) {
          setWalletTransactions(prev => [data.transaction, ...prev]);
        }
        showToast(`✨ Exchanged ${(amount ?? 0).toLocaleString()} TEST COINS into Diamonds!`);
        return { success: true, message: `Exchanged ${(amount ?? 0).toLocaleString()} TEST COINS` };
      } else {
        return { success: false, error: data.error || 'Exchange failed' };
      }
    } catch (err: any) {
      const rate = walletSettings.coinToDiamondRate ?? 1.0;
      const diamondsGained = Math.floor(amount * rate);
      if (currentUser.coinBalance < amount) {
        return { success: false, error: 'Insufficient TEST COINS' };
      }
      const nextCoins = currentUser.coinBalance - amount;
      const nextDiamonds = currentUser.diamondBalance + diamondsGained;
      setCurrentUser(prev => ({ ...prev, coinBalance: nextCoins, diamondBalance: nextDiamonds }));
      const tx: WalletTransaction = {
        id: `WTX-EXC-${Date.now()}`,
        userId: currentUser.id,
        userName: currentUser.name,
        type: 'VIRTUAL_EXCHANGE',
        amountCoins: -amount,
        amountDiamonds: diamondsGained,
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
        status: 'Completed',
        TEST_MODE: true,
        notes: `Virtual exchange: ${(amount ?? 0).toLocaleString()} coins for ${(diamondsGained ?? 0).toLocaleString()} diamonds`
      };
      setWalletTransactions(prev => [tx, ...prev]);
      showToast(`✨ Exchanged ${(amount ?? 0).toLocaleString()} TEST COINS into Diamonds!`);
      return { success: true };
    }
  };

  // Handlers for Coin Sellers and Owner Test Wallet
  const handleTransferToSeller = async (sellerId: string, amount: number, notes?: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/owner/transfer-to-seller', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sellerId, amount, notes })
      });
      const data = await res.json();
      if (data.success) {
        setOwnerTestCoinBalance(data.ownerBalance);
        setCoinSellers(data.coinSellers);
        setOwnerToSellerTxs(prev => [data.transaction, ...prev]);
        showToast(`✅ Distributed ${(amount ?? 0).toLocaleString()} Test Coins to seller!`);
        playSoundFX('win');
        return true;
      }
    } catch (e) {
      // Local fallback
    }

    if (ownerTestCoinBalance < amount) {
      showToast('❌ Insufficient Owner Test Coin balance!');
      return false;
    }
    const targetSeller = coinSellers.find(s => s.id === sellerId);
    if (!targetSeller) return false;

    const prevOwner = ownerTestCoinBalance;
    const nextOwner = prevOwner - amount;
    const prevSeller = targetSeller.testCoinBalance;
    const nextSeller = prevSeller + amount;

    setOwnerTestCoinBalance(nextOwner);
    setCoinSellers(prev =>
      prev.map(s => (s.id === sellerId ? { ...s, testCoinBalance: nextSeller } : s))
    );
    const newTx: OwnerToSellerTransaction = {
      id: `CTX-OWN-${Date.now()}`,
      ownerId: 'OWNER-001',
      sellerId,
      sellerName: targetSeller.name,
      amount,
      type: 'OWNER_TO_SELLER',
      previousOwnerBalance: prevOwner,
      newOwnerBalance: nextOwner,
      previousSellerBalance: prevSeller,
      newSellerBalance: nextSeller,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
      operator: 'DIYO LIVE Master Owner',
      TEST_MODE: true,
      notes: notes || 'Owner test coins grant'
    };
    setOwnerToSellerTxs(prev => [newTx, ...prev]);
    showToast(`✅ Distributed ${(amount ?? 0).toLocaleString()} Test Coins to ${targetSeller.name}`);
    playSoundFX('win');
    return true;
  };

  const handleReclaimFromSeller = async (sellerId: string, amount: number, notes?: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/owner/reclaim-from-seller', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sellerId, amount, notes })
      });
      const data = await res.json();
      if (data.success) {
        setOwnerTestCoinBalance(data.ownerBalance);
        setCoinSellers(data.coinSellers);
        setOwnerToSellerTxs(prev => [data.transaction, ...prev]);
        showToast(`✅ Reclaimed ${(amount ?? 0).toLocaleString()} Test Coins from seller!`);
        playSoundFX('win');
        return true;
      }
    } catch (e) {}

    const targetSeller = coinSellers.find(s => s.id === sellerId);
    if (!targetSeller || targetSeller.testCoinBalance < amount) {
      showToast('❌ Seller has insufficient test coin balance to reclaim!');
      return false;
    }
    const prevOwner = ownerTestCoinBalance;
    const nextOwner = prevOwner + amount;
    const prevSeller = targetSeller.testCoinBalance;
    const nextSeller = prevSeller - amount;

    setCoinSellers(prev =>
      prev.map(s => (s.id === sellerId ? { ...s, testCoinBalance: nextSeller } : s))
    );
    setOwnerTestCoinBalance(nextOwner);
    const newTx: OwnerToSellerTransaction = {
      id: `CTX-REC-${Date.now()}`,
      ownerId: 'OWNER-001',
      sellerId,
      sellerName: targetSeller.name,
      amount,
      type: 'RECLAIM_FROM_SELLER',
      previousOwnerBalance: prevOwner,
      newOwnerBalance: nextOwner,
      previousSellerBalance: prevSeller,
      newSellerBalance: nextSeller,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
      operator: 'DIYO LIVE Master Owner',
      TEST_MODE: true,
      notes: notes || 'Owner test coins reclaim'
    };
    setOwnerToSellerTxs(prev => [newTx, ...prev]);
    showToast(`✅ Reclaimed ${(amount ?? 0).toLocaleString()} Test Coins from ${targetSeller.name}`);
    playSoundFX('win');
    return true;
  };

  const handleCreateCoinSeller = async (sellerData: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/coin-sellers/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sellerData)
      });
      const data = await res.json();
      if (data.success) {
        setCoinSellers(data.coinSellers);
        setOwnerTestCoinBalance(data.ownerBalance);
        showToast(`✅ Created Authorized Coin Seller ${sellerData.name}`);
        return true;
      }
    } catch (e) {}

    const initialGrant = Number(sellerData.initialCoins) || 0;
    if (initialGrant > ownerTestCoinBalance) {
      showToast('❌ Insufficient Owner Test Coins for initial grant!');
      return false;
    }
    const newSeller: CoinSellerAccount = {
      id: `CS-${Math.floor(100 + Math.random() * 900)}`,
      name: sellerData.name,
      username: sellerData.username,
      phone: sellerData.phone || '+91 99881 12233',
      email: sellerData.email || `${sellerData.username}@srlive.io`,
      status: 'Active',
      testCoinBalance: initialGrant,
      totalDistributed: 0,
      dailyLimit: Number(sellerData.dailyLimit) || 50000000,
      singleTransferLimit: Number(sellerData.singleLimit) || 10000000,
      createdDate: new Date().toISOString().split('T')[0],
      lastActivity: 'Just now',
      notes: sellerData.notes || '',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
    };
    setOwnerTestCoinBalance(prev => prev - initialGrant);
    setCoinSellers(prev => [newSeller, ...prev]);
    showToast(`✅ Created Authorized Coin Seller ${newSeller.name}`);
    return true;
  };

  const handleUpdateCoinSellerStatus = async (sellerId: string, status: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/coin-sellers/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sellerId, status })
      });
      const data = await res.json();
      if (data.success) {
        setCoinSellers(data.coinSellers);
        showToast(`✅ Seller status updated to ${status}`);
        return true;
      }
    } catch (e) {}

    setCoinSellers(prev =>
      prev.map(s => (s.id === sellerId ? { ...s, status } : s))
    );
    showToast(`✅ Seller status updated to ${status}`);
    return true;
  };

  const handleUpdateCoinSellerLimits = async (sellerId: string, dailyLimit: number, singleLimit: number): Promise<boolean> => {
    try {
      const res = await fetch('/api/coin-sellers/limits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sellerId, dailyLimit, singleLimit })
      });
      const data = await res.json();
      if (data.success) {
        setCoinSellers(data.coinSellers);
        showToast(`✅ Updated limits for seller!`);
        return true;
      }
    } catch (e) {}

    setCoinSellers(prev =>
      prev.map(s => (s.id === sellerId ? { ...s, dailyLimit, singleTransferLimit: singleLimit } : s))
    );
    showToast(`✅ Updated limits for seller!`);
    return true;
  };

  // Modals state
  const [isCustomStreamModalOpen, setIsCustomStreamModalOpen] = useState(false);
  const [isClipMakerOpen, setIsClipMakerOpen] = useState(false);
  const [isVideoAnalyzerOpen, setIsVideoAnalyzerOpen] = useState(false);

  // Toast Notification Alert State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Add custom stream handler
  const handleAddCustomStream = (newStream: StreamChannel) => {
    setChannels((prev) => [newStream, ...prev]);
    setSelectedChannel(newStream);
    setActiveTab('browse');
    showToast(`Added and switched to "${newStream.title}"`);
  };

  // Toggle Reminder
  const handleSetReminder = (id: string) => {
    setSchedule((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nextState = !item.isReminderSet;
          if (nextState) {
            showToast(`🔔 Reminder set for "${item.title}"! We'll alert you when it goes live.`);
          }
          return { ...item, isReminderSet: nextState };
        }
        return item;
      })
    );
  };

  // Like Stream increment
  const handleLikeCurrentStream = () => {
    setChannels((prev) =>
      prev.map((c) =>
        c.id === selectedChannel.id ? { ...c, likesCount: (c.likesCount ?? 0) + 1 } : c
      )
    );
    setSelectedChannel((prev) => ({ ...prev, likesCount: (prev.likesCount ?? 0) + 1 }));
    showToast(`❤️ Liked "${selectedChannel.title}"`);
  };

  // Save new clip into highlights
  const handleSaveClip = (clip: { title: string; duration: string; url: string }) => {
    const newHighlight: VideoHighlight = {
      id: 'clip-' + Date.now(),
      title: clip.title,
      channelName: selectedChannel.broadcasterName,
      duration: clip.duration,
      views: '1 view',
      date: 'Just now',
      thumbnailUrl: selectedChannel.thumbnailUrl,
      videoUrl: clip.url,
      category: selectedChannel.category,
      tags: ['UserClip', 'SRLiveHighlight']
    };
    setHighlights((prev) => [newHighlight, ...prev]);
    showToast(`🎬 Highlight clip saved to VOD catalog!`);
  };

  // Handle user balance update
  const handleUpdateUserBalance = (newCoins: number, newDiamonds: number) => {
    const coinDelta = newCoins - currentUser.coinBalance;
    const diamondDelta = newDiamonds - currentUser.diamondBalance;
    setCurrentUser(prev => ({
      ...prev,
      coinBalance: newCoins,
      diamondBalance: newDiamonds,
      totalSpentCoins: coinDelta < 0 ? prev.totalSpentCoins + Math.abs(coinDelta) : prev.totalSpentCoins
    }));

    if (coinDelta !== 0 || diamondDelta !== 0) {
      // Sync update to backend persistent database
      fetch('/api/wallet/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          coinDelta,
          diamondDelta,
          source: coinDelta > 0 ? 'Game' : 'Gift',
          description: coinDelta > 0 ? `Game Win / Reward (+${coinDelta.toLocaleString()} Coins)` : `In-App Usage / Bet (-${Math.abs(coinDelta).toLocaleString()} Coins)`
        })
      }).catch(e => console.error('Error syncing wallet update to backend:', e));

      const newTx: WalletTransaction = {
        id: `TX-${Date.now()}`,
        userId: currentUser.id,
        userName: currentUser.name,
        type: coinDelta > 0 ? 'Deposit' : (diamondDelta > 0 ? 'Gift_Send' : 'Game_Bet'),
        amountCoins: coinDelta,
        amountDiamonds: diamondDelta,
        timestamp: 'Just now',
        status: 'Completed',
        notes: diamondDelta > 0 
          ? `Gifting / Activity: -${Math.abs(coinDelta).toLocaleString()} Coins → +${diamondDelta.toLocaleString()} 💎 Added to Withdraw Wallet`
          : coinDelta > 0 ? `Game Win Persistent Reward: +${coinDelta.toLocaleString()} Coins` : 'In-App Game Bet / Coin Usage'
      };
      setWalletTransactions(prev => [newTx, ...prev]);
    }
  };

  // Handle user VIP tier upgrade
  const handleUpgradeVip = (targetLevel: number) => {
    setCurrentUser(prev => ({
      ...prev,
      vipLevel: targetLevel
    }));
    showToast(`👑 Congratulations! You are now DIYO LIVE VIP Tier ${targetLevel}!`);
  };

  // Handle profile edits - Permanently saves to backend database and local storage
  const handleUpdateUserProfile = async (updated: { 
    name: string; 
    username: string; 
    avatar: string; 
    bio?: string;
    gender?: 'Male' | 'Female' | 'Other';
    dob?: string;
    countryName?: string;
    countryFlag?: string;
    countryCode?: string;
    phone?: string;
    profileTag?: string;
  }) => {
    setCurrentUser(prev => {
      const next = {
        ...prev,
        ...updated
      };
      try {
        localStorage.setItem('srlive_auth_session', JSON.stringify(next));
        localStorage.setItem('diyo_current_user', JSON.stringify(next));
        localStorage.setItem('srlive_current_user', JSON.stringify(next));
      } catch (e) {}
      return next;
    });

    try {
      const res = await fetch('/api/users/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          ...updated
        })
      });
      const data = await res.json();
      if (data?.success && data?.user) {
        setCurrentUser(prev => {
          const synced = { ...prev, ...data.user };
          try {
            localStorage.setItem('srlive_auth_session', JSON.stringify(synced));
            localStorage.setItem('diyo_current_user', JSON.stringify(synced));
            localStorage.setItem('srlive_current_user', JSON.stringify(synced));
          } catch (e) {}
          return synced;
        });
      }
    } catch (e) {
      console.warn('Profile sync to backend failed:', e);
    }
    showToast('✨ DIYO Profile updated & saved permanently in database!');
  };

  // Handle gift sending transaction
  const handleSendGiftTransaction = async (gift: GiftItem, recipientUserId: string) => {
    const cost = gift.coinPrice || (gift as any).coinCost || (gift as any).costCoins || 1000;
    if (currentUser.coinBalance < cost) {
      showToast('❌ Insufficient Coins to send gift! Please top up.');
      playSoundFX('alert');
      return false;
    }
    const newCoins = currentUser.coinBalance - cost;
    handleUpdateUserBalance(newCoins, currentUser.diamondBalance);
    showToast(`🎁 Successfully sent ${gift.name} (${cost.toLocaleString()} Coins)!`);
    playSoundFX('reward');
    return true;
  };

  // Logout Handler
  const handleLogout = () => {
    try {
      localStorage.removeItem('srlive_auth_session');
    } catch (e) {}
    androidLiveStreamService.stopCurrentStream(true);
    setMinimizedLiveSession(null);
    setIsAuthenticated(false);
    showToast('👋 You have been logged out of DIYO LIVE.');
    playSoundFX('alert');
  };

  // Filter channels by search and category
  const filteredChannels = (channels || []).filter((c) => {
    const matchesCategory = selectedCategory === 'all' || c.category === selectedCategory;
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (c.title || '').toLowerCase().includes(q) ||
      (c.broadcasterName || '').toLowerCase().includes(q) ||
      (c.tags || []).some((t) => (t || '').toLowerCase().includes(q));
    return matchesCategory && matchesSearch;
  });

  const categories: { id: StreamCategory; label: string; icon: any }[] = [
    { id: 'all', label: 'All Live Rooms', icon: Flame },
    { id: 'sports', label: 'Sports Arena', icon: Trophy },
    { id: 'gaming', label: 'Pro Esports', icon: Gamepad2 },
    { id: 'music', label: 'Music & Concerts', icon: Music },
    { id: 'news', label: '24/7 Global News', icon: Tv },
    { id: 'tech', label: 'Tech & Space', icon: Cpu },
    { id: 'radio', label: 'Lo-Fi Lounge', icon: Radio },
  ];

  // Splash Screen Gate
  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} duration={1800} />;
  }

  // Authentication Gate: Ensure unauthenticated users cannot enter the app
  if (!isAuthenticated) {
    return (
      <AuthScreen
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          setIsAuthenticated(true);
          try {
            localStorage.setItem('srlive_auth_session', JSON.stringify(user));
          } catch (e) {}
          setActiveTab('explore');
          showToast(`✨ Welcome to DIYO LIVE, ${user.name}!`);
        }}
      />
    );
  }

  return (
    <div className="diyo-compact-ui h-screen w-screen bg-neutral-950 text-neutral-100 flex flex-col selection:bg-emerald-500 selection:text-neutral-950 overflow-hidden">
      
      {/* Top Main Navigation (Home, Party Live, Messages, Me, Tools) - Desktop Only */}
      {activeTab !== 'party_live' && (
        <div className="hidden md:block">
          <Navbar
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onOpenGoLive={() => setActiveTab('party_live')}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onOpenCustomStream={() => setIsCustomStreamModalOpen(true)}
            onOpenVideoAnalyzer={() => setIsVideoAnalyzerOpen(true)}
            unreadNotifications={schedule.filter((s) => s.isReminderSet).length}
            currentRole={currentRole}
            currentUser={currentUser}
          />
        </div>
      )}

      {/* Main App Body */}
      {activeTab === 'owner' ? (
        (!hasOfficialTagOrRole && !['OWNER', 'MANAGER', 'OFFICIAL', 'SUPER_ADMIN', 'SUPER ADMIN', 'ADMIN', 'ADMIN_BD', 'BD_ADMIN', 'BD ADMIN', 'AGENCY', 'COIN_SELLER', 'COIN SELLER', 'HOST'].includes((currentUser.role || currentRole || 'USER').toUpperCase()) && currentUser.id !== '0000001' && currentUser.id !== 'OWNER-001') ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-neutral-950">
            <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-4 shadow-xl">
              <span className="text-2xl">🔒</span>
            </div>
            <h2 className="text-xl font-black text-white font-['Outfit'] mb-2">STAFF CLEARANCE REQUIRED</h2>
            <p className="text-xs text-neutral-400 max-w-sm mb-6">
              Official management panels are reserved for DIYO LIVE Staff (Owner, Manager, Super Admin, BD Admin, Agency Leaders). Your account role (<span className="text-amber-400 font-bold">{currentUser.role || 'USER'}</span>) is not assigned to staff.
            </p>
            <button
              onClick={() => {
                playSoundFX('click');
                setActiveTab('explore');
              }}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs uppercase tracking-wider transition-all shadow-lg cursor-pointer"
            >
              Return to Explore
            </button>
          </div>
        ) : (
        <OwnerDashboard
          currentRole={currentRole}
          setCurrentRole={setCurrentRole}
          stats={{
            ...ownerStats,
            adminsCount: admins.length,
            managersCount: managers.length,
            agenciesCount: agencies.length,
            usersCount: users.length,
            liveRoomsCount: liveRooms.length,
            totalGiftsSent: gifts.reduce((acc, g) => acc + g.totalSentCount, 0),
            totalTestTransactions: walletTransactions.filter(t => t.type === 'TEST_TRANSACTION').length,
            pendingWithdrawalsUSD: withdrawals.filter(w => w.status === 'Pending').reduce((acc, w) => acc + w.payoutAmountUSD, 0)
          }}
          admins={admins}
          managers={managers}
          agencies={agencies}
          users={users}
          liveRooms={liveRooms}
          gifts={gifts}
          walletTransactions={walletTransactions}
          vipConfigs={vipConfigs}
          withdrawals={withdrawals}
          reports={reports}
          notifications={notifications}
          auditLogs={auditLogs}
          platformSettings={platformSettings}
          coinSellers={coinSellers}
          ownerTestCoinBalance={ownerTestCoinBalance}
          ownerToSellerTxs={ownerToSellerTxs}
          sellerToUserTxs={sellerToUserTxs}
          partyLiveRoom={partyLiveRoom}
          avatarFrames={avatarFrames}
          onUpdateAvatarFrames={setAvatarFrames}
          onEquipFrameToUser={(userId, frameId, frameUrl) => {
            setUsers(prev => prev.map(u => u.id === userId ? { ...u, avatarFrameId: frameId || undefined, avatarFrameUrl: frameUrl || undefined } : u));
            if (currentUser.id === userId) {
              setCurrentUser(prev => ({ ...prev, avatarFrameId: frameId || undefined, avatarFrameUrl: frameUrl || undefined }));
            }
          }}
          pkBattles={pkBattles}
          casinoTransactions={casinoTransactions}
          walletSettings={walletSettings}
          platformUsers={platformWalletUsers}
          currentUser={currentUser}
          banners={platformBanners}
          onUpdateBanners={handleUpdatePlatformBanners}
          onUpdateAdmins={setAdmins}
          onUpdateManagers={setManagers}
          onUpdateAgencies={setAgencies}
          onUpdateUsers={setUsers}
          onUpdateLiveRooms={setLiveRooms}
          onUpdateGifts={setGifts}
          onUpdateWalletTransactions={setWalletTransactions}
          onUpdateVipConfigs={setVipConfigs}
          onUpdateWithdrawals={setWithdrawals}
          onUpdateReports={setReports}
          onUpdateNotifications={setNotifications}
          onAddAuditLog={(newLog) => setAuditLogs(prev => [newLog, ...prev])}
          onUpdateSettings={setPlatformSettings}
          onTransferToSeller={handleTransferToSeller}
          onReclaimFromSeller={handleReclaimFromSeller}
          onCreateCoinSeller={handleCreateCoinSeller}
          onUpdateCoinSellerStatus={handleUpdateCoinSellerStatus}
          onUpdateCoinSellerLimits={handleUpdateCoinSellerLimits}
          onUpdateWalletSettings={handleUpdateWalletSettings}
          onUserTransfer={handleUserTransferCoins}
        />)
      ) : (
        <main className={`flex-1 w-full mx-auto overflow-y-auto overscroll-y-contain [-webkit-overflow-scrolling:touch] min-h-0 ${
          activeTab === 'browse' || activeTab === 'me' || activeTab === 'party_live'
            ? 'p-0 pb-36'
            : 'max-w-7xl px-3 sm:px-4 lg:px-6 py-5 space-y-6 pb-36'
        }`}>
          
          {/* Tab 1: ROOM / Live Streams Mode (Explore Screen) */}
          {activeTab === 'browse' && (
            <ExploreScreen
              currentUser={currentUser}
              banners={platformBanners}
              liveRooms={liveRooms}
              hasApprovedAgency={hasApprovedAgency}
              onSelectStream={(streamId) => {
                setSelectedLiveRoomId(streamId);
                const target = liveRooms.find((r: any) => (r.roomId === streamId || r.id === streamId));
                const isParty = target && (
                  (target as any).liveType === 'PARTY' ||
                  (target as any).roomType === 'PARTY' ||
                  (target as any).type === 'party' ||
                  streamId.startsWith('LIVE-P') ||
                  (target as any).tag?.toLowerCase().includes('party')
                );
                if (isParty) {
                  setActiveTab('party_live');
                } else {
                  setActiveTab('video_live');
                }
              }}
              onOpenGoLive={() => handleAttemptGoLive()}
              onOpenVideoLive={() => handleAttemptGoLive('video')}
              onOpenPartyLive={() => handleAttemptGoLive('party')}
              onOpenLeaderboard={() => {
                setActiveTab('me');
              }}
            />
          )}

          {/* Tab: VIDEO LIVE Screen */}
          {activeTab === 'video_live' && (
            <VideoLiveScreen
              currentUser={currentUser}
              currentRoom={liveRooms.find((r: any) => (r.roomId === selectedLiveRoomId || r.id === selectedLiveRoomId))}
              roomId={selectedLiveRoomId || 'LIVE-V-101'}
              onClose={handleCloseOrEndLive}
              onUpdateUserBalance={handleUpdateUserBalance}
            />
          )}

          {/* Tab 3: PARTY LIVE 20-Seat Lounge & Sir Crown */}
          {activeTab === 'party_live' && (() => {
            const activeRoom = liveRooms.find((r: any) => (r.roomId === selectedLiveRoomId || r.id === selectedLiveRoomId));
            return (
              <PartyLiveScreen
                currentUser={{
                  id: currentUser.id,
                  name: currentUser.name,
                  avatar: currentUser.avatar,
                  coinBalance: currentUser.coinBalance,
                  diamondBalance: currentUser.diamondBalance,
                  vipLevel: currentUser.vipLevel,
                  role: currentUser.role,
                  hostTag: currentUser.hostTag,
                  avatarFrameId: currentUser.avatarFrameId,
                  avatarFrameUrl: currentUser.avatarFrameUrl
                }}
                partyLiveRoom={{
                  ...(partyLiveRoom || {}),
                  ...(activeRoom || {}),
                  id: selectedLiveRoomId || activeRoom?.roomId || activeRoom?.id || 'LIVE-P-201',
                  hostId: activeRoom?.hostId || activeRoom?.ownerId || partyLiveRoom?.hostId || currentUser.id,
                  hostName: activeRoom?.hostName || activeRoom?.ownerName || partyLiveRoom?.hostName || currentUser.name,
                  hostAvatar: activeRoom?.hostAvatar || activeRoom?.coverImage || activeRoom?.cover || partyLiveRoom?.hostAvatar || currentUser.avatar,
                  onlineCount: activeRoom?.onlineCount || activeRoom?.viewersCount || 1,
                  countryFlag: activeRoom?.countryFlag || '🇳🇵',
                  country: activeRoom?.country || 'Nepal'
                } as any}
                onUpdateUserBalance={handleUpdateUserBalance}
                onClose={handleCloseOrEndLive}
                onOpenVideoLive={() => handleAttemptGoLive('video')}
                onStartPartyLive={() => handleAttemptGoLive('party')}
              />
            );
          })()}

          {/* Tab 4: MOMENT Screen (Community Feed) */}
          {activeTab === 'moment' && (
            <MomentsScreen
              currentUserName={currentUser.name}
              currentUserAvatar={currentUser.avatar}
            />
          )}

          {/* Tab: GAMES CENTER */}
          {activeTab === 'games' && (
            <SRGameCenterHub
              userCoins={currentUser.coinBalance}
              onUpdateCoins={(delta) => handleUpdateUserBalance(currentUser.coinBalance + delta, currentUser.diamondBalance)}
              onClose={() => setActiveTab('browse')}
            />
          )}
          {activeTab === 'message' && (
            <MessagesScreen
              currentUserName={currentUser.name}
              currentUserAvatar={currentUser.avatar}
            />
          )}

          {/* Tab: WALLET & VAULT Screen */}
          {activeTab === 'wallet' && (
            <WalletScreen
              currentUser={currentUser}
              transactions={walletTransactions}
              onUpdateUserBalance={handleUpdateUserBalance}
              onUpdateBalance={handleUpdateUserBalance}
              onTransferCoins={handleUserTransferCoins}
              onExchangeCoins={handleUserExchangeCoins}
              walletSettings={walletSettings}
              platformUsers={platformWalletUsers}
              onBack={() => setActiveTab('me')}
            />
          )}

          {/* Tab 7: ME / PROFILE Screen */}
          {activeTab === 'me' && (
            <ProfileScreen
              currentUser={currentUser}
              vipConfigs={vipConfigs}
              transactions={walletTransactions}
              currentRole={currentRole}
              onChangeRole={setCurrentRole}
              onOpenOwnerPanel={() => setActiveTab('owner')}
              onGoLiveClick={() => handleAttemptGoLive()}
              hasApprovedAgency={hasApprovedAgency}
              agencies={agencies}
              agencyJoinRequests={agencyJoinRequests}
              onUpdateAgencyRequests={setAgencyJoinRequests}
              onUpdateUserAgencyMembership={(membership) => {
                setCurrentUser(prev => ({
                  ...prev,
                  agencyMembership: membership
                }));
              }}
              onAddAuditLog={(newLog) => setAuditLogs(prev => [newLog, ...prev])}
              onAddNotification={(newNotif) => setNotifications(prev => [newNotif, ...prev])}
              onUpdateUserBalance={handleUpdateUserBalance}
              onUpdateUserProfile={handleUpdateUserProfile}
              onUpgradeVip={handleUpgradeVip}
              onEquipAvatarFrame={(frameId, frameUrl, roleType, hostTag) => {
                setCurrentUser(prev => ({
                  ...prev,
                  avatarFrameId: frameId || undefined,
                  avatarFrameUrl: frameUrl || undefined,
                  role: roleType || (frameId && !frameId.startsWith('FRM-ROLE-') ? prev.role : (roleType || prev.role)),
                  hostTag: (hostTag as any) || prev.hostTag
                }));
                if (roleType) {
                  setCurrentRole(roleType as any);
                }
              }}
              onTransferCoins={handleUserTransferCoins}
              onExchangeCoins={handleUserExchangeCoins}
              walletSettings={walletSettings}
              platformUsers={platformWalletUsers}
              onNavigateTab={(tab) => setActiveTab(tab as any)}
              onLogout={handleLogout}
            />
          )}

          {/* Tab 8: Creator Broadcast Studio */}
          {activeTab === 'studio' && (
            <BroadcastStudio onGoLive={handleAddCustomStream} />
          )}

          {/* Tab 9: Quad-Stream Multi-View Monitor */}
          {activeTab === 'multiview' && (
            <MultiViewGrid
              channels={channels}
              onSelectMainChannel={(chan) => {
                setSelectedChannel(chan);
                setActiveTab('browse');
              }}
            />
          )}

          {/* Tab 10: 24/7 Audio Radio Lounge */}
          {activeTab === 'radio' && (
            <AudioRadioLounge />
          )}

        </main>
      )}

      {/* Global Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-20 right-6 z-50 bg-neutral-900 border border-emerald-500/60 rounded-2xl px-4 py-3 shadow-2xl shadow-emerald-950/40 text-xs font-semibold text-white flex items-center gap-3 animate-in fade-in slide-in-from-bottom-3 max-w-sm">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="flex-1">{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="text-neutral-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Login / Signup Modal */}
      <LoginSignupModal
        isOpen={isLoginSignupOpen}
        onClose={() => setIsLoginSignupOpen(false)}
        onSuccessLogin={(userData) => {
          setCurrentUser(prev => ({
            ...prev,
            name: userData.name,
            username: userData.username,
            email: userData.email
          }));
        }}
      />

      {/* Modals */}
      <ChooseLiveTypeModal
        isOpen={isChooseLiveTypeOpen}
        onClose={() => setIsChooseLiveTypeOpen(false)}
        hasApprovedAgency={hasApprovedAgency}
        onAgencyBlocked={() => {
          setIsChooseLiveTypeOpen(false);
          setIsAgencyJoinRequiredOpen(true);
        }}
        onSelectVideoLive={(details) => {
          setIsChooseLiveTypeOpen(false);
          handleStartLiveStream('VIDEO', details);
        }}
        onSelectPartyLive={(details) => {
          setIsChooseLiveTypeOpen(false);
          handleStartLiveStream('PARTY', details);
        }}
        userAvatar={currentUser.avatar}
        userName={currentUser.name}
      />

      <CustomStreamModal
        isOpen={isCustomStreamModalOpen}
        onClose={() => setIsCustomStreamModalOpen(false)}
        onAddStream={handleAddCustomStream}
      />

      <ClipMakerModal
        isOpen={isClipMakerOpen}
        onClose={() => setIsClipMakerOpen(false)}
        channel={selectedChannel}
        onSaveClip={handleSaveClip}
      />

      <VideoAnalyzerModal
        isOpen={isVideoAnalyzerOpen}
        onClose={() => setIsVideoAnalyzerOpen(false)}
        defaultVideoUrl={selectedChannel?.streamUrl}
        defaultVideoTitle={selectedChannel?.title}
        streamerName={selectedChannel?.streamerName}
      />

      {/* Floating Minimized Live Player (PIP) across all tabs */}
      {minimizedLiveSession && activeTab !== 'video_live' && activeTab !== 'party_live' && (
        <FloatingLiveMiniPlayer
          session={minimizedLiveSession}
          onExpand={() => {
            setActiveTab(minimizedLiveSession.roomType);
          }}
          onClose={() => {
            androidLiveStreamService.stopCurrentStream(true);
            setMinimizedLiveSession(null);
          }}
          onToggleMic={() => {
            const nextMic = androidLiveStreamService.toggleMicrophone();
            setMinimizedLiveSession(prev => prev ? ({ ...prev, isMicOn: nextMic }) : null);
          }}
        />
      )}

      {/* Persistent Bottom Navigation Bar */}
      {activeTab !== 'video_live' && activeTab !== 'party_live' && (
        <BottomNavigation
          activeTab={activeTab}
          onSelectTab={(tab) => setActiveTab(tab)}
          onOpenGoLive={() => handleAttemptGoLive()}
          hasApprovedAgency={hasApprovedAgency}
          unreadMessagesCount={2}
        />
      )}

      {/* Agency Requirement Guard Modal */}
      <AgencyJoinRequiredModal
        isOpen={isAgencyJoinRequiredOpen}
        onClose={() => setIsAgencyJoinRequiredOpen(false)}
        onOpenAgencyJoin={() => {
          setIsAgencyJoinRequiredOpen(false);
          setIsAgencyModalOpen(true);
        }}
        hostName={currentUser.name}
        membershipStatus={currentUser.agencyMembership?.status}
      />

      {/* Agency Center & Talent Guild Modal */}
      {isAgencyModalOpen && (
        <AgencyModal
          isOpen={isAgencyModalOpen}
          onClose={() => setIsAgencyModalOpen(false)}
          currentUser={currentUser}
          agencies={agencies}
          agencyJoinRequests={agencyJoinRequests}
          onUpdateAgencyRequests={setAgencyJoinRequests}
          onUpdateUserAgencyMembership={(membership) => {
            setCurrentUser(prev => ({
              ...prev,
              agencyMembership: membership
            }));
          }}
          onAddAuditLog={(newLog) => setAuditLogs(prev => [newLog, ...prev])}
          onAddNotification={(newNotif) => setNotifications(prev => [newNotif, ...prev])}
        />
      )}

      {/* Footer with padding for bottom nav (Hidden on 'me' profile to let all functions and panels sit right above bottom navigation) */}
      {activeTab !== 'video_live' && activeTab !== 'party_live' && activeTab !== 'browse' && activeTab !== 'me' && (
        <footer className="bg-neutral-950 border-t border-neutral-900 py-6 px-4 lg:px-6 mt-12 pb-nav-safe text-center text-xs text-neutral-500">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="font-['Outfit'] font-black text-sm text-white">DIYO LIVE</span>
              <span>• Ultra Low Latency Broadcast Network</span>
            </div>
            <p>© 2026 DIYO LIVE. All streams broadcast in 4K UHD & AV1 encoder standard.</p>
          </div>
        </footer>
      )}

    </div>
  );
}
