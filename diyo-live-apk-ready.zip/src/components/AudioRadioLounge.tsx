import React, { useState, useEffect, useRef } from 'react';
import { 
  Radio, 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  Volume2, 
  VolumeX, 
  Shuffle, 
  Repeat, 
  Repeat1, 
  Music, 
  Search, 
  Upload, 
  Sparkles, 
  Heart, 
  Share2, 
  Flame, 
  Sliders, 
  Disc, 
  Plus, 
  CheckCircle,
  Headphones,
  Mic2
} from 'lucide-react';
import { musicEngine, MusicEngineState, PlaybackMode } from '../utils/musicEngine';
import { MusicTrack, DJ_SOUND_EFFECTS } from '../utils/musicTracks';
import { getAnalyser, playSoundFX } from '../utils/audioSynth';

export const AudioRadioLounge: React.FC = () => {
  const [engineState, setEngineState] = useState<MusicEngineState>(musicEngine.getState());
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [likedTracks, setLikedTracks] = useState<Set<string>>(new Set(['trk-bol-01', 'trk-pun-01']));
  const [notification, setNotification] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const unsubscribe = musicEngine.subscribe((state) => {
      setEngineState(state);
    });
    return () => unsubscribe();
  }, []);

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleTogglePlay = () => {
    musicEngine.togglePlay();
    playSoundFX('click');
  };

  const handlePlayTrack = (track: MusicTrack) => {
    musicEngine.playTrack(track);
    playSoundFX('click');
    showToast(`▶️ Now Playing: "${track.title}" by ${track.artist}`);
  };

  const handleNext = () => {
    musicEngine.nextTrack();
    playSoundFX('click');
  };

  const handlePrev = () => {
    musicEngine.prevTrack();
    playSoundFX('click');
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    musicEngine.setVolume(val);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    musicEngine.seek(val);
  };

  const togglePlaybackMode = () => {
    const modes: PlaybackMode[] = ['repeat-all', 'repeat-one', 'shuffle'];
    const currentIdx = modes.indexOf(engineState.playbackMode);
    const nextMode = modes[(currentIdx + 1) % modes.length];
    musicEngine.setPlaybackMode(nextMode);
    playSoundFX('click');
  };

  const toggleLike = (trackId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedTracks((prev) => {
      const next = new Set(prev);
      if (next.has(trackId)) {
        next.delete(trackId);
      } else {
        next.add(trackId);
        playSoundFX('reaction');
      }
      return next;
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      const file = files[0];
      musicEngine.addCustomTrack(file);
      showToast(`🎵 Custom song added: "${file.name}"!`);
      playSoundFX('success');
    }
  };

  const handlePlaySoundEffect = (fx: any) => {
    playSoundFX(fx.sound as any);
    showToast(`🔊 Triggered FX: ${fx.name}`);
  };

  // Filter Tracks
  const filteredTracks = (engineState.playlist || []).filter((track) => {
    const matchesCat = selectedCategory === 'All' || track.category === selectedCategory;
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (track.title || '').toLowerCase().includes(q) ||
      (track.artist || '').toLowerCase().includes(q) ||
      (track.mood || '').toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Spectrum Canvas Render
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bars = 48;
    const dataArray = new Uint8Array(64);

    const render = () => {
      const analyser = getAnalyser();
      if (analyser && engineState.isPlaying) {
        analyser.getByteFrequencyData(dataArray);
      } else {
        for (let i = 0; i < dataArray.length; i++) {
          dataArray[i] = Math.sin(Date.now() * 0.003 + i * 0.2) * 15 + 20;
        }
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const barWidth = canvas.width / bars;
      for (let i = 0; i < bars; i++) {
        const value = dataArray[i % dataArray.length];
        const percent = value / 255;
        const barHeight = Math.max(3, percent * canvas.height * 0.85);

        const x = i * barWidth;
        const y = (canvas.height - barHeight) / 2;

        const grad = ctx.createLinearGradient(0, y, 0, y + barHeight);
        grad.addColorStop(0, '#f43f5e');
        grad.addColorStop(0.5, '#fb923c');
        grad.addColorStop(1, '#a855f7');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x + 1.5, y, barWidth - 3, barHeight, 3);
        ctx.fill();
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [engineState.isPlaying]);

  const current = engineState.currentTrack;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-20 right-4 z-50 px-4 py-2.5 rounded-2xl bg-neutral-900/90 border border-rose-500/50 text-white text-xs font-bold shadow-2xl backdrop-blur-md animate-in slide-in-from-top flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{notification}</span>
        </div>
      )}

      {/* Hero Live Jukebox Banner */}
      <div className="relative bg-gradient-to-br from-neutral-900 via-neutral-950 to-rose-950/40 border border-neutral-800 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Active Track Disc & Info */}
          <div className="flex items-center gap-6 w-full md:w-auto">
            {/* Spinning Vinyl Album Art */}
            <div className="relative flex-shrink-0">
              <div 
                className={`w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-neutral-900 border-4 border-neutral-800 shadow-2xl flex items-center justify-center p-2 transition-transform duration-1000 ${
                  engineState.isPlaying ? 'animate-[spin_7s_linear_infinite]' : ''
                }`}
              >
                <div className="w-full h-full rounded-full border-2 border-neutral-700/60 overflow-hidden relative">
                  <img
                    src={current?.coverUrl || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300'}
                    alt={current?.title || 'Song Cover'}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="w-8 h-8 rounded-full bg-neutral-950 border border-neutral-700 flex items-center justify-center shadow-md">
                      <Disc className="w-4 h-4 text-rose-400" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="absolute -top-1 -right-1 px-2 py-0.5 rounded-full bg-rose-600 text-white text-[9px] font-black shadow-lg">
                {engineState.isPlaying ? 'PLAYING 🎵' : 'PAUSED'}
              </div>
            </div>

            {/* Title & Metadata */}
            <div className="space-y-1.5 min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] font-black uppercase tracking-wider">
                  {current?.category || 'MUSIC'}
                </span>
                <span className="text-[11px] text-neutral-400 font-mono">
                  {current?.bpm || 100} BPM • {current?.mood || 'Vibes'}
                </span>
              </div>

              <h1 className="text-lg sm:text-2xl font-black text-white font-['Outfit'] truncate">
                {current?.title || 'Select any Song'}
              </h1>
              <p className="text-xs text-neutral-300 font-medium truncate">
                {current?.artist || 'SR Live Stream Jukebox'}
              </p>

              <div className="flex items-center gap-3 pt-1">
                <button
                  onClick={(e) => current && toggleLike(current.id, e)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold transition-all border ${
                    current && likedTracks.has(current.id)
                      ? 'bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-600/30'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-700'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${current && likedTracks.has(current.id) ? 'fill-white' : ''}`} />
                  <span>{(current?.likes ?? 42000).toLocaleString()}</span>
                </button>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700 transition-all active:scale-95"
                >
                  <Upload className="w-3.5 h-3.5 text-amber-400" />
                  <span>Upload Song (MP3)</span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </div>

          </div>

          {/* Master Transport & Volume Controls */}
          <div className="flex flex-col items-center gap-3 w-full md:w-auto bg-neutral-950/60 border border-neutral-800 p-4 rounded-2xl">
            
            {/* Player Buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={togglePlaybackMode}
                title="Playback Mode"
                className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-all"
              >
                {engineState.playbackMode === 'shuffle' && <Shuffle className="w-4 h-4 text-amber-400" />}
                {engineState.playbackMode === 'repeat-one' && <Repeat1 className="w-4 h-4 text-rose-400" />}
                {engineState.playbackMode === 'repeat-all' && <Repeat className="w-4 h-4 text-neutral-300" />}
              </button>

              <button
                onClick={handlePrev}
                className="p-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white transition-all active:scale-95"
              >
                <SkipBack className="w-5 h-5 fill-current" />
              </button>

              <button
                id="btn-music-play-pause"
                onClick={handleTogglePlay}
                className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-xl active:scale-95 ${
                  engineState.isPlaying
                    ? 'bg-gradient-to-tr from-rose-600 to-red-600 text-white shadow-rose-600/40 ring-4 ring-rose-500/20'
                    : 'bg-white text-neutral-950 hover:bg-neutral-200 shadow-white/20'
                }`}
              >
                {engineState.isPlaying ? <Pause className="w-7 h-7 fill-current" /> : <Play className="w-7 h-7 fill-current ml-0.5" />}
              </button>

              <button
                onClick={handleNext}
                className="p-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white transition-all active:scale-95"
              >
                <SkipForward className="w-5 h-5 fill-current" />
              </button>
            </div>

            {/* Time & Seek Bar */}
            <div className="w-full space-y-1">
              <input
                type="range"
                min="0"
                max={engineState.duration || 200}
                value={engineState.currentTime}
                onChange={handleSeek}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
              />
              <div className="flex justify-between text-[10px] font-mono text-neutral-400">
                <span>{formatTime(engineState.currentTime)}</span>
                <span>{formatTime(engineState.duration)}</span>
              </div>
            </div>

            {/* Volume */}
            <div className="flex items-center gap-2 w-full justify-center">
              <Volume2 className="w-3.5 h-3.5 text-neutral-400" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={engineState.volume}
                onChange={handleVolumeChange}
                className="w-28 h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
              />
            </div>

          </div>

        </div>

        {/* Realtime Audio Waveform Spectrum */}
        <div className="mt-6 pt-4 border-t border-neutral-800/80">
          <canvas
            ref={canvasRef}
            width={800}
            height={60}
            className="w-full h-16 rounded-xl bg-neutral-950/60 border border-neutral-800/60 shadow-inner"
          />
        </div>

      </div>

      {/* DJ Quick Sound Effects Soundboard */}
      <div className="bg-neutral-900/70 border border-neutral-800 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mic2 className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-black text-white uppercase tracking-wider">
              DJ Sound Effects & Party Drops (Live Soundboard)
            </h3>
          </div>
          <span className="text-[10px] text-neutral-400">Instant audio triggers for room & stream</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
          {DJ_SOUND_EFFECTS.map((fx) => (
            <button
              key={fx.id}
              onClick={() => handlePlaySoundEffect(fx)}
              className="p-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 hover:border-amber-500/50 flex flex-col items-center justify-center gap-1 transition-all active:scale-95 group"
            >
              <span className="text-xl group-hover:scale-110 transition-transform">{fx.icon}</span>
              <span className="text-[11px] font-bold text-neutral-300 group-hover:text-white truncate max-w-full">
                {fx.name.split(' ').slice(1).join(' ')}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Music Catalog Explorer */}
      <div className="space-y-4">
        
        {/* Category Filters & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {['All', 'Bollywood', 'Punjabi', 'LoFi', 'EDM', 'Sufi'].map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  playSoundFX('click');
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                  selectedCategory === cat
                    ? 'bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-600/30'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border-neutral-800 hover:bg-neutral-800'
                }`}
              >
                {cat === 'All' && '🔥 All Tracks'}
                {cat === 'Bollywood' && '🎬 Bollywood & Romantic'}
                {cat === 'Punjabi' && '⚡ Punjabi & Desi'}
                {cat === 'LoFi' && '🎧 Lo-Fi Chill'}
                {cat === 'EDM' && '💃 EDM & Club'}
                {cat === 'Sufi' && '🌙 Sufi & Soul'}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              type="text"
              placeholder="Search song, singer, mood..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs placeholder:text-neutral-500 focus:outline-none focus:border-rose-500"
            />
          </div>

        </div>

        {/* Songs Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredTracks.map((track) => {
            const isThisTrackPlaying = engineState.isPlaying && current?.id === track.id;
            const isLiked = likedTracks.has(track.id);

            return (
              <div
                key={track.id}
                onClick={() => handlePlayTrack(track)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 group relative overflow-hidden ${
                  current?.id === track.id
                    ? 'bg-rose-950/30 border-rose-500/60 ring-1 ring-rose-500/30 shadow-lg'
                    : 'bg-neutral-900/60 hover:bg-neutral-850 border-neutral-800'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  {/* Thumbnail & Play Icon */}
                  <div className="relative w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 bg-neutral-800">
                    <img
                      src={track.coverUrl}
                      alt={track.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div
                      className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${
                        isThisTrackPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                      }`}
                    >
                      {isThisTrackPlaying ? (
                        <Pause className="w-5 h-5 text-white fill-current" />
                      ) : (
                        <Play className="w-5 h-5 text-white fill-current ml-0.5" />
                      )}
                    </div>
                  </div>

                  {/* Title & Artist */}
                  <div className="min-w-0 space-y-0.5">
                    <h4 className="text-xs font-bold text-white truncate group-hover:text-rose-300 transition-colors">
                      {track.title}
                    </h4>
                    <p className="text-[11px] text-neutral-400 truncate">
                      {track.artist}
                    </p>
                    <div className="flex items-center gap-2 text-[10px] text-neutral-500 font-mono">
                      <span>{formatTime(track.duration)}</span>
                      <span>•</span>
                      <span>{track.bpm} BPM</span>
                      <span>•</span>
                      <span className="text-rose-400 font-sans">{track.category}</span>
                    </div>
                  </div>
                </div>

                {/* Right Actions */}
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button
                    onClick={(e) => toggleLike(track.id, e)}
                    className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 transition-colors"
                  >
                    <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePlayTrack(track);
                    }}
                    className={`p-2 rounded-xl transition-all ${
                      isThisTrackPlaying
                        ? 'bg-rose-600 text-white'
                        : 'bg-neutral-800 hover:bg-rose-600 text-neutral-300 hover:text-white'
                    }`}
                  >
                    {isThisTrackPlaying ? (
                      <Pause className="w-3.5 h-3.5 fill-current" />
                    ) : (
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {filteredTracks.length === 0 && (
          <div className="p-8 text-center rounded-2xl bg-neutral-900/40 border border-neutral-800 space-y-2">
            <Music className="w-8 h-8 text-neutral-500 mx-auto" />
            <p className="text-sm font-bold text-neutral-400">No songs found matching "{searchQuery}"</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="px-3 py-1 rounded-xl bg-neutral-800 text-xs text-white hover:bg-neutral-700"
            >
              Reset Filters
            </button>
          </div>
        )}

      </div>

    </div>
  );
};
