import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Smile, 
  DollarSign, 
  BarChart3, 
  HelpCircle, 
  MessageSquare, 
  ShieldAlert, 
  CheckCircle2, 
  Sparkles, 
  Flame, 
  Heart, 
  ThumbsUp, 
  Pin,
  TrendingUp,
  Gift
} from 'lucide-react';
import { ChatMessage, StreamPoll, QAItem } from '../types';
import { CHAT_GENERATION_BANK, INITIAL_CHAT_MESSAGES } from '../data/mockStreams';
import { playSoundFX } from '../utils/audioSynth';
import { BottomGiftSheet, GiftSheetItem } from './gifts/BottomGiftSheet';
import { VipBadge } from './badges/VipBadge';
import { HostAvatarWithFrame } from './HostAvatarWithFrame';
import confetti from 'canvas-confetti';

interface LiveChatProps {
  channelId: string;
  channelTitle: string;
  pinnedMessage?: {
    text: string;
    sender: string;
    time: string;
  };
  currentPoll?: StreamPoll;
  qaItems?: QAItem[];
  currentUser?: {
    id: string;
    name: string;
    avatar: string;
    coinBalance: number;
    diamondBalance: number;
    vipLevel?: number;
    role?: string;
    hostTag?: string;
    avatarFrameId?: string;
    avatarFrameUrl?: string;
  };
  onUpdateUserBalance?: (newCoins: number, newDiamonds: number) => void;
}

export const LiveChat: React.FC<LiveChatProps> = ({
  channelId,
  channelTitle,
  pinnedMessage,
  currentPoll: initialPoll,
  qaItems: initialQaItems,
  currentUser = {
    id: 'USR-8001',
    name: 'Aarav Mehta',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80&auto=format&fit=crop&q=80',
    coinBalance: 245000,
    diamondBalance: 18500,
    vipLevel: 8,
    role: 'SUPER_ADMIN',
    hostTag: 'CELEBRATE',
    avatarFrameId: 'FRM-CYBER-NEON',
    avatarFrameUrl: undefined
  },
  onUpdateUserBalance
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'poll' | 'qa' | 'stats'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSuperChatOpen, setIsSuperChatOpen] = useState(false);
  const [isGiftSheetOpen, setIsGiftSheetOpen] = useState(false);
  const [superChatAmount, setSuperChatAmount] = useState(5);
  const [superChatMessage, setSuperChatMessage] = useState('');
  const [poll, setPoll] = useState<StreamPoll | undefined>(initialPoll);
  const [qaList, setQaList] = useState<QAItem[]>(initialQaItems || []);
  const [newQuestionText, setNewQuestionText] = useState('');
  const [isAutoScrollPaused, setIsAutoScrollPaused] = useState(false);

  const chatContainerRef = useRef<HTMLDivElement | null>(null);

  // Load initial messages for this channel
  useEffect(() => {
    const existing = INITIAL_CHAT_MESSAGES[channelId] || [
      {
        id: 'init-1',
        user: 'StreamMod',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80&auto=format&fit=crop&q=80',
        badge: 'Mod',
        message: `Welcome to the DIYO LIVE official broadcast! Chat rules apply.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'system'
      }
    ];
    setMessages(existing);
    setPoll(initialPoll);
    setQaList(initialQaItems || []);
  }, [channelId]);

  // Periodic simulation of active live chat incoming messages
  useEffect(() => {
    const timer = setInterval(() => {
      if (Math.random() > 0.35) {
        const randomText = CHAT_GENERATION_BANK[Math.floor(Math.random() * CHAT_GENERATION_BANK.length)];
        const randomUsers = ['Leo_Gamer', 'AriaWave', 'Speedy99', 'CosmoTech', 'LunaStream', 'NovaBlast', 'Vortex_4K', 'RohanKing', 'PoojaStar'];
        const randomBadges: ('VIP' | 'Sub' | 'TopFan' | undefined)[] = ['VIP', 'VIP', 'Sub', 'TopFan', undefined];
        const randomVipLevels = [1, 2, 3, 4, 5, 6, 7, 8, 9];
        const randomUser = randomUsers[Math.floor(Math.random() * randomUsers.length)];
        const randomBadge = randomBadges[Math.floor(Math.random() * randomBadges.length)];
        const randomVip = randomBadge === 'VIP' 
          ? randomVipLevels[Math.floor(Math.random() * randomVipLevels.length)] 
          : Math.random() > 0.5 ? randomVipLevels[Math.floor(Math.random() * randomVipLevels.length)] : undefined;

        const newMsg: ChatMessage = {
          id: Math.random().toString(),
          user: randomUser,
          avatar: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 50000000)}?w=80&auto=format&fit=crop&q=80`,
          badge: randomBadge,
          vipLevel: randomVip,
          message: randomText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          type: 'chat'
        };

        setMessages((prev) => [...prev.slice(-60), newMsg]);
      }
    }, 3800);

    return () => clearInterval(timer);
  }, []);

  // Auto scroll to bottom
  useEffect(() => {
    if (!isAutoScrollPaused && chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isAutoScrollPaused]);

  // Send regular message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    playSoundFX('click');
    const newMsg: ChatMessage = {
      id: Math.random().toString(),
      user: currentUser?.name ? `${currentUser.name} (You)` : 'You (Broadcaster VIP)',
      avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&auto=format&fit=crop&q=80',
      avatarFrameId: currentUser?.avatarFrameId,
      avatarFrameUrl: currentUser?.avatarFrameUrl,
      role: currentUser?.role,
      hostTag: currentUser?.hostTag,
      badge: (currentUser?.vipLevel && currentUser.vipLevel > 0) ? 'VIP' : undefined,
      vipLevel: currentUser?.vipLevel ?? 0,
      message: inputText.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'chat'
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');
  };

  // Send Super Chat donation
  const handleSendSuperChat = () => {
    if (!superChatMessage.trim() && superChatAmount <= 0) return;

    playSoundFX('superchat');
    confetti({
      particleCount: 70,
      spread: 70,
      origin: { y: 0.6 }
    });

    const superMsg: ChatMessage = {
      id: Math.random().toString(),
      user: currentUser?.name ? `${currentUser.name} (You)` : 'You',
      avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&auto=format&fit=crop&q=80',
      avatarFrameId: currentUser?.avatarFrameId,
      avatarFrameUrl: currentUser?.avatarFrameUrl,
      role: currentUser?.role,
      hostTag: currentUser?.hostTag,
      badge: (currentUser?.vipLevel && currentUser.vipLevel > 0) ? 'VIP' : undefined,
      vipLevel: currentUser?.vipLevel ?? 0,
      message: superChatMessage.trim() || 'Supported the live broadcast!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'superchat',
      amount: superChatAmount,
      currency: '$',
      color: superChatAmount >= 20 ? 'rose' : superChatAmount >= 10 ? 'amber' : 'emerald'
    };

    setMessages((prev) => [...prev, superMsg]);
    setIsSuperChatOpen(false);
    setSuperChatMessage('');
  };

  // Vote in Poll
  const handleVotePoll = (optionId: string) => {
    if (!poll || poll.userVotedOptionId) return;
    playSoundFX('vote');
    setPoll({
      ...poll,
      userVotedOptionId: optionId,
      totalVotes: (poll.totalVotes || 0) + 1,
      options: (poll.options || []).map((opt) => 
        opt.id === optionId ? { ...opt, votes: (opt.votes || 0) + 1 } : opt
      )
    });
  };

  // Upvote Question in Q&A
  const handleUpvoteQA = (id: string) => {
    playSoundFX('vote');
    setQaList((prev) =>
      prev.map((q) =>
        q.id === id
          ? {
              ...q,
              upvotes: q.userUpvoted ? q.upvotes - 1 : q.upvotes + 1,
              userUpvoted: !q.userUpvoted
            }
          : q
      )
    );
  };

  // Submit Q&A question
  const handleSubmitQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuestionText.trim()) return;

    playSoundFX('notification');
    const newQ: QAItem = {
      id: Math.random().toString(),
      user: currentUser?.name ? `${currentUser.name} (You)` : 'You',
      avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&auto=format&fit=crop&q=80',
      avatarFrameId: currentUser?.avatarFrameId,
      avatarFrameUrl: currentUser?.avatarFrameUrl,
      role: currentUser?.role,
      hostTag: currentUser?.hostTag,
      vipLevel: currentUser?.vipLevel ?? 0,
      question: newQuestionText.trim(),
      upvotes: 1,
      userUpvoted: true,
      isAnswered: false,
      timestamp: 'Just now'
    };

    setQaList((prev) => [newQ, ...prev]);
    setNewQuestionText('');
  };

  return (
    <div className="flex flex-col h-[560px] lg:h-[660px] bg-neutral-900/90 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-md">
      
      {/* Chat Top Header & Tab Navigation */}
      <div className="bg-neutral-950 border-b border-neutral-800 p-2.5">
        <div className="flex items-center justify-between pb-2 border-b border-neutral-800/60 mb-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">Live Stream Chat</span>
          </div>
          <span className="text-[10px] font-mono text-neutral-400">DIYO LIVE</span>
        </div>

        {/* Tab Buttons */}
        <div className="grid grid-cols-4 gap-1 bg-neutral-900 p-1 rounded-xl border border-neutral-800 text-[11px] font-semibold">
          <button
            id="tab-live-chat"
            onClick={() => setActiveTab('chat')}
            className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg transition-all ${
              activeTab === 'chat' ? 'bg-neutral-800 text-white shadow-sm font-bold' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <MessageSquare className="w-3 h-3 text-rose-400" />
            <span>Chat</span>
          </button>

          <button
            id="tab-live-poll"
            onClick={() => setActiveTab('poll')}
            className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg transition-all relative ${
              activeTab === 'poll' ? 'bg-neutral-800 text-white shadow-sm font-bold' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <BarChart3 className="w-3 h-3 text-amber-400" />
            <span>Poll</span>
            {poll?.isActive && !poll.userVotedOptionId && (
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 absolute top-1 right-1 animate-ping" />
            )}
          </button>

          <button
            id="tab-live-qa"
            onClick={() => setActiveTab('qa')}
            className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg transition-all ${
              activeTab === 'qa' ? 'bg-neutral-800 text-white shadow-sm font-bold' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <HelpCircle className="w-3 h-3 text-cyan-400" />
            <span>Q&A</span>
          </button>

          <button
            id="tab-live-stats"
            onClick={() => setActiveTab('stats')}
            className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg transition-all ${
              activeTab === 'stats' ? 'bg-neutral-800 text-white shadow-sm font-bold' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <TrendingUp className="w-3 h-3 text-emerald-400" />
            <span>Stats</span>
          </button>
        </div>
      </div>

      {/* Pinned Broadcaster Alert */}
      {pinnedMessage && (
        <div className="bg-rose-950/40 border-b border-rose-800/40 px-3 py-2 flex items-start gap-2 text-xs">
          <Pin className="w-3.5 h-3.5 text-rose-400 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <span className="font-bold text-rose-400 text-[11px] mr-1">{pinnedMessage.sender}:</span>
            <span className="text-neutral-200 text-[11px] leading-relaxed">{pinnedMessage.text}</span>
          </div>
        </div>
      )}

      {/* Tab 1: Live Chat Message Feed */}
      {activeTab === 'chat' && (
        <div className="flex-1 flex flex-col min-h-0">
          <div
            id="sr-chat-messages-container"
            ref={chatContainerRef}
            onMouseEnter={() => setIsAutoScrollPaused(true)}
            onMouseLeave={() => setIsAutoScrollPaused(false)}
            className="flex-1 overflow-y-auto p-3 space-y-2.5 scroll-smooth"
          >
            {(messages || []).map((msg) => {
              const isUser = msg.user.includes('You') || (currentUser?.name && msg.user.startsWith(currentUser.name));
              const activeFrameId = msg.avatarFrameId || (isUser ? currentUser?.avatarFrameId : undefined);
              const activeFrameUrl = msg.avatarFrameUrl || (isUser ? currentUser?.avatarFrameUrl : undefined);
              const activeRole = msg.role || (isUser ? currentUser?.role : undefined);
              const activeHostTag = msg.hostTag || (isUser ? currentUser?.hostTag : undefined);

              if (msg.type === 'superchat') {
                return (
                  <div
                    key={msg.id}
                    className="p-3 rounded-xl bg-gradient-to-r from-amber-600/20 via-rose-600/20 to-neutral-900 border border-amber-500/40 shadow-lg animate-in fade-in"
                  >
                    <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-amber-500/20">
                      <div className="flex items-center gap-2 flex-wrap">
                        <HostAvatarWithFrame
                          avatarUrl={msg.avatar}
                          frameId={activeFrameId}
                          frameUrl={activeFrameUrl}
                          role={activeRole}
                          hostTag={activeHostTag}
                          vipLevel={msg.vipLevel}
                          size="xs"
                        />
                        <span className="text-xs font-bold text-white">{msg.user}</span>
                        {/* Visual VIP Badge */}
                        {msg.vipLevel ? (
                          <VipBadge level={msg.vipLevel} size="xs" />
                        ) : (
                          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-500/30 text-amber-300">
                            {msg.badge || 'SUPPORTER'}
                          </span>
                        )}
                      </div>
                      <span className="text-xs font-extrabold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/30">
                        {msg.currency || '$'}{msg.amount} Super Chat
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-white leading-relaxed">{msg.message}</p>
                  </div>
                );
              }

              if (msg.type === 'system') {
                return (
                  <div key={msg.id} className="py-1 px-2.5 rounded-lg bg-neutral-950/60 border border-neutral-800/60 text-[11px] text-neutral-400 italic">
                    {msg.message}
                  </div>
                );
              }

              return (
                <div key={msg.id} className="flex items-start gap-2 text-xs group hover:bg-neutral-800/40 p-1 rounded-lg transition-colors">
                  <div className="flex-shrink-0 mt-0.5">
                    <HostAvatarWithFrame
                      avatarUrl={msg.avatar}
                      frameId={activeFrameId}
                      frameUrl={activeFrameUrl}
                      role={activeRole}
                      hostTag={activeHostTag}
                      vipLevel={msg.vipLevel}
                      size="xs"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-neutral-200 hover:text-white cursor-pointer">{msg.user}</span>
                      {/* Visual VIP Badge based on vipLevel */}
                      {msg.vipLevel ? (
                        <VipBadge level={msg.vipLevel} size="xs" />
                      ) : msg.badge === 'VIP' ? (
                        <VipBadge level={7} size="xs" />
                      ) : null}
                      {msg.badge === 'Mod' && (
                        <span className="text-[9px] font-bold px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          MOD
                        </span>
                      )}
                      {msg.badge === 'Sub' && (
                        <span className="text-[9px] font-bold px-1 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          SUB
                        </span>
                      )}
                      {msg.badge === 'TopFan' && (
                        <span className="text-[9px] font-bold px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          TOP FAN
                        </span>
                      )}
                      <span className="text-[10px] text-neutral-500 font-mono">{msg.timestamp}</span>
                    </div>
                    <p className="text-neutral-300 break-words mt-0.5 leading-relaxed">{msg.message}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Chat Reaction Bar */}
          <div className="px-3 py-1.5 bg-neutral-950/80 border-t border-neutral-800/80 flex items-center justify-between gap-1 text-xs">
            <div className="flex items-center gap-1">
              {['🔥', '👏', '⚽', '❤️', '🚀', '💯'].map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => setInputText((prev) => prev + emoji)}
                  className="px-1.5 py-0.5 rounded hover:bg-neutral-800 text-sm transition-transform active:scale-125"
                >
                  {emoji}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              <button
                id="btn-open-gift-sheet"
                onClick={() => setIsGiftSheetOpen(true)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-pink-500/20 hover:bg-pink-500/30 text-pink-400 border border-pink-500/40 text-[11px] font-bold transition-all"
              >
                <Gift className="w-3 h-3" />
                <span>Gift</span>
              </button>

              <button
                id="btn-open-superchat"
                onClick={() => setIsSuperChatOpen(!isSuperChatOpen)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/40 text-[11px] font-bold transition-all"
              >
                <DollarSign className="w-3 h-3" />
                <span>Super Chat</span>
              </button>
            </div>
          </div>

          {/* Super Chat Modal Drawer */}
          {isSuperChatOpen && (
            <div className="bg-neutral-950 border-t border-amber-500/40 p-3 space-y-2.5 animate-in slide-in-from-bottom-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> Send Super Chat Highlight
                </span>
                <button onClick={() => setIsSuperChatOpen(false)} className="text-xs text-neutral-400 hover:text-white">✕</button>
              </div>

              {/* Amount Pills */}
              <div className="flex items-center gap-1.5">
                {[2, 5, 10, 20, 50].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setSuperChatAmount(amt)}
                    className={`flex-1 py-1 text-xs font-bold rounded-lg transition-all ${
                      superChatAmount === amt
                        ? 'bg-amber-500 text-neutral-950 font-black shadow-md'
                        : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>

              <input
                type="text"
                placeholder="Type your highlighted message..."
                value={superChatMessage}
                onChange={(e) => setSuperChatMessage(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
              />

              <button
                id="btn-submit-superchat"
                onClick={handleSendSuperChat}
                className="w-full py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-xs rounded-xl shadow-lg transition-all"
              >
                Send ${superChatAmount} Super Chat
              </button>
            </div>
          )}

          {/* Regular Message Input Form */}
          <form onSubmit={handleSendMessage} className="p-2.5 bg-neutral-950 border-t border-neutral-800 flex items-center gap-2">
            <input
              id="live-chat-input"
              type="text"
              placeholder="Send a live message..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500/50"
            />
            <button
              id="btn-send-chat"
              type="submit"
              disabled={!inputText.trim()}
              className="p-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:hover:bg-rose-600 text-white transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* Tab 2: Polls & Predictions */}
      {activeTab === 'poll' && (
        <div className="flex-1 p-4 space-y-4 overflow-y-auto">
          {poll ? (
            <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <BarChart3 className="w-4 h-4" /> Live Audience Poll
                </span>
                <span className="text-[10px] font-mono text-neutral-400 bg-neutral-900 px-2 py-0.5 rounded-full">
                  {(poll.totalVotes ?? 0).toLocaleString()} votes
                </span>
              </div>

              <h3 className="text-sm font-bold text-white leading-snug">{poll.question}</h3>

              {/* Options */}
              <div className="space-y-2 pt-1">
                {(poll.options || []).map((option) => {
                  const percentage = poll.totalVotes > 0 ? Math.round((option.votes / poll.totalVotes) * 100) : 0;
                  const isUserPick = poll.userVotedOptionId === option.id;

                  return (
                    <button
                      key={option.id}
                      id={`poll-opt-${option.id}`}
                      disabled={Boolean(poll.userVotedOptionId)}
                      onClick={() => handleVotePoll(option.id)}
                      className={`relative w-full text-left p-3 rounded-xl border transition-all overflow-hidden ${
                        isUserPick
                          ? 'border-amber-500 bg-amber-500/15 ring-1 ring-amber-500'
                          : 'border-neutral-800 bg-neutral-900 hover:border-neutral-700 hover:bg-neutral-850'
                      }`}
                    >
                      {/* Vote Percentage Fill Bar */}
                      {poll.userVotedOptionId && (
                        <div
                          className="absolute inset-y-0 left-0 bg-gradient-to-r from-amber-500/20 to-amber-500/5 transition-all duration-700"
                          style={{ width: `${percentage}%` }}
                        />
                      )}

                      <div className="relative z-10 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-white">{option.text}</span>
                          {isUserPick && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        {poll.userVotedOptionId && (
                          <span className="font-mono font-bold text-amber-400">{percentage}%</span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {poll.userVotedOptionId ? (
                <p className="text-[11px] text-emerald-400 text-center font-medium pt-1">
                  ✓ Your vote has been recorded live!
                </p>
              ) : (
                <p className="text-[11px] text-neutral-400 text-center pt-1">
                  Tap any option above to cast your live vote
                </p>
              )}
            </div>
          ) : (
            <div className="text-center py-12 text-neutral-500 text-xs">
              No active polls right now on this channel.
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Live Q&A */}
      {activeTab === 'qa' && (
        <div className="flex-1 flex flex-col min-h-0">
          <div className="flex-1 p-3 space-y-2.5 overflow-y-auto">
            {(qaList || []).map((qa) => {
              const isUser = qa.user.includes('You') || (currentUser?.name && qa.user.startsWith(currentUser.name));
              const activeFrameId = qa.avatarFrameId || (isUser ? currentUser?.avatarFrameId : undefined);
              const activeFrameUrl = qa.avatarFrameUrl || (isUser ? currentUser?.avatarFrameUrl : undefined);
              const activeRole = qa.role || (isUser ? currentUser?.role : undefined);
              const activeHostTag = qa.hostTag || (isUser ? currentUser?.hostTag : undefined);

              return (
                <div key={qa.id} className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <HostAvatarWithFrame
                        avatarUrl={qa.avatar}
                        frameId={activeFrameId}
                        frameUrl={activeFrameUrl}
                        role={activeRole}
                        hostTag={activeHostTag}
                        vipLevel={qa.vipLevel}
                        size="xs"
                      />
                      <span className="text-xs font-bold text-white">{qa.user}</span>
                      <span className="text-[10px] text-neutral-500">{qa.timestamp}</span>
                    </div>
                    {qa.isAnswered ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        Answered Live
                      </span>
                    ) : (
                      <span className="text-[10px] text-neutral-400">Pending</span>
                    )}
                  </div>

                  <p className="text-xs text-neutral-200 font-medium leading-relaxed">{qa.question}</p>

                  <div className="flex justify-end pt-1">
                    <button
                      onClick={() => handleUpvoteQA(qa.id)}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all border ${
                        qa.userUpvoted
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                          : 'bg-neutral-900 text-neutral-400 hover:text-white border-neutral-800'
                      }`}
                    >
                      <ThumbsUp className="w-3 h-3" />
                      <span>{qa.upvotes}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Ask Question Form */}
          <form onSubmit={handleSubmitQuestion} className="p-2.5 bg-neutral-950 border-t border-neutral-800 flex items-center gap-2">
            <input
              type="text"
              placeholder="Ask the broadcaster a question..."
              value={newQuestionText}
              onChange={(e) => setNewQuestionText(e.target.value)}
              className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-cyan-500"
            />
            <button
              type="submit"
              disabled={!newQuestionText.trim()}
              className="p-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* Tab 4: Real-time Stats */}
      {activeTab === 'stats' && (
        <div className="flex-1 p-4 space-y-3 overflow-y-auto text-xs">
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 space-y-2">
            <span className="text-neutral-400 font-bold uppercase tracking-wider text-[10px]">Chat Velocity</span>
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-extrabold text-white font-mono">142</span>
              <span className="text-emerald-400 font-semibold text-[11px]">messages/min</span>
            </div>
          </div>

          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 space-y-2">
            <span className="text-neutral-400 font-bold uppercase tracking-wider text-[10px]">Top Active Regions</span>
            <div className="space-y-1 text-neutral-300 font-mono text-[11px]">
              <div className="flex justify-between">
                <span>🇪🇸 Europe (West)</span>
                <span className="text-white font-bold">42%</span>
              </div>
              <div className="flex justify-between">
                <span>🇺🇸 Americas</span>
                <span className="text-white font-bold">34%</span>
              </div>
              <div className="flex justify-between">
                <span>🇯🇵 Asia-Pacific</span>
                <span className="text-white font-bold">24%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Flutter-style Bottom Gift Sheet */}
      <BottomGiftSheet
        isOpen={isGiftSheetOpen}
        onClose={() => setIsGiftSheetOpen(false)}
        initialCoins={currentUser.coinBalance}
        initialDiamonds={currentUser.diamondBalance}
        senderId={currentUser.id}
        senderName={currentUser.name}
        roomSeats={['Self', 'Host (Seat 1)', 'Broadcaster', 'All 20 Seats']}
        onSendSuccess={({ gift, target, multiplier, reward, totalCost, isSelfGift, diamondsEarned, newBalance, newDiamonds }) => {
          if (onUpdateUserBalance) {
            onUpdateUserBalance(newBalance, newDiamonds);
          }

          const isLuckyWin = (reward ?? 0) > 0;
          let msgText = '';
          if (isSelfGift) {
            msgText = isLuckyWin
              ? `🎁 Sent ${multiplier}x ${gift.name} to Self (LUCKY HIT +${(reward ?? 0).toLocaleString()} TC & +${(diamondsEarned ?? 0).toLocaleString()} 💎 in Withdrawal Wallet!)`
              : `🎁 Sent ${multiplier}x ${gift.name} to Self → +${(diamondsEarned ?? 0).toLocaleString()} Withdrawable Diamonds 💎 in Wallet!`;
          } else if (isLuckyWin) {
            msgText = `🎁 Sent ${multiplier}x ${gift.name} to ${target} and hit a LUCKY REWARD of +${(reward ?? 0).toLocaleString()} TC & +${(diamondsEarned ?? 0).toLocaleString()} 💎 in Withdrawal Wallet!`;
          } else {
            msgText = `🎁 Sent ${multiplier}x ${gift.name} (${gift.icon}) to ${target}! (+${(diamondsEarned ?? 0).toLocaleString()} 💎 Withdrawable)`;
          }

          const newMsg: ChatMessage = {
            id: Math.random().toString(),
            user: currentUser.name,
            avatar: currentUser.avatar,
            badge: (currentUser?.vipLevel && currentUser.vipLevel > 0) ? 'VIP' : undefined,
            vipLevel: currentUser?.vipLevel ?? 0,
            message: msgText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            type: 'superchat',
            amount: totalCost
          };
          setMessages((prev) => [...prev.slice(-60), newMsg]);
        }}
      />
    </div>
  );
};
