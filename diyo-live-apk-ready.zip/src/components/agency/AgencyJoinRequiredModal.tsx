import React from 'react';
import { Building2, ShieldAlert, ArrowRight, CheckCircle2, Clock, X } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface AgencyJoinRequiredModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAgencySearch: () => void;
  pendingRequest?: {
    agencyName: string;
    requestDate: string;
  } | null;
}

export const AgencyJoinRequiredModal: React.FC<AgencyJoinRequiredModalProps> = ({
  isOpen,
  onClose,
  onOpenAgencySearch,
  pendingRequest
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#0e142a] via-[#0a0f22] to-[#060918] border border-rose-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4">
        
        {/* Close Button */}
        <button
          onClick={() => {
            playSoundFX('click');
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Warning Header Icon */}
        <div className="text-center pt-2">
          <div className="w-14 h-14 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto mb-3 shadow-[0_0_20px_rgba(244,63,94,0.3)]">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-black tracking-wider uppercase">
            Host Governance Rule
          </span>
          <h3 className="text-base sm:text-lg font-black text-white mt-2">
            Agency Membership Required
          </h3>
          <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
            A Host cannot start any Live broadcast session until successfully joining an approved Agency on DIYO LIVE.
          </p>
        </div>

        {/* Status Notice */}
        {pendingRequest ? (
          <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 space-y-1">
            <div className="flex items-center gap-2 text-amber-300 text-xs font-black">
              <Clock className="w-4 h-4 text-amber-400 animate-spin" />
              <span>Join Request Pending Approval</span>
            </div>
            <p className="text-[11px] text-amber-200/80 leading-tight">
              Your request to join <strong>{pendingRequest.agencyName}</strong> has been submitted and is awaiting approval from the Agency Owner.
            </p>
          </div>
        ) : (
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
            <div className="flex items-center gap-2 text-neutral-300 text-xs font-bold">
              <Building2 className="w-4 h-4 text-cyan-400" />
              <span>Current Status: No Active Agency</span>
            </div>
            <p className="text-[11px] text-neutral-400 leading-tight">
              Please search for an Agency ID or name and submit a join request to get verified.
            </p>
          </div>
        )}

        {/* Step-by-Step Flow */}
        <div className="p-3 rounded-2xl bg-[#090d20] border border-white/10 space-y-2">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-cyan-400 block">
            Required Host Activation Flow
          </span>
          <div className="space-y-1.5 text-[11px] text-neutral-300">
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-full bg-cyan-500/20 text-cyan-300 text-[9px] font-black flex items-center justify-center flex-shrink-0">1</span>
              <span>Search & Select official Agency by ID / Name</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-full bg-cyan-500/20 text-cyan-300 text-[9px] font-black flex items-center justify-center flex-shrink-0">2</span>
              <span>Submit your formal Agency Join Request</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-full bg-cyan-500/20 text-cyan-300 text-[9px] font-black flex items-center justify-center flex-shrink-0">3</span>
              <span>Agency Owner / Admin reviews & approves</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span className="font-bold text-emerald-300">Go Live broadcast studio automatically unlocked</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 pt-1">
          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
              onOpenAgencySearch();
            }}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-teal-500 via-emerald-600 to-cyan-600 hover:from-teal-400 hover:to-cyan-500 text-white font-black text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
          >
            <Building2 className="w-4 h-4" />
            <span>Search & Join Agency Now</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white text-xs font-bold transition-colors cursor-pointer"
          >
            I'll Join Later
          </button>
        </div>

      </div>
    </div>
  );
};
