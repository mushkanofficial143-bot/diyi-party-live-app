import React, { useState } from 'react';
import { PartyLiveHomeScreen } from './PartyLiveHomeScreen';

interface ExploreScreenProps {
  onSelectStream: (streamId: string) => void;
  onOpenGoLive: () => void;
  onOpenVideoLive: () => void;
  onOpenPartyLive: () => void;
  onOpenLeaderboard?: () => void;
  banners?: any[];
  onUpdateBanners?: (banners: any[]) => void;
  liveRooms?: any[];
  currentUser?: any;
  hasApprovedAgency?: boolean;
}

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  onSelectStream,
  onOpenGoLive,
  onOpenVideoLive,
  onOpenPartyLive,
  onOpenLeaderboard,
  banners = [],
  onUpdateBanners,
  liveRooms = [],
  currentUser,
  hasApprovedAgency = false
}) => {
  return (
    <PartyLiveHomeScreen
      banners={banners}
      onUpdateBanners={onUpdateBanners}
      liveRooms={liveRooms}
      currentUser={currentUser}
      hasApprovedAgency={hasApprovedAgency}
      onSelectRoom={onSelectStream}
      onOpenGoLive={onOpenGoLive}
      onOpenVideoLive={onOpenVideoLive}
      onOpenPartyLive={onOpenPartyLive}
      onOpenLeaderboard={onOpenLeaderboard || (() => {})}
      onOpenSearch={() => {
        // Trigger search modal or scroll to search
      }}
      onOpenCalendar={() => {
        // Open events calendar
      }}
    />
  );
};
