import React, { useState, useRef } from 'react';
import { 
  X, 
  Image as ImageIcon, 
  Upload, 
  Camera, 
  Trash2, 
  Sparkles, 
  CheckCircle2, 
  Globe, 
  Plus, 
  Eye, 
  Layers,
  AlertCircle
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

export interface BannerItem {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  link?: string;
  badge?: string;
  targetCountry?: string;
  active: boolean;
  createdAt: string;
}

interface HomeBannerManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  banners: BannerItem[];
  onUpdateBanners: (banners: BannerItem[]) => void;
  currentUser?: any;
}

const PRESET_BANNERS = [
  {
    title: 'DIYO LIVE Grand Festival 2026',
    subtitle: 'Broadcast, Win Royal Rewards & Celebrate Worldwide',
    badge: 'OFFICIAL EVENT',
    imageUrl: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=1200&auto=format&fit=crop&q=80'
  },
  {
    title: 'Royal VIP Star Crown Gala',
    subtitle: 'Top Streamers & Gifting Champions Daily Leaderboard',
    badge: 'VIP SPOTLIGHT',
    imageUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=1200&auto=format&fit=crop&q=80'
  },
  {
    title: 'Weekend Mega Party Carnival',
    subtitle: '20-Seat Voice Lounges & Continuous Lucky Dice Thrills',
    badge: 'PARTY CARNIVAL',
    imageUrl: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=1200&auto=format&fit=crop&q=80'
  },
  {
    title: 'Live Music & Voice Talent Battle',
    subtitle: 'Sing, Connect & Win Multi-Million Coin Jackpots',
    badge: 'MUSIC FESTIVAL',
    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop&q=80'
  },
  {
    title: 'Cyber Neon DJ Night Beats',
    subtitle: 'Exclusive Animated Entrance Frames & Neon Badges',
    badge: 'NEON SPECIAL',
    imageUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=1200&auto=format&fit=crop&q=80'
  },
  {
    title: 'Global Star Host Championship',
    subtitle: 'Top 10 Agencies & Broadcasters Cash Prize Pool',
    badge: 'CHAMPIONSHIP',
    imageUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&auto=format&fit=crop&q=80'
  }
];

export const HomeBannerManagerModal: React.FC<HomeBannerManagerModalProps> = ({
  isOpen,
  onClose,
  banners = [],
  onUpdateBanners,
  currentUser
}) => {
  const [activeTab, setActiveTab] = useState<'NEW' | 'MANAGE'>('NEW');
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [badge, setBadge] = useState('GLOBAL EVENT');
  const [targetCountry, setTargetCountry] = useState('GLOBAL');
  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    playSoundFX('notification');
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please choose a valid image file (JPG, PNG, WEBP)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const result = uploadEvent.target?.result as string;
      if (result) {
        setImageUrl(result);
        playSoundFX('win');
        showToast('📸 Image loaded from your gallery!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPreset = (preset: typeof PRESET_BANNERS[0]) => {
    setTitle(preset.title);
    setSubtitle(preset.subtitle);
    setBadge(preset.badge);
    setImageUrl(preset.imageUrl);
    playSoundFX('click');
  };

  const handleSaveBanner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !imageUrl.trim()) {
      showToast('⚠️ Please provide Banner Title and Image!');
      return;
    }

    setIsSaving(true);
    playSoundFX('click');

    const newBanner: BannerItem = {
      id: `BNR-${Date.now().toString().slice(-6)}`,
      title: title.trim(),
      subtitle: subtitle.trim() || 'DIYO LIVE Official Event',
      imageUrl: imageUrl.trim(),
      badge: badge.trim() || 'GLOBAL EVENT',
      targetCountry: targetCountry || 'GLOBAL',
      active: true,
      createdAt: new Date().toISOString()
    };

    // Backend is the source of truth. Do not update the UI or localStorage before the
    // server confirms a successful persistent save.
    try {
      const res = await fetch('/api/banners/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-owner-email': currentUser?.email || 'salamstarhotel@gmail.com',
          'x-owner-id': currentUser?.id || '0000001',
          'x-role': currentUser?.role || 'OWNER'
        },
        body: JSON.stringify({ banner: newBanner })
      });
      const data = await res.json();
      if (!res.ok || !data.success || !Array.isArray(data.banners)) {
        throw new Error(data.error || 'Banner could not be persisted.');
      }
      onUpdateBanners(data.banners);
      try {
        localStorage.setItem('diyo_home_banners_persistent', JSON.stringify(data.banners));
      } catch (e) {}
      setIsSaving(false);
      playSoundFX('win');
      showToast('✨ Banner saved permanently.');
      setTitle('');
      setSubtitle('');
      setImageUrl('');
      setActiveTab('MANAGE');
      return;
    } catch (err) {
      console.error('Failed to save banner to backend:', err);
      setIsSaving(false);
      showToast(`❌ Banner save failed: ${err instanceof Error ? err.message : 'server error'}`);
      return;
    }

  };

  const handleToggleActive = async (bannerId: string) => {
    playSoundFX('click');
    try {
      const res = await fetch('/api/banners/toggle', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-owner-email': currentUser?.email || 'salamstarhotel@gmail.com',
          'x-owner-id': currentUser?.id || '0000001',
          'x-role': currentUser?.role || 'OWNER'
        },
        body: JSON.stringify({ id: bannerId, bannerId })
      });
      const data = await res.json();
      if (!res.ok || !data.success || !Array.isArray(data.banners)) throw new Error(data.error || 'Toggle failed');
      onUpdateBanners(data.banners);
      try { localStorage.setItem('diyo_home_banners_persistent', JSON.stringify(data.banners)); } catch (e) {}
    } catch (err) {
      console.error('Toggle failed in backend:', err);
      showToast(`❌ Banner update failed: ${err instanceof Error ? err.message : 'server error'}`);
    }
  };

  const handleDeleteBanner = async (bannerId: string) => {
    setDeleteConfirmId(null);
    playSoundFX('click');
    try {
      const res = await fetch('/api/banners/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-owner-email': currentUser?.email || 'salamstarhotel@gmail.com',
          'x-owner-id': currentUser?.id || '0000001',
          'x-role': currentUser?.role || 'OWNER'
        },
        body: JSON.stringify({ id: bannerId, bannerId })
      });
      const data = await res.json();
      if (!res.ok || !data.success || !Array.isArray(data.banners)) throw new Error(data.error || 'Delete failed');
      onUpdateBanners(data.banners);
      try { localStorage.setItem('diyo_home_banners_persistent', JSON.stringify(data.banners)); } catch (e) {}
      showToast('🗑️ Banner removed from Home Page.');
    } catch (err) {
      console.error('Delete failed in backend:', err);
      showToast(`❌ Banner delete failed: ${err instanceof Error ? err.message : 'server error'}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#0b0f24] border border-cyan-500/40 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col shadow-2xl shadow-cyan-950/80 relative">
        
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-cyan-900/50 flex items-center justify-between bg-[#0e1638]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-md">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white font-['Outfit'] tracking-wide">
                HOME BANNER MANAGER
              </h2>
              <p className="text-[11px] text-cyan-200/70 leading-none">
                Set permanent banners on Home Page (Stays until removed)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Toggle: Create New vs Manage Current */}
        <div className="px-5 pt-3 pb-1 border-b border-cyan-950/40 bg-[#090d20] flex items-center gap-2">
          <button
            onClick={() => {
              setActiveTab('NEW');
              playSoundFX('click');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'NEW'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white bg-neutral-900/50'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Set / Upload Banner</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('MANAGE');
              playSoundFX('click');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'MANAGE'
                ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white bg-neutral-900/50'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Active Banners ({banners.length})</span>
          </button>
        </div>

        {/* Toast */}
        {toastMessage && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Body Content */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">

          {activeTab === 'NEW' ? (
            <form onSubmit={handleSaveBanner} className="space-y-3.5">
              
              {/* Permanent Banner Guarantee Notice */}
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2 text-amber-200 text-xs">
                <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <p>
                  <strong>Permanent Home Banner:</strong> Once saved, this banner will remain on the Home Page at all times. It will never vanish until you explicitly click "Delete".
                </p>
              </div>

              {/* Banner Live Preview */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
                  <Eye className="w-3 h-3 text-cyan-400" />
                  <span>Live Home Page Preview</span>
                </label>
                <div className="relative w-full h-36 sm:h-40 rounded-2xl overflow-hidden shadow-xl border border-cyan-500/30 bg-[#050814]">
                  {imageUrl ? (
                    <img
                      src={imageUrl}
                      alt="Banner Preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-neutral-500 gap-1.5 p-4 text-center">
                      <ImageIcon className="w-8 h-8 text-neutral-600" />
                      <span className="text-xs font-medium">Select an image or upload from gallery below</span>
                    </div>
                  )}

                  {/* Gradient Overlay & Text Preview */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#070913] via-[#070913]/40 to-transparent p-3.5 flex flex-col justify-end">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[9px] font-black uppercase tracking-widest text-amber-300 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-full border border-amber-400/30 flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5 text-amber-400" />
                        {badge || 'GLOBAL EVENT'}
                      </span>
                      <span className="text-[9px] font-bold text-cyan-300 bg-cyan-950/80 backdrop-blur-md px-2 py-0.5 rounded-full border border-cyan-500/40">
                        {targetCountry === 'GLOBAL' ? '🌐 Worldwide' : `🏳️ ${targetCountry}`}
                      </span>
                    </div>
                    <h3 className="text-sm font-black text-white drop-shadow-md line-clamp-1">
                      {title || 'Your Banner Title Will Appear Here'}
                    </h3>
                    <p className="text-[11px] text-neutral-300 line-clamp-1 drop-shadow mt-0.5">
                      {subtitle || 'Your banner subtitle or description will appear here'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Image Input Options: Gallery File or URL */}
              <div className="p-3 rounded-2xl bg-[#070c20] border border-cyan-900/50 space-y-2.5">
                <label className="text-[11px] font-bold text-slate-200 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Camera className="w-3 h-3 text-cyan-400" />
                    <span>Upload Banner Image</span>
                  </span>
                  <span className="text-[10px] text-cyan-400">Mobile Gallery & Files Supported</span>
                </label>

                {/* Hidden File Input */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden"
                />

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-neutral-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition-all"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Choose from Device Gallery</span>
                  </button>
                </div>

                <div className="relative">
                  <input
                    type="url"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="Or paste direct image URL (https://...)"
                    className="w-full px-3 py-1.5 rounded-xl bg-[#050816] border border-cyan-950 text-white text-xs placeholder:text-neutral-500 focus:outline-none focus:border-cyan-400 font-mono"
                  />
                </div>

                {/* Preset Fast Picks */}
                <div className="space-y-1 pt-1">
                  <span className="text-[10px] text-neutral-400 font-bold">Or pick from ready-to-use events:</span>
                  <div className="grid grid-cols-3 gap-1.5">
                    {PRESET_BANNERS.slice(0, 3).map((p, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleSelectPreset(p)}
                        className="relative h-14 rounded-lg overflow-hidden border border-cyan-900/60 hover:border-cyan-400 transition-all cursor-pointer group"
                      >
                        <img src={p.imageUrl} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                        <div className="absolute inset-0 bg-black/50 p-1 flex items-end">
                          <span className="text-[9px] font-bold text-white line-clamp-1 leading-tight">{p.title}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Title & Badge */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-300">Banner Title *</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Grand Celebration 2026"
                    className="w-full px-3 py-2 rounded-xl bg-[#060a1c] border border-cyan-900/60 text-white text-xs font-bold focus:outline-none focus:border-cyan-400"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-300">Highlight Badge</label>
                  <input
                    type="text"
                    value={badge}
                    onChange={(e) => setBadge(e.target.value)}
                    placeholder="e.g. OFFICIAL EVENT"
                    className="w-full px-3 py-2 rounded-xl bg-[#060a1c] border border-cyan-900/60 text-amber-300 text-xs font-bold focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Subtitle / Description */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-300">Subtitle / Offer Description</label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="e.g. Join top streamers and win 5,000,000 coins"
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1c] border border-cyan-900/60 text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* Target Country */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
                  <Globe className="w-3 h-3 text-emerald-400" />
                  <span>Target Region</span>
                </label>
                <select
                  value={targetCountry}
                  onChange={(e) => setTargetCountry(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1c] border border-cyan-900/60 text-white text-xs font-bold focus:outline-none focus:border-cyan-400"
                >
                  <option value="GLOBAL">🌐 Worldwide (All Users Everywhere)</option>
                  <option value="NP">🇳🇵 Nepal Only</option>
                  <option value="IN">🇮🇳 India Only</option>
                  <option value="BD">🇧🇩 Bangladesh Only</option>
                  <option value="PK">🇵🇰 Pakistan Only</option>
                  <option value="AE">🇦🇪 UAE Only</option>
                  <option value="SA">🇸🇦 Saudi Arabia Only</option>
                  <option value="US">🇺🇸 USA Only</option>
                </select>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSaving || !title.trim() || !imageUrl.trim()}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:brightness-110 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-rose-950/60 cursor-pointer disabled:opacity-50 mt-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isSaving ? 'Posting to Home Page...' : 'Save & Keep on Home Page Forever'}</span>
              </button>
            </form>
          ) : (
            /* Tab 2: Manage Existing Banners */
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>All Banners currently on Home Page:</span>
                <span className="font-bold text-cyan-400">{banners.length} total</span>
              </div>

              {banners.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-[#060a1a] border border-cyan-950/60 space-y-2">
                  <ImageIcon className="w-8 h-8 text-neutral-600 mx-auto" />
                  <p className="text-xs text-neutral-400">No banners currently active.</p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('NEW')}
                    className="px-4 py-1.5 rounded-xl bg-cyan-500 text-neutral-950 text-xs font-bold"
                  >
                    Add First Banner
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {banners.map((b) => (
                    <div
                      key={b.id}
                      className={`p-3 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        b.active 
                          ? 'bg-[#080e26] border-cyan-500/40 shadow-md' 
                          : 'bg-[#050814] border-neutral-800 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={b.imageUrl}
                          alt={b.title}
                          className="w-16 h-12 rounded-xl object-cover border border-white/10 flex-shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                              {b.badge || 'EVENT'}
                            </span>
                            <span className="text-[9px] font-mono text-neutral-400">
                              {b.targetCountry === 'GLOBAL' ? '🌐 Global' : b.targetCountry}
                            </span>
                          </div>
                          <h4 className="text-xs font-black text-white truncate">{b.title}</h4>
                          <p className="text-[10px] text-neutral-400 truncate">{b.subtitle}</p>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-2 self-end sm:self-center flex-shrink-0">
                        {/* Toggle Active */}
                        <button
                          type="button"
                          onClick={() => handleToggleActive(b.id)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition-all ${
                            b.active
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-neutral-800 text-neutral-400'
                          }`}
                        >
                          {b.active ? '🟢 Active' : '⚪ Paused'}
                        </button>

                        {/* Explicit Delete Button */}
                        {deleteConfirmId === b.id ? (
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleDeleteBanner(b.id)}
                              className="px-2 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-black cursor-pointer shadow animate-in fade-in"
                            >
                              Confirm Remove
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteConfirmId(null)}
                              className="px-2 py-1 rounded-lg bg-neutral-800 text-neutral-400 text-[10px]"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setDeleteConfirmId(b.id);
                              playSoundFX('click');
                            }}
                            className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 cursor-pointer transition-all"
                            title="Remove banner from Home Page"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-3 border-t border-cyan-900/40 bg-[#070b1c] flex items-center justify-between text-[11px] text-neutral-400 px-4">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Changes reflect across all user screens immediately</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="font-bold text-cyan-400 hover:underline cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
