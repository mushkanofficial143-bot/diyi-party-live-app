import React, { useState, useEffect } from 'react';
import {
  Search,
  Trophy,
  Crown,
  Flame,
  Star,
  Sparkles,
  Radio,
  Calendar,
  Home,
  Users,
  Compass,
  ChevronRight,
  ShieldCheck,
  Gift,
  Heart,
  Globe,
  Tv,
  Play,
  Zap,
  Bell,
  X,
  Video,
  Lock,
  Image as ImageIcon,
  Plus
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { RankLeaderboardModal } from '../profile/RankLeaderboardModal';
import { HomeBannerManagerModal } from './HomeBannerManagerModal';

interface PartyLiveHomeScreenProps {
  banners: any[];
  onUpdateBanners?: (banners: any[]) => void;
  liveRooms: any[];
  currentUser?: any;
  hasApprovedAgency?: boolean;
  onSelectRoom: (roomId: string) => void;
  onOpenGoLive: () => void;
  onOpenVideoLive: () => void;
  onOpenPartyLive: () => void;
  onOpenLeaderboard: () => void;
  onOpenSearch: () => void;
  onOpenCalendar: () => void;
}

const DEFAULT_OFFICIAL_BANNER = {
  id: 'BNR-OFFICIAL-1',
  title: 'DIYO LIVE Grand Festival 2026',
  subtitle: 'Broadcast, Win Royal Rewards & Celebrate Worldwide',
  imageUrl: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=1200&auto=format&fit=crop&q=80',
  link: '#',
  badge: 'OFFICIAL EVENT',
  targetCountry: 'GLOBAL',
  active: true,
  createdAt: '2026-09-20'
};

export const PartyLiveHomeScreen: React.FC<PartyLiveHomeScreenProps> = ({
  banners = [],
  onUpdateBanners,
  liveRooms = [],
  currentUser,
  hasApprovedAgency = false,
  onSelectRoom,
  onOpenGoLive,
  onOpenVideoLive,
  onOpenPartyLive,
  onOpenLeaderboard,
  onOpenSearch,
  onOpenCalendar
}) => {
  const [topNavTab, setTopNavTab] = useState<'Mine' | 'Party' | 'Events'>('Party');
  const [streamTypeFilter, setStreamTypeFilter] = useState<'ALL' | 'VIDEO' | 'PARTY'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<'Popular' | 'New'>('Popular');
  const [selectedCountry, setSelectedCountry] = useState<string>('GLOBAL');
  const [isGoLiveModalOpen, setIsGoLiveModalOpen] = useState(false);
  const [activeBannerIndex, setActiveBannerIndex] = useState(0);
  const [isRankModalOpen, setIsRankModalOpen] = useState(false);
  const [isBannerModalOpen, setIsBannerModalOpen] = useState(false);
  const [rankingSubTab, setRankingSubTab] = useState<'GIFT' | 'FRIENDS' | 'FAMILY'>('GIFT');
  const [rankingPeriod, setRankingPeriod] = useState<'Daily' | 'Weekly' | 'Monthly' | 'All Time'>('Daily');

  const isOwner = Boolean(
    currentUser && (
      currentUser.role === 'OWNER' ||
      currentUser.role === 'SUPER_ADMIN' ||
      currentUser.role === 'MANAGER' ||
      currentUser.id === '0000001' ||
      currentUser.id === 'OWNER-001' ||
      currentUser.email === 'salamstarhotel@gmail.com'
    )
  );

  // Detect if the logged in user currently has an active broadcast
  const userLiveRoom = liveRooms.find(r => 
    currentUser && (
      r.hostId === currentUser.id || 
      r.hostId === currentUser.username || 
      (currentUser.id && r.hostId?.includes(currentUser.id))
    ) && (r.status === 'LIVE' || r.roomStatus === 'Active' || !r.status)
  );

  const HOME_COUNTRY_FILTERS = [
    { code: 'GLOBAL', name: 'Global', flag: '🌐' },
    { code: 'NP', name: 'Nepal', flag: '🇳🇵' },
    { code: 'IN', name: 'India', flag: '🇮🇳' },
    { code: 'BD', name: 'Bangladesh', flag: '🇧🇩' },
    { code: 'PK', name: 'Pakistan', flag: '🇵🇰' },
    { code: 'PH', name: 'Philippines', flag: '🇵🇭' },
    { code: 'AE', name: 'UAE', flag: '🇦🇪' },
    { code: 'SA', name: 'Saudi', flag: '🇸🇦' },
    { code: 'US', name: 'USA', flag: '🇺🇸' },
  ];

  // Live Activity Ticker notification
  const [activityTicker, setActivityTicker] = useState<{
    avatar: string;
    username: string;
    action: string;
    giftName: string;
  } | null>({
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
    username: 'SR Angel',
    action: 'sent a Golden Castle 🏰',
    giftName: 'Golden Castle'
  });

  // Auto-rotate banners
  useEffect(() => {
    const activeBanners = banners.filter(b => b.active);
    if (activeBanners.length <= 1) return;
    const timer = setInterval(() => {
      setActiveBannerIndex(prev => (prev + 1) % activeBanners.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [banners]);

  // Rotate activity ticker items
  useEffect(() => {
    const tickerItems = [
      { avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', username: 'Vikram Rajput', action: 'sent a Diamond Yacht 🛥️', giftName: 'Diamond Yacht' },
      { avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100', username: 'Pooja Verma', action: 'unlocked VIP 8 Status 👑', giftName: 'VIP 8' },
      { avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', username: 'Kabir Khan', action: 'joined Agency Guild AG-01 ⭐', giftName: 'Guild Join' }
    ];
    let idx = 0;
    const timer = setInterval(() => {
      idx = (idx + 1) % tickerItems.length;
      setActivityTicker(tickerItems[idx]);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const activeBanners = (banners || []).filter(b => b && b.active);
  const currentBanner = activeBanners.length > 0 
    ? activeBanners[activeBannerIndex % activeBanners.length] 
    : DEFAULT_OFFICIAL_BANNER;

  const recommendedRooms = liveRooms.filter(r => r.isRecommended || r.recommendRank);
  const displayedRooms = liveRooms.filter(r => {
    // If viewing 'Mine' tab, prioritize user's room or show all active
    if (topNavTab === 'Mine') {
      const isMyRoom = currentUser && (r.hostId === currentUser.id || r.hostId === currentUser.username || (currentUser.id && r.hostId?.includes(currentUser.id)));
      if (userLiveRoom) return isMyRoom;
    }

    const isActive = r.status === 'LIVE' || r.roomStatus === 'Active' || (!r.status && r.status !== 'ENDED');
    if (!isActive) return false;

    const isVideo = r.liveType === 'VIDEO' || (r.liveType !== 'PARTY' && r.roomType !== 'PARTY' && !r.roomId?.startsWith('LIVE-P') && !r.tag?.toLowerCase().includes('party'));
    if (streamTypeFilter === 'VIDEO' && !isVideo) return false;
    if (streamTypeFilter === 'PARTY' && isVideo) return false;

    // Current user's live room is ALWAYS shown
    const isMe = currentUser && (r.hostId === currentUser.id || r.hostId === currentUser.username || (currentUser.id && r.hostId?.includes(currentUser.id)));
    if (isMe) return true;

    // Country Filter (GLOBAL shows all rooms from every country!)
    if (selectedCountry !== 'GLOBAL') {
      const cCode = selectedCountry.toUpperCase();
      const rCountry = (r.country || '').toUpperCase();
      const rFlag = r.countryFlag || '';
      const matchesCountry = 
        (cCode === 'NP' && (rCountry.includes('NEPAL') || rFlag === '🇳🇵')) ||
        (cCode === 'IN' && (rCountry.includes('INDIA') || rFlag === '🇮🇳')) ||
        (cCode === 'BD' && (rCountry.includes('BANGLADESH') || rFlag === '🇧🇩')) ||
        (cCode === 'PK' && (rCountry.includes('PAKISTAN') || rFlag === '🇵🇰')) ||
        (cCode === 'PH' && (rCountry.includes('PHILIPPINES') || rFlag === '🇵🇭')) ||
        (cCode === 'AE' && (rCountry.includes('EMIRATES') || rCountry.includes('UAE') || rFlag === '🇦🇪')) ||
        (cCode === 'SA' && (rCountry.includes('SAUDI') || rFlag === '🇸🇦')) ||
        (cCode === 'US' && (rCountry.includes('UNITED STATES') || rCountry.includes('USA') || rFlag === '🇺🇸'));
      if (!matchesCountry) return false;
    }

    if (categoryFilter === 'New') return (r.tag?.includes('New') || r.createdAt || r.startedAt);
    return true; // Popular
  }).sort((a, b) => {
    // Current user's broadcast ALWAYS sits at the top position (#1) on Home page!
    const aIsMe = currentUser && (a.hostId === currentUser.id || a.hostId === currentUser.username || (currentUser.id && a.hostId?.includes(currentUser.id)));
    const bIsMe = currentUser && (b.hostId === currentUser.id || b.hostId === currentUser.username || (currentUser.id && b.hostId?.includes(currentUser.id)));
    if (aIsMe && !bIsMe) return -1;
    if (!aIsMe && bIsMe) return 1;
    return 0;
  });

  return (
    <div
      id="party-live-home-screen"
      className="w-full max-w-md md:max-w-lg mx-auto min-h-screen bg-[#070913] text-white pt-safe-top pb-56 select-none animate-in fade-in"
    >
      {/* ========================================================================= */}
      {/* 1. TOP HEADER / MAIN NAVIGATION                                           */}
      {/* ========================================================================= */}
      <header className="sticky top-0 z-40 bg-[#070913]/95 backdrop-blur-2xl px-4 pt-3 pb-2.5 flex items-center justify-between border-b border-white/10 shadow-lg">
        
        {/* 3 Main Tabs: Mine | Party | Events */}
        <div className="flex items-center gap-1.5 bg-[#11152d] p-1 rounded-full border border-white/10">
          {(['Mine', 'Party', 'Events'] as const).map((tab) => {
            const isSelected = topNavTab === tab;
            return (
              <button
                key={tab}
                onClick={() => {
                  playSoundFX('click');
                  setTopNavTab(tab);
                  if (tab === 'Events') {
                    onOpenCalendar();
                  }
                }}
                className={`relative px-3.5 py-1.5 rounded-full text-xs font-black tracking-wide transition-all ${
                  isSelected
                    ? 'bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 text-white shadow-md shadow-rose-950/60 scale-105'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {tab}
                {isSelected && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-amber-300 rounded-full animate-pulse" />
                )}
              </button>
            );
          })}
        </div>

        {/* Right-side Icons: Calendar, Room Home, Search */}
        <div className="flex items-center gap-2">
          {/* Calendar / Events */}
          <button
            onClick={() => {
              playSoundFX('click');
              onOpenCalendar();
            }}
            className="w-9 h-9 rounded-full bg-[#11152d] border border-white/10 flex items-center justify-center text-amber-400 hover:bg-amber-500/20 transition-all shadow-sm"
            title="Events Calendar"
          >
            <Calendar className="w-4 h-4" />
          </button>

          {/* Home / Room */}
          <button
            onClick={() => {
              playSoundFX('click');
              onOpenPartyLive();
            }}
            className="w-9 h-9 rounded-full bg-[#11152d] border border-white/10 flex items-center justify-center text-cyan-400 hover:bg-cyan-500/20 transition-all shadow-sm"
            title="Party Room Home"
          >
            <Home className="w-4 h-4" />
          </button>

          {/* Search Icon */}
          <button
            onClick={() => {
              playSoundFX('click');
              onOpenSearch();
            }}
            className="w-9 h-9 rounded-full bg-[#11152d] border border-white/10 flex items-center justify-center text-rose-400 hover:bg-rose-500/20 transition-all shadow-sm"
            title="Search Users, Rooms & Hosts"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Go Live Broadcast Button */}
          <button
            onClick={() => {
              if (!hasApprovedAgency) {
                playSoundFX('alert');
                onOpenGoLive();
              } else {
                playSoundFX('superchat');
                setIsGoLiveModalOpen(true);
              }
            }}
            className={`px-3 py-1.5 rounded-full text-white text-xs font-black shadow-lg flex items-center gap-1.5 active:scale-95 transition-all ${
              hasApprovedAgency
                ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 shadow-rose-950/60 animate-pulse'
                : 'bg-gradient-to-r from-amber-600 to-rose-700 shadow-amber-950/60'
            }`}
            title={hasApprovedAgency ? "Go Live (Video or Party)" : "Agency Required to Go Live"}
          >
            {hasApprovedAgency ? (
              <Video className="w-3.5 h-3.5" />
            ) : (
              <Lock className="w-3.5 h-3.5" />
            )}
            <span className="hidden xs:inline">{hasApprovedAgency ? "Go Live" : "Agency Req"}</span>
          </button>
        </div>
      </header>

      {/* GO LIVE CHOICE MODAL (VIDEO LIVE VS PARTY LIVE) */}
      {isGoLiveModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-[#0c1228] border border-white/20 rounded-3xl p-5 space-y-4 shadow-2xl relative">
            <button
              onClick={() => setIsGoLiveModalOpen(false)}
              className="absolute top-4 right-4 text-neutral-400 hover:text-white p-1 rounded-full bg-white/5"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center pt-1">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center mx-auto mb-2 text-white shadow-lg">
                <Video className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-white">Start Live Broadcast</h3>
              <p className="text-xs text-neutral-400 mt-0.5">Select your preferred broadcast format on DIYO LIVE</p>
            </div>

            <div className="space-y-3 pt-2">
              {/* Option 1: Video Live */}
              <button
                type="button"
                onClick={() => {
                  setIsGoLiveModalOpen(false);
                  if (!hasApprovedAgency) {
                    onOpenGoLive();
                  } else {
                    onOpenVideoLive();
                  }
                }}
                className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-violet-600/30 to-purple-600/30 hover:from-violet-600/40 hover:to-purple-600/40 border border-violet-500/50 text-left flex items-center justify-between transition-all group active:scale-98 shadow-md"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-violet-600 text-white flex items-center justify-center">
                    <Video className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-black text-white group-hover:text-violet-300">📹 VIDEO LIVE</div>
                    <div className="text-[10px] text-neutral-400">Camera broadcast, PK Battles, Beauty filters</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-violet-400 group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Option 2: Party Live */}
              <button
                type="button"
                onClick={() => {
                  setIsGoLiveModalOpen(false);
                  if (!hasApprovedAgency) {
                    onOpenGoLive();
                  } else {
                    onOpenPartyLive();
                  }
                }}
                className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-cyan-600/30 to-blue-600/30 hover:from-cyan-600/40 hover:to-blue-600/40 border border-cyan-500/50 text-left flex items-center justify-between transition-all group active:scale-98 shadow-md"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-600 text-white flex items-center justify-center">
                    <Radio className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-black text-white group-hover:text-cyan-300">🎙️ PARTY LIVE</div>
                    <div className="text-[10px] text-neutral-400">20-Seat Voice Lounge, Sir Crown, Games</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* QUICK LIVE TYPE SWITCH — VIDEO LIVE / PARTY LIVE                         */}
      {/* Every button opens the correct live experience immediately.              */}
      {/* ========================================================================= */}
      <div className="px-4 pt-3">
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => {
              playSoundFX('click');
              onOpenVideoLive();
            }}
            className="group relative overflow-hidden rounded-2xl border border-violet-500/40 bg-gradient-to-br from-violet-600/25 via-[#11152d] to-[#070913] p-3 text-left shadow-lg transition-all active:scale-[0.98] hover:border-violet-400"
            aria-label="Open Video Live"
          >
            <div className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-600/90 text-white shadow-md">
                <Video className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-[12px] font-black text-white">VIDEO LIVE</span>
                <span className="block text-[9px] text-neutral-400">Tap to open video live</span>
              </span>
            </div>
            <ChevronRight className="absolute right-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-violet-300 transition-transform group-hover:translate-x-0.5" />
          </button>

          <button
            type="button"
            onClick={() => {
              playSoundFX('click');
              onOpenPartyLive();
            }}
            className="group relative overflow-hidden rounded-2xl border border-cyan-500/40 bg-gradient-to-br from-cyan-600/25 via-[#11152d] to-[#070913] p-3 text-left shadow-lg transition-all active:scale-[0.98] hover:border-cyan-400"
            aria-label="Open Party Live"
          >
            <div className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-600/90 text-white shadow-md">
                <Radio className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-[12px] font-black text-white">PARTY LIVE</span>
                <span className="block text-[9px] text-neutral-400">Tap to open party room</span>
              </span>
            </div>
            <ChevronRight className="absolute right-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-cyan-300 transition-transform group-hover:translate-x-0.5" />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. LIVE ACTIVITY / REWARD NOTIFICATION TICKER                             */}
      {/* ========================================================================= */}
      {activityTicker && (
        <div className="px-4 pt-2.5">
          <div className="bg-gradient-to-r from-amber-500/15 via-purple-600/15 to-rose-500/15 border border-amber-500/30 rounded-2xl p-2.5 flex items-center justify-between shadow-md backdrop-blur-md animate-in slide-in-from-top-2">
            <div className="flex items-center gap-2.5">
              <img src={activityTicker.avatar} alt="" className="w-7 h-7 rounded-full object-cover ring-2 ring-amber-400/60" />
              <div className="text-xs">
                <span className="font-bold text-amber-300">{activityTicker.username}</span>{' '}
                <span className="text-neutral-300">{activityTicker.action}</span>
              </div>
            </div>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40">
              🎁 Live Gift
            </span>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. TOP PREMIUM BANNER SLIDER (Backend Managed Only)                        */}
      {/* ========================================================================= */}
      {currentBanner && (
        <div className="px-4 pt-3">
          <div className="relative w-full h-36 sm:h-42 rounded-3xl overflow-hidden shadow-2xl border border-white/15 group">
            <img
              src={currentBanner.imageUrl || currentBanner.image}
              alt={currentBanner.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#070913] via-[#070913]/40 to-transparent p-4 flex flex-col justify-end">
              <div className="flex items-center gap-1.5 mb-1.5">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-300 bg-black/60 backdrop-blur-md px-2.5 py-0.5 rounded-full w-fit border border-amber-400/30 flex items-center gap-1 shadow">
                  <Globe className="w-3 h-3 text-amber-400" />
                  {currentBanner.badge || 'GLOBAL EVENT'}
                </span>
                <span className="text-[9px] font-black text-cyan-300 bg-cyan-950/80 backdrop-blur-md px-2 py-0.5 rounded-full border border-cyan-500/40">
                  🌐 Worldwide
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-black text-white drop-shadow-md line-clamp-1">
                {currentBanner.title}
              </h2>
              {(currentBanner.subtitle || currentBanner.description) && (
                <p className="text-[11px] text-neutral-300 line-clamp-1 drop-shadow mt-0.5">
                  {currentBanner.subtitle || currentBanner.description}
                </p>
              )}
            </div>

            {/* Owner Management Overlay */}
            {isOwner && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsBannerModalOpen(true);
                  playSoundFX('click');
                }}
                className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/75 hover:bg-black/95 backdrop-blur-md border border-amber-400/60 text-amber-300 text-[10px] font-black flex items-center gap-1.5 shadow-xl cursor-pointer transition-all hover:scale-105 active:scale-95 z-20"
                title="Manage Home Page Banner"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>⚙️ Edit Banner</span>
              </button>
            )}

            {/* Pagination Dots */}
            {activeBanners.length > 1 && (
              <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full">
                {activeBanners.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveBannerIndex(idx)}
                    className={`h-1.5 rounded-full transition-all ${
                      idx === (activeBannerIndex % activeBanners.length) ? 'w-5 bg-amber-400' : 'w-1.5 bg-white/50'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. RANKING SECTION (3 Premium Cards)                                      */}
      {/* ========================================================================= */}
      <div className="px-4 pt-4">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs sm:text-sm font-black tracking-wide text-white">Global Leaderboard Rankings</h3>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              setIsRankModalOpen(true);
            }}
            className="text-[11px] font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            View All <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 3 Ranking Cards */}
        <div className="grid grid-cols-3 gap-2.5">
          {/* 1. Gift Ranking */}
          <div
            onClick={() => {
              playSoundFX('superchat');
              setRankingSubTab('GIFT');
              setIsRankModalOpen(true);
            }}
            className="p-3 rounded-2xl bg-gradient-to-br from-amber-500/20 via-[#11152d] to-[#070913] border border-amber-500/40 shadow-lg cursor-pointer hover:border-amber-400 transition-all group flex flex-col items-center text-center"
          >
            <div className="w-10 h-10 rounded-full bg-amber-500 text-neutral-950 flex items-center justify-center font-black shadow-md mb-2 group-hover:scale-110 transition-transform">
              🎁
            </div>
            <span className="text-xs font-black text-amber-300">Gift Rank</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">Top Gifters</span>
          </div>

          {/* 2. Best Friends */}
          <div
            onClick={() => {
              playSoundFX('superchat');
              setRankingSubTab('FRIENDS');
              setIsRankModalOpen(true);
            }}
            className="p-3 rounded-2xl bg-gradient-to-br from-rose-500/20 via-[#11152d] to-[#070913] border border-rose-500/40 shadow-lg cursor-pointer hover:border-rose-400 transition-all group flex flex-col items-center text-center"
          >
            <div className="w-10 h-10 rounded-full bg-rose-500 text-white flex items-center justify-center font-black shadow-md mb-2 group-hover:scale-110 transition-transform">
              ❤️
            </div>
            <span className="text-xs font-black text-rose-300">Best Friends</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">CP Ranks</span>
          </div>

          {/* 3. Family */}
          <div
            onClick={() => {
              playSoundFX('superchat');
              setRankingSubTab('FAMILY');
              setIsRankModalOpen(true);
            }}
            className="p-3 rounded-2xl bg-gradient-to-br from-purple-600/20 via-[#11152d] to-[#070913] border border-purple-500/40 shadow-lg cursor-pointer hover:border-purple-400 transition-all group flex flex-col items-center text-center"
          >
            <div className="w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center font-black shadow-md mb-2 group-hover:scale-110 transition-transform">
              🏰
            </div>
            <span className="text-xs font-black text-purple-300">Family Guild</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">Top Families</span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 6. FEATURED / RECOMMENDED PARTY ROOMS                                     */}
      {/* ========================================================================= */}
      {recommendedRooms.length > 0 && (
        <div className="px-4 pt-4">
          <div className="flex items-center gap-2 mb-2.5">
            <Crown className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs sm:text-sm font-black tracking-wide text-white">Recommended Party Rooms</h3>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
            {recommendedRooms.map((room, idx) => (
              <div
                key={room.roomId || room.id}
                onClick={() => {
                  playSoundFX('click');
                  onSelectRoom(room.roomId || room.id);
                }}
                className="flex-shrink-0 w-36 sm:w-40 bg-[#11152d] rounded-2xl border border-amber-500/40 overflow-hidden shadow-xl cursor-pointer hover:border-amber-400 transition-all group"
              >
                <div className="relative h-32 sm:h-36">
                  <img src={room.coverImage || room.roomImage || room.cover || room.hostAvatar || 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600'} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-amber-500 text-neutral-950 font-black text-[9px]">
                    Rank #{idx + 1}
                  </span>
                  <span className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-full text-[9px] font-bold text-cyan-300 flex items-center gap-1">
                    👥 {room.onlineCount || room.viewersCount || 1}
                  </span>
                </div>
                <div className="p-2.5">
                  <h4 className="text-xs font-black text-white truncate">{room.roomName || room.name}</h4>
                  <p className="text-[10px] text-neutral-400 truncate">Host: {room.hostName || room.ownerName || room.host || 'Broadcaster'}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. COUNTRY REGION TABS & STREAM TYPE & LIVE ROOM DISCOVERY LIST          */}
      {/* ========================================================================= */}
      <div className="px-4 pt-4 pb-20 space-y-3">
        {/* Global & Country Selector Bar: Global 🌐 | Nepal 🇳🇵 | India 🇮🇳 | Bangladesh 🇧🇩 | Pakistan 🇵🇰 | Philippines 🇵🇭 | UAE 🇦🇪 | Saudi 🇸🇦 | USA 🇺🇸 */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
          {HOME_COUNTRY_FILTERS.map((item) => {
            const isSelected = selectedCountry === item.code;
            return (
              <button
                key={item.code}
                onClick={() => {
                  playSoundFX('click');
                  setSelectedCountry(item.code);
                }}
                className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-neutral-950 font-black shadow-lg shadow-cyan-950/60 scale-102'
                    : 'bg-[#11152d] text-neutral-300 hover:text-white border border-white/10'
                }`}
              >
                <span>{item.flag}</span>
                <span>{item.name}</span>
                {item.code === 'GLOBAL' && (
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-cyan-950/60 text-cyan-300 font-mono">
                    All
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Stream Type Bar: All Live | Video Live | Party Live */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            {(['ALL', 'VIDEO', 'PARTY'] as const).map((type) => {
              const isSelected = streamTypeFilter === type;
              return (
                <button
                  key={type}
                  onClick={() => {
                    playSoundFX('click');
                    setStreamTypeFilter(type);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    isSelected
                      ? type === 'VIDEO'
                        ? 'bg-violet-600 text-white shadow-md shadow-violet-950/60 scale-102'
                        : type === 'PARTY'
                        ? 'bg-cyan-600 text-white shadow-md shadow-cyan-950/60 scale-102'
                        : 'bg-gradient-to-r from-amber-500 to-rose-500 text-white shadow-md scale-102'
                      : 'bg-[#11152d] text-neutral-400 hover:text-white border border-white/5'
                  }`}
                >
                  {type === 'ALL' && <Flame className="w-3.5 h-3.5" />}
                  {type === 'VIDEO' && <Video className="w-3.5 h-3.5" />}
                  {type === 'PARTY' && <Radio className="w-3.5 h-3.5" />}
                  <span>{type === 'ALL' ? 'All Live' : type === 'VIDEO' ? 'Video Live' : 'Party Live'}</span>
                </button>
              );
            })}
          </div>

          {/* Popular / New Toggle Tabs */}
          <div className="flex bg-[#11152d] p-0.5 rounded-xl border border-white/10 flex-shrink-0">
            {(['Popular', 'New'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => {
                  playSoundFX('click');
                  setCategoryFilter(cat);
                }}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase transition-all ${
                  categoryFilter === cat
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {cat === 'Popular' ? '🔥 Hot' : 'New'}
              </button>
            ))}
          </div>
        </div>

        {/* Active Broadcast Banner for Current User if Live */}
        {userLiveRoom && (
          <div className="mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-rose-950/80 via-neutral-900 to-amber-950/80 border-2 border-rose-500 shadow-2xl shadow-rose-950/60 flex flex-col sm:flex-row items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="relative">
                <img
                  src={userLiveRoom.coverImage || userLiveRoom.cover || userLiveRoom.roomImage || userLiveRoom.hostAvatar || currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'}
                  alt=""
                  className="w-12 h-12 rounded-xl object-cover ring-2 ring-rose-500"
                />
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-neutral-950 animate-ping" />
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-neutral-950" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-rose-500 text-[9px] font-black text-white uppercase tracking-wider animate-pulse flex items-center gap-1">
                    <Radio className="w-2.5 h-2.5" /> LIVE ON HOME PAGE
                  </span>
                  <span className="text-[10px] font-bold text-amber-300 truncate">
                    Broadcasting Now
                  </span>
                </div>
                <h4 className="text-xs sm:text-sm font-black text-white truncate mt-0.5 font-['Outfit']">
                  {userLiveRoom.roomName || userLiveRoom.name || userLiveRoom.title}
                </h4>
                <p className="text-[10px] text-neutral-400">
                  {userLiveRoom.onlineCount || userLiveRoom.viewersCount || 1} live viewers • Tap to return to your studio
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                playSoundFX('click');
                onSelectRoom(userLiveRoom.roomId || userLiveRoom.id);
              }}
              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-lg shadow-rose-950/60 transition-transform active:scale-95 cursor-pointer"
            >
              <span>ENTER STUDIO</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Room Grid / List */}
        {displayedRooms.length === 0 ? (
          <div className="p-8 text-center bg-[#11152d]/60 rounded-3xl border border-white/10 my-4">
            <Radio className="w-10 h-10 text-neutral-500 mx-auto mb-2 animate-pulse" />
            <p className="text-xs font-bold text-neutral-300">No active rooms in this category right now.</p>
            <p className="text-[10px] text-neutral-500 mt-1">Tap "Go Live" above to launch a broadcast!</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {displayedRooms.map((room) => {
              const isVideo = room.liveType === 'VIDEO' || (room.liveType !== 'PARTY' && room.roomType !== 'PARTY' && !room.roomId?.startsWith('LIVE-P') && !room.tag?.toLowerCase().includes('party'));
              const isMe = currentUser && (
                room.hostId === currentUser.id || 
                room.hostId === currentUser.username || 
                (currentUser.id && room.hostId?.includes(currentUser.id))
              );

              return (
                <div
                  key={room.roomId || room.id}
                  onClick={() => {
                    playSoundFX('click');
                    onSelectRoom(room.roomId || room.id);
                  }}
                  className={`bg-[#11152d] rounded-2xl border overflow-hidden shadow-xl cursor-pointer transition-all group flex flex-col relative ${
                    isMe
                      ? 'border-amber-400 ring-2 ring-amber-400/50 shadow-amber-950/60'
                      : isVideo
                        ? 'border-violet-500/30 hover:border-violet-400'
                        : 'border-cyan-500/30 hover:border-cyan-400'
                  }`}
                >
                  {/* Highlight ribbon if this is the user's room */}
                  {isMe && (
                    <div className="bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 text-[9px] font-black uppercase tracking-wider py-0.5 px-2 text-center flex items-center justify-center gap-1">
                      <Crown className="w-2.5 h-2.5" />
                      <span>YOUR LIVE ROOM</span>
                    </div>
                  )}

                  <div className="relative h-36 sm:h-40">
                    <img
                      src={room.roomImage || room.cover || room.coverImage || 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600'}
                      alt=""
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent p-2.5 flex flex-col justify-between">
                      <div className="flex items-center justify-between gap-1">
                        {/* Stream Type Pill */}
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black text-white flex items-center gap-1 shadow-md ${
                          isVideo ? 'bg-violet-600/90' : 'bg-cyan-600/90'
                        }`}>
                          {isVideo ? <Video className="w-2.5 h-2.5" /> : <Radio className="w-2.5 h-2.5" />}
                          <span>{isVideo ? 'Video Live' : 'Party Live'}</span>
                        </span>

                        {/* Viewer Count */}
                        <span className="px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-[9px] font-black text-white flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                          {room.onlineCount || room.viewersCount || 1}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-bold text-white bg-black/60 px-1.5 py-0.5 rounded backdrop-blur-sm">
                          {room.countryFlag || '🇳🇵'} {room.country || 'Nepal'}
                        </span>
                        <span className="text-[9px] font-mono text-neutral-300 bg-black/60 px-1.5 py-0.5 rounded">
                          #{room.roomId || room.id}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 flex flex-col justify-between flex-1">
                    <div>
                      <h4 className="text-xs font-black text-white truncate">{room.roomName || room.name}</h4>
                      <p className="text-[10px] text-neutral-400 truncate mt-0.5">
                        Host: {isMe ? `You (${room.hostName || currentUser.name})` : (room.hostName || room.ownerName || room.host || 'Broadcaster')}
                      </p>
                    </div>
                    {room.tag && (
                      <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-white/10">
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold truncate">
                          {room.tag}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Global Leaderboard Modal */}
      <RankLeaderboardModal
        isOpen={isRankModalOpen}
        onClose={() => setIsRankModalOpen(false)}
      />

      {/* Home Banner Manager Modal (Permanent Home Banners) */}
      <HomeBannerManagerModal
        isOpen={isBannerModalOpen}
        onClose={() => setIsBannerModalOpen(false)}
        banners={banners}
        onUpdateBanners={onUpdateBanners || (() => {})}
        currentUser={currentUser}
      />

      {/* Footer inside Home scroll */}
      <footer className="bg-neutral-950/80 border-t border-white/10 py-6 px-4 mt-8 text-center text-xs text-neutral-400">
        <div className="max-w-md md:max-w-lg mx-auto flex flex-col items-center justify-center gap-1.5">
          <div className="flex items-center gap-2">
            <span className="font-['Outfit'] font-black text-sm text-white">DIYO LIVE</span>
            <span className="text-neutral-500">•</span>
            <span className="text-neutral-400">Ultra Low Latency Broadcast Network</span>
          </div>
          <p className="text-[10px] text-neutral-500">© 2026 DIYO LIVE. All streams broadcast in 4K UHD & AV1 encoder standard.</p>
        </div>
      </footer>
    </div>
  );
};
