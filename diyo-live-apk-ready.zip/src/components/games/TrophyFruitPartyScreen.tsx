import React, { useState, useEffect } from 'react';
import { ArrowLeft, Sparkles, Trophy, Volume2, VolumeX, HelpCircle, Settings, Coins } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface TrophyFruitPartyScreenProps {
  userCoins: number;
  onUpdateCoins: (delta: number) => void;
  onClose: () => void;
}

interface FruitTile {
  id: string;
  name: string;
  icon: string;
  multiplier: number;
}

const FRUITS: FruitTile[] = [
  { id: 'orange', name: 'Orange', icon: '🍊', multiplier: 5 },
  { id: 'kiwi', name: 'Kiwi', icon: '🥝', multiplier: 5 },
  { id: 'tomato', name: 'Tomato', icon: '🍅', multiplier: 5 },
  { id: 'pomegranate', name: 'Pomegranate', icon: '🫐', multiplier: 10 },
  { id: 'avocado', name: 'Avocado', icon: '🥑', multiplier: 45 },
  { id: 'lemon', name: 'Lemon', icon: '🍋', multiplier: 25 },
  { id: 'date', name: 'Dates', icon: '🥥', multiplier: 15 },
  { id: 'watermelon', name: 'Watermelon', icon: '🍉', multiplier: 5 },
];

export const TrophyFruitPartyScreen: React.FC<TrophyFruitPartyScreenProps> = ({
  userCoins,
  onUpdateCoins,
  onClose,
}) => {
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [selectedBet, setSelectedBet] = useState<number>(1000);
  const [fruitBets, setFruitBets] = useState<Record<string, number>>({});
  const [roundNumber, setRoundNumber] = useState<number>(680);
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [todaysScore, setTodaysScore] = useState<number>(200000);
  const [resultHistory, setResultHistory] = useState<string[]>(['🍊', '🥝', '🍅', '🍊', '🍉', '🍋', '🥑']);
  const [roundResult, setRoundResult] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalType, setModalType] = useState<'help' | 'settings' | null>(null);

  // Countdown timer loop
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          resolveRound();
          return 30;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [fruitBets, selectedBet]);

  const resolveRound = () => {
    const winningFruit = FRUITS[Math.floor(Math.random() * FRUITS.length)];
    setRoundResult(winningFruit.icon);
    setResultHistory((prev) => [winningFruit.icon, ...prev.slice(0, 15)]);
    setRoundNumber((r) => r + 1);

    if (soundEnabled) playSoundFX('success');

    const betOnWinning = fruitBets[winningFruit.id] || 0;
    if (betOnWinning > 0) {
      const won = betOnWinning * winningFruit.multiplier;
      onUpdateCoins(won);
      setTodaysScore((s) => s + won);
      confetti({ particleCount: 60, spread: 90, origin: { y: 0.6 } });
    }

    setTimeout(() => {
      setFruitBets({});
      setRoundResult(null);
    }, 3000);
  };

  const handleSelectFruit = (fruit: FruitTile) => {
    if (soundEnabled) playSoundFX('click');
    if (userCoins < selectedBet) {
      alert('⚠️ Insufficient DIYO LIVE coins! Please recharge in Wallet.');
      return;
    }
    setFruitBets((prev) => ({
      ...prev,
      [fruit.id]: (prev[fruit.id] || 0) + selectedBet,
    }));
    onUpdateCoins(-selectedBet);
  };

  const renderFruitButton = (fruit: FruitTile) => {
    const betAmount = fruitBets[fruit.id] || 0;
    const isSelected = betAmount > 0;
    const isWinning = roundResult === fruit.icon;

    return (
      <button
        key={fruit.id}
        onClick={() => handleSelectFruit(fruit)}
        className={`relative flex flex-col items-center justify-center py-2.5 rounded-2xl border-2 transition-all duration-200 shadow-md ${
          isSelected
            ? 'bg-amber-500/35 border-amber-300 scale-105 shadow-[0_0_20px_rgba(245,158,11,0.6)]'
            : isWinning
            ? 'bg-emerald-500/40 border-emerald-300 scale-105 animate-bounce'
            : 'bg-[#06160f] border-amber-500/40 hover:border-amber-400 hover:bg-[#0d2a1f]'
        }`}
      >
        <div className="text-2xl sm:text-3xl mb-0.5 filter drop-shadow-md">{fruit.icon}</div>
        <span className="text-[10px] sm:text-[11px] font-bold text-neutral-300 mb-0.5">{fruit.name}</span>
        <div className="flex items-center gap-1 mb-0.5">
          <span className="text-[10px] font-black text-amber-300 font-mono bg-black/60 px-1.5 py-0.2 rounded-full border border-amber-500/30">
            {fruit.multiplier}x
          </span>
        </div>
        {betAmount > 0 && (
          <span className="absolute -top-2 -right-2 bg-rose-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full shadow-lg border border-white animate-pulse">
            {betAmount >= 1000 ? `${(betAmount/1000).toFixed(0)}K` : betAmount}
          </span>
        )}
        <div className="absolute bottom-1 w-8 h-1 rounded-full bg-amber-500/60" />
      </button>
    );
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-[#061a12] via-[#09261a] to-[#040f0a] text-white overflow-y-auto select-none font-['Plus_Jakarta_Sans',sans-serif]">
      
      {/* Live Winning Patti Ticker */}
      <div className="bg-amber-500/20 border-b border-amber-500/40 py-2 px-4 flex items-center gap-3 text-xs text-amber-300 font-mono font-bold overflow-hidden shadow-inner shrink-0">
        <span className="shrink-0 flex items-center gap-1 text-amber-400 font-black"><Trophy className="w-4 h-4" /> LIVE WINNING PATTI:</span>
        <div className="truncate animate-pulse flex items-center gap-6">
          <span>🏆 Rahul won 50,000 coins</span>
          <span>•</span>
          <span>🏆 User123 won 120,000 coins</span>
          <span>•</span>
          <span>🏆 Trophy Master won 1,000,000 coins</span>
          <span>•</span>
          <span>🏆 Priya Sharma won 250,000 coins</span>
        </div>
      </div>

      {/* Top Game Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#0d3323]/90 border-b border-amber-500/30 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              if (soundEnabled) playSoundFX('click');
              onClose();
            }}
            className="w-9 h-9 rounded-xl bg-black/40 border border-amber-500/40 text-amber-300 flex items-center justify-center hover:bg-amber-500/20 transition-all shadow"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-sm font-black tracking-wider uppercase font-['Outfit'] bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-500 bg-clip-text text-transparent flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>🌟 DIYO LIVE BATTLES</span>
            </h1>
            <p className="text-[10px] text-emerald-300 font-mono">Casual 3D Fruit Betting Hub</p>
          </div>
        </div>

        {/* Header Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="w-8 h-8 rounded-lg bg-black/40 border border-amber-500/30 text-amber-300 flex items-center justify-center hover:bg-amber-500/20"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            onClick={() => { setModalType('help'); setIsModalOpen(true); }}
            className="w-8 h-8 rounded-lg bg-black/40 border border-amber-500/30 text-amber-300 flex items-center justify-center hover:bg-amber-500/20"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
          <button
            onClick={() => { setModalType('settings'); setIsModalOpen(true); }}
            className="w-8 h-8 rounded-lg bg-black/40 border border-amber-500/30 text-amber-300 flex items-center justify-center hover:bg-amber-500/20"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Balance & Score Banner */}
      <div className="px-4 py-2.5 bg-[#082218]/80 border-b border-emerald-500/20 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2 bg-black/50 border border-amber-500/40 px-3 py-1.5 rounded-2xl shadow-inner">
          <Coins className="w-4 h-4 text-amber-400 animate-spin" />
          <div>
            <div className="text-[9px] uppercase tracking-wider text-neutral-400 font-bold">Balance</div>
            <div className="text-xs font-black text-amber-300 font-mono">{userCoins.toLocaleString()} Coins</div>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-black/50 border border-emerald-500/40 px-3 py-1.5 rounded-2xl shadow-inner">
          <Trophy className="w-4 h-4 text-emerald-400" />
          <div className="text-right">
            <div className="text-[9px] uppercase tracking-wider text-neutral-400 font-bold">Today's Total Win</div>
            <div className="text-xs font-black text-emerald-300 font-mono">{todaysScore.toLocaleString()}</div>
          </div>
        </div>
      </div>

      {/* Round Badge Capsule */}
      <div className="flex justify-center my-2 shrink-0">
        <div className="px-4 py-1 rounded-full bg-gradient-to-r from-rose-600 via-pink-600 to-purple-700 border border-pink-400/50 text-[11px] font-black tracking-widest text-white shadow-lg uppercase">
          ROUND {roundNumber} OF TODAY
        </div>
      </div>

      {/* Main Game Board (3x3 Fruit Grid with Central Timer Wheel) */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-2">
        <div className="w-full max-w-sm bg-gradient-to-b from-[#0b3b28] via-[#072418] to-[#04120c] border-4 border-amber-500/60 rounded-3xl p-4 shadow-[0_0_40px_rgba(245,158,11,0.3)] relative">
          
          <div className="grid grid-cols-3 gap-3">
            {/* Top Row: Orange, Kiwi, Tomato */}
            {FRUITS.slice(0, 3).map(renderFruitButton)}

            {/* Middle Left: Pomegranate */}
            {renderFruitButton(FRUITS[3])}

            {/* Center: Glowing Circular Wheel Timer with Rotating Highlight Lights */}
            <div className="flex flex-col items-center justify-center bg-gradient-to-br from-black/90 to-emerald-950/90 border-4 border-amber-400 rounded-2xl p-2 shadow-[0_0_25px_rgba(245,158,11,0.5)] relative overflow-hidden animate-pulse">
              <div className="absolute inset-0 border-2 border-dashed border-amber-300/40 rounded-xl animate-spin" style={{ animationDuration: '10s' }} />
              <div className="text-2xl font-black text-amber-300 font-mono tracking-tighter drop-shadow-lg">{timeLeft}s</div>
              <span className="text-[9px] font-black uppercase tracking-widest text-emerald-400">WHEEL TIMER</span>
              <div className="text-[8px] text-amber-200 mt-0.5 font-bold">DIYO LIVE</div>
            </div>

            {/* Middle Right: Avocado */}
            {renderFruitButton(FRUITS[4])}

            {/* Bottom Row: Lemon, Dates, Watermelon */}
            {FRUITS.slice(5, 8).map(renderFruitButton)}
          </div>

        </div>
      </div>

      {/* Casino Poker Chips Control Panel (100, 1K, 10K, 100K, 500K) */}
      <div className="px-4 py-3 bg-[#082218]/90 border-t border-emerald-500/20 shrink-0">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] uppercase font-bold text-neutral-300 tracking-wider">Casino Poker Chips</span>
          <span className="text-xs font-black text-amber-300">Selected Bet: {selectedBet.toLocaleString()} Coins</span>
        </div>
        <div className="grid grid-cols-5 gap-2">
          {[
            { val: 100, label: '100', color: 'from-blue-600 to-indigo-700' },
            { val: 1000, label: '1K', color: 'from-emerald-600 to-teal-700' },
            { val: 10000, label: '10K', color: 'from-purple-600 to-pink-700' },
            { val: 100000, label: '100K', color: 'from-amber-500 to-orange-600' },
            { val: 500000, label: '500K', color: 'from-rose-600 to-red-700' },
          ].map((chip) => (
            <button
              key={chip.val}
              onClick={() => {
                if (soundEnabled) playSoundFX('click');
                setSelectedBet(chip.val);
              }}
              className={`py-2 rounded-2xl text-xs font-black font-mono transition-all shadow-lg border ${
                selectedBet === chip.val
                  ? `bg-gradient-to-r ${chip.color} text-white shadow-amber-500/50 scale-105 border-white`
                  : 'bg-black/50 text-neutral-300 border-emerald-500/30 hover:bg-emerald-950/40'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* Results History Bar */}
      <div className="px-4 py-2 bg-[#04100b] border-t border-emerald-500/30 flex items-center gap-2 overflow-x-auto shrink-0">
        <span className="text-[10px] font-black uppercase text-amber-400 tracking-widest whitespace-nowrap">RECENT HISTORY:</span>
        <div className="flex items-center gap-1.5">
          {resultHistory.map((res, idx) => (
            <div key={idx} className="w-7 h-7 rounded-lg bg-black/60 border border-amber-500/30 flex items-center justify-center text-sm shrink-0 shadow">
              {res}
            </div>
          ))}
        </div>
      </div>

      {/* Help / Settings Modal Popup */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-[#0a281d] border-2 border-amber-500/50 rounded-3xl p-6 shadow-2xl text-white">
            <h3 className="text-base font-black text-amber-300 uppercase mb-3 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              {modalType === 'help' ? 'Trophy Fruit Party Rules' : 'Game Settings'}
            </h3>
            {modalType === 'help' ? (
              <div className="text-xs text-neutral-300 space-y-2 mb-6 leading-relaxed">
                <p>1. Select your poker chip bet from 100 to 500K coins.</p>
                <p>2. Tap any fruit tile before the circular wheel timer hits zero.</p>
                <p>3. If the selected fruit wins the round, you win your bet multiplied by the fruit multiplier (up to 45x)!</p>
                <p>4. All wins sync permanently to your DIYO LIVE balance.</p>
              </div>
            ) : (
              <div className="text-xs text-neutral-300 space-y-3 mb-6">
                <div className="flex items-center justify-between bg-black/40 p-3 rounded-xl border border-emerald-500/20">
                  <span>Sound Effects</span>
                  <button
                    onClick={() => setSoundEnabled(!soundEnabled)}
                    className="px-3 py-1 rounded-lg bg-amber-500 text-neutral-950 font-bold text-xs"
                  >
                    {soundEnabled ? 'ENABLED' : 'MUTED'}
                  </button>
                </div>
              </div>
            )}
            <button
              onClick={() => setIsModalOpen(false)}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 font-black text-xs uppercase shadow-lg"
            >
              Close
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
