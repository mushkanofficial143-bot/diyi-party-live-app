import React, { useState, useEffect } from 'react';
import {
  X,
  Coins,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  Sparkles,
  Send,
  Heart,
  Flame,
  Zap,
  Crown,
  ShieldCheck
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { LuckyGift3DEffect } from './LuckyGift3DEffect';

export interface GiftSheetItem {
  id: string;
  name: string;
  cost: number;
  isLucky: boolean;
  icon: string;
  image?: string;
  category: 'Gift' | 'CP' | 'Lucky Gift' | 'Exclusive' | 'Lucky Me';
  luckyMultiplierMax?: number;
}

export interface BottomGiftSheetProps {
  isOpen: boolean;
  onClose: () => void;
  initialCoins?: number;
  initialDiamonds?: number;
  roomSeats?: string[];
  senderId?: string;
  senderName?: string;
  roomType?: string;
  targetHostId?: string;
  liveRoomId?: string;
  onSendSuccess?: (data: {
    gift: GiftSheetItem;
    target: string;
    multiplier: number;
    totalCost: number;
    reward: number;
    newBalance: number;
    newDiamonds: number;
    diamondsEarned: number;
    isSelfGift?: boolean;
    netProfitLoss: number;
  }) => void;
}

// Exact catalog organized by categories matching Screenshot 1
export const SCREENSHOT_GIFT_CATALOG: GiftSheetItem[] = [
  // --- Tab 1: 'Gift' (Exact 8 items from Screenshot 1) ---
  {
    id: 'g-bell-jar',
    name: 'Bell Jar',
    cost: 499,
    isLucky: false,
    icon: '🔔',
    image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=120&auto=format&fit=crop&q=80',
    category: 'Gift'
  },
  {
    id: 'g-virgo-perfume',
    name: 'Virgo Perfume',
    cost: 999,
    isLucky: false,
    icon: '🔮',
    image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=120&auto=format&fit=crop&q=80',
    category: 'Gift'
  },
  {
    id: 'g-diamond-ring',
    name: 'Diamond Ring',
    cost: 1999,
    isLucky: false,
    icon: '💍',
    image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=120&auto=format&fit=crop&q=80',
    category: 'Gift'
  },
  {
    id: 'g-aquarius-pitcher',
    name: 'Aquarius Vase',
    cost: 2999,
    isLucky: false,
    icon: '🏺',
    image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=120&auto=format&fit=crop&q=80',
    category: 'Gift'
  },
  {
    id: 'g-pumpkin-fairy',
    name: 'Pumpkin Carriage',
    cost: 4999,
    isLucky: false,
    icon: '🎃',
    image: 'https://images.unsplash.com/photo-1508873696983-2df5293cb32b?w=120&auto=format&fit=crop&q=80',
    category: 'Gift'
  },
  {
    id: 'g-celebration-cake',
    name: 'Celebration Cake',
    cost: 8999,
    isLucky: false,
    icon: '🎂',
    image: 'https://images.unsplash.com/photo-1535141192574-5d4897c13136?w=120&auto=format&fit=crop&q=80',
    category: 'Gift'
  },

  // --- Tab 2: 'CP' (Couple Romantic Gifts) ---
  { id: 'cp-1', name: 'Couple Swan Lake', cost: 13140, isLucky: false, icon: '🦢', category: 'CP' },
  { id: 'cp-2', name: 'Love Castle', cost: 52000, isLucky: false, icon: '🏰', category: 'CP' },
  { id: 'cp-3', name: 'Couple Rings', cost: 19999, isLucky: false, icon: '💍', category: 'CP' },
  { id: 'cp-4', name: 'Rose Bouquet 999', cost: 9999, isLucky: false, icon: '🌹', category: 'CP' },
  { id: 'cp-5', name: 'Cinderella Carriage', cost: 100000, isLucky: false, icon: '🎠', category: 'CP' },
  { id: 'cp-6', name: 'Romantic Fireworks', cost: 5200, isLucky: false, icon: '🎆', category: 'CP' },

  // --- Tab 3: 'Lucky Gift' ---
  { id: 'lg-0', name: 'Lucky Wishing Bell (10X)', cost: 10, isLucky: true, luckyMultiplierMax: 10, icon: '🔔', category: 'Lucky Gift' },
  { id: 'lg-00', name: 'Lucky Gold Coin (20X)', cost: 100, isLucky: true, luckyMultiplierMax: 20, icon: '🪙', category: 'Lucky Gift' },
  { id: 'lg-000', name: 'Lucky Fortune Orb (50X)', cost: 500, isLucky: true, luckyMultiplierMax: 50, icon: '🔮', category: 'Lucky Gift' },
  { id: 'lg-1', name: 'Lucky Clover (100X)', cost: 1000, isLucky: true, luckyMultiplierMax: 100, icon: '🍀', category: 'Lucky Gift' },
  { id: 'lg-3', name: 'Mystery Lucky Box (200X)', cost: 2000, isLucky: true, luckyMultiplierMax: 200, icon: '🎁', category: 'Lucky Gift' },
  { id: 'lg-2', name: 'Lucky 777 Wheel (500X)', cost: 10000, isLucky: true, luckyMultiplierMax: 500, icon: '🎰', category: 'Lucky Gift' },
  { id: 'lg-6', name: 'Cosmic Crystal (600X)', cost: 20000, isLucky: true, luckyMultiplierMax: 600, icon: '💎', category: 'Lucky Gift' },
  { id: 'lg-4', name: 'Fortune Dragon (777X)', cost: 50000, isLucky: true, luckyMultiplierMax: 777, icon: '🐉', category: 'Lucky Gift' },
  { id: 'lg-5', name: 'Lucky Star Rocket (1000X)', cost: 100000, isLucky: true, luckyMultiplierMax: 1000, icon: '🚀', category: 'Lucky Gift' },
  { id: 'lg-7', name: 'Universe Portal (1500X)', cost: 200000, isLucky: true, luckyMultiplierMax: 1500, icon: '🪐', category: 'Lucky Gift' },
  { id: 'lg-8', name: 'Zeus God Vault (2000X)', cost: 500000, isLucky: true, luckyMultiplierMax: 2000, icon: '⚡', category: 'Lucky Gift' },

  // --- Tab 4: 'Exclusive' ---
  { id: 'ex-1', name: 'Luxury Cyber Supercar', cost: 250000, isLucky: false, icon: '🏎️', category: 'Exclusive' },
  { id: 'ex-2', name: 'Royal Yacht', cost: 500000, isLucky: false, icon: '🛥️', category: 'Exclusive' },
  { id: 'ex-3', name: 'Private Jet', cost: 1000000, isLucky: false, icon: '✈️', category: 'Exclusive' },
  { id: 'ex-4', name: 'Golden Dragon Throne', cost: 2500000, isLucky: false, icon: '👑', category: 'Exclusive' },
  { id: 'ex-5', name: 'Interstellar Starship', cost: 5000000, isLucky: false, icon: '🛸', category: 'Exclusive' },

  // --- Tab 5: 'Lucky Me' ---
  { id: 'lm-0', name: 'Lucky Me Mini Clover', cost: 500, isLucky: true, luckyMultiplierMax: 50, icon: '🍀', category: 'Lucky Me' },
  { id: 'lm-1', name: 'Lucky Me Spinner Box', cost: 2000, isLucky: true, luckyMultiplierMax: 150, icon: '🌟', category: 'Lucky Me' },
  { id: 'lm-2', name: 'Lucky Me Jackpot Vault', cost: 10000, isLucky: true, luckyMultiplierMax: 500, icon: '💎', category: 'Lucky Me' },
  { id: 'lm-5', name: 'Lucky Me Golden Ring', cost: 15000, isLucky: true, luckyMultiplierMax: 600, icon: '💍', category: 'Lucky Me' },
  { id: 'lm-3', name: 'Lucky Me Golden Crown', cost: 25000, isLucky: true, luckyMultiplierMax: 1000, icon: '👑', category: 'Lucky Me' },
  { id: 'lm-4', name: 'Lucky Me Fortune Star', cost: 50000, isLucky: true, luckyMultiplierMax: 777, icon: '⭐', category: 'Lucky Me' },
  { id: 'lm-6', name: 'Lucky Me Dragon Pearl', cost: 100000, isLucky: true, luckyMultiplierMax: 1200, icon: '🔮', category: 'Lucky Me' },
  { id: 'lm-7', name: 'Lucky Me Phoenix Wing', cost: 250000, isLucky: true, luckyMultiplierMax: 2000, icon: '🦅', category: 'Lucky Me' }
];

export const QUANTITY_PRESETS = [1, 10, 66, 88, 99, 188, 520, 1314];

export const BottomGiftSheet: React.FC<BottomGiftSheetProps> = ({
  isOpen,
  onClose,
  initialCoins = 10720,
  initialDiamonds = 18500,
  roomSeats = ['Host (SR **)', 'No.1', 'No.2', 'No.3', 'No.4', 'No.5', 'No.6', 'No.7', 'No.8', 'No.9', 'No.10'],
  senderId = 'USR-882941',
  senderName = 'SR **',
  roomType = 'PARTY_LIVE',
  targetHostId,
  liveRoomId,
  onSendSuccess
}) => {
  const [activeCategory, setActiveCategory] = useState<'Gift' | 'CP' | 'Lucky Gift' | 'Exclusive' | 'Lucky Me'>('Gift');
  const [currentCoins, setCurrentCoins] = useState<number>(initialCoins);
  const [currentDiamonds, setCurrentDiamonds] = useState<number>(initialDiamonds);
  const [selectedGiftId, setSelectedGiftId] = useState<string>('g-bell-jar');
  const [selectedQuantity, setSelectedQuantity] = useState<number>(1);
  const [isQuantityMenuOpen, setIsQuantityMenuOpen] = useState<boolean>(false);
  const [isSending, setIsSending] = useState<boolean>(false);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'win' } | null>(null);
  const [show3DEffect, setShow3DEffect] = useState<boolean>(false);
  const [lastResult, setLastResult] = useState<{ reward: number; won: boolean; wonMultiplier?: string }>({ reward: 0, won: false });

  useEffect(() => {
    setCurrentCoins(initialCoins);
  }, [initialCoins]);

  useEffect(() => {
    setCurrentDiamonds(initialDiamonds);
  }, [initialDiamonds]);

  if (!isOpen) return null;

  const currentGiftsList = SCREENSHOT_GIFT_CATALOG.filter((g) => g.category === activeCategory);
  const selectedGift = SCREENSHOT_GIFT_CATALOG.find((g) => g.id === selectedGiftId) || currentGiftsList[0] || SCREENSHOT_GIFT_CATALOG[0];
  const totalCost = selectedGift ? selectedGift.cost * selectedQuantity : 0;

  const handleSendGift = async () => {
    if (!selectedGift) return;

    if (currentCoins < totalCost) {
      playSoundFX('alert');
      setNotification({
        message: `Insufficient Coins! Need ${totalCost.toLocaleString()} Coins, you have ${currentCoins.toLocaleString()}.`,
        type: 'error'
      });
      return;
    }

    setIsSending(true);
    playSoundFX('coin');

    const newCoins = Math.max(0, currentCoins - totalCost);
    let reward = 0;
    let won = false;

    // Stable, reliable, and dynamic reward calculation for Lucky & Premier gifts
    let wonMultiplierStr = '';
    if (selectedGift.isLucky || activeCategory === 'Lucky Gift' || activeCategory === 'Lucky Me') {
      won = true;
      const maxMult = selectedGift.luckyMultiplierMax || 100;
      // Multiplier scaled by combo quantity and random fortune factor (up to gift max)
      const baseComboMult = selectedQuantity >= 20 ? 10 : selectedQuantity >= 10 ? 5 : selectedQuantity >= 5 ? 3 : 2;
      const fortuneBonus = Math.random() < 0.25 ? Math.min(maxMult, Math.round(baseComboMult * (1.5 + Math.random() * 3))) : baseComboMult;
      const effectiveMult = Math.min(maxMult, Math.max(2, fortuneBonus));
      reward = totalCost * effectiveMult;
      wonMultiplierStr = `${effectiveMult}X`;
    }

    const diamondsEarned = totalCost;
    const finalDiamonds = currentDiamonds + diamondsEarned;
    const finalBalance = newCoins + reward;

    let serverResult: any = null;
    try {
      const response = await fetch('/api/gifts/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId, giftId: selectedGift.id, giftName: selectedGift.name, count: selectedQuantity,
          totalCost, reward, target: 'Host', targetHostId, liveRoomId, roomType
        })
      });
      serverResult = await response.json().catch(() => null);
      if (!response.ok || !serverResult?.success) {
        throw new Error(serverResult?.error || 'Gift transaction failed');
      }
    } catch (err: any) {
      setIsSending(false);
      playSoundFX('alert');
      setNotification({ message: `❌ ${err?.message || 'Gift could not be sent.'}`, type: 'error' });
      setTimeout(() => setNotification(null), 3000);
      return;
    }

    const confirmedBalance = typeof serverResult.senderBalance === 'number' ? serverResult.senderBalance : finalBalance;
    const confirmedDiamonds = typeof serverResult.senderDiamonds === 'number' ? serverResult.senderDiamonds : currentDiamonds;
    setCurrentCoins(confirmedBalance);
    setCurrentDiamonds(confirmedDiamonds);

    setLastResult({ reward, won, wonMultiplier: wonMultiplierStr });
    setShow3DEffect(true);

    if (won) {
      playSoundFX('win');
      setNotification({
        message: `🎉 LUCKY HIT (${wonMultiplierStr})! Won +${reward.toLocaleString()} Coins!`,
        type: 'win'
      });
    } else {
      playSoundFX('superchat');
      setNotification({
        message: `🎁 Sent ${selectedQuantity}x ${selectedGift.name}!`,
        type: 'success'
      });
    }

    if (onSendSuccess) {
      onSendSuccess({
        gift: selectedGift,
        target: 'Host',
        multiplier: selectedQuantity,
        totalCost,
        reward,
        newBalance: confirmedBalance,
        newDiamonds: confirmedDiamonds,
        diamondsEarned: Number(serverResult?.diamondsEarned || 0),
        netProfitLoss: reward - totalCost
      });
    }

    setIsSending(false);
    setTimeout(() => setNotification(null), 3000);
  };

  return (
    <div
      id="bottom-gift-sheet-backdrop"
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-[2px] animate-fade-in p-0"
      onClick={onClose}
    >
      <div
        id="bottom-gift-sheet-container"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-[#131622]/95 border-t border-cyan-500/30 rounded-t-[32px] shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in slide-in-from-bottom-5 duration-300 text-white select-none pb-4 backdrop-blur-md"
      >
        {/* ========================================================================= */}
        {/* 1. TOP CATEGORY TABS: Gift | CP | Lucky Gift | Exclusive | Lucky Me      */}
        {/* ========================================================================= */}
        <div className="px-4 pt-3.5 pb-2 flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-4 overflow-x-auto scrollbar-none py-1">
            {(['Gift', 'CP', 'Lucky Gift', 'Exclusive', 'Lucky Me'] as const).map((cat) => {
              const isActive = activeCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => {
                    playSoundFX('click');
                    setActiveCategory(cat);
                  }}
                  className={`text-xs sm:text-sm font-bold tracking-wide transition-all relative pb-1 whitespace-nowrap ${
                    isActive ? 'text-amber-300 font-black' : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <span>{cat}</span>
                  {isActive && (
                    <div className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-gradient-to-r from-amber-400 to-emerald-400 rounded-full" />
                  )}
                </button>
              );
            })}
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-full text-neutral-400 hover:text-white shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Winning Patti Ticker for Lucky Gift & Lucky Me */}
        {(activeCategory === 'Lucky Gift' || activeCategory === 'Lucky Me') && (
          <div className="bg-amber-500/15 border-b border-amber-500/30 py-1.5 px-3 flex items-center gap-2 text-[11px] text-amber-300 font-mono font-bold overflow-hidden">
            <span className="shrink-0 flex items-center gap-1 text-amber-400 font-black">🎰 LUCKY HITS:</span>
            <div className="truncate animate-pulse flex items-center gap-4">
              <span>{senderName} hit 500X (+250,000 TC)</span>
              <span>•</span>
              <span>Kavya won 777X (+1,200,000 TC)</span>
              <span>•</span>
              <span>Vikram hit 1000X (+2,500,000 TC)</span>
            </div>
          </div>
        )}

        {/* Status notification toast */}
        {notification && (
          <div
            className={`px-3 py-1.5 text-xs font-bold text-center border-b ${
              notification.type === 'win'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : notification.type === 'error'
                ? 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
            }`}
          >
            {notification.message}
          </div>
        )}

        {/* ========================================================================= */}
        {/* 2. 4-COLUMN x 2-ROW GIFT GRID (Matching Screenshot 1 exactly)              */}
        {/* ========================================================================= */}
        <div className="flex-1 overflow-y-auto px-3 py-3 grid grid-cols-4 gap-2.5 max-h-[300px] scrollbar-none">
          {currentGiftsList.map((gift) => {
            const isSelected = selectedGiftId === gift.id;
            return (
              <div
                key={gift.id}
                onClick={() => {
                  playSoundFX('click');
                  setSelectedGiftId(gift.id);
                }}
                className={`relative flex flex-col items-center justify-between p-2 rounded-2xl cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-cyan-950/40 border-2 border-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.3)] scale-[1.02]'
                    : 'bg-[#181c2d]/70 border border-white/5 hover:border-white/20 hover:bg-[#1d2238]'
                }`}
              >
                {/* Lucky Multiplier Badge */}
                {gift.luckyMultiplierMax && (
                  <span className="absolute -top-1.5 -right-1 px-1.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-pink-500 text-[8px] font-black text-black tracking-tight shadow">
                    {gift.luckyMultiplierMax}X
                  </span>
                )}

                {/* 3D Visual Art / Icon Container */}
                <div className="w-12 h-12 rounded-xl flex items-center justify-center relative overflow-hidden my-0.5">
                  {gift.id === 'g-bell-jar' ? (
                    <div className="relative flex items-center justify-center">
                      <span className="text-3xl drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">🔔</span>
                      <span className="absolute -bottom-1 text-xs">💐</span>
                    </div>
                  ) : gift.id === 'g-virgo-perfume' ? (
                    <div className="relative flex items-center justify-center">
                      <span className="text-3xl drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">🔮</span>
                      <span className="absolute -top-1 right-0 text-[10px]">🌸</span>
                    </div>
                  ) : gift.id === 'g-diamond-ring' ? (
                    <div className="flex items-center justify-center">
                      <span className="text-3xl drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">💍</span>
                    </div>
                  ) : gift.id === 'g-aquarius-pitcher' ? (
                    <div className="flex items-center justify-center">
                      <span className="text-3xl drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">🏺</span>
                    </div>
                  ) : gift.id === 'g-pumpkin-fairy' ? (
                    <div className="flex items-center justify-center">
                      <span className="text-3xl drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">🎃</span>
                    </div>
                  ) : gift.id === 'g-celebration-cake' ? (
                    <div className="flex items-center justify-center">
                      <span className="text-3xl drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">🎂</span>
                    </div>
                  ) : (
                    <span className="text-3xl">{gift.icon}</span>
                  )}
                </div>

                {/* Price in Gold Coins (Exact representation from Screenshot 1) */}
                <div className="flex items-center justify-center gap-1 mt-1">
                  <div className="w-3.5 h-3.5 rounded-full bg-amber-400 border border-amber-200 flex items-center justify-center shadow-xs">
                    <span className="text-[8px] text-black font-black">🪙</span>
                  </div>
                  <span className="text-xs font-bold text-amber-300 font-mono">
                    {gift.cost.toLocaleString()}
                  </span>
                </div>

              </div>
            );
          })}
        </div>

        {/* ========================================================================= */}
        {/* 3. BOTTOM ACTION BAR: Coins Balance Pill + Quantity + Send Button         */}
        {/* ========================================================================= */}
        <div className="px-4 pt-2.5 flex items-center justify-between gap-3 border-t border-white/10">
          
          {/* Coins Balance with Arrow (e.g. 🪙 10720 > ) */}
          <button
            onClick={() => playSoundFX('coin')}
            className="flex items-center gap-1.5 text-sm font-black text-amber-400 hover:text-amber-300 transition-colors"
          >
            <div className="w-5 h-5 rounded-full bg-amber-400 border border-amber-200 flex items-center justify-center shadow-sm">
              <span className="text-xs text-black">🪙</span>
            </div>
            <span className="font-mono text-base tracking-tight">{currentCoins.toLocaleString()}</span>
            <ChevronRight className="w-4 h-4 text-neutral-400" />
          </button>

          {/* Right Action: Quantity Dropdown + Send Button */}
          <div className="flex items-center gap-2 relative">
            
            {/* Quantity Selector Dropdown Button [ 1 ⌃ ] */}
            <div className="relative">
              <button
                onClick={() => setIsQuantityMenuOpen(!isQuantityMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1e2338] hover:bg-[#282f4c] border border-white/15 text-white font-bold text-xs transition-all"
              >
                <span>{selectedQuantity}</span>
                <ChevronUp className={`w-3.5 h-3.5 text-neutral-400 transition-transform ${isQuantityMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Quantity Options Menu */}
              {isQuantityMenuOpen && (
                <div className="absolute right-0 bottom-full mb-2 w-32 bg-[#1b2034] border border-cyan-500/30 rounded-2xl shadow-2xl py-1.5 z-50 max-h-48 overflow-y-auto">
                  {QUANTITY_PRESETS.map((q) => (
                    <button
                      key={q}
                      onClick={() => {
                        setSelectedQuantity(q);
                        setIsQuantityMenuOpen(false);
                      }}
                      className={`w-full px-3 py-1.5 text-left text-xs font-bold flex items-center justify-between hover:bg-white/10 ${
                        selectedQuantity === q ? 'text-cyan-400 bg-cyan-400/10' : 'text-neutral-200'
                      }`}
                    >
                      <span>x{q}</span>
                      {q === 520 && <span className="text-[10px]">❤️</span>}
                      {q === 1314 && <span className="text-[10px]">♾️</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Mint Green / Cyan Send Button (Exact match for Screenshot 1) */}
            <button
              id="bottom-gift-sheet-send-btn"
              disabled={isSending || currentCoins < totalCost}
              onClick={handleSendGift}
              className="px-6 py-2 rounded-full bg-[#34e3a4] hover:bg-[#2bca91] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed text-black font-black text-xs tracking-wider shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-1"
            >
              {isSending ? (
                <span className="animate-spin text-sm">⏳</span>
              ) : (
                <span>Send</span>
              )}
            </button>

          </div>

        </div>

      </div>

      <LuckyGift3DEffect
        isOpen={show3DEffect}
        onClose={() => setShow3DEffect(false)}
        giftName={selectedGift.name}
        giftIcon={selectedGift.icon}
        giftImage={selectedGift.image}
        giftCost={selectedGift.cost}
        senderName={senderName}
        receiverName={roomSeats && roomSeats.length > 0 ? roomSeats[0] : 'Host'}
        quantity={selectedQuantity}
        multiplier={lastResult.wonMultiplier || (selectedGift.luckyMultiplierMax ? `Up to ${selectedGift.luckyMultiplierMax}X` : undefined)}
        rewardCoins={lastResult.reward}
        isLuckyHit={lastResult.won}
        category={activeCategory}
      />
    </div>
  );
};
