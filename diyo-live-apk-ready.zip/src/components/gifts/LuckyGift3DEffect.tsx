/**
 * DIYO LIVE / SR LIVE - Clean Core 3D Virtual Gift Engine
 * 
 * Configured according to the strict visual clarity directive:
 * "Configure the virtual gift rendering logic to only display the core 3D object of the selected gift.
 * Ensure the model is rendered using natural proportions and a balanced central scale,
 * so it fills a compact area without full-screen backgrounds, wrapper effects,
 * or unnecessary UI elements, maintaining perfect visual clarity."
 */

import React, { useEffect, useMemo } from 'react';
import { playSoundFX } from '../../utils/audioSynth';

export interface LuckyGift3DEffectProps {
  isOpen: boolean;
  onClose: () => void;
  giftName: string;
  giftIcon?: string;
  giftImage?: string;
  giftCost?: number;
  senderName?: string;
  senderAvatar?: string;
  receiverName?: string;
  quantity?: number;
  multiplier?: number | string;
  rewardCoins?: number;
  isLuckyHit?: boolean;
  category?: string;
}

interface GiftScaleConfig {
  scale: number;
  maxWidth: number;
  maxHeight: number;
  shadowWidth: number;
}

/**
 * Calculates natural, balanced physical proportions for the core 3D object
 * within a compact central footprint, ensuring the rose appears naturally smaller
 * than a car, rocket, or castle.
 */
function getCoreGiftScaleConfig(name: string): GiftScaleConfig {
  const lower = name.toLowerCase();

  // 1. Colossal / Vehicle Tier (Rocket, Castle, Cars, Yachts) - Compact Balanced Max Bounds
  if (lower.includes('rocket') || lower.includes('space') || lower.includes('missile')) {
    return { scale: 1.0, maxWidth: 140, maxHeight: 220, shadowWidth: 120 };
  }
  if (lower.includes('castle') || lower.includes('palace') || lower.includes('throne')) {
    return { scale: 1.0, maxWidth: 210, maxHeight: 200, shadowWidth: 150 };
  }
  if (lower.includes('car') || lower.includes('ferrari') || lower.includes('lambo') || lower.includes('supercar') || lower.includes('speed')) {
    return { scale: 0.95, maxWidth: 220, maxHeight: 125, shadowWidth: 170 };
  }
  if (lower.includes('yacht') || lower.includes('boat') || lower.includes('ship')) {
    return { scale: 0.95, maxWidth: 220, maxHeight: 130, shadowWidth: 170 };
  }
  if (lower.includes('carriage') || lower.includes('cinderella')) {
    return { scale: 0.95, maxWidth: 200, maxHeight: 180, shadowWidth: 160 };
  }
  if (lower.includes('copter') || lower.includes('chopper') || lower.includes('helicopter') || lower.includes('plane')) {
    return { scale: 0.92, maxWidth: 210, maxHeight: 130, shadowWidth: 150 };
  }

  // 2. Medium Tabletop / Regalia Tier
  if (lower.includes('chest') || lower.includes('lucky box') || lower.includes('box')) {
    return { scale: 0.68, maxWidth: 130, maxHeight: 130, shadowWidth: 110 };
  }
  if (lower.includes('crown') || lower.includes('tiara') || lower.includes('king') || lower.includes('queen')) {
    return { scale: 0.65, maxWidth: 125, maxHeight: 120, shadowWidth: 100 };
  }
  if (lower.includes('trophy') || lower.includes('cup') || lower.includes('shield')) {
    return { scale: 0.66, maxWidth: 120, maxHeight: 130, shadowWidth: 100 };
  }
  if (lower.includes('cake') || lower.includes('banquet') || lower.includes('feast')) {
    return { scale: 0.64, maxWidth: 125, maxHeight: 115, shadowWidth: 105 };
  }

  // 3. Delicate / Petite / Floral Tier (Rose is naturally smaller than car or rocket)
  if (lower.includes('rose') || lower.includes('bouquet') || lower.includes('flower') || lower.includes('tulip') || lower.includes('lotus')) {
    return { scale: 0.46, maxWidth: 88, maxHeight: 95, shadowWidth: 65 };
  }
  if (lower.includes('ring') || lower.includes('diamond') || lower.includes('gem') || lower.includes('necklace')) {
    return { scale: 0.42, maxWidth: 80, maxHeight: 80, shadowWidth: 60 };
  }
  if (lower.includes('perfume') || lower.includes('lipstick') || lower.includes('makeup')) {
    return { scale: 0.44, maxWidth: 75, maxHeight: 90, shadowWidth: 60 };
  }
  if (lower.includes('heart') || lower.includes('kiss') || lower.includes('love')) {
    return { scale: 0.48, maxWidth: 90, maxHeight: 90, shadowWidth: 70 };
  }
  if (lower.includes('candy') || lower.includes('coffee') || lower.includes('bell') || lower.includes('clover')) {
    return { scale: 0.40, maxWidth: 70, maxHeight: 75, shadowWidth: 55 };
  }

  // Default compact fallback
  return { scale: 0.58, maxWidth: 115, maxHeight: 115, shadowWidth: 90 };
}

export const LuckyGift3DEffect: React.FC<LuckyGift3DEffectProps> = ({
  isOpen,
  onClose,
  giftName,
  giftIcon = '🎁',
  giftImage,
}) => {
  // Synchronized Impact Sound & Auto-Dismiss lifecycle
  useEffect(() => {
    if (isOpen) {
      playSoundFX('gift_3d_impact');

      const timer = setTimeout(() => {
        onClose();
      }, 3600);
      return () => clearTimeout(timer);
    }
  }, [isOpen, onClose]);

  // Compute natural proportion sizing
  const scaleConfig = useMemo(() => getCoreGiftScaleConfig(giftName), [giftName]);

  if (!isOpen) return null;

  // Normalized gift detection for tailored 3D geometries
  const lowerName = giftName.toLowerCase();
  const isCarriage = lowerName.includes('carriage') || lowerName.includes('cinderella');
  const isCastle = lowerName.includes('castle') || lowerName.includes('palace') || lowerName.includes('throne');
  const isRing = lowerName.includes('ring') || lowerName.includes('diamond');
  const isRoses = lowerName.includes('rose') || lowerName.includes('bouquet') || lowerName.includes('flower');
  const isSupercar = lowerName.includes('car') || lowerName.includes('ferrari') || lowerName.includes('lambo') || lowerName.includes('supercar') || lowerName.includes('speed');
  const isYacht = lowerName.includes('yacht') || lowerName.includes('boat') || lowerName.includes('ship');
  const isRocket = lowerName.includes('rocket') || lowerName.includes('space') || lowerName.includes('missile');
  const isCrown = lowerName.includes('crown') || lowerName.includes('tiara') || lowerName.includes('king') || lowerName.includes('queen');
  const isHelicopter = lowerName.includes('copter') || lowerName.includes('chopper') || lowerName.includes('helicopter');
  const isChest = lowerName.includes('chest') || lowerName.includes('box') || lowerName.includes('lucky box');
  const isHeart = lowerName.includes('heart') || lowerName.includes('kiss') || lowerName.includes('love');

  return (
    <div
      id="pure-core-3d-gift"
      onClick={onClose}
      className="fixed inset-0 z-[100] flex items-center justify-center select-none overflow-hidden cursor-pointer bg-transparent pointer-events-auto"
    >
      {/* 
        PURE CORE 3D OBJECT ONLY:
        - Rendered with natural proportions & balanced central scale
        - Fills a compact area in screen center
        - NO full-screen backgrounds (underlying stream/app stays fully visible)
        - NO wrapper effects (no pedestal rings, no light beams, no particle storms)
        - NO UI cards, badges, timers or text overlays
        - Flawless visual clarity with subtle 3D hover & bouncy pop-up
      */}
      <div 
        className="relative flex items-center justify-center"
        style={{ perspective: '1000px' }}
      >
        <div 
          className="relative bouncy-gift-popup slow-3d-rotate flex flex-col items-center justify-center pointer-events-none"
          style={{
            transformStyle: 'preserve-3d',
            maxWidth: `${scaleConfig.maxWidth}px`,
            maxHeight: `${scaleConfig.maxHeight}px`,
          }}
        >
          {/* Custom Core 3D Model Rendering with Natural Physical Proportions */}
          {isCarriage ? (
            // Core 3D Cinderella Royal Carriage
            <div 
              className="relative flex items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              {/* Carriage Main Cabin */}
              <div className="relative w-32 h-32 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 border-4 border-yellow-100 shadow-[0_12px_28px_rgba(245,158,11,0.5),inset_0_0_16px_rgba(255,255,255,0.7)] flex items-center justify-center overflow-hidden">
                <div className="w-16 h-16 rounded-full border-2 border-amber-800/40 bg-cyan-950/70 shadow-inner flex items-center justify-center relative">
                  <span className="text-2xl animate-pulse">👑</span>
                </div>
              </div>

              {/* Crown on Carriage Roof */}
              <div className="absolute -top-2 left-1/2 -translate-x-1/2 text-2xl drop-shadow-[0_0_8px_gold]">
                👑
              </div>

              {/* Carriage Wheels */}
              <div className="absolute -bottom-2 -left-1 w-12 h-12 rounded-full border-4 border-amber-300 bg-amber-950/80 shadow-md flex items-center justify-center animate-spin" style={{ animationDuration: '6s' }}>
                <div className="w-1.5 h-1.5 rounded-full bg-yellow-100" />
              </div>
              <div className="absolute -bottom-2 -right-1 w-12 h-12 rounded-full border-4 border-amber-300 bg-amber-950/80 shadow-md flex items-center justify-center animate-spin" style={{ animationDuration: '6s' }}>
                <div className="w-1.5 h-1.5 rounded-full bg-yellow-100" />
              </div>
            </div>
          ) : isCastle ? (
            // Core 3D Crystal Palace Castle (Monumental proportion)
            <div 
              className="relative flex flex-col items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <div className="text-7xl sm:text-8xl drop-shadow-[0_12px_28px_rgba(56,189,248,0.7)] animate-bounce" style={{ animationDuration: '2.5s' }}>
                🏰
              </div>
            </div>
          ) : isRing ? (
            // Core 3D Diamond Solitaire Ring (Delicate petite proportion)
            <div 
              className="relative flex items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-5xl drop-shadow-[0_0_20px_rgba(56,189,248,0.8)] animate-pulse">💍</span>
            </div>
          ) : isRoses ? (
            // Core 3D Rose Bouquet (Delicate floral proportion - Noticeably smaller than car or rocket)
            <div 
              className="relative flex flex-col items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-5xl drop-shadow-[0_8px_20px_rgba(244,63,94,0.8)]">🌹</span>
              <div className="text-base text-amber-300 -mt-1">🎀</div>
            </div>
          ) : isSupercar ? (
            // Core 3D Neon Supercar (Wide Vehicle proportion)
            <div 
              className="relative flex flex-col items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-7xl sm:text-8xl drop-shadow-[0_12px_28px_rgba(239,68,68,0.75)]">🏎️</span>
            </div>
          ) : isYacht ? (
            // Core 3D Luxury Yacht
            <div 
              className="relative flex flex-col items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-7xl sm:text-8xl drop-shadow-[0_12px_28px_rgba(56,189,248,0.75)]">🛥️</span>
            </div>
          ) : isRocket ? (
            // Core 3D Space Rocket (Aerospace proportion)
            <div 
              className="relative flex flex-col items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-7xl sm:text-8xl drop-shadow-[0_12px_28px_rgba(249,115,22,0.75)] -rotate-12">🚀</span>
              <div className="text-2xl -mt-3 animate-pulse">🔥</div>
            </div>
          ) : isCrown ? (
            // Core 3D Imperial Crown
            <div 
              className="relative flex items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-6xl drop-shadow-[0_0_24px_rgba(245,158,11,0.85)] animate-pulse">👑</span>
            </div>
          ) : isHelicopter ? (
            // Core 3D Chopper
            <div 
              className="relative flex items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-7xl drop-shadow-[0_12px_28px_rgba(168,85,247,0.75)]">🚁</span>
            </div>
          ) : isChest ? (
            // Core 3D Lucky Chest
            <div 
              className="relative flex flex-col items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-6xl drop-shadow-[0_12px_28px_rgba(245,158,11,0.85)] animate-bounce">📦</span>
            </div>
          ) : isHeart ? (
            // Core 3D Heart (Petite love token)
            <div 
              className="relative flex items-center justify-center"
              style={{ width: `${scaleConfig.maxWidth}px`, height: `${scaleConfig.maxHeight}px` }}
            >
              <span className="text-5xl drop-shadow-[0_0_25px_rgba(244,63,94,0.85)] animate-pulse">💖</span>
            </div>
          ) : (
            // Universal Clean Core 3D Item
            <div 
              className="relative rounded-2xl bg-gradient-to-tr from-purple-900/90 via-indigo-900/90 to-slate-900/90 border-2 border-amber-300/80 shadow-[0_12px_32px_rgba(0,0,0,0.75),0_0_20px_rgba(245,158,11,0.4)] flex items-center justify-center overflow-hidden"
              style={{
                width: `${scaleConfig.maxWidth}px`,
                height: `${scaleConfig.maxHeight}px`,
              }}
            >
              {giftImage ? (
                <img src={giftImage} alt={giftName} className="w-3/4 h-3/4 object-contain drop-shadow-xl" />
              ) : (
                <span className="text-4xl drop-shadow-md">{giftIcon}</span>
              )}
            </div>
          )}

          {/* Clean ground contact shadow scaled to model proportion */}
          <div 
            className="rounded-full bg-black/40 blur-sm mt-1 transition-all duration-300"
            style={{
              width: `${scaleConfig.shadowWidth}px`,
              height: `${Math.max(5, scaleConfig.shadowWidth * 0.08)}px`,
              transform: 'rotateX(75deg)'
            }}
          />
        </div>
      </div>

      {/* Embedded CSS Animations for Clean Pop-up and Subtle 3D Depth */}
      <style>{`
        @keyframes bouncyGiftPop {
          0% {
            opacity: 0;
            transform: scale(0.2) translateY(80px);
          }
          60% {
            opacity: 1;
            transform: scale(1.15) translateY(-8px);
          }
          80% {
            transform: scale(0.96) translateY(2px);
          }
          100% {
            opacity: 1;
            transform: scale(1.0) translateY(0);
          }
        }

        @keyframes slow3DRotation {
          0% {
            transform: perspective(1000px) rotateY(-14deg) rotateX(4deg) translateY(0);
          }
          50% {
            transform: perspective(1000px) rotateY(14deg) rotateX(8deg) translateY(-8px);
          }
          100% {
            transform: perspective(1000px) rotateY(-14deg) rotateX(4deg) translateY(0);
          }
        }

        .bouncy-gift-popup {
          animation: bouncyGiftPop 0.7s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
        }

        .slow-3d-rotate {
          animation: slow3DRotation 4.5s ease-in-out infinite alternate;
        }
      `}</style>
    </div>
  );
};
