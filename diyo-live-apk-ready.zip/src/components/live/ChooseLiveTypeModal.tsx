import React, { useState, useRef, useEffect } from 'react';
import { 
  Video, 
  Users, 
  Sparkles, 
  Crown, 
  X, 
  Radio, 
  ArrowRight, 
  Camera, 
  RefreshCw, 
  Sliders, 
  Mic, 
  Flame, 
  Music, 
  Gamepad2, 
  Smile, 
  CheckCircle,
  Eye,
  Lock
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface ChooseLiveTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVideoLive: (details?: { title: string; tag: string }) => void;
  onSelectPartyLive: (details?: { title: string; tag: string }) => void;
  userAvatar?: string;
  userName?: string;
  hasApprovedAgency?: boolean;
  onAgencyBlocked?: () => void;
}

export const ChooseLiveTypeModal: React.FC<ChooseLiveTypeModalProps> = ({
  isOpen,
  onClose,
  onSelectVideoLive,
  onSelectPartyLive,
  userAvatar,
  userName,
  hasApprovedAgency = false,
  onAgencyBlocked
}) => {
  const [selectedType, setSelectedType] = useState<'video' | 'party' | 'audio' | 'gaming'>('video');
  const [streamTitle, setStreamTitle] = useState('🔥 DIYO LIVE Super Showcase: Music, Fun & Lucky Gifts!');
  const [selectedTag, setSelectedTag] = useState('Music');
  const [isBeautyOn, setIsBeautyOn] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('user');
  
  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const tags = [
    { label: '🔥 Viral', tag: 'Viral' },
    { label: '🎵 Music', tag: 'Music' },
    { label: '💃 Dance PK', tag: 'Dance PK' },
    { label: '🎮 Gaming', tag: 'Gaming' },
    { label: '💬 Chit Chat', tag: 'Chit Chat' },
    { label: '👑 Crown Party', tag: 'Crown Party' }
  ];

  useEffect(() => {
    if (isOpen) {
      navigator.mediaDevices?.getUserMedia({
        video: { facingMode: cameraFacing },
        audio: false
      }).then(st => {
        streamRef.current = st;
        if (videoPreviewRef.current) {
          videoPreviewRef.current.srcObject = st;
        }
      }).catch(() => {});
    } else {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
    }
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
    };
  }, [isOpen, cameraFacing]);

  if (!isOpen) return null;

  const handleFlipCamera = () => {
    setCameraFacing(prev => prev === 'user' ? 'environment' : 'user');
    playSoundFX('click');
  };

  const handleStartBroadcast = () => {
    playSoundFX('superchat');
    if (!hasApprovedAgency) {
      if (onAgencyBlocked) {
        onAgencyBlocked();
      }
      return;
    }
    const details = {
      title: streamTitle.trim() || `${userName || 'Star Broadcaster'}'s ${selectedType === 'party' ? 'Party Room' : 'Live Stream'}`,
      tag: selectedTag
    };
    if (selectedType === 'party') {
      onSelectPartyLive(details);
    } else {
      onSelectVideoLive(details);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0d141e] sm:bg-black/80 sm:backdrop-blur-md flex items-center justify-center p-0 sm:p-4 animate-in fade-in select-none">
      
      {/* Mobile-First Full Viewport Container */}
      <div className="relative w-full h-full sm:h-auto sm:max-h-[92vh] sm:max-w-xl bg-[#0d141e] sm:border sm:border-neutral-800 sm:rounded-3xl flex flex-col justify-between overflow-y-auto scrollbar-none shadow-2xl">
        
        {/* Background Subtle Camera Blur for Live Studio Feel */}
        <div className="absolute inset-0 z-0 opacity-20 pointer-events-none overflow-hidden">
          <video
            ref={videoPreviewRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover blur-md"
          />
        </div>

        {/* ========================================================================= */}
        {/* TOP HEADER: Studio Header & Close Button                                  */}
        {/* ========================================================================= */}
        <div className="relative z-10 pt-safe-top p-4 sm:p-5 flex items-center justify-between border-b border-neutral-800/80 bg-neutral-900/60 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 flex items-center justify-center shadow-md shadow-emerald-950">
              <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
                <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              </div>
            </div>
            <div>
              <h2 className="text-base font-black text-white font-['Outfit'] tracking-wide">
                DIYO LIVE Broadcast Studio
              </h2>
              <span className="text-[10px] text-emerald-400 font-mono font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                HD 4K Low Latency Ready
              </span>
            </div>
          </div>

          <button
            id="btn-close-live-type-modal"
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* ========================================================================= */}
        {/* MAIN BODY: Camera Thumbnail + Title Input + Mode Selectors                */}
        {/* ========================================================================= */}
        <div className="relative z-10 p-4 sm:p-6 space-y-5 flex-1">
          
          {/* Cover & Broadcast Title Card */}
          <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center gap-3.5 backdrop-blur-md">
            {/* Live Stream Cover Thumbnail */}
            <div className="relative w-16 h-16 rounded-2xl overflow-hidden ring-2 ring-emerald-500/50 flex-shrink-0 group cursor-pointer">
              <img
                src={userAvatar}
                alt={userName}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera className="w-4 h-4 text-white" />
              </div>
              <span className="absolute bottom-0 inset-x-0 bg-emerald-600 text-[8px] font-black text-white text-center py-0.5 uppercase tracking-tighter">
                Cover
              </span>
            </div>

            {/* Title & Tag Selector */}
            <div className="flex-1 min-w-0 space-y-1.5">
              <input
                type="text"
                value={streamTitle}
                onChange={(e) => setStreamTitle(e.target.value)}
                placeholder="Give your live stream a captivating title..."
                className="w-full bg-transparent text-sm font-bold text-white placeholder-neutral-500 focus:outline-none border-b border-transparent focus:border-emerald-500 pb-0.5"
              />
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] text-neutral-400 font-medium">Tag:</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  #{selectedTag}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Tag Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {tags.map((t) => (
              <button
                key={t.tag}
                onClick={() => {
                  setSelectedTag(t.tag);
                  playSoundFX('click');
                }}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all border ${
                  selectedTag === t.tag
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 border-emerald-400 text-white shadow-md'
                    : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Broadcast Format Selection */}
          <div className="space-y-2">
            <span className="text-xs font-black text-neutral-400 uppercase tracking-wider">
              Broadcast Room Format
            </span>

            <div className="grid grid-cols-2 gap-3">
              {/* Option 1: Video Live (Solo Host / PK Battle) */}
              <div
                id="btn-choose-video-live"
                onClick={() => {
                  setSelectedType('video');
                  playSoundFX('click');
                }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-2.5 ${
                  selectedType === 'video'
                    ? 'bg-gradient-to-br from-violet-950/50 via-neutral-900 to-neutral-900 border-violet-500 shadow-xl shadow-violet-950/40 ring-1 ring-violet-500/50'
                    : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700 opacity-70 hover:opacity-100'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className={`w-9 h-9 rounded-xl p-0.5 flex items-center justify-center shadow-md ${
                    selectedType === 'video'
                      ? 'bg-gradient-to-tr from-violet-400 to-fuchsia-500 shadow-violet-950'
                      : 'bg-neutral-800'
                  }`}>
                    <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
                      <Video className={`w-4 h-4 ${selectedType === 'video' ? 'text-violet-400' : 'text-neutral-400'}`} />
                    </div>
                  </div>
                  <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase border ${
                    selectedType === 'video'
                      ? 'bg-violet-500/20 text-violet-300 border-violet-500/30'
                      : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                  }`}>
                    Solo / PK
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-1">
                    <h3 className="text-xs font-black text-white font-['Outfit']">
                      Video Live
                    </h3>
                    {selectedType === 'video' && <CheckCircle className="w-3.5 h-3.5 text-violet-400 flex-shrink-0" />}
                  </div>
                  <p className="text-[10px] text-neutral-400 mt-0.5 leading-snug">
                    Solo camera live with PK Battles & Lucky Gifts.
                  </p>
                </div>
              </div>

              {/* Option 2: 20-Seat Party Live */}
              <div
                id="btn-choose-party-live"
                onClick={() => {
                  setSelectedType('party');
                  playSoundFX('click');
                }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-2.5 ${
                  selectedType === 'party'
                    ? 'bg-gradient-to-br from-amber-950/50 via-neutral-900 to-neutral-900 border-amber-500 shadow-xl shadow-amber-950/40 ring-1 ring-amber-500/50'
                    : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700 opacity-70 hover:opacity-100'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className={`w-9 h-9 rounded-xl p-0.5 flex items-center justify-center shadow-md ${
                    selectedType === 'party'
                      ? 'bg-gradient-to-tr from-amber-400 to-yellow-500 shadow-amber-950'
                      : 'bg-neutral-800'
                  }`}>
                    <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
                      <Crown className={`w-4 h-4 ${selectedType === 'party' ? 'text-amber-400' : 'text-neutral-400'}`} />
                    </div>
                  </div>
                  <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase border ${
                    selectedType === 'party'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                  }`}>
                    20 Seats
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-1">
                    <h3 className="text-xs font-black text-white font-['Outfit']">
                      Party Live Room
                    </h3>
                    {selectedType === 'party' && <CheckCircle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />}
                  </div>
                  <p className="text-[10px] text-neutral-400 mt-0.5 leading-snug">
                    Multi-guest audio/video party. Host receives Sir Crown!
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Studio Device Controls (Beauty, Camera, Mic) */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800">
            <span className="text-xs font-bold text-neutral-300">Quick Studio Settings:</span>
            
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setIsBeautyOn(!isBeautyOn);
                  playSoundFX('click');
                }}
                className={`p-2 rounded-xl border text-xs font-bold transition-all ${
                  isBeautyOn
                    ? 'bg-pink-500/20 border-pink-500/40 text-pink-300'
                    : 'bg-neutral-800 border-neutral-700 text-neutral-500'
                }`}
                title="Beauty Filter"
              >
                <Sparkles className="w-4 h-4" />
              </button>

              <button
                onClick={handleFlipCamera}
                className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 transition-all"
                title="Flip Camera"
              >
                <RefreshCw className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  setIsMicOn(!isMicOn);
                  playSoundFX('click');
                }}
                className={`p-2 rounded-xl border text-xs font-bold transition-all ${
                  isMicOn
                    ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                }`}
                title="Microphone"
              >
                <Mic className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

        {/* ========================================================================= */}
        {/* BOTTOM LAUNCHER: GO LIVE NOW BUTTON                                       */}
        {/* ========================================================================= */}
        <div className="relative z-10 p-4 sm:p-5 border-t border-neutral-800 bg-neutral-900/90 backdrop-blur-md pb-safe-bottom">
          <button
            id="btn-confirm-go-live-now"
            onClick={handleStartBroadcast}
            className="w-full py-3.5 px-6 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl transition-transform active:scale-[0.98] cursor-pointer bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-neutral-950 shadow-emerald-950/60"
          >
            <Radio className="w-5 h-5 animate-pulse" />
            <span>START LIVE BROADCAST</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
