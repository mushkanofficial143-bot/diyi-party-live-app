import React, { useState, useEffect, useCallback } from 'react';
import {
  Clock,
  Gift,
  Coins,
  CheckCircle2,
  Trophy,
  History,
  X,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ShieldCheck,
  Copy,
  Check,
  Radio,
  ExternalLink
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { playSoundFX } from '../../utils/audioSynth';

export interface HostRewardRecord {
  transactionId: string;
  hostId: string;
  hostName: string;
  roomId: string;
  liveType: 'VIDEO' | 'PARTY';
  requiredTime: string;
  requiredSeconds: number;
  rewardCoins: number;
  completionTime: string;
  durationSeconds: number;
  status: 'REWARDED';
}

interface HostLiveRewardWidgetProps {
  roomId: string;
  liveType: 'VIDEO' | 'PARTY';
  hostId: string;
  hostName?: string;
  onRewardEarned?: (rewardCoins: number, newBalance?: number) => void;
  compact?: boolean;
}

export const HostLiveRewardWidget: React.FC<HostLiveRewardWidgetProps> = ({
  roomId,
  liveType,
  hostId,
  hostName,
  onRewardEarned,
  compact = false
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(!compact);
  const [verifiedSeconds, setVerifiedSeconds] = useState<number>(0);
  const [liveTimeFormatted, setLiveTimeFormatted] = useState<string>('00:00:00');
  const [targetTimeFormatted, setTargetTimeFormatted] = useState<string>('02:00:00');
  const [rewardCoins, setRewardCoins] = useState<number>(liveType === 'VIDEO' ? 70000 : 50000);
  const [status, setStatus] = useState<'In Progress' | 'REWARDED'>('In Progress');
  const [rewardClaimed, setRewardClaimed] = useState<boolean>(false);
  const [rewardTransactionId, setRewardTransactionId] = useState<string | null>(null);
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [rewardHistory, setRewardHistory] = useState<HostRewardRecord[]>([]);
  const [copiedTxId, setCopiedTxId] = useState<string | null>(null);
  const [hasTriggeredCelebration, setHasTriggeredCelebration] = useState<boolean>(false);

  // Send heartbeat to backend and verify continuous live duration
  const pollHeartbeat = useCallback(async () => {
    if (!roomId || !hostId) return;
    try {
      const res = await fetch('/api/host-rewards/heartbeat-and-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, hostId })
      });
      if (!res.ok) return;
      const data = await res.json();
      if (data.success) {
        setVerifiedSeconds(data.verifiedSeconds || 0);
        setLiveTimeFormatted(data.liveTimeFormatted || '00:00:00');
        setTargetTimeFormatted(data.targetTimeFormatted || '02:00:00');
        setRewardCoins(data.rewardCoins);
        setStatus(data.status);
        setRewardClaimed(data.rewardClaimed);
        if (data.rewardTransactionId) {
          setRewardTransactionId(data.rewardTransactionId);
        }

        // Celebrate if just rewarded
        if (data.justRewarded && !hasTriggeredCelebration) {
          setHasTriggeredCelebration(true);
          try {
            playSoundFX('win');
            confetti({
              particleCount: 80,
              spread: 70,
              origin: { y: 0.6 }
            });
          } catch (e) {}

          if (onRewardEarned) {
            onRewardEarned(data.rewardCoins, data.currentCoinBalance);
          }
        }
      }
    } catch (e) {
      // Benign network retry on next interval
    }
  }, [roomId, hostId, hasTriggeredCelebration, onRewardEarned]);

  // Periodic heartbeat every 5 seconds
  useEffect(() => {
    pollHeartbeat();
    const interval = setInterval(pollHeartbeat, 5000);
    return () => clearInterval(interval);
  }, [pollHeartbeat]);

  // Load reward history
  const loadHistory = async () => {
    try {
      const res = await fetch(`/api/host-rewards/history?hostId=${encodeURIComponent(hostId)}`);
      const data = await res.json();
      if (data.success) {
        setRewardHistory(data.history || []);
      }
    } catch (e) {
      console.error("Failed to load host reward history", e);
    }
  };

  const openHistory = () => {
    loadHistory();
    setShowHistoryModal(true);
  };

  const handleCopy = (tx: string) => {
    navigator.clipboard?.writeText(tx);
    setCopiedTxId(tx);
    setTimeout(() => setCopiedTxId(null), 2000);
  };

  const progressPercent = Math.min(100, Math.max(0, (verifiedSeconds / 7200) * 100));

  return (
    <>
      {/* Floating Host Reward HUD Card */}
      <div className="relative z-30 w-full max-w-sm mx-auto transition-all duration-200">
        <div className="rounded-xl border border-amber-500/40 bg-neutral-950/85 backdrop-blur-md shadow-2xl p-2.5 text-white">
          
          {/* Header Bar */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shadow-md ${
                liveType === 'VIDEO'
                  ? 'bg-gradient-to-tr from-rose-500 to-amber-500 text-white'
                  : 'bg-gradient-to-tr from-purple-600 to-indigo-500 text-white'
              }`}>
                {liveType === 'VIDEO' ? '📹' : '🎙️'}
              </div>
              <div className="flex flex-col">
                <span className="text-[11px] font-black uppercase tracking-wider text-amber-300 flex items-center gap-1">
                  {liveType} LIVE REWARD
                  {rewardClaimed && <span className="text-emerald-400 text-[10px]">✓</span>}
                </span>
                <span className="text-[9px] text-neutral-400 font-medium">
                  2 Hours → <span className="text-amber-300 font-bold">+{rewardCoins.toLocaleString()} Coins</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={openHistory}
                className="p-1 rounded-md bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors"
                title="View Reward History"
              >
                <History className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1 rounded-md bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors"
                title={isExpanded ? "Collapse" : "Expand"}
              >
                {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Quick Progress Indicator */}
          <div className="mt-2 w-full bg-neutral-800 rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                rewardClaimed
                  ? 'bg-gradient-to-r from-emerald-400 to-teal-300'
                  : 'bg-gradient-to-r from-amber-500 to-yellow-300'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Expanded Specification Details */}
          {isExpanded && (
            <div className="mt-2.5 pt-2 border-t border-neutral-800/80 space-y-1.5 font-mono text-[11px]">
              
              {rewardClaimed ? (
                /* Completed State */
                <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-lg p-2 flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-300 flex items-center gap-1">
                      <Trophy className="w-3.5 h-3.5 text-amber-400" />
                      LIVE TIME COMPLETED
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-black text-[9px] border border-emerald-500/40">
                      REWARDED
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-neutral-300">
                    <span>Reward:</span>
                    <span className="font-bold text-amber-300">+{rewardCoins.toLocaleString()} Coins</span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-neutral-300">
                    <span>Verified Duration:</span>
                    <span className="text-white font-bold">{liveTimeFormatted}</span>
                  </div>
                  {rewardTransactionId && (
                    <div className="flex items-center justify-between text-[9px] text-neutral-400 pt-1 border-t border-emerald-900/40">
                      <span>TxID:</span>
                      <button
                        onClick={() => handleCopy(rewardTransactionId)}
                        className="text-neutral-300 hover:text-white flex items-center gap-1 underline font-mono"
                      >
                        {rewardTransactionId.slice(0, 15)}...
                        {copiedTxId === rewardTransactionId ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                /* In Progress State */
                <div className="bg-neutral-900/70 rounded-lg p-2 flex flex-col gap-1 text-[10px]">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">Live Time:</span>
                    <span className="text-white font-bold tracking-wider">{liveTimeFormatted}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">Target:</span>
                    <span className="text-neutral-300 font-bold">{targetTimeFormatted}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">Reward:</span>
                    <span className="text-amber-300 font-bold">{rewardCoins.toLocaleString()} Coins</span>
                  </div>
                  <div className="flex items-center justify-between pt-0.5 border-t border-neutral-800">
                    <span className="text-neutral-400">Status:</span>
                    <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[9px] border border-amber-500/40 animate-pulse">
                      In Progress
                    </span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between text-[9px] text-neutral-400 pt-1">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Backend Verified
                </span>
                <span className="text-neutral-500">
                  {Math.floor(progressPercent)}% of 2 Hours
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Host Reward History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-700 rounded-2xl shadow-2xl p-4 text-white max-h-[85vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                  <Trophy className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Host Live Reward History</h3>
                  <p className="text-[11px] text-neutral-400">Verified 2-Hour Live-Time Coin Transactions</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowHistoryModal(false)}
                className="w-7 h-7 rounded-full bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content List */}
            <div className="flex-1 overflow-y-auto py-3 space-y-2.5 pr-1">
              {rewardHistory.length === 0 ? (
                <div className="py-10 text-center text-neutral-400 flex flex-col items-center gap-2">
                  <Clock className="w-8 h-8 text-neutral-600" />
                  <p className="text-xs">No live-time rewards completed yet.</p>
                  <p className="text-[10px] text-neutral-500 max-w-xs">
                    Stay LIVE continuously for 2 Hours (Video: +70,000 Coins / Party: +50,000 Coins) to automatically earn your rewards.
                  </p>
                </div>
              ) : (
                rewardHistory.map((item) => (
                  <div
                    key={item.transactionId}
                    className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800 flex flex-col gap-1.5 hover:border-amber-500/40 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase ${
                          item.liveType === 'VIDEO'
                            ? 'bg-rose-900/60 text-rose-300 border border-rose-500/30'
                            : 'bg-purple-900/60 text-purple-300 border border-purple-500/30'
                        }`}>
                          {item.liveType} LIVE
                        </span>
                        <span className="text-[11px] font-bold text-white font-mono">
                          Room: {item.roomId}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-400 font-bold text-[10px] flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        {item.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] font-mono py-1 border-y border-neutral-800/60">
                      <div>
                        <span className="text-neutral-400 text-[10px]">Required Time:</span>
                        <p className="font-bold text-white">{item.requiredTime}</p>
                      </div>
                      <div>
                        <span className="text-neutral-400 text-[10px]">Reward Granted:</span>
                        <p className="font-bold text-amber-300">+{item.rewardCoins.toLocaleString()} Coins</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-neutral-400 pt-0.5">
                      <span>Host ID: <strong className="text-neutral-200">{item.hostId}</strong></span>
                      <span>{new Date(item.completionTime).toLocaleTimeString()} {new Date(item.completionTime).toLocaleDateString()}</span>
                    </div>

                    <div className="flex items-center justify-between text-[9px] text-neutral-500 pt-1 border-t border-neutral-900">
                      <span className="font-mono truncate max-w-[220px]">
                        Tx: {item.transactionId}
                      </span>
                      <button
                        onClick={() => handleCopy(item.transactionId)}
                        className="text-amber-400 hover:text-amber-300 flex items-center gap-1"
                      >
                        {copiedTxId === item.transactionId ? 'Copied' : 'Copy Tx'}
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            <div className="pt-3 border-t border-neutral-800 flex items-center justify-between text-[11px] text-neutral-400">
              <span className="text-amber-300 font-semibold">Video: 70,000 | Party: 50,000</span>
              <button
                type="button"
                onClick={() => setShowHistoryModal(false)}
                className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-medium text-xs transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
