import React, { useEffect, useRef, useState } from 'react';
import { liveStreamRelay, LiveStreamFramePayload } from '../../services/liveStreamRelayService';
import { Video, VideoOff, Mic, Wifi, Sparkles, Swords, UserCheck, Radio } from 'lucide-react';

interface LiveStreamVideoPlayerProps {
  roomId: string;
  isHost: boolean;
  currentRoom?: any;
  currentUser?: any;
  localStream: MediaStream | null;
  isCameraOn: boolean;
  isVoiceOnly: boolean;
  activeFilter?: 'normal' | 'beauty' | 'warm' | 'cyber' | 'glow';
  audioLevel?: number;
  isPkBattleActive?: boolean;
  opponentInfo?: {
    name: string;
    avatar: string;
    vip?: number;
  };
  coHostStream?: MediaStream | null;
  isCoHostActive?: boolean;
  onToggleCoHost?: () => void;
}

export const LiveStreamVideoPlayer: React.FC<LiveStreamVideoPlayerProps> = ({
  roomId,
  isHost,
  currentRoom,
  currentUser,
  localStream,
  isCameraOn,
  isVoiceOnly,
  activeFilter = 'normal',
  audioLevel = 35,
  isPkBattleActive = false,
  opponentInfo,
  coHostStream,
  isCoHostActive = false,
  onToggleCoHost
}) => {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const coHostVideoRef = useRef<HTMLVideoElement>(null);
  const studioCanvasRef = useRef<HTMLCanvasElement>(null);

  const [remoteFrame, setRemoteFrame] = useState<LiveStreamFramePayload | null>(null);
  const [hasRemoteVideo, setHasRemoteVideo] = useState(false);

  // Host profile information
  const hostName = currentRoom?.hostName || currentRoom?.name || (isHost ? currentUser?.name : 'Star Broadcaster');
  const hostAvatar = currentRoom?.hostAvatar || currentRoom?.coverImage || currentRoom?.cover || (isHost ? currentUser?.avatar : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400');
  const hostTag = currentRoom?.tag || 'Video Live';
  const isMusicTheme = hostTag.toLowerCase().includes('music') || hostName.toLowerCase().includes('dj');
  const isGamingTheme = hostTag.toLowerCase().includes('game') || hostTag.toLowerCase().includes('cyber') || hostName.toLowerCase().includes('esports');

  // --------------------------------------------------------------------------
  // 1. BROADCASTER (HOST): Attach local camera & start broadcasting frames
  // --------------------------------------------------------------------------
  useEffect(() => {
    if (!isHost) return;

    if (localStream && localVideoRef.current) {
      localVideoRef.current.srcObject = localStream;
      localVideoRef.current.play().catch(() => {});

      liveStreamRelay.startBroadcasting(
        roomId,
        currentUser?.id || '0000001',
        currentUser?.name || hostName,
        () => localVideoRef.current,
        () => audioLevel,
        activeFilter
      );
    } else {
      liveStreamRelay.startBroadcasting(
        roomId,
        currentUser?.id || '0000001',
        currentUser?.name || hostName,
        () => studioCanvasRef.current,
        () => audioLevel,
        activeFilter
      );
    }

    return () => {
      liveStreamRelay.stopBroadcasting();
    };
  }, [isHost, localStream, roomId, currentUser?.id, currentUser?.name, hostName, activeFilter, audioLevel]);

  // --------------------------------------------------------------------------
  // 2. CO-HOST BROADCASTING (When viewer joins video as co-host)
  // --------------------------------------------------------------------------
  useEffect(() => {
    if (isHost) return;

    if (isCoHostActive && coHostStream && coHostVideoRef.current) {
      coHostVideoRef.current.srcObject = coHostStream;
      coHostVideoRef.current.play().catch(() => {});

      liveStreamRelay.startCoHostBroadcasting(
        roomId,
        currentUser?.id || 'COHOST-USER',
        currentUser?.name || 'Co-Host',
        () => coHostVideoRef.current
      );
    } else {
      liveStreamRelay.stopCoHostBroadcasting(roomId);
    }

    return () => {
      if (!isHost) {
        liveStreamRelay.stopCoHostBroadcasting(roomId);
      }
    };
  }, [isHost, isCoHostActive, coHostStream, roomId, currentUser?.id, currentUser?.name]);

  // --------------------------------------------------------------------------
  // 3. AUDIENCE & HOST: Subscribe to live stream frames from relay
  // --------------------------------------------------------------------------
  useEffect(() => {
    const unsubscribe = liveStreamRelay.subscribeToRoom(roomId, (payload) => {
      if (payload) {
        setRemoteFrame(payload);
        if (payload.frameData) {
          setHasRemoteVideo(true);
        }
      }
    });

    return () => {
      unsubscribe();
    };
  }, [roomId]);

  // --------------------------------------------------------------------------
  // 4. 60FPS DYNAMIC LIVE STUDIO CANVAS
  // High-performance fallback animation with untainted vector graphics
  // --------------------------------------------------------------------------
  useEffect(() => {
    const canvas = studioCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let frame = 0;

    const render = () => {
      frame++;
      const w = (canvas.width = canvas.clientWidth || 720);
      const h = (canvas.height = canvas.clientHeight || 1280);

      // Dynamic Animated Background
      const time = frame * 0.02;
      const grad = ctx.createLinearGradient(0, 0, 0, h);

      if (isMusicTheme) {
        const hue = (frame * 0.4) % 360;
        grad.addColorStop(0, `hsl(${hue}, 80%, 14%)`);
        grad.addColorStop(0.45, `hsl(${(hue + 60) % 360}, 75%, 9%)`);
        grad.addColorStop(1, '#05030b');
      } else if (isGamingTheme) {
        grad.addColorStop(0, '#041726');
        grad.addColorStop(0.5, '#020d18');
        grad.addColorStop(1, '#020509');
      } else {
        grad.addColorStop(0, '#15092a');
        grad.addColorStop(0.4, '#0d091e');
        grad.addColorStop(1, '#040209');
      }

      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Spotlight Cones
      const spotX = w / 2 + Math.sin(time * 0.8) * 80;
      const spotY = h * 0.38 + Math.cos(time * 0.6) * 20;
      const spotRadius = Math.min(340, w * 0.7);
      const spotGrad = ctx.createRadialGradient(spotX, spotY, 20, w / 2, h * 0.4, spotRadius);

      if (isMusicTheme) {
        spotGrad.addColorStop(0, 'rgba(236, 72, 153, 0.4)');
        spotGrad.addColorStop(0.5, 'rgba(139, 92, 246, 0.2)');
        spotGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else if (isGamingTheme) {
        spotGrad.addColorStop(0, 'rgba(6, 182, 212, 0.4)');
        spotGrad.addColorStop(0.5, 'rgba(59, 130, 246, 0.2)');
        spotGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else {
        spotGrad.addColorStop(0, 'rgba(245, 158, 11, 0.35)');
        spotGrad.addColorStop(0.5, 'rgba(236, 72, 153, 0.18)');
        spotGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      }

      ctx.fillStyle = spotGrad;
      ctx.beginPath();
      ctx.arc(w / 2, h * 0.4, spotRadius, 0, Math.PI * 2);
      ctx.fill();

      // Cyber Stage Grid Lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1.5;
      const horizon = h * 0.72;
      for (let i = -6; i <= 6; i++) {
        ctx.beginPath();
        ctx.moveTo(w / 2, horizon);
        ctx.lineTo(w / 2 + i * (w * 0.16), h);
        ctx.stroke();
      }
      for (let y = horizon; y <= h; y += (h - horizon) / 5) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Audio Reactive Sound Spectrum Bars
      const numBars = 32;
      const barW = Math.max(3, w / (numBars * 2.2));
      const startX = (w - numBars * (barW + 4)) / 2;
      for (let i = 0; i < numBars; i++) {
        const barH = 15 + Math.abs(Math.sin(time * 3 + i * 0.35)) * (35 + audioLevel * 0.75);
        const barGrad = ctx.createLinearGradient(0, horizon - barH, 0, horizon);
        barGrad.addColorStop(0, '#f43f5e');
        barGrad.addColorStop(0.5, '#fbbf24');
        barGrad.addColorStop(1, '#06b6d4');
        ctx.fillStyle = barGrad;
        ctx.fillRect(startX + i * (barW + 4), horizon - barH, barW, barH);
      }

      // Center Broadcaster Neon Graphic Ring
      const avatarSize = Math.min(200, w * 0.42);
      const centerX = w / 2;
      const centerY = h * 0.38 + Math.sin(time) * 5;

      // Outer animated pulsing halo
      ctx.beginPath();
      ctx.arc(centerX, centerY, avatarSize / 2 + 14 + Math.sin(time * 3) * 6, 0, Math.PI * 2);
      ctx.strokeStyle = isMusicTheme
        ? 'rgba(236, 72, 153, 0.85)'
        : isGamingTheme
        ? 'rgba(6, 182, 212, 0.85)'
        : 'rgba(245, 158, 11, 0.85)';
      ctx.lineWidth = 4;
      ctx.stroke();

      // Clean vector circle with gradient and initials
      const circleGrad = ctx.createLinearGradient(
        centerX - avatarSize / 2,
        centerY - avatarSize / 2,
        centerX + avatarSize / 2,
        centerY + avatarSize / 2
      );
      circleGrad.addColorStop(0, '#ec4899');
      circleGrad.addColorStop(0.5, '#8b5cf6');
      circleGrad.addColorStop(1, '#3b82f6');
      ctx.fillStyle = circleGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, avatarSize / 2, 0, Math.PI * 2);
      ctx.fill();

      // Host Name Initial in Center
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(avatarSize * 0.4)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const initial = (hostName || 'L').charAt(0).toUpperCase();
      ctx.fillText(initial, centerX, centerY);

      // Floating Ambient Stars / Particles
      ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
      for (let p = 0; p < 16; p++) {
        const px = (Math.sin(time * 0.4 + p * 1.3) * 0.45 + 0.5) * w;
        const py = (time * 28 + p * 80) % h;
        const pSize = (p % 3) + 1.5;
        ctx.beginPath();
        ctx.arc(px, py, pSize, 0, Math.PI * 2);
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [hostName, isMusicTheme, isGamingTheme, audioLevel]);

  // Filter Class Helper
  const getFilterClass = (filter: string) => {
    switch (filter) {
      case 'beauty':
        return 'brightness-110 contrast-105 saturate-110';
      case 'warm':
        return 'sepia-[0.25] saturate-125 brightness-105';
      case 'cyber':
        return 'hue-rotate-30 saturate-150';
      case 'glow':
        return 'brightness-120 drop-shadow-[0_0_15px_rgba(236,72,153,0.3)]';
      default:
        return '';
    }
  };

  const hasCoHostRemote = Boolean(remoteFrame?.coHostFrameData && remoteFrame?.isCoHostCameraOn);

  return (
    <div className="relative w-full h-full overflow-hidden bg-black select-none">
      {/* ----------------------------------------------------------------- */}
      {/* 1. PK BATTLE MODE: Split Screen Dual Feeds                        */}
      {/* ----------------------------------------------------------------- */}
      {isPkBattleActive ? (
        <div className="relative w-full h-full flex">
          {/* Left Feed: Host Stream */}
          <div className="relative w-1/2 h-full overflow-hidden bg-neutral-900 border-r border-rose-500/40">
            {isHost && localStream && isCameraOn ? (
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover scale-x-[-1] ${getFilterClass(activeFilter)}`}
              />
            ) : hasRemoteVideo && remoteFrame?.frameData ? (
              <img
                src={remoteFrame.frameData}
                alt="Host Live Stream"
                className={`w-full h-full object-cover ${getFilterClass(remoteFrame?.filter || activeFilter)}`}
              />
            ) : (
              <canvas ref={studioCanvasRef} className="w-full h-full object-cover" />
            )}
            <div className="absolute bottom-20 left-2 z-10 px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-[10px] font-black text-cyan-300">
              👑 {hostName}
            </div>
          </div>

          {/* Right Feed: Opponent Stream */}
          <div className="relative w-1/2 h-full overflow-hidden bg-neutral-950">
            <div className="absolute inset-0 bg-gradient-to-b from-rose-950/40 via-purple-950/30 to-black/90 flex flex-col items-center justify-center">
              <img
                src={opponentInfo?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400'}
                alt=""
                className="w-24 h-24 rounded-full object-cover border-4 border-rose-500 shadow-xl animate-pulse"
              />
              <span className="mt-2 text-xs font-black text-white">{opponentInfo?.name || 'Challenger'}</span>
              <span className="text-[9px] font-bold text-rose-300">⚔️ PK DEFENDER</span>
            </div>
            <div className="absolute bottom-20 right-2 z-10 px-2 py-0.5 rounded-full bg-rose-950/80 border border-rose-400/40 text-[10px] font-black text-rose-300">
              ⚔️ {opponentInfo?.name || 'Challenger'}
            </div>
          </div>
        </div>
      ) : (
        <div className="relative w-full h-full">
          {/* 2. STANDARD FULL SCREEN LIVE VIDEO FEED */}
          {/* Host Local Camera Stream */}
          {isHost && localStream && isCameraOn && !isVoiceOnly && (
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover scale-x-[-1] transition-all duration-300 ${getFilterClass(activeFilter)}`}
            />
          )}

          {/* Viewer: Broadcaster's Live Stream via Relay */}
          {!isHost && hasRemoteVideo && remoteFrame?.frameData && !isVoiceOnly && (
            <img
              src={remoteFrame.frameData}
              alt="Live Video Broadcaster"
              className={`w-full h-full object-cover transition-all duration-200 ${getFilterClass(remoteFrame?.filter || activeFilter)}`}
            />
          )}

          {/* Ultra-HD Dynamic Live Studio Feed (Fallback when camera is off or frame pending) */}
          {(isVoiceOnly || (!isHost && (!hasRemoteVideo || !remoteFrame?.frameData)) || (isHost && (!localStream || !isCameraOn))) && (
            <canvas ref={studioCanvasRef} className="w-full h-full object-cover" />
          )}

          {/* Co-Host Dual Video Picture-in-Picture */}
          {/* A: Viewer is actively broadcasting as Co-Host */}
          {!isHost && isCoHostActive && coHostStream && (
            <div className="absolute top-28 right-3 z-30 w-28 h-40 sm:w-32 sm:h-48 rounded-2xl overflow-hidden border-2 border-cyan-400 shadow-2xl bg-neutral-900 animate-in slide-in-from-right">
              <video
                ref={coHostVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover scale-x-[-1]"
              />
              <div className="absolute bottom-1 left-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur-sm text-[9px] font-bold text-cyan-300 flex items-center justify-between">
                <span>You (Co-Host)</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              </div>
            </div>
          )}

          {/* B: Host or Viewer receives Remote Co-Host feed */}
          {(!isCoHostActive || isHost) && hasCoHostRemote && (
            <div className="absolute top-28 right-3 z-30 w-28 h-40 sm:w-32 sm:h-48 rounded-2xl overflow-hidden border-2 border-emerald-400 shadow-2xl bg-neutral-900 animate-in slide-in-from-right">
              <img
                src={remoteFrame!.coHostFrameData}
                alt="Co-Host Stream"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-1 left-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur-sm text-[9px] font-bold text-emerald-300 flex items-center justify-between">
                <span className="truncate max-w-[70px]">{remoteFrame?.coHostName || 'Co-Host'}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              </div>
            </div>
          )}
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 3. LIVE STREAM STATUS BADGE (TOP-LEFT)                              */}
      {/* ------------------------------------------------------------------- */}
      <div className="absolute top-20 left-3 z-20 flex items-center gap-1.5 pointer-events-none">
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-bold text-white shadow-lg">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
          <span className="font-black tracking-wider uppercase text-rose-300">
            {isHost ? 'BROADCASTING' : 'LIVE'}
          </span>
          <span className="text-neutral-400">•</span>
          <span className="text-cyan-300 font-mono">
            {hasRemoteVideo || (isHost && localStream && isCameraOn) ? 'HD 1080p' : '4K STUDIO'}
          </span>
          {(isCoHostActive || hasCoHostRemote) && (
            <>
              <span className="text-neutral-400">•</span>
              <span className="text-emerald-300 font-bold">DUAL LIVE</span>
            </>
          )}
        </div>
      </div>

      {/* ------------------------------------------------------------------- */}
      {/* 4. AUDIENCE CO-HOST BUTTON (JOIN VIDEO)                             */}
      {/* ------------------------------------------------------------------- */}
      {!isHost && onToggleCoHost && (
        <div className="absolute bottom-24 right-3 z-30 pointer-events-auto">
          <button
            onClick={onToggleCoHost}
            className={`px-3 py-1.5 rounded-full border shadow-xl backdrop-blur-xl text-xs font-black flex items-center gap-1.5 transition-all active:scale-95 ${
              isCoHostActive
                ? 'bg-rose-600 border-rose-400 text-white shadow-rose-950/60'
                : 'bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 border-pink-400/40 text-white shadow-pink-950/60 hover:brightness-110'
            }`}
          >
            {isCoHostActive ? <VideoOff className="w-3.5 h-3.5" /> : <Video className="w-3.5 h-3.5" />}
            <span>{isCoHostActive ? 'Leave Video' : 'Join Video'}</span>
          </button>
        </div>
      )}
    </div>
  );
};
