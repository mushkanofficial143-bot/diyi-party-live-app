import React, { useState } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  XCircle, 
  Search, 
  Clock, 
  ShieldCheck, 
  AlertTriangle,
  UserCheck,
  Award
} from 'lucide-react';
import { AgencyJoinRequest } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';
import { createAuditLog } from '../../utils/rbacGuard';

interface AgencyJoinRequestsSectionProps {
  requests: AgencyJoinRequest[];
  onUpdateRequests: (reqs: AgencyJoinRequest[]) => void;
  onAddAuditLog: (log: any) => void;
  onAddNotification: (notif: any) => void;
}

export const AgencyJoinRequestsSection: React.FC<AgencyJoinRequestsSectionProps> = ({
  requests,
  onUpdateRequests,
  onAddAuditLog,
  onAddNotification
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filtered = requests.filter((req) => {
    const matchesStatus = statusFilter === 'ALL' || req.status === statusFilter;
    const q = search.toLowerCase();
    const matchesSearch =
      !q ||
      req.hostName.toLowerCase().includes(q) ||
      req.hostId.toLowerCase().includes(q) ||
      req.agencyName.toLowerCase().includes(q) ||
      req.agencyId.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  const handleApprove = (req: AgencyJoinRequest) => {
    playSoundFX('superchat');
    confetti({ particleCount: 50, spread: 70 });

    const updated = requests.map(r => r.id === req.id ? {
      ...r,
      status: 'APPROVED' as const,
      approvalDate: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC'
    } : r);

    onUpdateRequests(updated);

    // Call backend
    fetch('/api/agency/approve-request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        requestId: req.id,
        hostId: req.hostId
      })
    }).catch(() => {});

    // Audit log
    onAddAuditLog(createAuditLog(
      'OWN-001',
      'Agency Owner / Admin',
      'AGENCY',
      'APPROVE_AGENCY_JOIN',
      req.id,
      'AGENCY',
      'SUCCESS',
      `Approved host ${req.hostName} (${req.hostId}) joining agency ${req.agencyName} (${req.agencyId})`
    ));

    // Notification to Host
    onAddNotification({
      id: `NTF-${Math.floor(1000 + Math.random() * 9000)}`,
      title: '🏢 Agency Joining Approved!',
      message: `Your application to join ${req.agencyName} (${req.agencyId}) has been approved by the agency owner. You are now officially verified and joined!`,
      targetAudience: req.hostId,
      timestamp: 'Just now',
      readCount: 0,
      sentBy: 'Agency Guild Administration'
    });
  };

  const handleReject = (req: AgencyJoinRequest) => {
    playSoundFX('notification');

    const updated = requests.map(r => r.id === req.id ? {
      ...r,
      status: 'REJECTED' as const,
      rejectionReason: 'Declined by Agency Owner review'
    } : r);

    onUpdateRequests(updated);

    // Audit log
    onAddAuditLog(createAuditLog(
      'OWN-001',
      'Agency Owner / Admin',
      'AGENCY',
      'REJECT_AGENCY_JOIN',
      req.id,
      'AGENCY',
      'SUCCESS',
      `Rejected host ${req.hostName} (${req.hostId}) joining agency ${req.agencyName} (${req.agencyId})`
    ));

    // Notification to Host
    onAddNotification({
      id: `NTF-${Math.floor(1000 + Math.random() * 9000)}`,
      title: '❌ Agency Joining Rejected',
      message: `Your application to join ${req.agencyName} (${req.agencyId}) was rejected by the agency owner. You may apply to another agency or resubmit.`,
      targetAudience: req.hostId,
      timestamp: 'Just now',
      readCount: 0,
      sentBy: 'Agency Guild Administration'
    });
  };

  return (
    <div className="space-y-4 animate-in fade-in pb-10">
      
      {/* Header Info */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-[#0c142c] via-[#111c3c] to-[#0c142c] border border-teal-500/30 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-500/40 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-['Outfit'] font-black text-lg text-white">Host Joining Requests & Management</h2>
              <p className="text-xs text-neutral-400">Review host applications, verify credentials, and approve or reject guild assignments.</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold font-mono">
            Pending: {requests.filter(r => r.status === 'PENDING').length}
          </span>
          <span className="px-3 py-1 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-bold font-mono">
            Total: {requests.length}
          </span>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Host name, ID, or Agency..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-9 pr-3 py-2 text-white placeholder-neutral-500 focus:outline-none focus:border-teal-400"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto">
          {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map((st) => (
            <button
              key={st}
              onClick={() => {
                setStatusFilter(st);
                playSoundFX('click');
              }}
              className={`px-3.5 py-1.5 rounded-xl font-bold transition-all ${
                statusFilter === st
                  ? 'bg-teal-500 text-neutral-950 shadow-md font-black'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Requests Table / Cards */}
      <div className="bg-neutral-900/90 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-4">Host Details</th>
                <th className="p-4">Target Agency</th>
                <th className="p-4">Request Date / Time</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Owner Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-neutral-500">
                    No joining requests found matching your filter.
                  </td>
                </tr>
              ) : (
                filtered.map((req) => (
                  <tr key={req.id} className="hover:bg-neutral-850/50 transition-colors">
                    
                    {/* Host Details */}
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={req.hostAvatar}
                          alt={req.hostName}
                          className="w-10 h-10 rounded-2xl object-cover border border-teal-500/40 flex-shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{req.hostName}</span>
                            <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px] font-mono font-bold">
                              Lv.{req.hostLevel}
                            </span>
                            {req.hostVipLevel && req.hostVipLevel > 0 && (
                              <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold">
                                VIP {req.hostVipLevel}
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-neutral-400 font-mono">ID: {req.hostId}</span>
                        </div>
                      </div>
                    </td>

                    {/* Target Agency */}
                    <td className="p-4">
                      <div className="space-y-0.5">
                        <span className="font-bold text-teal-300 block">{req.agencyName}</span>
                        <span className="text-[11px] text-neutral-400 font-mono">Agency ID: {req.agencyId}</span>
                      </div>
                    </td>

                    {/* Date / Time */}
                    <td className="p-4">
                      <div className="flex items-center gap-1.5 text-neutral-300 font-mono">
                        <Clock className="w-3.5 h-3.5 text-neutral-500" />
                        <span>{req.requestDate}</span>
                      </div>
                      {req.approvalDate && (
                        <span className="text-[10px] text-emerald-400 block font-mono mt-0.5">
                          Approved: {req.approvalDate}
                        </span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="p-4">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black tracking-wider uppercase border ${
                        req.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' :
                        req.status === 'REJECTED' ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' :
                        'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      }`}>
                        {req.status}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="p-4 text-right">
                      {req.status === 'PENDING' ? (
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleApprove(req)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => handleReject(req)}
                            className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 font-bold text-xs transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] text-neutral-500 italic font-medium">
                          Processed
                        </span>
                      )}
                    </td>

                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
