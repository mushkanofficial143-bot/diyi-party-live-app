import React, { useState } from 'react';
import { 
  Sparkles, 
  Plus, 
  Search, 
  Crown, 
  CheckCircle2, 
  Trash2, 
  Layers, 
  Edit, 
  UserCheck, 
  UserPlus, 
  ShieldAlert, 
  Upload, 
  Clock, 
  Eye, 
  X, 
  Coins, 
  Award, 
  Check, 
  AlertTriangle,
  RotateCcw,
  Sliders,
  UserX
} from 'lucide-react';
import { AvatarFrameItem, UserAccount, UserRole } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface FramesSectionProps {
  frames: AvatarFrameItem[];
  users?: UserAccount[];
  currentRole?: UserRole;
  onUpdateFrames?: (frames: AvatarFrameItem[]) => void;
  onAssignFrameToUser?: (userId: string, frame: AvatarFrameItem, duration?: string) => void;
  onRevokeFrameFromUser?: (userId: string) => void;
}

const PRESET_FRAME_ASSETS = [
  { name: '👑 Imperial Gold Crown', url: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150', rarity: 'Royalty' as const, type: 'VIP' as const },
  { name: '🔥 Blazing Dragon Fire', url: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150', rarity: 'Legendary' as const, type: 'Special' as const },
  { name: '💎 Cyberpunk Neon Glow', url: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150', rarity: 'Epic' as const, type: 'Avatar' as const },
  { name: '🌸 Cherry Blossom Petals', url: 'https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?w=150', rarity: 'Rare' as const, type: 'Profile' as const },
  { name: '⭐ Classic Star Aura', url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150', rarity: 'Common' as const, type: 'Profile' as const },
  { name: '⚡ Thunder Storm Ring', url: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=150', rarity: 'Epic' as const, type: 'Special' as const },
  { name: '🦁 Golden Lion Monarch', url: 'https://images.unsplash.com/photo-1534188753412-3e26d0d618d6?w=150', rarity: 'Royalty' as const, type: 'VIP' as const }
];

export const FramesSection: React.FC<FramesSectionProps> = ({
  frames = [],
  users = [],
  currentRole = 'OWNER',
  onUpdateFrames,
  onAssignFrameToUser,
  onRevokeFrameFromUser
}) => {
  const [frameList, setFrameList] = useState<AvatarFrameItem[]>(() => {
    if (frames && frames.length > 0) return frames;
    return PRESET_FRAME_ASSETS.map((p, idx) => ({
      id: `FRM-00${idx + 1}`,
      name: p.name,
      rarity: p.rarity,
      type: p.type,
      previewUrl: p.url,
      coinPrice: (idx + 1) * 5000,
      vipLevelRequired: Math.min(idx + 1, 8),
      activeUsersCount: Math.floor(Math.random() * 500) + 20,
      isAnimated: true,
      status: 'Active',
      createdDate: '2026-01-15'
    }));
  });

  const [activeTab, setActiveTab] = useState<'catalog' | 'assignments'>('catalog');
  const [search, setSearch] = useState('');
  const [rarityFilter, setRarityFilter] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingFrame, setEditingFrame] = useState<AvatarFrameItem | null>(null);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [assignSelectedFrame, setAssignSelectedFrame] = useState<AvatarFrameItem | null>(null);
  const [assignSearchUser, setAssignSearchUser] = useState('');
  const [assignDuration, setAssignDuration] = useState('Permanent');
  const [deleteConfirmFrame, setDeleteConfirmFrame] = useState<AvatarFrameItem | null>(null);
  const [previewFrame, setPreviewFrame] = useState<AvatarFrameItem | null>(null);

  // Form state for Create / Edit Frame
  const [formName, setFormName] = useState('');
  const [formUrl, setFormUrl] = useState('');
  const [formType, setFormType] = useState<'Profile' | 'Avatar' | 'VIP' | 'Special'>('Avatar');
  const [formRarity, setFormRarity] = useState<'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Royalty'>('Epic');
  const [formVipRequired, setFormVipRequired] = useState(0);
  const [formCoinPrice, setFormCoinPrice] = useState(0);
  const [formStartDate, setFormStartDate] = useState('');
  const [formEndDate, setFormEndDate] = useState('');
  const [formStatus, setFormStatus] = useState<'Active' | 'Inactive'>('Active');
  const [formIsAnimated, setFormIsAnimated] = useState(true);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Open Create Frame Modal
  const handleOpenCreateModal = () => {
    playSoundFX('click');
    setEditingFrame(null);
    setFormName('');
    setFormUrl(PRESET_FRAME_ASSETS[0].url);
    setFormType('Avatar');
    setFormRarity('Epic');
    setFormVipRequired(1);
    setFormCoinPrice(10000);
    setFormStartDate(new Date().toISOString().split('T')[0]);
    setFormEndDate('');
    setFormStatus('Active');
    setFormIsAnimated(true);
    setIsAddModalOpen(true);
  };

  // Open Edit Frame Modal
  const handleOpenEditModal = (frame: AvatarFrameItem) => {
    playSoundFX('click');
    setEditingFrame(frame);
    setFormName(frame.name);
    setFormUrl(frame.previewUrl);
    setFormType(frame.type || 'Avatar');
    setFormRarity(frame.rarity);
    setFormVipRequired(frame.vipLevelRequired || 0);
    setFormCoinPrice(frame.coinPrice || 0);
    setFormStartDate(frame.startDate || '2026-01-01');
    setFormEndDate(frame.endDate || '');
    setFormStatus(frame.status || 'Active');
    setFormIsAnimated(frame.isAnimated ?? true);
    setIsAddModalOpen(true);
  };

  // Handle Save Frame (Create or Edit)
  const handleSaveFrame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      showToast('⚠️ Please enter a frame name.');
      return;
    }

    if (editingFrame) {
      // Update existing frame
      const updatedList = frameList.map(f => {
        if (f.id === editingFrame.id) {
          return {
            ...f,
            name: formName.trim(),
            previewUrl: formUrl || f.previewUrl,
            type: formType,
            rarity: formRarity,
            vipLevelRequired: Number(formVipRequired),
            coinPrice: Number(formCoinPrice),
            startDate: formStartDate,
            endDate: formEndDate,
            status: formStatus,
            isAnimated: formIsAnimated
          };
        }
        return f;
      });
      setFrameList(updatedList);
      if (onUpdateFrames) onUpdateFrames(updatedList);
      showToast(`✨ Frame "${formName}" updated successfully!`);
      playSoundFX('win');
    } else {
      // Create new frame
      const generatedId = `FRM-${Math.floor(100000 + Math.random() * 900000)}`;
      const newFrame: AvatarFrameItem = {
        id: generatedId,
        name: formName.trim(),
        previewUrl: formUrl || PRESET_FRAME_ASSETS[0].url,
        type: formType,
        rarity: formRarity,
        vipLevelRequired: Number(formVipRequired),
        coinPrice: Number(formCoinPrice),
        activeUsersCount: 0,
        isAnimated: formIsAnimated,
        status: formStatus,
        startDate: formStartDate,
        endDate: formEndDate,
        createdDate: new Date().toISOString().split('T')[0]
      };
      const updatedList = [newFrame, ...frameList];
      setFrameList(updatedList);
      if (onUpdateFrames) onUpdateFrames(updatedList);
      showToast(`🎉 New Frame "${newFrame.name}" (${newFrame.id}) created permanently!`);
      playSoundFX('win');
    }

    setIsAddModalOpen(false);
  };

  // Toggle Frame Status
  const handleToggleStatus = (frameId: string) => {
    playSoundFX('click');
    const updatedList = frameList.map(f => {
      if (f.id === frameId) {
        const nextStatus: 'Active' | 'Inactive' = f.status === 'Inactive' ? 'Active' : 'Inactive';
        showToast(`Frame ${f.name} is now ${nextStatus}.`);
        return { ...f, status: nextStatus };
      }
      return f;
    });
    setFrameList(updatedList);
    if (onUpdateFrames) onUpdateFrames(updatedList);
  };

  // Safe Delete Frame
  const handleConfirmDelete = () => {
    if (!deleteConfirmFrame) return;
    playSoundFX('click');
    const updatedList = frameList.filter(f => f.id !== deleteConfirmFrame.id);
    setFrameList(updatedList);
    if (onUpdateFrames) onUpdateFrames(updatedList);
    showToast(`🗑️ Frame "${deleteConfirmFrame.name}" permanently deleted.`);
    setDeleteConfirmFrame(null);
  };

  // Open Assign Modal ("Frame dene ka option")
  const handleOpenAssignModal = (frame?: AvatarFrameItem) => {
    playSoundFX('click');
    setAssignSelectedFrame(frame || (frameList.length > 0 ? frameList[0] : null));
    setAssignSearchUser('');
    setAssignDuration('Permanent');
    setIsAssignModalOpen(true);
  };

  // Handle Assign Frame to Target User
  const handleAssignToUser = (targetUser: UserAccount) => {
    if (!assignSelectedFrame) {
      showToast('⚠️ Please select a frame first.');
      return;
    }

    playSoundFX('win');
    if (onAssignFrameToUser) {
      onAssignFrameToUser(targetUser.id, assignSelectedFrame, assignDuration);
    }

    // Increment activeUsersCount for this frame
    const updatedList = frameList.map(f => {
      if (f.id === assignSelectedFrame.id) {
        return { ...f, activeUsersCount: (f.activeUsersCount || 0) + 1 };
      }
      return f;
    });
    setFrameList(updatedList);
    if (onUpdateFrames) onUpdateFrames(updatedList);

    showToast(`✨ Frame "${assignSelectedFrame.name}" equipped on user ${targetUser.name} (ID: #${targetUser.id})!`);
    setIsAssignModalOpen(false);
  };

  // Handle Revoke Frame from User
  const handleRevokeFromUser = (targetUserId: string, userName: string) => {
    playSoundFX('click');
    if (onRevokeFrameFromUser) {
      onRevokeFrameFromUser(targetUserId);
    }
    showToast(`🔄 Frame revoked from user ${userName}.`);
  };

  // File Upload handler for custom frames
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormUrl(reader.result as string);
        showToast('Frame image uploaded successfully!');
      };
      reader.readAsDataURL(file);
    }
  };

  // Filtered frames
  const filteredFrames = frameList.filter(f => {
    const matchSearch = !search || 
      f.name.toLowerCase().includes(search.toLowerCase()) || 
      f.id.toLowerCase().includes(search.toLowerCase());
    const matchRarity = rarityFilter === 'ALL' || f.rarity.toLowerCase() === rarityFilter.toLowerCase();
    const matchType = typeFilter === 'ALL' || (f.type || 'Avatar').toLowerCase() === typeFilter.toLowerCase();
    const matchStatus = statusFilter === 'ALL' || (f.status || 'Active').toLowerCase() === statusFilter.toLowerCase();
    return matchSearch && matchRarity && matchType && matchStatus;
  });

  // Users currently holding a frame
  const usersWithFrames = users.filter(u => u.avatarFrameId || u.avatarFrameUrl);

  // Users filtered for assign search
  const assignableUsers = users.filter(u => {
    if (!assignSearchUser.trim()) return true;
    const q = assignSearchUser.toLowerCase();
    return (
      (u.name || '').toLowerCase().includes(q) ||
      (u.id || '').toLowerCase().includes(q) ||
      (u.username || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 px-5 py-3 rounded-2xl bg-neutral-900 border border-amber-500/50 text-white font-bold text-xs shadow-2xl flex items-center gap-3 animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header & Action Row */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-5 rounded-3xl bg-[#0f1422] border border-white/10 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center shadow-lg shadow-amber-500/20 text-neutral-950 font-black">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-wide font-['Outfit'] flex items-center gap-2">
                <span>FRAME MANAGEMENT</span>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] font-mono font-bold">
                  👑 OWNER ONLY
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Create, customize, activate, delete, and directly grant avatar frames to any platform user.
              </p>
            </div>
          </div>
        </div>

        {/* Master Actions */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => handleOpenAssignModal()}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-900/40 transition-all active:scale-95"
          >
            <UserCheck className="w-4 h-4 text-cyan-200 stroke-[2.5]" />
            <span>⚡ Give Frame to User</span>
          </button>

          <button
            onClick={handleOpenCreateModal}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/30 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>+ Add New Frame</span>
          </button>
        </div>
      </div>

      {/* Tabs Switcher: Catalog vs User Assignments */}
      <div className="flex items-center justify-between p-1.5 rounded-2xl bg-neutral-900 border border-neutral-800">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeTab === 'catalog'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Frame Catalog ({frameList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('assignments')}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeTab === 'assignments'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>User Frame Grants ({usersWithFrames.length})</span>
          </button>
        </div>

        <div className="text-xs text-neutral-400 hidden sm:flex items-center gap-2 pr-3">
          <Crown className="w-3.5 h-3.5 text-amber-400" />
          <span>Authorized: Master Platform Owner (ID: #0000001)</span>
        </div>
      </div>

      {/* TAB 1: FRAME CATALOG & MANAGEMENT */}
      {activeTab === 'catalog' && (
        <div className="space-y-4">
          {/* Search and Filters Bar */}
          <div className="p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search frame by name or ID (e.g., FRM-001, Imperial)..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full h-10 bg-neutral-950 border border-neutral-800 rounded-xl pl-10 pr-4 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-all"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap text-xs">
              {/* Type Filter */}
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="h-10 px-3 bg-neutral-950 border border-neutral-800 rounded-xl text-neutral-300 focus:outline-none focus:border-amber-500 text-xs"
              >
                <option value="ALL">All Types</option>
                <option value="Profile">Profile</option>
                <option value="Avatar">Avatar</option>
                <option value="VIP">VIP</option>
                <option value="Special">Special</option>
              </select>

              {/* Rarity Filter */}
              <select
                value={rarityFilter}
                onChange={(e) => setRarityFilter(e.target.value)}
                className="h-10 px-3 bg-neutral-950 border border-neutral-800 rounded-xl text-neutral-300 focus:outline-none focus:border-amber-500 text-xs"
              >
                <option value="ALL">All Rarities</option>
                <option value="Royalty">Royalty</option>
                <option value="Legendary">Legendary</option>
                <option value="Epic">Epic</option>
                <option value="Rare">Rare</option>
                <option value="Common">Common</option>
              </select>

              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="h-10 px-3 bg-neutral-950 border border-neutral-800 rounded-xl text-neutral-300 focus:outline-none focus:border-amber-500 text-xs"
              >
                <option value="ALL">All Status</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          {/* Frame Grid */}
          {filteredFrames.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-neutral-900 border border-neutral-800">
              <Sparkles className="w-10 h-10 text-neutral-600 mx-auto mb-3" />
              <p className="text-white font-bold text-sm">No frames found matching your criteria</p>
              <p className="text-neutral-400 text-xs mt-1">Try changing filters or add a new frame using "+ Add New Frame".</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredFrames.map(frame => {
                const isActive = frame.status !== 'Inactive';
                const rarityColor = 
                  frame.rarity === 'Royalty' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                  frame.rarity === 'Legendary' ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' :
                  frame.rarity === 'Epic' ? 'bg-purple-500/20 text-purple-300 border-purple-500/40' :
                  frame.rarity === 'Rare' ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' :
                  'bg-neutral-700/30 text-neutral-300 border-neutral-600/40';

                return (
                  <div 
                    key={frame.id}
                    className={`p-4 rounded-3xl bg-[#121624] border transition-all flex flex-col justify-between space-y-4 hover:shadow-xl ${
                      isActive ? 'border-white/10 hover:border-amber-500/40' : 'border-red-500/20 opacity-75'
                    }`}
                  >
                    {/* Header Row */}
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${rarityColor}`}>
                        {frame.rarity}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono text-neutral-400">{frame.id}</span>
                        <button
                          onClick={() => handleToggleStatus(frame.id)}
                          title={`Toggle status (currently ${frame.status || 'Active'})`}
                          className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border transition-all ${
                            isActive 
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30' 
                              : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:bg-neutral-700'
                          }`}
                        >
                          {frame.status || 'Active'}
                        </button>
                      </div>
                    </div>

                    {/* Frame Preview Visual */}
                    <div className="flex flex-col items-center justify-center py-2">
                      <div className="relative w-24 h-24 flex items-center justify-center">
                        {/* The Animated Frame Effect Ring */}
                        <div 
                          className={`absolute inset-0 rounded-full border-4 ${
                            frame.rarity === 'Royalty' ? 'border-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.5)] animate-pulse' :
                            frame.rarity === 'Legendary' ? 'border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.5)]' :
                            frame.rarity === 'Epic' ? 'border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.4)]' :
                            frame.rarity === 'Rare' ? 'border-cyan-400' : 'border-neutral-500'
                          }`} 
                        />
                        {/* User Avatar Inside Frame */}
                        <img
                          src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                          alt="Avatar"
                          className="w-20 h-20 rounded-full object-cover z-0"
                        />
                        {/* Frame Overlay Image if available */}
                        {frame.previewUrl && (
                          <img
                            src={frame.previewUrl}
                            alt={frame.name}
                            className="absolute inset-0 w-full h-full rounded-full object-cover pointer-events-none opacity-40 mix-blend-screen"
                          />
                        )}
                        {/* VIP Requirement Badge */}
                        <div className="absolute -bottom-1.5 px-2 py-0.5 rounded-md bg-neutral-900 border border-amber-500/40 text-amber-300 text-[9px] font-black shadow flex items-center gap-1 z-10">
                          <span>VIP {frame.vipLevelRequired || 0}</span>
                        </div>
                      </div>

                      <h4 className="font-black text-white text-sm mt-3 text-center line-clamp-1">{frame.name}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] text-neutral-400 font-medium">Type: <b className="text-white">{frame.type || 'Avatar'}</b></span>
                        <span className="text-neutral-600">•</span>
                        <span className="text-[11px] font-mono text-amber-400 font-bold">
                          {frame.coinPrice > 0 ? `${frame.coinPrice.toLocaleString()} 🪙` : 'Free / Exclusive'}
                        </span>
                      </div>
                    </div>

                    {/* Meta stats */}
                    <div className="p-2.5 rounded-xl bg-neutral-950/60 border border-white/5 flex items-center justify-between text-[11px] text-neutral-400">
                      <span>Equipped by:</span>
                      <span className="font-bold text-white flex items-center gap-1">
                        <UserCheck className="w-3 h-3 text-cyan-400" />
                        {((frame.activeUsersCount) ?? 0).toLocaleString()} users
                      </span>
                    </div>

                    {/* Action Buttons: Give to User, Edit, Preview, Delete */}
                    <div className="pt-2 border-t border-white/10 space-y-2">
                      <button
                        onClick={() => handleOpenAssignModal(frame)}
                        className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow transition-all active:scale-95"
                      >
                        <UserPlus className="w-3.5 h-3.5 stroke-[2.5]" />
                        <span>Give Frame to User</span>
                      </button>

                      <div className="grid grid-cols-3 gap-1.5">
                        <button
                          onClick={() => handleOpenEditModal(frame)}
                          className="py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-all"
                        >
                          <Edit className="w-3 h-3" />
                          <span>Edit</span>
                        </button>

                        <button
                          onClick={() => setPreviewFrame(frame)}
                          className="py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-all"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Preview</span>
                        </button>

                        <button
                          onClick={() => setDeleteConfirmFrame(frame)}
                          className="py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 text-[11px] font-bold flex items-center justify-center gap-1 transition-all"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: ACTIVE USER ASSIGNMENTS (Where Owner can see & revoke) */}
      {activeTab === 'assignments' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-cyan-400" />
                <span>Active User Frame Allocations</span>
              </h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                Overview of all platform users who currently possess a custom avatar or role frame.
              </p>
            </div>

            <button
              onClick={() => handleOpenAssignModal()}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>+ Assign Another User</span>
            </button>
          </div>

          {usersWithFrames.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
              <UserCheck className="w-10 h-10 text-neutral-600 mx-auto" />
              <p className="text-white font-bold text-sm">No custom user frame allocations yet</p>
              <p className="text-neutral-400 text-xs max-w-sm mx-auto">
                Use the "⚡ Give Frame to User" button to select any user by ID or name and assign them an exclusive frame!
              </p>
              <button
                onClick={() => handleOpenAssignModal()}
                className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 font-black text-xs uppercase tracking-wider inline-flex items-center gap-2 shadow-lg"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Assign Frame Now</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {usersWithFrames.map(user => {
                const assignedFrame = frameList.find(f => f.id === user.avatarFrameId);
                return (
                  <div key={user.id} className="p-4 rounded-3xl bg-[#121624] border border-white/10 space-y-3 flex flex-col justify-between">
                    <div className="flex items-center gap-3">
                      <div className="relative w-14 h-14 flex items-center justify-center">
                        <div className="absolute inset-0 rounded-full border-2 border-amber-400 animate-pulse" />
                        <img
                          src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                          alt={user.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      </div>
                      <div className="space-y-0.5 flex-1 min-w-0">
                        <h4 className="font-bold text-white text-xs truncate">{user.name}</h4>
                        <p className="text-[10px] text-neutral-400 font-mono">ID: #{user.id}</p>
                        <span className="inline-block text-[9px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">
                          Role: {user.role || 'USER'}
                        </span>
                      </div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-neutral-950 border border-white/5 space-y-1 text-xs">
                      <div className="flex justify-between text-[11px]">
                        <span className="text-neutral-400">Equipped Frame:</span>
                        <span className="font-bold text-amber-300 truncate max-w-[140px]">
                          {assignedFrame?.name || user.avatarFrameId || 'Custom Frame'}
                        </span>
                      </div>
                      <div className="flex justify-between text-[11px]">
                        <span className="text-neutral-400">VIP Level:</span>
                        <span className="font-mono text-cyan-300 font-bold">VIP {user.vipLevel || 0}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleRevokeFromUser(user.id, user.name)}
                      className="w-full py-2 px-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
                    >
                      <UserX className="w-3.5 h-3.5" />
                      <span>Revoke Frame</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: CREATE OR EDIT FRAME ("+ Add New Frame") */}
      {/* ========================================================================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xl bg-[#0c101d] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-5 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base uppercase tracking-wider font-['Outfit']">
                    {editingFrame ? `Edit Frame: ${editingFrame.name}` : '+ Create New Frame'}
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    {editingFrame ? 'Update frame parameters and pricing' : 'Configure new avatar frame permanently saved to catalog'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-8 h-8 rounded-full bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveFrame} className="space-y-4 text-xs">
              {/* Live Preview Box */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-center gap-4 text-center sm:text-left">
                <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
                  <div className={`absolute inset-0 rounded-full border-4 ${
                    formRarity === 'Royalty' ? 'border-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.5)] animate-pulse' :
                    formRarity === 'Legendary' ? 'border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.5)]' :
                    formRarity === 'Epic' ? 'border-purple-500' :
                    formRarity === 'Rare' ? 'border-cyan-400' : 'border-neutral-500'
                  }`} />
                  <img
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150"
                    alt="Preview Avatar"
                    className="w-20 h-20 rounded-full object-cover"
                  />
                  {formUrl && (
                    <img
                      src={formUrl}
                      alt="Overlay"
                      className="absolute inset-0 w-full h-full rounded-full object-cover pointer-events-none opacity-40 mix-blend-screen"
                    />
                  )}
                  <div className="absolute -bottom-1 px-2 py-0.5 rounded bg-neutral-900 border border-amber-400 text-amber-300 text-[9px] font-black z-10">
                    VIP {formVipRequired}
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-black text-amber-400 uppercase tracking-wider">Live Frame Preview</span>
                  <h4 className="text-sm font-black text-white">{formName || 'New Frame Title'}</h4>
                  <p className="text-[11px] text-neutral-400">
                    {formType} Frame • {formRarity} • {formCoinPrice > 0 ? `${Number(formCoinPrice).toLocaleString()} Coins` : 'Free / Exclusive'}
                  </p>
                  <p className="text-[10px] text-neutral-500">Status: <b className="text-emerald-400">{formStatus}</b></p>
                </div>
              </div>

              {/* Frame Name */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                  Frame Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., 👑 Imperial Monarch Aura, 🔥 Dragon Blaze"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl px-3.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Frame Type & Rarity */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                    Frame Type
                  </label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as any)}
                    className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl px-3 text-xs text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Avatar">Avatar</option>
                    <option value="Profile">Profile</option>
                    <option value="VIP">VIP</option>
                    <option value="Special">Special</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                    Rarity
                  </label>
                  <select
                    value={formRarity}
                    onChange={(e) => setFormRarity(e.target.value as any)}
                    className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl px-3 text-xs text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Common">Normal / Common</option>
                    <option value="Rare">Rare</option>
                    <option value="Epic">Epic</option>
                    <option value="Legendary">Legendary</option>
                    <option value="Royalty">Royalty</option>
                  </select>
                </div>
              </div>

              {/* Required VIP & Coin Price */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                    Required VIP Level (0 to 10)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    value={formVipRequired}
                    onChange={(e) => setFormVipRequired(Number(e.target.value))}
                    className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl px-3.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                    Price in Coins (0 for free)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="500"
                    value={formCoinPrice}
                    onChange={(e) => setFormCoinPrice(Number(e.target.value))}
                    className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl px-3.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              {/* Frame Image / Asset URL or File Upload */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                  Frame Image / Animation
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="https://... (image / animation URL)"
                    value={formUrl}
                    onChange={(e) => setFormUrl(e.target.value)}
                    className="flex-1 h-10 bg-neutral-950 border border-white/10 rounded-xl px-3.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                  <label className="h-10 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all shrink-0">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload</span>
                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                  </label>
                </div>

                {/* Preset Assets Selector */}
                <div className="space-y-1 pt-1">
                  <span className="text-[10px] text-neutral-400">Or pick from curated official presets:</span>
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    {PRESET_FRAME_ASSETS.map((p, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setFormUrl(p.url);
                          setFormName(p.name);
                          setFormRarity(p.rarity);
                          setFormType(p.type);
                        }}
                        className={`px-2.5 py-1 rounded-lg border text-[10px] font-bold whitespace-nowrap transition-all ${
                          formUrl === p.url 
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500' 
                            : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Validity Dates & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={formStartDate}
                    onChange={(e) => setFormStartDate(e.target.value)}
                    className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl px-3 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                    End Date (Optional)
                  </label>
                  <input
                    type="date"
                    value={formEndDate}
                    onChange={(e) => setFormEndDate(e.target.value)}
                    className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl px-3 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                    Status
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl px-3 text-xs text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              {/* Animated Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-950 border border-white/5">
                <span className="text-neutral-300 font-bold">Animated Ring & Particle FX</span>
                <button
                  type="button"
                  onClick={() => setFormIsAnimated(!formIsAnimated)}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    formIsAnimated ? 'bg-amber-500' : 'bg-neutral-800'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    formIsAnimated ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30 flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Save Frame Permanently</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: ASSIGN / GIVE FRAME TO USER ("Kahi frame dene ka option") */}
      {/* ========================================================================= */}
      {isAssignModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xl bg-[#0c101d] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-5 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base uppercase tracking-wider font-['Outfit']">
                    Give Frame to User
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    Grant, equip, or gift an exclusive avatar frame directly to any user
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAssignModalOpen(false)}
                className="w-8 h-8 rounded-full bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Selected Frame Picker */}
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-white/10 space-y-2">
              <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider block">
                1. Select Frame to Give
              </label>
              <select
                value={assignSelectedFrame?.id || ''}
                onChange={(e) => {
                  const picked = frameList.find(f => f.id === e.target.value);
                  if (picked) setAssignSelectedFrame(picked);
                }}
                className="w-full h-10 bg-neutral-900 border border-neutral-800 rounded-xl px-3 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                {frameList.map(f => (
                  <option key={f.id} value={f.id}>
                    {f.name} ({f.id}) — {f.rarity} [VIP {f.vipLevelRequired}]
                  </option>
                ))}
              </select>

              {assignSelectedFrame && (
                <div className="flex items-center gap-3 pt-1">
                  <div className="relative w-12 h-12 flex items-center justify-center shrink-0">
                    <div className="absolute inset-0 rounded-full border-2 border-amber-400 animate-pulse" />
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150"
                      alt="Sample"
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  </div>
                  <div>
                    <span className="font-bold text-white text-xs">{assignSelectedFrame.name}</span>
                    <p className="text-[10px] text-neutral-400 font-mono">ID: {assignSelectedFrame.id} • {assignSelectedFrame.rarity}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Duration Selector */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                2. Allocation Duration
              </label>
              <div className="grid grid-cols-4 gap-2">
                {['7 Days', '30 Days', '90 Days', 'Permanent'].map(dur => (
                  <button
                    key={dur}
                    type="button"
                    onClick={() => setAssignDuration(dur)}
                    className={`py-2 rounded-xl text-xs font-bold transition-all border ${
                      assignDuration === dur
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500 shadow'
                        : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-white'
                    }`}
                  >
                    {dur}
                  </button>
                ))}
              </div>
            </div>

            {/* Search User */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider block">
                3. Choose Target User (Search by 7-digit ID, name, or username)
              </label>
              <div className="relative">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Enter User ID (e.g. 0000001) or name..."
                  value={assignSearchUser}
                  onChange={(e) => setAssignSearchUser(e.target.value)}
                  className="w-full h-10 bg-neutral-950 border border-white/10 rounded-xl pl-10 pr-4 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* User List to Pick From */}
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {assignableUsers.length === 0 ? (
                <div className="p-4 text-center text-xs text-neutral-500">
                  No users found matching "{assignSearchUser}".
                </div>
              ) : (
                assignableUsers.slice(0, 10).map(u => (
                  <div
                    key={u.id}
                    className="p-3 rounded-2xl bg-neutral-950 border border-white/5 hover:border-cyan-500/40 flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={u.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                        alt={u.name}
                        className="w-9 h-9 rounded-full object-cover"
                      />
                      <div>
                        <h5 className="font-bold text-white text-xs">{u.name}</h5>
                        <p className="text-[10px] text-neutral-400 font-mono">
                          ID: #{u.id} • VIP {u.vipLevel || 0} • {u.role || 'USER'}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleAssignToUser(u)}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs flex items-center gap-1 shadow active:scale-95"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Equip Frame</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: SAFE DELETE CONFIRMATION DIALOG */}
      {/* ========================================================================= */}
      {deleteConfirmFrame && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0e121e] border border-rose-500/40 rounded-3xl p-6 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-1">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-black text-white text-base font-['Outfit']">Delete Frame Permanently?</h3>
              <p className="text-xs text-neutral-300">
                Are you sure you want to permanently delete frame <b className="text-white font-bold">"{deleteConfirmFrame.name}"</b> ({deleteConfirmFrame.id})?
              </p>
            </div>

            {deleteConfirmFrame.activeUsersCount > 0 && (
              <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 shrink-0" />
                <span>
                  ⚠️ Warning: This frame is currently active on <b>{deleteConfirmFrame.activeUsersCount} user(s)</b>. Deleting it will remove it from them.
                </span>
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                onClick={() => setDeleteConfirmFrame(null)}
                className="px-4 py-2.5 rounded-xl bg-neutral-800 text-neutral-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-rose-900/40"
              >
                Yes, Delete Frame
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: FULL PREVIEW MODAL */}
      {/* ========================================================================= */}
      {previewFrame && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0c101d] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-5 text-center animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Frame Inspector</span>
              <button
                onClick={() => setPreviewFrame(null)}
                className="w-7 h-7 rounded-full bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="py-4 flex flex-col items-center">
              <div className="relative w-32 h-32 flex items-center justify-center mb-3">
                <div className={`absolute inset-0 rounded-full border-4 ${
                  previewFrame.rarity === 'Royalty' ? 'border-amber-400 shadow-[0_0_20px_rgba(251,191,36,0.6)] animate-pulse' :
                  previewFrame.rarity === 'Legendary' ? 'border-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.6)]' :
                  previewFrame.rarity === 'Epic' ? 'border-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.5)]' :
                  'border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                }`} />
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200"
                  alt="Avatar"
                  className="w-28 h-28 rounded-full object-cover"
                />
                {previewFrame.previewUrl && (
                  <img
                    src={previewFrame.previewUrl}
                    alt={previewFrame.name}
                    className="absolute inset-0 w-full h-full rounded-full object-cover pointer-events-none opacity-40 mix-blend-screen"
                  />
                )}
              </div>

              <h3 className="text-base font-black text-white">{previewFrame.name}</h3>
              <p className="text-xs text-neutral-400 font-mono mt-0.5">{previewFrame.id} • {previewFrame.rarity}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold">
                  VIP {previewFrame.vipLevelRequired || 0} Required
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold">
                  {previewFrame.coinPrice > 0 ? `${previewFrame.coinPrice.toLocaleString()} Coins` : 'Free'}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                setPreviewFrame(null);
                handleOpenAssignModal(previewFrame);
              }}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-black text-xs uppercase tracking-wider shadow"
            >
              Give this Frame to a User
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
