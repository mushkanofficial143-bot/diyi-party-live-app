import React, { useState } from 'react';
import { 
  Crown, 
  LayoutDashboard, 
  ShieldCheck, 
  Shield, 
  UserCheck, 
  Building2, 
  Tv, 
  Users, 
  Radio, 
  Gift, 
  Sparkles, 
  Coins, 
  Layers, 
  Dices, 
  DollarSign, 
  AlertTriangle, 
  Bell, 
  Activity, 
  Settings, 
  LogOut,
  User,
  ExternalLink,
  Wallet,
  Swords,
  Gamepad2,
  Sliders,
  FileText,
  Award,
  Image,
  UserPlus
} from 'lucide-react';
import { 
  UserRole, 
  AdminAccount, 
  ManagerAccount, 
  AgencyAccount, 
  UserAccount,
  LiveRoomAccount,
  GiftItem,
  WalletTransaction,
  VipTierConfig,
  WithdrawalRequest,
  ModerationReport,
  NotificationItem,
  AuditLogEntry,
  PlatformSettings,
  OwnerDashboardStats,
  CoinSellerAccount,
  CoinSellerTransaction,
  OwnerToSellerTransaction,
  PartyLiveRoomSession,
  AvatarFrameItem,
  PkBattleItem,
  CasinoTestTransaction,
  PlatformWalletSettings
} from '../../types/ownerTypes';
import { checkRBACPermission, createAuditLog, ROLE_LABELS, ROLE_HIERARCHY_RANK } from '../../utils/rbacGuard';
import { OwnerGlobalSearch } from './OwnerGlobalSearch';
import { OwnerDashboardView } from './OwnerDashboardView';
import { AdminsSection } from './AdminsSection';
import { ManagersSection } from './ManagersSection';
import { AgenciesSection } from './AgenciesSection';
import { UsersSection } from './UsersSection';
import { LiveRoomsSection } from './LiveRoomsSection';
import { GiftsSection } from './GiftsSection';
import { WalletSection } from './WalletSection';
import { VipSection } from './VipSection';
import { WithdrawalsSection } from './WithdrawalsSection';
import { ReportsSection } from './ReportsSection';
import { NotificationsSection } from './NotificationsSection';
import { AuditLogsSection } from './AuditLogsSection';
import { SettingsSection } from './SettingsSection';
import { CoinSellersSection } from './CoinSellersSection';
import { OwnerTestWalletSection } from './OwnerTestWalletSection';
import { PartyLiveSection } from './PartyLiveSection';
import { FramesSection } from './FramesSection';
import { PkBattlesSection } from './PkBattlesSection';
import { TransactionsSection } from './TransactionsSection';
import { PartyLiveRoom } from '../party/PartyLiveRoom';
import { HierarchyTreeModal } from './HierarchyTreeModal';
import { RoleDetailModal } from './RoleDetailModal';
import { RoleActionModal } from './RoleActionModal';
import { LuckyBoxOwnerSection } from './LuckyBoxOwnerSection';
import { RedPacketOwnerSection } from './RedPacketOwnerSection';
import { DailySummaryReportWidget } from './DailySummaryReportWidget';
import { BadgeTagsShowcase } from '../badges/BadgeTagsShowcase';
import { HostTypesSection } from './HostTypesSection';
import { CoinManagementHub } from './CoinManagementHub';
import { GameManagementSection } from './GameManagementSection';
import { BannersSection } from './BannersSection';
import { AgencyJoinRequestsSection } from './AgencyJoinRequestsSection';
import { StaffHiringHubSection } from './StaffHiringHubSection';
import { playSoundFX } from '../../utils/audioSynth';

import { ProfileFrameStudio } from '../frames/ProfileFrameStudio';

interface OwnerDashboardProps {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  // State props
  stats: OwnerDashboardStats;
  admins: AdminAccount[];
  managers: ManagerAccount[];
  agencies: AgencyAccount[];
  users: UserAccount[];
  liveRooms: LiveRoomAccount[];
  gifts: GiftItem[];
  walletTransactions: WalletTransaction[];
  vipConfigs: VipTierConfig[];
  withdrawals: WithdrawalRequest[];
  reports: ModerationReport[];
  notifications: NotificationItem[];
  auditLogs: AuditLogEntry[];
  platformSettings: PlatformSettings;
  // New props for Coin Sellers, Test Wallet, Party Live, Frames, PK Battles, Casino
  coinSellers?: CoinSellerAccount[];
  ownerTestCoinBalance?: number;
  ownerToSellerTxs?: OwnerToSellerTransaction[];
  sellerToUserTxs?: CoinSellerTransaction[];
  partyLiveRoom?: PartyLiveRoomSession;
  avatarFrames?: AvatarFrameItem[];
  pkBattles?: PkBattleItem[];
  casinoTransactions?: CasinoTestTransaction[];
  walletSettings?: PlatformWalletSettings;
  platformUsers?: any[];
  currentUser?: any;
  banners?: any[];
  agencyJoinRequests?: any[];
  // Handlers
  onUpdateAdmins: (adm: AdminAccount[]) => void;
  onUpdateManagers: (mgr: ManagerAccount[]) => void;
  onUpdateAgencies: (ag: AgencyAccount[]) => void;
  onUpdateUsers: (usr: UserAccount[]) => void;
  onUpdateLiveRooms: (rooms: LiveRoomAccount[]) => void;
  onUpdateGifts: (gifts: GiftItem[]) => void;
  onUpdateWalletTransactions: (txs: WalletTransaction[]) => void;
  onUpdateVipConfigs: (vips: VipTierConfig[]) => void;
  onUpdateWithdrawals: (w: WithdrawalRequest[]) => void;
  onUpdateReports: (r: ModerationReport[]) => void;
  onUpdateNotifications: (n: NotificationItem[]) => void;
  onAddAuditLog: (log: AuditLogEntry) => void;
  onAddNotification?: (notif: NotificationItem) => void;
  onUpdateSettings: (s: PlatformSettings) => void;
  onUpdateAvatarFrames?: (frames: AvatarFrameItem[]) => void;
  onEquipFrameToUser?: (userId: string, frameId: string, frameUrl?: string) => void;
  // New handlers
  onTransferToSeller?: (sellerId: string, amount: number, notes?: string) => Promise<boolean>;
  onReclaimFromSeller?: (sellerId: string, amount: number, notes?: string) => Promise<boolean>;
  onCreateCoinSeller?: (sellerData: any) => Promise<boolean>;
  onUpdateCoinSellerStatus?: (sellerId: string, status: any) => Promise<boolean>;
  onUpdateCoinSellerLimits?: (sellerId: string, dailyLimit: number, singleLimit: number) => Promise<boolean>;
  onUpdateWalletSettings?: (settings: PlatformWalletSettings) => Promise<boolean> | void;
  onUserTransfer?: (senderId: string, receiverId: string, amount: number, notes?: string) => Promise<any>;
}

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({
  currentRole,
  setCurrentRole,
  stats,
  admins,
  managers,
  agencies,
  users,
  liveRooms,
  gifts,
  walletTransactions,
  vipConfigs,
  games,
  withdrawals,
  reports,
  notifications,
  auditLogs,
  platformSettings,
  coinSellers = [],
  ownerTestCoinBalance = 500000000,
  ownerToSellerTxs = [],
  sellerToUserTxs = [],
  partyLiveRoom,
  avatarFrames = [],
  pkBattles = [],
  casinoTransactions = [],
  walletSettings,
  platformUsers,
  currentUser,
  banners = [],
  agencyJoinRequests = [],
  onUpdateAdmins,
  onUpdateManagers,
  onUpdateAgencies,
  onUpdateUsers,
  onUpdateLiveRooms,
  onUpdateGifts,
  onUpdateWalletTransactions,
  onUpdateVipConfigs,
  onUpdateGames,
  onUpdateWithdrawals,
  onUpdateReports,
  onUpdateNotifications,
  onAddAuditLog,
  onAddNotification = () => {},
  onUpdateSettings,
  onUpdateAvatarFrames,
  onEquipFrameToUser,
  onTransferToSeller,
  onReclaimFromSeller,
  onCreateCoinSeller,
  onUpdateCoinSellerStatus,
  onUpdateCoinSellerLimits,
  onUpdateWalletSettings,
  onUserTransfer,
  onUpdateBanners = () => {},
  onUpdateAgencyRequests = () => {}
}) => {
  // Navigation active section
  const [activeSection, setActiveSection] = useState<string>(() => {
    try {
      const guard = localStorage.getItem('diyo_hiring_guard_state');
      if (guard) {
        const parsed = JSON.parse(guard);
        if (parsed && parsed.active && parsed.isGuarded) {
          return 'staff_hiring';
        }
      }
      const saved = localStorage.getItem('diyo_owner_active_section');
      if (saved) return saved;
    } catch {}
    return 'dashboard';
  });

  const handleSelectSection = (sec: string) => {
    setActiveSection(sec);
    try {
      localStorage.setItem('diyo_owner_active_section', sec);
    } catch {}
  };

  // Modals
  const [showHierarchyTree, setShowHierarchyTree] = useState(false);
  const [detailModalItem, setDetailModalItem] = useState<{ role: UserRole; data: any } | null>(null);
  const [actionModalType, setActionModalType] = useState<any>(null);

  // Security Verification Guard
  const handleProtectedAction = (
    action: string,
    targetRole?: UserRole,
    targetId?: string,
    callback?: () => void
  ) => {
    const isAllowed = checkRBACPermission(currentRole, action, targetRole);
    if (!isAllowed) {
      playSoundFX('alert');
      alert(`⛔ RBAC Security Guard: Permission Denied! Role "${currentRole}" is not authorized to execute "${action}" on ${targetRole || 'this resource'}.`);
      onAddAuditLog(
        createAuditLog(
          'OWN-001',
          'Current User',
          currentRole,
          action,
          targetId || 'SYSTEM',
          targetRole,
          'DENIED',
          `Unauthorized attempt blocked by DIYO LIVE Security Engine.`
        )
      );
      return;
    }

    if (callback) {
      callback();
    }
  };

  // Select entity from search or table
  const handleSelectEntity = (role: UserRole, item: any) => {
    setDetailModalItem({ role, data: item });
  };

  // Nav Items Configuration - DIYO LIVE Professional Dark Neon Admin Dashboard
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: null },
    { id: 'staff_hiring', label: 'Staff & Hiring Hub', icon: UserPlus, badge: 'HIRE' },
    { id: 'users', label: 'User Management', icon: Users, badge: users.length },
    { id: 'hosts', label: 'Host Management', icon: Tv, badge: null },
    { id: 'frames', label: 'Frame Management', icon: Sparkles, badge: (avatarFrames && avatarFrames.length > 0) ? `${avatarFrames.length}` : '👑', ownerOnly: true },
    { id: 'coin_management', label: 'Coin Management', icon: Coins, badge: 'CENTRAL' },
    { id: 'game_management', label: 'Game Management', icon: Dices, badge: 'ACTIVE' },
    { id: 'gifts', label: 'Gift Management', icon: Gift, badge: gifts.length },
    { id: 'live_management', label: 'Live Management', icon: Radio, badge: liveRooms.length, isLive: true },
    { id: 'banners', label: 'Banners & Sliders', icon: Image, badge: banners.length },
    { id: 'agency_joins', label: 'Host Joining Requests', icon: UserCheck, badge: agencyJoinRequests.filter(r => r.status === 'PENDING').length, alertBadge: true },
    { id: 'role_permission', label: 'Role & Permission', icon: ShieldCheck, badge: currentRole },
    { id: 'reports', label: 'Reports', icon: AlertTriangle, badge: reports.filter(r => r.status === 'Pending').length, alertBadge: true },
    { id: 'settings', label: 'Settings', icon: Settings, badge: null }
  ];

  const displayedNavItems = navItems.filter(item => {
    if ((item as any).ownerOnly && currentRole !== 'OWNER') {
      return false;
    }
    const roleUpper = (currentRole || '').toUpperCase();
    if (roleUpper === 'OWNER') return true;

    if (roleUpper === 'MANAGER') {
      return ['dashboard', 'staff_hiring', 'hosts', 'users', 'reports', 'live_management', 'agency_joins', 'role_permission', 'settings'].includes(item.id);
    }
    if (roleUpper === 'SUPER_ADMIN' || roleUpper === 'SUPER ADMIN' || roleUpper === 'ADMIN') {
      return ['dashboard', 'staff_hiring', 'hosts', 'users', 'reports', 'live_management', 'agency_joins', 'role_permission'].includes(item.id);
    }
    if (roleUpper === 'ADMIN_BD' || roleUpper === 'BD_ADMIN' || roleUpper === 'BD ADMIN') {
      return ['dashboard', 'staff_hiring', 'hosts', 'agency_joins', 'role_permission'].includes(item.id);
    }
    if (roleUpper === 'AGENCY') {
      return ['dashboard', 'hosts', 'agency_joins', 'role_permission'].includes(item.id);
    }
    return ['dashboard', 'hosts'].includes(item.id);
  });

  // Action Modal Submission Dispatcher
  const handleActionModalSubmit = (data: any) => {
    const timestamp = new Date().toLocaleTimeString();

    if (actionModalType === 'CREATE_ADMIN') {
      const newAdm: AdminAccount = {
        id: `ADM-${Math.floor(100 + Math.random() * 900)}`,
        name: data.name,
        username: data.username,
        contact: data.email || data.phone,
        status: 'Active',
        permissions: ['ROOM_MONITOR', 'USER_MUTE', 'REPORT_RESOLVE'],
        lastLogin: 'Just now',
        createdDate: new Date().toISOString().split('T')[0],
        activityCount: 0,
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'
      };
      onUpdateAdmins([newAdm, ...admins]);
      onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'CREATE_ADMIN', newAdm.id, 'ADMIN', 'SUCCESS', `Created Admin ${newAdm.name}`));
    } else if (actionModalType === 'CREATE_MANAGER') {
      const newMgr: ManagerAccount = {
        id: `MGR-${Math.floor(100 + Math.random() * 900)}`,
        name: data.name,
        username: data.username,
        contact: data.email || data.phone,
        status: 'Active',
        assignedAgencies: ['AG-101'],
        assignedAgencyNames: ['Apex Royalty Guild'],
        assignedHosts: ['HST-5001'],
        hostCount: 1,
        totalEarningsDiamonds: 0,
        performanceRating: 5.0,
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150'
      };
      onUpdateManagers([newMgr, ...managers]);
      onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'CREATE_MANAGER', newMgr.id, 'MANAGER', 'SUCCESS', `Created Manager ${newMgr.name}`));
    } else if (actionModalType === 'CREATE_AGENCY') {
      const newAg: AgencyAccount = {
        id: `AG-${Math.floor(100 + Math.random() * 900)}`,
        name: data.name,
        code: (data.username || data.name || 'AG').toUpperCase(),
        ownerOrManager: 'Ananya Deshmukh (MGR-301)',
        managerId: data.managerId || 'MGR-301',
        status: 'Active',
        numberOfHosts: 0,
        activeHosts: 0,
        totalGiftsReceived: 0,
        hostPerformanceScore: 95,
        totalEarningsDiamonds: 0,
        commissionRate: data.commissionRate || 15,
        createdDate: new Date().toISOString().split('T')[0],
        logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150',
        contactEmail: data.email
      };
      onUpdateAgencies([newAg, ...agencies]);
      onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'CREATE_AGENCY', newAg.id, 'AGENCY', 'SUCCESS', `Created Agency ${newAg.name}`));
    } else if (actionModalType === 'CREATE_GIFT') {
      const newGift: GiftItem = {
        id: `GFT-${Math.floor(100 + Math.random() * 900)}`,
        name: data.name,
        category: data.isLucky ? 'Lucky' : 'Deluxe',
        coinPrice: data.coinPrice || 500,
        diamondValue: data.diamondValue || 350,
        isLucky: data.isLucky || false,
        luckyMultiplierMax: data.isLucky ? 200 : undefined,
        animationType: 'imperial-burst',
        isActive: true,
        totalSentCount: 0,
        icon: data.isLucky ? '✨' : '👑'
      };
      onUpdateGifts([newGift, ...gifts]);
      onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'CREATE_GIFT', newGift.id, undefined, 'SUCCESS', `Created Gift ${newGift.name}`));
    } else if (actionModalType === 'SEND_NOTIFICATION') {
      const newNotif: NotificationItem = {
        id: `NTF-${Math.floor(100 + Math.random() * 900)}`,
        title: data.title,
        message: data.message,
        targetAudience: data.targetAudience || 'All',
        timestamp: 'Just now',
        readCount: 1,
        sentBy: 'Master Owner'
      };
      onUpdateNotifications([newNotif, ...notifications]);
      onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'SEND_NOTIFICATION', newNotif.id, undefined, 'SUCCESS', `Dispatched Push Notification "${newNotif.title}"`));
    } else if (actionModalType === 'ADJUST_COINS') {
      const targetUser = users.find(u => u.id === data.targetUserId);
      if (targetUser) {
        const updated = users.map(u => u.id === targetUser.id ? { ...u, coinBalance: u.coinBalance + Number(data.amountCoins) } : u);
        onUpdateUsers(updated);
        const newTx: WalletTransaction = {
          id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
          type: 'MANUAL_ADJUSTMENT',
          senderId: 'OWN-001',
          senderName: 'Master Treasury',
          recipientId: targetUser.id,
          recipientName: targetUser.name,
          amountCoins: Number(data.amountCoins),
          amountDiamonds: 0,
          status: 'Completed',
          timestamp: 'Just now',
          paymentChannel: 'Owner Treasury Adjustment',
          txHash: `0x${Math.random().toString(16).substring(2, 10)}...manual`
        };
        onUpdateWalletTransactions([newTx, ...walletTransactions]);
        onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'ADJUST_COINS', targetUser.id, 'USER', 'SUCCESS', `Adjusted coins by ${data.amountCoins} for ${targetUser.name}`));
      }
    }
  };

  // Generate Test Transaction
  const handleGenerateTestTransaction = () => {
    const randomUser = users[Math.floor(Math.random() * users.length)];
    const randomRecipient = users[Math.floor(Math.random() * users.length)];
    const randomCoin = 2500;
    const randomDiamond = 1750;

    const newTx: WalletTransaction = {
      id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
      type: 'TEST_TRANSACTION',
      senderId: randomUser.id,
      senderName: `${randomUser.name} (QA Sandbox)`,
      recipientId: randomRecipient.id,
      recipientName: `${randomRecipient.name} (Live)`,
      amountCoins: randomCoin,
      amountDiamonds: randomDiamond,
      status: 'Completed',
      timestamp: 'Just now',
      paymentChannel: 'Sandbox Mock Gateway',
      txHash: `0xTEST${Math.random().toString(16).substring(2, 12)}`
    };

    onUpdateWalletTransactions([newTx, ...walletTransactions]);
    onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'TEST_TRANSACTION', newTx.id, undefined, 'SUCCESS', `Simulated Test Transaction of ${randomCoin} coins to ${randomRecipient.name}`));
  };

  const handleAutoGenerateCoins = async (data: any) => {
    const targetUsr = users.find(u => u.id === data.receiverId) || users[0];
    if (targetUsr) {
      const updated = users.map(u => u.id === targetUsr.id ? { ...u, coinBalance: u.coinBalance + data.amount } : u);
      onUpdateUsers(updated);
      const newTx: WalletTransaction = {
        id: `TXN-GEN-${Date.now()}`,
        userId: targetUsr.id,
        userName: targetUsr.name,
        type: 'Deposit',
        amountCoins: data.amount,
        amountDiamonds: 0,
        timestamp: 'Just now',
        status: 'Completed',
        notes: `Auto Coin Generate (${data.type}): ${data.reason}`
      };
      onUpdateWalletTransactions([newTx, ...walletTransactions]);
      onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'AUTO_GENERATE_COINS', targetUsr.id, undefined, 'SUCCESS', `Auto-generated ${data.amount} coins for ${targetUsr.name} (${data.type})`));
      return true;
    }
    return false;
  };

  const handleReverseTransaction = async (txId: string, reason: string) => {
    const tx = walletTransactions.find(t => t.id === txId) || sellerToUserTxs.find(t => t.id === txId);
    if (!tx) return false;
    const revTx: WalletTransaction = {
      id: `REV-${Date.now()}`,
      userId: tx.userId || 'SYSTEM',
      userName: tx.userName || 'System Reversal',
      type: 'Withdraw',
      amountCoins: -Math.abs(tx.amountCoins || tx.amount || 0),
      amountDiamonds: 0,
      timestamp: 'Just now',
      status: 'Completed',
      notes: `Reversal of Tx ${txId}: ${reason}`
    };
    onUpdateWalletTransactions([revTx, ...walletTransactions]);
    onAddAuditLog(createAuditLog('OWN-001', 'Super Admin Owner', currentRole, 'REVERSE_TRANSACTION', txId, undefined, 'SUCCESS', `Reversed transaction ${txId}. Reason: ${reason}`));
    return true;
  };

  const handleHireCoinSeller = async (data: any) => {
    if (onCreateCoinSeller) {
      return await onCreateCoinSeller(data);
    }
    return false;
  };

  const handleHireAdmin = async (data: any) => {
    const newAdm: AdminAccount = {
      id: `ADM-${Math.floor(100 + Math.random() * 900)}`,
      name: data.name,
      username: data.username,
      contact: data.contact,
      status: 'Active',
      permissions: data.permissions || ['ROOM_MONITOR'],
      lastLogin: 'Just now',
      createdDate: new Date().toISOString().split('T')[0],
      activityCount: 0,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'
    };
    onUpdateAdmins([newAdm, ...admins]);
    onAddAuditLog(createAuditLog('OWN-001', 'Master Owner', currentRole, 'CREATE_ADMIN', newAdm.id, 'ADMIN', 'SUCCESS', `Hired Admin ${newAdm.name}`));
    return true;
  };

  const handleHireManager = async (data: any) => {
    const newMgr: ManagerAccount = {
      id: `MGR-${Math.floor(300 + Math.random() * 600)}`,
      name: data.name,
      username: data.username,
      contact: data.contact,
      status: 'Active',
      assignedAgencies: data.assignedAgencies || ['AG-01'],
      assignedAgencyNames: ['Agency ' + (data.assignedAgencies?.[0] || 'AG-01')],
      assignedHosts: [],
      hostCount: 0,
      totalEarningsDiamonds: 0,
      performanceRating: 100,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
    };
    onUpdateManagers([newMgr, ...managers]);
    onAddAuditLog(createAuditLog('OWN-001', 'Master Owner', currentRole, 'CREATE_MANAGER', newMgr.id, 'MANAGER', 'SUCCESS', `Hired Manager ${newMgr.name}`));
    return true;
  };

  const handleHireAgency = async (data: any) => {
    const newAg: AgencyAccount = {
      id: `AG-${Math.floor(100 + Math.random() * 900)}`,
      name: data.name,
      code: data.code || `AG-${Math.floor(100 + Math.random() * 900)}`,
      ownerOrManager: data.ownerOrManager || 'Agency Owner',
      managerId: 'MGR-301',
      status: 'Active',
      numberOfHosts: 0,
      activeHosts: 0,
      totalGiftsReceived: 0,
      hostPerformanceScore: 98,
      totalEarningsDiamonds: 0,
      commissionRate: Number(data.commissionRate) || 15,
      createdDate: new Date().toISOString().split('T')[0],
      logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150',
      contactEmail: data.contactEmail || 'agency@srlive.io'
    };
    onUpdateAgencies([newAg, ...agencies]);
    onAddAuditLog(createAuditLog('OWN-001', 'Master Owner', currentRole, 'CREATE_AGENCY', newAg.id, 'AGENCY', 'SUCCESS', `Hired & Created Agency ${newAg.name}`));
    return true;
  };

  const handleHireBD = async (data: any) => {
    const newBd: AdminAccount = {
      id: `BD-${Math.floor(100 + Math.random() * 900)}`,
      name: data.name,
      username: data.username,
      contact: data.contact || data.email,
      status: 'Active',
      permissions: ['BD_OPERATIONS', 'AGENCY_RECRUIT'],
      lastLogin: 'Just now',
      createdDate: new Date().toISOString().split('T')[0],
      activityCount: 0,
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150'
    };
    onUpdateAdmins([newBd, ...admins]);
    onAddAuditLog(createAuditLog('OWN-001', 'Master Owner', currentRole, 'CREATE_ADMIN', newBd.id, 'ADMIN_BD', 'SUCCESS', `Hired BD Executive ${newBd.name} (${data.assignedArea})`));
    return true;
  };

  return (
    <div className="flex flex-col lg:flex-row h-full lg:h-[calc(100vh-4rem)] bg-neutral-950 text-neutral-100 overflow-y-auto lg:overflow-hidden">
      
      {/* Sidebar Navigation */}
      <aside className="w-full lg:w-64 bg-neutral-900/90 border-r border-neutral-800 p-4 flex flex-col justify-between flex-shrink-0">
        
        <div className="space-y-4">
          {/* Top Panel Brand */}
          <div className="flex items-center gap-2.5 px-2 py-1">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/20">
              <Crown className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white font-['Outfit'] tracking-wide">
                {currentRole === 'OWNER' ? 'OWNER PANEL' :
                 currentRole === 'MANAGER' ? 'MANAGER DESK' :
                 currentRole === 'SUPER_ADMIN' || currentRole === 'SUPER ADMIN' ? 'SUPER ADMIN DESK' :
                 currentRole === 'ADMIN_BD' || currentRole === 'BD_ADMIN' ? 'BD ADMIN DESK' :
                 currentRole === 'AGENCY' ? 'AGENCY GUILD DESK' : 'STAFF PANEL'}
              </h2>
              <p className="text-[10px] text-amber-400 font-mono font-bold">DIYO LIVE GOVERNANCE</p>
            </div>
          </div>

          {/* Role Impersonation Switcher (Interactive Sandbox Switch) */}
          <div className="p-3 bg-neutral-950/80 rounded-2xl border border-neutral-800/80 space-y-1.5 text-xs">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-neutral-400 font-medium">Active Role Context:</span>
              <span className="font-mono text-amber-400 font-bold">Rank #{ROLE_HIERARCHY_RANK[currentRole]}</span>
            </div>

            <select
              value={currentRole}
              onChange={(e) => {
                const newRole = e.target.value as UserRole;
                setCurrentRole(newRole);
                playSoundFX('notification');
                onAddAuditLog(createAuditLog('OWN-001', 'Current User', newRole, 'SWITCH_ROLE_CONTEXT', 'SYSTEM', undefined, 'SUCCESS', `Switched active role context to ${newRole}`));
              }}
              className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-2.5 py-1.5 text-xs text-white font-bold focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="OWNER">👑 OWNER (Authority: 7)</option>
              <option value="SUPER_ADMIN">🛡️ SUPER ADMIN (Authority: 6)</option>
              <option value="ADMIN">🛡️ ADMIN (Authority: 5)</option>
              <option value="OFFICIAL">🛡️ OFFICIAL (Authority: 4)</option>
              <option value="MANAGER">👔 MANAGER (Authority: 4)</option>
              <option value="AGENCY">🏢 AGENCY (Authority: 3)</option>
              <option value="HOST">🎙️ HOST (Authority: 2)</option>
              <option value="USER">👤 USER (Authority: 1)</option>
            </select>
          </div>

          {/* Nav List */}
          <nav className="space-y-1 max-h-[55vh] overflow-y-auto pr-1">
            {displayedNavItems.map((item) => {
              const IconComponent = item.icon;
              const isActive = activeSection === item.id || (item.id === 'lucky_gifts' && activeSection === 'gifts');
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    handleSelectSection(item.id === 'lucky_gifts' ? 'gifts' : item.id);
                    playSoundFX('click');
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-amber-500/20 to-rose-500/20 text-white border border-amber-500/40 shadow-sm'
                      : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <IconComponent className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-neutral-400'}`} />
                    <span>{item.label}</span>
                  </div>

                  {item.badge !== null && item.badge > 0 && (
                    <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full font-bold ${
                      item.alertBadge ? 'bg-rose-500 text-white' :
                      item.isLive ? 'bg-rose-600 text-white animate-pulse' :
                      'bg-neutral-800 text-neutral-300'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Hierarchy Action */}
        <div className="pt-4 border-t border-neutral-800 space-y-2">
          <button
            onClick={() => {
              setShowHierarchyTree(true);
              playSoundFX('click');
            }}
            className="w-full py-2 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-2 border border-neutral-700"
          >
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span>Hierarchy Tree Visualizer</span>
          </button>
        </div>

      </aside>

      {/* Main Content Workspace */}
      <main className="flex-1 p-4 lg:p-6 pb-36 space-y-6 overflow-y-auto min-h-0 [-webkit-overflow-scrolling:touch]">
        
        {/* Global Search Bar (Always Accessible to Owner) */}
        <OwnerGlobalSearch
          admins={admins}
          managers={managers}
          agencies={agencies}
          users={users}
          onSelectEntity={handleSelectEntity}
        />

        {/* Dynamic Section Routing */}
        {activeSection === 'dashboard' && (
          <div className="space-y-6">
            <OwnerDashboardView
              stats={stats}
              onNavigateSection={(sec) => setActiveSection(sec)}
              onOpenHierarchyTree={() => setShowHierarchyTree(true)}
              onOpenActionModal={(type) => setActionModalType(type)}
            />
            {/* Embedded Daily Operations & Security Summary Report Widget */}
            <DailySummaryReportWidget
              auditLogs={auditLogs}
              reports={reports}
              onResolveReport={(id) => {
                handleProtectedAction('REPORT_REVIEW', undefined, id, () => {
                  onUpdateReports(reports.map(r => r.id === id ? { ...r, status: 'Resolved' } : r));
                  onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'RESOLVE_REPORT', id, undefined, 'SUCCESS', `Resolved flagged report from daily summary widget`));
                });
              }}
            />
          </div>
        )}

        {(activeSection === 'staff_hiring' || activeSection === 'role_permission') && (
          <StaffHiringHubSection
            currentUser={currentUser}
            currentRole={currentRole}
            onHireCoinSeller={handleHireCoinSeller}
            onHireAdmin={handleHireAdmin}
            onHireManager={handleHireManager}
            onHireAgency={handleHireAgency}
            onHireBD={handleHireBD}
          />
        )}

        {activeSection === 'coin_management' && (
          <CoinManagementHub
            coinSellers={coinSellers}
            ownerTestCoinBalance={ownerTestCoinBalance}
            sellerToUserTxs={sellerToUserTxs}
            walletTransactions={walletTransactions}
            onTransferToSeller={onTransferToSeller || (async () => true)}
            onReclaimFromSeller={onReclaimFromSeller || (async () => true)}
            onCreateSeller={onCreateCoinSeller || (async () => true)}
            onUpdateSellerStatus={onUpdateCoinSellerStatus || (async () => true)}
            onAutoGenerateCoins={handleAutoGenerateCoins}
            onReverseTransaction={handleReverseTransaction}
          />
        )}

        {activeSection === 'game_management' && (
          <GameManagementSection
            onAddAuditLog={onAddAuditLog}
          />
        )}

        {activeSection === 'daily_summary' && (
          <DailySummaryReportWidget
            auditLogs={auditLogs}
            reports={reports}
            onResolveReport={(id) => {
              handleProtectedAction('REPORT_REVIEW', undefined, id, () => {
                onUpdateReports(reports.map(r => r.id === id ? { ...r, status: 'Resolved' } : r));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'RESOLVE_REPORT', id, undefined, 'SUCCESS', `Resolved flagged report from daily summary report`));
              });
            }}
          />
        )}

        {activeSection === 'profile_frames_system' && (
          <ProfileFrameStudio />
        )}

        {activeSection === 'badge_tags_catalog' && (
          <BadgeTagsShowcase />
        )}

        {activeSection === 'admins' && (
          <AdminsSection
            admins={admins}
            users={users}
            onUpdateUsers={onUpdateUsers}
            onOpenDetail={(adm) => handleSelectEntity('ADMIN', adm)}
            onOpenCreate={() => setActionModalType('CREATE_ADMIN')}
            onUpdateStatus={(id, st) => {
              handleProtectedAction('MANAGE_ADMINS', 'ADMIN', id, () => {
                onUpdateAdmins(admins.map(a => a.id === id ? { ...a, status: st as any } : a));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'UPDATE_STATUS', id, 'ADMIN', 'SUCCESS', `Status updated to ${st}`));
              });
            }}
            onRemove={(id) => {
              handleProtectedAction('MANAGE_ADMINS', 'ADMIN', id, () => {
                onUpdateAdmins(admins.filter(a => a.id !== id));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'REMOVE_ACCOUNT', id, 'ADMIN', 'SUCCESS', `Removed Admin account`));
              });
            }}
          />
        )}

        {activeSection === 'managers' && (
          <ManagersSection
            managers={managers}
            onOpenDetail={(mgr) => handleSelectEntity('MANAGER', mgr)}
            onOpenCreate={() => setActionModalType('CREATE_MANAGER')}
            onUpdateStatus={(id, st) => {
              handleProtectedAction('MANAGE_MANAGERS', 'MANAGER', id, () => {
                onUpdateManagers(managers.map(m => m.id === id ? { ...m, status: st as any } : m));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'UPDATE_STATUS', id, 'MANAGER', 'SUCCESS', `Status updated to ${st}`));
              });
            }}
            onRemove={(id) => {
              handleProtectedAction('MANAGE_MANAGERS', 'MANAGER', id, () => {
                onUpdateManagers(managers.filter(m => m.id !== id));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'REMOVE_ACCOUNT', id, 'MANAGER', 'SUCCESS', `Removed Manager account`));
              });
            }}
          />
        )}

        {activeSection === 'agencies' && (
          <AgenciesSection
            agencies={agencies}
            onOpenDetail={(ag) => handleSelectEntity('AGENCY', ag)}
            onOpenCreate={() => setActionModalType('CREATE_AGENCY')}
            onUpdateStatus={(id, st) => {
              handleProtectedAction('MANAGE_AGENCIES', 'AGENCY', id, () => {
                onUpdateAgencies(agencies.map(a => a.id === id ? { ...a, status: st as any } : a));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'UPDATE_STATUS', id, 'AGENCY', 'SUCCESS', `Agency status updated to ${st}`));
              });
            }}
            onRemove={(id) => {
              handleProtectedAction('MANAGE_AGENCIES', 'AGENCY', id, () => {
                onUpdateAgencies(agencies.filter(a => a.id !== id));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'REMOVE_ACCOUNT', id, 'AGENCY', 'SUCCESS', `Removed Agency guild`));
              });
            }}
          />
        )}

        {activeSection === 'users' && (
          <UsersSection
            users={users}
            onOpenDetail={(usr) => handleSelectEntity('USER', usr)}
            onUpdateStatus={(id, st) => {
              handleProtectedAction('MANAGE_USERS', 'USER', id, () => {
                onUpdateUsers(users.map(u => u.id === id ? { ...u, status: st as any } : u));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'UPDATE_STATUS', id, 'USER', 'SUCCESS', `User status updated to ${st}`));
              });
            }}
          />
        )}

        {activeSection === 'live_rooms' && (
          <LiveRoomsSection
            liveRooms={liveRooms}
            onTerminateRoom={(roomId) => {
              handleProtectedAction('LIVE_ROOM_MOD', undefined, roomId, () => {
                onUpdateLiveRooms(liveRooms.filter(r => r.id !== roomId));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'TERMINATE_LIVE_STREAM', roomId, 'HOST', 'SUCCESS', `Stream room killed immediately by Owner`));
              });
            }}
            onWarnHost={(hostId) => {
              handleProtectedAction('LIVE_ROOM_MOD', undefined, hostId, () => {
                alert(`Warning banner broadcasted to Host ${hostId}.`);
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'WARN_HOST', hostId, 'HOST', 'SUCCESS', `Dispatched warning to live host`));
              });
            }}
          />
        )}

        {activeSection === 'gifts' && (
          <GiftsSection
            gifts={gifts}
            onOpenCreate={() => setActionModalType('CREATE_GIFT')}
            onToggleActive={(giftId) => {
              handleProtectedAction('MANAGE_PLATFORM_SETTINGS', undefined, giftId, () => {
                onUpdateGifts(gifts.map(g => g.id === giftId ? { ...g, isActive: !g.isActive } : g));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'TOGGLE_GIFT_ACTIVE', giftId, undefined, 'SUCCESS', `Toggled gift active state`));
              });
            }}
            onDeleteGift={(giftId) => {
              handleProtectedAction('MANAGE_PLATFORM_SETTINGS', undefined, giftId, () => {
                onUpdateGifts(gifts.filter(g => g.id !== giftId));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'DELETE_GIFT', giftId, undefined, 'SUCCESS', `Deleted gift from catalog`));
              });
            }}
          />
        )}

        {activeSection === 'lucky_box' && (
          <LuckyBoxOwnerSection />
        )}

        {activeSection === 'red_packets' && (
          <RedPacketOwnerSection />
        )}

        {activeSection === 'wallet' && (
          <WalletSection
            transactions={walletTransactions}
            onOpenAdjustCoins={() => setActionModalType('ADJUST_COINS')}
            onGenerateTestTransaction={handleGenerateTestTransaction}
          />
        )}

        {activeSection === 'vip' && (
          <VipSection
            vipConfigs={vipConfigs}
            onUpdateVipConfig={(lvl, updated) => {
              handleProtectedAction('MANAGE_PLATFORM_SETTINGS', undefined, `VIP-${lvl}`, () => {
                onUpdateVipConfigs(vipConfigs.map(v => v.level === lvl ? { ...v, ...updated } : v));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'UPDATE_VIP_MATRIX', `VIP-${lvl}`, undefined, 'SUCCESS', `Updated VIP Level ${lvl} settings`));
              });
            }}
          />
        )}



        {activeSection === 'withdrawals' && (
          <WithdrawalsSection
            withdrawals={withdrawals}
            onApprove={(id) => {
              handleProtectedAction('APPROVE_WITHDRAWALS', undefined, id, () => {
                onUpdateWithdrawals(withdrawals.map(w => w.id === id ? { ...w, status: 'Approved' } : w));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'APPROVE_WITHDRAWAL', id, undefined, 'SUCCESS', `Approved creator withdrawal`));
              });
            }}
            onReject={(id) => {
              handleProtectedAction('APPROVE_WITHDRAWALS', undefined, id, () => {
                onUpdateWithdrawals(withdrawals.map(w => w.id === id ? { ...w, status: 'Rejected' } : w));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'REJECT_WITHDRAWAL', id, undefined, 'SUCCESS', `Rejected withdrawal request`));
              });
            }}
          />
        )}

        {activeSection === 'coin_sellers' && (
          <CoinSellersSection
            coinSellers={coinSellers || []}
            ownerTestCoinBalance={ownerTestCoinBalance || 500000000}
            sellerToUserTxs={sellerToUserTxs || []}
            onCreateSeller={onCreateCoinSeller || (async () => true)}
            onUpdateStatus={onUpdateCoinSellerStatus || (async () => true)}
            onUpdateLimits={onUpdateCoinSellerLimits || (async () => true)}
            onTransferToSeller={onTransferToSeller || (async () => true)}
            onReclaimFromSeller={onReclaimFromSeller || (async () => true)}
          />
        )}

        {activeSection === 'party_live' && (
          <PartyLiveSection
            partyRoom={partyLiveRoom || {
              id: 'PARTY-2001',
              title: '🎉 DIYO LIVE Royal 20-Seat Lounge & Musical Party',
              ownerId: 'USR-882941',
              ownerName: 'Aarav Mehta (SR Creator)',
              ownerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
              crownHolderId: 'USR-882941',
              crownHolderName: 'Aarav Mehta',
              crownTitle: '👑 SIR CROWN',
              totalSeats: 20,
              viewerCount: 2480,
              totalGiftsReceivedCoins: 890000,
              startedAt: '2026-08-15 04:00 UTC',
              status: 'Active',
              category: 'Music & Hangout',
              seats: []
            }}
          />
        )}

        {activeSection === 'owner_test_wallet' && (
          <OwnerTestWalletSection
            ownerTestCoinBalance={ownerTestCoinBalance || 500000000}
            coinSellers={coinSellers || []}
            ownerToSellerTxs={ownerToSellerTxs || []}
            onTransferToSeller={onTransferToSeller || (async () => true)}
            onReclaimFromSeller={onReclaimFromSeller || (async () => true)}
            walletSettings={walletSettings}
            onUpdateWalletSettings={onUpdateWalletSettings}
            platformUsers={platformUsers}
            onUserTransfer={onUserTransfer}
          />
        )}

        {activeSection === 'host_types' && (
          <HostTypesSection
            hosts={users.map(u => ({
              id: u.id,
              name: u.name,
              username: u.username,
              agencyId: 'AG-101',
              agencyName: 'Apex Guild',
              managerId: 'MGR-301',
              managerName: 'Manager',
              status: u.status === 'Active' ? 'Active' : 'Suspended',
              liveStatus: 'Live',
              followers: u.followersCount || 100,
              diamonds: u.diamondBalance,
              earningsUSD: u.diamondBalance / 10000,
              totalLiveHours: 10,
              lastLive: u.lastActive,
              verificationStatus: 'Verified Creator',
              streamCategory: 'Music',
              avatar: u.avatar,
              hostTag: u.hostTag,
              avatarFrameUrl: u.avatarFrameUrl
            }))}
            onAssignHostType={(userId, tag) => {
              onUpdateUsers(users.map(u => u.id === userId ? { ...u, hostTag: tag } : u));
              onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'ASSIGN_HOST_TYPE', userId, 'USER', 'SUCCESS', `Assigned Tag: ${tag}`));
            }}
            onAssignAvatarFrame={(userId, frameUrl) => {
              onUpdateUsers(users.map(u => u.id === userId ? { ...u, avatarFrameUrl: frameUrl } : u));
              onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'ASSIGN_AVATAR_FRAME', userId, 'USER', 'SUCCESS', `Assigned Avatar Frame`));
            }}
          />
        )}

        {activeSection === 'frames' && (
          currentRole !== 'OWNER' ? (
            <div className="p-8 text-center bg-neutral-900 border border-rose-500/30 rounded-3xl space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-white">ACCESS RESTRICTED – OWNER ONLY</h3>
              <p className="text-xs text-neutral-400 max-w-md mx-auto">
                Frame Management is strictly reserved for the Master Platform Owner. Other accounts cannot view, create, edit, or assign frames.
              </p>
            </div>
          ) : (
            <FramesSection 
              frames={avatarFrames || []} 
              users={users}
              currentRole={currentRole}
              onUpdateFrames={onUpdateAvatarFrames}
              onAssignFrameToUser={(userId, frame) => {
                if (onEquipFrameToUser) {
                  onEquipFrameToUser(userId, frame.id, frame.previewUrl);
                } else {
                  onUpdateUsers(users.map(u => u.id === userId ? { ...u, avatarFrameId: frame.id, avatarFrameUrl: frame.previewUrl } : u));
                }
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'ASSIGN_AVATAR_FRAME', userId, 'USER', 'SUCCESS', `Equipped frame: ${frame.name} (${frame.id})`));
              }}
              onRevokeFrameFromUser={(userId) => {
                if (onEquipFrameToUser) {
                  onEquipFrameToUser(userId, '', '');
                } else {
                  onUpdateUsers(users.map(u => u.id === userId ? { ...u, avatarFrameId: undefined, avatarFrameUrl: undefined } : u));
                }
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'REVOKE_AVATAR_FRAME', userId, 'USER', 'SUCCESS', `Revoked avatar frame from user ${userId}`));
              }}
            />
          )
        )}

        {activeSection === 'pk_battles' && (
          <PkBattlesSection pkBattles={pkBattles || []} />
        )}

        {activeSection === 'transactions' && (
          <TransactionsSection
            walletTransactions={walletTransactions}
            casinoTransactions={casinoTransactions || []}
            coinSellerTransactions={sellerToUserTxs || []}
            ownerToSellerTransactions={ownerToSellerTxs || []}
          />
        )}

        {activeSection === 'reports' && (
          <ReportsSection
            reports={reports}
            onResolveReport={(id, action) => {
              handleProtectedAction('REPORT_REVIEW', undefined, id, () => {
                onUpdateReports(reports.map(r => r.id === id ? { ...r, status: 'Resolved' } : r));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'RESOLVE_REPORT', id, undefined, 'SUCCESS', `Resolved report with action: ${action}`));
              });
            }}
            onDismissReport={(id) => {
              handleProtectedAction('REPORT_REVIEW', undefined, id, () => {
                onUpdateReports(reports.map(r => r.id === id ? { ...r, status: 'Dismissed' } : r));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'DISMISS_REPORT', id, undefined, 'SUCCESS', `Dismissed moderation report`));
              });
            }}
            onUpdateReportStatus={(id, newStatus, internalNote) => {
              handleProtectedAction('REPORT_REVIEW', undefined, id, () => {
                const now = new Date().toLocaleTimeString();
                onUpdateReports(reports.map(r => {
                  if (r.id !== id) return r;
                  const newHist = [...(r.history || []), { timestamp: now, action: `Status changed to ${newStatus}`, note: internalNote, author: currentRole }];
                  return { ...r, status: newStatus as any, internalNote, history: newHist };
                }));
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'UPDATE_REPORT_STATUS', id, undefined, 'SUCCESS', `Updated report ${id} status to ${newStatus} with note: ${internalNote}`));
              });
            }}
          />
        )}

        {activeSection === 'notifications' && (
          <NotificationsSection
            notifications={notifications}
            onOpenCreate={() => setActionModalType('SEND_NOTIFICATION')}
          />
        )}

        {activeSection === 'banners' && (
          <BannersSection
            banners={banners}
            onUpdateBanners={onUpdateBanners}
            onAddAuditLog={onAddAuditLog}
          />
        )}

        {activeSection === 'agency_joins' && (
          <AgencyJoinRequestsSection
            requests={agencyJoinRequests}
            onUpdateRequests={onUpdateAgencyRequests}
            onAddAuditLog={onAddAuditLog}
            onAddNotification={onAddNotification}
          />
        )}

        {activeSection === 'audit_logs' && (
          <AuditLogsSection logs={auditLogs} />
        )}

        {activeSection === 'settings' && (
          <SettingsSection
            settings={platformSettings}
            onUpdateSettings={(newSettings) => {
              handleProtectedAction('MANAGE_PLATFORM_SETTINGS', undefined, 'SYSTEM_SETTINGS', () => {
                onUpdateSettings(newSettings);
                onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'UPDATE_PLATFORM_SETTINGS', 'SYSTEM_SETTINGS', undefined, 'SUCCESS', `Updated global exchange rates & fraud rules`));
              });
            }}
          />
        )}

      </main>

      {/* Hierarchy Tree Visualizer Modal */}
      <HierarchyTreeModal
        isOpen={showHierarchyTree}
        onClose={() => setShowHierarchyTree(false)}
        adminsCount={admins.length}
        managersCount={managers.length}
        agenciesCount={agencies.length}
        usersCount={users.length}
      />

      {/* Role Detail Modal */}
      {detailModalItem && (
        <RoleDetailModal
          isOpen={!!detailModalItem}
          onClose={() => setDetailModalItem(null)}
          role={detailModalItem.role}
          data={detailModalItem.data}
          onUpdateStatus={(st) => {
            const id = detailModalItem.data.id;
            handleProtectedAction('UPDATE_ROLE_STATUS', detailModalItem.role, id, () => {
              if (detailModalItem.role === 'ADMIN') {
                onUpdateAdmins(admins.map(a => a.id === id ? { ...a, status: st as any } : a));
              } else if (detailModalItem.role === 'MANAGER') {
                onUpdateManagers(managers.map(m => m.id === id ? { ...m, status: st as any } : m));
              } else if (detailModalItem.role === 'AGENCY') {
                onUpdateAgencies(agencies.map(a => a.id === id ? { ...a, status: st as any } : a));
              } else if (detailModalItem.role === 'USER') {
                onUpdateUsers(users.map(u => u.id === id ? { ...u, status: st as any } : u));
              }
              setDetailModalItem(null);
            });
          }}
          onAssignAgency={(agId, agName) => {
            const id = detailModalItem.data.id;
            if (detailModalItem.role === 'USER') {
              onUpdateUsers(users.map(u => u.id === id ? { ...u, agencyId: agId, agencyName: agName } : u));
            }
          }}
          onAssignManager={(mgrId, mgrName) => {
            const id = detailModalItem.data.id;
            if (detailModalItem.role === 'USER') {
              onUpdateUsers(users.map(u => u.id === id ? { ...u, managerId: mgrId, managerName: mgrName } : u));
            }
          }}
          onAssignHostType={(hostTag) => {
            const id = detailModalItem.data.id;
            if (detailModalItem.role === 'USER') {
              onUpdateUsers(users.map(u => u.id === id ? { ...u, hostTag } : u));
              onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'ASSIGN_HOST_TYPE', id, 'USER', 'SUCCESS', `Assigned Tag: ${hostTag}`));
            }
          }}
          onAssignAvatarFrame={(avatarFrameUrl) => {
            const id = detailModalItem.data.id;
            if (detailModalItem.role === 'USER') {
              onUpdateUsers(users.map(u => u.id === id ? { ...u, avatarFrameUrl } : u));
              onAddAuditLog(createAuditLog('OWN-001', 'Owner', currentRole, 'ASSIGN_AVATAR_FRAME', id, 'USER', 'SUCCESS', `Assigned Avatar Frame`));
            }
          }}
          agencies={agencies}
          managers={managers}
        />
      )}

      {/* Role Action Modal (Create/Adjust) */}
      {actionModalType && (
        <RoleActionModal
          isOpen={!!actionModalType}
          onClose={() => setActionModalType(null)}
          actionType={actionModalType}
          onSuccess={handleActionModalSubmit}
          agencies={agencies}
          managers={managers}
        />
      )}

    </div>
  );
};
