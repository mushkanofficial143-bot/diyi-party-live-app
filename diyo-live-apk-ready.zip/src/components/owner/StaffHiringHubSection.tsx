/**
 * DIYO LIVE - Official Role Hierarchy & Subordinate Management Hub
 * Connects directly to real backend hierarchy endpoints:
 * - /api/hierarchy/tree
 * - /api/hierarchy/roles-matrix
 * - /api/hierarchy/hire
 * - /api/hierarchy/remove
 * - /api/hierarchy/change-role
 * - /api/hierarchy/super-admin/distribute-frame
 * - /api/hierarchy/ban-unban
 * - /api/hierarchy/audit
 *
 * Enforces:
 * 1. 8 Official Roles: OWNER > MANAGER > SUPER ADMIN > BD ADMIN > AGENCY > COIN SELLER > HOST > USER
 * 2. Automatic Reporting Line Visibility: Whoever hires a subordinate automatically sees them and all downstream sub-accounts.
 * 3. Branch Isolation: Higher-level users may manage users only within their authorized reporting line.
 * 4. Role-Specific Hiring Permissions: Only authorized roles can hire specific subordinates.
 * 5. Super Admin Frame Restrictions: Super Admin can distribute Frames 1-5 only.
 * 6. User search by 7-digit ID with pre-hiring profile inspection card.
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  UserCheck,
  UserX,
  ShieldCheck,
  Crown,
  Briefcase,
  Building2,
  Coins,
  Sparkles,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  ShieldAlert,
  Sliders,
  Filter,
  Users,
  Radio,
  User,
  ChevronRight,
  Eye,
  Lock,
  Unlock,
  X,
  Pin,
  GitBranch,
  Key,
  Activity,
  Layers,
  Ban,
  Shield,
  Award
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

export interface PersistentHiringGuardState {
  active: boolean;
  isGuarded: boolean; // lock toggle to prevent accidental dismissal
  userId: string;
  name: string;
  username: string;
  avatar?: string;
  role: string;
  roleTag: string;
  operatorId: string;
  operatorName: string;
  operatorRole: string;
  hiredAt: string;
  hierarchyPath?: string;
  actionType: 'HIRE_NEW' | 'ASSIGN_ROLE';
  coinsAllocated?: number;
}

export type OfficialHierarchyRole =
  | 'OWNER'
  | 'MANAGER'
  | 'OFFICIAL'
  | 'SUPER ADMIN'
  | 'ADMIN'
  | 'BD ADMIN'
  | 'AGENCY'
  | 'COIN SELLER'
  | 'HOST'
  | 'USER';

export interface HierarchySubordinate {
  id: string;
  userId: string;
  name: string;
  username: string;
  avatar: string;
  role: OfficialHierarchyRole;
  roleTag: string;
  hiredByUserId: string;
  hiredByName: string;
  hiredByRole: string;
  parentUserId: string;
  parentRole: string;
  hierarchyPath: string;
  assignedAt: string;
  assignedBy: string;
  roleStatus: 'Active' | 'Removed' | 'Banned';
  activeStatus: 'ACTIVE' | 'SUSPENDED' | 'BANNED';
  permissions: string[];
  notes?: string;
}

export interface HierarchyAuditItem {
  id: string;
  timestamp: string;
  action: string;
  operatorId: string;
  operatorRole: string;
  targetUserId: string;
  targetRole?: string;
  details: string;
  status: 'SUCCESS' | 'DENIED' | 'FAILED';
}

export interface DemoOperator {
  id: string;
  name: string;
  username: string;
  role: OfficialHierarchyRole;
  avatar: string;
  tag: string;
}

export const DEMO_OPERATORS: DemoOperator[] = [
  {
    id: '0000001',
    name: 'Salam Star Owner',
    username: 'salamstar_owner',
    role: 'OWNER',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    tag: 'Master Owner (Supreme Platform Authority)'
  }
];

export const ROLE_BADGE_STYLES: Record<OfficialHierarchyRole, {
  color: string;
  bg: string;
  border: string;
  icon: any;
  rank: number;
  description: string;
}> = {
  'OWNER': {
    color: 'text-amber-400',
    bg: 'bg-amber-500/20 text-amber-300',
    border: 'border-amber-500/50',
    icon: Crown,
    rank: 1,
    description: 'Absolute platform authority. Access all panels, full hiring, unrestricted permissions, global unban.'
  },
  'MANAGER': {
    color: 'text-blue-400',
    bg: 'bg-blue-500/20 text-blue-300',
    border: 'border-blue-500/50',
    icon: Briefcase,
    rank: 2,
    description: 'Reports to Owner. Manages downstream Super Admins, BD Admins, Agencies, Coin Sellers, and Hosts in their branch.'
  },
  'OFFICIAL': {
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/20 text-yellow-300',
    border: 'border-yellow-500/50',
    icon: Shield,
    rank: 3,
    description: 'Official Platform Staff. Holds official verification tag, unrestricted Video & Party live broadcast rights, and official staff panel.'
  },
  'SUPER ADMIN': {
    color: 'text-rose-400',
    bg: 'bg-rose-500/20 text-rose-300',
    border: 'border-rose-500/50',
    icon: ShieldCheck,
    rank: 4,
    description: 'Enforcement & moderation. Hires BD Admins, Agencies, Hosts. Distributes Frames 1-5 only. Moderates live streams.'
  },
  'ADMIN': {
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/20 text-indigo-300',
    border: 'border-indigo-500/50',
    icon: Shield,
    rank: 5,
    description: 'Official Administrator. Moderates live rooms, monitors global live streams, and accesses admin management tools.'
  },
  'BD ADMIN': {
    color: 'text-purple-400',
    bg: 'bg-purple-500/20 text-purple-300',
    border: 'border-purple-500/50',
    icon: Building2,
    rank: 6,
    description: 'Business development executive. Onboards partner agency guilds and recruits broadcasting hosts.'
  },
  'AGENCY': {
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/20 text-cyan-300',
    border: 'border-cyan-500/50',
    icon: Users,
    rank: 5,
    description: 'Guild leader managing contracted hosts. Reviews streaming performance, live-time rewards, and commission records.'
  },
  'COIN SELLER': {
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/20 text-emerald-300',
    border: 'border-emerald-500/50',
    icon: Coins,
    rank: 6,
    description: 'Authorized virtual coin vendor. Searches users and executes coin recharges. Cannot hire subordinates.'
  },
  'HOST': {
    color: 'text-pink-400',
    bg: 'bg-pink-500/20 text-pink-300',
    border: 'border-pink-500/50',
    icon: Radio,
    rank: 7,
    description: 'Verified broadcaster. Runs Video Live and Party Live streams. Receives 70K Coins for 2 continuous live hours.'
  },
  'USER': {
    color: 'text-neutral-400',
    bg: 'bg-neutral-800 text-neutral-300',
    border: 'border-neutral-700',
    icon: User,
    rank: 8,
    description: 'Standard viewer account. Watches streams, sends gifts, participates in chat and games.'
  }
};

interface StaffHiringHubSectionProps {
  currentUser?: any;
  currentRole?: string;
  onHireCoinSeller?: (data: any) => Promise<boolean>;
  onHireAdmin?: (data: any) => Promise<boolean>;
  onHireManager?: (data: any) => Promise<boolean>;
  onHireAgency?: (data: any) => Promise<boolean>;
  onHireBD?: (data: any) => Promise<boolean>;
}

export const StaffHiringHubSection: React.FC<StaffHiringHubSectionProps> = ({
  currentUser,
  currentRole
}) => {
  // Active Operator Context for Multi-Role Hierarchy Testing
  const [activeOperator, setActiveOperator] = useState<DemoOperator>(
    DEMO_OPERATORS.find(o => o.id === currentUser?.id) || DEMO_OPERATORS[0]
  );

  // Active View Tab: 'TREE' | 'HIRE' | 'FRAMES' | 'PERMISSIONS' | 'AUDIT'
  const [activeTab, setActiveTab] = useState<'TREE' | 'HIRE' | 'FRAMES' | 'PERMISSIONS' | 'AUDIT'>('TREE');

  // Hierarchy Data from Backend
  const [subordinates, setSubordinates] = useState<HierarchySubordinate[]>([]);
  const [directCount, setDirectCount] = useState<number>(0);
  const [descendantCount, setDescendantCount] = useState<number>(0);
  const [allowedHiringRoles, setAllowedHiringRoles] = useState<string[]>([]);
  const [isLoadingHierarchy, setIsLoadingHierarchy] = useState(false);

  // Roles Matrix from Backend
  const [rolesMatrix, setRolesMatrix] = useState<any>(null);

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<HierarchyAuditItem[]>([]);
  const [isLoadingAudit, setIsLoadingAudit] = useState(false);

  // Search User by 7-digit ID for Hiring
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchedUser, setSearchedUser] = useState<any | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Role to Assign in Hire Tab
  const [selectedRoleToAssign, setSelectedRoleToAssign] = useState<string>('MANAGER');
  const [isHiring, setIsHiring] = useState(false);

  // Real Staff Hiring Form State (Real 7-digit ID Generation)
  const [hiringMode, setHiringMode] = useState<'NEW_STAFF' | 'EXISTING_USER'>('NEW_STAFF');
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffUsername, setNewStaffUsername] = useState('');
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [newStaffPhone, setNewStaffPhone] = useState('');
  const [newStaffCoins, setNewStaffCoins] = useState('100000');
  const [newStaffNotes, setNewStaffNotes] = useState('');
  const [lastHiredResult, setLastHiredResult] = useState<any | null>(null);

  // Persistent State Guard for Hiring Hub (Ensures status remains active & visible until manually toggled off)
  const [persistentHiringGuard, setPersistentHiringGuard] = useState<PersistentHiringGuardState | null>(() => {
    try {
      const saved = localStorage.getItem('diyo_hiring_guard_state');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const updatePersistentGuard = (state: PersistentHiringGuardState | null) => {
    setPersistentHiringGuard(state);
    try {
      if (state) {
        localStorage.setItem('diyo_hiring_guard_state', JSON.stringify(state));
      } else {
        localStorage.removeItem('diyo_hiring_guard_state');
      }
    } catch {}
  };

  // Dynamic Available Operators (Master Owner + Real Hired Subordinates with Authority)
  const availableOperators: DemoOperator[] = useMemo(() => {
    const list: DemoOperator[] = [...DEMO_OPERATORS];
    subordinates.forEach(s => {
      if (['MANAGER', 'SUPER ADMIN', 'BD ADMIN', 'AGENCY'].includes(s.role)) {
        if (!list.some(o => o.id === s.userId)) {
          list.push({
            id: s.userId,
            name: s.name,
            username: s.username,
            role: s.role as OfficialHierarchyRole,
            avatar: s.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
            tag: `${s.role} (#${s.userId})`
          });
        }
      }
    });
    return list;
  }, [subordinates]);

  // Super Admin Frame Distribution Tool
  const [selectedTargetUserForFrame, setSelectedTargetUserForFrame] = useState<string>('');
  const [selectedFrameId, setSelectedFrameId] = useState<string>('1');
  const [isDistributingFrame, setIsDistributingFrame] = useState(false);

  // Change Role Modal
  const [changeRoleTarget, setChangeRoleTarget] = useState<HierarchySubordinate | null>(null);
  const [newSelectedRole, setNewSelectedRole] = useState<string>('HOST');
  const [isChangingRole, setIsChangingRole] = useState(false);

  // Feedback Notifications
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const [actionErrorMsg, setActionErrorMsg] = useState<string | null>(null);

  // Filter & Search in Subordinates List
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [listSearch, setListSearch] = useState<string>('');

  const showSuccess = (msg: string) => {
    playSoundFX('win');
    setActionSuccessMsg(msg);
    setActionErrorMsg(null);
    setTimeout(() => setActionSuccessMsg(null), 6000);
  };

  const showError = (msg: string) => {
    playSoundFX('alert');
    setActionErrorMsg(msg);
    setActionSuccessMsg(null);
    setTimeout(() => setActionErrorMsg(null), 6000);
  };

  // 1. Fetch Hierarchy Tree for Active Operator
  const fetchHierarchyTree = async (operatorId: string) => {
    setIsLoadingHierarchy(true);
    try {
      const res = await fetch(`/api/hierarchy/tree?operatorId=${operatorId}`);
      const data = await res.json();
      if (data.success) {
        setSubordinates(data.subordinates || []);
        setDirectCount(data.directCount || 0);
        setDescendantCount(data.descendantCount || 0);
        setAllowedHiringRoles(data.allowedHiringRoles || []);

        // Default the selected role to assign to the first allowed role
        if (data.allowedHiringRoles && data.allowedHiringRoles.length > 0) {
          setSelectedRoleToAssign(data.allowedHiringRoles[0]);
        }
      }
    } catch (err) {
      console.error('Failed to fetch hierarchy tree:', err);
    } finally {
      setIsLoadingHierarchy(false);
    }
  };

  // 2. Fetch Roles Matrix
  const fetchRolesMatrix = async () => {
    try {
      const res = await fetch('/api/hierarchy/roles-matrix');
      const data = await res.json();
      if (data.success) {
        setRolesMatrix(data);
      }
    } catch (err) {
      console.error('Failed to fetch roles matrix:', err);
    }
  };

  // 3. Fetch Audit Logs
  const fetchAuditLogs = async () => {
    setIsLoadingAudit(true);
    try {
      const res = await fetch('/api/hierarchy/audit');
      const data = await res.json();
      if (data.success && data.logs) {
        setAuditLogs(data.logs);
      }
    } catch (err) {
      console.error('Failed to fetch hierarchy audit:', err);
    } finally {
      setIsLoadingAudit(false);
    }
  };

  // Initial and operator change effect
  useEffect(() => {
    fetchHierarchyTree(activeOperator.id);
    fetchRolesMatrix();
    fetchAuditLogs();
  }, [activeOperator.id]);

  // Handle Switch Operator
  const handleSelectOperator = (op: DemoOperator) => {
    playSoundFX('click');
    setActiveOperator(op);
    setSearchedUser(null);
    setSearchError(null);
  };

  // 4. Search user by 7-digit ID for hiring
  const handleSearchUser = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setSearchError(null);
    setSearchedUser(null);
    playSoundFX('click');

    try {
      const rawDigits = searchQuery.trim().replace(/\D/g, '');
      const numVal = parseInt(rawDigits, 10);
      if (!isNaN(numVal) && numVal >= 2 && numVal <= 10) {
        setSearchError(`User IDs 0000002 to 0000010 have been permanently deleted. Please use ID 0000001 (Owner) or new sequential IDs >= 0000014.`);
        return;
      }

      const res = await fetch(`/api/users/search?q=${encodeURIComponent(searchQuery.trim())}`);
      const data = await res.json();

      if (data.success && data.users && data.users.length > 0) {
        setSearchedUser(data.users[0]);
        playSoundFX('notification');
      } else {
        setSearchError(`No real user found for "${searchQuery}". A hiring action can only target an existing database user. Use the New Staff form to create a new account.`);
      }
    } catch (err) {
      console.error('User search failed:', err);
      setSearchError('User search failed. Please check the connection and try again.');
    } finally {
      setIsSearching(false);
    }
  };

  // 4.5. Hire Real Staff with Newly Generated 7-Digit ID
  const handleHireNewStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffName.trim() || !newStaffUsername.trim()) {
      showError('Staff Full Name and Desired Username are required.');
      return;
    }

    setIsHiring(true);
    playSoundFX('coin');

    try {
      const res = await fetch('/api/hierarchy/hire', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-operator-id': activeOperator.id,
          'x-role': activeOperator.role
        },
        body: JSON.stringify({
          operatorId: activeOperator.id,
          operatorRole: activeOperator.role,
          targetUserId: 'NEW',
          isNewAccount: true,
          autoGenerateId: true,
          targetName: newStaffName.trim(),
          targetUsername: newStaffUsername.trim().toLowerCase().replace(/[^a-z0-9_]/g, ''),
          email: newStaffEmail.trim() || `${newStaffUsername.trim().toLowerCase()}@diyolive.io`,
          phone: newStaffPhone.trim(),
          role: selectedRoleToAssign,
          allocation: newStaffCoins,
          notes: newStaffNotes.trim() || `Officially hired as ${selectedRoleToAssign} under ${activeOperator.name}`
        })
      });

      const data = await res.json();
      if (!data.success) {
        showError(data.error || 'Real staff hiring failed.');
      } else {
        const assignedId = data.newUserId || data.user?.id || data.relationship?.userId;
        const hiredTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        
        const guardState: PersistentHiringGuardState = {
          active: true,
          isGuarded: true,
          userId: assignedId,
          name: data.user?.name || newStaffName,
          username: data.user?.username || newStaffUsername,
          avatar: data.user?.avatar,
          role: selectedRoleToAssign,
          roleTag: data.relationship?.roleTag || selectedRoleToAssign,
          operatorId: activeOperator.id,
          operatorName: activeOperator.name,
          operatorRole: activeOperator.role,
          hiredAt: hiredTimeStr,
          hierarchyPath: data.relationship?.hierarchyPath || `${activeOperator.id}/${assignedId}`,
          actionType: 'HIRE_NEW',
          coinsAllocated: Number(newStaffCoins) || 100000
        };
        updatePersistentGuard(guardState);

        setLastHiredResult({
          userId: assignedId,
          name: data.user?.name || newStaffName,
          username: data.user?.username || newStaffUsername,
          role: selectedRoleToAssign,
          roleTag: data.relationship?.roleTag || selectedRoleToAssign,
          hiredAt: hiredTimeStr
        });

        showSuccess(`🎉 Success! Real Staff #${assignedId} (${newStaffName}) hired as ${selectedRoleToAssign}! Panel & permissions activated.`);
        window.dispatchEvent(new CustomEvent('diyo_role_updated', {
          detail: { userId: assignedId, newRole: selectedRoleToAssign }
        }));
        setNewStaffName('');
        setNewStaffUsername('');
        setNewStaffEmail('');
        setNewStaffPhone('');
        setNewStaffNotes('');
        await fetchHierarchyTree(activeOperator.id);
        await fetchAuditLogs();
      }
    } catch (err) {
      showError('Network error during staff hiring.');
    } finally {
      setIsHiring(false);
    }
  };

  // 5. Hire Subordinate
  const handleHireSubordinate = async () => {
    if (!searchedUser) return;
    setIsHiring(true);
    playSoundFX('coin');

    try {
      const res = await fetch('/api/hierarchy/hire', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-operator-id': activeOperator.id,
          'x-role': activeOperator.role
        },
        body: JSON.stringify({
          operatorId: activeOperator.id,
          targetUserId: searchedUser.id,
          targetName: searchedUser.name,
          targetUsername: searchedUser.username,
          isNewAccount: Boolean((searchedUser as any).isNewCandidate),
          role: selectedRoleToAssign
        })
      });

      const data = await res.json();
      if (!data.success) {
        showError(data.error || 'Hiring failed.');
      } else {
        const assignedId = data.relationship?.userId || searchedUser.id;
        const hiredTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

        showSuccess(data.message || `Successfully hired ${searchedUser.name} as ${selectedRoleToAssign}!`);
        // Notify live app state
        window.dispatchEvent(new CustomEvent('diyo_role_updated', {
          detail: { userId: assignedId, newRole: selectedRoleToAssign }
        }));

        // PERSISTENT GUARD: Retain and lock hiring status (prevents accidental UI dismissal)
        const guardState: PersistentHiringGuardState = {
          active: true,
          isGuarded: true,
          userId: assignedId,
          name: searchedUser.name,
          username: searchedUser.username,
          avatar: searchedUser.avatar,
          role: selectedRoleToAssign,
          roleTag: data.relationship?.roleTag || selectedRoleToAssign,
          operatorId: activeOperator.id,
          operatorName: activeOperator.name,
          operatorRole: activeOperator.role,
          hiredAt: hiredTimeStr,
          hierarchyPath: data.relationship?.hierarchyPath || `${activeOperator.id}/${assignedId}`,
          actionType: 'ASSIGN_ROLE'
        };
        updatePersistentGuard(guardState);

        // DO NOT dismiss or clear searchedUser! Retain the candidate card with official role badge
        setSearchedUser((prev: any) => prev ? {
          ...prev,
          id: assignedId,
          role: selectedRoleToAssign,
          roleTag: selectedRoleToAssign,
          roleStatus: 'Active',
          isHired: true,
          hiredRole: selectedRoleToAssign,
          hiredBy: activeOperator.name,
          hiredAt: hiredTimeStr
        } : null);

        await fetchHierarchyTree(activeOperator.id);
        await fetchAuditLogs();
      }
    } catch (err) {
      showError('Network error while assigning subordinate role.');
    } finally {
      setIsHiring(false);
    }
  };

  // 6. Remove Subordinate Role
  const handleRemoveSubordinate = async (targetUserId: string, targetName: string) => {
    if (!confirm(`Are you sure you want to REMOVE role from #${targetUserId} (${targetName})?\nThis will disconnect them from your reporting tree and reset them to normal USER.`)) {
      return;
    }

    playSoundFX('click');
    try {
      const res = await fetch('/api/hierarchy/remove', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-operator-id': activeOperator.id,
          'x-role': activeOperator.role
        },
        body: JSON.stringify({
          operatorId: activeOperator.id,
          targetUserId
        })
      });

      const data = await res.json();
      if (!data.success) {
        showError(data.error || 'Failed to remove subordinate.');
      } else {
        showSuccess(data.message);
        window.dispatchEvent(new CustomEvent('diyo_role_updated', {
          detail: { userId: targetUserId, newRole: 'USER' }
        }));
        await fetchHierarchyTree(activeOperator.id);
        await fetchAuditLogs();
      }
    } catch (err) {
      showError('Network error removing subordinate.');
    }
  };

  // 7. Change Role Submit
  const handleChangeRoleSubmit = async () => {
    if (!changeRoleTarget) return;
    setIsChangingRole(true);
    playSoundFX('coin');

    try {
      const res = await fetch('/api/hierarchy/change-role', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-operator-id': activeOperator.id,
          'x-role': activeOperator.role
        },
        body: JSON.stringify({
          operatorId: activeOperator.id,
          targetUserId: changeRoleTarget.userId,
          newRole: newSelectedRole
        })
      });

      const data = await res.json();
      if (!data.success) {
        showError(data.error || 'Failed to change role.');
      } else {
        showSuccess(data.message);
        window.dispatchEvent(new CustomEvent('diyo_role_updated', {
          detail: { userId: changeRoleTarget.userId, newRole: newSelectedRole }
        }));

        // PERSISTENT GUARD: Retain and lock role assignment status (prevents accidental UI dismissal)
        const hiredTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const guardState: PersistentHiringGuardState = {
          active: true,
          isGuarded: true,
          userId: changeRoleTarget.userId,
          name: changeRoleTarget.name,
          username: changeRoleTarget.username,
          avatar: changeRoleTarget.avatar,
          role: newSelectedRole,
          roleTag: newSelectedRole,
          operatorId: activeOperator.id,
          operatorName: activeOperator.name,
          operatorRole: activeOperator.role,
          hiredAt: hiredTimeStr,
          hierarchyPath: changeRoleTarget.hierarchyPath || `${activeOperator.id}/${changeRoleTarget.userId}`,
          actionType: 'ASSIGN_ROLE'
        };
        updatePersistentGuard(guardState);

        setChangeRoleTarget(null);
        await fetchHierarchyTree(activeOperator.id);
        await fetchAuditLogs();
      }
    } catch (err) {
      showError('Network error updating subordinate role.');
    } finally {
      setIsChangingRole(false);
    }
  };

  // 8. Distribute Frame (Super Admin / Owner)
  const handleDistributeFrame = async (frameIdToDistribute?: string) => {
    const frameId = frameIdToDistribute || selectedFrameId;
    const targetUserId = selectedTargetUserForFrame || (subordinates.length > 0 ? subordinates[0].userId : '');

    if (!targetUserId) {
      showError('Please select a subordinate account in your branch to equip the frame.');
      return;
    }

    setIsDistributingFrame(true);
    playSoundFX('click');

    try {
      const res = await fetch('/api/hierarchy/super-admin/distribute-frame', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-operator-id': activeOperator.id,
          'x-role': activeOperator.role
        },
        body: JSON.stringify({
          operatorId: activeOperator.id,
          targetUserId,
          frameId
        })
      });

      const data = await res.json();
      if (!data.success) {
        showError(data.error || 'Frame distribution rejected.');
      } else {
        showSuccess(data.message);
        await fetchHierarchyTree(activeOperator.id);
        await fetchAuditLogs();
      }
    } catch (err) {
      showError('Network error during frame distribution.');
    } finally {
      setIsDistributingFrame(false);
    }
  };

  // 9. Moderate Subordinate (Ban / Unban)
  const handleModerateSubordinate = async (targetUserId: string, action: 'BAN' | 'UNBAN') => {
    playSoundFX('click');
    try {
      const res = await fetch('/api/hierarchy/ban-unban', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-operator-id': activeOperator.id,
          'x-role': activeOperator.role
        },
        body: JSON.stringify({
          operatorId: activeOperator.id,
          targetUserId,
          action,
          reason: `Action executed by ${activeOperator.role} #${activeOperator.id}`
        })
      });

      const data = await res.json();
      if (!data.success) {
        showError(data.error || 'Moderation action rejected.');
      } else {
        showSuccess(data.message);
        await fetchHierarchyTree(activeOperator.id);
        await fetchAuditLogs();
      }
    } catch (err) {
      showError('Network error during moderation action.');
    }
  };

  // Filter subordinates list
  const filteredSubordinates = subordinates.filter(sub => {
    if (roleFilter !== 'ALL' && sub.role !== roleFilter) return false;
    if (listSearch.trim()) {
      const q = listSearch.toLowerCase();
      return (
        sub.userId.includes(q) ||
        sub.name.toLowerCase().includes(q) ||
        sub.username.toLowerCase().includes(q) ||
        sub.role.toLowerCase().includes(q) ||
        (sub.hiredByName && sub.hiredByName.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const canActiveOperatorHire = allowedHiringRoles.length > 0;
  const isSuperAdminOrOwner = activeOperator.role === 'SUPER ADMIN' || activeOperator.role === 'OWNER';

  return (
    <div id="hierarchy-management-hub" className="space-y-6 select-none animate-in fade-in">

      {/* ========================================================================= */}
      {/* 1. OPERATOR PERSPECTIVE SIMULATOR & CURRENT OPERATOR CONTEXT BAR           */}
      {/* ========================================================================= */}
      <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-2xl space-y-4">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-3 border-b border-neutral-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
                <GitBranch className="w-5 h-5" />
              </span>
              <div>
                <h2 className="text-base font-black text-white font-['Outfit'] uppercase tracking-wider flex items-center gap-2">
                  <span>DIYO LIVE Role Hierarchy & Reporting Architecture</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    REAL BACKEND CONNECTED
                  </span>
                </h2>
                <p className="text-xs text-neutral-400">
                  Switch operating persona below to verify branch isolation, automatic subordinate visibility, and strict hiring matrix permissions.
                </p>
              </div>
            </div>
          </div>

          {/* Active Operator Status Card */}
          <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-neutral-950 border border-neutral-800">
            <img
              src={activeOperator.avatar}
              alt=""
              className="w-10 h-10 rounded-xl object-cover ring-1 ring-cyan-500/50"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-white">{activeOperator.name}</span>
                <span className="text-[10px] font-mono text-cyan-400 font-bold">#{activeOperator.id}</span>
              </div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border ${ROLE_BADGE_STYLES[activeOperator.role].bg} ${ROLE_BADGE_STYLES[activeOperator.role].border}`}>
                  {activeOperator.role}
                </span>
                <span className="text-[10px] text-neutral-500">
                  Rank #{ROLE_BADGE_STYLES[activeOperator.role].rank}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Persona Selector Buttons */}
        <div>
          <div className="flex items-center justify-between text-[11px] font-bold text-neutral-400 mb-2">
            <span>Choose Acting Operator Account:</span>
            <span className="text-neutral-500 text-[10px]">Changes filter view and backend authorization headers</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-8 gap-2">
            {availableOperators.map((op) => {
              const isSelected = activeOperator.id === op.id;
              const roleCfg = ROLE_BADGE_STYLES[op.role] || ROLE_BADGE_STYLES['OWNER'];
              return (
                <button
                  key={op.id}
                  onClick={() => handleSelectOperator(op)}
                  className={`p-2 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-neutral-800 border-amber-400 ring-2 ring-amber-400/20 shadow-lg scale-102'
                      : 'bg-neutral-950/70 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900 opacity-80 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-[9px] font-black uppercase ${roleCfg.color}`}>
                      {op.role}
                    </span>
                    {isSelected && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />}
                  </div>
                  <div className="text-xs font-bold text-white truncate mt-1">{op.name.split(' ')[0]}</div>
                  <div className="text-[9px] font-mono text-neutral-500">#{op.id}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Visibility Metrics & Security Indicators */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
            <div>
              <div className="text-[10px] uppercase font-bold text-neutral-400">Total Visible Subordinates</div>
              <div className="text-xl font-black text-white font-mono mt-0.5">
                {subordinates.length} Accounts
              </div>
              <div className="text-[10px] text-neutral-500">
                {directCount} Direct Reports · {descendantCount} Downstream
              </div>
            </div>
            <Users className="w-6 h-6 text-cyan-400 opacity-60" />
          </div>

          <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
            <div>
              <div className="text-[10px] uppercase font-bold text-neutral-400">Authorized Hiring Scope</div>
              <div className="text-xs font-black text-amber-300 mt-1 truncate max-w-[200px]">
                {canActiveOperatorHire ? allowedHiringRoles.join(', ') : 'No Hiring Authority'}
              </div>
              <div className="text-[10px] text-neutral-500">
                {canActiveOperatorHire ? 'Can provision subordinates' : 'Requires higher manager'}
              </div>
            </div>
            <UserCheck className="w-6 h-6 text-amber-400 opacity-60" />
          </div>

          <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
            <div>
              <div className="text-[10px] uppercase font-bold text-neutral-400">Branch Isolation Status</div>
              <div className="text-xs font-black text-emerald-400 mt-1">
                {activeOperator.role === 'OWNER' ? 'Master (All Platform)' : 'Strict Hierarchy Isolation'}
              </div>
              <div className="text-[10px] text-neutral-500">
                {activeOperator.role === 'OWNER' ? 'Full global oversight' : 'Cannot see other branches'}
              </div>
            </div>
            <Shield className="w-6 h-6 text-emerald-400 opacity-60" />
          </div>
        </div>
      </div>

      {/* FEEDBACK BANNERS */}
      {actionSuccessMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2.5 shadow-lg animate-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span className="font-semibold">{actionSuccessMsg}</span>
        </div>
      )}

      {actionErrorMsg && (
        <div className="p-3.5 rounded-2xl bg-rose-500/20 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2.5 shadow-lg animate-in slide-in-from-top-2">
          <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
          <span className="font-semibold">{actionErrorMsg}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. NAVIGATION TABS                                                        */}
      {/* ========================================================================= */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2 overflow-x-auto">
        <button
          onClick={() => { playSoundFX('click'); setActiveTab('TREE'); }}
          className={`px-4 py-2 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'TREE'
              ? 'bg-amber-500 text-neutral-950 shadow-lg shadow-amber-500/20'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-850'
          }`}
        >
          <GitBranch className="w-4 h-4" />
          <span>Reporting Tree & Roster ({subordinates.length})</span>
        </button>

        <button
          onClick={() => { playSoundFX('click'); setActiveTab('HIRE'); }}
          className={`px-4 py-2 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'HIRE'
              ? 'bg-amber-500 text-neutral-950 shadow-lg shadow-amber-500/20'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-850'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>Hire / Assign Subordinate</span>
        </button>

        <button
          onClick={() => { playSoundFX('click'); setActiveTab('FRAMES'); }}
          className={`px-4 py-2 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'FRAMES'
              ? 'bg-amber-500 text-neutral-950 shadow-lg shadow-amber-500/20'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-850'
          }`}
        >
          <Crown className="w-4 h-4" />
          <span>Super Admin Frame Distribution (1-5)</span>
        </button>

        <button
          onClick={() => { playSoundFX('click'); setActiveTab('PERMISSIONS'); }}
          className={`px-4 py-2 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'PERMISSIONS'
              ? 'bg-amber-500 text-neutral-950 shadow-lg shadow-amber-500/20'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-850'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>Role Permissions Matrix</span>
        </button>

        <button
          onClick={() => { playSoundFX('click'); setActiveTab('AUDIT'); }}
          className={`px-4 py-2 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'AUDIT'
              ? 'bg-amber-500 text-neutral-950 shadow-lg shadow-amber-500/20'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-850'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Hierarchy Audit Ledger ({auditLogs.length})</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: REPORTING TREE & SUBORDINATES ROSTER                                */}
      {/* ========================================================================= */}
      {activeTab === 'TREE' && (
        <div className="space-y-4 animate-in fade-in">
          {/* Header & Controls */}
          <div className="p-5 rounded-3xl bg-neutral-900/80 border border-neutral-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-400" />
                <span>Authorized Downstream Subordinates for {activeOperator.name}</span>
              </h3>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                "Whoever hires a subordinate automatically sees that subordinate and all downstream sub-accounts created below them."
              </p>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:w-56">
                <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter subordinates..."
                  value={listSearch}
                  onChange={(e) => setListSearch(e.target.value)}
                  className="w-full h-8.5 bg-neutral-950 border border-neutral-800 rounded-xl pl-9 pr-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-cyan-500 transition-all"
                />
              </div>

              <button
                onClick={() => fetchHierarchyTree(activeOperator.id)}
                disabled={isLoadingHierarchy}
                className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-all cursor-pointer"
                title="Refresh Subordinates Tree"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingHierarchy ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {/* Subordinates Roster Table / Card Grid */}
          {filteredSubordinates.length === 0 ? (
            <div className="p-8 text-center rounded-3xl bg-neutral-900/60 border border-neutral-800 space-y-2">
              <UserX className="w-8 h-8 text-neutral-500 mx-auto" />
              <div className="text-sm font-bold text-white">No subordinates found in this reporting line.</div>
              <p className="text-xs text-neutral-400 max-w-md mx-auto">
                {activeOperator.role === 'COIN SELLER' || activeOperator.role === 'HOST' || activeOperator.role === 'USER'
                  ? `Role "${activeOperator.role}" is not authorized to hold or hire subordinates.`
                  : `No accounts have been provisioned under ${activeOperator.name}'s hierarchy branch yet. Click "Hire / Assign Subordinate" to create reporting lines.`}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredSubordinates.map((sub) => {
                const roleCfg = ROLE_BADGE_STYLES[sub.role];
                const isDirect = sub.parentUserId === activeOperator.id || sub.hiredByUserId === activeOperator.id;

                return (
                  <div
                    key={sub.id || sub.userId}
                    className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-cyan-500/40 transition-all space-y-3 shadow-lg"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={sub.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                          alt=""
                          className="w-12 h-12 rounded-xl object-cover ring-2 ring-neutral-800 shadow"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-black text-white">{sub.name}</span>
                            <span className="text-[10px] font-mono text-cyan-400 font-bold">#{sub.userId}</span>
                          </div>
                          <div className="text-xs text-neutral-400">@{sub.username}</div>
                          <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border ${roleCfg.bg} ${roleCfg.border}`}>
                              {sub.role}
                            </span>
                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${isDirect ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-neutral-800 text-neutral-400'}`}>
                              {isDirect ? 'Direct Report' : 'Downstream Sub-Account'}
                            </span>
                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${sub.roleStatus === 'Active' ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                              {sub.roleStatus}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Rank tag */}
                      <span className="text-[10px] font-mono font-bold text-neutral-500">
                        Tier #{roleCfg.rank}
                      </span>
                    </div>

                    {/* Hierarchy Path Visualizer */}
                    <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800/80 text-[10px] font-mono space-y-1">
                      <div className="flex items-center justify-between text-neutral-400">
                        <span>Hierarchy Lineage Path:</span>
                        <span className="text-cyan-400 truncate max-w-[200px]">{sub.hierarchyPath}</span>
                      </div>
                      <div className="flex items-center justify-between text-neutral-500">
                        <span>Hired By:</span>
                        <span className="text-white font-bold">{sub.hiredByName} (#{sub.hiredByUserId})</span>
                      </div>
                    </div>

                    {/* Permissions summary */}
                    <div className="flex items-center gap-1 flex-wrap">
                      <span className="text-[9px] font-bold text-neutral-500 mr-1">Perms:</span>
                      {sub.permissions.slice(0, 3).map(p => (
                        <span key={p} className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-neutral-950 text-cyan-300 border border-cyan-500/20">
                          {p}
                        </span>
                      ))}
                      {sub.permissions.length > 3 && (
                        <span className="text-[8px] font-mono text-neutral-500">
                          +{sub.permissions.length - 3} more
                        </span>
                      )}
                    </div>

                    {/* Subordinate Management Actions */}
                    <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-end gap-2 flex-wrap">
                      {/* Frame Distribution Button (for Super Admin / Owner) */}
                      {isSuperAdminOrOwner && (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedTargetUserForFrame(sub.userId);
                            setActiveTab('FRAMES');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all"
                        >
                          <Crown className="w-3 h-3" />
                          <span>Equip Frame</span>
                        </button>
                      )}

                      {/* Change Role Button */}
                      <button
                        type="button"
                        onClick={() => {
                          setChangeRoleTarget(sub);
                          setNewSelectedRole(sub.role);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all"
                      >
                        <Sliders className="w-3 h-3" />
                        <span>Change Role</span>
                      </button>

                      {/* Ban / Unban Toggle Button */}
                      {isSuperAdminOrOwner && (
                        sub.roleStatus === 'Banned' ? (
                          <button
                            type="button"
                            onClick={() => handleModerateSubordinate(sub.userId, 'UNBAN')}
                            className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <ShieldCheck className="w-3 h-3" />
                            <span>Unban</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleModerateSubordinate(sub.userId, 'BAN')}
                            className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <Ban className="w-3 h-3" />
                            <span>Ban</span>
                          </button>
                        )
                      )}

                      {/* Remove Subordinate Button */}
                      <button
                        type="button"
                        onClick={() => handleRemoveSubordinate(sub.userId, sub.name)}
                        className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all"
                      >
                        <UserX className="w-3 h-3" />
                        <span>Remove</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: HIRE / ASSIGN SUBORDINATE                                          */}
      {/* ========================================================================= */}
      {activeTab === 'HIRE' && (
        <div className="space-y-4 animate-in fade-in">
          {!canActiveOperatorHire ? (
            <div className="p-8 rounded-3xl bg-neutral-900/80 border border-rose-500/30 text-center space-y-3">
              <ShieldAlert className="w-10 h-10 text-rose-400 mx-auto" />
              <h3 className="text-base font-black text-white">HIRING RESTRICTION</h3>
              <p className="text-xs text-neutral-400 max-w-md mx-auto">
                Role <span className="text-rose-300 font-bold">{activeOperator.role}</span> is not authorized to hire subordinates. Under the official DIYO LIVE hierarchy architecture, only Owner, Manager, Super Admin, BD Admin, and Agency hold hiring authority.
              </p>
            </div>
          ) : (
            <div className="p-5 rounded-3xl bg-neutral-900/80 border border-neutral-800 space-y-5 shadow-xl">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-emerald-400" />
                    <span>Official Real Staff Hiring Hub (Under {activeOperator.name} - {activeOperator.role})</span>
                  </h3>
                  <p className="text-[11px] text-neutral-400 mt-0.5">
                    Generate brand new 7-digit IDs for real staff candidates or assign official roles to existing users.
                  </p>
                </div>

                {/* Mode Selector Tabs */}
                <div className="flex items-center p-1 rounded-2xl bg-neutral-950 border border-neutral-800">
                  <button
                    type="button"
                    onClick={() => {
                      playSoundFX('click');
                      setHiringMode('NEW_STAFF');
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                      hiringMode === 'NEW_STAFF'
                        ? 'bg-emerald-500 text-neutral-950 shadow-md shadow-emerald-950/60'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Issue New 7-Digit ID</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      playSoundFX('click');
                      setHiringMode('EXISTING_USER');
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                      hiringMode === 'EXISTING_USER'
                        ? 'bg-emerald-500 text-neutral-950 shadow-md shadow-emerald-950/60'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    <Search className="w-3.5 h-3.5" />
                    <span>Search Existing User</span>
                  </button>
                </div>
              </div>

              {/* Persistent State Guard Banner for Hiring Hub (Ensures status remains active & visible) */}
              {persistentHiringGuard && persistentHiringGuard.active && (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-neutral-950 via-emerald-950/40 to-neutral-950 border-2 border-emerald-500/60 shadow-2xl space-y-3 animate-in zoom-in-95">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-neutral-800/80 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-emerald-500 text-neutral-950 flex items-center justify-center font-black text-lg shadow-lg">
                        ✓
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                            <ShieldCheck className="w-4 h-4" />
                            <span>PERSISTENT HIRING GUARD ACTIVE</span>
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                            LOCKED ON SCREEN
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-400">
                          Official hiring status is guarded on screen to prevent accidental dismissal until you manually close it.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      <button
                        type="button"
                        onClick={() => {
                          playSoundFX('click');
                          updatePersistentGuard({
                            ...persistentHiringGuard,
                            isGuarded: !persistentHiringGuard.isGuarded
                          });
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
                          persistentHiringGuard.isGuarded
                            ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                            : 'bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-white'
                        }`}
                        title="Toggle persistent guard locking"
                      >
                        {persistentHiringGuard.isGuarded ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                        <span>{persistentHiringGuard.isGuarded ? 'Guard Locked' : 'Guard Unlocked'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          playSoundFX('click');
                          updatePersistentGuard(null);
                          setLastHiredResult(null);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-neutral-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                        title="Dismiss guard and hire next candidate"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Dismiss & Next</span>
                      </button>
                    </div>
                  </div>

                  {/* User Details & Reporting Path */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-1">
                    <div className="flex items-center gap-3.5">
                      <img
                        src={persistentHiringGuard.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                        alt=""
                        className="w-12 h-12 rounded-xl object-cover ring-2 ring-emerald-500 shadow"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-black text-white">{persistentHiringGuard.name}</span>
                          <span className="text-xs text-neutral-400 font-mono">@{persistentHiringGuard.username}</span>
                          <span className="text-xs font-mono font-black text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded-lg border border-cyan-500/30">
                            #{persistentHiringGuard.userId}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 mt-1 flex-wrap text-xs">
                          <span className="font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                            Role: {persistentHiringGuard.role}
                          </span>
                          <span className="text-neutral-400">
                            Hired By: <b className="text-white">{persistentHiringGuard.operatorName}</b> ({persistentHiringGuard.operatorRole})
                          </span>
                          <span className="text-neutral-500">•</span>
                          <span className="text-neutral-400">Time: <b className="text-neutral-200">{persistentHiringGuard.hiredAt}</b></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          playSoundFX('click');
                          setActiveTab('TREE');
                        }}
                        className="px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <GitBranch className="w-4 h-4" />
                        <span>View Tree</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          playSoundFX('click');
                          setActiveTab('SUBORDINATES');
                        }}
                        className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Users className="w-4 h-4" />
                        <span>Subordinates</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* MODE A: Issue New 7-Digit ID (Real Staff) */}
              {hiringMode === 'NEW_STAFF' && (
                <form onSubmit={handleHireNewStaff} className="space-y-4">
                  {/* Step 1: Role Selection */}
                  <div className="space-y-2">
                    <label className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Select Real Role to Assign (Authorized for {activeOperator.role}):</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                      {allowedHiringRoles.map((role) => {
                        const cfg = ROLE_BADGE_STYLES[role as OfficialHierarchyRole] || ROLE_BADGE_STYLES['USER'];
                        const Icon = cfg.icon;
                        const isSelected = selectedRoleToAssign === role;
                        return (
                          <button
                            key={role}
                            type="button"
                            onClick={() => {
                              playSoundFX('click');
                              setSelectedRoleToAssign(role);
                            }}
                            className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                              isSelected
                                ? `bg-neutral-800 border-emerald-400 shadow-md ${cfg.color} scale-102 ring-2 ring-emerald-400/20`
                                : 'bg-neutral-950/80 border-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-900'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <Icon className="w-4 h-4" />
                              {isSelected && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
                            </div>
                            <span className="text-xs font-black mt-2">{role}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step 2: Form Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="text-[11px] font-bold text-neutral-400 mb-1 block">
                        Real Candidate Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Ramesh Verma"
                        value={newStaffName}
                        onChange={(e) => setNewStaffName(e.target.value)}
                        className="w-full h-11 bg-neutral-950 border border-neutral-800 rounded-2xl px-3.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-emerald-500 transition-all font-sans"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-neutral-400 mb-1 block">
                        Unique Desired Username *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. ramesh_official"
                        value={newStaffUsername}
                        onChange={(e) => setNewStaffUsername(e.target.value)}
                        className="w-full h-11 bg-neutral-950 border border-neutral-800 rounded-2xl px-3.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-emerald-500 transition-all font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-neutral-400 mb-1 block">
                        Official Contact Email (Optional)
                      </label>
                      <input
                        type="email"
                        placeholder="e.g. ramesh@diyolive.io"
                        value={newStaffEmail}
                        onChange={(e) => setNewStaffEmail(e.target.value)}
                        className="w-full h-11 bg-neutral-950 border border-neutral-800 rounded-2xl px-3.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-emerald-500 transition-all font-sans"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-neutral-400 mb-1 block">
                        Initial Coins Allocation
                      </label>
                      <input
                        type="number"
                        placeholder="100000"
                        value={newStaffCoins}
                        onChange={(e) => setNewStaffCoins(e.target.value)}
                        className="w-full h-11 bg-neutral-950 border border-neutral-800 rounded-2xl px-3.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-emerald-500 transition-all font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-neutral-400 mb-1 block">
                      Administrative Notes / Branch Designation (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder={`Designated as ${selectedRoleToAssign} under reporting line of ${activeOperator.name}`}
                      value={newStaffNotes}
                      onChange={(e) => setNewStaffNotes(e.target.value)}
                      className="w-full h-10 bg-neutral-950 border border-neutral-800 rounded-2xl px-3.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-emerald-500 transition-all"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-neutral-800">
                    <div className="text-[11px] text-neutral-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Automatic sequential 7-digit ID will be generated upon hiring</span>
                    </div>

                    <button
                      type="submit"
                      disabled={isHiring || !newStaffName.trim() || !newStaffUsername.trim()}
                      className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-neutral-950 text-xs font-black flex items-center gap-2 shadow-xl shadow-emerald-950/60 transition-all cursor-pointer disabled:opacity-50"
                    >
                      {isHiring ? <RefreshCw className="w-4 h-4 animate-spin" /> : <UserCheck className="w-4 h-4" />}
                      <span>Issue 7-Digit ID & Officially Hire as {selectedRoleToAssign}</span>
                    </button>
                  </div>
                </form>
              )}

              {/* MODE B: Existing User Search & Assign */}
              {hiringMode === 'EXISTING_USER' && (
                <div className="space-y-4">
                  {/* Step 1: Search Form */}
                  <form onSubmit={handleSearchUser} className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Enter 7-Digit User ID (e.g. 0000001, 0000002) or username..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full h-11 bg-neutral-950 border border-neutral-800 rounded-2xl pl-10 pr-4 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-all font-mono"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={isSearching || !searchQuery.trim()}
                      className="px-5 h-11 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-neutral-950 text-xs font-black flex items-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
                    >
                      {isSearching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                      <span>Search</span>
                    </button>
                  </form>

                  {searchError && (
                    <div className="p-3 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{searchError}</span>
                    </div>
                  )}

                  {/* Step 2: Profile Inspection Card & Role Assignment */}
                  {searchedUser && (
                    <div className="p-4 rounded-2xl bg-neutral-950 border border-emerald-500/30 shadow-2xl animate-in zoom-in-95 space-y-4">
                      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                        <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">
                          User Profile Inspection Card
                        </span>
                        <span className="text-xs font-mono font-bold text-neutral-400">
                          Target User: <span className="text-white">#{searchedUser.id}</span>
                        </span>
                      </div>

                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                        <div className="flex items-center gap-3.5">
                          <img
                            src={searchedUser.avatar || 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150'}
                            alt=""
                            className="w-14 h-14 rounded-2xl object-cover ring-2 ring-emerald-500/50"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-black text-white">{searchedUser.name}</h4>
                              <span className="text-xs text-neutral-400">@{searchedUser.username}</span>
                            </div>
                            <div className="flex items-center gap-2 mt-1 flex-wrap">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300">
                                Level {searchedUser.userLevel ?? 0}
                              </span>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300">
                                VIP {searchedUser.vipLevel ?? 0}
                              </span>
                              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                                Current Role: {searchedUser.role || 'USER'}
                              </span>
                              {(searchedUser as any).isNewCandidate && (
                                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse">
                                  ✨ 7-Digit Candidate Ready to Hire
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="text-right sm:border-l sm:border-neutral-800 sm:pl-4">
                          <div className="text-xs font-bold text-neutral-400">Virtual Balances</div>
                          <div className="text-xs font-mono text-amber-400 mt-0.5">
                            🪙 {(searchedUser.coinBalance ?? 0).toLocaleString()} Coins
                          </div>
                          <div className="text-xs font-mono text-cyan-400">
                            💎 {(searchedUser.diamondBalance ?? 0).toLocaleString()} Diamonds
                          </div>
                        </div>
                      </div>

                      {/* Select Role from Operator's Authorized Hiring Roles */}
                      <div className="pt-3 border-t border-neutral-800 space-y-3">
                        <div className="text-xs font-bold text-neutral-300">
                          Step 2: Select Role to Assign (Permitted for {activeOperator.role}):
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                          {allowedHiringRoles.map((role) => {
                            const cfg = ROLE_BADGE_STYLES[role as OfficialHierarchyRole] || ROLE_BADGE_STYLES['USER'];
                            const Icon = cfg.icon;
                            const isSelected = selectedRoleToAssign === role;
                            return (
                              <button
                                key={role}
                                type="button"
                                onClick={() => {
                                  playSoundFX('click');
                                  setSelectedRoleToAssign(role);
                                }}
                                className={`p-2.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                                  isSelected
                                    ? `bg-neutral-800 border-emerald-400 shadow-md ${cfg.color} scale-102`
                                    : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-850'
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <Icon className="w-4 h-4" />
                                  {isSelected && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
                                </div>
                                <span className="text-xs font-black mt-2">{role}</span>
                              </button>
                            );
                          })}
                        </div>

                        {/* Status indicator & Actions if user is already hired */}
                        {searchedUser.isHired && (
                          <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-xl bg-emerald-500 text-neutral-950 flex items-center justify-center font-bold">
                                ✓
                              </div>
                              <div>
                                <div className="text-xs font-black text-emerald-300">
                                  HIRING STATUS: ACTIVE & ASSIGNED AS {searchedUser.role}
                                </div>
                                <div className="text-[11px] text-neutral-400">
                                  Reporting line established under {activeOperator.name} ({activeOperator.role}) at {searchedUser.hiredAt || 'just now'}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  playSoundFX('click');
                                  setActiveTab('TREE');
                                }}
                                className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                              >
                                <GitBranch className="w-3.5 h-3.5" />
                                <span>View Tree</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  playSoundFX('click');
                                  setSearchedUser(null);
                                  setSearchQuery('');
                                }}
                                className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                              >
                                <X className="w-3.5 h-3.5" />
                                <span>Search Next Candidate</span>
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Submit Hire Button */}
                        <div className="flex items-center justify-between pt-2">
                          {searchedUser.isHired ? (
                            <span className="text-xs text-emerald-400 font-bold flex items-center gap-1.5">
                              <ShieldCheck className="w-4 h-4" />
                              <span>Role Active on User Profile</span>
                            </span>
                          ) : (
                            <span className="text-xs text-neutral-400">
                              Click to hire candidate and establish hierarchy link.
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={handleHireSubordinate}
                            disabled={isHiring}
                            className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-neutral-950 text-xs font-black flex items-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
                          >
                            {isHiring ? <RefreshCw className="w-4 h-4 animate-spin" /> : <UserCheck className="w-4 h-4" />}
                            <span>{searchedUser.isHired ? `Re-assign Role to ${selectedRoleToAssign}` : `Hire as ${selectedRoleToAssign} & Establish Reporting Line`}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: SUPER ADMIN FRAME DISTRIBUTION TOOL (FRAMES 1 TO 5)                */}
      {/* ========================================================================= */}
      {activeTab === 'FRAMES' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="p-5 rounded-3xl bg-neutral-900/80 border border-neutral-800 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span>Super Admin Avatar Frame Distribution Hub</span>
                </h3>
                <p className="text-[11px] text-neutral-400 mt-0.5">
                  Super Admins are strictly authorized to distribute <span className="text-amber-300 font-bold">Frames 1 to 5 only</span> to authorized subordinate accounts.
                </p>
              </div>

              <div className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold">
                Permitted: Frames 1 – 5
              </div>
            </div>

            {/* Subordinate Selector */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                  Select Subordinate Target Account:
                </label>
                <select
                  value={selectedTargetUserForFrame}
                  onChange={(e) => setSelectedTargetUserForFrame(e.target.value)}
                  className="w-full h-11 bg-neutral-950 border border-neutral-800 rounded-2xl px-4 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                >
                  <option value="">-- Choose Subordinate in Your Line --</option>
                  {subordinates.map((sub) => (
                    <option key={sub.userId} value={sub.userId}>
                      #{sub.userId} - {sub.name} ({sub.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                  Choose Frame to Equip:
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {['1', '2', '3', '4', '5'].map((fId) => (
                    <button
                      key={fId}
                      type="button"
                      onClick={() => {
                        playSoundFX('click');
                        setSelectedFrameId(fId);
                      }}
                      className={`h-11 rounded-2xl border text-xs font-black flex items-center justify-center gap-1 transition-all cursor-pointer ${
                        selectedFrameId === fId
                          ? 'bg-amber-500 text-neutral-950 border-amber-400 shadow-md font-bold'
                          : 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:text-white'
                      }`}
                    >
                      <span>Frame #{fId}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Test Restricted Frame 6+ Button */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="text-xs font-bold text-neutral-300 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <span>Security Validation: Test Frame 6+ Rejection</span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Clicking the button below tests the real backend boundary rule. If executed by Super Admin, the backend will strictly respond with a 403 Forbidden error stating Frames 6+ are restricted.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => handleDistributeFrame('6')}
                  className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold cursor-pointer transition-all"
                >
                  Test Frame #6 Allocation (Expected 403)
                </button>
                <button
                  type="button"
                  onClick={() => handleDistributeFrame('7')}
                  className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold cursor-pointer transition-all"
                >
                  Test Frame #7 Allocation (Expected 403)
                </button>
              </div>
            </div>

            {/* Action Button */}
            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => handleDistributeFrame()}
                disabled={isDistributingFrame || !selectedTargetUserForFrame}
                className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-neutral-950 text-xs font-black flex items-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
              >
                {isDistributingFrame ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Award className="w-4 h-4" />}
                <span>Equip Frame #{selectedFrameId} on Subordinate</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: ROLE PERMISSIONS MATRIX                                            */}
      {/* ========================================================================= */}
      {activeTab === 'PERMISSIONS' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="p-5 rounded-3xl bg-neutral-900/80 border border-neutral-800 space-y-4 shadow-xl">
            <div className="border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Key className="w-4 h-4 text-cyan-400" />
                <span>Official DIYO LIVE Role Hierarchy Architecture</span>
              </h3>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Every role operates with strictly verified backend permissions and permanent reporting relationships.
              </p>
            </div>

            {/* 8 Official Roles Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {(Object.keys(ROLE_BADGE_STYLES) as OfficialHierarchyRole[]).map((role) => {
                const cfg = ROLE_BADGE_STYLES[role];
                const Icon = cfg.icon;
                const permissions = rolesMatrix?.permissionsMap?.[role] || [];
                const hiringAllowed = rolesMatrix?.hiringMatrix?.[role] || [];

                return (
                  <div
                    key={role}
                    className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className={`p-1.5 rounded-xl ${cfg.bg}`}>
                          <Icon className="w-4 h-4" />
                        </span>
                        <div>
                          <span className="text-xs font-black text-white">{role}</span>
                          <span className="text-[10px] font-mono text-neutral-500 ml-1.5">
                            Level #{cfg.rank}
                          </span>
                        </div>
                      </div>

                      <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.border}`}>
                        {role}
                      </span>
                    </div>

                    <p className="text-[11px] text-neutral-400 leading-relaxed">
                      {cfg.description}
                    </p>

                    <div className="p-2 rounded-xl bg-neutral-900/60 border border-neutral-800/80 text-[10px] space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-neutral-500 font-bold">Authorized to Hire:</span>
                        <span className="text-amber-300 font-bold font-mono">
                          {hiringAllowed.length > 0 ? hiringAllowed.join(', ') : 'None'}
                        </span>
                      </div>
                    </div>

                    {/* Permissions chips */}
                    <div className="flex items-center gap-1 flex-wrap pt-1">
                      <span className="text-[9px] font-bold text-neutral-500 mr-1">Perms:</span>
                      {permissions.map((p: string) => (
                        <span key={p} className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-neutral-900 text-cyan-300 border border-cyan-500/20">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: HIERARCHY AUDIT LEDGER                                             */}
      {/* ========================================================================= */}
      {activeTab === 'AUDIT' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="p-5 rounded-3xl bg-neutral-900/80 border border-neutral-800 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  <span>Hierarchy Operations & Hiring Audit Ledger</span>
                </h3>
                <p className="text-[11px] text-neutral-400 mt-0.5">
                  Permanent immutable record of role assignments, frame allocations, and reporting path modifications.
                </p>
              </div>

              <button
                onClick={fetchAuditLogs}
                disabled={isLoadingAudit}
                className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-all cursor-pointer"
                title="Refresh Audit Logs"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingAudit ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {auditLogs.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-500">
                No hierarchy events recorded yet.
              </div>
            ) : (
              <div className="divide-y divide-neutral-800/60 max-h-[500px] overflow-y-auto pr-1">
                {auditLogs.map((log) => (
                  <div key={log.id} className="py-3 flex items-start justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] text-neutral-500">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                        <span className="font-bold text-white">{log.action}</span>
                        <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${log.status === 'SUCCESS' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>
                          {log.status}
                        </span>
                      </div>
                      <p className="text-neutral-400 text-[11px]">{log.details}</p>
                    </div>

                    <div className="text-right text-[10px] font-mono text-neutral-500 flex-shrink-0">
                      <div>Op: #{log.operatorId} ({log.operatorRole})</div>
                      <div>Target: #{log.targetUserId}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CHANGE ROLE MODAL                                                         */}
      {/* ========================================================================= */}
      {changeRoleTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md p-6 rounded-3xl bg-neutral-900 border border-neutral-700 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h4 className="text-sm font-black text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>Change Subordinate Role</span>
              </h4>
              <button
                onClick={() => setChangeRoleTarget(null)}
                className="text-neutral-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-neutral-300">
              Update role for <span className="font-bold text-white">{changeRoleTarget.name}</span> (#{changeRoleTarget.userId}).
            </p>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-neutral-400">Select New Role:</label>
              <select
                value={newSelectedRole}
                onChange={(e) => setNewSelectedRole(e.target.value)}
                className="w-full h-11 bg-neutral-950 border border-neutral-800 rounded-2xl px-4 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
              >
                {allowedHiringRoles.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setChangeRoleTarget(null)}
                className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleChangeRoleSubmit}
                disabled={isChangingRole}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-black shadow-lg"
              >
                {isChangingRole ? 'Updating...' : 'Confirm Role Change'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
