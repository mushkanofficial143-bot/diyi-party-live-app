import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Search, 
  ShieldAlert, 
  Ban, 
  VolumeX, 
  Crown, 
  Coins, 
  Gem, 
  Eye,
  CheckCircle2,
  Hash,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  UserPlus
} from 'lucide-react';
import { UserAccount } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface UsersSectionProps {
  users: UserAccount[];
  onOpenDetail: (user: UserAccount) => void;
  onUpdateStatus: (userId: string, newStatus: string) => void;
}

interface IdStats {
  currentCounter: number;
  latestUserId: string;
  nextAvailableId: string;
  totalRegisteredUsers: number;
  activeUsersCount: number;
  startingId: string;
  totalDeletedAccounts: number;
}

export const UsersSection: React.FC<UsersSectionProps> = ({
  users,
  onOpenDetail,
  onUpdateStatus
}) => {
  const [search, setSearch] = useState('');
  const [vipFilter, setVipFilter] = useState<number | 'ALL'>('ALL');
  const [idStats, setIdStats] = useState<IdStats | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [testRegNotice, setTestRegNotice] = useState<string | null>(null);

  const fetchIdStats = async () => {
    try {
      setIsRefreshing(true);
      const res = await fetch('/api/admin/user-id-stats');
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setIdStats(data);
        }
      }
    } catch (err) {
      console.warn('Failed to load user ID stats:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchIdStats();
  }, [users.length]);

  const handleTestRegisterUser = async () => {
    try {
      playSoundFX('click');
      const fakeEmail = `tester_${Date.now().toString().slice(-4)}@srlive.io`;
      const res = await fetch('/api/auth/register-or-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: 'email',
          identifier: fakeEmail,
          email: fakeEmail,
          name: `SR Star ${fakeEmail.split('@')[0]}`,
          countryCode: 'NP',
          countryFlag: '🇳🇵',
          countryName: 'Nepal'
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.user) {
          playSoundFX('win');
          setTestRegNotice(`✅ Successfully generated User ID #${data.user.id} (${data.user.name}) on backend.`);
          fetchIdStats();
          setTimeout(() => setTestRegNotice(null), 5000);
        }
      }
    } catch (e) {
      console.warn('Test user registration failed:', e);
    }
  };

  const filtered = users.filter((u) => {
    const matchesVip = vipFilter === 'ALL' || u.vipLevel === vipFilter;
    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (u.name || '').toLowerCase().includes(q) ||
      (u.username || '').toLowerCase().includes(q) ||
      (u.id || '').toLowerCase().includes(q) ||
      (u.email || '').toLowerCase().includes(q);

    return matchesVip && matchesSearch;
  });

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
              <Users className="w-4 h-4 text-amber-400" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Registered App Users & VIP Community</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
              7-Digit Sequential IDs
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Manage viewer accounts with permanent backend-generated 7-digit IDs, VIP badges 1–8, coin balances, bans, and stream mutes.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchIdStats}
            disabled={isRefreshing}
            className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-xs text-neutral-300 hover:text-white flex items-center gap-1.5 transition-all"
            title="Sync ID Statistics"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : ''}`} />
            <span>Sync Stats</span>
          </button>
          
          <button
            onClick={handleTestRegisterUser}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-950/40 transition-all"
            title="Atomically Register Next Sequential User"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>+ Test Sequential ID</span>
          </button>
        </div>
      </div>

      {/* 7-Digit Sequential User ID Registry & Admin Telemetry Card */}
      <div className="bg-gradient-to-r from-amber-950/30 via-neutral-900 to-purple-950/30 border border-amber-500/30 rounded-2xl p-4 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40">
                <Hash className="w-3.5 h-3.5" />
              </span>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-['Outfit']">
                Sequential User ID Generator Engine (7 Digits)
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> Backend Authoritative
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 max-w-xl">
              Every newly registered SR LIVE user automatically receives a permanent sequential 7-digit ID starting at <strong className="text-amber-300 font-mono">0000001</strong>. Client manual choice is forbidden. Deleted accounts are retired and never recycled.
            </p>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="flex-1 md:flex-initial bg-neutral-950/80 border border-neutral-800 rounded-xl px-3.5 py-2 text-center">
              <span className="text-[10px] text-neutral-400 block font-medium">Starting ID</span>
              <span className="text-xs font-mono font-black text-amber-400">0000001</span>
            </div>

            <div className="flex-1 md:flex-initial bg-neutral-950/80 border border-neutral-800 rounded-xl px-3.5 py-2 text-center">
              <span className="text-[10px] text-neutral-400 block font-medium">Latest Assigned ID</span>
              <span className="text-xs font-mono font-black text-emerald-400">
                {idStats?.latestUserId || '0000005'}
              </span>
            </div>

            <div className="flex-1 md:flex-initial bg-amber-500/10 border border-amber-500/40 rounded-xl px-3.5 py-2 text-center">
              <span className="text-[10px] text-amber-300 block font-medium">Next Available ID</span>
              <span className="text-xs font-mono font-black text-amber-300 animate-pulse">
                {idStats?.nextAvailableId || '0000006'}
              </span>
            </div>
          </div>
        </div>

        {testRegNotice && (
          <div className="mt-3 p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{testRegNotice}</span>
          </div>
        )}
      </div>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by 7-digit ID (e.g. 0000001), username, name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setVipFilter('ALL')}
            className={`px-3 py-1 rounded-xl font-bold transition-all ${
              vipFilter === 'ALL'
                ? 'bg-amber-500 text-black shadow-sm'
                : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            All VIPs
          </button>
          {[1, 2, 3, 4, 5, 6, 7, 8].map((lvl) => (
            <button
              key={lvl}
              onClick={() => setVipFilter(lvl)}
              className={`px-2.5 py-1 rounded-xl font-bold text-[11px] transition-all flex items-center gap-1 ${
                vipFilter === lvl
                  ? 'bg-gradient-to-r from-amber-400 to-rose-500 text-black font-black'
                  : 'bg-neutral-900 text-neutral-400 hover:text-amber-300'
              }`}
            >
              <Crown className="w-3 h-3" />
              <span>VIP {lvl}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Table of Users */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-3.5">User Identity & 7-Digit ID</th>
                <th className="p-3.5">VIP Tier</th>
                <th className="p-3.5">Coin Balance</th>
                <th className="p-3.5">Total Coins Spent</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Owner Moderation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filtered.map((usr) => (
                <tr key={usr.id} className="hover:bg-neutral-850/50 transition-colors">
                  
                  {/* User Profile */}
                  <td className="p-3.5">
                    <div className="flex items-center gap-3">
                      <img
                        src={usr.avatar}
                        alt={usr.name}
                        className="w-9 h-9 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                      />
                      <div>
                        <span className="font-bold text-white block">{usr.name}</span>
                        <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
                          <span className="font-mono text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/30">
                            ID: {usr.id}
                          </span>
                          <span>•</span>
                          <span>@{usr.username}</span>
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* VIP Tier */}
                  <td className="p-3.5">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-500/20 to-rose-500/20 text-amber-300 border border-amber-500/30 inline-flex items-center gap-1">
                      <Crown className="w-3 h-3 text-amber-400" />
                      <span>VIP LEVEL {usr.vipLevel}</span>
                    </span>
                  </td>

                  {/* Coin Balance */}
                  <td className="p-3.5 font-mono">
                    <span className="font-bold text-yellow-400 block">
                      {(usr?.coinBalance ?? 0).toLocaleString()} 🪙
                    </span>
                    <span className="text-[10px] text-neutral-400">
                      {(usr?.diamondBalance ?? 0).toLocaleString()} 💎
                    </span>
                  </td>

                  {/* Total Spent */}
                  <td className="p-3.5 font-mono">
                    <span className="text-white font-bold block">
                      {(usr?.totalSpentCoins ?? 0).toLocaleString()} 🪙
                    </span>
                    <span className="text-[10px] text-neutral-500">
                      {usr?.giftsSentCount ?? 0} gifts sent
                    </span>
                  </td>

                  {/* Status */}
                  <td className="p-3.5">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                      usr.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                      usr.status === 'Banned' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                      'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    }`}>
                      {usr.status}
                    </span>
                  </td>

                  {/* Owner Moderation */}
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => {
                          onOpenDetail(usr);
                          playSoundFX('click');
                        }}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white"
                        title="View User Dossier"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          const next = usr.status === 'Muted' ? 'Active' : 'Muted';
                          onUpdateStatus(usr.id, next);
                          playSoundFX('notification');
                        }}
                        className={`p-1.5 rounded-lg ${
                          usr.status === 'Muted' ? 'bg-emerald-600 text-white' : 'bg-neutral-800 text-amber-300 hover:bg-neutral-700'
                        }`}
                        title={usr.status === 'Muted' ? 'Unmute User' : 'Mute from Live Chat'}
                      >
                        <VolumeX className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          const next = usr.status === 'Banned' ? 'Active' : 'Banned';
                          onUpdateStatus(usr.id, next);
                          playSoundFX('click');
                        }}
                        className={`p-1.5 rounded-lg ${
                          usr.status === 'Banned' ? 'bg-emerald-600 text-white' : 'bg-rose-600/20 text-rose-300 hover:bg-rose-600/30'
                        }`}
                        title={usr.status === 'Banned' ? 'Unban User' : 'Ban User Account'}
                      >
                        <Ban className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
