import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Mic,
  MicOff,
  Smile,
  Gift,
  Share2,
  AlertTriangle,
  Power,
  ChevronRight,
  Flame,
  Trophy,
  Shield,
  Sparkles,
  Crown,
  Heart,
  Send,
  MessageSquare,
  Volume2,
  VolumeX,
  Music,
  Users,
  Swords,
  Maximize2,
  MoreVertical,
  Check,
  Copy
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';
import { UserAccount, GiftItem } from '../../types/ownerTypes';
import { UserProfileCardModal, UserProfileCardData } from '../profile/UserProfileCardModal';
import { BottomGiftSheet } from '../gifts/BottomGiftSheet';
import { PartyDjMusicModal } from './PartyDjMusicModal';
import { PartyRtcService } from '../../services/partyRtcService';
import { audioDebug, AudioDebugLogEntry } from '../../services/audioDebugService';
import { RankLeaderboardModal } from '../profile/RankLeaderboardModal';
import { HostLiveRewardWidget } from '../live/HostLiveRewardWidget';
import { PartyLiveRoomSession } from '../../types/ownerTypes';
import { SRGameCenterHub } from '../games/SRGameCenterHub';

export interface PartySeat {
  seatNumber: number;
  userId?: string;
  userName?: string;
  avatar?: string;
  isOwner?: boolean;
  hasSirCrown?: boolean;
  isMuted?: boolean;
  isSpeaking?: boolean;
  isCameraOn?: boolean;
  isMicOn?: boolean;
  isLocked?: boolean;
  vipLevel?: number;
  userLevel?: number;
  countryFlag?: string;
  diamondsEarned?: number;
  joinedAt?: string;
  heartsCount?: number;
  userTagId?: string;
}

export interface PartyLiveRoomProps {
  currentUser?: UserAccount;
  partyRoom?: PartyLiveRoomSession;
  onClose?: () => void;
  onSendGift?: (gift: GiftItem, recipientUserId: string) => Promise<boolean>;
  onUpdateUserBalance?: (newCoins: number, newDiamonds: number) => void;
}

export const PartyLiveRoom: React.FC<PartyLiveRoomProps> = ({
  currentUser = {
    id: '0000001',
    name: 'SR Angel',
    username: 'sr_angel',
    email: 'sr.angel@srlive.io',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    role: 'SUPER_ADMIN',
    hostTag: 'CELEBRATE',
    vipLevel: 5,
    svipLevel: 2,
    coinBalance: 0,
    diamondBalance: 0,
    boltBalance: 0,
    userLevel: 42,
    followersCount: 12800,
    followingCount: 856,
    countryCode: 'NP',
    countryFlag: '🇳🇵',
    countryName: 'Nepal',
    bio: 'Live • Laugh • Share ❤️',
    totalRechargedUSD: 0,
    totalSpentCoins: 0,
    status: 'ACTIVE',
    deviceType: 'Mobile App',
    registrationDate: '2025-01-10',
    lastLogin: 'Just now'
  },
  partyRoom,
  onClose,
  onSendGift,
  onUpdateUserBalance
}) => {
  const hostId = partyRoom?.hostId || partyRoom?.ownerId || (partyRoom as any)?.id || currentUser.id;
  const hostName = partyRoom?.hostName || partyRoom?.ownerName || (partyRoom as any)?.name || 'Party Host';
  const hostAvatar = partyRoom?.hostAvatar || partyRoom?.coverImage || partyRoom?.cover || currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150';
  const isCurrentUserHost = currentUser.id === hostId;

  // 20 real seats: never invent occupants; only render backend-provided users.
  const [seats, setSeats] = useState<PartySeat[]>(() => Array.from({ length: 20 }, (_, i) => {
    const src: any = partyRoom?.seats?.find((x: any) => x.seatNumber === i + 1);
    return { seatNumber:i+1, userId:src?.userId, userName:src?.userName, avatar:src?.avatar, isOwner:Boolean(src?.isOwner), hasSirCrown:Boolean(src?.hasSirCrown), isMuted:Boolean(src?.isMuted), isSpeaking:Boolean(src?.isSpeaking), isCameraOn:Boolean(src?.isCameraOn), isMicOn:Boolean(src?.isMicOn), isLocked:Boolean(src?.isLocked), vipLevel:src?.vipLevel, userLevel:src?.userLevel, countryFlag:src?.countryFlag, diamondsEarned:Number(src?.diamondsEarned||0), heartsCount:Number(src?.heartsCount||0), userTagId:src?.userId };
  }));

  useEffect(() => {
    const incoming:any[] = Array.isArray(partyRoom?.seats) ? partyRoom!.seats as any[] : [];
    setSeats(Array.from({ length:20 }, (_, i) => {
      const src:any = incoming.find(x => x.seatNumber === i+1);
      return { seatNumber:i+1, userId:src?.userId, userName:src?.userName, avatar:src?.avatar, isOwner:Boolean(src?.isOwner), hasSirCrown:Boolean(src?.hasSirCrown), isMuted:Boolean(src?.isMuted), isSpeaking:Boolean(src?.isSpeaking), isCameraOn:Boolean(src?.isCameraOn), isMicOn:Boolean(src?.isMicOn), isLocked:Boolean(src?.isLocked), vipLevel:src?.vipLevel, userLevel:src?.userLevel, countryFlag:src?.countryFlag, diamondsEarned:Number(src?.diamondsEarned||0), heartsCount:Number(src?.heartsCount||0), userTagId:src?.userId };
    }));
  }, [partyRoom]);

  const [userCoins, setUserCoins] = useState(currentUser.coinBalance || 0);
  const [userDiamonds, setUserDiamonds] = useState(currentUser.diamondBalance || 0);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isSpeakerMuted, setIsSpeakerMuted] = useState(false);

  // RTC & Audio state
  const [rtcStatus, setRtcStatus] = useState<string>('INITIALIZING');
  const [micPermissionGranted, setMicPermissionGranted] = useState<boolean>(false);
  const localAudioStreamRef = useRef<MediaStream | null>(null);

  // Modals state
  const [showGiftModal, setShowGiftModal] = useState(false);
  const [showDjMusicModal, setShowDjMusicModal] = useState(false);
  const [showGameCenter, setShowGameCenter] = useState(false);
  const [showAudioDebugModal, setShowAudioDebugModal] = useState(false);
  const [isRankModalOpen, setIsRankModalOpen] = useState(false);
  const [isDailyPrizeModalOpen, setIsDailyPrizeModalOpen] = useState(false);

  const [audioLogs, setAudioLogs] = useState<AudioDebugLogEntry[]>([]);
  const [selectedProfileUser, setSelectedProfileUser] = useState<UserProfileCardData | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // Subscribe to audio debug logs
  useEffect(() => {
    const unsubscribe = audioDebug.subscribe((logs) => {
      setAudioLogs(logs);
    });
    return () => unsubscribe();
  }, []);

  // Chat stream
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ id: string; user: string; text: string; type?: string }>>([]);

  // Party Live Room specific states matching screenshot
  const [activeTab, setActiveTab] = useState<'all' | 'chat' | 'gift'>('all');
  const [isFollowingHost, setIsFollowingHost] = useState(true);
  const [hostFollowersCount, setHostFollowersCount] = useState(2);
  const [copiedRefer, setCopiedRefer] = useState(false);
  const [showPkToast, setShowPkToast] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(() => {
    const started = partyRoom?.startedAt ? Date.parse(partyRoom.startedAt) : Date.now();
    return Math.max(0, Math.floor((Date.now() - started) / 1000));
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatGiftCount = (diamonds: number = 0) => {
    if (!diamonds || diamonds === 0) return '0';
    if (diamonds >= 1000000) {
      return (diamonds / 1000).toFixed(0) + 'K';
    }
    if (diamonds >= 1000) {
      return (diamonds / 1000).toFixed(0) + 'K';
    }
    return diamonds.toString();
  };

  const handleReferShare = () => {
    playSoundFX('click');
    setCopiedRefer(true);
    try {
      navigator.clipboard?.writeText(window.location.href);
    } catch (e) {}
    setTimeout(() => setCopiedRefer(false), 2000);
  };

  const handlePkClick = () => {
    playSoundFX('superchat');
    confetti({ particleCount: 40, spread: 60 });
    setShowPkToast(true);
    setTimeout(() => setShowPkToast(false), 3000);
  };

  // Initialize RTC Channel & Microphone on mount using PartyRtcService
  useEffect(() => {
    console.log('[RTC_INITIALIZED] SR LIVE Party Room Channel: sr_party_room_12345');
    setRtcStatus('RTC_JOIN_STARTED');

    const rtcService = PartyRtcService.getInstance();
    rtcService.joinRoom('sr_party_room_12345', currentUser.id, currentUser.name)
      .then((res) => {
        if (res.success) {
          setMicPermissionGranted(true);
          setRtcStatus('RTC_JOIN_SUCCESS');
          console.log('[AUDIO] participant joined: ' + currentUser.name);
        } else {
          setMicPermissionGranted(false);
          setRtcStatus('MIC_PERMISSION_DENIED');
        }
      })
      .catch((err) => {
        console.warn('[MIC_PERMISSION_DENIED]', err);
        setMicPermissionGranted(false);
        setRtcStatus('MIC_PERMISSION_DENIED');
      });

    return () => {
      rtcService.leaveRoom();
      console.log('[RTC_LEAVE] Party Room exited');
    };
  }, [currentUser.id, currentUser.name]);

  // Sync state when currentUser updates
  useEffect(() => {
    setUserCoins(currentUser.coinBalance || 0);
    setUserDiamonds(currentUser.diamondBalance || 0);
  }, [currentUser.coinBalance, currentUser.diamondBalance]);

  const handleSeatClick = async (seat: PartySeat) => {
    playSoundFX('click');
    if (seat.userId) {
      if (seat.userId === currentUser.id && !seat.isOwner) {
        // Option to leave seat
        if (confirm(`Do you want to step down from Seat #${seat.seatNumber}?`)) {
          try {
            const response = await fetch('/api/party-live/seat/action', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ action:'LEAVE_SEAT', seatNumber:seat.seatNumber, roomId:partyRoom?.id || partyRoom?.liveRoomId, user:currentUser }) });
            const data = await response.json();
            if (!response.ok || !data?.success) { alert(data?.error || 'Unable to leave seat.'); return; }
            if (data.room?.seats) setSeats(data.room.seats as PartySeat[]);
          } catch { alert('Network error while leaving the seat.'); return; }
          setSeats((prev) => {
            const next = [...prev];
            next[seat.seatNumber - 1] = {
              seatNumber: seat.seatNumber,
              userId: undefined,
              userName: undefined,
              avatar: undefined,
              isOwner: false,
              isMuted: false,
              isSpeaking: false,
              isCameraOn: false,
              isMicOn: false,
              isLocked: false
            };
            return next;
          });
          playSoundFX('click');
        }
        return;
      }

      setSelectedProfileUser({
        id: seat.userId,
        name: seat.userName || 'SR User',
        avatar: seat.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        gender: 'male',
        countryFlag: seat.countryFlag || '🇳🇵',
        countryCode: 'NP',
        level: seat.userLevel ?? 1,
        vipLevel: seat.vipLevel ?? 0,
        roleTag: seat.isOwner ? 'Host' : (seat.vipLevel && seat.vipLevel > 0 ? 'VIP Member' : 'Member'),
        followingCount: 31,
        followersCount: 839,
        bio: 'Welcome to SR LIVE Royal Lounge! 🌟',
        isFollowing: false,
        seatNumber: seat.seatNumber
      });
      setIsProfileModalOpen(true);
    } else {
      // Sit on empty seat -> Request mic and publish audio
      if (!micPermissionGranted) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          localAudioStreamRef.current = stream;
          setMicPermissionGranted(true);
          console.log('[MIC_PERMISSION_GRANTED] Seat audio enabled');
        } catch (e) {
          alert('⚠️ Microphone permission is required to speak on party seats.');
          return;
        }
      }

      console.log(`[AUDIO_PUBLISH_STARTED] User ${currentUser.id} occupied Seat #${seat.seatNumber}`);
      try {
        const response = await fetch('/api/party-live/seat/action', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ action:'TAKE_SEAT', seatNumber:seat.seatNumber, roomId:partyRoom?.id || partyRoom?.liveRoomId, user:currentUser }) });
        const data = await response.json();
        if (!response.ok || !data?.success) { alert(data?.error || 'Unable to take this seat.'); return; }
        if (data.room?.seats) setSeats(data.room.seats as PartySeat[]);
      } catch { alert('Network error while taking the seat.'); return; }
      setSeats((prev) => {
        const next = [...prev];
        const idx = seat.seatNumber - 1;
        next[idx] = {
          seatNumber: seat.seatNumber,
          userId: currentUser.id,
          userName: currentUser.name,
          avatar: currentUser.avatar,
          isOwner: false,
          isMuted: false,
          isSpeaking: true,
          isCameraOn: true,
          isMicOn: true,
          isLocked: false,
          vipLevel: currentUser.vipLevel || 0,
          userLevel: currentUser.userLevel || 1,
          countryFlag: currentUser.countryFlag || '🇳🇵',
          diamondsEarned: 0
        };
        return next;
      });
      playSoundFX('win');
      confetti({ particleCount: 30, spread: 45 });
    }
  };

  const handleToggleMic = () => {
    playSoundFX('click');
    const nextMuted = PartyRtcService.getInstance().toggleMute();
    setIsMicMuted(nextMuted);
    const mySeat = seats.find(s => s.userId === currentUser.id);
    if (mySeat) fetch('/api/party-live/seat/action', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ action:'TOGGLE_MUTE', seatNumber:mySeat.seatNumber, roomId:partyRoom?.id || partyRoom?.liveRoomId, user:currentUser }) }).catch(() => {});
    setSeats(prev => prev.map(seat => {
      if (seat.userId === currentUser.id || (seat.seatNumber === 1 && seat.isOwner)) {
        return {
          ...seat,
          isMuted: nextMuted,
          isMicOn: !nextMuted
        };
      }
      return seat;
    }));
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setChatMessages((prev) => [
      ...prev,
      { id: Math.random().toString(), user: currentUser.name, text: chatInput.trim(), type: 'chat' }
    ]);
    setChatInput('');
    playSoundFX('click');
  };

  return (
    <div
      id="party-live-room-container"
      className="relative w-full min-h-[92vh] bg-[#0d0915] text-white flex flex-col justify-between overflow-x-hidden font-sans select-none pb-20 sm:pb-6 rounded-2xl border border-purple-900/30 shadow-2xl"
      style={{
        backgroundImage: 'radial-gradient(circle at 50% 15%, #2a1548 0%, #120a22 55%, #06030c 100%)'
      }}
    >
      {/* ========================================================================= */}
      {/* 1. TOP ROOM HEADER & SCREENSHOT UI (Browser Bar, Host Card, Stats)        */}
      {/* ========================================================================= */}
      <div className="relative z-20 px-3 pt-2 sm:pt-3 flex flex-col gap-2">
        {/* Top Browser / App Address Bar matching Screenshot */}
        <div className="flex items-center justify-between px-2 py-1.5 rounded-xl bg-black/60 border border-white/10 backdrop-blur-md text-xs">
          <div className="flex items-center gap-2">
            {onClose ? (
              <button
                onClick={onClose}
                className="w-6 h-6 rounded-full hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
            )}
            <span className="text-[11px] font-mono text-neutral-300 truncate max-w-[180px] sm:max-w-none">
              partylive.freebuff.app
            </span>
          </div>

          <div className="flex items-center gap-2 text-neutral-400">
            <button
              onClick={() => {
                playSoundFX('click');
                handleReferShare();
              }}
              className="hover:text-white transition-colors"
              title="Share Room"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => {
                playSoundFX('click');
                alert('Room reported to moderation safety team.');
              }}
              className="hover:text-amber-400 transition-colors"
              title="Report Room"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => {
                playSoundFX('click');
                const el = document.getElementById('party-live-room-container');
                if (el) {
                  if (!document.fullscreenElement) {
                    el.requestFullscreen?.();
                  } else {
                    document.exitFullscreen?.();
                  }
                }
              }}
              className="hover:text-white transition-colors"
              title="Toggle Fullscreen"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Host Identity Card & Controls */}
        <div className="flex items-center justify-between gap-2 mt-1">
          {/* Left: Host Avatar, Name, ID, Following button, Followers count */}
          <div className="flex items-center gap-2">
            <div className="relative cursor-pointer" onClick={() => handleSeatClick(seats[0])}>
              <div className="w-10 h-10 rounded-full ring-2 ring-amber-400 p-0.5 bg-gradient-to-tr from-pink-500 via-purple-600 to-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.5)]">
                <img
                  src={hostAvatar}
                  alt="Room Host"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 text-neutral-950 flex items-center justify-center text-[9px] font-black border border-neutral-900 shadow">
                👑
              </div>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="text-xs sm:text-sm font-black text-white tracking-tight drop-shadow-md truncate max-w-[110px]">
                  {hostName}
                </span>
                <span className="text-xs">{partyRoom?.countryFlag || currentUser.countryFlag || '🇳🇵'}</span>
              </div>

              {/* ID Tag Pill: ● 0000021 💕 */}
              <div className="flex items-center gap-1.5">
                <div className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full bg-black/70 border border-white/15 text-[9px] text-amber-300 font-mono font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{seats[0]?.userTagId || hostId.slice(-7) || '0000021'}</span>
                  <span className="text-rose-400">💕</span>
                </div>

                {/* Following Toggle Button */}
                <button
                  onClick={() => {
                    playSoundFX('click');
                    setIsFollowingHost(prev => !prev);
                    setHostFollowersCount(prev => (isFollowingHost ? Math.max(0, prev - 1) : prev + 1));
                  }}
                  className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase transition-all shadow ${
                    isFollowingHost
                      ? 'bg-neutral-800/90 text-neutral-300 border border-neutral-600'
                      : 'bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 border border-amber-300 font-black'
                  }`}
                >
                  {isFollowingHost ? 'Following' : '+ Follow'}
                </button>

                <span className="text-[9px] text-neutral-400">
                  {hostFollowersCount} followers
                </span>
              </div>
            </div>
          </div>

          {/* Right Action Icons: DJ Music, Mic Mute/Unmute, Exit */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                playSoundFX('magic');
                setShowDjMusicModal(true);
              }}
              className="w-8 h-8 rounded-full bg-purple-950/80 border border-purple-500/30 flex items-center justify-center text-purple-300 hover:text-white active:scale-95 transition-all shadow"
              title="Party DJ Music"
            >
              <Music className="w-4 h-4" />
            </button>

            <button
              onClick={handleToggleMic}
              className={`w-8 h-8 rounded-full border flex items-center justify-center active:scale-95 transition-all shadow ${
                isMicMuted
                  ? 'bg-rose-950/90 border-rose-500 text-rose-300 shadow-[0_0_8px_rgba(244,63,94,0.5)]'
                  : 'bg-emerald-950/90 border-emerald-500 text-emerald-300 shadow-[0_0_8px_rgba(16,185,129,0.5)]'
              }`}
              title={isMicMuted ? 'Unmute Microphone' : 'Mute Microphone'}
            >
              {isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {onClose && (
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-rose-950/60 border border-rose-500/40 flex items-center justify-center text-rose-300 hover:text-rose-100 active:scale-95 transition-all shadow"
                title="Exit Party Room"
              >
                <Power className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Room Live Stats Bar (Timer, Coins, Trophy, Flame) - Matching Screenshot */}
        <div className="flex items-center justify-between px-2.5 py-1 rounded-xl bg-[#140f28]/90 border border-white/10 backdrop-blur-md shadow-inner text-[11px] font-mono">
          {/* Room Live Timer */}
          <div className="flex items-center gap-1 text-neutral-300 font-bold">
            <span className="text-amber-400">🕒</span>
            <span>{formatTimer(elapsedSeconds)}</span>
          </div>

          {/* Room Total Coin Pool */}
          <div className="flex items-center gap-1 text-amber-300 font-bold">
            <span>🪙</span>
            <span>{Number(partyRoom?.totalGiftsReceivedCoins || 0).toLocaleString()}</span>
          </div>

          {/* Trophy Diamond Milestone */}
          <div className="flex items-center gap-1 text-yellow-400 font-bold">
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            <span>{formatGiftCount(seats.reduce((sum, s) => sum + Number(s.diamondsEarned || 0), 0))}</span>
          </div>

          {/* Heat / Flame Counter */}
          <div className="flex items-center gap-1 text-rose-400 font-bold">
            <Flame className="w-3.5 h-3.5 text-rose-400 fill-rose-500 animate-pulse" />
            <span>{seats.filter(s => s.userId).length.toLocaleString()}</span>
          </div>
        </div>

        {/* Sub-Header: Rankings button (Left) & Daily Prize (Right) */}
        <div className="flex items-center justify-between px-1">
          <button
            onClick={() => {
              playSoundFX('superchat');
              setIsRankModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/50 text-amber-300 text-xs font-black shadow-md hover:bg-amber-500/30 active:scale-95 transition-all"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Rankings</span>
          </button>

          <button
            onClick={() => {
              playSoundFX('coin');
              setIsDailyPrizeModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-rose-500/20 to-purple-500/20 border border-rose-400/50 text-rose-300 text-xs font-black shadow-md hover:bg-rose-500/30 active:scale-95 transition-all"
          >
            <span className="text-sm">🎁</span>
            <span>Daily Prize</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1B. HOST LIVE-TIME REWARD HUD                                             */}
      {/* ========================================================================= */}
      <div className="relative z-20 px-3.5 my-1 max-w-sm mx-auto w-full">
        <HostLiveRewardWidget
          roomId={partyRoom?.id || 'LIVE-P-201'}
          liveType="PARTY"
          hostId={currentUser.id}
          hostName={currentUser.name}
          onRewardEarned={(coins, newBal) => {
            const updated = newBal !== undefined ? newBal : (userCoins + coins);
            setUserCoins(updated);
            if (onUpdateUserBalance) {
              onUpdateUserBalance(updated, userDiamonds);
            }
          }}
        />
      </div>

      {/* ========================================================================= */}
      {/* 2. 20 MIC SEATS GRID (4 Rows of 5 Seats: 1 to 20) with Floating Hearts    */}
      {/* ========================================================================= */}
      <div className="relative z-10 my-auto px-2 sm:px-3 py-1 max-w-lg mx-auto w-full">
        {/* Animated Floating Hearts (translucent red and pink hearts drifting up) */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden z-0">
          <span className="absolute bottom-6 left-[12%] text-rose-500 text-lg opacity-40 animate-pulse">❤️</span>
          <span className="absolute bottom-16 left-[45%] text-pink-500 text-xl opacity-50 animate-bounce">💕</span>
          <span className="absolute bottom-28 left-[78%] text-rose-400 text-base opacity-35 animate-pulse">❤️</span>
          <span className="absolute top-1/3 left-[28%] text-rose-500 text-2xl opacity-40 animate-pulse">💕</span>
          <span className="absolute top-2/3 right-[15%] text-pink-400 text-lg opacity-35">❤️</span>
        </div>

        {/* 20 Seats Grid: 4 rows x 5 columns (Seats 1 to 20) */}
        <div className="grid grid-cols-5 gap-x-1.5 gap-y-2 sm:gap-x-2.5 sm:gap-y-3 relative z-10">
          {seats.map((seat) => {
            const isOccupied = Boolean(seat.userId);
            const isHost = seat.isOwner || seat.seatNumber === 1;
            return (
              <div
                key={seat.seatNumber}
                onClick={() => handleSeatClick(seat)}
                className="flex flex-col items-center group cursor-pointer active:scale-95 transition-transform select-none"
              >
                {/* User ID Tag Pill (Above Avatar if Occupied) */}
                {isOccupied && (
                  <div className="mb-0.5 px-1 py-0.2 rounded-full bg-black/75 border border-white/20 text-[7px] text-amber-300 font-mono font-bold tracking-tight">
                    {seat.userTagId || seat.userId?.slice(-7) || `ID:${seat.seatNumber}`}
                  </div>
                )}

                {/* 3D Circular Platform / Seat Circle */}
                <div
                  className={`relative w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                    isHost
                      ? 'bg-gradient-to-tr from-amber-500/20 via-purple-900/50 to-yellow-400/20 border-2 border-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.5)]'
                      : isOccupied
                      ? 'bg-[#181a28]/90 border-2 border-purple-400 shadow-[0_0_10px_rgba(168,85,247,0.4)]'
                      : 'bg-[#161226]/80 border border-white/15 hover:border-amber-400/60 shadow-[inset_0_2px_4px_rgba(0,0,0,0.6)]'
                  } ${seat.isSpeaking ? 'ring-2 ring-emerald-400 ring-offset-1 ring-offset-[#0d0915] animate-pulse' : ''}`}
                >
                  {isOccupied && seat.avatar ? (
                    <div className="relative w-full h-full rounded-full overflow-hidden p-0.5">
                      <img
                        src={seat.avatar}
                        alt={seat.userName || `Seat ${seat.seatNumber}`}
                        className="w-full h-full rounded-full object-cover"
                      />
                      {seat.countryFlag && (
                        <span className="absolute top-0 right-0 text-[8px] bg-black/70 rounded-full px-0.5">
                          {seat.countryFlag}
                        </span>
                      )}
                    </div>
                  ) : (
                    /* Golden Car / Lounge Chair Silhouette Icon matching screenshot */
                    <div className="flex items-center justify-center text-amber-400/75 group-hover:text-amber-300 group-hover:scale-110 transition-transform">
                      <svg className="w-5 h-5 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.08 3.11H5.77L6.85 7zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z"/>
                        <circle cx="7.5" cy="14.5" r="1.5"/>
                        <circle cx="16.5" cy="14.5" r="1.5"/>
                      </svg>
                    </div>
                  )}

                  {/* Host Crown */}
                  {isHost && (
                    <div className="absolute -top-1.5 -left-1 text-[9px] bg-amber-400 text-neutral-950 font-black rounded-full px-1 shadow border border-amber-200">
                      👑
                    </div>
                  )}

                  {/* Mic Status */}
                  {isOccupied && (
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border border-white flex items-center justify-center text-[7px] text-white shadow ${
                      seat.isMuted ? 'bg-rose-500' : 'bg-emerald-500'
                    }`}>
                      {seat.isMuted ? <MicOff className="w-2 h-2" /> : <Mic className="w-2 h-2 fill-current" />}
                    </div>
                  )}
                </div>

                {/* Seat Information Underneath (Seat #, Gifts, Occupant Name, Hearts) */}
                <div className="mt-0.5 flex flex-col items-center max-w-[62px] w-full text-center">
                  {/* Seat Number */}
                  <span className="text-[10px] font-black text-neutral-300 group-hover:text-amber-300">
                    {seat.seatNumber}
                  </span>

                  {/* Gift Diamonds Count (e.g., 🎁 3600K or 🎁 0) */}
                  <span className="text-[8px] font-bold text-amber-400/90 flex items-center gap-0.5 truncate leading-tight">
                    <span>🎁</span>
                    <span>{formatGiftCount(seat.diamondsEarned)}</span>
                  </span>

                  {/* Occupant Name (if occupied) */}
                  {isOccupied && (
                    <span className="text-[8px] font-bold text-neutral-100 truncate w-full leading-tight drop-shadow">
                      {seat.userName}
                    </span>
                  )}

                  {/* Hearts Count (e.g. 💕 2 or 💕 0) */}
                  <span className="text-[8px] text-pink-400/90 flex items-center gap-0.5 leading-tight font-medium">
                    <span>💕</span>
                    <span>{seat.heartsCount || 0}</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. TABS (All | Chat | Gift) & FLOATING PK / MUSIC / REFER BUTTONS          */}
      {/* ========================================================================= */}
      <div className="relative z-20 px-3.5 pt-1">
        <div className="flex items-center justify-between">
          {/* Tabs: All | Chat | Gift */}
          <div className="flex items-center gap-3 text-xs font-bold text-neutral-400">
            <button
              onClick={() => setActiveTab('all')}
              className={`flex items-center gap-1 transition-colors ${
                activeTab === 'all' ? 'text-amber-400 font-black' : 'hover:text-neutral-200'
              }`}
            >
              <span>All</span>
              {activeTab === 'all' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
            </button>

            <button
              onClick={() => setActiveTab('chat')}
              className={`flex items-center gap-1 transition-colors ${
                activeTab === 'chat' ? 'text-amber-400 font-black' : 'hover:text-neutral-200'
              }`}
            >
              <span>Chat</span>
              {activeTab === 'chat' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
            </button>

            <button
              onClick={() => setActiveTab('gift')}
              className={`flex items-center gap-1 transition-colors ${
                activeTab === 'gift' ? 'text-amber-400 font-black' : 'hover:text-neutral-200'
              }`}
            >
              <span>Gift</span>
              {activeTab === 'gift' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
            </button>
          </div>

          {/* Quick Floating Action Buttons on the Right (PK, Music, Refer) */}
          <div className="flex items-center gap-2">
            {/* PK Battle Button */}
            <button
              onClick={handlePkClick}
              className="flex flex-col items-center group active:scale-95 transition-transform"
              title="Party PK Battle"
            >
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-orange-500 to-yellow-400 flex items-center justify-center text-white shadow-lg shadow-orange-500/40 border border-amber-300">
                <Swords className="w-4 h-4 group-hover:rotate-12 transition-transform" />
              </div>
              <span className="text-[9px] font-black text-amber-300 mt-0.5">PK</span>
            </button>

            {/* Game Center Button */}
            <button onClick={() => { playSoundFX('click'); setShowGameCenter(true); }} className="w-10 h-10 rounded-xl bg-emerald-950/80 border border-emerald-500/30 flex flex-col items-center justify-center text-emerald-300 shadow active:scale-95 transition-all" title="Game Center">
              <Trophy className="w-4 h-4" />
              <span className="text-[8px] font-black mt-0.5">GAME</span>
            </button>

            {/* DJ Music Button */}
            <button
              onClick={() => {
                playSoundFX('magic');
                setShowDjMusicModal(true);
              }}
              className="flex flex-col items-center group active:scale-95 transition-transform"
              title="Music Player"
            >
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 via-pink-600 to-rose-500 flex items-center justify-center text-white shadow-lg shadow-pink-600/40 border border-pink-300">
                <Music className="w-4 h-4 group-hover:scale-110 transition-transform" />
              </div>
              <span className="text-[9px] font-black text-pink-300 mt-0.5">Music</span>
            </button>

            {/* Refer Button */}
            <button
              onClick={handleReferShare}
              className="flex flex-col items-center group active:scale-95 transition-transform"
              title="Refer & Share"
            >
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center text-white shadow-lg shadow-cyan-500/40 border border-cyan-300">
                {copiedRefer ? <Check className="w-4 h-4 text-white" /> : <Share2 className="w-4 h-4 group-hover:scale-110 transition-transform" />}
              </div>
              <span className="text-[9px] font-black text-cyan-300 mt-0.5">
                {copiedRefer ? 'Copied' : 'Refer'}
              </span>
            </button>
          </div>
        </div>

        {/* Ticker Notifications Pill */}
        <div className="mt-2 flex items-center justify-between gap-2">
          <div className="flex-1 px-3 py-1 rounded-full bg-purple-950/60 border border-purple-500/30 text-[10px] text-neutral-200 flex items-center gap-1.5 truncate">
            <span className="text-amber-400">🎉</span>
            <span className="truncate">Won 6.5x 1,275,000 coins!</span>
          </div>
          <div className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-[9px] font-black text-amber-300">
            You [{currentUser.role || 'MEMBER'}]
          </div>
        </div>
      </div>

      {/* PK Announcement Toast */}
      {showPkToast && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-gradient-to-r from-orange-600 via-amber-600 to-red-600 text-white font-black text-xs shadow-2xl flex items-center gap-2 animate-bounce border border-yellow-300">
          <Swords className="w-4 h-4 text-yellow-200 animate-spin" />
          <span>⚔️ PARTY LIVE 20-SEAT PK BATTLE READY!</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. COMMUNITY GUIDELINES & CHAT STREAM                                      */}
      {/* ========================================================================= */}
      <div className="px-3.5 py-1">
        <div className="bg-[#151226]/80 backdrop-blur-md border border-white/10 rounded-xl p-2 text-[10px] text-neutral-300 leading-relaxed shadow-inner">
          <span className="font-bold text-amber-300">Community Guidelines:</span> Please maintain respect. Explicit content, harassment, or inappropriate behavior toward minors is strictly prohibited.
        </div>
      </div>

      {/* Chat Stream & Quick Audio Controls */}
      <div className="relative z-10 px-3.5 flex items-end justify-between gap-3 mb-1">
        {/* Left: Chat stream */}
        <div className="flex-1 space-y-1 max-w-[280px]">
          {chatMessages.slice(-3).map((msg) => (
            <div
              key={msg.id}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-xs text-neutral-200 shadow"
            >
              <span className="font-bold text-amber-300">{msg.user}:</span>
              <span className="text-neutral-300 font-normal">{msg.text}</span>
            </div>
          ))}
        </div>

        {/* Right: Floating Mic & Speaker Toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleToggleMic}
            className={`w-8 h-8 rounded-full border flex items-center justify-center shadow-lg active:scale-95 transition-all ${
              isMicMuted
                ? 'bg-rose-950/80 border-rose-500/50 text-rose-300 shadow-rose-900/30'
                : 'bg-gradient-to-tr from-cyan-500 to-teal-400 border-cyan-300 text-neutral-950 shadow-cyan-500/30'
            }`}
            title={isMicMuted ? 'Unmute Mic' : 'Mute Mic'}
          >
            {isMicMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={() => {
              setIsSpeakerMuted(!isSpeakerMuted);
              playSoundFX('click');
            }}
            className={`w-8 h-8 rounded-full border flex items-center justify-center shadow-lg active:scale-95 transition-all ${
              isSpeakerMuted
                ? 'bg-neutral-800 border-neutral-600 text-neutral-400'
                : 'bg-[#1b1c28] border-white/20 text-white shadow-purple-900/30'
            }`}
            title={isSpeakerMuted ? 'Turn Sound On' : 'Mute Room Audio'}
          >
            {isSpeakerMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 5. BOTTOM TOOLBAR: Chat Input + Emoji + Gift Button                        */}
      {/* ========================================================================= */}
      <div className="relative z-20 px-3 pt-2 pb-2 border-t border-white/10 flex items-center justify-between gap-2 bg-[#090611]/90 backdrop-blur-md">
        {/* Chat Input */}
        <form onSubmit={handleSendChat} className="flex-1 flex items-center gap-1.5 bg-black/60 border border-neutral-700/80 rounded-full px-3 py-1.5 focus-within:border-amber-400">
          <MessageSquare className="w-3.5 h-3.5 text-neutral-400" />
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 bg-transparent text-xs text-white placeholder-neutral-500 focus:outline-none"
          />
          <button type="submit" className="p-1 rounded-full bg-amber-500 text-neutral-950 hover:bg-amber-400 transition-colors">
            <Send className="w-3 h-3" />
          </button>
        </form>

        {/* Emoji Button */}
        <button
          onClick={() => {
            setChatMessages((prev) => [
              ...prev,
              { id: Math.random().toString(), user: currentUser.name, text: '🔥❤️🎉', type: 'chat' }
            ]);
            playSoundFX('vote');
          }}
          className="w-8 h-8 rounded-full bg-black/60 border border-neutral-700 flex items-center justify-center text-amber-400 hover:text-white active:scale-95 transition-all shrink-0"
          title="Send Reaction"
        >
          <Smile className="w-4 h-4" />
        </button>

        {/* Gift Button -> Opens Bottom Gift Sheet */}
        <button
          id="party-room-gift-sheet-btn"
          onClick={() => {
            playSoundFX('coin');
            setShowGiftModal(true);
          }}
          className="h-8 px-3.5 rounded-full bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 text-white flex items-center gap-1.5 font-black text-xs uppercase tracking-wider shadow-lg shadow-pink-600/40 active:scale-95 shrink-0 border border-pink-400/40"
          title="Send Gifts"
        >
          <Gift className="w-3.5 h-3.5 text-amber-300 animate-bounce" />
          <span>Gift Center</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 6. MODALS & SHEETS                                                        */}
      {/* ========================================================================= */}

      {/* Global Leaderboard Rankings Modal */}
      <RankLeaderboardModal
        isOpen={isRankModalOpen}
        onClose={() => setIsRankModalOpen(false)}
      />

      {/* Daily Prize Modal */}
      {isDailyPrizeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-sm bg-gradient-to-b from-[#1a1130] to-[#0d0915] border border-amber-500/50 rounded-3xl p-6 text-center shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-3xl mx-auto mb-3 animate-bounce">
              🎁
            </div>
            <h3 className="text-lg font-black text-amber-300">Daily Party Prize Chest</h3>
            <p className="text-xs text-neutral-300 mt-1 mb-5">
              Claim your daily free coins & bonus diamonds for participating in party rooms!
            </p>
            <div className="p-3 rounded-2xl bg-black/40 border border-white/10 mb-5 flex items-center justify-around">
              <div>
                <span className="text-[10px] text-neutral-400 block">Free Reward</span>
                <span className="text-sm font-black text-amber-400">5,000 Coins 🪙</span>
              </div>
              <div className="h-8 w-px bg-white/10" />
              <div>
                <span className="text-[10px] text-neutral-400 block">Bonus</span>
                <span className="text-sm font-black text-cyan-400">100 Diamonds 💎</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  playSoundFX('win');
                  confetti({ particleCount: 50, spread: 60 });
                  alert('🎉 Successfully claimed Daily Party Prize!');
                  setIsDailyPrizeModalOpen(false);
                }}
                className="flex-1 py-2.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 font-black text-xs uppercase shadow-lg shadow-amber-500/30"
              >
                Claim Now
              </button>
              <button
                onClick={() => setIsDailyPrizeModalOpen(false)}
                className="px-4 py-2.5 rounded-full bg-white/10 text-neutral-300 font-bold text-xs hover:bg-white/20"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomGiftSheet
        isOpen={showGiftModal}
        onClose={() => setShowGiftModal(false)}
        initialCoins={userCoins}
        initialDiamonds={userDiamonds}
        senderId={currentUser.id}
        senderName={currentUser.name}
        targetHostId={hostId}
        liveRoomId={partyRoom?.id || partyRoom?.liveRoomId}
        roomType="PARTY_LIVE"
        onSendSuccess={({ gift, multiplier, newBalance, newDiamonds, diamondsEarned }) => {
          setUserCoins(newBalance);
          const updatedDiamonds = newDiamonds !== undefined ? newDiamonds : (userDiamonds + (diamondsEarned || 0));
          setUserDiamonds(updatedDiamonds);
          if (onUpdateUserBalance) onUpdateUserBalance(newBalance, updatedDiamonds);

          setChatMessages((prev) => [
            ...prev,
            {
              id: Math.random().toString(),
              user: currentUser.name,
              text: `🎁 Sent ${multiplier}x ${gift.name}!`,
              type: 'gift'
            }
          ]);
        }}
      />

      <UserProfileCardModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        user={selectedProfileUser}
        onSendGift={() => setShowGiftModal(true)}
        onSendMessage={(u) => setChatInput(`@${u.name} `)}
      />

      {showGameCenter && (
        <div className="fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-2" onClick={() => setShowGameCenter(false)}>
          <div className="w-full max-w-md max-h-[88vh] overflow-y-auto rounded-2xl bg-[#0c0a14] border border-white/10 shadow-2xl" onClick={e => e.stopPropagation()}>
            <SRGameCenterHub userCoins={userCoins} onUpdateCoins={(delta) => { const next=Math.max(0,userCoins+delta); setUserCoins(next); onUpdateUserBalance?.(next,userDiamonds); }} onClose={() => setShowGameCenter(false)} />
          </div>
        </div>
      )}

      <PartyDjMusicModal
        isOpen={showDjMusicModal}
        onClose={() => setShowDjMusicModal(false)}
        roomTitle="SR Royal Party Live"
        onBroadcastSong={(songTitle) => {
          setChatMessages((prev) => [
            ...prev,
            {
              id: Math.random().toString(),
              user: currentUser.name,
              text: `🎵 Playing track: "${songTitle}"`,
              type: 'system'
            }
          ]);
        }}
      />

      {showAudioDebugModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-lg bg-neutral-900 border border-emerald-500/40 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center justify-center">
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">Audio Pipeline & RTC Diagnostics</h3>
                  <p className="text-[10px] text-neutral-400">Real-time voice communication health check</p>
                </div>
              </div>
              <button 
                onClick={() => setShowAudioDebugModal(false)}
                className="p-1.5 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 text-xs">
              <div className="space-y-2">
                <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-bold">Real-Time Audio States</span>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <span>RTC Connected</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">ACTIVE</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <span>Mic Permission</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black ${micPermissionGranted ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'}`}>
                      {micPermissionGranted ? 'GRANTED' : 'PENDING'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <span>Mic Capturing</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black ${!isMicMuted && micPermissionGranted ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'}`}>
                      {!isMicMuted && micPermissionGranted ? 'ACTIVE' : 'MUTED'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <span>Speaker Playback</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black ${!isSpeakerMuted ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'}`}>
                      {!isSpeakerMuted ? 'PLAYING' : 'MUTED'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-bold">Structured Audio Event Logs</span>
                  <button
                    onClick={() => audioDebug.clearLogs()}
                    className="text-[10px] text-rose-400 hover:underline cursor-pointer"
                  >
                    Clear Logs
                  </button>
                </div>
                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 font-mono text-[10px] space-y-1.5 max-h-48 overflow-y-auto">
                  {audioLogs.map(log => (
                    <div key={log.id} className="flex items-start gap-2 border-b border-neutral-900 pb-1">
                      <span className="text-neutral-500 shrink-0">{log.timestamp.substring(11, 19)}</span>
                      <span className={`px-1 rounded shrink-0 font-bold ${
                        log.category === 'ERROR' ? 'bg-rose-500/20 text-rose-300' :
                        log.category === 'PERMISSION' ? 'bg-blue-500/20 text-blue-300' :
                        log.category === 'PUBLISH' ? 'bg-emerald-500/20 text-emerald-300' :
                        log.category === 'SUBSCRIBE' ? 'bg-purple-500/20 text-purple-300' :
                        'bg-neutral-800 text-neutral-300'
                      }`}>
                        {log.category}
                      </span>
                      <span className="text-neutral-300 break-all">{log.message}</span>
                    </div>
                  ))}
                  {audioLogs.length === 0 && (
                    <div className="text-neutral-500 text-center py-4">No audio logs recorded yet.</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
