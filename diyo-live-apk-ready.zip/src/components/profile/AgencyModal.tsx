import React, { useState, useEffect } from 'react';
import { 
  X, 
  Users, 
  Sparkles, 
  Check, 
  Building2, 
  ShieldCheck, 
  DollarSign, 
  Award, 
  ChevronRight,
  UserCheck,
  TrendingUp,
  Coins,
  Search,
  AlertCircle,
  Clock,
  CheckCircle2,
  XCircle,
  Camera,
  Scan,
  RefreshCw,
  Eye,
  Smile
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';
import { AgencyAccount, AgencyJoinRequest } from '../../types/ownerTypes';
import { createAuditLog } from '../../utils/rbacGuard';

interface AgencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: any;
  agencies: AgencyAccount[];
  agencyJoinRequests: AgencyJoinRequest[];
  onUpdateAgencyRequests: (reqs: AgencyJoinRequest[]) => void;
  onUpdateUserAgencyMembership: (membership: any) => void;
  onAddAuditLog: (log: any) => void;
  onAddNotification: (notif: any) => void;
}

export const AgencyModal: React.FC<AgencyModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  agencies = [],
  agencyJoinRequests = [],
  onUpdateAgencyRequests,
  onUpdateUserAgencyMembership,
  onAddAuditLog,
  onAddNotification
}) => {
  const [activeTab, setActiveTab] = useState<'VERIFY_JOIN' | 'CREATE' | 'HOST_LIST'>('VERIFY_JOIN');
  const [searchAgencyId, setSearchAgencyId] = useState('');
  const [verifiedAgency, setVerifiedAgency] = useState<AgencyAccount | null>(null);
  const [searchNotFound, setSearchNotFound] = useState(false);
  const [agencyName, setAgencyName] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Face Verification State
  const [faceVerified, setFaceVerified] = useState<boolean>(() => {
    return !!(currentUser?.faceVerified || localStorage.getItem(`diyo_face_verified_${currentUser?.id}`));
  });
  const [isScanningFace, setIsScanningFace] = useState<boolean>(false);
  const [scanStep, setScanStep] = useState<'idle' | 'centering' | 'blinking' | 'analyzing' | 'done'>('idle');
  const [scanProgress, setScanProgress] = useState<number>(0);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    playSoundFX('notification');
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleStartFaceVerification = () => {
    setIsScanningFace(true);
    setScanStep('centering');
    setScanProgress(15);
    playSoundFX('click');

    setTimeout(() => {
      setScanStep('blinking');
      setScanProgress(45);
      playSoundFX('coin');

      setTimeout(() => {
        setScanStep('analyzing');
        setScanProgress(80);
        playSoundFX('spin');

        setTimeout(() => {
          setScanProgress(100);
          setScanStep('done');
          setFaceVerified(true);
          try {
            localStorage.setItem(`diyo_face_verified_${currentUser?.id}`, 'true');
          } catch (e) {}
          setIsScanningFace(false);
          playSoundFX('win');
          confetti({ particleCount: 50, spread: 60 });
          showToast('✅ Face verification passed 100%! Broadcaster identity authenticated.');
        }, 1200);
      }, 1200);
    }, 1200);
  };

  const handleSearchAgency = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchAgencyId.trim()) return;
    playSoundFX('click');

    const q = searchAgencyId.trim().toUpperCase();
    const found = agencies.find(a => a.id.toUpperCase() === q || a.code.toUpperCase() === q || a.name.toUpperCase().includes(q));

    if (found) {
      setVerifiedAgency(found);
      setSearchNotFound(false);
      showToast(`✨ Agency verified successfully: ${found.name}`);
    } else {
      setVerifiedAgency(null);
      setSearchNotFound(true);
      showToast('❌ Agency Not Found. Please check the Agency ID or Power ID.');
    }
  };

  const existingRequestForUser = agencyJoinRequests.find(
    r => r.hostId === currentUser.id && verifiedAgency && r.agencyId === verifiedAgency.id && r.status === 'PENDING'
  );

  const userMembership = currentUser.agencyMembership || { status: 'NONE' };

  const handleSendJoinRequest = async () => {
    if (!verifiedAgency) return;

    if (!faceVerified) {
      showToast('⚠️ Face verification is required before sending Agency Join Request.');
      playSoundFX('alert');
      return;
    }

    if (verifiedAgency.status !== 'Active') {
      showToast('❌ Cannot join: This agency is Suspended, Banned, or Deactivated.');
      return;
    }

    if (userMembership.status === 'VERIFIED_JOINED' || userMembership.status === 'APPROVED') {
      showToast('⚠️ You are already joined in an approved agency. Leave your current agency first to join a new one.');
      return;
    }

    if (existingRequestForUser) {
      showToast('⚠️ You already have a pending join request for this agency.');
      return;
    }

    try {
      const res = await fetch('/api/agency/request-join', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hostId: currentUser.id || 'HST-5001',
          hostName: currentUser.name || currentUser.username || 'Host Broadcaster',
          hostAvatar: currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
          agencyId: verifiedAgency.id,
          faceVerified: true,
          facePhotoUrl: currentUser.avatar
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        showToast(`❌ ${data.error || 'Failed to submit join request.'}`);
        return;
      }

      const newReq: AgencyJoinRequest = data.request || {
        id: `AJR-${Math.floor(1000 + Math.random() * 9000)}`,
        hostId: currentUser.id || 'HST-5001',
        hostName: currentUser.name || 'Host Broadcaster',
        hostAvatar: currentUser.avatar,
        agencyId: verifiedAgency.id,
        agencyName: verifiedAgency.name,
        status: 'PENDING',
        requestDate: new Date().toISOString()
      };

      onUpdateAgencyRequests([newReq, ...agencyJoinRequests]);

      onUpdateUserAgencyMembership({
        agencyId: verifiedAgency.id,
        agencyName: verifiedAgency.name,
        status: 'PENDING',
        requestId: newReq.id,
        requestDate: newReq.requestDate
      });

      playSoundFX('superchat');
      confetti({ particleCount: 60, spread: 70 });

      // Audit Log
      onAddAuditLog(createAuditLog(
        currentUser.id || 'HST-5001',
        currentUser.name || 'Host',
        'HOST',
        'CREATE_AGENCY_JOIN_REQUEST',
        newReq.id,
        'AGENCY',
        'SUCCESS',
        `Host with Face Verification submitted joining request for agency ${verifiedAgency.name} (${verifiedAgency.id})`
      ));

      showToast('🚀 Join request submitted with Face Verification! Awaiting Agency Owner approval.');
    } catch (e) {
      showToast('❌ Network error submitting request. Please try again.');
    }
  };

  const handleLeaveAgency = async () => {
    try {
      await fetch('/api/agency/leave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hostId: currentUser.id })
      });
      onUpdateUserAgencyMembership({ status: 'NONE' });
      showToast('🔓 You have left your agency. You can now join a new one.');
      playSoundFX('alert');
    } catch (e) {
      onUpdateUserAgencyMembership({ status: 'NONE' });
      showToast('🔓 Agency membership cleared.');
    }
  };

  const handleCreateAgency = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agencyName.trim()) return;
    playSoundFX('superchat');
    confetti({ particleCount: 60, spread: 80 });
    showToast(`Congratulations! Agency "${agencyName.trim()}" created successfully. Your Agency ID is AG-9901.`);
    setAgencyName('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-[#0c1226] via-[#090d1f] to-[#050814] border border-teal-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-teal-900/40 flex items-center justify-between bg-[#080d20]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-500/40 flex items-center justify-center shadow-md">
              <Building2 className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white font-['Outfit']">Host Agency Join & Face Verification</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-teal-500/20 text-teal-300 border border-teal-500/40">
                  OFFICIAL GUILD
                </span>
              </div>
              <p className="text-xs text-neutral-400">Step 1: Face Scan • Step 2: Agency ID • Step 3: Approval</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-teal-500/20 border border-teal-500/50 text-teal-200 text-xs font-bold text-center animate-in zoom-in-95">
            {toastMsg}
          </div>
        )}

        {/* Tab switcher */}
        <div className="p-4 border-b border-neutral-800 flex items-center gap-2">
          {[
            { key: 'VERIFY_JOIN', label: 'Host Agency Join (KYC)' },
            { key: 'CREATE', label: 'Create New Agency' },
            { key: 'HOST_LIST', label: 'Top Guild Ranking' }
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => {
                setActiveTab(tab.key as any);
                playSoundFX('click');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                activeTab === tab.key
                  ? 'bg-teal-500 text-neutral-950 border-teal-400 shadow-md font-black'
                  : 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:bg-neutral-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Body content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {activeTab === 'VERIFY_JOIN' && (
            <div className="space-y-4">
              
              {/* Current Status Box */}
              <div className="p-4 rounded-2xl bg-neutral-950/90 border border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-wider">Current Host Status</span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase ${
                      userMembership.status === 'VERIFIED_JOINED' || userMembership.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                      userMembership.status === 'PENDING' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                      'bg-neutral-800 text-neutral-400'
                    }`}>
                      {userMembership.status === 'VERIFIED_JOINED' || userMembership.status === 'APPROVED' ? 'Approved Host / Live Broadcaster' :
                       userMembership.status === 'PENDING' ? 'Request Pending Owner Approval' : 'Unattached Host'}
                    </span>
                    {userMembership.agencyName && (
                      <span className="text-xs font-bold text-white">({userMembership.agencyName})</span>
                    )}
                  </div>
                </div>
                {(userMembership.status === 'VERIFIED_JOINED' || userMembership.status === 'APPROVED') && (
                  <button
                    onClick={handleLeaveAgency}
                    className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold border border-rose-500/30 cursor-pointer"
                  >
                    Leave Agency
                  </button>
                )}
              </div>

              {/* STEP 1: FACE VERIFICATION (MANDATORY) */}
              <div className={`p-4 rounded-2xl border transition-all ${
                faceVerified 
                  ? 'bg-emerald-950/20 border-emerald-500/40' 
                  : 'bg-neutral-950/90 border-cyan-500/40'
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                      faceVerified ? 'bg-emerald-500/20 text-emerald-400' : 'bg-cyan-500/20 text-cyan-400'
                    }`}>
                      <Camera className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                        <span>STEP 1: HOST FACE VERIFICATION</span>
                        {faceVerified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 fill-emerald-500/20" />}
                      </h4>
                      <p className="text-[10px] text-neutral-400">Real host identity biometric anti-fraud check</p>
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                    faceVerified 
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}>
                    {faceVerified ? 'PASSED 100% ✓' : 'REQUIRED'}
                  </span>
                </div>

                {isScanningFace ? (
                  <div className="p-4 rounded-xl bg-neutral-900 border border-cyan-500/30 space-y-3 text-center">
                    <div className="relative w-28 h-36 mx-auto rounded-full border-2 border-dashed border-cyan-400 flex items-center justify-center overflow-hidden bg-black/40">
                      <img 
                        src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400'} 
                        alt="Face scan preview" 
                        className="w-full h-full object-cover opacity-80"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-cyan-500/20 animate-pulse pointer-events-none" />
                      <div className="absolute w-full h-0.5 bg-cyan-400 shadow-[0_0_12px_#22d3ee] animate-bounce" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-cyan-300 animate-pulse">
                        {scanStep === 'centering' && '🎯 Center your face in the oval frame...'}
                        {scanStep === 'blinking' && '👁️ Blink your eyes & hold still for liveness check...'}
                        {scanStep === 'analyzing' && '⚡ Authenticating 3D facial biometric contours...'}
                      </p>
                      <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden max-w-xs mx-auto">
                        <div 
                          className="bg-gradient-to-r from-cyan-500 to-teal-400 h-full transition-all duration-300"
                          style={{ width: `${scanProgress}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ) : faceVerified ? (
                  <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs">
                    <div className="flex items-center gap-2">
                      <img 
                        src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'} 
                        alt="Verified face" 
                        className="w-8 h-8 rounded-full object-cover border border-emerald-400"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <span className="font-bold text-emerald-300 block">Identity Authenticated</span>
                        <span className="text-[10px] text-neutral-400">Broadcaster biometrics verified & stamped</span>
                      </div>
                    </div>
                    <button
                      onClick={handleStartFaceVerification}
                      className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-300 text-[10px] font-bold border border-white/10 flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" /> Re-scan
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      Before connecting with an Agency, official DIYO Host guidelines require a quick live facial scan to protect streams from impersonation.
                    </p>
                    <button
                      onClick={handleStartFaceVerification}
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98"
                    >
                      <Scan className="w-4 h-4" />
                      <span>Start Face Verification Scan</span>
                    </button>
                  </div>
                )}
              </div>

              {/* STEP 2: AGENCY SEARCH & SELECTION */}
              <form onSubmit={handleSearchAgency} className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800 space-y-3">
                <h4 className="text-xs font-bold text-white flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Search className="w-4 h-4 text-teal-400" />
                    <span>STEP 2: ENTER AGENCY ID OR POWER ID</span>
                  </span>
                  <span className="text-[10px] text-teal-300 font-mono">e.g. AG-01, AG-02, AG-03</span>
                </h4>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    required
                    placeholder="Enter Agency ID (e.g. AG-01)"
                    value={searchAgencyId}
                    onChange={(e) => setSearchAgencyId(e.target.value)}
                    className="flex-1 px-3.5 py-2.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-teal-400 font-mono"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-neutral-950 font-black text-xs uppercase shadow-md cursor-pointer transition-all"
                  >
                    Verify Agency
                  </button>
                </div>
              </form>

              {/* Quick Agency Selectors */}
              {!verifiedAgency && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Official Verified Guilds</span>
                  <div className="grid grid-cols-3 gap-2">
                    {agencies.slice(0, 3).map(a => (
                      <button
                        key={a.id}
                        onClick={() => {
                          setVerifiedAgency(a);
                          setSearchAgencyId(a.id);
                          setSearchNotFound(false);
                          playSoundFX('click');
                        }}
                        className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-left transition-all cursor-pointer flex items-center gap-2"
                      >
                        <img src={a.logo} alt={a.name} className="w-6 h-6 rounded-lg object-cover" referrerPolicy="no-referrer" />
                        <div className="truncate">
                          <span className="text-xs font-bold text-white truncate block">{a.name}</span>
                          <span className="text-[10px] text-teal-400 font-mono font-bold block">{a.id}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Not Found State */}
              {searchNotFound && (
                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <div>
                    <span className="font-bold block">Agency Not Found</span>
                    <span className="text-[11px] text-neutral-400">Please check the Agency ID or Power ID and try searching again.</span>
                  </div>
                </div>
              )}

              {/* Verified Agency Details Card */}
              {verifiedAgency && (
                <div className="p-4 rounded-2xl bg-gradient-to-b from-neutral-900 to-neutral-950 border border-teal-500/40 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                    <div className="flex items-center gap-3">
                      <img
                        src={verifiedAgency.logo}
                        alt={verifiedAgency.name}
                        className="w-12 h-12 rounded-2xl object-cover border border-teal-500/40"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <h4 className="font-bold text-white text-sm">{verifiedAgency.name}</h4>
                        <div className="flex items-center gap-2 text-[11px] text-neutral-400">
                          <span className="font-mono text-teal-400 font-bold">{verifiedAgency.id}</span>
                          <span>•</span>
                          <span className="font-mono text-neutral-300">Code: {verifiedAgency.code}</span>
                        </div>
                      </div>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase ${
                      verifiedAgency.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                      'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    }`}>
                      {verifiedAgency.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800">
                      <span className="text-[10px] text-neutral-400 block">Agency Owner / Manager</span>
                      <span className="font-bold text-white">{verifiedAgency.ownerOrManager}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800">
                      <span className="text-[10px] text-neutral-400 block">Commission & Hosts</span>
                      <span className="font-bold text-teal-300">{verifiedAgency.commissionRate}% • {verifiedAgency.numberOfHosts} Hosts</span>
                    </div>
                  </div>

                  {/* STEP 3: SUBMIT JOIN REQUEST */}
                  <div className="pt-2">
                    {verifiedAgency.status !== 'Active' ? (
                      <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs text-center font-bold">
                        ⚠️ This agency is currently Suspended or Banned. Joining is not permitted.
                      </div>
                    ) : (userMembership.status === 'VERIFIED_JOINED' || userMembership.status === 'APPROVED') ? (
                      <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400 text-xs text-center font-medium">
                        🔒 You are already joined in an approved agency.
                      </div>
                    ) : existingRequestForUser ? (
                      <div className="p-3 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs text-center font-bold flex items-center justify-center gap-2">
                        <Clock className="w-4 h-4 animate-spin" />
                        <span>Joining request pending approval by Agency Owner.</span>
                      </div>
                    ) : (
                      <button
                        onClick={handleSendJoinRequest}
                        className={`w-full py-3 rounded-xl font-black text-xs uppercase tracking-wider shadow-lg cursor-pointer transition-all flex items-center justify-center gap-2 ${
                          faceVerified
                            ? 'bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-neutral-950 shadow-teal-950/50'
                            : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                        }`}
                      >
                        <UserCheck className="w-4 h-4" />
                        <span>{faceVerified ? 'SUBMIT JOIN REQUEST (WITH FACE KYC)' : 'COMPLETE STEP 1 FACE SCAN FIRST'}</span>
                      </button>
                    )}
                  </div>
                </div>
              )}

            </div>
          )}

          {activeTab === 'CREATE' && (
            <form onSubmit={handleCreateAgency} className="space-y-4">
              <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800 space-y-3">
                <h4 className="text-xs font-bold text-white">Agency Guild Name</h4>
                <input
                  type="text"
                  required
                  placeholder="e.g., Galaxy Stars Guild"
                  value={agencyName}
                  onChange={(e) => setAgencyName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-teal-400"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-neutral-950 font-black text-xs uppercase shadow-md transition-all cursor-pointer"
              >
                Register Official Agency
              </button>
            </form>
          )}

          {activeTab === 'HOST_LIST' && (
            <div className="space-y-3">
              {agencies.map((agency, idx) => (
                <div key={agency.id} className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="w-6 text-center font-black text-xs text-teal-400">#{idx + 1}</span>
                    <img src={agency.logo} alt={agency.name} className="w-10 h-10 rounded-xl object-cover" referrerPolicy="no-referrer" />
                    <div>
                      <h4 className="text-xs font-bold text-white">{agency.name}</h4>
                      <span className="text-[10px] text-neutral-400">{agency.numberOfHosts} Verified Hosts • {agency.commissionRate}% Rev</span>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-teal-400">{agency.id}</span>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
