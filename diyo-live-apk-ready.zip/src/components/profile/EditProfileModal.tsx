import React, { useState, useRef, useMemo } from 'react';
import { 
  X, 
  Camera, 
  Save, 
  User, 
  CheckCircle2, 
  Upload, 
  Loader2, 
  Calendar, 
  Globe, 
  Phone, 
  Mail, 
  Search, 
  ChevronDown, 
  Check, 
  Sparkles 
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { 
  SUPPORTED_COUNTRIES, 
  POPULAR_COUNTRIES, 
  CountryItem, 
  getCountryByCode 
} from '../../data/countryData';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: {
    name: string;
    username: string;
    avatar: string;
    bio?: string;
    gender?: 'Male' | 'Female' | 'Other';
    dob?: string;
    countryName?: string;
    countryFlag?: string;
    countryCode?: string;
    phone?: string;
    email?: string;
    profileTag?: string;
  };
  onSaveProfile?: (updated: {
    name: string;
    username: string;
    avatar: string;
    bio?: string;
    gender?: 'Male' | 'Female' | 'Other';
    dob?: string;
    countryName?: string;
    countryFlag?: string;
    countryCode?: string;
    phone?: string;
    profileTag?: string;
  }) => void;
  onSave?: (updated: {
    name: string;
    username: string;
    avatar: string;
    bio?: string;
    gender?: 'Male' | 'Female' | 'Other';
    dob?: string;
    countryName?: string;
    countryFlag?: string;
    countryCode?: string;
    phone?: string;
    profileTag?: string;
  }) => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSaveProfile,
  onSave
}) => {
  // Resolve initial country
  const initialCountry = useMemo(() => {
    return getCountryByCode(currentUser.countryCode || currentUser.countryName || 'Nepal');
  }, [currentUser.countryCode, currentUser.countryName]);

  const [name, setName] = useState(currentUser.name || '');
  const [username, setUsername] = useState(currentUser.username || '');
  const [avatar, setAvatar] = useState(currentUser.avatar || '');
  const [bio, setBio] = useState(currentUser.bio || 'Live • Laugh • Share ❤️');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>(currentUser.gender || 'Male');
  const [dob, setDob] = useState(currentUser.dob || '2004-05-12');
  
  // Country state with full freedom
  const [countryName, setCountryName] = useState(currentUser.countryName || initialCountry.name);
  const [countryFlag, setCountryFlag] = useState(currentUser.countryFlag || initialCountry.flag);
  const [countryCode, setCountryCode] = useState(currentUser.countryCode || initialCountry.code);

  const [phone, setPhone] = useState(currentUser.phone || '+977 9800000000');
  const [email] = useState(currentUser.email || 'user@diyolive.com');
  const [profileTag, setProfileTag] = useState(currentUser.profileTag || 'DIYO VIP');

  // Searchable Country Picker state
  const [isCountryPickerOpen, setIsCountryPickerOpen] = useState(false);
  const [countrySearch, setCountrySearch] = useState('');

  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter countries based on search query
  const filteredCountries = useMemo(() => {
    if (!countrySearch.trim()) return SUPPORTED_COUNTRIES;
    const q = countrySearch.toLowerCase().trim();
    return SUPPORTED_COUNTRIES.filter(
      c => c.name.toLowerCase().includes(q) || 
           c.code.toLowerCase().includes(q) || 
           c.dialCode.includes(q)
    );
  }, [countrySearch]);

  if (!isOpen) return null;

  const sampleAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80'
  ];

  const handleGalleryFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file (JPG, PNG, WEBP)');
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const result = uploadEvent.target?.result as string;
      if (result) {
        setAvatar(result);
        playSoundFX('win');
      }
      setIsUploading(false);
    };
    reader.onerror = () => {
      setIsUploading(false);
      alert('Failed to read image file');
    };
    reader.readAsDataURL(file);
  };

  const handleTriggerFileInput = () => {
    playSoundFX('click');
    fileInputRef.current?.click();
  };

  const handleSelectCountry = (country: CountryItem) => {
    setCountryName(country.name);
    setCountryFlag(country.flag);
    setCountryCode(country.code);
    setIsCountryPickerOpen(false);
    setCountrySearch('');
    playSoundFX('click');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    playSoundFX('click');

    setTimeout(() => {
      const updatedData = {
        name: name.trim() || currentUser.name,
        username: username.trim() || currentUser.username,
        avatar,
        bio: bio.trim(),
        gender,
        dob,
        countryName,
        countryFlag,
        countryCode,
        phone: phone.trim(),
        profileTag
      };

      if (onSave) onSave(updatedData);
      if (onSaveProfile) onSaveProfile(updatedData);

      setIsSaving(false);
      setSaved(true);
      playSoundFX('win');

      setTimeout(() => {
        setSaved(false);
        onClose();
      }, 900);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-[#0e1635] via-[#091026] to-[#060a19] border border-cyan-500/40 rounded-2xl w-full max-w-md max-h-[88vh] overflow-hidden flex flex-col shadow-2xl shadow-cyan-950/60 relative">
        
        {/* Compact Header */}
        <div className="px-4 py-2.5 border-b border-cyan-900/40 flex items-center justify-between bg-[#0a1430]/90 flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/30">
              <User className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <h2 className="text-xs font-black text-white font-['Outfit'] tracking-wide">EDIT DIYO PROFILE</h2>
              <p className="text-[10px] text-cyan-200/70 leading-none">Update photo, country, nickname & details</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Compact Content */}
        <div className="p-3 sm:p-4 overflow-y-auto flex-1 space-y-2.5">
          
          {saved && (
            <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold flex items-center gap-1.5 animate-in fade-in shadow-md">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Profile & country updated successfully!</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-2.5">
            
            {/* Compact Gallery Upload Section */}
            <div className="p-2.5 rounded-xl bg-[#070e24]/90 border border-cyan-500/30 flex items-center gap-3 shadow-inner">
              <div className="relative flex-shrink-0">
                <div className="w-14 h-14 rounded-full p-0.5 bg-gradient-to-tr from-cyan-400 via-blue-500 to-amber-400 shadow-[0_0_12px_rgba(6,182,212,0.5)]">
                  <img
                    src={avatar}
                    alt="Avatar Preview"
                    className="w-full h-full rounded-full object-cover border border-[#071330]"
                  />
                </div>
                
                {/* Hidden File Input for Device Gallery */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleGalleryFileSelect}
                  accept="image/*"
                  className="hidden"
                />
                
                {/* Camera Overlay */}
                <button
                  type="button"
                  onClick={handleTriggerFileInput}
                  className="absolute -bottom-1 -right-1 p-1 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 text-neutral-950 shadow border border-white cursor-pointer active:scale-95"
                  title="Choose image from device gallery"
                >
                  <Camera className="w-3 h-3" />
                </button>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleTriggerFileInput}
                    disabled={isUploading}
                    className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-cyan-500 via-teal-400 to-blue-500 text-neutral-950 text-[10px] font-black flex items-center gap-1 shadow hover:brightness-110 active:scale-95 transition-all cursor-pointer"
                  >
                    <Upload className="w-3 h-3" />
                    <span>{isUploading ? 'Loading...' : 'Upload Photo'}</span>
                  </button>
                  <span className="text-[9px] text-cyan-200/60 font-medium truncate">JPG, PNG, WEBP</span>
                </div>
                
                {/* Preset Sample Avatars */}
                <div className="flex items-center gap-1.5 mt-1.5 overflow-x-auto py-0.5 scrollbar-none">
                  {sampleAvatars.map((sAv, i) => (
                    <img
                      key={i}
                      src={sAv}
                      alt="Preset"
                      onClick={() => {
                        setAvatar(sAv);
                        playSoundFX('click');
                      }}
                      className={`w-6 h-6 rounded-full object-cover cursor-pointer border flex-shrink-0 transition-all ${
                        avatar === sAv ? 'border-cyan-400 scale-110 ring-1 ring-cyan-400/50' : 'border-neutral-700 opacity-70 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* 2-Column Grid: Display Nickname & Username */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-0.5">
                <label className="text-[10px] font-bold text-slate-300">Display Nickname</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-[#091026] border border-cyan-900/50 text-white text-xs font-bold focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>

              <div className="space-y-0.5">
                <label className="text-[10px] font-bold text-slate-300">Username Handle</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-[#091026] border border-cyan-900/50 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>
            </div>

            {/* Bio / Signature */}
            <div className="space-y-0.5">
              <label className="text-[10px] font-bold text-slate-300">Bio / Signature</label>
              <textarea
                rows={1}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#091026] border border-cyan-900/50 text-white text-xs focus:outline-none focus:border-cyan-400 resize-none"
              />
            </div>

            {/* 2-Column Grid: Gender & Date of Birth */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-0.5">
                <label className="text-[10px] font-bold text-slate-300">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as 'Male' | 'Female' | 'Other')}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-[#091026] border border-cyan-900/50 text-white text-xs font-bold focus:outline-none focus:border-cyan-400"
                >
                  <option value="Male">Male ♂</option>
                  <option value="Female">Female ♀</option>
                  <option value="Other">Other ⚧</option>
                </select>
              </div>

              <div className="space-y-0.5">
                <label className="text-[10px] font-bold text-slate-300 flex items-center gap-1">
                  <Calendar className="w-2.5 h-2.5 text-cyan-400" />
                  <span>Date of Birth</span>
                </label>
                <input
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full px-2 py-1.5 rounded-lg bg-[#091026] border border-cyan-900/50 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            {/* 2-Column Grid: Country Selection (All 195+ Countries) & Mobile Number */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-0.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold text-slate-300 flex items-center gap-1">
                    <Globe className="w-2.5 h-2.5 text-emerald-400" />
                    <span>Country / Region</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsCountryPickerOpen(true);
                      playSoundFX('click');
                    }}
                    className="text-[9px] text-cyan-400 hover:text-cyan-300 font-bold hover:underline cursor-pointer"
                  >
                    All ({SUPPORTED_COUNTRIES.length})
                  </button>
                </div>

                {/* Interactive Clickable Country Button - Opens Searchable Country Picker */}
                <button
                  type="button"
                  onClick={() => {
                    setIsCountryPickerOpen(true);
                    playSoundFX('click');
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-[#091026] border border-cyan-900/60 hover:border-cyan-400 transition-all text-white text-xs font-bold flex items-center justify-between gap-1 cursor-pointer group shadow-inner"
                  title="Click to choose from all 195+ countries"
                >
                  <div className="flex items-center gap-1.5 min-w-0 truncate">
                    <span className="text-base flex-shrink-0">{countryFlag}</span>
                    <span className="truncate text-white group-hover:text-cyan-200">{countryName}</span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0 group-hover:translate-y-0.5 transition-transform" />
                </button>
              </div>

              <div className="space-y-0.5">
                <label className="text-[10px] font-bold text-slate-300 flex items-center gap-1">
                  <Phone className="w-2.5 h-2.5 text-amber-400" />
                  <span>Mobile</span>
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-2 py-1.5 rounded-lg bg-[#091026] border border-cyan-900/50 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            {/* Quick Country Change Hint / Native Dropdown Fallback */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[10px] text-slate-400">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5 text-amber-400" />
                  <span>Quick Dropdown Select:</span>
                </span>
                <span className="text-[9px] font-mono text-cyan-300 font-bold">
                  {countryFlag} {countryName} ({countryCode})
                </span>
              </div>
              <select
                value={countryName}
                onChange={(e) => {
                  const c = SUPPORTED_COUNTRIES.find(item => item.name === e.target.value);
                  if (c) {
                    setCountryName(c.name);
                    setCountryFlag(c.flag);
                    setCountryCode(c.code);
                    playSoundFX('click');
                  }
                }}
                className="w-full px-2 py-1.5 rounded-lg bg-[#060c1e] border border-cyan-900/50 text-white text-xs font-medium focus:outline-none focus:border-cyan-400"
              >
                <optgroup label="⭐ Popular Countries">
                  {POPULAR_COUNTRIES.map((c) => (
                    <option key={`pop-${c.code}`} value={c.name}>
                      {c.flag} {c.name} ({c.dialCode})
                    </option>
                  ))}
                </optgroup>
                <optgroup label="🌍 All World Countries (A-Z)">
                  {SUPPORTED_COUNTRIES.map((c) => (
                    <option key={`all-${c.code}`} value={c.name}>
                      {c.flag} {c.name} ({c.code})
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            {/* Email (Secure) */}
            <div className="space-y-0.5">
              <label className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                <Mail className="w-2.5 h-2.5 text-purple-400" />
                <span>Account Email (Verified)</span>
              </label>
              <input
                type="email"
                value={email}
                disabled
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#091026]/50 border border-cyan-900/30 text-neutral-400 text-xs font-mono cursor-not-allowed"
                title="Secured Account Email (Read-only)"
              />
            </div>

            {/* Save Button */}
            <button
              type="submit"
              disabled={isSaving}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-md shadow-cyan-950/60 cursor-pointer active:scale-98 disabled:opacity-50 mt-1"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                  <span>Saving Profile...</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Profile & Country</span>
                </>
              )}
            </button>
          </form>

        </div>

        {/* ========================================================================= */}
        {/* MODAL / SHEET: SEARCHABLE ALL-COUNTRY PICKER (195+ WORLD COUNTRIES)        */}
        {/* ========================================================================= */}
        {isCountryPickerOpen && (
          <div className="absolute inset-0 z-50 bg-[#070e22] flex flex-col animate-in fade-in duration-200">
            {/* Header */}
            <div className="px-3.5 py-2.5 border-b border-cyan-900/60 flex items-center justify-between bg-[#0b1536] flex-shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Globe className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-white font-['Outfit'] tracking-wide">
                    CHOOSE YOUR COUNTRY
                  </h3>
                  <p className="text-[10px] text-cyan-200/70">
                    All {SUPPORTED_COUNTRIES.length} sovereign countries & regions
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCountryPickerOpen(false)}
                className="w-6 h-6 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 flex items-center justify-center cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Search Input Bar */}
            <div className="p-2.5 border-b border-cyan-900/30 bg-[#081028] flex-shrink-0 space-y-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-cyan-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={countrySearch}
                  onChange={(e) => setCountrySearch(e.target.value)}
                  placeholder="Search country, code or dial code (e.g. Nepal, NP, +977)..."
                  className="w-full pl-8 pr-7 py-1.5 rounded-lg bg-[#040815] border border-cyan-500/40 text-white text-xs placeholder:text-neutral-500 focus:outline-none focus:border-cyan-400 font-medium"
                  autoFocus
                />
                {countrySearch && (
                  <button
                    type="button"
                    onClick={() => setCountrySearch('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Popular Quick-Picks Chips */}
              {!countrySearch && (
                <div className="space-y-1">
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5 text-amber-400" />
                    <span>Popular Quick Select:</span>
                  </span>
                  <div className="flex flex-wrap gap-1 max-h-16 overflow-y-auto py-0.5 scrollbar-none">
                    {POPULAR_COUNTRIES.map((pop) => (
                      <button
                        key={`chip-${pop.code}`}
                        type="button"
                        onClick={() => handleSelectCountry(pop)}
                        className={`px-2 py-1 rounded-md text-[10px] font-bold flex items-center gap-1 border transition-all cursor-pointer ${
                          countryCode === pop.code
                            ? 'bg-cyan-500 text-neutral-950 border-cyan-300 font-black shadow-sm'
                            : 'bg-[#0e1a3d] hover:bg-[#152554] text-slate-200 border-cyan-900/60'
                        }`}
                      >
                        <span>{pop.flag}</span>
                        <span>{pop.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Scrollable Country List */}
            <div className="flex-1 overflow-y-auto p-2 space-y-1 divide-y divide-cyan-950/40">
              {filteredCountries.length === 0 ? (
                <div className="p-6 text-center space-y-2">
                  <p className="text-xs text-neutral-400">No country found matching "{countrySearch}"</p>
                  <button
                    type="button"
                    onClick={() => setCountrySearch('')}
                    className="text-[11px] font-bold text-cyan-400 hover:underline cursor-pointer"
                  >
                    Clear Search
                  </button>
                </div>
              ) : (
                filteredCountries.map((c) => {
                  const isSelected = countryCode === c.code || countryName.toLowerCase() === c.name.toLowerCase();
                  return (
                    <button
                      key={c.code}
                      type="button"
                      onClick={() => handleSelectCountry(c)}
                      className={`w-full px-3 py-2 rounded-xl flex items-center justify-between text-left transition-all cursor-pointer group pt-1.5 ${
                        isSelected 
                          ? 'bg-gradient-to-r from-cyan-950/80 to-blue-950/60 border border-cyan-400/80 shadow-md'
                          : 'hover:bg-cyan-950/30 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="text-xl flex-shrink-0 filter drop-shadow-sm">{c.flag}</span>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className={`text-xs font-bold truncate ${isSelected ? 'text-cyan-200 font-black' : 'text-slate-100 group-hover:text-cyan-300'}`}>
                              {c.name}
                            </span>
                            <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-neutral-800 text-neutral-300">
                              {c.code}
                            </span>
                          </div>
                          <span className="text-[9px] font-mono text-cyan-400/80 block">
                            Dial: {c.dialCode} • {c.currency}
                          </span>
                        </div>
                      </div>

                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-cyan-400 text-neutral-950 flex items-center justify-center flex-shrink-0 shadow">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })
              )}
            </div>

            {/* Bottom bar inside picker */}
            <div className="p-2 border-t border-cyan-900/40 bg-[#060c1e] flex items-center justify-between text-[10px] text-neutral-400 px-3">
              <span>Showing {filteredCountries.length} countries</span>
              <button
                type="button"
                onClick={() => setIsCountryPickerOpen(false)}
                className="font-bold text-cyan-400 hover:underline cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
