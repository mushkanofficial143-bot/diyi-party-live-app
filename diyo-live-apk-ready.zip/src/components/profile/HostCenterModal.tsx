import React, { useState } from 'react';
import { X, Mic2, Video, Clock, Gem, Users, Award, ShieldCheck, PlayCircle, BarChart3, AlertCircle, Sparkles, Crown, Lock } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { HostTagType } from '../../types/ownerTypes';
import { HOST_TYPE_DEFINITIONS } from '../../data/mockOwnerData';
import { HostTagBadge } from '../HostTagBadge';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';

interface HostCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGoLiveClick: () => void;
  hostTag?: HostTagType | string;
  avatarUrl?: string;
  hostName?: string;
  currentUser?: any;
  hasApprovedAgency?: boolean;
  onOpenAgencyJoin?: () => void;
}

export const HostCenterModal: React.FC<HostCenterModalProps> = ({
  isOpen,
  onClose,
  onGoLiveClick,
  hostTag,
  avatarUrl,
  hostName,
  currentUser,
  hasApprovedAgency = false,
  onOpenAgencyJoin
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'tasks' | 'earnings'>('overview');

  if (!isOpen) return null;

  const resolvedName = hostName || currentUser?.name || currentUser?.username || 'Host Broadcaster';
  const resolvedAvatar = avatarUrl || currentUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150';
  const resolvedTag = hostTag || currentUser?.hostTag || (currentUser?.role === 'HOST' ? 'VIP_HOST' : 'NEW_HOST');

  const currentHostType = HOST_TYPE_DEFINITIONS.find(t => t.tag === resolvedTag) || HOST_TYPE_DEFINITIONS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-emerald-500/30 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl shadow-emerald-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-600 via-emerald-600 to-amber-500 flex items-center justify-center text-white shadow-lg">
              <Mic2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white">HOST CREATOR CENTER</h2>
                <HostTagBadge tag={hostTag} size="xs" glow={true} />
              </div>
              <p className="text-xs text-neutral-400">Live Analytics, Diamond Targets & Commission Tier</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          
          {/* Host Type & Frame Showcase Banner */}
          <div className={`p-4 rounded-2xl border ${currentHostType.badgeBorder} ${currentHostType.badgeBg} flex items-center justify-between gap-4 flex-wrap shadow-lg`}>
            <div className="flex items-center gap-3.5">
              <HostAvatarWithFrame
                avatarUrl={resolvedAvatar}
                hostTag={resolvedTag}
                size="lg"
              />
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-white text-sm">{resolvedName}</span>
                  <HostTagBadge tag={resolvedTag} size="sm" glow={true} />
                </div>
                <p className="text-xs text-neutral-300 mt-0.5">{currentHostType.description}</p>
                <div className="flex items-center gap-3 text-[10px] text-neutral-400 mt-1.5">
                  <span className="text-amber-300 font-bold">Frame: {currentHostType.frameName}</span>
                  <span>•</span>
                  <span className="text-emerald-400 font-bold">Split: {currentHostType.commissionRateDefault}%</span>
                </div>
              </div>
            </div>

            <div className="bg-black/40 px-3 py-1.5 rounded-xl border border-white/10 text-right">
              <span className="text-[9px] text-neutral-400 font-bold uppercase block flex items-center gap-1 justify-end">
                <Lock className="w-2.5 h-2.5" /> Governance
              </span>
              <span className="text-[10px] text-neutral-300 font-semibold">Assigned by Owner/Admin</span>
            </div>
          </div>

          {/* Quick Metrics Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-1">
              <span className="text-[10px] text-neutral-400 font-bold uppercase flex items-center gap-1">
                <Clock className="w-3 h-3 text-emerald-400" /> Live Duration
              </span>
              <p className="text-lg font-black text-white font-mono">42.5 hrs</p>
              <span className="text-[10px] text-emerald-400">Target: 40 hrs (Met)</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-1">
              <span className="text-[10px] text-neutral-400 font-bold uppercase flex items-center gap-1">
                <Gem className="w-3 h-3 text-rose-400" /> Diamonds
              </span>
              <p className="text-lg font-black text-rose-400 font-mono">245,000</p>
              <span className="text-[10px] text-neutral-400">Est: $245.00 USD</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-1">
              <span className="text-[10px] text-neutral-400 font-bold uppercase flex items-center gap-1">
                <Users className="w-3 h-3 text-amber-400" /> Peak Viewers
              </span>
              <p className="text-lg font-black text-white font-mono">3,840</p>
              <span className="text-[10px] text-amber-400">+18% this week</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-1">
              <span className="text-[10px] text-neutral-400 font-bold uppercase flex items-center gap-1">
                <Award className="w-3 h-3 text-yellow-400" /> Agency Split
              </span>
              <p className="text-lg font-black text-yellow-400 font-mono">{currentHostType.commissionRateDefault}% Net</p>
              <span className="text-[10px] text-neutral-400">Starlight Guild</span>
            </div>
          </div>

          {/* Action Go Live Banner */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950 via-neutral-900 to-amber-950/40 border border-emerald-500/40 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <h3 className="text-sm font-black text-white flex items-center gap-2 justify-center sm:justify-start">
                <Video className="w-4 h-4 text-emerald-400" /> Start Live Broadcast Studio
              </h3>
              <p className="text-xs text-neutral-300">
                Go live in 4K UHD with AV1 ultra-low latency, virtual gift alerts, and interactive polls.
              </p>
            </div>

            <button
              onClick={() => {
                onClose();
                onGoLiveClick();
              }}
              className={`px-6 py-3 rounded-xl font-black text-xs uppercase tracking-wider shadow-lg flex items-center gap-2 flex-shrink-0 cursor-pointer transition-all ${
                hasApprovedAgency
                  ? 'bg-gradient-to-r from-emerald-600 via-teal-600 to-amber-500 hover:from-emerald-500 hover:to-amber-400 text-white shadow-emerald-950/50'
                  : 'bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-500 hover:to-rose-500 text-white shadow-amber-950/50'
              }`}
            >
              {hasApprovedAgency ? (
                <>
                  <PlayCircle className="w-4 h-4 fill-white" />
                  <span>Launch Studio</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Agency Required to Go Live</span>
                </>
              )}
            </button>
          </div>

          {/* Host Policies & Safety notice */}
          <div className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-neutral-200 font-bold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Host Contract & Governance Rules
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              • Host Type and Frame are locked to Owner / Admin governance. Regular hosts cannot alter their assigned classification.
              <br />• Minimum monthly broadcast requirement: 40 active stream hours across at least 15 active calendar days.
              <br />• Agency support manager: <strong>Rahul Verma (Starlight Media)</strong>
              <br />• All diamond balances are virtual test credits in test mode.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};
