import React, { useState } from 'react';
import { 
  X, 
  Award, 
  Zap, 
  Sparkles, 
  Trophy, 
  Check, 
  ShieldCheck, 
  ChevronRight,
  TrendingUp,
  Star,
  Crown
} from 'lucide-react';
import { LevelSettings, LevelConfigItem } from '../../types/ownerTypes';
import { DEFAULT_LEVELS_CONFIG } from '../../data/platformFeaturesData';

interface LevelModalProps {
  isOpen: boolean;
  onClose: () => void;
  userLevel?: number;
  userXp?: number;
  currentUser?: any;
  levelConfig?: LevelSettings;
  onLevelUp?: (newLevel: number) => void;
}

export const LevelModal: React.FC<LevelModalProps> = ({ 
  isOpen, 
  onClose, 
  userLevel,
  userXp = 48500,
  currentUser,
  levelConfig = DEFAULT_LEVELS_CONFIG,
  onLevelUp
}) => {
  const effectiveLevel = typeof userLevel === 'number' ? userLevel : (currentUser?.userLevel ?? 24);
  const [activeTab, setActiveTab] = useState<'PROGRESS' | 'TIERS' | 'SIMULATOR'>('PROGRESS');
  const [simulatedLevel, setSimulatedLevel] = useState<number>(effectiveLevel);
  const [simulatedXp, setSimulatedXp] = useState<number>(userXp);
  const [showLevelUpToast, setShowLevelUpToast] = useState<boolean>(false);

  if (!isOpen) return null;

  const safeLevels = Array.isArray(levelConfig?.levels) && levelConfig.levels.length > 0
    ? levelConfig.levels
    : DEFAULT_LEVELS_CONFIG.levels;

  const currentLevelConfig = safeLevels.find(l => l.level === simulatedLevel) || safeLevels[0];
  const nextLevelConfig = safeLevels.find(l => l.level === simulatedLevel + 1);

  const requiredExpNext = nextLevelConfig ? nextLevelConfig.requiredXp : currentLevelConfig.requiredXp;
  const currentExpInLevel = simulatedXp % requiredExpNext;
  const progressPercent = Math.min(100, Math.round((currentExpInLevel / requiredExpNext) * 100));

  // Tiers breakdown
  const tiers = [
    { name: 'Imperial Supreme', range: 'Lv. 96–100', icon: '👑', color: 'from-yellow-400 to-amber-600', perk: 'Supreme Host Seat, Holographic Avatar Frame, 2.0x Boost' },
    { name: 'Mythic Overlord', range: 'Lv. 86–95', icon: '🌌', color: 'from-purple-600 to-indigo-600', perk: 'Custom 3D Room Entrance Sound & Ultra Badge' },
    { name: 'Grandmaster', range: 'Lv. 71–85', icon: '⚔️', color: 'from-rose-600 to-orange-600', perk: 'VIP Lounge Priority Speaker Access' },
    { name: 'Diamond Vanguard', range: 'Lv. 56–70', icon: '💎', color: 'from-cyan-500 to-blue-600', perk: 'Exclusive Animated Diamond Chat Frame' },
    { name: 'Platinum Paladin', range: 'Lv. 41–55', icon: '🛡️', color: 'from-slate-300 to-slate-500', perk: 'Speaker Seat Priority & Room Kick Immunity' },
    { name: 'Gold Champion', range: 'Lv. 26–40', icon: '🥇', color: 'from-yellow-500 to-amber-600', perk: 'Golden Username Highlight & Audio Lounge Fast Pass' },
    { name: 'Silver Knight', range: 'Lv. 11–25', icon: '🥈', color: 'from-neutral-400 to-slate-400', perk: 'Silver Flame Entrance Effect' },
    { name: 'Bronze Explorer', range: 'Lv. 1–10', icon: '🥉', color: 'from-amber-700 to-amber-900', perk: 'Basic Member Tag & Standard Reactions' },
  ];

  const handleSimulateGainXp = (amount: number) => {
    const newXp = simulatedXp + amount;
    setSimulatedXp(newXp);

    // Calculate new level based on cumulative XP
    let newLvl = 1;
    for (const lvl of levelConfig.levels) {
      if (newXp >= lvl.cumulativeXp) {
        newLvl = Math.min(100, lvl.level + 1);
      }
    }

    if (newLvl > simulatedLevel) {
      setSimulatedLevel(newLvl);
      setShowLevelUpToast(true);
      if (onLevelUp) onLevelUp(newLvl);
      setTimeout(() => setShowLevelUpToast(false), 3500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div 
        id="level-system-modal-container"
        className="bg-neutral-900 border border-amber-500/30 rounded-3xl w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl text-neutral-100"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-neutral-950 via-neutral-900 to-neutral-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-xl shadow-lg shadow-amber-500/20">
              {currentLevelConfig.badgeIcon}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white tracking-wide">LEVEL SYSTEM (1–100)</h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  XP PROGRESSION
                </span>
              </div>
              <p className="text-xs text-neutral-400">{currentLevelConfig.title}</p>
            </div>
          </div>
          <button
            id="close-level-modal-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Level Up Celebration Banner */}
        {showLevelUpToast && (
          <div className="px-6 py-3 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-neutral-950 flex items-center justify-between animate-bounce font-black text-xs shadow-lg">
            <span className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              🎉 LEVEL UP! You reached Level {simulatedLevel} ({currentLevelConfig.title})!
            </span>
            <span className="bg-black/20 px-2 py-0.5 rounded text-[11px]">Privileges Unlocked</span>
          </div>
        )}

        {/* Tabs */}
        <div className="flex border-b border-neutral-800 bg-neutral-950/60 px-6 pt-2 gap-2">
          <button
            id="level-tab-progress"
            onClick={() => setActiveTab('PROGRESS')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'PROGRESS'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            My Progress
          </button>
          <button
            id="level-tab-tiers"
            onClick={() => setActiveTab('TIERS')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'TIERS'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            All 100 Tiers & Perks
          </button>
          <button
            id="level-tab-simulator"
            onClick={() => setActiveTab('SIMULATOR')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'SIMULATOR'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            XP Test Simulator
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'PROGRESS' && (
            <>
              {/* Level Hero Card */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-neutral-900 to-yellow-950/30 border border-amber-500/30 space-y-4 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-yellow-500/10 border-2 border-amber-400 text-2xl font-black text-amber-300 shadow-xl shadow-amber-500/20">
                  Lv.{simulatedLevel}
                </div>
                <div>
                  <h3 className="text-base font-black text-white">{currentLevelConfig.title}</h3>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Total XP: <strong className="text-amber-300 font-mono">{(simulatedXp ?? 0).toLocaleString()} XP</strong>
                  </p>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1.5 text-left">
                  <div className="flex justify-between text-xs text-neutral-400">
                    <span>Progress to Level {Math.min(100, simulatedLevel + 1)}</span>
                    <span className="font-mono text-amber-300 font-bold">{progressPercent}%</span>
                  </div>
                  <div className="w-full bg-neutral-800 h-2.5 rounded-full overflow-hidden p-0.5 border border-neutral-700">
                    <div
                      className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-500"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-neutral-500">
                    <span>{(currentExpInLevel ?? 0).toLocaleString()} XP</span>
                    <span>{(requiredExpNext ?? 0).toLocaleString()} XP needed</span>
                  </div>
                </div>

                {/* Active Perks */}
                <div className="p-3 bg-neutral-950/80 rounded-xl border border-neutral-800 text-left text-xs space-y-1.5">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400">Active Unlocked Privilege</div>
                  <p className="text-neutral-200">{currentLevelConfig.perk}</p>
                </div>
              </div>

              {/* Quick Roadmap */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Upcoming Milestones</span>
                <div className="space-y-2">
                  {safeLevels
                    .filter(l => l.level === 10 || l.level === 25 || l.level === 50 || l.level === 75 || l.level === 100)
                    .map((milestone) => (
                      <div
                        key={milestone.level}
                        className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                          simulatedLevel >= milestone.level
                            ? 'bg-neutral-900 border-amber-500/30 text-white'
                            : 'bg-neutral-950/50 border-neutral-900 text-neutral-500'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <span className={`px-2 py-0.5 rounded font-mono font-bold text-[11px] ${
                            simulatedLevel >= milestone.level
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-neutral-800 text-neutral-500'
                          }`}>
                            Lv.{milestone.level}
                          </span>
                          <div>
                            <span className="font-semibold text-neutral-200">{milestone.title}</span>
                            <p className="text-[11px] text-neutral-400">{milestone.perk}</p>
                          </div>
                        </div>
                        {simulatedLevel >= milestone.level ? (
                          <span className="text-emerald-400 font-bold text-[10px] px-2 py-1 bg-emerald-950 rounded border border-emerald-800">
                            UNLOCKED ✓
                          </span>
                        ) : (
                          <span className="text-neutral-600 font-mono text-[11px]">
                            {((milestone?.cumulativeXp) ?? 0).toLocaleString()} XP
                          </span>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            </>
          )}

          {activeTab === 'TIERS' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                1–100 Level Privilege Tiers
              </h4>
              <div className="space-y-2.5">
                {tiers.map((tier, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 bg-neutral-950/80 border border-neutral-800 rounded-xl flex items-center justify-between gap-3 hover:border-neutral-700 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{tier.icon}</div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-xs">{tier.name}</span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-900 border border-neutral-700 text-amber-300">
                            {tier.range}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-400 mt-0.5">{tier.perk}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'SIMULATOR' && (
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-br from-neutral-950 to-neutral-900 border border-amber-500/30 rounded-2xl space-y-3">
                <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Test Mode Level-Up Simulator
                </h4>
                <p className="text-xs text-neutral-400">
                  Simulate spending TEST COINS or earning XP to test level progression, milestone unlocking, and live level-up animations.
                </p>

                <div className="grid grid-cols-3 gap-2 pt-2">
                  <button
                    onClick={() => handleSimulateGainXp(5000)}
                    className="p-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    +5,000 XP (50K TC)
                  </button>
                  <button
                    onClick={() => handleSimulateGainXp(25000)}
                    className="p-2.5 bg-neutral-800 hover:bg-neutral-700 text-amber-300 rounded-xl text-xs font-bold transition-colors"
                  >
                    +25,000 XP (250K TC)
                  </button>
                  <button
                    onClick={() => handleSimulateGainXp(100000)}
                    className="p-2.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-xl text-xs font-bold transition-colors"
                  >
                    +100,000 XP (1M TC)
                  </button>
                </div>

                <div className="flex justify-between items-center text-xs pt-2 border-t border-neutral-800">
                  <span className="text-neutral-400">Current Level in Simulator:</span>
                  <span className="font-bold text-amber-300">Level {simulatedLevel} / 100</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
