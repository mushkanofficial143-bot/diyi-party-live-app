import React, { useState } from 'react';
import { 
  Folder, 
  Tv, 
  Users, 
  UserCheck, 
  ShieldCheck, 
  ChevronRight, 
  Coins, 
  Gem, 
  Shield, 
  ShoppingBag, 
  Award, 
  Star, 
  Moon, 
  Trophy,
  Sparkles,
  Settings,
  Crown,
  Share2,
  Briefcase,
  Heart,
  Send,
  Zap,
  ArrowRight,
  Flame,
  Medal,
  CheckCircle2,
  Lock,
  Layers,
  Palette,
  Building2
} from 'lucide-react';
import { UserAccount, VipTierConfig, WalletTransaction, UserRole, PlatformWalletSettings } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

// Sub-modals
import { EditProfileModal } from './EditProfileModal';
import { WalletModal } from './WalletModal';
import { StoreModal } from './StoreModal';
import { HostCenterModal } from './HostCenterModal';
import { LevelModal } from './LevelModal';
import { SettingsModal } from './SettingsModal';
import { InviteModal } from './InviteModal';
import { RewardModal } from './RewardModal';
import { VipUpgradeModal } from './VipUpgradeModal';
import { GuardianModal } from './GuardianModal';
import { FanClubModal } from './FanClubModal';
import { OrdersModal } from './OrdersModal';
import { AgencyModal } from './AgencyModal';
import { SellerModal } from './SellerModal';
import { VerificationModal } from './VerificationModal';
import { SpecialIdModal } from './SpecialIdModal';
import { BadgeTagsShowcase } from '../badges/BadgeTagsShowcase';
import { SRLiveProfileHeader } from './SRLiveProfileHeader';
import { AvatarFrameSelectorModal } from './AvatarFrameSelectorModal';
import { BagModal } from './BagModal';
import { MedalWallModal } from './MedalWallModal';
import { CpModal } from './CpModal';
import { UserProfileCardModal } from './UserProfileCardModal';

interface ProfileScreenProps {
  currentUser: UserAccount;
  vipConfigs: VipTierConfig[];
  transactions: WalletTransaction[];
  currentRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  onOpenOwnerPanel: () => void;
  onGoLiveClick: () => void;
  onUpdateUserBalance: (newCoins: number, newDiamonds: number) => void;
  onUpdateUserProfile: (updated: { 
    name: string; 
    username: string; 
    avatar: string; 
    bio?: string; 
    gender?: 'Male' | 'Female' | 'Other';
    dob?: string;
    countryCode?: string; 
    countryFlag?: string; 
    countryName?: string;
    phone?: string;
    profileTag?: string;
  }) => void;
  onUpgradeVip: (level: number) => void;
  onEquipAvatarFrame?: (frameId: string, frameUrl?: string, roleType?: any, hostTag?: string) => void;
  onTransferCoins?: (recipientId: string, amount: number, notes?: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  onExchangeCoins?: (amount: number) => Promise<{ success: boolean; error?: string; message?: string }>;
  walletSettings?: PlatformWalletSettings;
  platformUsers?: any[];
  agencies?: any[];
  agencyJoinRequests?: any[];
  onUpdateAgencyRequests?: (reqs: any[]) => void;
  onUpdateUserAgencyMembership?: (membership: any) => void;
  onAddAuditLog?: (log: any) => void;
  onAddNotification?: (notif: any) => void;
  hasApprovedAgency?: boolean;
  onNavigateTab?: (tab: string) => void;
  onLogout?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  currentUser,
  vipConfigs,
  transactions,
  currentRole,
  onChangeRole,
  onOpenOwnerPanel,
  onGoLiveClick,
  onUpdateUserBalance,
  onUpdateUserProfile,
  onUpgradeVip,
  onEquipAvatarFrame,
  onTransferCoins,
  onExchangeCoins,
  walletSettings,
  platformUsers,
  agencies = [],
  agencyJoinRequests = [],
  onUpdateAgencyRequests = () => {},
  onUpdateUserAgencyMembership = () => {},
  onAddAuditLog = () => {},
  onAddNotification = () => {},
  hasApprovedAgency = false,
  onNavigateTab,
  onLogout
}) => {
  // Modal states
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [walletDefaultTab, setWalletDefaultTab] = useState<'RECHARGE' | 'EXCHANGE' | 'WITHDRAW'>('RECHARGE');
  const [isStoreOpen, setIsStoreOpen] = useState(false);
  const [isLevelOpen, setIsLevelOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isVipModalOpen, setIsVipModalOpen] = useState(false);
  const [isHostCenterOpen, setIsHostCenterOpen] = useState(false);
  const [isGuardianOpen, setIsGuardianOpen] = useState(false);
  const [isFanClubOpen, setIsFanClubOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isAgencyOpen, setIsAgencyOpen] = useState(false);
  const [isSellerOpen, setIsSellerOpen] = useState(false);
  const [isVerificationOpen, setIsVerificationOpen] = useState(false);
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [isSpecialIdOpen, setIsSpecialIdOpen] = useState(false);
  const [isBadgeModalOpen, setIsBadgeModalOpen] = useState(false);

  // New Modals
  const [isAvatarFrameModalOpen, setIsAvatarFrameModalOpen] = useState(false);
  const [isBagModalOpen, setIsBagModalOpen] = useState(false);
  const [isMedalModalOpen, setIsMedalModalOpen] = useState(false);
  const [isCpModalOpen, setIsCpModalOpen] = useState(false);
  const [isProfileCardModalOpen, setIsProfileCardModalOpen] = useState(false);

  const activeUserId = currentUser.id.replace('USR-', '') || '148830743';
  const userRoleRaw = (currentUser.role || '').toUpperCase();
  const isOwner = userRoleRaw === 'OWNER' || currentUser.email === 'salamstarhotel@gmail.com' || currentUser.id === '0000001' || currentUser.id === 'OWNER-001';
  const isManager = userRoleRaw === 'MANAGER';
  const isSuperAdmin = userRoleRaw === 'SUPER_ADMIN' || userRoleRaw === 'SUPER ADMIN';
  const isAdmin = userRoleRaw === 'ADMIN' || (currentUser as any).roleTag === 'ADMIN';
  const isOfficial = userRoleRaw === 'OFFICIAL' || (currentUser as any).roleTag === 'OFFICIAL';
  const isBdAdmin = userRoleRaw === 'ADMIN_BD' || userRoleRaw === 'BD_ADMIN' || userRoleRaw === 'BD ADMIN' || userRoleRaw === 'SUPER BD';
  const isAgency = userRoleRaw === 'AGENCY' || (currentUser as any).isAgency;
  const isCoinSeller = userRoleRaw === 'COIN_SELLER' || (currentUser as any).coinSeller;
  const isHost = userRoleRaw === 'HOST' || (currentUser as any).isHost;
  const hasOfficialTag = Boolean(
    isOwner ||
    isManager ||
    isSuperAdmin ||
    isAdmin ||
    isOfficial ||
    isBdAdmin ||
    isAgency ||
    isCoinSeller ||
    isHost ||
    currentUser.roleTag ||
    currentUser.hostTag ||
    (currentUser as any).assignedRoleTag
  );

  const handleOpenWalletTopUp = () => {
    playSoundFX('click');
    setWalletDefaultTab('RECHARGE');
    setIsWalletOpen(true);
  };

  const handleOpenPointsExchange = () => {
    playSoundFX('click');
    setWalletDefaultTab('EXCHANGE');
    setIsWalletOpen(true);
  };

  // Calculate Level EXP & progress
  const userLevel = currentUser.userLevel ?? 1;
  const currentExp = 350;
  const targetExp = 1000;
  const expPercentage = Math.min(100, Math.round((currentExp / targetExp) * 100));

  return (
    <div className="w-full max-w-md md:max-w-lg mx-auto flex flex-col pb-28 pt-1 text-white select-none animate-in fade-in bg-[#070b16] min-h-screen relative overflow-hidden">
      
      {/* FUTURISTIC NEON CIRCUIT LINE ACCENTS & DEEP NAVY BLUE GLOW */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Deep Navy Radial Backdrop */}
        <div className="absolute top-0 inset-x-0 h-96 bg-[radial-gradient(ellipse_at_top,#0e2042_0%,#081226_45%,transparent_80%)]" />
        <div className="absolute -top-32 -left-32 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-48 -right-32 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
        
        {/* Realistic Cyber Circuit Boards & Neon Lines as in Screenshot */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.14] text-cyan-400 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="neonGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" strokeOpacity="0.4" />
            </pattern>
            <linearGradient id="neonBeamCyan" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#6366f1" stopOpacity="0.1" />
            </linearGradient>
            <linearGradient id="neonBeamMagenta" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ec4899" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.2" />
            </linearGradient>
          </defs>
          <rect width="100%" height="100%" fill="url(#neonGrid)" />
          
          {/* Vertical Circuit Lines with 45-degree angle turns and nodes */}
          <path d="M 60 0 L 60 220 L 90 250 L 90 480 L 120 510 L 120 750" fill="none" stroke="url(#neonBeamCyan)" strokeWidth="1.2" />
          <circle cx="60" cy="220" r="3" fill="#38bdf8" />
          <circle cx="90" cy="480" r="2.5" fill="#38bdf8" />
          <circle cx="120" cy="750" r="3" fill="#38bdf8" />

          <path d="M 280 0 L 280 180 L 250 210 L 250 420 L 290 460 L 290 800" fill="none" stroke="url(#neonBeamCyan)" strokeWidth="1.2" />
          <circle cx="280" cy="180" r="2.5" fill="#06b6d4" />
          <circle cx="250" cy="420" r="3" fill="#06b6d4" />

          <path d="M 380 100 L 380 320 L 340 360 L 340 600 L 360 620 L 360 900" fill="none" stroke="url(#neonBeamMagenta)" strokeWidth="1.2" />
          <circle cx="380" cy="320" r="2.5" fill="#ec4899" />
          <circle cx="340" cy="600" r="2.5" fill="#ec4899" />

          <path d="M 20 300 L 40 320 L 40 600 L 20 620 L 20 850" fill="none" stroke="url(#neonBeamCyan)" strokeWidth="1" />
          <circle cx="40" cy="600" r="2" fill="#38bdf8" />
        </svg>

        {/* Ambient Top Glow Line */}
        <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent" />
      </div>
      
      <div className="relative z-10 space-y-3 pb-8 pt-1">
      
        {/* 1. TOP PROFILE HEADER (Dynamic & High-End) */}
        <div className="px-3 sm:px-4">
          <SRLiveProfileHeader
            username={currentUser.name || 'Diyo live'}
            userId={activeUserId === '148830743' ? '0000001' : activeUserId}
            countryFlag={currentUser.countryFlag || '🇳🇵'}
            countryCode={currentUser.countryCode || 'NP'}
            countryName={currentUser.countryName || 'Nepal'}
            bio={currentUser.bio || 'DIYO LIVE Supreme Owner & Founder'}
            avatarUrl={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600'}
            avatarFrameId={currentUser.avatarFrameId}
            avatarFrameUrl={currentUser.avatarFrameUrl}
            followersCount={currentUser.followersCount ?? 0}
            followingCount={currentUser.followingCount ?? 0}
            friendsCount={12}
            visitorsCount={'1.4K'}
            vipLevel={typeof currentUser.vipLevel === 'number' ? currentUser.vipLevel : 0}
            userLevel={typeof currentUser.userLevel === 'number' ? currentUser.userLevel : 0}
            gender={currentUser.gender || 'Male'}
            age={currentUser.age || 22}
            role={currentUser.role || 'USER'}
            roleTitle={currentUser.roleTitle}
            hostTag={currentUser.hostTag}
            onEditProfile={() => setIsEditProfileOpen(true)}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenVipModal={() => setIsVipModalOpen(true)}
            onOpenLevelModal={() => setIsLevelOpen(true)}
            onOpenFollowers={() => setIsFanClubOpen(true)}
            onOpenFollowing={() => setIsGuardianOpen(true)}
            onOpenFriends={() => setIsGuardianOpen(true)}
            onOpenVisitors={() => setIsFanClubOpen(true)}
            onOpenFrames={() => setIsAvatarFrameModalOpen(true)}
            onOpenShareCard={() => setIsProfileCardModalOpen(true)}
            onUpdateAvatar={(newAvatarUrl) => {
              onUpdateUserProfile({
                name: currentUser.name,
                username: currentUser.username,
                avatar: newAvatarUrl,
                bio: currentUser.bio,
                countryCode: currentUser.countryCode,
                countryFlag: currentUser.countryFlag,
                countryName: currentUser.countryName
              });
            }}
          />
        </div>

        {/* 2. ROYAL WALLET VAULT CARDS (Futuristic Neon Glassmorphic Styling) */}
        <div className="px-3 sm:px-4">
          <div className="grid grid-cols-2 gap-2.5">
            
            {/* Test Coin Vault Card */}
            <div 
              onClick={handleOpenWalletTopUp}
              className="relative overflow-hidden p-2.5 sm:p-3 rounded-2xl bg-gradient-to-br from-[#181926]/80 via-[#101422]/90 to-[#0c0f1d]/95 border border-amber-500/40 hover:border-amber-400/70 shadow-[0_8px_20px_rgba(0,0,0,0.5),0_0_15px_rgba(245,158,11,0.15)] backdrop-blur-xl cursor-pointer transition-all flex flex-col justify-between group"
            >
              {/* Radial Coin Aura & Glass Highlight */}
              <div className="absolute -top-10 -right-10 w-24 h-24 bg-amber-500/20 rounded-full blur-xl pointer-events-none" />
              <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />

              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-[0_0_10px_rgba(245,158,11,0.3)]">
                    <Coins className="w-3 h-3 text-amber-400 animate-spin-slow" />
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-300">
                    Test Coins
                  </span>
                </div>
                <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40 shadow-sm">
                  Vault
                </span>
              </div>

              <div className="mb-1.5">
                <div className="text-base sm:text-lg font-black font-['Outfit'] text-amber-200 tracking-tight leading-tight drop-shadow-[0_2px_8px_rgba(245,158,11,0.3)]">
                  {(currentUser.coinBalance ?? 0).toLocaleString()}
                </div>
              </div>

              <div className="flex items-center gap-1 pt-0.5">
                <button 
                  onClick={(e) => { e.stopPropagation(); handleOpenWalletTopUp(); }}
                  className="flex-1 py-1 px-1.5 rounded-lg bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-neutral-950 text-[10px] font-black shadow-[0_0_10px_rgba(245,158,11,0.4)] flex items-center justify-center gap-1 transition-transform active:scale-95"
                >
                  <span>+ Top Up</span>
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); handleOpenWalletTopUp(); }}
                  className="py-1 px-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-neutral-300 text-[10px] font-bold border border-white/15 flex items-center justify-center transition-all backdrop-blur-md"
                  title="Send Coins"
                >
                  <Send className="w-2.5 h-2.5" />
                </button>
              </div>
            </div>

            {/* Diamonds Revenue Card */}
            <div 
              onClick={handleOpenPointsExchange}
              className="relative overflow-hidden p-2.5 sm:p-3 rounded-2xl bg-gradient-to-br from-[#12192e]/80 via-[#0d1426]/90 to-[#080d1a]/95 border border-cyan-500/40 hover:border-cyan-400/70 shadow-[0_8px_20px_rgba(0,0,0,0.5),0_0_15px_rgba(6,182,212,0.15)] backdrop-blur-xl cursor-pointer transition-all flex flex-col justify-between group"
            >
              {/* Radial Gem Aura & Glass Highlight */}
              <div className="absolute -top-10 -right-10 w-24 h-24 bg-cyan-500/20 rounded-full blur-xl pointer-events-none" />
              <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/40 to-transparent" />

              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
                    <Gem className="w-3 h-3 text-cyan-400" />
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-cyan-300">
                    Diamonds
                  </span>
                </div>
                <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40 shadow-sm">
                  Revenue
                </span>
              </div>

              <div className="mb-1.5">
                <div className="text-base sm:text-lg font-black font-['Outfit'] text-cyan-200 tracking-tight leading-tight drop-shadow-[0_2px_8px_rgba(6,182,212,0.3)]">
                  {(currentUser.diamondBalance ?? 0).toLocaleString()}
                </div>
              </div>

              <div className="flex items-center gap-1 pt-0.5">
                <button 
                  onClick={(e) => { e.stopPropagation(); handleOpenPointsExchange(); }}
                  className="flex-1 py-1 px-1.5 rounded-lg bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-[10px] font-black shadow-[0_0_10px_rgba(6,182,212,0.4)] flex items-center justify-center gap-1 transition-transform active:scale-95"
                >
                  <span>Exchange</span>
                  <ChevronRight className="w-2.5 h-2.5 stroke-[3]" />
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* 3. ALL CORE FUNCTIONS & ASSETS (Futuristic Glassmorphic Navy Grid) */}
        <div className="px-3 sm:px-4 animate-in fade-in duration-200 space-y-2.5">
          
          {/* Main 6-Item Functional Grid (Frames, Backpack, Store, Medals, Special ID, CP Space) */}
          <div className="relative overflow-hidden p-3 rounded-2xl bg-[#0e1628]/85 border border-cyan-500/20 shadow-[0_10px_30px_rgba(2,6,23,0.7)] backdrop-blur-2xl">
            <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent" />
            <div className="grid grid-cols-3 gap-2 text-center relative z-10">
              
              {/* 1. Frames Center */}
              <div 
                onClick={() => { playSoundFX('win'); setIsAvatarFrameModalOpen(true); }} 
                className="p-2 sm:p-2.5 rounded-xl bg-white/[0.03] hover:bg-purple-500/15 border border-purple-500/25 hover:border-purple-400/50 flex flex-col items-center gap-1.5 cursor-pointer transition-all group backdrop-blur-md shadow-sm"
              >
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-purple-600/30 to-pink-600/30 border border-purple-400/40 flex items-center justify-center text-pink-300 group-hover:scale-105 shadow-[0_0_10px_rgba(216,70,239,0.25)] transition-transform">
                  <Sparkles className="w-4 h-4 text-pink-400" />
                </div>
                <div>
                  <div className="text-[11px] font-bold text-white leading-tight group-hover:text-pink-300 transition-colors">Avatar Frames</div>
                  <span className="text-[9px] text-pink-400/90 font-medium">50+ 3D Frames</span>
                </div>
              </div>

              {/* 2. My Backpack */}
              <div 
                onClick={() => { playSoundFX('click'); setIsBagModalOpen(true); }} 
                className="p-2 sm:p-2.5 rounded-xl bg-white/[0.03] hover:bg-emerald-500/15 border border-emerald-500/25 hover:border-emerald-400/50 flex flex-col items-center gap-1.5 cursor-pointer transition-all group backdrop-blur-md shadow-sm"
              >
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-emerald-600/30 to-teal-600/30 border border-emerald-400/40 flex items-center justify-center text-emerald-300 group-hover:scale-105 shadow-[0_0_10px_rgba(16,185,129,0.25)] transition-transform">
                  <Briefcase className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <div className="text-[11px] font-bold text-white leading-tight group-hover:text-emerald-300 transition-colors">My Backpack</div>
                  <span className="text-[9px] text-emerald-400/90 font-medium">Items & Chests</span>
                </div>
              </div>

              {/* 3. Costume Store */}
              <div 
                onClick={() => { playSoundFX('click'); setIsStoreOpen(true); }} 
                className="p-2 sm:p-2.5 rounded-xl bg-white/[0.03] hover:bg-blue-500/15 border border-cyan-500/25 hover:border-cyan-400/50 flex flex-col items-center gap-1.5 cursor-pointer transition-all group backdrop-blur-md shadow-sm"
              >
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-cyan-600/30 to-blue-600/30 border border-cyan-400/40 flex items-center justify-center text-cyan-300 group-hover:scale-105 shadow-[0_0_10px_rgba(6,182,212,0.25)] transition-transform">
                  <ShoppingBag className="w-4 h-4 text-cyan-400" />
                </div>
                <div>
                  <div className="text-[11px] font-bold text-white leading-tight group-hover:text-cyan-300 transition-colors">Costume Store</div>
                  <span className="text-[9px] text-cyan-400/90 font-medium">Mounts & Bubbles</span>
                </div>
              </div>

              {/* 4. Medal Wall */}
              <div 
                onClick={() => { playSoundFX('win'); setIsMedalModalOpen(true); }} 
                className="p-2 sm:p-2.5 rounded-xl bg-white/[0.03] hover:bg-amber-500/15 border border-amber-500/25 hover:border-amber-400/50 flex flex-col items-center gap-1.5 cursor-pointer transition-all group backdrop-blur-md shadow-sm"
              >
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-amber-600/30 to-yellow-600/30 border border-amber-400/40 flex items-center justify-center text-amber-300 group-hover:scale-105 shadow-[0_0_10px_rgba(245,158,11,0.25)] transition-transform">
                  <Medal className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <div className="text-[11px] font-bold text-white leading-tight group-hover:text-amber-300 transition-colors">Medal Wall</div>
                  <span className="text-[9px] text-amber-400/90 font-medium">Achievements</span>
                </div>
              </div>

              {/* 5. Special ID */}
              <div 
                onClick={() => { playSoundFX('click'); setIsSpecialIdOpen(true); }} 
                className="p-2 sm:p-2.5 rounded-xl bg-white/[0.03] hover:bg-rose-500/15 border border-rose-500/25 hover:border-rose-400/50 flex flex-col items-center gap-1.5 cursor-pointer transition-all group backdrop-blur-md shadow-sm"
              >
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-rose-600/30 to-red-600/30 border border-rose-400/40 flex items-center justify-center text-rose-300 group-hover:scale-105 shadow-[0_0_10px_rgba(244,63,94,0.25)] transition-transform">
                  <Award className="w-4 h-4 text-rose-400" />
                </div>
                <div>
                  <div className="text-[11px] font-bold text-white leading-tight group-hover:text-rose-300 transition-colors">Special ID</div>
                  <span className="text-[9px] text-rose-400/90 font-medium">Vanity & Rare</span>
                </div>
              </div>

              {/* 6. CP Space */}
              <div 
                onClick={() => { playSoundFX('click'); setIsCpModalOpen(true); }} 
                className="p-2 sm:p-2.5 rounded-xl bg-white/[0.03] hover:bg-pink-500/15 border border-pink-500/25 hover:border-pink-400/50 flex flex-col items-center gap-1.5 cursor-pointer transition-all group backdrop-blur-md shadow-sm"
              >
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-pink-600/30 to-rose-600/30 border border-pink-400/40 flex items-center justify-center text-pink-300 group-hover:scale-105 shadow-[0_0_10px_rgba(236,72,153,0.25)] transition-transform">
                  <Heart className="w-4 h-4 text-pink-400 fill-pink-400" />
                </div>
                <div>
                  <div className="text-[11px] font-bold text-white leading-tight group-hover:text-pink-300 transition-colors">CP Space</div>
                  <span className="text-[9px] text-pink-400/90 font-medium">Couple Intimacy</span>
                </div>
              </div>

            </div>
          </div>

          {/* BELOW CP SPACE: SETTING, HOST VERIFICATION & OWNER PANEL (As explicitly requested by user) */}
          <div className="space-y-2">
            
            {/* 1. Settings */}
            <div 
              onClick={() => { playSoundFX('click'); setIsSettingsOpen(true); }}
              className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-[#0d1424]/80 hover:bg-[#121c32]/90 border border-cyan-500/20 hover:border-cyan-400/40 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
            >
              <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/20 to-transparent" />
              <div className="flex items-center gap-2.5 relative z-10">
                <div className="w-8 h-8 rounded-lg bg-cyan-950/50 border border-cyan-500/30 text-cyan-300 flex items-center justify-center shadow-sm">
                  <Settings className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block leading-tight group-hover:text-cyan-200 transition-colors">Account Settings & Security</span>
                  <span className="text-[10px] text-slate-400">Password, language, sounds & privacy</span>
                </div>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-300 transition-colors" />
            </div>

            {/* 2. Host Verification */}
            <div 
              onClick={() => { playSoundFX('click'); setIsVerificationOpen(true); }}
              className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-[#0d1424]/80 hover:bg-[#121c32]/90 border border-cyan-500/25 hover:border-cyan-400/50 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
            >
              <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent" />
              <div className="flex items-center gap-2.5 relative z-10">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 flex items-center justify-center shadow-[0_0_8px_rgba(6,182,212,0.2)]">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block leading-tight group-hover:text-cyan-200 transition-colors">Host Verification Center</span>
                  <span className="text-[10px] text-slate-400">Apply for official talent badge & live permissions</span>
                </div>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-300 transition-colors" />
            </div>

            {/* 3. Agency Center & Guild (Agency Join Requirement) */}
            <div 
              onClick={() => { playSoundFX('click'); setIsAgencyOpen(true); }}
              className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-[#0d1424]/80 hover:bg-[#121c32]/90 border border-teal-500/30 hover:border-teal-400/60 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
            >
              <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-teal-400/30 to-transparent" />
              <div className="flex items-center gap-2.5 relative z-10">
                <div className="w-8 h-8 rounded-lg bg-teal-500/15 border border-teal-400/30 text-teal-300 flex items-center justify-center shadow-[0_0_8px_rgba(20,184,166,0.2)]">
                  <Building2 className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white block leading-tight group-hover:text-teal-200 transition-colors">
                      Agency Center & Guild
                    </span>
                    {hasApprovedAgency ? (
                      <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-bold border border-emerald-500/30">
                        VERIFIED
                      </span>
                    ) : currentUser.agencyMembership?.status === 'PENDING' ? (
                      <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold border border-amber-500/30">
                        PENDING
                      </span>
                    ) : (
                      <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 text-[9px] font-bold border border-rose-500/30">
                        REQUIRED FOR LIVE
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {hasApprovedAgency 
                      ? `Member of ${currentUser.agencyMembership?.agencyName || 'Official Agency'}`
                      : 'Join an Agency to unlock host live streaming'}
                  </span>
                </div>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-teal-300 transition-colors" />
            </div>

            {/* 4. Host Live Broadcast Center */}
            <div 
              onClick={() => { playSoundFX('click'); setIsHostCenterOpen(true); }}
              className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-[#0d1424]/80 hover:bg-[#121c32]/90 border border-purple-500/25 hover:border-purple-400/50 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
            >
              <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-purple-400/30 to-transparent" />
              <div className="flex items-center gap-2.5 relative z-10">
                <div className="w-8 h-8 rounded-lg bg-purple-500/15 border border-purple-400/30 text-purple-300 flex items-center justify-center shadow-[0_0_8px_rgba(168,85,247,0.2)]">
                  <Tv className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white block leading-tight group-hover:text-purple-200 transition-colors">Host Live Broadcast Center</span>
                    {isHost && (
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-purple-500/20 text-purple-300 border border-purple-400/40 font-black">
                        HOST
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400">Stream analytics, live tasks & host rewards</span>
                </div>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-purple-300 transition-colors" />
            </div>

            {/* 5. Agency Guild Leader Desk */}
            {(isAgency || isOwner) && (
              <div 
                onClick={() => { playSoundFX('click'); onOpenOwnerPanel(); }}
                className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-[#0e172a]/90 via-[#132238]/90 to-[#0f1d32]/90 border border-indigo-500/40 hover:border-indigo-400/70 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
              >
                <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-indigo-400/40 to-transparent" />
                <div className="flex items-center gap-2.5 relative z-10">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-400/40 text-indigo-300 flex items-center justify-center shadow-[0_0_10px_rgba(99,102,241,0.25)]">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-indigo-200 block leading-tight">Agency Guild Leader Desk</span>
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-indigo-500/25 text-indigo-300 border border-indigo-400/40 font-black">
                        AGENCY
                      </span>
                    </div>
                    <span className="text-[10px] text-indigo-300/80">Manage registered hosts, commission & stream hours</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-indigo-400 group-hover:text-white transition-colors" />
              </div>
            )}

            {/* 6. Authorized Coin Seller Desk */}
            {(isCoinSeller || isOwner) && (
              <div 
                onClick={() => { playSoundFX('click'); setIsSellerOpen(true); }}
                className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-[#1b191a]/90 via-[#141219]/90 to-[#0f1422]/90 border border-amber-500/40 hover:border-amber-400/60 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
              >
                <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-amber-400/30 to-transparent" />
                <div className="flex items-center gap-2.5 relative z-10">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-400/30 text-amber-300 flex items-center justify-center shadow-[0_0_8px_rgba(245,158,11,0.25)]">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-amber-300 block leading-tight">Authorized Coin Seller Desk</span>
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-amber-500/25 text-amber-300 border border-amber-400/40 font-black">
                        COIN SELLER
                      </span>
                    </div>
                    <span className="text-[10px] text-amber-400/80">Distribute coins & fulfill direct recharge requests</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-amber-400 group-hover:text-white transition-colors" />
              </div>
            )}

            {/* 7. Business Development (BD) Panel */}
            {(isBdAdmin || isOwner) && (
              <div 
                onClick={() => { playSoundFX('click'); onOpenOwnerPanel(); }}
                className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-[#0d1d29]/90 via-[#0f2735]/90 to-[#0b1724]/90 border border-teal-500/40 hover:border-teal-400/70 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
              >
                <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-teal-400/30 to-transparent" />
                <div className="flex items-center gap-2.5 relative z-10">
                  <div className="w-8 h-8 rounded-lg bg-teal-500/20 border border-teal-400/40 text-teal-300 flex items-center justify-center shadow-[0_0_10px_rgba(20,184,166,0.25)]">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-teal-200 block leading-tight">Business Development (BD) Panel</span>
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-teal-500/25 text-teal-300 border border-teal-400/40 font-black">
                        BD ADMIN
                      </span>
                    </div>
                    <span className="text-[10px] text-teal-300/80">Agency recruitment, performance audits & guild expansion</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-teal-400 group-hover:text-white transition-colors" />
              </div>
            )}

            {/* 8. Super Admin Moderation Panel */}
            {(isSuperAdmin || isOwner) && (
              <div 
                onClick={() => { playSoundFX('click'); onOpenOwnerPanel(); }}
                className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-[#171228]/90 via-[#1c1634]/90 to-[#100d1e]/90 border border-purple-500/40 hover:border-purple-400/70 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
              >
                <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-purple-400/30 to-transparent" />
                <div className="flex items-center gap-2.5 relative z-10">
                  <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-400/40 text-purple-300 flex items-center justify-center shadow-[0_0_10px_rgba(168,85,247,0.25)]">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-purple-200 block leading-tight">Super Admin Moderation Panel</span>
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-purple-500/25 text-purple-300 border border-purple-400/40 font-black">
                        SUPER ADMIN
                      </span>
                    </div>
                    <span className="text-[10px] text-purple-300/80">Live room moderation, ban enforcement & subordinate supervision</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-purple-400 group-hover:text-white transition-colors" />
              </div>
            )}

            {/* 9. Operations Manager Control Panel */}
            {(isManager || isOwner) && (
              <div 
                onClick={() => { playSoundFX('click'); onOpenOwnerPanel(); }}
                className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-[#181a29]/90 via-[#1e2238]/90 to-[#131524]/90 border border-blue-500/40 hover:border-blue-400/70 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
              >
                <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-blue-400/30 to-transparent" />
                <div className="flex items-center gap-2.5 relative z-10">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 border border-blue-400/40 text-blue-300 flex items-center justify-center shadow-[0_0_10px_rgba(59,130,246,0.25)]">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-blue-200 block leading-tight">Operations Manager Control Panel</span>
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-blue-500/25 text-blue-300 border border-blue-400/40 font-black">
                        MANAGER
                      </span>
                    </div>
                    <span className="text-[10px] text-blue-300/80">Staff hiring, subordinate management & operations overview</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-blue-400 group-hover:text-white transition-colors" />
              </div>
            )}

            {/* 9.5. Official / Admin Staff Desk */}
            {((isOfficial || isAdmin) && !isOwner && !isManager && !isSuperAdmin) && (
              <div 
                onClick={() => { playSoundFX('click'); onOpenOwnerPanel(); }}
                className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-[#1a1708]/90 via-[#26200d]/90 to-[#141206]/90 border border-yellow-500/40 hover:border-yellow-400/70 backdrop-blur-xl cursor-pointer transition-all shadow-md group"
              >
                <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-yellow-400/30 to-transparent" />
                <div className="flex items-center gap-2.5 relative z-10">
                  <div className="w-8 h-8 rounded-lg bg-yellow-500/20 border border-yellow-400/40 text-yellow-300 flex items-center justify-center shadow-[0_0_10px_rgba(234,179,8,0.25)]">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-yellow-200 block leading-tight">Official Staff Desk</span>
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-yellow-500/25 text-yellow-300 border border-yellow-400/40 font-black uppercase">
                        {(currentUser as any).roleTag || currentUser.role || 'OFFICIAL'}
                      </span>
                    </div>
                    <span className="text-[10px] text-yellow-300/80">Active Staff Panel & Live Broadcasting Rights</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-yellow-400 group-hover:text-white transition-colors" />
              </div>
            )}

            {/* 10. Master Owner Panel (Strictly for Owner) */}
            {isOwner && (
              <div 
                onClick={() => { playSoundFX('win'); onOpenOwnerPanel(); }}
                className="relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-amber-500/20 via-yellow-500/15 to-indigo-900/30 border border-amber-400/50 hover:border-amber-300/80 backdrop-blur-xl cursor-pointer transition-all shadow-[0_0_15px_rgba(245,158,11,0.2)] group"
              >
                <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-amber-300/40 to-transparent" />
                <div className="flex items-center gap-2.5 relative z-10">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-yellow-500 text-neutral-950 flex items-center justify-center font-black shadow-[0_0_10px_rgba(245,158,11,0.4)]">
                    <Crown className="w-4 h-4 fill-neutral-950" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-amber-300 flex items-center gap-1 leading-tight">
                      Master Owner Dashboard
                      <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-400 text-neutral-950 font-black shadow-sm">
                        OWNER
                      </span>
                    </span>
                    <span className="text-[10px] text-amber-300/80">Manage all staff, minting, banners, frames & users</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-amber-400 group-hover:text-white transition-colors" />
              </div>
            )}

          </div>

        </div>

      </div>

      {/* MODALS */}

      {/* 1. Avatar Frame Selector & Dressing Center Modal */}
      <AvatarFrameSelectorModal
        isOpen={isAvatarFrameModalOpen}
        onClose={() => setIsAvatarFrameModalOpen(false)}
        currentAvatar={currentUser.avatar}
        currentFrameId={currentUser.avatarFrameId}
        currentRole={currentUser.role}
        currentHostTag={currentUser.hostTag}
        vipLevel={currentUser.vipLevel ?? 0}
        userCoins={currentUser.coinBalance ?? 0}
        onEquipFrame={(frameId, frameUrl, roleType, hostTag) => {
          if (onEquipAvatarFrame) {
            onEquipAvatarFrame(frameId, frameUrl, roleType, hostTag);
          }
        }}
        onUnequipFrame={() => {
          if (onEquipAvatarFrame) {
            onEquipAvatarFrame('', '', undefined, undefined);
          }
        }}
      />

      {/* 2. My Backpack / Bag Modal */}
      <BagModal
        isOpen={isBagModalOpen}
        onClose={() => setIsBagModalOpen(false)}
      />

      {/* 3. Medal Wall Modal */}
      <MedalWallModal
        isOpen={isMedalModalOpen}
        onClose={() => setIsMedalModalOpen(false)}
      />

      {/* 4. CP Sweetheart Space Modal */}
      <CpModal
        isOpen={isCpModalOpen}
        onClose={() => setIsCpModalOpen(false)}
      />

      {/* 5. User Profile Card / Share Modal */}
      <UserProfileCardModal
        isOpen={isProfileCardModalOpen}
        onClose={() => setIsProfileCardModalOpen(false)}
        user={{
          id: activeUserId,
          name: currentUser.name || 'SR LIVE STREAM',
          avatar: currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600',
          gender: currentUser.gender === 'Female' ? 'female' : 'male',
          countryFlag: currentUser.countryFlag || '🇳🇵',
          countryCode: currentUser.countryCode || 'NP',
          level: userLevel,
          vipLevel: currentUser.vipLevel || 0,
          roleTag: currentUser.role || 'USER',
          customFrameUrl: currentUser.avatarFrameUrl,
          followingCount: currentUser.followingCount || 0,
          followersCount: currentUser.followersCount || 0,
          bio: currentUser.bio,
          diamondsEarned: currentUser.diamondBalance || 0
        }}
      />

      {/* 6. Wallet Modal */}
      {isWalletOpen && (
        <WalletModal
          isOpen={isWalletOpen}
          onClose={() => setIsWalletOpen(false)}
          currentUser={currentUser}
          transactions={transactions}
          onUpdateUserBalance={onUpdateUserBalance}
          defaultTab={walletDefaultTab}
        />
      )}

      {/* 7. Store Modal */}
      {isStoreOpen && (
        <StoreModal
          isOpen={isStoreOpen}
          onClose={() => setIsStoreOpen(false)}
          currentUser={currentUser}
          onUpdateUserBalance={onUpdateUserBalance}
        />
      )}

      {/* 8. Level Modal */}
      {isLevelOpen && (
        <LevelModal
          isOpen={isLevelOpen}
          onClose={() => setIsLevelOpen(false)}
          currentUser={currentUser}
        />
      )}

      {/* 9. Orders Modal */}
      {isOrdersOpen && (
        <OrdersModal
          isOpen={isOrdersOpen}
          onClose={() => setIsOrdersOpen(false)}
          transactions={transactions}
        />
      )}

      {/* 10. Agency Modal */}
      {isAgencyOpen && (
        <AgencyModal
          isOpen={isAgencyOpen}
          onClose={() => setIsAgencyOpen(false)}
          currentUser={currentUser}
          agencies={agencies}
          agencyJoinRequests={agencyJoinRequests}
          onUpdateAgencyRequests={onUpdateAgencyRequests}
          onUpdateUserAgencyMembership={onUpdateUserAgencyMembership}
          onAddAuditLog={onAddAuditLog}
          onAddNotification={onAddNotification}
        />
      )}

      {/* 11. Seller Modal */}
      {isSellerOpen && (
        <SellerModal
          isOpen={isSellerOpen}
          onClose={() => setIsSellerOpen(false)}
          currentUser={currentUser}
        />
      )}

      {/* 12. Verification Modal */}
      {isVerificationOpen && (
        <VerificationModal
          isOpen={isVerificationOpen}
          onClose={() => setIsVerificationOpen(false)}
          currentUser={currentUser}
        />
      )}

      {/* 13. Invite Modal */}
      {isInviteOpen && (
        <InviteModal
          isOpen={isInviteOpen}
          onClose={() => setIsInviteOpen(false)}
        />
      )}

      {/* 14. Host Center Modal */}
      {isHostCenterOpen && (
        <HostCenterModal
          isOpen={isHostCenterOpen}
          onClose={() => setIsHostCenterOpen(false)}
          currentUser={currentUser}
          hasApprovedAgency={hasApprovedAgency}
          onGoLiveClick={() => {
            setIsHostCenterOpen(false);
            onGoLiveClick();
          }}
        />
      )}

      {/* 15. Edit Profile Modal */}
      {isEditProfileOpen && (
        <EditProfileModal
          isOpen={isEditProfileOpen}
          onClose={() => setIsEditProfileOpen(false)}
          currentUser={currentUser}
          onSave={onUpdateUserProfile}
        />
      )}

      {/* 16. Settings Modal */}
      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          currentRole={currentRole}
          onChangeRole={onChangeRole}
          onOpenOwnerPanel={onOpenOwnerPanel}
          onLogout={onLogout}
          currentUser={currentUser}
        />
      )}

      {/* 17. VIP Upgrade Modal */}
      {isVipModalOpen && (
        <VipUpgradeModal
          isOpen={isVipModalOpen}
          onClose={() => setIsVipModalOpen(false)}
          currentVipLevel={currentUser.vipLevel || 0}
          vipConfigs={vipConfigs}
          userCoinsSpent={currentUser.totalSpentCoins || 0}
          userCoins={currentUser.coinBalance || 0}
          userId={currentUser.id}
          userName={currentUser.name}
          userAvatar={currentUser.avatar}
          onUpgradeVip={onUpgradeVip}
          onUpgrade={onUpgradeVip}
        />
      )}

      {/* 18. Special ID Modal */}
      {isSpecialIdOpen && (
        <SpecialIdModal
          isOpen={isSpecialIdOpen}
          onClose={() => setIsSpecialIdOpen(false)}
          currentUser={currentUser}
          onUpdateUserBalance={onUpdateUserBalance}
        />
      )}

      {/* 19. Badge Showcase Modal */}
      {isBadgeModalOpen && (
        <BadgeTagsShowcase
          isOpen={isBadgeModalOpen}
          onClose={() => setIsBadgeModalOpen(false)}
        />
      )}

      {/* 20. Guardian Modal */}
      {isGuardianOpen && (
        <GuardianModal
          isOpen={isGuardianOpen}
          onClose={() => setIsGuardianOpen(false)}
        />
      )}

      {/* 21. Fan Club Modal */}
      {isFanClubOpen && (
        <FanClubModal
          isOpen={isFanClubOpen}
          onClose={() => setIsFanClubOpen(false)}
        />
      )}

    </div>
  );
};

