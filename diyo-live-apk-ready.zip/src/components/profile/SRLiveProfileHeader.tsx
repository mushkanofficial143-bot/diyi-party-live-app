import React, { useState, useRef } from 'react';
import { 
  Edit3, 
  Settings, 
  Copy, 
  Crown, 
  Sparkles, 
  CheckCircle2,
  ChevronRight,
  Share2,
  Camera,
  Shield,
  Star,
  Gem,
  Flame,
  Award,
  Users,
  Eye,
  HeartHandshake
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';

interface SRLiveProfileHeaderProps {
  username?: string;
  userId?: string;
  countryFlag?: string;
  countryCode?: string;
  countryName?: string;
  bio?: string;
  avatarUrl?: string;
  avatarFrameId?: string;
  avatarFrameUrl?: string;
  followersCount?: string | number;
  followingCount?: string | number;
  friendsCount?: string | number;
  visitorsCount?: string | number;
  diamondsCount?: string | number;
  coinsCount?: string | number;
  vipLevel?: number;
  userLevel?: number;
  age?: number;
  gender?: string;
  roleTitle?: string;
  role?: string;
  hostTag?: string;
  profileTag?: string;
  onEditProfile?: () => void;
  onOpenSettings?: () => void;
  onOpenVipModal?: () => void;
  onOpenLevelModal?: () => void;
  onOpenFollowers?: () => void;
  onOpenFollowing?: () => void;
  onOpenFriends?: () => void;
  onOpenVisitors?: () => void;
  onOpenFrames?: () => void;
  onOpenShareCard?: () => void;
  onOpenWallet?: (tab?: 'RECHARGE' | 'EXCHANGE') => void;
  onUpdateAvatar?: (newUrl: string) => void;
}

export const SRLiveProfileHeader: React.FC<SRLiveProfileHeaderProps> = ({
  username = "Diyo live",
  userId = "0000001",
  countryFlag = "🇳🇵",
  countryCode = "NP",
  countryName = "Nepal",
  bio = "DIYO LIVE Supreme Owner & Founder",
  avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600",
  avatarFrameId,
  avatarFrameUrl,
  followersCount = 0,
  followingCount = 0,
  friendsCount = 12,
  visitorsCount = '1.4K',
  vipLevel = 0,
  userLevel = 0,
  age = 22,
  gender = "Male",
  role = "USER",
  roleTitle,
  hostTag,
  onEditProfile,
  onOpenSettings,
  onOpenVipModal,
  onOpenLevelModal,
  onOpenFollowers,
  onOpenFollowing,
  onOpenFriends,
  onOpenVisitors,
  onOpenFrames,
  onOpenShareCard,
  onUpdateAvatar
}) => {
  const [copiedId, setCopiedId] = useState(false);
  const [uploadToast, setUploadToast] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCopyId = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(userId);
    playSoundFX('click');
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const triggerGalleryPicker = (e: React.MouseEvent) => {
    e.stopPropagation();
    playSoundFX('click');
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleDirectPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const res = reader.result as string;
        if (onUpdateAvatar) {
          onUpdateAvatar(res);
        }
        playSoundFX('win');
        setUploadToast(true);
        setTimeout(() => setUploadToast(false), 3000);
      };
      reader.readAsDataURL(file);
    }
  };

  const isOwner = role === 'OWNER' || userId === '0000001' || userId === 'OWNER-001';
  const hasOfficialRole = Boolean(role && role !== 'USER' && role !== 'NONE');
  const hasAdminOrRoleFrame = Boolean(avatarFrameId || (hasOfficialRole && role !== 'HOST'));

  // Format role name dynamically for badges and labels
  const formattedRoleName = (role || 'USER').replace(/_/g, ' ');
  const displayLevel = typeof userLevel === 'number' ? userLevel : 1;
  const displayVipLevel = typeof vipLevel === 'number' ? vipLevel : 0;

  return (
    <div 
      id="sr-live-profile-header-container"
      className="relative w-full overflow-hidden text-white select-none rounded-2xl bg-gradient-to-b from-[#0e1628]/90 via-[#0a1020]/92 to-[#070c18]/96 border border-cyan-500/25 backdrop-blur-2xl shadow-[0_16px_40px_rgba(2,6,23,0.85),inset_0_1px_1px_rgba(56,189,248,0.3)] p-3 sm:p-4"
    >
      {/* Intricate Futuristic Subtle Neon Grid & Circuit Accents */}
      <div className="absolute inset-0 opacity-[0.06] pointer-events-none bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]" />
      
      {/* Dynamic Cyber Ambient Lighting Glows */}
      <div className="absolute -top-24 -left-20 w-72 h-72 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" style={{ animationDuration: '4s' }} />
      <div className="absolute -top-24 -right-20 w-72 h-72 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" style={{ animationDuration: '5s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-88 h-88 bg-gradient-to-b from-cyan-400/10 via-purple-600/10 to-transparent rounded-full blur-3xl pointer-events-none" />

      {/* Hidden file input for avatar upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleDirectPhotoUpload}
        accept="image/*"
        className="hidden"
      />

      {/* Top Controls Bar: Dynamic Role Pill on Left, Edit & Settings Icons on Right */}
      <div className="relative z-10 flex items-center justify-between mb-3 px-1">
        {/* Left: Dynamic Role Pill with Dropdown Arrow */}
        <div 
          onClick={() => {
            playSoundFX('click');
            if (onOpenSettings) onOpenSettings();
          }}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full border backdrop-blur-md cursor-pointer transition-all active:scale-95 shadow-md ${
            isOwner 
              ? 'bg-gradient-to-r from-amber-500/20 via-yellow-500/15 to-amber-600/20 border-amber-400/40 shadow-[0_0_12px_rgba(245,158,11,0.25)] hover:border-amber-400/70'
              : role === 'ADMIN' || role === 'SUPER_ADMIN'
              ? 'bg-gradient-to-r from-blue-500/20 via-sky-500/15 to-indigo-600/20 border-sky-400/40 shadow-[0_0_12px_rgba(56,189,248,0.25)] hover:border-sky-400/70'
              : role === 'MANAGER'
              ? 'bg-gradient-to-r from-emerald-500/20 to-teal-600/20 border-emerald-400/40 shadow-[0_0_12px_rgba(16,185,129,0.25)]'
              : role === 'HOST'
              ? 'bg-gradient-to-r from-pink-500/20 to-rose-600/20 border-pink-400/40 shadow-[0_0_12px_rgba(244,63,94,0.25)]'
              : role === 'AGENCY'
              ? 'bg-gradient-to-r from-cyan-500/20 to-blue-600/20 border-cyan-400/40 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
              : role === 'COIN_SELLER'
              ? 'bg-gradient-to-r from-yellow-500/20 to-amber-600/20 border-yellow-400/40 shadow-[0_0_12px_rgba(234,179,8,0.25)]'
              : 'bg-white/10 border-white/20 text-neutral-200'
          }`}
          title="Switch or view role settings"
        >
          <Crown className={`w-3.5 h-3.5 ${isOwner ? 'text-amber-400 fill-amber-400 drop-shadow-[0_0_4px_rgba(251,191,36,0.8)]' : 'text-cyan-300'}`} />
          <span className="text-[11px] font-black tracking-wider uppercase text-white font-['Outfit']">
            {roleTitle || formattedRoleName}
          </span>
          <span className="text-[10px] text-neutral-300 font-bold ml-0.5">▾</span>
        </div>

        {/* Right: Action Buttons (Edit Pencil + Settings Gear as in photo) */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              playSoundFX('click');
              if (onEditProfile) onEditProfile();
            }}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white flex items-center justify-center transition-all active:scale-95 shadow"
            title="Edit Profile"
          >
            <Edit3 className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              playSoundFX('click');
              if (onOpenSettings) onOpenSettings();
            }}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white flex items-center justify-center transition-all active:scale-95 shadow"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* CENTER PIECE: Futuristic Avatar */}
      <div className="relative z-10 flex flex-col items-center text-center mt-0.5">
        
        {/* Avatar Container */}
        <div className="relative flex items-center justify-center mb-1">
          
          {hasAdminOrRoleFrame && (
            <>
              {/* Soft Glowing Ambient Radial Gradient Behind Avatar */}
              <div className="absolute -inset-8 rounded-full bg-[radial-gradient(circle_at_center,#06b6d4_0%,#3b82f6_40%,#6366f1_70%,transparent_85%)] opacity-80 blur-xl pointer-events-none animate-pulse" style={{ animationDuration: '3.5s' }} />
              <div className="absolute -inset-3 rounded-full bg-cyan-400/25 blur-md pointer-events-none" />

              {/* Futuristic Cybernetic Wings SVG */}
              <div className="absolute -inset-x-12 sm:-inset-x-14 -inset-y-2 pointer-events-none flex items-center justify-center">
                <svg 
                  className="w-full h-28 sm:h-32 filter drop-shadow-[0_4px_12px_rgba(6,182,212,0.45)] overflow-visible" 
                  viewBox="0 0 440 140" 
                  fill="none"
                >
                  <defs>
                    <linearGradient id="cyberWingLeft" x1="100%" y1="50%" x2="0%" y2="0%">
                      <stop offset="0%" stopColor="#64748b" />
                      <stop offset="25%" stopColor="#94a3b8" />
                      <stop offset="50%" stopColor="#cbd5e1" />
                      <stop offset="75%" stopColor="#38bdf8" />
                      <stop offset="100%" stopColor="#0284c7" />
                    </linearGradient>
                    <linearGradient id="cyberWingRight" x1="0%" y1="50%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#64748b" />
                      <stop offset="25%" stopColor="#94a3b8" />
                      <stop offset="50%" stopColor="#cbd5e1" />
                      <stop offset="75%" stopColor="#38bdf8" />
                      <stop offset="100%" stopColor="#0284c7" />
                    </linearGradient>
                    <filter id="neonWingGlow" x="-20%" y="-20%" width="140%" height="140%">
                      <feGaussianBlur stdDeviation="2.5" result="blur" />
                      <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                  </defs>

                  {/* LEFT CYBERNETIC WING */}
                  <g filter="url(#neonWingGlow)">
                    <path 
                      d="M155 70 C130 45, 95 32, 40 45 C25 48, 20 62, 45 60 C80 58, 120 66, 150 78 Z" 
                      fill="url(#cyberWingLeft)" 
                      stroke="#38bdf8" 
                      strokeWidth="1.2"
                    />
                    <path 
                      d="M150 78 C125 68, 85 64, 55 78 C42 84, 52 92, 70 88 C100 82, 130 84, 148 90 Z" 
                      fill="#1e293b" 
                      stroke="#0ea5e9" 
                      strokeWidth="1"
                    />
                    <path 
                      d="M145 88 C120 85, 90 90, 75 102 C68 108, 80 110, 95 104 C115 97, 135 95, 146 96 Z" 
                      fill="#0f172a" 
                      stroke="#38bdf8" 
                      strokeWidth="0.8"
                    />
                    <circle cx="90" cy="53" r="2" fill="#22d3ee" className="animate-pulse" />
                    <circle cx="102" cy="55" r="2" fill="#22d3ee" />
                    <circle cx="114" cy="58" r="2" fill="#38bdf8" />
                    <circle cx="126" cy="62" r="2" fill="#38bdf8" />
                  </g>

                  {/* RIGHT CYBERNETIC WING */}
                  <g filter="url(#neonWingGlow)">
                    <path 
                      d="M285 70 C310 45, 345 32, 400 45 C415 48, 420 62, 395 60 C360 58, 320 66, 290 78 Z" 
                      fill="url(#cyberWingRight)" 
                      stroke="#38bdf8" 
                      strokeWidth="1.2"
                    />
                    <path 
                      d="M290 78 C315 68, 355 64, 385 78 C398 84, 388 92, 370 88 C340 82, 310 84, 292 90 Z" 
                      fill="#1e293b" 
                      stroke="#0ea5e9" 
                      strokeWidth="1"
                    />
                    <path 
                      d="M295 88 C320 85, 350 90, 365 102 C372 108, 360 110, 345 104 C325 97, 305 95, 294 96 Z" 
                      fill="#0f172a" 
                      stroke="#38bdf8" 
                      strokeWidth="0.8"
                    />
                    <circle cx="350" cy="53" r="2" fill="#22d3ee" className="animate-pulse" />
                    <circle cx="338" cy="55" r="2" fill="#22d3ee" />
                    <circle cx="326" cy="58" r="2" fill="#38bdf8" />
                    <circle cx="314" cy="62" r="2" fill="#38bdf8" />
                  </g>

                  {/* Glowing Halo Rings */}
                  <circle cx="220" cy="74" r="56" stroke="#38bdf8" strokeWidth="2" strokeOpacity="0.4" fill="none" />
                  <circle cx="220" cy="74" r="52" stroke="#fbbf24" strokeWidth="1.5" fill="none" />
                </svg>
              </div>

              {/* Top Edge DIYO LIVE Pill Badge on Avatar */}
              {(isOwner || role === 'SUPER_ADMIN') && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center pointer-events-none">
                  <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#0a192f] border border-cyan-400/80 text-cyan-300 font-black text-[8px] tracking-wider uppercase shadow-[0_0_10px_rgba(6,182,212,0.6)]">
                    <span className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse" />
                    <span>DIYO LIVE</span>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Avatar Container */}
          <div 
            onClick={triggerGalleryPicker}
            className={`relative z-20 w-16 h-16 sm:w-18 sm:h-18 rounded-full cursor-pointer group flex items-center justify-center transition-all ${
              hasAdminOrRoleFrame 
                ? 'p-0.5 bg-gradient-to-tr from-amber-400 via-yellow-200 to-amber-500 shadow-[0_0_16px_rgba(6,182,212,0.4)] ring-2 ring-cyan-400/50 ring-offset-2 ring-offset-[#070b16]'
                : 'p-0.5 bg-neutral-800 border border-slate-700/80 shadow-md hover:border-cyan-400/50'
            }`}
            title="Tap to change avatar"
          >
            <div className="w-full h-full rounded-full bg-neutral-900 flex flex-col items-center justify-center overflow-hidden relative shadow-inner">
              <img 
                src={avatarUrl} 
                alt={username} 
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />

              {/* Camera Icon Overlay */}
              <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-neutral-950/80 border border-cyan-400 text-cyan-300 flex items-center justify-center shadow group-hover:bg-cyan-500 group-hover:text-black transition-colors z-30">
                <Camera className="w-2 h-2" />
              </div>
            </div>
          </div>

        </div>

        {/* Floating Badge Directly Under Avatar: Render ONLY if user has explicit official role or roleTitle */}
        {(hasOfficialRole || roleTitle) && (
          <div className="relative z-30 -mt-1 mb-1.5">
            <div className="px-3 py-0.5 rounded-full bg-[#09152a] border border-cyan-400/80 shadow-[0_0_10px_rgba(6,182,212,0.4)] flex items-center gap-1.5">
              <span className="w-1 h-1 rounded-full bg-cyan-400" />
              <span className="text-[9px] font-black tracking-widest text-cyan-200 uppercase font-['Outfit']">
                {roleTitle || formattedRoleName}
              </span>
              <span className="w-1 h-1 rounded-full bg-cyan-400" />
            </div>
          </div>
        )}

        {/* Username + Gender/Age + Country Flag */}
        <div className="flex items-center justify-center gap-1.5 flex-wrap mb-1">
          <h1 className="text-sm sm:text-base font-black font-['Outfit'] text-white tracking-tight drop-shadow-md flex items-center gap-1">
            <span>{username}</span>
            {(isOwner || displayVipLevel >= 5) && (
              <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400 drop-shadow-[0_0_6px_rgba(251,191,36,0.9)]" />
            )}
          </h1>

          {/* Gender & Age Pill */}
          <span className="px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/40 text-[9px] font-black flex items-center gap-0.5 shadow-sm">
            <span>♂</span>
            <span>{age}</span>
          </span>

          {/* Country Flag Pill */}
          <span className="px-1.5 py-0.2 rounded-full bg-white/10 border border-white/20 text-[9px] font-bold text-neutral-200 flex items-center gap-1 shadow-sm">
            <span>{countryFlag}</span>
            <span>{countryName || countryCode}</span>
          </span>
        </div>

        {/* User ID with Copy Icon */}
        <div 
          onClick={handleCopyId}
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#10182c]/90 hover:bg-[#16213c] border border-cyan-500/25 cursor-pointer transition-all active:scale-95 mb-2 group shadow-sm"
          title="Click to copy ID"
        >
          <span className="text-[10px] font-mono font-bold text-slate-400 group-hover:text-slate-200">
            ID: <span className="text-amber-300 font-extrabold">{userId}</span>
          </span>
          <Copy className="w-2.5 h-2.5 text-slate-400 group-hover:text-amber-400 transition-colors" />
          {copiedId && (
            <span className="text-[8px] text-emerald-400 font-black animate-in fade-in ml-0.5">
              Copied!
            </span>
          )}
        </div>

        {/* Badges Row: Rendered STRICTLY based on real assigned attributes */}
        <div className="flex items-center justify-center gap-1.5 flex-wrap mb-2">
          
          {/* 1. DYNAMIC ROLE - 3D Golden Metallic Shield: Only for users with explicit roles */}
          {hasOfficialRole && (
            <div 
              onClick={() => {
                playSoundFX('win');
                if (onOpenSettings) onOpenSettings();
              }}
              className="relative cursor-pointer group hover:scale-105 transition-transform"
              title={`Role: ${formattedRoleName}`}
            >
              <div className="w-11 h-13 relative flex items-center justify-center drop-shadow-[0_2px_8px_rgba(245,158,11,0.5)]">
                <svg viewBox="0 0 100 115" className="w-full h-full overflow-visible">
                  <defs>
                    <linearGradient id="shieldGold" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#fef08a" />
                      <stop offset="25%" stopColor="#f59e0b" />
                      <stop offset="50%" stopColor="#d97706" />
                      <stop offset="75%" stopColor="#fbbf24" />
                      <stop offset="100%" stopColor="#92400e" />
                    </linearGradient>
                    <linearGradient id="shieldInner" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#fef08a" />
                      <stop offset="50%" stopColor="#d97706" />
                      <stop offset="100%" stopColor="#78350f" />
                    </linearGradient>
                  </defs>
                  <path 
                    d="M50 5 L92 20 C92 65 50 110 50 110 C50 110 8 65 8 20 Z" 
                    fill="url(#shieldGold)" 
                    stroke="#fef08a" 
                    strokeWidth="2"
                  />
                  <path 
                    d="M50 14 L82 26 C82 62 50 98 50 98 C50 98 18 62 18 26 Z" 
                    fill="url(#shieldInner)" 
                    stroke="#ca8a04" 
                    strokeWidth="1.5"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center pt-0.5 text-center pointer-events-none px-1">
                  <Crown className="w-2.5 h-2.5 text-neutral-950 fill-neutral-950 mb-0.5" />
                  <span className="text-[6.5px] font-black uppercase text-neutral-950 leading-tight font-['Outfit'] tracking-tight break-words max-w-[36px] line-clamp-2">
                    {formattedRoleName}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* 2. HOST TAG: Render ONLY IF explicitly assigned */}
          {hostTag && hostTag.trim().length > 0 && (
            <div className="relative overflow-hidden px-2.5 py-0.5 rounded-full bg-[#0a1b32]/90 text-cyan-300 text-[9px] font-black tracking-widest shadow-[0_0_10px_rgba(6,182,212,0.4)] flex items-center gap-1 border border-cyan-400/80 backdrop-blur-md">
              <span>{hostTag.toUpperCase()}</span>
            </div>
          )}

          {/* 3. VIP TIER - Square Glassmorphic Badge with Dynamic Lighting Sweep & Laser Dots */}
          <div 
            onClick={() => {
              playSoundFX('win');
              if (onOpenVipModal) onOpenVipModal();
            }}
            className="relative overflow-hidden w-14 h-14 rounded-xl bg-gradient-to-br from-[#0f172a]/80 via-[#172554]/90 to-[#1e1b4b]/85 backdrop-blur-2xl border border-cyan-400/90 shadow-[0_0_20px_rgba(6,182,212,0.6),inset_0_0_14px_rgba(56,189,248,0.35)] flex flex-col items-center justify-center cursor-pointer hover:scale-105 active:scale-95 transition-all group"
            title={`VIP Tier ${displayVipLevel}`}
          >
            {/* Ambient Backlight Glow */}
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/20 via-sky-400/30 to-purple-500/20 rounded-xl blur-sm pointer-events-none animate-laser-pulse" />

            {/* Continuous Dynamic Specular Lighting Sweep */}
            <div className="absolute inset-0 w-full h-full pointer-events-none overflow-hidden rounded-xl">
              <div className="absolute -inset-full bg-gradient-to-r from-transparent via-cyan-200/35 to-transparent animate-light-sweep pointer-events-none" />
            </div>

            {/* Corner LED Dotted Border Frame */}
            <div className="absolute inset-1 rounded-lg border border-dotted border-cyan-300/60 pointer-events-none" />
            
            {/* Diagonal Laser Flare */}
            <div className="absolute -inset-1 bg-gradient-to-tr from-transparent via-cyan-400/30 to-pink-500/30 rotate-45 pointer-events-none" />

            <span className="relative z-10 text-[9.5px] font-black uppercase tracking-widest text-cyan-300 font-['Outfit'] drop-shadow-[0_0_6px_rgba(6,182,212,0.9)]">
              VIP
            </span>
            <span className="relative z-10 text-base font-black text-cyan-100 tracking-tight font-['Outfit'] drop-shadow-[0_0_10px_rgba(34,211,238,1)] leading-none mt-0.5">
              {displayVipLevel}
            </span>
          </div>

          {/* 4. Level Orb - Dynamic Lv. (Cosmic Swirling Orb surrounded by Sacred Polyhedral Geometry) */}
          <div 
            onClick={() => {
              playSoundFX('win');
              if (onOpenLevelModal) onOpenLevelModal();
            }}
            className="relative w-15 h-15 rounded-2xl flex items-center justify-center cursor-pointer hover:scale-105 active:scale-95 transition-all group"
            title={`Level ${displayLevel}`}
          >
            {/* Dynamic Halo Glow behind geometry */}
            <div className="absolute -inset-2 rounded-full bg-gradient-to-r from-blue-500/30 via-cyan-400/40 to-indigo-600/30 blur-md pointer-events-none animate-laser-pulse" />

            {/* Sacred Geometry Polyhedral Wireframe SVG with dynamic spin/glow */}
            <svg viewBox="0 0 100 100" className="w-16 h-16 absolute inset-0 overflow-visible pointer-events-none">
              <defs>
                <linearGradient id="geomGold" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fde047" />
                  <stop offset="50%" stopColor="#f59e0b" />
                  <stop offset="100%" stopColor="#fbbf24" />
                </linearGradient>
              </defs>
              {/* Outer Hexagram / Octagram Lines */}
              <polygon points="50,4 96,27 96,73 50,96 4,73 4,27" fill="none" stroke="url(#geomGold)" strokeWidth="1" strokeOpacity="0.85" />
              <polygon points="50,96 4,50 50,4 96,50" fill="none" stroke="url(#geomGold)" strokeWidth="0.8" strokeOpacity="0.7" />
              <circle cx="50" cy="50" r="42" fill="none" stroke="#38bdf8" strokeWidth="1" strokeDasharray="3 3" />
            </svg>

            {/* Cosmic Swirling Blue Vortex Sphere with Glassmorphism & Dynamic Light */}
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-400 via-blue-600 to-indigo-950 shadow-[0_0_20px_rgba(59,130,246,0.9),inset_0_0_14px_rgba(255,255,255,0.5)] flex items-center justify-center relative overflow-hidden backdrop-blur-md">
              {/* Nebula swirls inside orb */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.7),transparent_60%)] pointer-events-none" />
              
              {/* Dynamic Sweep Light across Orb */}
              <div className="absolute -inset-full bg-gradient-to-r from-transparent via-white/30 to-transparent animate-light-sweep pointer-events-none" />
              
              {/* Lv. Dynamic text */}
              <div className="relative z-10 flex items-baseline justify-center text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]">
                <span className="text-[9.5px] font-bold text-cyan-200 mr-0.5">Lv.</span>
                <span className="text-base font-black font-['Outfit'] text-white">
                  {displayLevel}
                </span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* 4-Item Social Stats Grid (Following, Followers, Friends, Visitors) with High-Tech Glassmorphism */}
      <div className="relative z-10 grid grid-cols-4 gap-1.5 pt-2 border-t border-cyan-500/20 text-center">
        
        {/* Following */}
        <div 
          onClick={() => {
            playSoundFX('click');
            if (onOpenFollowing) onOpenFollowing();
          }}
          className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-white/[0.04] hover:bg-cyan-500/10 border border-white/5 hover:border-cyan-400/30 backdrop-blur-md cursor-pointer transition-all group shadow-sm"
        >
          <span className="text-xs sm:text-sm font-black font-['Outfit'] text-white group-hover:text-cyan-300 transition-colors leading-tight drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">
            {followingCount}
          </span>
          <span className="text-[9px] text-slate-400 group-hover:text-slate-200 font-medium">Following</span>
        </div>

        {/* Followers */}
        <div 
          onClick={() => {
            playSoundFX('click');
            if (onOpenFollowers) onOpenFollowers();
          }}
          className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-white/[0.04] hover:bg-cyan-500/10 border border-white/5 hover:border-cyan-400/30 backdrop-blur-md cursor-pointer transition-all group shadow-sm"
        >
          <span className="text-xs sm:text-sm font-black font-['Outfit'] text-white group-hover:text-cyan-300 transition-colors leading-tight drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">
            {followersCount}
          </span>
          <span className="text-[9px] text-slate-400 group-hover:text-slate-200 font-medium">Followers</span>
        </div>

        {/* Friends */}
        <div 
          onClick={() => {
            playSoundFX('click');
            if (onOpenFriends) onOpenFriends();
            else if (onOpenFollowing) onOpenFollowing();
          }}
          className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-white/[0.04] hover:bg-cyan-500/10 border border-white/5 hover:border-cyan-400/30 backdrop-blur-md cursor-pointer transition-all group shadow-sm"
        >
          <span className="text-xs sm:text-sm font-black font-['Outfit'] text-white group-hover:text-cyan-300 transition-colors leading-tight drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">
            {friendsCount}
          </span>
          <span className="text-[9px] text-slate-400 group-hover:text-slate-200 font-medium">Friends</span>
        </div>

        {/* Visitors */}
        <div 
          onClick={() => {
            playSoundFX('click');
            if (onOpenVisitors) onOpenVisitors();
            else if (onOpenFollowers) onOpenFollowers();
          }}
          className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-white/[0.04] hover:bg-cyan-500/10 border border-white/5 hover:border-cyan-400/30 backdrop-blur-md cursor-pointer transition-all group shadow-sm"
        >
          <span className="text-xs sm:text-sm font-black font-['Outfit'] text-white group-hover:text-cyan-300 transition-colors leading-tight drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">
            {visitorsCount}
          </span>
          <span className="text-[9px] text-slate-400 group-hover:text-slate-200 font-medium">Visitors</span>
        </div>

      </div>

      {/* Upload toast confirmation */}
      {uploadToast && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-50 px-4 py-1.5 rounded-full bg-emerald-500 text-neutral-950 text-xs font-black shadow-2xl flex items-center gap-1.5 animate-in fade-in">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Photo updated!</span>
        </div>
      )}
    </div>
  );
};

