import React, { useState, useEffect } from 'react';
import { 
  X, Crown, Sparkles, Check, ChevronRight, Zap, Shield, Flame, 
  Clock, DollarSign, Gift, Award, MessageSquare, Play, History,
  TrendingUp, Star, Info, ArrowUpRight, CheckCircle2, AlertCircle
} from 'lucide-react';
import { VipLevelConfig, UserVipRecord, VipPlanDuration, VipTransaction } from '../../types/vipTypes.js';
import { VipBadge } from '../badges/VipBadge.js';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame.js';
import { VipEntranceBanner, VipEntranceEvent } from './VipEntranceBanner.js';
import { playSoundFX } from '../../utils/audioSynth.js';

interface VipNobilityCenterProps {
  isOpen: boolean;
  onClose: () => void;
  userId?: string;
  userName?: string;
  userAvatar?: string;
  userCoins?: number;
  currentVipLevel?: number;
  onVipUpdated?: (newLevel: number, newBalance: number) => void;
}

export const VipNobilityCenter: React.FC<VipNobilityCenterProps> = ({
  isOpen,
  onClose,
  userId = 'USR-882941',
  userName = 'Aarav Mehta',
  userAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  userCoins = 5200422000,
  currentVipLevel = 8,
  onVipUpdated
}) => {
  const [levels, setLevels] = useState<VipLevelConfig[]>([]);
  const [activeTabLevel, setActiveTabLevel] = useState<number>(currentVipLevel || 1);
  const [selectedDuration, setSelectedDuration] = useState<VipPlanDuration>('30d');
  const [userVipRecord, setUserVipRecord] = useState<UserVipRecord | null>(null);
  const [balance, setBalance] = useState<number>(userCoins);
  const [loading, setLoading] = useState<boolean>(false);
  const [purchasing, setPurchasing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [previewTab, setPreviewTab] = useState<'frame' | 'entrance' | 'chat' | 'gifts'>('frame');
  const [entranceTestEvent, setEntranceTestEvent] = useState<VipEntranceEvent | null>(null);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [transactions, setTransactions] = useState<VipTransaction[]>([]);

  // Fetch VIP Levels and User Status on Mount or Open
  useEffect(() => {
    if (isOpen) {
      fetchVipData();
    }
  }, [isOpen, userId]);

  useEffect(() => {
    setBalance(userCoins);
  }, [userCoins]);

  const fetchVipData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      // 1. Get all VIP Levels
      const levelsRes = await fetch('/api/vip/levels');
      const levelsData = await levelsRes.json();
      if (levelsData.success && Array.isArray(levelsData.levels)) {
        setLevels(levelsData.levels);
        if (!levelsData.levels.some((l: VipLevelConfig) => l.level === activeTabLevel)) {
          setActiveTabLevel(levelsData.levels[0]?.level || 1);
        }
      }

      // 2. Get User VIP Status
      const userRes = await fetch(`/api/vip/user/${userId}`);
      const userData = await userRes.json();
      if (userData.success && userData.vipRecord) {
        setUserVipRecord(userData.vipRecord);
        if (userData.vipRecord.status === 'ACTIVE') {
          setActiveTabLevel(userData.vipRecord.vipLevel);
        }
      }
    } catch (err: any) {
      console.error('Failed to load VIP data:', err);
      setErrorMsg('Could not sync VIP data from server.');
    } finally {
      setLoading(false);
    }
  };

  const fetchTransactions = async () => {
    try {
      const res = await fetch('/api/vip/transactions');
      const data = await res.json();
      if (data.success && Array.isArray(data.transactions)) {
        setTransactions(data.transactions.filter((t: VipTransaction) => t.userId === userId));
      }
    } catch (err) {
      console.error('Failed to load VIP transactions:', err);
    }
  };

  if (!isOpen) return null;

  const currentLevelConfig = levels.find(l => l.level === activeTabLevel) || levels[0];
  const userActiveConfig = levels.find(l => l.level === userVipRecord?.vipLevel);
  const isCurrentlyActiveLevel = userVipRecord?.status === 'ACTIVE' && userVipRecord.vipLevel === activeTabLevel;
  const isLowerThanActive = userVipRecord?.status === 'ACTIVE' && userVipRecord.vipLevel > activeTabLevel;
  const isHigherThanActive = userVipRecord?.status === 'ACTIVE' && userVipRecord.vipLevel < activeTabLevel;

  const durationPricing = currentLevelConfig ? currentLevelConfig.pricing : { '7d': 0, '30d': 0, '90d': 0, '365d': 0 };
  const currentPrice = durationPricing[selectedDuration as '7d' | '30d' | '90d' | '365d'] || durationPricing['30d'];

  // Handle Real VIP Purchase / Upgrade
  const handlePurchase = async () => {
    if (!currentLevelConfig) return;
    if (balance < currentPrice) {
      setErrorMsg(`Insufficient TEST COINS! Required: ${currentPrice.toLocaleString()} TC, Balance: ${balance.toLocaleString()} TC`);
      playSoundFX('alert');
      return;
    }

    setPurchasing(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await fetch('/api/vip/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          userName,
          userAvatar,
          targetLevel: currentLevelConfig.level,
          duration: selectedDuration,
          currentCoinBalance: balance
        })
      });

      const data = await res.json();

      if (data.success) {
        playSoundFX('win');
        setSuccessMsg(data.message || `👑 Successfully activated VIP ${currentLevelConfig.level} (${currentLevelConfig.title})!`);
        setUserVipRecord(data.vipRecord);
        setBalance(data.newCoinBalance);
        
        if (onVipUpdated) {
          onVipUpdated(currentLevelConfig.level, data.newCoinBalance);
        }

        // Trigger entrance effect celebration
        setEntranceTestEvent({
          id: `ENT-WIN-${Date.now()}`,
          userId,
          userName,
          userAvatar,
          vipLevel: currentLevelConfig.level,
          effect: currentLevelConfig.entranceEffect,
          timestamp: Date.now()
        });

        // Re-fetch transactions
        fetchTransactions();
      } else {
        setErrorMsg(data.error || 'VIP activation failed.');
        playSoundFX('alert');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Network error while activating VIP.');
    } finally {
      setPurchasing(false);
    }
  };

  // Test Entrance Effect in Live Simulator
  const handleTestEntrance = () => {
    if (!currentLevelConfig) return;
    playSoundFX('win');
    setEntranceTestEvent({
      id: `TEST-ENT-${Date.now()}`,
      userId,
      userName,
      userAvatar,
      vipLevel: currentLevelConfig.level,
      effect: currentLevelConfig.entranceEffect,
      timestamp: Date.now()
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-xl animate-in fade-in overflow-y-auto">
      
      {/* Floating Live Entrance Effect Banner */}
      <VipEntranceBanner 
        event={entranceTestEvent} 
        onComplete={() => setEntranceTestEvent(null)} 
      />

      <div className="relative bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border-2 border-amber-500/40 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-[0_0_50px_rgba(217,119,6,0.35)] overflow-hidden">
        
        {/* ========================================================================= */}
        {/* 1. TOP HEADER                                                             */}
        {/* ========================================================================= */}
        <div className="px-5 py-4 border-b border-amber-500/30 flex items-center justify-between bg-gradient-to-r from-amber-950/70 via-neutral-900 to-amber-950/50 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 via-yellow-400 to-amber-500 flex items-center justify-center text-black shadow-lg shadow-amber-950/60 font-black">
              <Crown className="w-6 h-6 fill-black" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                  SR LIVE NOBILITY VIP CENTER
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500/20 to-yellow-500/20 text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase tracking-wider font-mono">
                  VIP 1–10
                </span>
              </div>
              <p className="text-xs text-neutral-400">Official Membership, Exclusive Entrances & Sovereign Privileges</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setShowHistory(!showHistory);
                if (!showHistory) fetchTransactions();
              }}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 ${
                showHistory 
                  ? 'bg-amber-500 text-black border-amber-400' 
                  : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">History</span>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 2. USER STATUS & TEST COIN BALANCE STRIP                                 */}
        {/* ========================================================================= */}
        <div className="px-5 py-3 bg-neutral-950 border-b border-neutral-800/80 flex flex-wrap items-center justify-between gap-3 text-xs flex-shrink-0">
          
          {/* User VIP badge & remaining days */}
          <div className="flex items-center gap-3">
            <HostAvatarWithFrame 
              avatarUrl={userAvatar} 
              vipLevel={userVipRecord?.status === 'ACTIVE' ? userVipRecord.vipLevel : 0} 
              frameId={userActiveConfig?.frameId}
              size="sm" 
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-sm">{userName}</span>
                {userVipRecord?.status === 'ACTIVE' ? (
                  <VipBadge level={userVipRecord.vipLevel} size="xs" glow />
                ) : (
                  <span className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-400 text-[10px] font-bold">No Active VIP</span>
                )}
              </div>
              {userVipRecord?.status === 'ACTIVE' ? (
                <div className="flex items-center gap-2 text-[11px] text-amber-300 font-mono">
                  <Clock className="w-3 h-3 text-amber-400" />
                  <span>Valid for: <strong>{userVipRecord.remainingDays} days</strong> ({userVipRecord.remainingHours} hrs)</span>
                  <span className="text-neutral-500">•</span>
                  <span className="text-neutral-400 capitalize">{userVipRecord.planDuration} Plan</span>
                </div>
              ) : (
                <span className="text-neutral-500 text-[11px]">Subscribe to unlock VIP status, frames & cars</span>
              )}
            </div>
          </div>

          {/* Real Wallet Balance */}
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-neutral-900 border border-amber-500/30">
            <span className="text-neutral-400 text-xs">Wallet:</span>
            <span className="font-mono font-black text-yellow-400 text-sm">{balance.toLocaleString()}</span>
            <span className="text-amber-400 font-bold text-xs">🪙 TC</span>
          </div>

        </div>

        {/* Transaction History Drawer if toggled */}
        {showHistory ? (
          <div className="p-6 overflow-y-auto flex-1 space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                VIP Purchase & Upgrade History
              </h3>
              <button 
                onClick={() => setShowHistory(false)}
                className="text-xs text-amber-400 hover:underline font-bold"
              >
                Back to Nobility Center
              </button>
            </div>

            {transactions.length === 0 ? (
              <div className="py-12 text-center text-neutral-500 text-xs">
                No VIP transactions recorded yet.
              </div>
            ) : (
              <div className="space-y-2">
                {transactions.map(tx => (
                  <div key={tx.id} className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-300 font-bold">
                        V{tx.level}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-black text-white">{tx.levelTitle}</span>
                          <span className="px-1.5 py-0.2 rounded bg-neutral-800 text-[10px] text-neutral-300 uppercase font-mono">{tx.type}</span>
                        </div>
                        <span className="text-[11px] text-neutral-400">{tx.notes}</span>
                      </div>
                    </div>

                    <div className="text-right font-mono">
                      <span className="text-yellow-400 font-black block">-{tx.costCoins.toLocaleString()} TC</span>
                      <span className="text-[10px] text-neutral-500">{new Date(tx.timestamp).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* ========================================================================= */
          /* 3. MAIN NOBILITY CONTENT (TIER SELECTOR + PREVIEWS + PERKS)               */
          /* ========================================================================= */
          <div className="flex-1 overflow-y-auto flex flex-col">
            
            {/* VIP 1 to 10 Tier Navigation Pills */}
            <div className="p-3 bg-neutral-900/70 border-b border-neutral-800 overflow-x-auto flex items-center gap-2 scrollbar-none flex-shrink-0">
              {levels.map(tier => {
                const isSelected = activeTabLevel === tier.level;
                const isCurrent = userVipRecord?.status === 'ACTIVE' && userVipRecord.vipLevel === tier.level;

                return (
                  <button
                    key={tier.level}
                    onClick={() => {
                      setActiveTabLevel(tier.level);
                      playSoundFX('click');
                    }}
                    className={`flex-shrink-0 px-3.5 py-2 rounded-2xl border text-xs font-bold transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-black border-amber-300 shadow-lg shadow-amber-950/60 font-black scale-105'
                        : isCurrent
                        ? 'bg-amber-950/60 border-amber-500/60 text-amber-300'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                    }`}
                  >
                    <span>{tier.badgeIcon}</span>
                    <span>VIP {tier.level}</span>
                    {isCurrent && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Error or Success Alert */}
            {errorMsg && (
              <div className="m-4 p-3.5 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
            )}
            {successMsg && (
              <div className="m-4 p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Body Grid: Left = Preview Simulator, Right = Pricing & Privileges */}
            <div className="p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1">
              
              {/* Left Column: Interactive Previews (Frame, Entrance Car, Chat, Gifts) */}
              <div className="lg:col-span-5 space-y-4">
                
                {/* Preview Selector Tabs */}
                <div className="grid grid-cols-4 gap-1 p-1 bg-neutral-900 rounded-2xl border border-neutral-800 text-[11px] font-bold">
                  <button
                    onClick={() => setPreviewTab('frame')}
                    className={`py-1.5 rounded-xl transition-all ${previewTab === 'frame' ? 'bg-amber-500 text-black font-black' : 'text-neutral-400 hover:text-white'}`}
                  >
                    Frame
                  </button>
                  <button
                    onClick={() => setPreviewTab('entrance')}
                    className={`py-1.5 rounded-xl transition-all ${previewTab === 'entrance' ? 'bg-amber-500 text-black font-black' : 'text-neutral-400 hover:text-white'}`}
                  >
                    Entrance
                  </button>
                  <button
                    onClick={() => setPreviewTab('chat')}
                    className={`py-1.5 rounded-xl transition-all ${previewTab === 'chat' ? 'bg-amber-500 text-black font-black' : 'text-neutral-400 hover:text-white'}`}
                  >
                    Chat
                  </button>
                  <button
                    onClick={() => setPreviewTab('gifts')}
                    className={`py-1.5 rounded-xl transition-all ${previewTab === 'gifts' ? 'bg-amber-500 text-black font-black' : 'text-neutral-400 hover:text-white'}`}
                  >
                    Gifts
                  </button>
                </div>

                {/* Preview Canvas Box */}
                <div className="relative rounded-3xl bg-gradient-to-b from-neutral-900 to-neutral-950 border-2 border-amber-500/30 p-6 flex flex-col items-center justify-center min-h-[260px] overflow-hidden shadow-inner">
                  
                  {/* Subtle radial backdrop aura */}
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.12)_0%,transparent_70%)] pointer-events-none" />

                  {/* 1. FRAME PREVIEW */}
                  {previewTab === 'frame' && (
                    <div className="flex flex-col items-center gap-3 text-center z-10 animate-in fade-in">
                      <HostAvatarWithFrame 
                        avatarUrl={userAvatar} 
                        vipLevel={currentLevelConfig?.level} 
                        frameId={currentLevelConfig?.frameId}
                        size="xl" 
                      />
                      <div>
                        <h4 className="font-black text-white text-sm">{currentLevelConfig?.frameName}</h4>
                        <p className="text-[11px] text-amber-300/80">Animated 3D Halo for Level {currentLevelConfig?.level}</p>
                      </div>
                      <VipBadge level={currentLevelConfig?.level} size="md" glow />
                    </div>
                  )}

                  {/* 2. ENTRANCE VEHICLE PREVIEW */}
                  {previewTab === 'entrance' && (
                    <div className="flex flex-col items-center gap-3 text-center z-10 w-full animate-in fade-in">
                      <div className="text-5xl animate-bounce" style={{ animationDuration: '2s' }}>
                        {currentLevelConfig?.entranceEffect.emoji}
                      </div>
                      <div>
                        <h4 className="font-black text-white text-base text-amber-300">{currentLevelConfig?.entranceEffect.name}</h4>
                        <p className="text-xs text-neutral-300 max-w-xs">{currentLevelConfig?.entranceEffect.description}</p>
                      </div>
                      <button
                        onClick={handleTestEntrance}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-black font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-amber-950/50"
                      >
                        <Play className="w-3.5 h-3.5 fill-black" />
                        <span>Test Entrance Live</span>
                      </button>
                    </div>
                  )}

                  {/* 3. CHAT BUBBLE PREVIEW */}
                  {previewTab === 'chat' && (
                    <div className="w-full space-y-3 z-10 animate-in fade-in">
                      <span className="text-[11px] text-neutral-400 block text-center font-bold">Stream Chat Appearance</span>
                      
                      <div className={`p-3.5 rounded-2xl bg-gradient-to-r ${currentLevelConfig?.chatStyle.bubbleGradient} border ${currentLevelConfig?.chatStyle.bubbleBorder} shadow-lg space-y-1.5`}>
                        <div className="flex items-center gap-2">
                          <img src={userAvatar} alt="user" className="w-5 h-5 rounded-full border border-white/30 object-cover" />
                          <span className={`text-xs ${currentLevelConfig?.chatStyle.nameGlow}`}>{userName}</span>
                          <VipBadge level={currentLevelConfig?.level} size="xs" />
                        </div>
                        <p className="text-xs font-medium text-white/90 pl-1">
                          👑 Greetings everyone! Entering with VIP {currentLevelConfig?.level} status.
                        </p>
                      </div>

                      <div className="p-2 rounded-xl bg-neutral-900/90 border border-neutral-800 text-[11px] text-neutral-400 text-center">
                        Includes exclusive text color, bubble sheen & high-priority ranking.
                      </div>
                    </div>
                  )}

                  {/* 4. GIFTS PREVIEW */}
                  {previewTab === 'gifts' && (
                    <div className="w-full space-y-3 z-10 animate-in fade-in">
                      <span className="text-[11px] text-neutral-400 block text-center font-bold">Unlocked VIP Gifts</span>
                      <div className="grid grid-cols-2 gap-2">
                        {(currentLevelConfig?.unlockedGifts || []).map((giftName, idx) => (
                          <div key={idx} className="p-2.5 rounded-2xl bg-neutral-900/90 border border-amber-500/30 flex items-center gap-2 text-xs">
                            <Gift className="w-4 h-4 text-amber-400 flex-shrink-0" />
                            <span className="font-bold text-white truncate">{giftName}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>

                {/* Tier Highlights Summary */}
                <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-around text-center text-xs">
                  <div>
                    <span className="text-neutral-400 block text-[10px] uppercase font-bold">Store Discount</span>
                    <span className="font-black text-amber-400 text-sm">{currentLevelConfig?.storeDiscountPercent}% OFF</span>
                  </div>
                  <div className="w-px h-7 bg-neutral-800" />
                  <div>
                    <span className="text-neutral-400 block text-[10px] uppercase font-bold">Payout Tax Rebate</span>
                    <span className="font-black text-emerald-400 text-sm">{currentLevelConfig?.withdrawalTaxDiscountPercent}% Saved</span>
                  </div>
                  <div className="w-px h-7 bg-neutral-800" />
                  <div>
                    <span className="text-neutral-400 block text-[10px] uppercase font-bold">Coin Transfer</span>
                    <span className="font-black text-yellow-300 text-sm">
                      {currentLevelConfig?.coinTransferTaxDiscountPercent === 100 ? '0% Fee' : `${currentLevelConfig?.coinTransferTaxDiscountPercent}% Off`}
                    </span>
                  </div>
                </div>

              </div>

              {/* Right Column: Duration Selection, Privileges Matrix & Checkout */}
              <div className="lg:col-span-7 space-y-4 flex flex-col justify-between">
                
                <div className="space-y-4">
                  {/* Selected Tier Title Header */}
                  <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-400 uppercase font-mono tracking-wider">Nobility Tier</span>
                        <VipBadge level={currentLevelConfig?.level} size="sm" />
                      </div>
                      <h3 className="text-lg font-black text-white flex items-center gap-2">
                        VIP {currentLevelConfig?.level} — {currentLevelConfig?.title}
                      </h3>
                      <p className="text-xs text-neutral-400">{currentLevelConfig?.subtitle}</p>
                    </div>

                    <div className="text-right font-mono">
                      <span className="text-[10px] text-neutral-400 block uppercase">Monthly Spend Level</span>
                      <span className="text-xs font-bold text-yellow-400">
                        {currentLevelConfig?.monthlyCoinsRequired.toLocaleString()} 🪙
                      </span>
                    </div>
                  </div>

                  {/* Plan Duration Selector (7d, 30d, 90d, 365d) */}
                  <div>
                    <label className="text-xs font-bold text-neutral-300 mb-2 block">Choose Membership Duration:</label>
                    <div className="grid grid-cols-4 gap-2">
                      {[
                        { id: '7d', label: '7 Days', discount: '' },
                        { id: '30d', label: '30 Days', discount: 'Popular' },
                        { id: '90d', label: '90 Days', discount: 'Save 10%' },
                        { id: '365d', label: '1 Year', discount: 'Best Value' }
                      ].map(plan => {
                        const price = durationPricing[plan.id as '7d' | '30d' | '90d' | '365d'];
                        const isSelected = selectedDuration === plan.id;

                        return (
                          <button
                            key={plan.id}
                            onClick={() => {
                              setSelectedDuration(plan.id as VipPlanDuration);
                              playSoundFX('click');
                            }}
                            className={`relative p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                              isSelected
                                ? 'bg-gradient-to-b from-amber-500/20 to-neutral-900 border-amber-400 shadow-md shadow-amber-950/40'
                                : 'bg-neutral-900/80 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                            }`}
                          >
                            {plan.discount && (
                              <span className="absolute -top-2 right-2 px-1.5 py-0.2 rounded-full bg-amber-500 text-[8px] font-black text-black uppercase">
                                {plan.discount}
                              </span>
                            )}
                            <span className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-neutral-300'}`}>
                              {plan.label}
                            </span>
                            <div className="mt-2 font-mono">
                              <span className={`text-xs font-black ${isSelected ? 'text-yellow-400' : 'text-neutral-400'}`}>
                                {price.toLocaleString()}
                              </span>
                              <span className="text-[10px] text-amber-500 ml-1">TC</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Included Privileges List */}
                  <div>
                    <label className="text-xs font-bold text-neutral-300 mb-2 block flex items-center justify-between">
                      <span>Exclusive Privileges Included:</span>
                      <span className="text-[11px] text-amber-400 font-mono">{(currentLevelConfig?.privileges || []).length} Perks</span>
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[160px] overflow-y-auto pr-1">
                      {(currentLevelConfig?.privileges || []).map((privilege, idx) => (
                        <div key={idx} className="flex items-center gap-2 p-2 rounded-xl bg-neutral-900/90 border border-neutral-800 text-xs text-neutral-200">
                          <div className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-black flex-shrink-0">
                            ✓
                          </div>
                          <span className="truncate">{privilege}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Checkout & Action Button */}
                <div className="pt-4 border-t border-neutral-800 space-y-3">
                  
                  {/* Price breakdown bar */}
                  <div className="flex items-center justify-between p-3.5 rounded-2xl bg-neutral-900 border border-amber-500/30">
                    <div>
                      <span className="text-[11px] text-neutral-400 block">Total Investment:</span>
                      <div className="flex items-baseline gap-1 font-mono">
                        <span className="text-lg font-black text-yellow-400">{currentPrice.toLocaleString()}</span>
                        <span className="text-xs font-bold text-amber-400">TEST COINS</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[11px] text-neutral-400 block">Status:</span>
                      <span className={`text-xs font-black ${isCurrentlyActiveLevel ? 'text-emerald-400' : 'text-neutral-300'}`}>
                        {isCurrentlyActiveLevel ? 'Current Active Tier' : isHigherThanActive ? 'Tier Upgrade' : 'Direct Activation'}
                      </span>
                    </div>
                  </div>

                  {/* Purchase CTA */}
                  <button
                    onClick={handlePurchase}
                    disabled={purchasing}
                    className={`w-full py-3.5 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-xl ${
                      balance < currentPrice
                        ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        : 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-black shadow-amber-950/60 active:scale-[0.99]'
                    }`}
                  >
                    {purchasing ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        <span>Activating Nobility Status...</span>
                      </div>
                    ) : balance < currentPrice ? (
                      <span>Insufficient Test Coins ({balance.toLocaleString()} TC)</span>
                    ) : isCurrentlyActiveLevel ? (
                      <>
                        <Zap className="w-4 h-4 fill-black" />
                        <span>Renew VIP {currentLevelConfig?.level} for {selectedDuration} ({currentPrice.toLocaleString()} TC)</span>
                      </>
                    ) : (
                      <>
                        <Crown className="w-4 h-4 fill-black" />
                        <span>Unlock VIP {currentLevelConfig?.level} ({currentLevelConfig?.title})</span>
                      </>
                    )}
                  </button>

                  <p className="text-[10px] text-neutral-500 text-center">
                    Instant activation with real wallet coin deduction. Status applies app-wide in Live Streams, Party Rooms & Chat.
                  </p>
                </div>

              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
