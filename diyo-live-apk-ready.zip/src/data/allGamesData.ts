export type GameCategoryType = 'All' | 'Slots' | 'Cards' | 'Dice' | 'Arcade' | 'Fishing' | 'Sports' | 'Other';

export interface GameCatalogItem {
  id: string;
  name: string;
  category: 'Slots' | 'Cards' | 'Dice' | 'Arcade' | 'Fishing' | 'Sports' | 'Other';
  icon: string;
  banner: string;
  rtpRate: number;
  minBet: number;
  maxBet?: number;
  maxMultiplier: string;
  isHot?: boolean;
  isNew?: boolean;
  totalPlays: number;
  description: string;
}

// EXACT APPROVED 17 GAMES FOR TROPHY PARTY LIVE PLATFORM
export const CATALOG_17_GAMES: GameCatalogItem[] = [
  {
    id: 'mahjong_ways_2',
    name: 'Mahjong Ways 2',
    category: 'Arcade',
    icon: '🀄',
    banner: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.1,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '800x',
    isHot: true,
    isNew: false,
    totalPlays: 785000,
    description: '1024-Ways Jade & Gold Dragon Cascade with Transforming Tiles & 800x Combos.'
  },
  {
    id: 'slot',
    name: 'Slot',
    category: 'Slots',
    icon: '🎰',
    banner: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    rtpRate: 97.8,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '777x',
    isHot: true,
    isNew: false,
    totalPlays: 940000,
    description: 'Vegas Royal 777 5-Reel Video Slots with Free Spins Scatters & Wild Stars.'
  },
  {
    id: 'yummy',
    name: 'Yummy',
    category: 'Arcade',
    icon: '🍬',
    banner: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.4,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '1200x',
    isHot: true,
    isNew: true,
    totalPlays: 890000,
    description: 'Sweet Sugar Wonderland with Gummy Bombs & 1200x Lollipop Multipliers.'
  },
  {
    id: 'dragon_tiger',
    name: 'Dragon Tiger',
    category: 'Cards',
    icon: '🐯',
    banner: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.2,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '12x',
    isHot: true,
    isNew: false,
    totalPlays: 995000,
    description: '3D Dragon vs Tiger Fortune Arena with Live Roadmaps & 12x Tie Jackpots.'
  },
  {
    id: 'lion_greedy',
    name: 'Lion Greedy',
    category: 'Slots',
    icon: '🦁',
    banner: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    rtpRate: 97.6,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '750x',
    isHot: false,
    isNew: true,
    totalPlays: 540000,
    description: 'Savannah King 3D Adventure with Roaring Lion Multipliers & 750x Golden Totems.'
  },
  {
    id: 'teen_patti',
    name: 'Teen Patti',
    category: 'Cards',
    icon: '🃏',
    banner: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.0,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '500x',
    isHot: true,
    isNew: false,
    totalPlays: 1120000,
    description: '3-Card Poker Showdown with Blind/Seen Modes & Live Virtual Tables.'
  },
  {
    id: 'luck77',
    name: 'Luck77',
    category: 'Slots',
    icon: '🎰',
    banner: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.3,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '777x',
    isHot: true,
    isNew: false,
    totalPlays: 1250000,
    description: 'Cyber-Gold Triple 7s Video Slot with Neon Lasers & 777x Grand Vegas Jackpot.'
  },
  {
    id: 'greedy_box',
    name: 'Greedy Box',
    category: 'Arcade',
    icon: '🎡',
    banner: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.5,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '1000x',
    isHot: true,
    isNew: false,
    totalPlays: 1080000,
    description: 'Futuristic 3D Neon Rotary Wheel with Multi-Pointer Wedges & 1000x Mega Vault.'
  },
  {
    id: 'speed_racing',
    name: 'Speed Racing',
    category: 'Arcade',
    icon: '🏎️',
    banner: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    rtpRate: 97.4,
    minBet: 10000,
    maxBet: 2000000,
    maxMultiplier: '1500x',
    isHot: false,
    isNew: true,
    totalPlays: 620000,
    description: 'High-Speed Neon Supercar Grand Prix with Turbo Multipliers & 1500x Finish Line.'
  },
  {
    id: 'fruit_party',
    name: 'Fruit Party',
    category: 'Slots',
    icon: '🍉',
    banner: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    rtpRate: 97.9,
    minBet: 10000,
    maxBet: 3000000,
    maxMultiplier: '800x',
    isHot: true,
    isNew: false,
    totalPlays: 790000,
    description: 'Juicy Tropical Fruit Festival with Watermelon Scatters & 800x Cocktail Frenzy.'
  },
  {
    id: 'greedy_baby',
    name: 'Greedy Baby',
    category: 'Arcade',
    icon: '👼',
    banner: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.7,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '2000x',
    isHot: true,
    isNew: false,
    totalPlays: 970000,
    description: 'Celestial Anime Magic Realm with Shimmering Wand Multipliers & 2000x Celestial Drops.'
  },
  {
    id: 'food_greedy',
    name: 'Food Greedy',
    category: 'Arcade',
    icon: '🍔',
    banner: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600&auto=format&fit=crop&q=80',
    rtpRate: 97.5,
    minBet: 10000,
    maxBet: 4000000,
    maxMultiplier: '650x',
    isHot: false,
    isNew: true,
    totalPlays: 460000,
    description: 'Royal Feast Buffet with Golden Burgers, Diamond Desserts & 650x Gourmet Vault.'
  },
  {
    id: 'fishing_star',
    name: 'Fishing Star',
    category: 'Fishing',
    icon: '🐟',
    banner: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&auto=format&fit=crop&q=80',
    rtpRate: 97.9,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '888x',
    isHot: true,
    isNew: false,
    totalPlays: 730000,
    description: 'Deep Sea Underwater Abyss with Golden Pearl Drops & 888x Kraken Chest Jackpots.'
  },
  {
    id: 'magic_slot',
    name: 'Magic Slot',
    category: 'Slots',
    icon: '✨',
    banner: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.0,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '1000x',
    isHot: true,
    isNew: false,
    totalPlays: 850000,
    description: 'Mystic Archmage Spellbook with Arcane Free Spins & 1000x Mythic Jackpots.'
  },
  {
    id: 'lava_link',
    name: 'LAVA LINK',
    category: 'Arcade',
    icon: '🔥',
    banner: 'https://images.unsplash.com/photo-1541845157-a6d2d100c931?w=600&auto=format&fit=crop&q=80',
    rtpRate: 97.7,
    minBet: 10000,
    maxBet: 3000000,
    maxMultiplier: '250x',
    isHot: true,
    isNew: false,
    totalPlays: 670000,
    description: '10-Level Volcanic Tower Climb with Exponential 250x Survival Payouts.'
  },
  {
    id: 'rocket',
    name: 'Rocket',
    category: 'Arcade',
    icon: '🚀',
    banner: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    rtpRate: 99.0,
    minBet: 10000,
    maxBet: 5000000,
    maxMultiplier: '1000x',
    isHot: true,
    isNew: false,
    totalPlays: 1420000,
    description: 'Provably Fair Starship Multiplier Climb with Auto-Cashout & 1000x Max Orbit.'
  },
  {
    id: 'lucky_bag',
    name: 'LuckyBag',
    category: 'Other',
    icon: '🎁',
    banner: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=600&auto=format&fit=crop&q=80',
    rtpRate: 98.8,
    minBet: 10000,
    maxBet: 1000000,
    maxMultiplier: '100x',
    isHot: false,
    isNew: false,
    totalPlays: 810000,
    description: 'Bronze, Silver, Gold & Royal Fortune Lucky Bags with Guaranteed Multiplier Drops.'
  }
];

// Alias for backwards-compatibility
export const CATALOG_26_GAMES: GameCatalogItem[] = CATALOG_17_GAMES;
