import { Request, Response } from 'express';
import { VipLevelConfig, UserVipRecord, VipTransaction, VipSystemStats, VipPlanDuration } from '../types/vipTypes.js';

// Initial VIP 1 to 10 Configurations
export const INITIAL_VIP_LEVELS: VipLevelConfig[] = [
  {
    level: 1,
    title: 'Bronze Noble',
    subtitle: 'Entry Nobility Status',
    badgeLabel: 'VIP 1',
    badgeIcon: '🥉',
    badgeColor: '#d97706',
    textColor: '#fef3c7',
    gradient: 'from-amber-700 via-amber-600 to-amber-900',
    frameId: 'FRM-VIP-01',
    frameName: 'VIP 1 Starlight Halo',
    frameBorderClass: 'border-amber-500',
    monthlyCoinsRequired: 10000,
    pricing: {
      '7d': 3000,
      '30d': 10000,
      '90d': 27000,
      '365d': 90000
    },
    entranceEffect: {
      id: 'ENT-VIP-01',
      name: '🏎️ Neon Cyber Roadster',
      type: 'supercar',
      emoji: '🏎️',
      soundFx: 'engine_rev',
      bannerGradient: 'from-amber-600 to-yellow-600',
      description: 'Sporty neon roadster cruising onto the live screen.'
    },
    chatStyle: {
      bubbleGradient: 'from-amber-950/60 via-neutral-900 to-neutral-950',
      bubbleBorder: 'border-amber-600/40',
      textColor: '#fef3c7',
      nameGlow: 'text-amber-300',
      badgeGlow: 'shadow-[0_0_8px_rgba(217,119,6,0.5)]'
    },
    storeDiscountPercent: 5,
    withdrawalTaxDiscountPercent: 5,
    coinTransferTaxDiscountPercent: 0,
    privileges: [
      'Bronze VIP Badge in Chat & Profile',
      'VIP 1 Starlight Halo Avatar Frame',
      'Neon Cyber Roadster Entrance Banner',
      '5% Virtual Store Discount',
      'Custom Bronze Chat Highlight',
      'Unlock VIP 1 Exclusive Gifts'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish'],
    totalActiveMembers: 1420,
    isActive: true
  },
  {
    level: 2,
    title: 'Silver Guardian',
    subtitle: 'Silver Elite Nobility',
    badgeLabel: 'VIP 2',
    badgeIcon: '🥈',
    badgeColor: '#94a3b8',
    textColor: '#f8fafc',
    gradient: 'from-slate-600 via-slate-500 to-zinc-700',
    frameId: 'FRM-VIP-02',
    frameName: 'VIP 2 Crystal Azure Frame',
    frameBorderClass: 'border-sky-400',
    monthlyCoinsRequired: 30000,
    pricing: {
      '7d': 8000,
      '30d': 25000,
      '90d': 65000,
      '365d': 220000
    },
    entranceEffect: {
      id: 'ENT-VIP-02',
      name: '🏍️ Crystal Hoverbike',
      type: 'aircraft',
      emoji: '🏍️',
      soundFx: 'whoosh',
      bannerGradient: 'from-slate-600 via-cyan-700 to-slate-900',
      description: 'Futuristic floating hoverbike with cyan trail.'
    },
    chatStyle: {
      bubbleGradient: 'from-slate-900/80 via-neutral-900 to-slate-950',
      bubbleBorder: 'border-slate-400/50',
      textColor: '#f1f5f9',
      nameGlow: 'text-slate-200',
      badgeGlow: 'shadow-[0_0_10px_rgba(148,163,184,0.6)]'
    },
    storeDiscountPercent: 8,
    withdrawalTaxDiscountPercent: 10,
    coinTransferTaxDiscountPercent: 5,
    privileges: [
      'Silver VIP 2 Shiny Badge',
      'VIP 2 Crystal Azure Animated Frame',
      'Crystal Hoverbike Stream Entrance',
      '8% Store Discount',
      '10% Payout Tax Rebate',
      'Unlock Silver Champagne Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne'],
    totalActiveMembers: 980,
    isActive: true
  },
  {
    level: 3,
    title: 'Golden Baron',
    subtitle: 'Golden Knight Royalty',
    badgeLabel: 'VIP 3',
    badgeIcon: '🥇',
    badgeColor: '#eab308',
    textColor: '#fef08a',
    gradient: 'from-yellow-600 via-amber-500 to-yellow-700',
    frameId: 'FRM-VIP-03',
    frameName: 'VIP 3 Sapphire Radiance',
    frameBorderClass: 'border-blue-500',
    monthlyCoinsRequired: 80000,
    pricing: {
      '7d': 20000,
      '30d': 65000,
      '90d': 175000,
      '365d': 580000
    },
    entranceEffect: {
      id: 'ENT-VIP-03',
      name: '🏎️ Golden Ferrari Spider',
      type: 'supercar',
      emoji: '🏎️',
      soundFx: 'engine_turbo',
      bannerGradient: 'from-yellow-600 via-amber-600 to-neutral-950',
      description: 'Gold-plated convertible supercar with glowing headlights.'
    },
    chatStyle: {
      bubbleGradient: 'from-amber-950/70 via-neutral-900 to-yellow-950/50',
      bubbleBorder: 'border-yellow-500/60',
      textColor: '#fef08a',
      nameGlow: 'text-yellow-300 font-bold',
      badgeGlow: 'shadow-[0_0_12px_rgba(234,179,8,0.7)]'
    },
    storeDiscountPercent: 12,
    withdrawalTaxDiscountPercent: 15,
    coinTransferTaxDiscountPercent: 10,
    privileges: [
      'Golden Baron VIP 3 Badge with Gold Glow',
      'VIP 3 Sapphire Radiance Frame',
      'Golden Ferrari Live Room Entrance Effect',
      '12% Store Discount',
      '15% Cashout Tax Rebate',
      'Priority Party Live Guest Seat Request',
      'Unlock Golden Castle Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne', 'Golden Castle'],
    totalActiveMembers: 760,
    isActive: true,
    isPopular: true
  },
  {
    level: 4,
    title: 'Platinum Duke',
    subtitle: 'High Sovereign Duke',
    badgeLabel: 'VIP 4',
    badgeIcon: '💎',
    badgeColor: '#38bdf8',
    textColor: '#e0f2fe',
    gradient: 'from-sky-500 via-blue-600 to-indigo-700',
    frameId: 'FRM-VIP-04',
    frameName: 'VIP 4 Ruby Blaze Emperor',
    frameBorderClass: 'border-rose-500',
    monthlyCoinsRequired: 200000,
    pricing: {
      '7d': 50000,
      '30d': 160000,
      '90d': 420000,
      '365d': 1400000
    },
    entranceEffect: {
      id: 'ENT-VIP-04',
      name: '🚁 Platinum Stealth Chopper',
      type: 'aircraft',
      emoji: '🚁',
      soundFx: 'helicopter',
      bannerGradient: 'from-sky-700 via-blue-800 to-neutral-950',
      description: 'Sleek luxury platinum helicopter landing in stream.'
    },
    chatStyle: {
      bubbleGradient: 'from-sky-950/70 via-neutral-900 to-blue-950/60',
      bubbleBorder: 'border-sky-400/60',
      textColor: '#e0f2fe',
      nameGlow: 'text-sky-300 font-extrabold',
      badgeGlow: 'shadow-[0_0_14px_rgba(56,189,248,0.7)]'
    },
    storeDiscountPercent: 15,
    withdrawalTaxDiscountPercent: 20,
    coinTransferTaxDiscountPercent: 15,
    privileges: [
      'Platinum Duke VIP 4 Animated Badge',
      'VIP 4 Ruby Blaze Emperor Frame',
      'Platinum Helicopter Entrance with Audio',
      'Flying Bullet Chat (Barrage effect)',
      '15% Store Discount',
      '20% Payout Tax Rebate',
      'Unlock Platinum Ring Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne', 'Golden Castle', 'Platinum Ring'],
    totalActiveMembers: 540,
    isActive: true
  },
  {
    level: 5,
    title: 'Diamond Prince',
    subtitle: 'Royal Diamond Nobility',
    badgeLabel: 'VIP 5',
    badgeIcon: '👑',
    badgeColor: '#c084fc',
    textColor: '#fae8ff',
    gradient: 'from-purple-600 via-pink-600 to-indigo-700',
    frameId: 'FRM-VIP-05',
    frameName: 'VIP 5 Diamond Crown Aura',
    frameBorderClass: 'border-purple-400',
    monthlyCoinsRequired: 500000,
    pricing: {
      '7d': 120000,
      '30d': 380000,
      '90d': 980000,
      '365d': 3200000
    },
    entranceEffect: {
      id: 'ENT-VIP-05',
      name: '🛥️ Diamond Luxury Yacht',
      type: 'chariot',
      emoji: '🛥️',
      soundFx: 'yacht_horn',
      bannerGradient: 'from-purple-800 via-pink-800 to-neutral-950',
      description: 'Diamond megayacht cruising across live screen with fireworks.'
    },
    chatStyle: {
      bubbleGradient: 'from-purple-950/80 via-neutral-900 to-pink-950/60',
      bubbleBorder: 'border-purple-400/70',
      textColor: '#fae8ff',
      nameGlow: 'text-purple-300 font-black',
      badgeGlow: 'shadow-[0_0_16px_rgba(192,132,252,0.8)]'
    },
    storeDiscountPercent: 20,
    withdrawalTaxDiscountPercent: 25,
    coinTransferTaxDiscountPercent: 25,
    privileges: [
      'Diamond Prince VIP 5 Shimmering Badge',
      'VIP 5 Diamond Crown Aura Frame',
      'Diamond Yacht Arrival Broadcast with Fireworks',
      'Exclusive Room Host Anti-Kick Immunity',
      '20% Store Discount',
      '25% Cashout Tax Rebate',
      'Unlock Diamond Tiara Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne', 'Golden Castle', 'Platinum Ring', 'Diamond Tiara'],
    totalActiveMembers: 390,
    isActive: true,
    isPopular: true
  },
  {
    level: 6,
    title: 'Dragon Overlord',
    subtitle: 'Mythical Dragon Monarch',
    badgeLabel: 'VIP 6',
    badgeIcon: '🐉',
    badgeColor: '#f43f5e',
    textColor: '#ffe4e6',
    gradient: 'from-rose-600 via-red-600 to-amber-600',
    frameId: 'FRM-VIP-06',
    frameName: 'VIP 6 Cyber Dragon Lord',
    frameBorderClass: 'border-fuchsia-500',
    monthlyCoinsRequired: 1200000,
    pricing: {
      '7d': 280000,
      '30d': 880000,
      '90d': 2300000,
      '365d': 7500000
    },
    entranceEffect: {
      id: 'ENT-VIP-06',
      name: '🐉 Celestial Fire Dragon',
      type: 'dragon',
      emoji: '🐉',
      soundFx: 'dragon_roar',
      bannerGradient: 'from-rose-800 via-red-700 to-amber-800',
      description: 'Flying fire dragon soaring across with blazing smoke trails.'
    },
    chatStyle: {
      bubbleGradient: 'from-rose-950/80 via-neutral-900 to-amber-950/60',
      bubbleBorder: 'border-rose-500/80',
      textColor: '#ffe4e6',
      nameGlow: 'text-rose-400 font-black tracking-wide',
      badgeGlow: 'shadow-[0_0_18px_rgba(244,63,94,0.85)]'
    },
    storeDiscountPercent: 25,
    withdrawalTaxDiscountPercent: 30,
    coinTransferTaxDiscountPercent: 50,
    privileges: [
      'VIP 6 Dragon Overlord Flaming Badge',
      'VIP 6 Cyber Dragon Lord Animated Frame',
      'Celestial Fire Dragon Entrance with Roar SFX',
      'Permanent Room Kick/Mute Shield (Except Owner)',
      'Global Stream Entrance Notification Bar',
      '25% Store Discount',
      '30% Cashout Tax Rebate',
      'Unlock Mythical Dragon Palace Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne', 'Golden Castle', 'Platinum Ring', 'Diamond Tiara', 'Dragon Palace'],
    totalActiveMembers: 240,
    isActive: true
  },
  {
    level: 7,
    title: 'Galaxy Lord',
    subtitle: 'Universal Astral Ruler',
    badgeLabel: 'VIP 7',
    badgeIcon: '🌌',
    badgeColor: '#818cf8',
    textColor: '#e0e7ff',
    gradient: 'from-indigo-600 via-purple-600 to-cyan-500',
    frameId: 'FRM-VIP-07',
    frameName: 'VIP 7 Galaxy Lord Sovereign',
    frameBorderClass: 'border-indigo-400',
    monthlyCoinsRequired: 3000000,
    pricing: {
      '7d': 650000,
      '30d': 2000000,
      '90d': 5200000,
      '365d': 17000000
    },
    entranceEffect: {
      id: 'ENT-VIP-07',
      name: '🚀 Hyper Galaxy Cruiser',
      type: 'aircraft',
      emoji: '🚀',
      soundFx: 'warp_speed',
      bannerGradient: 'from-indigo-800 via-purple-800 to-cyan-900',
      description: 'Cosmic starship hyper-jumping into the live channel.'
    },
    chatStyle: {
      bubbleGradient: 'from-indigo-950/90 via-purple-950/60 to-cyan-950/70',
      bubbleBorder: 'border-indigo-400/80',
      textColor: '#e0e7ff',
      nameGlow: 'text-indigo-300 font-black tracking-wider',
      badgeGlow: 'shadow-[0_0_20px_rgba(129,140,248,0.9)]'
    },
    storeDiscountPercent: 30,
    withdrawalTaxDiscountPercent: 40,
    coinTransferTaxDiscountPercent: 75,
    privileges: [
      'VIP 7 Galaxy Lord Nebula Badge with Constellation Orbit',
      'VIP 7 Galaxy Lord Sovereign Frame',
      'Hyper Galaxy Cruiser Warp Entrance',
      'Full App-Wide Global Top Banner Broadcast on Entry',
      'Stealth Mode Option (Browse streams anonymously)',
      '30% Store Discount',
      '40% Cashout Tax Rebate',
      'Unlock Cosmic Galaxy Cruiser Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne', 'Golden Castle', 'Platinum Ring', 'Diamond Tiara', 'Dragon Palace', 'Galaxy Cruiser'],
    totalActiveMembers: 160,
    isActive: true,
    isRoyalty: true
  },
  {
    level: 8,
    title: 'Imperial Emperor',
    subtitle: 'Supreme Royal Sovereign',
    badgeLabel: 'VIP 8',
    badgeIcon: '👑',
    badgeColor: '#fbbf24',
    textColor: '#fef3c7',
    gradient: 'from-amber-400 via-yellow-300 to-amber-500',
    frameId: 'FRM-VIP-08',
    frameName: 'VIP 8 Imperial Sovereign Crown',
    frameBorderClass: 'border-amber-300',
    monthlyCoinsRequired: 8000000,
    pricing: {
      '7d': 1500000,
      '30d': 4500000,
      '90d': 12000000,
      '365d': 40000000
    },
    entranceEffect: {
      id: 'ENT-VIP-08',
      name: '🦁 Golden Lion Royal Chariot',
      type: 'chariot',
      emoji: '🦁',
      soundFx: 'royal_fanfare',
      bannerGradient: 'from-amber-500 via-yellow-400 to-amber-600',
      description: 'Twin golden winged lions pulling an imperial jewel-encrusted royal chariot with trumpets.'
    },
    chatStyle: {
      bubbleGradient: 'from-amber-900/90 via-yellow-900/40 to-neutral-950',
      bubbleBorder: 'border-2 border-yellow-300',
      textColor: '#ffffff',
      nameGlow: 'text-amber-300 font-black tracking-widest text-shadow-gold',
      badgeGlow: 'shadow-[0_0_24px_rgba(251,191,36,1)]'
    },
    storeDiscountPercent: 35,
    withdrawalTaxDiscountPercent: 50,
    coinTransferTaxDiscountPercent: 100,
    privileges: [
      'VIP 8 Imperial Sovereign 3D Golden Crown Badge',
      'VIP 8 Imperial Sovereign Crown Frame with Rubies',
      'Golden Lion Royal Chariot Entrance with Royal Fanfare audio',
      '0% Fee Unlimited Coin Transfers (100% Tax Rebate)',
      'Global Server-Wide Sound Notification on Entrance',
      'Dedicated VIP Concierge Customer Support',
      '35% Store Discount',
      '50% Cashout Tax Rebate',
      'Unlock Crown of Imperial Emperor Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne', 'Golden Castle', 'Platinum Ring', 'Diamond Tiara', 'Dragon Palace', 'Galaxy Cruiser', 'Imperial Crown'],
    totalActiveMembers: 95,
    isActive: true,
    isPopular: true,
    isRoyalty: true
  },
  {
    level: 9,
    title: 'Solar Sovereign',
    subtitle: 'Divine Sun Monarch',
    badgeLabel: 'VIP 9',
    badgeIcon: '⚡',
    badgeColor: '#f59e0b',
    textColor: '#fffbeb',
    gradient: 'from-orange-500 via-amber-400 to-yellow-300',
    frameId: 'FRM-VIP-09',
    frameName: 'VIP 9 Solar Phoenix Frame',
    frameBorderClass: 'border-orange-400',
    monthlyCoinsRequired: 20000000,
    pricing: {
      '7d': 3500000,
      '30d': 10000000,
      '90d': 26000000,
      '365d': 85000000
    },
    entranceEffect: {
      id: 'ENT-VIP-09',
      name: '🦅 Solar Golden Phoenix',
      type: 'phoenix',
      emoji: '🦅',
      soundFx: 'phoenix_screech',
      bannerGradient: 'from-orange-600 via-amber-500 to-yellow-400',
      description: 'Immortal flaming solar phoenix illuminating the entire stream room.'
    },
    chatStyle: {
      bubbleGradient: 'from-orange-950/90 via-amber-950/60 to-yellow-950/50',
      bubbleBorder: 'border-2 border-orange-400',
      textColor: '#ffffff',
      nameGlow: 'text-orange-300 font-black tracking-widest',
      badgeGlow: 'shadow-[0_0_28px_rgba(245,158,11,1)]'
    },
    storeDiscountPercent: 40,
    withdrawalTaxDiscountPercent: 65,
    coinTransferTaxDiscountPercent: 100,
    privileges: [
      'VIP 9 Solar Sovereign Radiant Plasma Badge',
      'VIP 9 Solar Phoenix Frame with Pulsating Sunrays',
      'Golden Solar Phoenix Flight Entrance Animation',
      'Room Host Mic Auto-Reserve Priority #1',
      'Custom Unique User Profile Background Theme',
      '40% Store Discount',
      '65% Cashout Tax Rebate',
      'Unlock Solar Phoenix Avatar Effect & Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne', 'Golden Castle', 'Platinum Ring', 'Diamond Tiara', 'Dragon Palace', 'Galaxy Cruiser', 'Imperial Crown', 'Solar Phoenix'],
    totalActiveMembers: 42,
    isActive: true,
    isRoyalty: true
  },
  {
    level: 10,
    title: 'Celestial Supreme God',
    subtitle: 'Apex Deity of SR LIVE',
    badgeLabel: 'VIP 10',
    badgeIcon: '🌟',
    badgeColor: '#ec4899',
    textColor: '#ffffff',
    gradient: 'from-pink-500 via-purple-600 to-amber-400',
    frameId: 'FRM-VIP-10',
    frameName: 'VIP 10 Celestial Supreme God Frame',
    frameBorderClass: 'border-pink-400',
    monthlyCoinsRequired: 50000000,
    pricing: {
      '7d': 8000000,
      '30d': 25000000,
      '90d': 65000000,
      '365d': 200000000
    },
    entranceEffect: {
      id: 'ENT-VIP-10',
      name: '👑 Supreme Sovereign Celestial Throne',
      type: 'throne',
      emoji: '👑',
      soundFx: 'divine_choir',
      bannerGradient: 'from-pink-600 via-purple-700 to-amber-500',
      description: 'Floating divine crystalline throne descending from the heavens with full-screen cosmic stars.'
    },
    chatStyle: {
      bubbleGradient: 'from-purple-950/90 via-pink-950/70 to-amber-950/80',
      bubbleBorder: 'border-2 border-gradient-to-r border-pink-400 animate-pulse',
      textColor: '#ffffff',
      nameGlow: 'text-amber-200 font-black tracking-widest text-shadow-neon',
      badgeGlow: 'shadow-[0_0_35px_rgba(236,72,153,1)]'
    },
    storeDiscountPercent: 50,
    withdrawalTaxDiscountPercent: 80,
    coinTransferTaxDiscountPercent: 100,
    privileges: [
      'VIP 10 Supreme Celestial God Multi-Prism Diamond Badge',
      'VIP 10 Celestial Supreme God Animated Infinity Frame',
      'Supreme Sovereign Throne Entrance with Divine Choir SFX',
      'Full App-Wide Global Announcement every time you enter any Live Room',
      'Host Immunity: Cannot be kicked, muted, or restricted in any stream',
      '0% Transfer Fees + 80% Cashout Tax Rebate',
      '50% Permanent Store Discount on all items',
      'Custom Personal VIP Account Manager & Direct Line',
      'Unlock Apex God of Olympus Infinite Gift'
    ],
    unlockedGifts: ['Bronze Trophy', 'Starlight Wish', 'Silver Champagne', 'Golden Castle', 'Platinum Ring', 'Diamond Tiara', 'Dragon Palace', 'Galaxy Cruiser', 'Imperial Crown', 'Solar Phoenix', 'Apex God Throne'],
    totalActiveMembers: 18,
    isActive: true,
    isPopular: true,
    isRoyalty: true
  }
];

// In-Memory Data Stores
export let serverVipLevels: VipLevelConfig[] = JSON.parse(JSON.stringify(INITIAL_VIP_LEVELS));

export let serverUserVipRecords: Map<string, UserVipRecord> = new Map([
  [
    'USR-882941', // Aarav Mehta (Current Active User)
    {
      userId: 'USR-882941',
      userName: 'Aarav Mehta',
      userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      vipLevel: 8,
      status: 'ACTIVE',
      planDuration: '30d',
      activatedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      expiresAt: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000).toISOString(),
      remainingDays: 25,
      remainingHours: 600,
      autoRenew: true,
      totalCoinsSpentOnVip: 4500000,
      renewalCount: 1
    }
  ],
  [
    'USR-8002',
    {
      userId: 'USR-8002',
      userName: 'Meera Patel',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      vipLevel: 6,
      status: 'ACTIVE',
      planDuration: '30d',
      activatedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
      expiresAt: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000).toISOString(),
      remainingDays: 20,
      remainingHours: 480,
      autoRenew: false,
      totalCoinsSpentOnVip: 880000,
      renewalCount: 0
    }
  ],
  [
    'HST-901',
    {
      userId: 'HST-901',
      userName: 'Ananya Sharma',
      userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      vipLevel: 7,
      status: 'ACTIVE',
      planDuration: '90d',
      activatedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
      expiresAt: new Date(Date.now() + 75 * 24 * 60 * 60 * 1000).toISOString(),
      remainingDays: 75,
      remainingHours: 1800,
      autoRenew: true,
      totalCoinsSpentOnVip: 5200000,
      renewalCount: 1
    }
  ],
  [
    'USR-8004',
    {
      userId: 'USR-8004',
      userName: 'David Miller',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      vipLevel: 4,
      status: 'ACTIVE',
      planDuration: '7d',
      activatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      expiresAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
      remainingDays: 5,
      remainingHours: 120,
      autoRenew: false,
      totalCoinsSpentOnVip: 50000,
      renewalCount: 0
    }
  ]
]);

export let serverVipTransactions: VipTransaction[] = [
  {
    id: 'VIP-TX-9001',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    type: 'VIP_PURCHASE',
    level: 8,
    levelTitle: 'Imperial Emperor',
    duration: '30d',
    durationDays: 30,
    costCoins: 4500000,
    prevBalance: 5204922000,
    newBalance: 5200422000,
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'COMPLETED',
    notes: 'Purchased 30-Day VIP 8 Imperial Emperor Membership with full privileges.'
  },
  {
    id: 'VIP-TX-9002',
    userId: 'HST-901',
    userName: 'Ananya Sharma',
    userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
    type: 'VIP_PURCHASE',
    level: 7,
    levelTitle: 'Galaxy Lord',
    duration: '90d',
    durationDays: 90,
    costCoins: 5200000,
    prevBalance: 12000000,
    newBalance: 6800000,
    timestamp: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'COMPLETED',
    notes: 'Purchased 90-Day VIP 7 Galaxy Lord Membership.'
  },
  {
    id: 'VIP-TX-9003',
    userId: 'USR-8002',
    userName: 'Meera Patel',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    type: 'VIP_PURCHASE',
    level: 6,
    levelTitle: 'Dragon Overlord',
    duration: '30d',
    durationDays: 30,
    costCoins: 880000,
    prevBalance: 3500000,
    newBalance: 2620000,
    timestamp: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'COMPLETED',
    notes: 'Activated 30-Day VIP 6 Dragon Overlord tier.'
  }
];

// Helper: Get duration in days
function getDaysFromDuration(duration: VipPlanDuration | string, customDays?: number): number {
  if (customDays && customDays > 0) return Number(customDays);
  switch (duration) {
    case '7d': return 7;
    case '30d': return 30;
    case '90d': return 90;
    case '365d': return 365;
    case 'permanent': return 36500; // 100 years
    default: return 30;
  }
}

// ----------------------------------------------------------------------
// 0. SEARCH USERS FOR VIP ASSIGNMENT / MANAGEMENT
// ----------------------------------------------------------------------
export const searchUsersForVip = (req: Request, res: Response) => {
  const query = (req.query.q as string || '').toLowerCase().trim();
  
  // Base mock user pool for search
  const systemUsers = [
    { id: 'USR-882941', name: 'Aarav Mehta', username: 'aarav_prime', email: 'aarav.m@gmail.com', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', role: 'VIP User' },
    { id: 'USR-8001', name: 'Aarav Mehta (Alpha)', username: 'aarav_alpha', email: 'aarav.alpha@srlive.io', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', role: 'User' },
    { id: 'USR-8002', name: 'Ananya Gupta', username: 'ananya_queen', email: 'ananya.g@yahoo.com', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', role: 'User' },
    { id: 'USR-8003', name: 'Rishi Kapoor', username: 'rishi_vip', email: 'rishi.k@outlook.com', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150', role: 'User' },
    { id: 'USR-8004', name: 'David Miller', username: 'david_miller', email: 'david.m@gmail.com', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', role: 'User' },
    { id: 'HST-901', name: 'Anya Sharma (DJ Anya)', username: 'dj_anya_live', email: 'anya.sharma@srlive.io', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', role: 'Celebrate Host' },
    { id: 'HST-902', name: 'Kavita Roy', username: 'kavita_esports', email: 'kavita.roy@srlive.io', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', role: 'Talent Host' },
    { id: 'HST-903', name: 'Devansh Kapoor', username: 'devansh_singer', email: 'devansh.k@srlive.io', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', role: 'Singer Host' },
    { id: 'HST-904', name: 'Meera Patel', username: 'meera_tech_space', email: 'meera.p@srlive.io', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', role: 'Normal Host' },
    { id: 'HST-905', name: 'Rohan Joshi', username: 'rohan_acoustic', email: 'rohan.j@srlive.io', avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150', role: 'Singer Host' },
    { id: 'MGR-301', name: 'Rahul Verma', username: 'rahul_talents', email: 'rahul.talent@srlive.io', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150', role: 'Manager' },
    { id: 'MGR-302', name: 'Jessica Chen', username: 'jessica_stream_lead', email: 'jessica.chen@srlive.io', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150', role: 'Manager' },
    { id: 'SA-1001', name: 'Salam Super Admin', username: 'salam_super_admin', email: 'salamstarhotel@gmail.com', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', role: 'Super Admin' },
    { id: 'ADM-201', name: 'Vikram Malhotra', username: 'vikram_ops', email: 'vikram.m@srlive.io', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', role: 'Admin' }
  ];

  // Also include any users who are in serverUserVipRecords but not in systemUsers
  serverUserVipRecords.forEach((vipRec, uId) => {
    if (!systemUsers.some(u => u.id === uId)) {
      systemUsers.push({
        id: uId,
        name: vipRec.userName,
        username: vipRec.userName.toLowerCase().replace(/\s+/g, '_'),
        email: `${vipRec.userId.toLowerCase()}@srlive.io`,
        avatar: vipRec.userAvatar,
        role: 'VIP Member'
      });
    }
  });

  const now = Date.now();
  const results = systemUsers
    .filter(u => {
      if (!query) return true;
      return (
        u.id.toLowerCase().includes(query) ||
        u.name.toLowerCase().includes(query) ||
        u.username.toLowerCase().includes(query) ||
        u.email.toLowerCase().includes(query) ||
        u.role.toLowerCase().includes(query)
      );
    })
    .map(u => {
      const vipRec = serverUserVipRecords.get(u.id);
      let vipStatus: 'ACTIVE' | 'EXPIRED' | 'NONE' = 'NONE';
      let vipLevel = 0;
      let expiresAt: string | null = null;
      let isPermanent = false;
      let remainingDays = 0;

      if (vipRec) {
        vipLevel = vipRec.vipLevel;
        isPermanent = Boolean(vipRec.isPermanent || vipRec.planDuration === 'permanent');
        if (isPermanent) {
          vipStatus = vipRec.status === 'INACTIVE' ? 'NONE' : 'ACTIVE';
          remainingDays = 9999;
          expiresAt = 'Permanent / Lifetime';
        } else {
          const diff = new Date(vipRec.expiresAt).getTime() - now;
          if (diff > 0 && vipRec.status === 'ACTIVE') {
            vipStatus = 'ACTIVE';
            remainingDays = Math.ceil(diff / (1000 * 60 * 60 * 24));
            expiresAt = vipRec.expiresAt;
          } else {
            vipStatus = vipRec.status === 'INACTIVE' ? 'NONE' : 'EXPIRED';
            remainingDays = 0;
            expiresAt = vipRec.expiresAt;
          }
        }
      }

      return {
        ...u,
        vipStatus,
        vipLevel,
        isPermanent,
        remainingDays,
        expiresAt,
        vipRecord: vipRec || null
      };
    });

  res.json({
    success: true,
    total: results.length,
    users: results
  });
};

// ----------------------------------------------------------------------
// 1. GET ALL VIP CONFIGURATIONS
// ----------------------------------------------------------------------
export const getVipLevels = (req: Request, res: Response) => {
  res.json({
    success: true,
    levels: serverVipLevels
  });
};

// ----------------------------------------------------------------------
// 2. UPDATE A VIP CONFIGURATION (Super Admin)
// ----------------------------------------------------------------------
export const updateVipLevel = (req: Request, res: Response) => {
  try {
    const { level, updated } = req.body;
    const targetIdx = serverVipLevels.findIndex(l => l.level === Number(level));
    
    if (targetIdx === -1) {
      return res.status(404).json({ success: false, error: `VIP Level ${level} not found.` });
    }

    serverVipLevels[targetIdx] = {
      ...serverVipLevels[targetIdx],
      ...updated,
      level: Number(level) // Enforce level integrity
    };

    res.json({
      success: true,
      message: `VIP Level ${level} updated successfully.`,
      levelConfig: serverVipLevels[targetIdx]
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to update VIP configuration' });
  }
};

// ----------------------------------------------------------------------
// 3. CREATE / ADD A NEW VIP LEVEL (Super Admin)
// ----------------------------------------------------------------------
export const createVipLevel = (req: Request, res: Response) => {
  try {
    const newLevelData: Partial<VipLevelConfig> = req.body;
    const nextLevelNum = newLevelData.level || (serverVipLevels.length > 0 ? Math.max(...serverVipLevels.map(l => l.level)) + 1 : 1);

    if (serverVipLevels.some(l => l.level === nextLevelNum)) {
      return res.status(400).json({ success: false, error: `VIP Level ${nextLevelNum} already exists.` });
    }

    const created: VipLevelConfig = {
      level: nextLevelNum,
      title: newLevelData.title || `VIP Level ${nextLevelNum}`,
      subtitle: newLevelData.subtitle || 'Custom Nobility Status',
      badgeLabel: newLevelData.badgeLabel || `VIP ${nextLevelNum}`,
      badgeIcon: newLevelData.badgeIcon || '👑',
      badgeColor: newLevelData.badgeColor || '#fbbf24',
      textColor: newLevelData.textColor || '#ffffff',
      gradient: newLevelData.gradient || 'from-amber-500 to-yellow-600',
      frameId: newLevelData.frameId || `FRM-VIP-${String(nextLevelNum).padStart(2, '0')}`,
      frameName: newLevelData.frameName || `VIP ${nextLevelNum} Custom Frame`,
      frameBorderClass: newLevelData.frameBorderClass || 'border-amber-400',
      monthlyCoinsRequired: newLevelData.monthlyCoinsRequired || 1000000 * nextLevelNum,
      pricing: newLevelData.pricing || {
        '7d': 50000 * nextLevelNum,
        '30d': 150000 * nextLevelNum,
        '90d': 400000 * nextLevelNum,
        '365d': 1300000 * nextLevelNum
      },
      entranceEffect: newLevelData.entranceEffect || {
        id: `ENT-VIP-${nextLevelNum}`,
        name: '👑 Imperial Royal Entrance',
        type: 'supercar',
        emoji: '👑',
        soundFx: 'engine_turbo',
        bannerGradient: 'from-amber-600 to-yellow-500',
        description: 'Exclusive custom VIP entrance banner'
      },
      chatStyle: newLevelData.chatStyle || {
        bubbleGradient: 'from-amber-950/80 to-neutral-950',
        bubbleBorder: 'border-amber-400',
        textColor: '#ffffff',
        nameGlow: 'text-amber-300 font-bold',
        badgeGlow: 'shadow-md'
      },
      storeDiscountPercent: newLevelData.storeDiscountPercent || Math.min(nextLevelNum * 5, 50),
      withdrawalTaxDiscountPercent: newLevelData.withdrawalTaxDiscountPercent || Math.min(nextLevelNum * 7, 80),
      coinTransferTaxDiscountPercent: newLevelData.coinTransferTaxDiscountPercent || (nextLevelNum >= 7 ? 100 : nextLevelNum * 10),
      privileges: newLevelData.privileges || [
        `VIP ${nextLevelNum} Exclusive Badge`,
        `Custom Animated Avatar Frame`,
        `Stream Entrance Broadcast`,
        `Special Chat Highlighting`
      ],
      unlockedGifts: newLevelData.unlockedGifts || ['Bronze Trophy', 'Starlight Wish'],
      totalActiveMembers: 0,
      isActive: true
    };

    serverVipLevels.push(created);
    serverVipLevels.sort((a, b) => a.level - b.level);

    res.json({
      success: true,
      message: `VIP Level ${nextLevelNum} created successfully.`,
      createdLevel: created
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to create VIP level' });
  }
};

// ----------------------------------------------------------------------
// 4. TOGGLE VIP LEVEL STATUS (Active / Inactive)
// ----------------------------------------------------------------------
export const toggleVipLevel = (req: Request, res: Response) => {
  const { level } = req.body;
  const target = serverVipLevels.find(l => l.level === Number(level));
  if (!target) {
    return res.status(404).json({ success: false, error: `VIP Level ${level} not found.` });
  }

  target.isActive = !target.isActive;
  res.json({
    success: true,
    message: `VIP Level ${level} is now ${target.isActive ? 'Active' : 'Deactivated'}.`,
    isActive: target.isActive
  });
};

// ----------------------------------------------------------------------
// 5. GET USER'S CURRENT VIP STATUS & REMAINING TIME
// ----------------------------------------------------------------------
export const getUserVipStatus = (req: Request, res: Response) => {
  const userId = req.params.userId || 'USR-882941';
  let record = serverUserVipRecords.get(userId);

  if (record) {
    const isPermanent = Boolean(record.isPermanent || record.planDuration === 'permanent');
    if (isPermanent) {
      if (record.status !== 'INACTIVE') {
        record.status = 'ACTIVE';
        record.remainingDays = 9999;
        record.remainingHours = 99999;
      }
    } else {
      const now = Date.now();
      const expiryTime = new Date(record.expiresAt).getTime();
      const diffMs = expiryTime - now;

      if (diffMs <= 0) {
        record.status = 'EXPIRED';
        record.remainingDays = 0;
        record.remainingHours = 0;
      } else {
        record.status = 'ACTIVE';
        record.remainingDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
        record.remainingHours = Math.ceil(diffMs / (1000 * 60 * 60));
      }
    }
  }

  const userConfig = record && record.status === 'ACTIVE' 
    ? serverVipLevels.find(l => l.level === record.vipLevel) || null 
    : null;

  res.json({
    success: true,
    hasActiveVip: Boolean(record && record.status === 'ACTIVE'),
    vipRecord: record || null,
    vipConfig: userConfig
  });
};

// ----------------------------------------------------------------------
// 6. REAL VIP PURCHASE (With Coin Deduction & Transaction Record)
// ----------------------------------------------------------------------
export const purchaseVip = (req: Request, res: Response) => {
  try {
    const { 
      userId = 'USR-882941', 
      userName = 'Aarav Mehta',
      userAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      targetLevel = 1, 
      duration = '30d',
      currentCoinBalance = 5200422000 
    } = req.body;

    const targetConfig = serverVipLevels.find(l => l.level === Number(targetLevel));
    if (!targetConfig) {
      return res.status(404).json({ success: false, error: `VIP Level ${targetLevel} configuration not found.` });
    }

    if (!targetConfig.isActive) {
      return res.status(400).json({ success: false, error: `VIP Level ${targetLevel} is currently not available for purchase.` });
    }

    const durationKey = (duration as '7d' | '30d' | '90d' | '365d') || '30d';
    const priceCoins = targetConfig.pricing[durationKey] || targetConfig.pricing['30d'];

    if (currentCoinBalance < priceCoins) {
      return res.status(400).json({
        success: false,
        error: `Insufficient TEST COINS! Required: ${priceCoins.toLocaleString()} TC. Your Balance: ${currentCoinBalance.toLocaleString()} TC.`
      });
    }

    const daysToAdd = getDaysFromDuration(durationKey);
    const now = new Date();
    let expiresAt = new Date(now.getTime() + daysToAdd * 24 * 60 * 60 * 1000);

    // If user already has active VIP of same level, extend it
    const existingRecord = serverUserVipRecords.get(userId);
    let isExtension = false;
    let isUpgrade = false;

    if (existingRecord && existingRecord.status === 'ACTIVE') {
      if (existingRecord.vipLevel === targetLevel && !existingRecord.isPermanent) {
        const currentExp = new Date(existingRecord.expiresAt).getTime();
        if (currentExp > now.getTime()) {
          expiresAt = new Date(currentExp + daysToAdd * 24 * 60 * 60 * 1000);
          isExtension = true;
        }
      } else {
        isUpgrade = true;
      }
    }

    const newBalance = currentCoinBalance - priceCoins;
    const remainingDays = Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    const remainingHours = Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60));

    // Update / Set VIP record
    const updatedRecord: UserVipRecord = {
      userId,
      userName,
      userAvatar,
      vipLevel: Number(targetLevel),
      status: 'ACTIVE',
      planDuration: durationKey,
      isPermanent: false,
      activatedAt: existingRecord ? existingRecord.activatedAt : now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      remainingDays,
      remainingHours,
      autoRenew: true,
      totalCoinsSpentOnVip: (existingRecord?.totalCoinsSpentOnVip || 0) + priceCoins,
      renewalCount: (existingRecord?.renewalCount || 0) + (isExtension ? 1 : 0)
    };

    serverUserVipRecords.set(userId, updatedRecord);

    // Increment tier active members count
    targetConfig.totalActiveMembers = (targetConfig.totalActiveMembers || 0) + 1;

    // Create Audit Transaction
    const txId = `VIP-TX-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const tx: VipTransaction = {
      id: txId,
      userId,
      userName,
      userAvatar,
      type: isUpgrade ? 'VIP_UPGRADE' : isExtension ? 'VIP_RENEWAL' : 'VIP_PURCHASE',
      level: Number(targetLevel),
      previousLevel: existingRecord ? existingRecord.vipLevel : undefined,
      levelTitle: targetConfig.title,
      duration: durationKey,
      durationDays: daysToAdd,
      isPermanent: false,
      costCoins: priceCoins,
      prevBalance: currentCoinBalance,
      newBalance: newBalance,
      timestamp: now.toISOString(),
      status: 'COMPLETED',
      notes: `${isUpgrade ? 'Upgraded to' : isExtension ? 'Extended' : 'Purchased'} ${daysToAdd}-Day VIP ${targetLevel} (${targetConfig.title}) for ${priceCoins.toLocaleString()} TEST COINS.`
    };

    serverVipTransactions.unshift(tx);

    res.json({
      success: true,
      message: `👑 Successfully activated VIP Level ${targetLevel} (${targetConfig.title}) for ${daysToAdd} days!`,
      newCoinBalance: newBalance,
      costCoins: priceCoins,
      vipRecord: updatedRecord,
      vipConfig: targetConfig,
      transaction: tx
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'VIP purchase processing failed' });
  }
};

// ----------------------------------------------------------------------
// 7. GET ALL VIP MEMBERS (Super Admin)
// ----------------------------------------------------------------------
export const getAllVipMembers = (req: Request, res: Response) => {
  const members: UserVipRecord[] = Array.from(serverUserVipRecords.values());
  const now = Date.now();

  // Refresh remaining days
  members.forEach(m => {
    if (m.isPermanent || m.planDuration === 'permanent') {
      if (m.status !== 'INACTIVE') {
        m.status = 'ACTIVE';
        m.remainingDays = 9999;
        m.remainingHours = 99999;
      }
    } else {
      const diff = new Date(m.expiresAt).getTime() - now;
      if (diff <= 0) {
        m.status = 'EXPIRED';
        m.remainingDays = 0;
        m.remainingHours = 0;
      } else {
        m.status = 'ACTIVE';
        m.remainingDays = Math.ceil(diff / (1000 * 60 * 60 * 24));
        m.remainingHours = Math.ceil(diff / (1000 * 60 * 60));
      }
    }
  });

  res.json({
    success: true,
    totalMembers: members.length,
    activeCount: members.filter(m => m.status === 'ACTIVE').length,
    members: members.sort((a, b) => b.vipLevel - a.vipLevel)
  });
};

// ----------------------------------------------------------------------
// 8. ADMIN MANUALLY GIVE / ASSIGN VIP TO USER (VIP 1 to VIP 10)
// ----------------------------------------------------------------------
export const adminGrantVip = (req: Request, res: Response) => {
  try {
    const { 
      userId, 
      userName, 
      userAvatar, 
      targetLevel = 1, 
      duration = '30d', 
      durationDays, 
      isPermanent = false,
      adminId = 'SA-1001', 
      adminName = 'Super Admin', 
      notes 
    } = req.body;

    if (!userId) {
      return res.status(400).json({ success: false, error: 'User ID is required' });
    }

    const lvl = Math.min(10, Math.max(1, Number(targetLevel)));
    const targetConfig = serverVipLevels.find(l => l.level === lvl) || serverVipLevels[0];
    const now = new Date();
    const existing = serverUserVipRecords.get(userId);

    const isPerm = Boolean(isPermanent || duration === 'permanent' || durationDays === 9999 || durationDays === 36500);
    let finalDays = isPerm ? 36500 : (durationDays ? Number(durationDays) : getDaysFromDuration(duration));
    let expiresAtDate = isPerm 
      ? new Date('2099-12-31T23:59:59.000Z') 
      : new Date(now.getTime() + finalDays * 24 * 60 * 60 * 1000);

    const durationLabel: VipPlanDuration = isPerm ? 'permanent' : (['7d', '30d', '90d', '365d'].includes(duration) ? duration as VipPlanDuration : 'custom');

    const record: UserVipRecord = {
      userId,
      userName: userName || existing?.userName || `User ${userId}`,
      userAvatar: userAvatar || existing?.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      vipLevel: lvl,
      status: 'ACTIVE',
      planDuration: durationLabel,
      isPermanent: isPerm,
      activatedAt: now.toISOString(),
      expiresAt: expiresAtDate.toISOString(),
      remainingDays: isPerm ? 9999 : finalDays,
      remainingHours: isPerm ? 99999 : finalDays * 24,
      autoRenew: false,
      totalCoinsSpentOnVip: existing?.totalCoinsSpentOnVip || 0,
      renewalCount: (existing?.renewalCount || 0) + (existing ? 1 : 0),
      grantedByAdmin: true,
      adminId,
      adminName,
      adminNote: notes || `Granted VIP ${lvl} by ${adminName}`,
      lastUpdated: now.toISOString()
    };

    serverUserVipRecords.set(userId, record);

    // Audit TX
    const tx: VipTransaction = {
      id: `ADMIN-VIP-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      userName: record.userName,
      userAvatar: record.userAvatar,
      type: existing ? 'VIP_UPGRADE' : 'ADMIN_GRANT',
      level: lvl,
      previousLevel: existing ? existing.vipLevel : undefined,
      levelTitle: targetConfig.title,
      duration: durationLabel,
      durationDays: isPerm ? 9999 : finalDays,
      isPermanent: isPerm,
      costCoins: 0,
      prevBalance: 0,
      newBalance: 0,
      timestamp: now.toISOString(),
      status: 'COMPLETED',
      adminId,
      adminName,
      notes: notes || `Admin ${adminName} granted ${isPerm ? 'Permanent (Lifetime)' : `${finalDays} days of`} VIP ${lvl} (${targetConfig.title}) to ${record.userName}.`
    };

    serverVipTransactions.unshift(tx);

    res.json({
      success: true,
      message: `👑 Successfully granted VIP ${lvl} (${targetConfig.title}) to ${record.userName} (${isPerm ? 'Permanent' : `${finalDays} Days`})!`,
      vipRecord: record,
      vipConfig: targetConfig,
      transaction: tx
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to grant VIP' });
  }
};

// ----------------------------------------------------------------------
// 8B. ADMIN CHANGE / MODIFY VIP (Level 1–10, Duration, Expiry Date)
// ----------------------------------------------------------------------
export const adminChangeVip = (req: Request, res: Response) => {
  try {
    const { 
      userId, 
      targetLevel, 
      duration, 
      durationDays, 
      isPermanent,
      customExpiryDate,
      adminId = 'SA-1001', 
      adminName = 'Super Admin', 
      notes 
    } = req.body;

    if (!userId) {
      return res.status(400).json({ success: false, error: 'User ID is required' });
    }

    const existing = serverUserVipRecords.get(userId);
    const now = new Date();
    const prevLvl = existing ? existing.vipLevel : 0;
    const newLvl = targetLevel !== undefined ? Math.min(10, Math.max(1, Number(targetLevel))) : (existing ? existing.vipLevel : 1);
    const targetConfig = serverVipLevels.find(l => l.level === newLvl) || serverVipLevels[0];

    const isPerm = isPermanent !== undefined ? Boolean(isPermanent) : (duration === 'permanent');
    let expiresAtDate: Date;
    let finalDays = 30;

    if (customExpiryDate) {
      expiresAtDate = new Date(customExpiryDate);
      finalDays = Math.max(1, Math.ceil((expiresAtDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
    } else if (isPerm) {
      expiresAtDate = new Date('2099-12-31T23:59:59.000Z');
      finalDays = 36500;
    } else if (durationDays) {
      finalDays = Number(durationDays);
      expiresAtDate = new Date(now.getTime() + finalDays * 24 * 60 * 60 * 1000);
    } else if (duration) {
      finalDays = getDaysFromDuration(duration);
      expiresAtDate = new Date(now.getTime() + finalDays * 24 * 60 * 60 * 1000);
    } else if (existing && existing.status === 'ACTIVE' && !existing.isPermanent) {
      expiresAtDate = new Date(existing.expiresAt);
      finalDays = Math.max(1, Math.ceil((expiresAtDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
    } else {
      finalDays = 30;
      expiresAtDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    }

    const durationLabel: VipPlanDuration = isPerm ? 'permanent' : (['7d', '30d', '90d', '365d'].includes(duration) ? duration as VipPlanDuration : 'custom');

    const updatedRecord: UserVipRecord = {
      userId,
      userName: existing?.userName || `User ${userId}`,
      userAvatar: existing?.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      vipLevel: newLvl,
      status: 'ACTIVE',
      planDuration: durationLabel,
      isPermanent: isPerm,
      activatedAt: existing?.activatedAt || now.toISOString(),
      expiresAt: expiresAtDate.toISOString(),
      remainingDays: isPerm ? 9999 : finalDays,
      remainingHours: isPerm ? 99999 : finalDays * 24,
      autoRenew: existing?.autoRenew ?? false,
      totalCoinsSpentOnVip: existing?.totalCoinsSpentOnVip || 0,
      renewalCount: (existing?.renewalCount || 0) + 1,
      grantedByAdmin: true,
      adminId,
      adminName,
      adminNote: notes || `VIP changed from Level ${prevLvl} to ${newLvl} by ${adminName}`,
      lastUpdated: now.toISOString()
    };

    serverUserVipRecords.set(userId, updatedRecord);

    // Audit TX
    const tx: VipTransaction = {
      id: `ADMIN-CHANGE-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      userName: updatedRecord.userName,
      userAvatar: updatedRecord.userAvatar,
      type: 'ADMIN_CHANGE',
      level: newLvl,
      previousLevel: prevLvl,
      levelTitle: targetConfig.title,
      duration: durationLabel,
      durationDays: isPerm ? 9999 : finalDays,
      isPermanent: isPerm,
      costCoins: 0,
      prevBalance: 0,
      newBalance: 0,
      timestamp: now.toISOString(),
      status: 'COMPLETED',
      adminId,
      adminName,
      notes: notes || `Admin ${adminName} changed VIP for ${updatedRecord.userName}: VIP ${prevLvl} ➔ VIP ${newLvl} (${isPerm ? 'Permanent' : `Expires ${expiresAtDate.toLocaleDateString()}`}).`
    };

    serverVipTransactions.unshift(tx);

    res.json({
      success: true,
      message: `👑 Successfully updated VIP to Level ${newLvl} (${targetConfig.title}) for ${updatedRecord.userName}!`,
      vipRecord: updatedRecord,
      vipConfig: targetConfig,
      transaction: tx
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to update user VIP' });
  }
};

// ----------------------------------------------------------------------
// 9. ADMIN REVOKE / REMOVE VIP
// ----------------------------------------------------------------------
export const adminRevokeVip = (req: Request, res: Response) => {
  const { userId, adminId = 'SA-1001', adminName = 'Super Admin', reason = 'Revoked by Admin' } = req.body;
  const existing = serverUserVipRecords.get(userId);

  if (!existing) {
    return res.status(404).json({ success: false, error: 'User does not have any VIP record.' });
  }

  const prevLvl = existing.vipLevel;
  existing.status = 'INACTIVE';
  existing.isPermanent = false;
  existing.remainingDays = 0;
  existing.remainingHours = 0;
  existing.expiresAt = new Date().toISOString();
  existing.adminNote = `Revoked by ${adminName}: ${reason}`;
  existing.lastUpdated = new Date().toISOString();

  // Audit TX
  const tx: VipTransaction = {
    id: `ADMIN-REVOKE-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    userId,
    userName: existing.userName,
    userAvatar: existing.userAvatar,
    type: 'ADMIN_REVOKE',
    level: prevLvl,
    previousLevel: prevLvl,
    levelTitle: `VIP ${prevLvl} (Revoked)`,
    duration: existing.planDuration,
    durationDays: 0,
    isPermanent: false,
    costCoins: 0,
    prevBalance: 0,
    newBalance: 0,
    timestamp: new Date().toISOString(),
    status: 'COMPLETED',
    adminId,
    adminName,
    notes: reason || `Admin ${adminName} removed VIP ${prevLvl} status.`
  };

  serverVipTransactions.unshift(tx);

  res.json({
    success: true,
    message: `❌ VIP status (Level ${prevLvl}) for user ${existing.userName} (${userId}) has been removed.`,
    vipRecord: existing,
    transaction: tx
  });
};

// ----------------------------------------------------------------------
// 10. GET ALL VIP TRANSACTIONS
// ----------------------------------------------------------------------
export const getVipTransactions = (req: Request, res: Response) => {
  res.json({
    success: true,
    transactions: serverVipTransactions
  });
};

// ----------------------------------------------------------------------
// 11. GET VIP SYSTEM STATS & METRICS
// ----------------------------------------------------------------------
export const getVipStats = (req: Request, res: Response) => {
  const allMembers = Array.from(serverUserVipRecords.values());
  const activeMembers = allMembers.filter(m => m.status === 'ACTIVE');
  
  const totalRevenue = serverVipTransactions.reduce((acc, tx) => acc + (tx.costCoins || 0), 0);

  const vipMembersByLevel: { [level: number]: number } = {};
  for (let i = 1; i <= 10; i++) {
    vipMembersByLevel[i] = activeMembers.filter(m => m.vipLevel === i).length;
  }

  const stats: VipSystemStats = {
    totalActiveVipMembers: activeMembers.length,
    totalVipRevenueCoins: totalRevenue,
    vipMembersByLevel,
    recentTransactions: serverVipTransactions.slice(0, 10),
    topSpenders: allMembers
      .sort((a, b) => b.totalCoinsSpentOnVip - a.totalCoinsSpentOnVip)
      .slice(0, 5)
      .map(m => ({
        userId: m.userId,
        userName: m.userName,
        avatar: m.userAvatar,
        vipLevel: m.vipLevel,
        totalSpent: m.totalCoinsSpentOnVip
      }))
  };

  res.json({
    success: true,
    stats
  });
};
