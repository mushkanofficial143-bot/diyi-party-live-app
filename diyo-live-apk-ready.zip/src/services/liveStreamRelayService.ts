/**
 * DIYO LIVE - Real-Time Live Video Stream Relay Service
 * Handles instant cross-tab video streaming via BroadcastChannel and
 * cross-client network frame synchronization via the backend API.
 */

export interface LiveStreamFramePayload {
  roomId: string;
  hostId: string;
  hostName: string;
  isCameraOn: boolean;
  frameData?: string; // base64 JPEG thumbnail / video snapshot
  filter?: string;
  audioLevel?: number;
  timestamp: number;
  coHostId?: string;
  coHostName?: string;
  coHostFrameData?: string;
  isCoHostCameraOn?: boolean;
}

export class LiveStreamRelayService {
  private static instance: LiveStreamRelayService | null = null;
  private channel: BroadcastChannel | null = null;
  private listeners: Map<string, Set<(data: LiveStreamFramePayload) => void>> = new Map();
  private isBroadcasting: boolean = false;
  private broadcastInterval: any = null;
  private currentRoomId: string | null = null;
  private isCoHostBroadcasting: boolean = false;
  private coHostInterval: any = null;
  private lastKnownPayloads: Map<string, LiveStreamFramePayload> = new Map();

  private constructor() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.channel = new BroadcastChannel('diyo_live_video_stream');
        this.channel.onmessage = (event) => {
          if (event && event.data && event.data.roomId) {
            this.notifyListeners(event.data.roomId, event.data);
          }
        };
      } catch (e) {
        console.warn('[LiveRelay] BroadcastChannel not supported in this environment', e);
      }
    }
  }

  public static getInstance(): LiveStreamRelayService {
    if (!LiveStreamRelayService.instance) {
      LiveStreamRelayService.instance = new LiveStreamRelayService();
    }
    return LiveStreamRelayService.instance;
  }

  /**
   * Start broadcasting frames from a video element or canvas (Broadcaster / Host)
   */
  public startBroadcasting(
    roomId: string,
    hostId: string,
    hostName: string,
    getVideoElement: () => HTMLVideoElement | HTMLCanvasElement | null,
    getAudioLevel?: () => number,
    filter: string = 'normal'
  ) {
    this.currentRoomId = roomId;
    this.isBroadcasting = true;

    if (this.broadcastInterval) {
      clearInterval(this.broadcastInterval);
    }

    const captureCanvas = document.createElement('canvas');
    captureCanvas.width = 360;
    captureCanvas.height = 640;
    const ctx = captureCanvas.getContext('2d');

    let postCounter = 0;

    this.broadcastInterval = setInterval(() => {
      if (!this.isBroadcasting || !this.currentRoomId) return;

      const sourceEl = getVideoElement();
      let frameData: string | undefined;

      if (sourceEl && ctx) {
        try {
          if (sourceEl instanceof HTMLVideoElement) {
            if (sourceEl.readyState >= 2 && sourceEl.videoWidth > 0) {
              ctx.drawImage(sourceEl, 0, 0, captureCanvas.width, captureCanvas.height);
              frameData = captureCanvas.toDataURL('image/jpeg', 0.6);
            }
          } else if (sourceEl instanceof HTMLCanvasElement) {
            ctx.drawImage(sourceEl, 0, 0, captureCanvas.width, captureCanvas.height);
            frameData = captureCanvas.toDataURL('image/jpeg', 0.6);
          }
        } catch (err) {
          // If canvas was tainted by cross-origin image, generate an untainted dynamic snapshot
          try {
            const cleanCanvas = document.createElement('canvas');
            cleanCanvas.width = 360;
            cleanCanvas.height = 640;
            const cleanCtx = cleanCanvas.getContext('2d');
            if (cleanCtx) {
              const grad = cleanCtx.createLinearGradient(0, 0, 0, 640);
              grad.addColorStop(0, '#1e1b4b');
              grad.addColorStop(0.5, '#0f172a');
              grad.addColorStop(1, '#020617');
              cleanCtx.fillStyle = grad;
              cleanCtx.fillRect(0, 0, 360, 640);

              // Center neon circle
              cleanCtx.beginPath();
              cleanCtx.arc(180, 260, 70, 0, Math.PI * 2);
              cleanCtx.fillStyle = '#6366f1';
              cleanCtx.fill();
              cleanCtx.strokeStyle = '#a855f7';
              cleanCtx.lineWidth = 4;
              cleanCtx.stroke();

              // Text initials
              cleanCtx.fillStyle = '#ffffff';
              cleanCtx.font = 'bold 36px sans-serif';
              cleanCtx.textAlign = 'center';
              cleanCtx.textBaseline = 'middle';
              cleanCtx.fillText(hostName ? hostName.charAt(0).toUpperCase() : 'L', 180, 260);

              cleanCtx.font = 'bold 18px sans-serif';
              cleanCtx.fillText(hostName || 'Live Host', 180, 360);

              cleanCtx.fillStyle = '#38bdf8';
              cleanCtx.font = '12px sans-serif';
              cleanCtx.fillText('HD 1080p Live Broadcast', 180, 385);

              frameData = cleanCanvas.toDataURL('image/jpeg', 0.6);
            }
          } catch (e2) {}
        }
      }

      const existing = this.lastKnownPayloads.get(roomId) || {} as Partial<LiveStreamFramePayload>;
      const payload: LiveStreamFramePayload = {
        roomId,
        hostId,
        hostName,
        isCameraOn: Boolean(frameData),
        frameData: frameData || existing.frameData,
        filter,
        audioLevel: getAudioLevel ? getAudioLevel() : 35,
        timestamp: Date.now(),
        coHostId: existing.coHostId,
        coHostName: existing.coHostName,
        coHostFrameData: existing.coHostFrameData,
        isCoHostCameraOn: existing.isCoHostCameraOn
      };

      this.lastKnownPayloads.set(roomId, payload);

      // 1. BroadcastChannel (immediate cross-tab)
      if (this.channel) {
        try {
          this.channel.postMessage(payload);
        } catch {}
      }

      // Also notify local in-memory listeners
      this.notifyListeners(roomId, payload);

      // 2. Network Relay (send to server every ~1.5 seconds)
      postCounter++;
      if (postCounter % 3 === 0) {
        fetch('/api/live-stream/frame', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }).catch(() => {});
      }
    }, 500);
  }

  /**
   * Start broadcasting frames as a Co-Host / Dual-Video participant
   */
  public startCoHostBroadcasting(
    roomId: string,
    coHostId: string,
    coHostName: string,
    getCoHostVideoElement: () => HTMLVideoElement | HTMLCanvasElement | null
  ) {
    this.isCoHostBroadcasting = true;

    if (this.coHostInterval) {
      clearInterval(this.coHostInterval);
    }

    const coHostCanvas = document.createElement('canvas');
    coHostCanvas.width = 240;
    coHostCanvas.height = 320;
    const ctx = coHostCanvas.getContext('2d');

    let counter = 0;

    this.coHostInterval = setInterval(() => {
      if (!this.isCoHostBroadcasting) return;

      const sourceEl = getCoHostVideoElement();
      let coHostFrameData: string | undefined;

      if (sourceEl && ctx) {
        try {
          if (sourceEl instanceof HTMLVideoElement) {
            if (sourceEl.readyState >= 2 && sourceEl.videoWidth > 0) {
              ctx.drawImage(sourceEl, 0, 0, coHostCanvas.width, coHostCanvas.height);
              coHostFrameData = coHostCanvas.toDataURL('image/jpeg', 0.55);
            }
          } else if (sourceEl instanceof HTMLCanvasElement) {
            ctx.drawImage(sourceEl, 0, 0, coHostCanvas.width, coHostCanvas.height);
            coHostFrameData = coHostCanvas.toDataURL('image/jpeg', 0.55);
          }
        } catch (err) {}
      }

      const existing = this.lastKnownPayloads.get(roomId) || {} as Partial<LiveStreamFramePayload>;
      const updatedPayload: LiveStreamFramePayload = {
        roomId,
        hostId: existing.hostId || '',
        hostName: existing.hostName || '',
        isCameraOn: existing.isCameraOn ?? true,
        frameData: existing.frameData,
        filter: existing.filter || 'normal',
        audioLevel: existing.audioLevel || 30,
        timestamp: Date.now(),
        coHostId,
        coHostName,
        coHostFrameData: coHostFrameData || existing.coHostFrameData,
        isCoHostCameraOn: Boolean(coHostFrameData)
      };

      this.lastKnownPayloads.set(roomId, updatedPayload);

      if (this.channel) {
        try {
          this.channel.postMessage(updatedPayload);
        } catch {}
      }
      this.notifyListeners(roomId, updatedPayload);

      counter++;
      if (counter % 3 === 0) {
        fetch('/api/live-stream/cohost-frame', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            roomId,
            coHostId,
            coHostName,
            coHostFrameData,
            isCoHostCameraOn: Boolean(coHostFrameData)
          })
        }).catch(() => {});
      }
    }, 500);
  }

  /**
   * Stop co-host broadcasting
   */
  public stopCoHostBroadcasting(roomId?: string) {
    this.isCoHostBroadcasting = false;
    if (this.coHostInterval) {
      clearInterval(this.coHostInterval);
      this.coHostInterval = null;
    }
    if (roomId && this.lastKnownPayloads.has(roomId)) {
      const existing = this.lastKnownPayloads.get(roomId)!;
      existing.coHostId = undefined;
      existing.coHostName = undefined;
      existing.coHostFrameData = undefined;
      existing.isCoHostCameraOn = false;
      this.notifyListeners(roomId, existing);
      if (this.channel) {
        try {
          this.channel.postMessage(existing);
        } catch {}
      }
    }
  }

  /**
   * Stop broadcasting
   */
  public stopBroadcasting() {
    this.isBroadcasting = false;
    if (this.broadcastInterval) {
      clearInterval(this.broadcastInterval);
      this.broadcastInterval = null;
    }
    this.currentRoomId = null;
  }

  /**
   * Subscribe to live video stream frames for a specific room
   */
  public subscribeToRoom(roomId: string, callback: (data: LiveStreamFramePayload) => void): () => void {
    if (!this.listeners.has(roomId)) {
      this.listeners.set(roomId, new Set());
    }
    this.listeners.get(roomId)!.add(callback);

    // Also fetch initial frame from server
    fetch(`/api/live-stream/frame/${encodeURIComponent(roomId)}`)
      .then(res => res.json())
      .then(data => {
        if (data && data.success && data.frame) {
          callback(data.frame);
        }
      })
      .catch(() => {});

    // Polling fallback every 1.5 seconds for cross-network clients
    const pollInterval = setInterval(() => {
      fetch(`/api/live-stream/frame/${encodeURIComponent(roomId)}`)
        .then(res => res.json())
        .then(data => {
          if (data && data.success && data.frame && data.active) {
            callback(data.frame);
          }
        })
        .catch(() => {});
    }, 1500);

    return () => {
      clearInterval(pollInterval);
      const set = this.listeners.get(roomId);
      if (set) {
        set.delete(callback);
        if (set.size === 0) {
          this.listeners.delete(roomId);
        }
      }
    };
  }

  private notifyListeners(roomId: string, data: LiveStreamFramePayload) {
    const set = this.listeners.get(roomId);
    if (set) {
      set.forEach(cb => {
        try {
          cb(data);
        } catch (e) {
          console.error('[LiveRelay] Error in listener callback:', e);
        }
      });
    }
  }
}

export const liveStreamRelay = LiveStreamRelayService.getInstance();
