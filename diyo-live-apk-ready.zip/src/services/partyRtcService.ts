/**
 * DIYO LIVE - Party Room Real-Time Two-Way Voice Audio Service
 * Manages WebRTC PeerConnections, STUN/TURN servers, local microphone capture,
 * track publishing, remote track subscription, speaker playback, autoplay unlocking,
 * and comprehensive structured debug logging via audioDebug.
 */

import { audioDebug } from './audioDebugService';

export interface PartyRtcParticipant {
  userId: string;
  userName: string;
  stream?: MediaStream;
  isMuted: boolean;
}

export class PartyRtcService {
  private static instance: PartyRtcService | null = null;
  private localStream: MediaStream | null = null;
  private peerConnections = new Map<string, RTCPeerConnection>();
  private remoteStreams = new Map<string, MediaStream>();
  private audioElements = new Map<string, HTMLAudioElement>();
  private roomId = '';
  private userId = '';
  private userName = '';
  private isConnected = false;
  private isMuted = false;
  private pollInterval: ReturnType<typeof setInterval> | null = null;
  private peerPollInterval: ReturnType<typeof setInterval> | null = null;
  private seenPeers = new Set<string>();

  private constructor() {}

  public static getInstance(): PartyRtcService {
    if (!PartyRtcService.instance) PartyRtcService.instance = new PartyRtcService();
    return PartyRtcService.instance;
  }

  private rtcConfig(): RTCConfiguration {
    return {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ],
      iceCandidatePoolSize: 8
    };
  }

  public async joinRoom(roomId: string, userId: string, userName: string): Promise<{ success: boolean; error?: string }> {
    this.leaveRoom();
    this.roomId = roomId;
    this.userId = userId;
    this.userName = userName;
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('Microphone is not supported in this device/browser.');
      this.localStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, sampleRate: 48000 },
        video: false
      });
      const track = this.localStream.getAudioTracks()[0];
      if (!track) throw new Error('Microphone audio track was not created.');
      track.enabled = true;
      this.isMuted = false;
      this.unlockAutoplay();
      this.isConnected = true;
      audioDebug.log('PERMISSION', `Microphone granted for ${userId}`);

      const joinRes = await fetch('/api/party-live/rtc/join', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, userId, userName })
      }).then(r => r.json());
      if (!joinRes?.success) throw new Error(joinRes?.error || 'RTC room join failed');

      for (const peer of (joinRes.peers || [])) {
        if (String(this.userId) < String(peer.userId)) await this.createOfferForPeer(peer.userId, peer.userName);
      }
      this.pollSignals();
      this.peerPollInterval = setInterval(() => this.refreshPeers(), 2000);
      this.pollInterval = setInterval(() => this.pollSignals(), 350);
      return { success: true };
    } catch (err: any) {
      audioDebug.log('ERROR', err?.message || String(err));
      this.leaveRoom();
      return { success: false, error: err?.message || 'Microphone access denied' };
    }
  }

  private unlockAutoplay() {
    try {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      if (Ctx) {
        const ctx = new Ctx();
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      }
    } catch {}
  }

  private async refreshPeers() {
    if (!this.isConnected || !this.roomId) return;
    try {
      const data = await fetch(`/api/party-live/rtc/peers?roomId=${encodeURIComponent(this.roomId)}&userId=${encodeURIComponent(this.userId)}`).then(r => r.json()).catch(() => null);
      // GET is not required by the server; fall back to signal-driven discovery.
      if (data?.peers) for (const peer of data.peers) { if (String(this.userId) < String(peer.userId)) await this.ensurePeer(peer.userId, peer.userName); }
    } catch {}
  }

  private async ensurePeer(peerId: string, peerName = 'Party User') {
    if (!peerId || peerId === this.userId) return;
    if (this.peerConnections.has(peerId)) return;
    this.seenPeers.add(peerId);
    await this.createOfferForPeer(peerId, peerName);
  }

  private async createOfferForPeer(peerId: string, peerName = 'Party User') {
    if (this.peerConnections.has(peerId) || !this.localStream) return;
    const pc = new RTCPeerConnection(this.rtcConfig());
    this.peerConnections.set(peerId, pc);
    this.localStream.getTracks().forEach(track => pc.addTrack(track, this.localStream!));
    pc.onicecandidate = (event) => {
      if (event.candidate) this.sendSignal(peerId, 'ice', event.candidate).catch(() => {});
    };
    pc.ontrack = (event) => {
      const stream = event.streams[0] || new MediaStream([event.track]);
      this.attachRemoteStream(peerId, peerName, stream);
    };
    pc.onconnectionstatechange = () => {
      if (['failed', 'closed', 'disconnected'].includes(pc.connectionState)) {
        if (pc.connectionState === 'failed') pc.restartIce?.();
      }
    };
    const offer = await pc.createOffer({ offerToReceiveAudio: true });
    await pc.setLocalDescription(offer);
    await this.sendSignal(peerId, 'offer', pc.localDescription);
  }

  private async sendSignal(to: string, type: string, payload: any) {
    await fetch('/api/party-live/rtc/signal', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ roomId: this.roomId, from: this.userId, to, type, payload })
    });
  }

  private async pollSignals() {
    if (!this.roomId || !this.userId || !this.isConnected) return;
    try {
      const data = await fetch(`/api/party-live/rtc/signals?roomId=${encodeURIComponent(this.roomId)}&userId=${encodeURIComponent(this.userId)}`).then(r => r.json());
      for (const signal of (data?.signals || [])) await this.handleSignal(signal);
    } catch {}
  }

  private async handleSignal(signal: { from: string; type: string; payload: any }) {
    const peerId = signal.from;
    let pc = this.peerConnections.get(peerId);
    if (signal.type === 'offer') {
      if (!pc) {
        pc = new RTCPeerConnection(this.rtcConfig());
        this.peerConnections.set(peerId, pc);
        this.localStream?.getTracks().forEach(track => pc!.addTrack(track, this.localStream!));
        pc.onicecandidate = e => { if (e.candidate) this.sendSignal(peerId, 'ice', e.candidate).catch(() => {}); };
        pc.ontrack = e => this.attachRemoteStream(peerId, 'Party User', e.streams[0] || new MediaStream([e.track]));
      }
      await pc.setRemoteDescription(new RTCSessionDescription(signal.payload));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await this.sendSignal(peerId, 'answer', pc.localDescription);
    } else if (signal.type === 'answer' && pc) {
      await pc.setRemoteDescription(new RTCSessionDescription(signal.payload));
    } else if (signal.type === 'ice' && pc) {
      try { await pc.addIceCandidate(new RTCIceCandidate(signal.payload)); } catch {}
    }
  }

  public toggleMute(muted?: boolean): boolean {
    this.isMuted = muted !== undefined ? muted : !this.isMuted;
    this.localStream?.getAudioTracks().forEach(track => { track.enabled = !this.isMuted; });
    audioDebug.log('LOCAL_TRACK', this.isMuted ? 'Microphone MUTED' : 'Microphone UNMUTED');
    return this.isMuted;
  }

  public attachRemoteStream(participantId: string, participantName: string, stream: MediaStream) {
    this.remoteStreams.set(participantId, stream);
    let audioEl = this.audioElements.get(participantId);
    if (!audioEl) {
      audioEl = document.createElement('audio');
      audioEl.id = `remote-audio-${participantId}`;
      audioEl.autoplay = true;
      audioEl.playsInline = true;
      audioEl.controls = false;
      audioEl.setAttribute('aria-label', `${participantName} audio`);
      document.body.appendChild(audioEl);
      this.audioElements.set(participantId, audioEl);
    }
    audioEl.srcObject = stream;
    audioEl.muted = false;
    audioEl.volume = 1;
    audioEl.play().catch(() => {
      const resume = () => { audioEl?.play().catch(() => {}); window.removeEventListener('touchstart', resume); window.removeEventListener('click', resume); };
      window.addEventListener('touchstart', resume, { once: true });
      window.addEventListener('click', resume, { once: true });
    });
    audioDebug.log('PLAYBACK', `Remote audio connected for ${participantName}`);
  }

  public leaveRoom() {
    if (this.pollInterval) clearInterval(this.pollInterval);
    if (this.peerPollInterval) clearInterval(this.peerPollInterval);
    this.pollInterval = null;
    this.peerPollInterval = null;
    if (this.roomId && this.userId) fetch('/api/party-live/rtc/leave', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ roomId:this.roomId, userId:this.userId }) }).catch(() => {});
    this.localStream?.getTracks().forEach(track => track.stop());
    this.localStream = null;
    this.peerConnections.forEach(pc => pc.close());
    this.peerConnections.clear();
    this.audioElements.forEach(el => { el.srcObject = null; el.remove(); });
    this.audioElements.clear();
    this.remoteStreams.clear();
    this.seenPeers.clear();
    this.isConnected = false;
  }

  public isUserConnected() { return this.isConnected; }
  public isUserMuted() { return this.isMuted; }
}
