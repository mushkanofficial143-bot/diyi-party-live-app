export type UserRole = 
  | 'OWNER'
  | 'OFFICIAL'
  | 'MANAGER'
  | 'SUPER_ADMIN'
  | 'ADMIN'
  | 'ADMIN_BD'
  | 'AGENCY'
  | 'HOST'
  | 'COIN_SELLER'
  | 'USER';

export type AccountStatus = 'Active' | 'Inactive' | 'Suspended' | 'Banned' | 'Pending' | 'Deactivated';

export interface OfficialAccount {
  id: string; // e.g. OFF-001
  name: string;
  username: string;
  email: string;
  phone: string;
  status: 'Active' | 'Inactive' | 'Suspended';
  createdDate: string;
  lastLogin: string;
  assignedPermissions: string[];
  assignedArea: string;
  activityLogsCount: number;
  avatar: string;
}

export interface SuperAdminAccount {
  id: string; // e.g. SA-1001
  name: string;
  username: string;
  email: string;
  phone: string;
  status: 'Active' | 'Inactive' | 'Suspended';
  createdDate: string;
  lastLogin: string;
  assignedPermissions: string[];
  assignedArea: string;
  activityLogsCount: number;
  avatar: string;
}

export interface AdminAccount {
  id: string; // e.g. ADM-201
  name: string;
  username: string;
  contact: string;
  status: 'Active' | 'Inactive' | 'Suspended';
  permissions: string[];
  lastLogin: string;
  createdDate: string;
  activityCount: number;
  avatar: string;
}

export interface ManagerAccount {
  id: string; // e.g. MGR-301
  name: string;
  username: string;
  contact: string;
  status: 'Active' | 'Inactive' | 'Suspended';
  assignedAgencies: string[];
  assignedAgencyNames: string[];
  assignedHosts: string[];
  hostCount: number;
  totalEarningsDiamonds: number;
  performanceRating: number;
  permissions?: string[];
  lastLogin?: string;
  avatar: string;
}

export interface AgencyAccount {
  id: string; // e.g. AG-01
  name: string;
  code: string;
  ownerOrManager: string;
  managerId: string;
  status: 'Active' | 'Suspended' | 'Deactivated';
  numberOfHosts: number;
  activeHosts: number;
  totalGiftsReceived: number;
  hostPerformanceScore: number; // e.g. 98.5%
  totalEarningsDiamonds: number;
  commissionRate: number; // e.g. 15%
  createdDate: string;
  logo: string;
  contactEmail: string;
}

export interface HostLiveHistoryItem {
  id: string;
  title: string;
  date: string;
  durationMinutes: number;
  peakViewers: number;
  diamondsEarned: number;
  category: string;
}

export interface HostGiftHistoryItem {
  id: string;
  giftName: string;
  senderName: string;
  coinsValue: number;
  diamondsReceived: number;
  time: string;
}

export type HostTagType = 'CELEBRATE' | 'TALENT' | 'SINGER' | 'NORMAL';

export interface HostTypeDefinition {
  id: string; // 'HT-CELEBRATE', 'HT-TALENT', 'HT-SINGER', 'HT-NORMAL'
  tag: HostTagType;
  name: string; // 'Celebrate Host', 'Talent Host', 'Singer Host', 'Normal Host'
  tagLabel: string; // '🎉 CELEBRATE HOST', '🎭 TALENT HOST', '🎤 SINGER HOST', '⭐ NORMAL HOST'
  badgeIcon: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  gradient: string;
  description: string;
  frameId: string;
  frameName: string;
  frameBorderClass: string;
  liveRoomFrameClass: string;
  entryEffect: string;
  status: 'Active' | 'Disabled';
  commissionRateDefault: number; // percentage, e.g. 70
  isEnabled: boolean;
}

export interface HostEarningsLedgerEntry {
  id: string;
  transactionId: string;
  senderId: string;
  senderName: string;
  receiverHostId: string;
  receiverHostName?: string;
  giftId?: string;
  giftName: string;
  giftIcon?: string;
  giftPrice: number;
  multiplier?: number;
  senderPrevBalance: number;
  senderNewBalance: number;
  hostEarningAmount: number;
  hostPrevEarnings: number;
  hostNewEarnings: number;
  sourceType: 'GIFT' | 'LUCKY_GIFT' | 'RED_PACKET';
  timestamp: string;
  liveRoomId?: string;
  status: 'COMPLETED';
  TEST_MODE: true;
}

export interface HostEarningsWallet {
  totalEarnedCoins: number;
  availableEarnings: number;
  pendingEarnings: number;
  giftEarnings: number;
  luckyGiftEarnings: number;
  redPacketEarnings: number;
  commissionRate: number; // percentage e.g. 70
  history: HostEarningsLedgerEntry[];
}

export interface HostAccount {
  id: string; // e.g. HST-901
  name: string;
  username: string;
  agencyId: string;
  agencyName: string;
  managerId: string;
  managerName: string;
  status: 'Active' | 'Pending' | 'Suspended' | 'Banned';
  onlineStatus?: 'Online' | 'Offline';
  isOnline?: boolean;
  liveStatus: 'Live' | 'Off-Air' | string;
  followers: number;
  giftsReceived?: number;
  giftsReceivedCount?: number;
  diamonds: number;
  earningsUSD: number;
  totalLiveHours: number;
  lastLive: string;
  verificationStatus: 'Verified' | 'Pending' | 'Rejected' | 'Verified Creator';
  streamCategory: string;
  avatar: string;
  countryCode?: string;
  countryFlag?: string;
  countryName?: string;
  boltBalance?: number;
  liveRoomId?: string;
  bio?: string;
  liveHistory?: HostLiveHistoryItem[];
  giftHistory?: HostGiftHistoryItem[];
  // Host Type, Frame & Earnings Wallet
  hostTag?: HostTagType;
  hostTypeId?: string;
  avatarFrameId?: string;
  avatarFrameUrl?: string;
  hostLevel?: number; // 1-10
  xp?: number;
  earningsWallet?: HostEarningsWallet;
}

export interface UserAccount {
  id: string; // e.g. 0000001
  name: string;
  username: string;
  email: string;
  phone?: string;
  vipLevel: number;
  coinBalance: number;
  diamondBalance: number;
  boltBalance?: number;
  userLevel?: number;
  countryCode?: string;
  countryFlag?: string;
  countryName?: string;
  followersCount?: number;
  followingCount?: number;
  bio?: string;
  gender?: 'Male' | 'Female' | 'Other';
  dob?: string;
  status: 'Active' | 'Muted' | 'Banned' | 'ACTIVE';
  joinedDate: string;
  lastActive: string;
  totalSpentCoins: number;
  avatar: string;
  role?: UserRole | string;
  roleTag?: string;
  hostTag?: HostTagType;
  profileTag?: string;
  avatarFrameId?: string;
  avatarFrameUrl?: string;
  svipLevel?: number;
  totalRechargedUSD?: number;
  deviceType?: string;
  registrationDate?: string;
  lastLogin?: string;
  linkedProviders?: Record<string, string>;
  linkedEmails?: string[];
  linkedPhones?: string[];
  boundDeviceIds?: string[];
  boundFingerprints?: string[];
}

export interface LiveRoomSession {
  id: string;
  title: string;
  hostId: string;
  hostName: string;
  hostAvatar?: string;
  category: string;
  viewersCount: number;
  diamondsEarned: number;
  startedAt: string;
  resolution: string;
  bitrate: string;
  status: 'Active' | 'Warning' | 'Terminated' | string;
  thumbnailUrl?: string;
}

export type LiveRoomAccount = LiveRoomSession;

export type GiftCategory = 'ALL' | 'FLAGS' | 'POPULAR' | 'VIP' | 'SPECIAL' | 'LUCKY' | 'RED PACKET' | 'Standard' | 'Luxury' | 'Deluxe' | string;

export interface GiftItem {
  id: string;
  name: string;
  icon: string;
  coinPrice: number;
  diamondValue: number;
  isLucky: boolean;
  luckyMultiplierMax?: number;
  animationType: 'pop' | 'fullscreen' | 'rain' | 'dragon' | 'confetti' | 'fireworks' | 'sparkle' | string;
  category: GiftCategory;
  totalSent?: number;
  totalSentCount?: number;
  isActive?: boolean;
  isRedPacket?: boolean;
  isLuckyBox?: boolean;
}

export type LuckyBoxMultiplier = '10X' | '20X' | '30X' | '50X' | '100X';

export interface LuckyBoxConfig {
  enabled: boolean;
  basePriceCoins: number;
  multipliers: {
    '10X': boolean;
    '20X': boolean;
    '30X': boolean;
    '50X': boolean;
    '100X': boolean;
  };
  rtpRate: number; // e.g. 96%
}

export interface LuckyBoxItem {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  multiplier: LuckyBoxMultiplier;
  multiplierNumber: number;
  costCoins: number;
  potentialMaxRewardCoins: number;
  opened: boolean;
  wonRewardCoins?: number;
  createdAt: string;
  openedAt?: string;
  TEST_MODE: boolean;
}

export interface RedPacketClaim {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  amountCoins: number;
  claimedAt: string;
}

export interface RedPacketItem {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  totalCoins: number;
  totalPackets: number;
  remainingCoins: number;
  remainingPackets: number;
  message: string;
  createdAt: string;
  expiresAt: string;
  isExpired: boolean;
  claims: RedPacketClaim[];
  status: 'ACTIVE' | 'EXPIRED' | 'COMPLETED';
  TEST_MODE: boolean;
}

export interface RedPacketSettings {
  enabled: boolean;
  minAmountCoins: number;
  maxAmountCoins: number;
  minReceivers: number;
  maxReceivers: number;
  defaultExpiryMinutes: number;
}

export interface LevelConfigItem {
  level: number;
  requiredXp: number;
  cumulativeXp: number;
  title: string;
  badgeColor: string;
  badgeIcon: string;
  borderStyle: string;
  perk: string;
  unlockedGiftsCount?: number;
}

export interface LevelSettings {
  maxLevel: number;
  baseXpMultiplier: number;
  growthRate: number;
  xpPerCoinSpent: number; // e.g. 1 XP per 10 TEST COINS
  levels: LevelConfigItem[];
}

export interface GameBetSettings {
  minBet: number;
  maxBet: number;
  allowedBetButtons: number[]; // default [10000, 50000, 100000] (10K, 50K, 100K)
  enforceButtonsOnly: boolean;
}

export interface PlatformWalletSettings {
  userTransferEnabled: boolean;
  virtualExchangeEnabled: boolean;
  withdrawalsEnabled?: boolean;
  minTransferAmount: number;
  maxTransferAmount: number;
  coinToDiamondRate: number; // e.g. 1.0 (1 TEST COIN = 1 Virtual Diamond)
  testModeNotice: string;
}

export interface WalletTransaction {
  id: string;
  type: 
    | 'Deposit' 
    | 'Gift_Send' 
    | 'Diamond_Convert' 
    | 'Payout' 
    | 'Admin_Adjustment' 
    | 'Test_Transaction' 
    | 'MANUAL_ADJUSTMENT' 
    | 'TEST_TRANSACTION' 
    | 'USER_TRANSFER'
    | 'USER_TRANSFER_SENT'
    | 'USER_TRANSFER_RECEIVED'
    | 'VIRTUAL_EXCHANGE'
    | 'FAUCET_RECHARGE'
    | string;
  userId?: string;
  userName?: string;
  senderId?: string;
  senderName?: string;
  receiverId?: string;
  receiverName?: string;
  recipientId?: string;
  recipientName?: string;
  role?: UserRole;
  amountCoins: number;
  amountDiamonds: number;
  exchangeRate?: number;
  fiatAmountUSD?: number;
  paymentMethod?: string;
  paymentChannel?: string;
  txHash?: string;
  previousBalance?: number;
  newBalance?: number;
  previousSenderBalance?: number;
  newSenderBalance?: number;
  previousReceiverBalance?: number;
  newReceiverBalance?: number;
  previousCoinBalance?: number;
  newCoinBalance?: number;
  previousDiamondBalance?: number;
  newDiamondBalance?: number;
  status: 'Completed' | 'Pending' | 'Failed' | 'Refunded' | string;
  timestamp: string;
  notes?: string;
  TEST_MODE?: boolean;
}

export interface VipTierConfig {
  level: number; // 1 - 8
  title: string;
  minCoinsSpent: number;
  badgeColor: string;
  textColor: string;
  perks: string[];
  totalMembers: number;
  monthlyCoinsRequired?: number;
  storeDiscountPercent?: number;
  withdrawalTaxDiscountPercent?: number;
  coinTransferTaxDiscountPercent?: number;
}

export interface GameItem {
  id: string;
  name: string;
  category: 'Cards' | 'Roulette' | 'Slots' | 'Crash' | 'Dice' | 'Arcade' | 'Casual' | string;
  status?: 'Active' | 'Maintenance' | 'Disabled';
  isActive?: boolean;
  rtpRate: number; // e.g. 96.5%
  minBet?: number; // e.g. 50
  maxBet?: number; // e.g. 50000
  totalPlayedSessions?: number;
  totalPlaysCount?: number;
  poolCoins?: number;
  prizePoolCoins?: number;
  revenueCoins?: number;
  revenueUSD?: number;
  totalWageredCoins?: number;
  totalPayoutCoins?: number;
  currentJackpotCoins?: number;
  description?: string;
  icon?: string;
  banner?: string;
  maxMultiplier?: string;
  isHot?: boolean;
  isNew?: boolean;
}

export type GameModule = GameItem;

export interface CasinoTestTransaction {
  id: string;
  userId: string;
  userName: string;
  gameId: string;
  gameName: string;
  category: string;
  bet?: number;
  betCoins: number;
  result?: string;
  reward?: number;
  multiplier: number;
  payoutCoins: number;
  outcome: 'WIN' | 'LOSS';
  previousBalance?: number;
  newBalance?: number;
  timestamp: string;
  rtpSetting: number;
  isTestMode: boolean;
  TEST_MODE?: boolean;
}

export interface WithdrawalRequest {
  id: string;
  requesterId: string;
  requesterName: string;
  requesterRole?: 'HOST' | 'AGENCY' | string;
  diamondsAmount: number;
  cashPayoutUSD?: number;
  payoutAmountUSD?: number;
  paymentMethod: 'Bank_Transfer' | 'USDT_TRC20' | 'UPI' | 'PayPal' | string;
  accountDetails: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Paid';
  requestDate?: string;
  timestamp?: string;
  processedBy?: string;
  transactionHash?: string;
}

export type PayoutMethod = 'UPI' | 'eSewa' | 'bKash' | 'JazzCash' | 'GCash' | 'USDT_TRC20' | 'Bank_Transfer' | 'PayPal' | string;

export interface WithdrawalItem {
  id: string;
  userId?: string;
  userName?: string;
  requesterId?: string;
  requesterName?: string;
  amountDiamonds: number;
  payoutAmountUSD: number;
  currency: string;
  targetCurrency?: string;
  method?: PayoutMethod;
  payoutMethod: PayoutMethod;
  recipientDetails: string;
  accountDetails?: string;
  status: 'Pending' | 'Approved' | 'Completed' | 'Processing' | 'Rejected' | 'Dispatched (Instant)' | string;
  requestedAt?: string;
  processedAt?: string;
  timestamp: string;
  txHash?: string;
  transactionRef?: string;
  referenceNumber?: string;
}

export interface ModerationReport {
  id: string;
  reportedTargetId?: string;
  reportedTargetName?: string;
  targetId?: string;
  targetName?: string;
  targetType?: 'Host' | 'User' | 'LiveRoom' | string;
  reportedTargetType?: 'Host' | 'User' | 'LiveRoom' | string;
  reporterName: string;
  reporterId: string;
  reason: 'Inappropriate Content' | 'Harassment' | 'Underage' | 'Scam' | 'Copyright' | string;
  description: string;
  status: 'Pending' | 'Investigating' | 'Resolved' | 'Dismissed';
  timestamp: string;
  internalNote?: string;
  history?: { timestamp: string; action: string; note: string; author: string }[];
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  targetAudience: 'All' | 'Hosts' | 'Agencies' | 'VIPs' | 'Managers' | string;
  type?: 'Announcement' | 'System_Alert' | 'Reward' | string;
  sentAt?: string;
  timestamp?: string;
  status?: 'Sent' | 'Scheduled' | string;
  reachCount?: number;
  readCount?: number;
  sentBy?: string;
}

export type NotificationItem = SystemNotification;

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actorId?: string;
  actorName: string;
  actorRole: UserRole;
  action?: string;
  actionType?: 
    | 'LOGIN'
    | 'LOGOUT'
    | 'USER_MANAGEMENT'
    | 'HOST_MANAGEMENT'
    | 'AGENCY_ASSIGNMENT'
    | 'COIN_ADJUSTMENT'
    | 'GIFT_ACTIVITY'
    | 'LIVE_MODERATION'
    | 'SETTINGS_CHANGE'
    | 'SECURITY_BLOCKED'
    | string;
  targetId?: string;
  targetRole?: UserRole | string;
  targetEntity?: string;
  details: string;
  ipAddress: string;
  status: 'SUCCESS' | 'DENIED' | 'FLAGGED';
}

export interface PlatformSettings {
  platformCommissionRate: number; // 15%
  diamondToUSDRate?: number; // 10,000 diamonds = $1.00 USD (100k = $10)
  coinPriceUSD?: number;
  diamondRedemptionRateUSD?: number;
  minWithdrawalDiamonds: number; // 50,000
  hostDefaultCommissionRate?: number; // 70%
  agencyDefaultCommissionRate?: number; // 15%
  defaultAgencyCommissionRate?: number;
  platformWithdrawalTaxRate?: number; // 5% TDS / Withdrawal Tax
  coinTransferTaxRate?: number; // 2% Merchant & P2P Transfer Tax
  platformGiftingTaxRate?: number; // 15% Gifting Platform Cut
  vipTaxRebateEnabled?: boolean; // Enable VIP tax reduction
  maintenanceMode: boolean;
  antiFraudAIEnabled?: boolean;
  antiFraudEnabled?: boolean;
  autoApproveHosts?: boolean;
  allowMultiCamStreaming?: boolean;
  maxTestTransactionAmount?: number;
}

export interface OwnerDashboardStats {
  superAdminsCount: number;
  adminsCount: number;
  managersCount: number;
  agenciesCount: number;
  coinSellersCount?: number;
  hostsCount: number;
  onlineHostsCount: number;
  usersCount: number;
  liveRoomsCount: number;
  totalCoinsCirculation: number;
  totalDiamondsMinted: number;
  totalGiftsSent: number;
  totalTestTransactions: number;
  totalRevenueUSD: number;
  pendingWithdrawalsUSD: number;
  ownerTestCoinBalance?: number;
}

export interface CoinSellerAccount {
  id: string; // e.g. CS-7001
  name: string;
  username: string;
  contact?: string;
  phone?: string;
  email?: string;
  status: 'Active' | 'Inactive' | 'Suspended' | 'Deactivated';
  testCoinBalance: number; // e.g. 10,000,000 TEST COINS
  totalDistributed: number;
  dailyLimit: number;
  singleTransferLimit: number;
  lastActivity: string;
  createdDate: string;
  avatar: string;
  notes?: string;
}

export interface CoinSellerTransaction {
  id: string; // e.g. CTX-SELLER-98124
  sellerId: string;
  sellerName: string;
  userId: string;
  userName: string;
  amount: number;
  previousSellerBalance: number;
  newSellerBalance: number;
  previousUserBalance: number;
  newUserBalance: number;
  timestamp: string;
  operator: string;
  TEST_MODE: true;
  notes?: string;
}

export interface OwnerToSellerTransaction {
  id: string; // e.g. CTX-OWNER-77123
  type: 'OWNER_TO_SELLER' | 'RECLAIM_FROM_SELLER';
  ownerId: string;
  sellerId: string;
  sellerName: string;
  amount: number;
  previousOwnerBalance: number;
  newOwnerBalance: number;
  previousSellerBalance: number;
  newSellerBalance: number;
  timestamp: string;
  operator: string;
  TEST_MODE: true;
  notes?: string;
}

export interface PartySeat {
  seatNumber: number; // 1 to 20
  userId?: string;
  userName?: string;
  avatar?: string;
  isOwner: boolean; // Seat 1 is room owner
  hasSirCrown: boolean; // Only Seat 1 / Room Owner gets 👑 SIR CROWN
  isMuted: boolean;
  isCameraOn: boolean;
  isMicOn: boolean;
  isLocked: boolean;
  vipLevel?: number;
  diamondsEarned?: number;
  joinedAt?: string;
}

export interface PartyLiveRoomSession {
  id: string; // e.g. PARTY-2001
  title: string;
  ownerId: string;
  ownerName: string;
  ownerAvatar: string;
  crownHolderId: string;
  crownHolderName: string;
  crownTitle: string; // "👑 SIR CROWN"
  totalSeats: 20; // Exactly 20 seats
  seats: PartySeat[];
  viewerCount: number;
  totalGiftsReceivedCoins: number;
  startedAt: string;
  status: 'Active' | 'Locked' | 'Closed';
  category: string;
  bgTheme?: string;
  isTestRoom?: boolean;
  isLive?: boolean;
}

export interface AvatarFrameItem {
  id: string;
  name: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Royalty';
  previewUrl: string;
  coinPrice: number;
  vipLevelRequired: number;
  activeUsersCount: number;
  isAnimated: boolean;
  type?: 'Profile' | 'Avatar' | 'VIP' | 'Special';
  status?: 'Active' | 'Inactive';
  startDate?: string;
  endDate?: string;
  createdDate?: string;
  description?: string;
  assignedUserIds?: string[];
}


export type AgencyJoinRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED';

export interface PkBattleItem {
  id: string;
  host1Id: string;
  host1Name: string;
  host1Avatar?: string;
  host1Score: number;
  host2Id: string;
  host2Name: string;
  host2Avatar?: string;
  host2Score: number;
  score1?: number;
  score2?: number;
  durationSeconds?: number;
  remainingSeconds?: number;
  status: 'Active' | 'Completed' | 'Live' | 'Ended';
  duration?: string;
  mvpGifterName?: string;
  startedAt?: string;
}

export interface AgencyJoinRequest {
  id: string;
  hostId: string;
  hostName: string;
  hostAvatar: string;
  hostLevel: number;
  hostVipLevel?: number;
  agencyId: string;
  agencyName: string;
  ownerId: string;
  status: AgencyJoinRequestStatus;
  requestDate: string;
  approvalDate?: string;
  rejectionReason?: string;
}


