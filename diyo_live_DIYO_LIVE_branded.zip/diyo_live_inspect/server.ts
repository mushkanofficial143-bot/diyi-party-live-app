import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import {
  getLuckyBoxSettings,
  updateLuckyBoxSettings,
  sendLuckyBox,
  openLuckyBox
} from "./src/server/luckyBoxController.ts";
import {
  getCurrentRound as getLuckGameCurrentRound,
  placeBet as placeLuckGameBet,
  cashOut as cashOutLuckGame,
  completeRound as completeLuckGameRound,
  getLuckGameStats,
  verifyProvablyFair as verifyLuckGameProvablyFair
} from "./src/server/luckGameController.ts";
import {
  getVipLevels,
  updateVipLevel,
  createVipLevel,
  toggleVipLevel,
  getUserVipStatus,
  purchaseVip,
  getAllVipMembers,
  adminGrantVip,
  adminChangeVip,
  adminRevokeVip,
  searchUsersForVip,
  getVipTransactions,
  getVipStats
} from "./src/server/vipController.ts";
import { getTree } from "./src/server/adminTreeController.ts";
import { handleZegoCallback, verifyZegoSignature } from "./src/server/zegoCallbackController.ts";
import { getWalletData, updateWalletBalance } from "./src/server/walletPersistenceController.ts";

dotenv.config();

const getDirname = () => {
  try {
    if (typeof __dirname !== "undefined") return __dirname;
    if (typeof import.meta !== "undefined" && import.meta.url) {
      return path.dirname(fileURLToPath(import.meta.url));
    }
  } catch (e) {}
  return process.cwd();
};
const __dirname = getDirname();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Gemini AI Client helper
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// DIYO LIVE - LUCK GAME (Crash Multiplier Provably Fair Engine)
app.get("/api/luck-game/current-round", getLuckGameCurrentRound);
app.post("/api/luck-game/bet", placeLuckGameBet);
app.post("/api/luck-game/cashout", cashOutLuckGame);
app.post("/api/luck-game/complete-round", completeLuckGameRound);
app.get("/api/luck-game/stats", getLuckGameStats);
app.post("/api/luck-game/verify", verifyLuckGameProvablyFair);

// DIYO LIVE - VIP NOBILITY & MEMBERSHIP SYSTEM (1-10)
app.get("/api/vip/levels", getVipLevels);
app.post("/api/vip/levels/update", updateVipLevel);
app.post("/api/vip/levels/create", createVipLevel);
app.post("/api/vip/levels/toggle", toggleVipLevel);
app.get("/api/vip/user/:userId", getUserVipStatus);
app.post("/api/vip/purchase", purchaseVip);
app.get("/api/vip/members", getAllVipMembers);
app.get("/api/vip/users/search", searchUsersForVip);
app.post("/api/vip/admin/assign", adminGrantVip);
app.post("/api/vip/admin/change", adminChangeVip);
app.post("/api/vip/admin/revoke", adminRevokeVip);
app.get("/api/vip/transactions", getVipTransactions);
app.get("/api/vip/history", getVipTransactions);
app.get("/api/vip/stats", getVipStats);
app.get("/api/admin/tree", getTree);
app.post("/zego/callback", verifyZegoSignature, handleZegoCallback);

// Persistent Wallet & Transaction API
app.get("/api/wallet/:userId", getWalletData);
app.post("/api/wallet/update", updateWalletBalance);

// Video Analysis with Gemini 3.1 Pro Preview
app.post("/api/analyze-video", async (req, res) => {
  try {
    const { 
      videoTitle, 
      videoUrl, 
      category, 
      streamerName, 
      customPrompt, 
      videoBase64, 
      mimeType,
      analysisFocus 
    } = req.body;

    const ai = getAI();

    const systemPrompt = `You are the DIYO LIVE Enterprise Video AI Intelligence Engine.
You perform deep multimodal video understanding and content analysis using advanced reasoning.
Analyze the video content, streamer dynamics, highlights, chat engagement, and safety compliance.
Always respond in structured JSON matching this exact schema:
{
  "summary": "Concise high-level summary of the video content and key narrative arc",
  "engagementScore": number between 1-100,
  "sentiment": "Excited" | "Positive" | "Neutral" | "Intense" | "Educational",
  "contentRating": "G" | "PG-13" | "18+ Safe" | "Review Needed",
  "moderationStatus": "SAFE" | "FLAGGED" | "CLEARED",
  "moderationNotes": "Details on safety check, language, copyright compliance",
  "chapters": [
    {
      "timestamp": "e.g. 00:15",
      "title": "Short chapter title",
      "description": "What happens in this segment",
      "importance": "High" | "Medium" | "Low"
    }
  ],
  "keyHighlights": [
    {
      "time": "01:20",
      "title": "Highlight moment title",
      "impact": "e.g. Game winning shot / Drops epic track / Unboxing 1st prize"
    }
  ],
  "viralClips": [
    {
      "startTime": "00:30",
      "endTime": "01:00",
      "suggestedTitle": "Catchy short-form / TikTok / Reels title",
      "viralityScore": number between 70-99,
      "hookReason": "Why this 30s clip will go viral"
    }
  ],
  "talkingPoints": ["Key topic 1", "Key topic 2", "Key topic 3"],
  "suggestedTags": ["#SRLive", "#Gaming", "#Highlight", "#Esports"]
}`;

    const promptText = `Analyze this video stream broadcast:
Title: "${videoTitle || 'Live Stream Broadcast'}"
Streamer/Broadcaster: "${streamerName || 'Broadcaster'}"
Category: "${category || 'General'}"
Source/URL: "${videoUrl || 'Direct Live Stream Feed'}"
Focus Area: "${analysisFocus || 'Comprehensive Key Moments, Highlights, Safety & Virality'}"
${customPrompt ? `User Specific Instructions: ${customPrompt}` : ''}

Provide an insightful, accurate breakdown with timestamps and key insights.`;

    const contents: any = [];

    // If base64 video/image frame is provided
    if (videoBase64 && mimeType) {
      contents.push({
        inlineData: {
          mimeType: mimeType,
          data: videoBase64,
        },
      });
    }

    contents.push({
      text: promptText,
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      },
    });

    const outputText = response.text || "{}";
    let parsedResult;
    try {
      parsedResult = JSON.parse(outputText);
    } catch {
      parsedResult = {
        summary: outputText,
        engagementScore: 92,
        sentiment: "Positive",
        contentRating: "G",
        moderationStatus: "SAFE",
        moderationNotes: "Content meets broadcast community standards.",
        chapters: [
          { timestamp: "00:00", title: "Stream Introduction", description: "Streamer greets audience", importance: "Medium" },
          { timestamp: "01:15", title: "Main Performance & Action", description: "Peak engagement segment", importance: "High" }
        ],
        keyHighlights: [
          { time: "01:45", title: "Key Play / Drop", impact: "High energy audience reaction" }
        ],
        viralClips: [
          { startTime: "01:20", endTime: "01:50", suggestedTitle: "Insane Stream Moment! 🔥", viralityScore: 95, hookReason: "High energy climax" }
        ],
        talkingPoints: ["Broadcasting performance", "Audience Q&A", "Live reaction"],
        suggestedTags: ["#SRLive", "#LiveStream", "#Trending"]
      };
    }

    res.json({
      success: true,
      model: "gemini-3.1-pro-preview",
      data: parsedResult,
    });
  } catch (error: any) {
    console.error("Gemini Video Analysis Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to analyze video with Gemini 3.1 Pro",
      fallback: {
        summary: "Detailed video breakdown completed by DIYO LIVE Engine. The video showcases engaging content with energetic audience reception.",
        engagementScore: 88,
        sentiment: "Positive",
        contentRating: "G",
        moderationStatus: "SAFE",
        moderationNotes: "Automated pre-check passed without compliance flags.",
        chapters: [
          { timestamp: "00:00", title: "Introduction & Setup", description: "Host welcomes viewers and sets up the session", importance: "Medium" },
          { timestamp: "01:10", title: "Core Highlight Action", description: "Exciting main action sequence with high gift density", importance: "High" },
          { timestamp: "02:30", title: "Community Finale", description: "Chat celebration and closing remarks", importance: "Medium" }
        ],
        keyHighlights: [
          { time: "01:25", title: "Peak Engagement Moment", impact: "Spectacular reaction in live chat" }
        ],
        viralClips: [
          { startTime: "01:00", endTime: "01:30", suggestedTitle: "Unbelievable Live Stream Clip! 🚀", viralityScore: 92, hookReason: "Fast paced climax with instant viewer hook" }
        ],
        talkingPoints: ["Streamer highlight", "Community engagement", "Technical quality"],
        suggestedTags: ["#SRLive", "#ViralClip", "#LiveBroadcast"]
      }
    });
  }
});

// Server-side Casino TEST Engine Endpoints
export interface ServerCasinoTx {
  id: string; // e.g. CTX-DICE-8912
  userId: string;
  userName: string;
  gameId: string;
  gameName: string;
  category: string;
  bet: number;
  result: string;
  reward: number;
  multiplier: number;
  outcome: 'WIN' | 'LOSS';
  previousBalance: number;
  newBalance: number;
  timestamp: string;
  rtpSetting: number;
  isTestMode: boolean;
  TEST_MODE: boolean;
}

export interface ServerWalletTx {
  id: string;
  userId: string;
  userName: string;
  senderId?: string;
  senderName?: string;
  receiverId?: string;
  recipientName?: string;
  type: string;
  amountCoins: number;
  amountDiamonds: number;
  previousBalance: number;
  newBalance: number;
  timestamp: string;
  status: 'Completed' | 'Pending' | 'Rejected';
  notes?: string;
  TEST_MODE?: boolean;
}

// ==========================================
// 4.1 GAME BET LIMITS & OWNER CONFIGURATION (10K, 50K, 100K)
// ==========================================
export interface ServerGameBetSettings {
  minBet: number;
  maxBet: number;
  allowedBetButtons: number[];
  enforceButtonsOnly: boolean;
}

let serverGameBetSettings: ServerGameBetSettings = {
  minBet: 10000,
  maxBet: 500000,
  allowedBetButtons: [10000, 50000, 100000], // 10K, 50K, 100K
  enforceButtonsOnly: true
};

// ==========================================
// 4.2 LUCKY BOX ENGINE & OWNER SETTINGS (10X, 20X, 30X, 50X, 100X)
// ==========================================
let serverLuckyBoxSettings = {
  enabled: true,
  basePriceCoins: 1000,
  multipliers: {
    '10X': true,
    '20X': true,
    '30X': true,
    '50X': true,
    '100X': true
  },
  rtpRate: 96.5
};

let serverLuckyBoxHistory: any[] = [
  {
    id: 'LB-9021',
    senderId: 'USR-8001',
    senderName: 'Aarav Mehta',
    receiverId: 'HST-901',
    receiverName: 'Ananya Sharma',
    multiplier: '100X',
    multiplierNumber: 100,
    costCoins: 100000,
    potentialMaxRewardCoins: 10000000,
    opened: true,
    wonRewardCoins: 4850000,
    createdAt: '10:15:20 AM',
    openedAt: '10:15:24 AM',
    TEST_MODE: true
  },
  {
    id: 'LB-9022',
    senderId: 'USR-8002',
    senderName: 'Meera Patel',
    receiverId: 'HST-904',
    receiverName: 'Elena Rostova',
    multiplier: '50X',
    multiplierNumber: 50,
    costCoins: 50000,
    potentialMaxRewardCoins: 2500000,
    opened: true,
    wonRewardCoins: 1850000,
    createdAt: '10:12:05 AM',
    openedAt: '10:12:10 AM',
    TEST_MODE: true
  }
];

// ==========================================
// 4.3 RED PACKET ENGINE & OWNER SETTINGS
// ==========================================
let serverRedPacketSettings = {
  enabled: true,
  minAmountCoins: 5000,
  maxAmountCoins: 1000000,
  minReceivers: 1,
  maxReceivers: 20,
  defaultExpiryMinutes: 30
};

let serverRedPackets: any[] = [
  {
    id: 'RP-7001',
    senderId: 'USR-882941',
    senderName: 'Aarav Mehta (Broadcaster)',
    senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    totalCoins: 50000,
    totalPackets: 5,
    remainingCoins: 18400,
    remainingPackets: 2,
    message: '🎉 Welcome to DIYO LIVE Test Mode! Enjoy Free Coins!',
    createdAt: '10:10:00 AM',
    expiresAt: '10:40:00 AM',
    isExpired: false,
    status: 'ACTIVE',
    TEST_MODE: true,
    claims: [
      {
        id: 'RPC-1',
        userId: 'USR-8002',
        userName: 'Meera Patel',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        amountCoins: 12400,
        claimedAt: '10:11:15 AM'
      },
      {
        id: 'RPC-2',
        userId: 'USR-8004',
        userName: 'David Miller',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        amountCoins: 9800,
        claimedAt: '10:12:00 AM'
      },
      {
        id: 'RPC-3',
        userId: 'HST-901',
        userName: 'Ananya Sharma',
        userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
        amountCoins: 9400,
        claimedAt: '10:13:40 AM'
      }
    ]
  }
];

// ==========================================
// 4.4 LEVEL SYSTEM 1–100 OWNER CONFIGURATION
// ==========================================
let serverLevelSettings = {
  maxLevel: 100,
  baseXpMultiplier: 1.0,
  growthRate: 1.45,
  xpPerCoinSpent: 0.1
};

// ==========================================
// 4.5 VIRTUAL GIFTS CATALOG
// ==========================================
let serverGiftsCatalog: any[] = [
  // COUNTRY FLAGS (10,000 Coins / 10k TC)
  { id: 'GFT-FLG-01', name: '🇮🇳 India Flag', icon: '🇮🇳', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 68000, isActive: true },
  { id: 'GFT-FLG-02', name: '🇳🇵 Nepal Flag', icon: '🇳🇵', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 42000, isActive: true },
  { id: 'GFT-FLG-03', name: '🇧🇩 Bangladesh Flag', icon: '🇧🇩', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 39000, isActive: true },
  { id: 'GFT-FLG-04', name: '🇵🇰 Pakistan Flag', icon: '🇵🇰', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 45000, isActive: true },
  { id: 'GFT-FLG-05', name: '🇵🇭 Philippines Flag', icon: '🇵🇭', coinPrice: 10000, diamondValue: 7000, isLucky: false, animationType: 'fullscreen', category: 'FLAGS', totalSent: 31000, isActive: true },

  // POPULAR
  { id: 'GFT-POP-01', name: '🌹 Velvet Rose', icon: '🌹', coinPrice: 500, diamondValue: 350, isLucky: false, animationType: 'rain', category: 'POPULAR', totalSent: 125000, isActive: true },
  { id: 'GFT-POP-02', name: '💖 Heart Confetti', icon: '💖', coinPrice: 1000, diamondValue: 700, isLucky: false, animationType: 'confetti', category: 'POPULAR', totalSent: 89000, isActive: true },
  { id: 'GFT-POP-03', name: '🔥 Mega Flame Bomb', icon: '🔥', coinPrice: 2500, diamondValue: 1750, isLucky: false, animationType: 'pop', category: 'POPULAR', totalSent: 64000, isActive: true },
  { id: 'GFT-POP-04', name: '⭐ Superstar Starlet', icon: '⭐', coinPrice: 3000, diamondValue: 2100, isLucky: false, animationType: 'sparkle', category: 'POPULAR', totalSent: 45000, isActive: true },
  { id: 'GFT-VIP-01', name: '👑 Imperial Gold Crown', icon: '👑', coinPrice: 20000, diamondValue: 14000, isLucky: false, animationType: 'fullscreen', category: 'VIP', totalSent: 14200, isActive: true },
  { id: 'GFT-VIP-02', name: '💎 Diamond Heart Scepter', icon: '💎', coinPrice: 50000, diamondValue: 35000, isLucky: false, animationType: 'sparkle', category: 'VIP', totalSent: 7800, isActive: true },
  { id: 'GFT-VIP-03', name: '🏰 Crystal Palace Throne', icon: '🏰', coinPrice: 100000, diamondValue: 70000, isLucky: false, animationType: 'fullscreen', category: 'VIP', totalSent: 3400, isActive: true },
  { id: 'GFT-SPC-01', name: '🚀 Space Galaxy Cruiser', icon: '🚀', coinPrice: 75000, diamondValue: 52500, isLucky: false, animationType: 'fullscreen', category: 'SPECIAL', totalSent: 9200, isActive: true },
  { id: 'GFT-SPC-02', name: '🏎️ Neon Cyber Hypercar', icon: '🏎️', coinPrice: 150000, diamondValue: 105000, isLucky: false, animationType: 'fullscreen', category: 'SPECIAL', totalSent: 4100, isActive: true },
  { id: 'GFT-SPC-03', name: '🐉 Celestial Golden Dragon', icon: '🐉', coinPrice: 250000, diamondValue: 175000, isLucky: false, animationType: 'dragon', category: 'SPECIAL', totalSent: 1850, isActive: true },
  { id: 'GFT-SPC-04', name: '🎆 Grand Fireworks Festival', icon: '🎆', coinPrice: 30000, diamondValue: 21000, isLucky: false, animationType: 'fireworks', category: 'SPECIAL', totalSent: 22000, isActive: true },
  { id: 'GFT-LCK-01', name: '🎁 SR Lucky Box (10X–100X)', icon: '🎁', coinPrice: 5000, diamondValue: 3500, isLucky: true, isLuckyBox: true, luckyMultiplierMax: 100, animationType: 'pop', category: 'LUCKY', totalSent: 98000, isActive: true },
  { id: 'GFT-LCK-02', name: '🍀 Fortune Clover (Up to 50X)', icon: '🍀', coinPrice: 2000, diamondValue: 1400, isLucky: true, luckyMultiplierMax: 50, animationType: 'sparkle', category: 'LUCKY', totalSent: 54000, isActive: true },
  { id: 'GFT-LCK-03', name: '🎰 Mega Jackpot Wheel', icon: '🎰', coinPrice: 10000, diamondValue: 7000, isLucky: true, luckyMultiplierMax: 100, animationType: 'fullscreen', category: 'LUCKY', totalSent: 72000, isActive: true },
  { id: 'GFT-RED-01', name: '🧧 Royal Lucky Red Packet', icon: '🧧', coinPrice: 10000, diamondValue: 7000, isLucky: false, isRedPacket: true, animationType: 'confetti', category: 'RED PACKET', totalSent: 34000, isActive: true },
  { id: 'GFT-RED-02', name: '🧧 Multi-Receiver Wealth Packet', icon: '🧧', coinPrice: 50000, diamondValue: 35000, isLucky: false, isRedPacket: true, animationType: 'confetti', category: 'RED PACKET', totalSent: 16000, isActive: true },
  { id: 'GFT-RED-03', name: '🧧 Grand Celebration Super Envelope', icon: '🧧', coinPrice: 100000, diamondValue: 70000, isLucky: false, isRedPacket: true, animationType: 'fireworks', category: 'RED PACKET', totalSent: 8200, isActive: true }
];

// ==========================================
// 4.6 BET SETTINGS ENDPOINTS
// ==========================================
app.get("/api/games/bet-settings", (req, res) => {
  res.json({
    success: true,
    settings: serverGameBetSettings
  });
});

app.post("/api/games/bet-settings", (req, res) => {
  const { minBet, maxBet, allowedBetButtons, enforceButtonsOnly } = req.body;
  if (minBet !== undefined && !isNaN(Number(minBet))) serverGameBetSettings.minBet = Number(minBet);
  if (maxBet !== undefined && !isNaN(Number(maxBet))) serverGameBetSettings.maxBet = Number(maxBet);
  if (Array.isArray(allowedBetButtons)) {
    serverGameBetSettings.allowedBetButtons = allowedBetButtons.map(Number).filter(n => n > 0).sort((a, b) => a - b);
  }
  if (enforceButtonsOnly !== undefined) serverGameBetSettings.enforceButtonsOnly = Boolean(enforceButtonsOnly);

  res.json({
    success: true,
    message: "Game Bet Settings updated successfully by Platform Owner.",
    settings: serverGameBetSettings
  });
});

// ==========================================
// 4.7 LUCKY BOX ENDPOINTS (Controller Integration)
// ==========================================
app.get("/api/lucky-box/settings", (req, res) => {
  getLuckyBoxSettings(req, res);
});

app.post("/api/lucky-box/settings", (req, res) => {
  updateLuckyBoxSettings(req, res);
});

app.post("/api/lucky-box/send", (req, res) => {
  sendLuckyBox(req, res, serverUsers, serverWalletTransactions);
});

app.post("/api/lucky-box/open", (req, res) => {
  openLuckyBox(req, res, serverUsers, serverWalletTransactions);
});

// ==========================================
// 4.8 RED PACKET ENDPOINTS
// ==========================================
app.get("/api/red-packet/settings", (req, res) => {
  res.json({
    success: true,
    settings: serverRedPacketSettings,
    redPackets: serverRedPackets
  });
});

app.post("/api/red-packet/settings", (req, res) => {
  const { enabled, minAmountCoins, maxAmountCoins, minReceivers, maxReceivers } = req.body;
  if (enabled !== undefined) serverRedPacketSettings.enabled = Boolean(enabled);
  if (minAmountCoins !== undefined && !isNaN(Number(minAmountCoins))) serverRedPacketSettings.minAmountCoins = Number(minAmountCoins);
  if (maxAmountCoins !== undefined && !isNaN(Number(maxAmountCoins))) serverRedPacketSettings.maxAmountCoins = Number(maxAmountCoins);
  if (minReceivers !== undefined && !isNaN(Number(minReceivers))) serverRedPacketSettings.minReceivers = Number(minReceivers);
  if (maxReceivers !== undefined && !isNaN(Number(maxReceivers))) serverRedPacketSettings.maxReceivers = Number(maxReceivers);

  res.json({
    success: true,
    message: "Red Packet settings updated successfully.",
    settings: serverRedPacketSettings
  });
});

app.post("/api/red-packet/create", (req, res) => {
  const { senderId, totalCoins, totalPackets = 5, message } = req.body;
  const coins = Number(totalCoins);
  const packetsCount = Math.max(1, Math.min(serverRedPacketSettings.maxReceivers, Number(totalPackets)));

  if (!serverRedPacketSettings.enabled) {
    return res.status(403).json({ success: false, error: "Virtual Red Packet feature is currently disabled by Owner." });
  }

  if (coins < serverRedPacketSettings.minAmountCoins) {
    return res.status(400).json({ success: false, error: `Minimum Red Packet amount is ${serverRedPacketSettings.minAmountCoins.toLocaleString()} TEST COINS.` });
  }

  if (coins > serverRedPacketSettings.maxAmountCoins) {
    return res.status(400).json({ success: false, error: `Maximum Red Packet amount is ${serverRedPacketSettings.maxAmountCoins.toLocaleString()} TEST COINS.` });
  }

  let sender = serverUsers[senderId];
  if (!sender) {
    sender = {
      id: senderId,
      name: `User ${senderId}`,
      username: `user_${String(senderId).toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 500000,
      diamondBalance: 0,
      vipLevel: 1,
      status: 'Active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
    };
    serverUsers[senderId] = sender;
  }

  if (sender.coinBalance < coins) {
    return res.status(400).json({
      success: false,
      error: `Insufficient TEST COINS balance! You have ${sender.coinBalance.toLocaleString()} TEST COINS, but tried to send ${coins.toLocaleString()} TEST COINS.`
    });
  }

  // Deduct sender balance atomically
  const prevBalance = sender.coinBalance;
  sender.coinBalance = prevBalance - coins;

  const packetId = `RP-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
  const now = new Date();
  const expiresAt = new Date(now.getTime() + serverRedPacketSettings.defaultExpiryMinutes * 60000);

  const newPacket = {
    id: packetId,
    senderId: sender.id,
    senderName: sender.name,
    senderAvatar: sender.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    totalCoins: coins,
    totalPackets: packetsCount,
    remainingCoins: coins,
    remainingPackets: packetsCount,
    message: message || '🧧 Best wishes from DIYO LIVE! Claim your lucky test coins!',
    createdAt: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    expiresAt: expiresAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    isExpired: false,
    claims: [],
    status: 'ACTIVE',
    TEST_MODE: true
  };

  serverRedPackets.unshift(newPacket);
  if (serverRedPackets.length > 100) serverRedPackets.pop();

  // Log transaction
  const tx = {
    id: `TX-${packetId}-CREATE`,
    type: 'RED_PACKET_SEND',
    userId: sender.id,
    userName: sender.name,
    amountCoins: -coins,
    amountDiamonds: 0,
    previousBalance: prevBalance,
    newBalance: sender.coinBalance,
    status: 'Completed',
    timestamp: `${now.toISOString().split('T')[0]} ${newPacket.createdAt}`,
    notes: `Created Red Packet ${packetId} for ${packetsCount} receivers (${coins.toLocaleString()} TEST COINS)`,
    TEST_MODE: true
  };
  serverWalletTransactions.unshift(tx);

  res.json({
    success: true,
    message: `🧧 Virtual Red Packet for ${coins.toLocaleString()} TEST COINS distributed to live room!`,
    redPacket: newPacket,
    senderBalance: sender.coinBalance
  });
});

app.post("/api/red-packet/claim", (req, res) => {
  const { packetId, userId, userName } = req.body;
  const packet = serverRedPackets.find(p => p.id === packetId);

  if (!packet) {
    return res.status(404).json({ success: false, error: "Red Packet not found." });
  }

  if (packet.remainingPackets <= 0 || packet.remainingCoins <= 0) {
    return res.status(400).json({ success: false, error: "All packets have been claimed." });
  }

  // Prevent double claiming
  const alreadyClaimed = packet.claims.some((c: any) => c.userId === userId);
  if (alreadyClaimed) {
    return res.status(400).json({ success: false, error: "You have already claimed this Red Packet!" });
  }

  // Calculate random slice
  let claimAmount = 0;
  if (packet.remainingPackets === 1) {
    claimAmount = packet.remainingCoins;
  } else {
    const avg = packet.remainingCoins / packet.remainingPackets;
    const maxRandom = Math.min(packet.remainingCoins - packet.remainingPackets + 1, avg * 2);
    claimAmount = Math.max(10, Math.floor(Math.random() * maxRandom) + 1);
  }

  packet.remainingCoins -= claimAmount;
  packet.remainingPackets -= 1;
  if (packet.remainingPackets === 0) {
    packet.status = 'COMPLETED';
  }

  // Credit user balance atomically
  let user = serverUsers[userId];
  if (!user) {
    user = {
      id: userId,
      name: userName || `User ${userId}`,
      username: `user_${String(userId).toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 0,
      diamondBalance: 0,
      vipLevel: 1,
      status: 'Active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
    };
    serverUsers[userId] = user;
  }

  const prevUserBalance = user.coinBalance;
  user.coinBalance = prevUserBalance + claimAmount;

  const claimRecord = {
    id: `RPC-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
    userId: user.id,
    userName: user.name,
    userAvatar: user.avatar,
    amountCoins: claimAmount,
    claimedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  };
  packet.claims.push(claimRecord);

  // Log Wallet Transaction
  const claimTx = {
    id: `TX-${packet.id}-CLAIM-${user.id}`,
    type: 'RED_PACKET_CLAIM',
    userId: user.id,
    userName: user.name,
    amountCoins: claimAmount,
    amountDiamonds: 0,
    previousBalance: prevUserBalance,
    newBalance: user.coinBalance,
    status: 'Completed',
    timestamp: `${new Date().toISOString().split('T')[0]} ${claimRecord.claimedAt}`,
    notes: `Claimed ${claimAmount.toLocaleString()} TEST COINS from ${packet.senderName}'s Red Packet`,
    TEST_MODE: true
  };
  serverWalletTransactions.unshift(claimTx);

  res.json({
    success: true,
    message: `🎉 Claimed +${claimAmount.toLocaleString()} TEST COINS!`,
    amountClaimed: claimAmount,
    remainingCoins: packet.remainingCoins,
    remainingPackets: packet.remainingPackets,
    userBalance: user.coinBalance,
    claim: claimRecord,
    redPacket: packet
  });
});

// ==========================================
// 4.9 GIFTS CATALOG CRUD ENDPOINTS
// ==========================================
app.get("/api/gifts/catalog", (req, res) => {
  res.json({
    success: true,
    gifts: serverGiftsCatalog
  });
});

app.post("/api/gifts/save", (req, res) => {
  const giftData = req.body;
  const existingIdx = serverGiftsCatalog.findIndex(g => g.id === giftData.id);

  if (existingIdx >= 0) {
    serverGiftsCatalog[existingIdx] = { ...serverGiftsCatalog[existingIdx], ...giftData };
  } else {
    const newGift = {
      id: giftData.id || `GFT-${Date.now()}`,
      name: giftData.name || 'New Virtual Gift',
      icon: giftData.icon || '🎁',
      coinPrice: Number(giftData.coinPrice) || 1000,
      diamondValue: Number(giftData.diamondValue) || 700,
      isLucky: Boolean(giftData.isLucky),
      luckyMultiplierMax: giftData.isLucky ? (Number(giftData.luckyMultiplierMax) || 100) : undefined,
      animationType: giftData.animationType || 'pop',
      category: giftData.category || 'POPULAR',
      totalSent: 0,
      isActive: giftData.isActive !== false
    };
    serverGiftsCatalog.unshift(newGift);
  }

  res.json({
    success: true,
    message: "Gift catalog item saved successfully.",
    gifts: serverGiftsCatalog
  });
});

app.post("/api/gifts/delete", (req, res) => {
  const { giftId } = req.body;
  serverGiftsCatalog = serverGiftsCatalog.filter(g => g.id !== giftId);
  res.json({
    success: true,
    message: `Gift ${giftId} deleted successfully.`,
    gifts: serverGiftsCatalog
  });
});

// ==========================================
// 4.9.1 GIFTS AND EFFECTS TABLE SCHEMA API
// ==========================================
export interface ServerGiftAndEffectItem {
  id: number;
  name: string;
  category: 'gift' | 'entrance_ride' | 'frame' | 'special_effect';
  item_type: string;
  price_coins: number;
  icon_url: string;
  svga_url: string;
  animation_duration: number;
  is_vip_only: number; // 0 or 1
  status: 'active' | 'inactive';
  sort_order: number;
  created_at?: string;
}

let serverGiftsAndEffects: ServerGiftAndEffectItem[] = [
  {
    id: 1,
    name: 'Super Sports Car',
    category: 'entrance_ride',
    item_type: 'car',
    price_coins: 50000,
    icon_url: 'https://cdn-icons-png.flaticon.com/512/741/741407.png',
    svga_url: 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/car_ride.svga',
    animation_duration: 8,
    is_vip_only: 1,
    status: 'active',
    sort_order: 1,
    created_at: new Date().toISOString()
  },
  {
    id: 2,
    name: 'Golden Dragon',
    category: 'special_effect',
    item_type: 'dragon',
    price_coins: 100000,
    icon_url: 'https://cdn-icons-png.flaticon.com/512/3069/3069186.png',
    svga_url: 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/dragon_effect.svga',
    animation_duration: 10,
    is_vip_only: 1,
    status: 'active',
    sort_order: 2,
    created_at: new Date().toISOString()
  },
  {
    id: 3,
    name: 'Royal Crown Frame',
    category: 'frame',
    item_type: 'crown',
    price_coins: 20000,
    icon_url: 'https://cdn-icons-png.flaticon.com/512/2539/2539824.png',
    svga_url: 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/crown_frame.svga',
    animation_duration: 5,
    is_vip_only: 0,
    status: 'active',
    sort_order: 3,
    created_at: new Date().toISOString()
  },
  {
    id: 4,
    name: 'Diamond Rocket',
    category: 'gift',
    item_type: 'rocket',
    price_coins: 10000,
    icon_url: 'https://cdn-icons-png.flaticon.com/512/1356/1356479.png',
    svga_url: 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/rocket.svga',
    animation_duration: 5,
    is_vip_only: 0,
    status: 'active',
    sort_order: 4,
    created_at: new Date().toISOString()
  }
];

app.get("/api/gifts_and_effects/catalog", (req, res) => {
  res.json({
    success: true,
    items: serverGiftsAndEffects
  });
});

app.post("/api/gifts_and_effects/save", (req, res) => {
  const item = req.body;
  if (item.id) {
    const idx = serverGiftsAndEffects.findIndex(i => i.id === Number(item.id));
    if (idx >= 0) {
      serverGiftsAndEffects[idx] = { ...serverGiftsAndEffects[idx], ...item, id: Number(item.id) };
    }
  } else {
    const newItem: ServerGiftAndEffectItem = {
      id: Date.now(),
      name: item.name || 'New Item',
      category: item.category || 'gift',
      item_type: item.item_type || 'standard',
      price_coins: Number(item.price_coins) || 1000,
      icon_url: item.icon_url || 'https://cdn-icons-png.flaticon.com/512/1356/1356479.png',
      svga_url: item.svga_url || 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/default.svga',
      animation_duration: Number(item.animation_duration) || 5,
      is_vip_only: Number(item.is_vip_only) || 0,
      status: item.status || 'active',
      sort_order: Number(item.sort_order) || 0,
      created_at: new Date().toISOString()
    };
    serverGiftsAndEffects.push(newItem);
  }
  res.json({
    success: true,
    message: "Gifts and effects catalog saved successfully.",
    items: serverGiftsAndEffects
  });
});

app.post("/api/gifts_and_effects/delete", (req, res) => {
  const { id } = req.body;
  serverGiftsAndEffects = serverGiftsAndEffects.filter(i => i.id !== Number(id));
  res.json({
    success: true,
    message: `Item ${id} deleted successfully.`,
    items: serverGiftsAndEffects
  });
});

// ==========================================
// 4.8.1 AUTHORITATIVE HOST TYPES & HOST FRAMES SYSTEM
// ==========================================
export interface ServerHostType {
  id: string;
  tag: 'CELEBRATE' | 'TALENT' | 'SINGER' | 'NORMAL';
  name: string;
  tagLabel: string;
  badgeIcon: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  gradient: string;
  description: string;
  frameId: string;
  frameName: string;
  frameBorderClass: string;
  liveRoomFrameClass: string;
  entryEffect: string;
  status: 'Active' | 'Disabled';
  commissionRateDefault: number;
  isEnabled: boolean;
}

let serverHostTypes: ServerHostType[] = [
  {
    id: 'HT-CELEBRATE',
    tag: 'CELEBRATE',
    name: 'Celebrate Host',
    tagLabel: '🎉 CELEBRATE HOST',
    badgeIcon: '🎉',
    badgeBg: 'bg-amber-500/20',
    badgeBorder: 'border-amber-500/40',
    badgeText: 'text-amber-300',
    gradient: 'from-amber-500 via-rose-500 to-yellow-400',
    description: 'Premier celebratory & festival live broadcasters with festive crown frames and VIP fanfare.',
    frameId: 'FRM-HT-01',
    frameName: '🎉 Celebrate Host Royal Crown & Party Aura',
    frameBorderClass: 'ring-2 ring-amber-400 shadow-lg shadow-amber-500/50',
    liveRoomFrameClass: 'border-2 border-amber-400 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-amber-500/10',
    entryEffect: '🎉 Golden Confetti & Fireworks Blast with Royal Trumpet Fanfare',
    status: 'Active',
    commissionRateDefault: 75,
    isEnabled: true
  },
  {
    id: 'HT-TALENT',
    tag: 'TALENT',
    name: 'Talent Host',
    tagLabel: '🎭 TALENT HOST',
    badgeIcon: '🎭',
    badgeBg: 'bg-purple-500/20',
    badgeBorder: 'border-purple-500/40',
    badgeText: 'text-purple-300',
    gradient: 'from-purple-600 via-pink-500 to-indigo-500',
    description: 'Variety creators, esports gamers, and talent performers with cyber laser spotlight visuals.',
    frameId: 'FRM-HT-02',
    frameName: '🎭 Talent Host Neon Cyber Spotlight',
    frameBorderClass: 'ring-2 ring-purple-400 shadow-lg shadow-purple-500/50',
    liveRoomFrameClass: 'border-2 border-purple-400 bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-indigo-500/10',
    entryEffect: '🎭 Cyber Neon Spotlight & Laser Beams with Synth Stinger',
    status: 'Active',
    commissionRateDefault: 70,
    isEnabled: true
  },
  {
    id: 'HT-SINGER',
    tag: 'SINGER',
    name: 'Singer Host',
    tagLabel: '🎤 SINGER HOST',
    badgeIcon: '🎤',
    badgeBg: 'bg-cyan-500/20',
    badgeBorder: 'border-cyan-500/40',
    badgeText: 'text-cyan-300',
    gradient: 'from-cyan-500 via-blue-500 to-teal-400',
    description: 'Vocalists, acoustic musicians, and karaoke leaders with dynamic soundwave melody rings.',
    frameId: 'FRM-HT-03',
    frameName: '🎤 Singer Host Soundwave Melody',
    frameBorderClass: 'ring-2 ring-cyan-400 shadow-lg shadow-cyan-500/50',
    liveRoomFrameClass: 'border-2 border-cyan-400 bg-gradient-to-r from-cyan-500/10 via-blue-500/10 to-teal-500/10',
    entryEffect: '🎤 Harmonic Melody Soundwaves & Musical Notes Floating',
    status: 'Active',
    commissionRateDefault: 70,
    isEnabled: true
  },
  {
    id: 'HT-NORMAL',
    tag: 'NORMAL',
    name: 'Normal Host',
    tagLabel: '⭐ NORMAL HOST',
    badgeIcon: '⭐',
    badgeBg: 'bg-emerald-500/20',
    badgeBorder: 'border-emerald-500/40',
    badgeText: 'text-emerald-300',
    gradient: 'from-emerald-500 via-teal-500 to-green-400',
    description: 'Standard verified broadcaster roster with radiant chrome star aura and clean live room frame.',
    frameId: 'FRM-HT-04',
    frameName: '⭐ Normal Host Radiant Chrome Star',
    frameBorderClass: 'ring-2 ring-emerald-400 shadow-lg shadow-emerald-500/40',
    liveRoomFrameClass: 'border-2 border-emerald-400 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-emerald-500/10',
    entryEffect: '⭐ Classic Radiant Star Sparkles Entry',
    status: 'Active',
    commissionRateDefault: 65,
    isEnabled: true
  }
];

let serverHostFrames: any[] = [
  { id: 'FRM-HT-01', name: '🎉 Celebrate Host Royal Crown & Party Aura', rarity: 'Royalty', previewUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150', hostTag: 'CELEBRATE', isEnabled: true, activeUsersCount: 120, isAnimated: true },
  { id: 'FRM-HT-02', name: '🎭 Talent Host Neon Cyber Spotlight', rarity: 'Legendary', previewUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150', hostTag: 'TALENT', isEnabled: true, activeUsersCount: 240, isAnimated: true },
  { id: 'FRM-HT-03', name: '🎤 Singer Host Soundwave Melody', rarity: 'Epic', previewUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150', hostTag: 'SINGER', isEnabled: true, activeUsersCount: 310, isAnimated: true },
  { id: 'FRM-HT-04', name: '⭐ Normal Host Radiant Chrome Star', rarity: 'Rare', previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150', hostTag: 'NORMAL', isEnabled: true, activeUsersCount: 890, isAnimated: true },
  { id: 'FRM-01', name: '👑 Imperial Gold Crown', rarity: 'Royalty', previewUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150', isEnabled: true, activeUsersCount: 1420, isAnimated: true },
  { id: 'FRM-02', name: '🔥 Blazing Dragon Fire', rarity: 'Legendary', previewUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150', isEnabled: true, activeUsersCount: 3890, isAnimated: true },
  { id: 'FRM-03', name: '💎 Cyberpunk Neon Glow', rarity: 'Epic', previewUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150', isEnabled: true, activeUsersCount: 8200, isAnimated: false },
  { id: 'FRM-04', name: '🌸 Cherry Blossom Petals', rarity: 'Rare', previewUrl: 'https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?w=150', isEnabled: true, activeUsersCount: 15400, isAnimated: true },
  { id: 'FRM-05', name: '⭐ Classic Star Aura', rarity: 'Common', previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150', isEnabled: true, activeUsersCount: 34100, isAnimated: false }
];

let serverHostEarningsLedger: any[] = [
  {
    id: 'HL-TX-001',
    transactionId: 'TX-GFT-9912',
    senderId: 'USR-882941',
    senderName: 'Aarav Mehta (VIP 8)',
    receiverHostId: 'HST-901',
    receiverHostName: 'Anya Sharma (DJ Anya)',
    giftId: 'g4',
    giftName: 'Lucky Castle',
    giftIcon: '🏰',
    giftPrice: 100000,
    multiplier: 1,
    senderPrevBalance: 345000,
    senderNewBalance: 245000,
    hostEarningAmount: 75000,
    hostPrevEarnings: 1775000,
    hostNewEarnings: 1850000,
    sourceType: 'LUCKY_GIFT',
    timestamp: '2026-08-15 05:50:12 UTC',
    liveRoomId: 'ROOM-401',
    status: 'COMPLETED',
    TEST_MODE: true
  },
  {
    id: 'HL-TX-002',
    transactionId: 'TX-GFT-9908',
    senderId: 'USR-8001',
    senderName: 'Rohan Joshi',
    receiverHostId: 'HST-901',
    receiverHostName: 'Anya Sharma (DJ Anya)',
    giftId: 'g2',
    giftName: 'Super Rocket',
    giftIcon: '🚀',
    giftPrice: 50000,
    multiplier: 1,
    senderPrevBalance: 170000,
    senderNewBalance: 120000,
    hostEarningAmount: 37500,
    hostPrevEarnings: 1737500,
    hostNewEarnings: 1775000,
    sourceType: 'GIFT',
    timestamp: '2026-08-15 05:32:45 UTC',
    liveRoomId: 'ROOM-401',
    status: 'COMPLETED',
    TEST_MODE: true
  }
];

let serverHosts: Record<string, any> = {
  'HST-901': {
    id: 'HST-901',
    name: 'Anya Sharma (DJ Anya)',
    username: 'dj_anya_live',
    agencyId: 'AG-01',
    agencyName: 'Starlight Media Global',
    managerId: 'MGR-301',
    managerName: 'Rahul Verma',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 142000,
    giftsReceived: 28400,
    diamonds: 1850000,
    earningsUSD: 1850.00,
    totalLiveHours: 320,
    lastLive: '2026-08-15 05:55 UTC (NOW)',
    verificationStatus: 'Verified',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-401',
    bio: 'Electronic Music Producer & resident DIYO LIVE 4K DJ. Nightly synthwave and melodic techno sets.',
    hostTag: 'CELEBRATE',
    hostTypeId: 'HT-CELEBRATE',
    avatarFrameId: 'FRM-HT-01',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150',
    hostLevel: 9,
    xp: 88500,
    earningsWallet: {
      totalEarnedCoins: 1850000,
      availableEarnings: 1850000,
      pendingEarnings: 0,
      giftEarnings: 1520000,
      luckyGiftEarnings: 280000,
      redPacketEarnings: 50000,
      commissionRate: 75,
      history: [serverHostEarningsLedger[0], serverHostEarningsLedger[1]]
    }
  },
  'HST-902': {
    id: 'HST-902',
    name: 'Kavita Roy',
    username: 'kavita_esports',
    agencyId: 'AG-02',
    agencyName: 'Nexus Talent Network',
    managerId: 'MGR-302',
    managerName: 'Jessica Chen',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 89000,
    giftsReceived: 19500,
    diamonds: 1240000,
    earningsUSD: 1240.00,
    totalLiveHours: 245,
    lastLive: '2026-08-15 05:40 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'gaming',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-402',
    bio: 'Professional FPS Champion & Grandmaster. Daily tournament commentary and viewer custom lobbies.',
    hostTag: 'TALENT',
    hostTypeId: 'HT-TALENT',
    avatarFrameId: 'FRM-HT-02',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150',
    hostLevel: 8,
    xp: 64200,
    earningsWallet: {
      totalEarnedCoins: 1240000,
      availableEarnings: 1240000,
      pendingEarnings: 0,
      giftEarnings: 980000,
      luckyGiftEarnings: 210000,
      redPacketEarnings: 50000,
      commissionRate: 70,
      history: []
    }
  },
  'HST-903': {
    id: 'HST-903',
    name: 'Devansh Kapoor',
    username: 'devansh_singer',
    agencyId: 'AG-01',
    agencyName: 'Starlight Media Global',
    managerId: 'MGR-301',
    managerName: 'Rahul Verma',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 210000,
    giftsReceived: 42000,
    diamonds: 2900000,
    earningsUSD: 2900.00,
    totalLiveHours: 410,
    lastLive: '2026-08-15 05:50 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-403',
    bio: 'Live acoustic sessions, vocal impressions, and Bollywood fusion vocalist.',
    hostTag: 'SINGER',
    hostTypeId: 'HT-SINGER',
    avatarFrameId: 'FRM-HT-03',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150',
    hostLevel: 10,
    xp: 145000,
    earningsWallet: {
      totalEarnedCoins: 2900000,
      availableEarnings: 2900000,
      pendingEarnings: 0,
      giftEarnings: 2400000,
      luckyGiftEarnings: 400000,
      redPacketEarnings: 100000,
      commissionRate: 70,
      history: []
    }
  },
  'HST-904': {
    id: 'HST-904',
    name: 'Meera Patel',
    username: 'meera_tech_space',
    agencyId: 'AG-02',
    agencyName: 'Nexus Talent Network',
    managerId: 'MGR-302',
    managerName: 'Jessica Chen',
    status: 'Active',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 67000,
    giftsReceived: 11200,
    diamonds: 780000,
    earningsUSD: 780.00,
    totalLiveHours: 180,
    lastLive: '2026-08-14 20:30 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'tech',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    bio: 'Aerospace engineer exploring next-generation AI breakthroughs and space launches.',
    hostTag: 'NORMAL',
    hostTypeId: 'HT-NORMAL',
    avatarFrameId: 'FRM-HT-04',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150',
    hostLevel: 6,
    xp: 32000,
    earningsWallet: {
      totalEarnedCoins: 780000,
      availableEarnings: 780000,
      pendingEarnings: 0,
      giftEarnings: 620000,
      luckyGiftEarnings: 120000,
      redPacketEarnings: 40000,
      commissionRate: 65,
      history: []
    }
  },
  'HST-905': {
    id: 'HST-905',
    name: 'Rohan Joshi',
    username: 'rohan_acoustic',
    agencyId: 'AG-03',
    agencyName: 'Apex Gaming Guild',
    managerId: 'MGR-301',
    managerName: 'Rahul Verma',
    status: 'Pending',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 1200,
    giftsReceived: 80,
    diamonds: 4500,
    earningsUSD: 4.50,
    totalLiveHours: 12,
    lastLive: '2026-08-10 14:00 UTC',
    verificationStatus: 'Pending',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&auto=format&fit=crop&q=80',
    bio: 'Acoustic indie guitarist and songwriter applying for official verified broadcaster status.',
    hostTag: 'SINGER',
    hostTypeId: 'HT-SINGER',
    avatarFrameId: 'FRM-HT-03',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150',
    hostLevel: 2,
    xp: 4500,
    earningsWallet: {
      totalEarnedCoins: 4500,
      availableEarnings: 4500,
      pendingEarnings: 0,
      giftEarnings: 4500,
      luckyGiftEarnings: 0,
      redPacketEarnings: 0,
      commissionRate: 70,
      history: []
    }
  },
  'HST-906': {
    id: 'HST-906',
    name: 'Zack Thorne',
    username: 'zack_shadow',
    agencyId: 'AG-04',
    agencyName: 'Solaris Entertainment',
    managerId: 'MGR-303',
    managerName: 'Carlos Fernandez',
    status: 'Banned',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 15400,
    giftsReceived: 3200,
    diamonds: 180000,
    earningsUSD: 180.00,
    totalLiveHours: 65,
    lastLive: '2026-07-20 18:00 UTC',
    verificationStatus: 'Rejected',
    streamCategory: 'gaming',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    bio: 'Account permanently suspended due to repeated copyright infringement and TOS violation.',
    hostTag: 'TALENT',
    hostTypeId: 'HT-TALENT',
    avatarFrameId: 'FRM-HT-02',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150',
    hostLevel: 4,
    xp: 18000,
    earningsWallet: {
      totalEarnedCoins: 180000,
      availableEarnings: 180000,
      pendingEarnings: 0,
      giftEarnings: 150000,
      luckyGiftEarnings: 30000,
      redPacketEarnings: 0,
      commissionRate: 70,
      history: []
    }
  }
};

// ==========================================
// HOST TYPES & FRAMES REST ENDPOINTS
// ==========================================
app.get("/api/host-types", (req, res) => {
  res.json({
    success: true,
    hostTypes: serverHostTypes,
    hostsCountByType: {
      CELEBRATE: Object.values(serverHosts).filter(h => h.hostTag === 'CELEBRATE').length,
      TALENT: Object.values(serverHosts).filter(h => h.hostTag === 'TALENT').length,
      SINGER: Object.values(serverHosts).filter(h => h.hostTag === 'SINGER').length,
      NORMAL: Object.values(serverHosts).filter(h => h.hostTag === 'NORMAL' || !h.hostTag).length
    }
  });
});

app.post("/api/host-types/toggle", (req, res) => {
  const { tagId, isEnabled } = req.body;
  const hostType = serverHostTypes.find(t => t.id === tagId || t.tag === tagId);
  if (!hostType) {
    return res.status(404).json({ success: false, error: "Host Type not found." });
  }

  hostType.isEnabled = Boolean(isEnabled);
  hostType.status = hostType.isEnabled ? 'Active' : 'Disabled';

  res.json({
    success: true,
    message: `${hostType.name} is now ${hostType.status}.`,
    hostType,
    hostTypes: serverHostTypes
  });
});

app.post("/api/host-types/update", (req, res) => {
  const { tagId, name, tagLabel, commissionRateDefault, entryEffect, description } = req.body;
  const hostType = serverHostTypes.find(t => t.id === tagId || t.tag === tagId);
  if (!hostType) {
    return res.status(404).json({ success: false, error: "Host Type not found." });
  }

  if (name) hostType.name = name;
  if (tagLabel) hostType.tagLabel = tagLabel;
  if (commissionRateDefault !== undefined) hostType.commissionRateDefault = Number(commissionRateDefault);
  if (entryEffect) hostType.entryEffect = entryEffect;
  if (description) hostType.description = description;

  res.json({
    success: true,
    message: `${hostType.name} configuration updated successfully.`,
    hostType,
    hostTypes: serverHostTypes
  });
});

app.get("/api/hosts", (req, res) => {
  res.json({
    success: true,
    hosts: Object.values(serverHosts)
  });
});

app.post("/api/hosts/assign-type", (req, res) => {
  const { hostId, hostTag, operatorRole = 'OWNER' } = req.body;
  if (operatorRole !== 'OWNER' && operatorRole !== 'SUPER_ADMIN' && operatorRole !== 'ADMIN') {
    return res.status(403).json({ success: false, error: "Unauthorized: Only Owner or Admin can assign Host Types." });
  }

  const host = serverHosts[hostId];
  if (!host) {
    return res.status(404).json({ success: false, error: `Host ${hostId} not found.` });
  }

  const validTags = ['CELEBRATE', 'TALENT', 'SINGER', 'NORMAL'];
  if (!validTags.includes(hostTag)) {
    return res.status(400).json({ success: false, error: `Invalid host tag. Must be one of: ${validTags.join(', ')}` });
  }

  const typeDef = serverHostTypes.find(t => t.tag === hostTag);
  host.hostTag = hostTag;
  host.hostTypeId = typeDef?.id || `HT-${hostTag}`;
  if (typeDef?.frameId) {
    host.avatarFrameId = typeDef.frameId;
    const frameObj = serverHostFrames.find(f => f.id === typeDef.frameId);
    if (frameObj) host.avatarFrameUrl = frameObj.previewUrl;
  }
  if (host.earningsWallet && typeDef?.commissionRateDefault) {
    host.earningsWallet.commissionRate = typeDef.commissionRateDefault;
  }

  res.json({
    success: true,
    message: `Host ${host.name} assigned to "${hostTag}" type with exclusive frame and badges.`,
    host,
    hosts: Object.values(serverHosts)
  });
});

app.post("/api/hosts/assign-frame", (req, res) => {
  const { hostId, frameId, operatorRole = 'OWNER' } = req.body;
  if (operatorRole !== 'OWNER' && operatorRole !== 'SUPER_ADMIN' && operatorRole !== 'ADMIN') {
    return res.status(403).json({ success: false, error: "Unauthorized: Only Owner or Admin can assign avatar frames." });
  }

  const host = serverHosts[hostId];
  if (!host) {
    return res.status(404).json({ success: false, error: `Host ${hostId} not found.` });
  }

  const frame = serverHostFrames.find(f => f.id === frameId);
  if (!frame) {
    return res.status(404).json({ success: false, error: `Frame ${frameId} not found.` });
  }

  host.avatarFrameId = frame.id;
  host.avatarFrameUrl = frame.previewUrl;

  res.json({
    success: true,
    message: `Frame "${frame.name}" assigned to host ${host.name}.`,
    host,
    hosts: Object.values(serverHosts)
  });
});

app.get("/api/host-earnings/all", (req, res) => {
  const summary = {
    totalHosts: Object.keys(serverHosts).length,
    totalCoinsEarned: Object.values(serverHosts).reduce((sum, h) => sum + (h.earningsWallet?.totalEarnedCoins || 0), 0),
    totalAvailableEarnings: Object.values(serverHosts).reduce((sum, h) => sum + (h.earningsWallet?.availableEarnings || 0), 0),
    totalPendingEarnings: 0,
    totalTransactions: serverHostEarningsLedger.length,
    cashWithdrawalStatus: "DISABLED_TEST_MODE",
    testNotice: "TEST MODE — Cash withdrawal is currently disabled. All balances are virtual TEST COINS with no real-world cash value."
  };

  res.json({
    success: true,
    summary,
    ledger: serverHostEarningsLedger,
    hosts: Object.values(serverHosts).map(h => ({
      id: h.id,
      name: h.name,
      username: h.username,
      hostTag: h.hostTag || 'NORMAL',
      agencyName: h.agencyName,
      managerName: h.managerName,
      followers: h.followers,
      giftsReceived: h.giftsReceived,
      totalLiveHours: h.totalLiveHours,
      earningsWallet: h.earningsWallet,
      avatar: h.avatar,
      avatarFrameUrl: h.avatarFrameUrl
    }))
  });
});

app.get("/api/host-earnings/ledger", (req, res) => {
  res.json({
    success: true,
    ledger: serverHostEarningsLedger || []
  });
});

app.get("/api/host-earnings/:hostId", (req, res) => {
  const host = serverHosts[req.params.hostId];
  if (!host) {
    return res.status(404).json({ success: false, error: "Host not found." });
  }

  res.json({
    success: true,
    hostId: host.id,
    hostName: host.name,
    hostTag: host.hostTag || 'NORMAL',
    earningsWallet: host.earningsWallet || {
      totalEarnedCoins: 0,
      availableEarnings: 0,
      pendingEarnings: 0,
      giftEarnings: 0,
      luckyGiftEarnings: 0,
      redPacketEarnings: 0,
      commissionRate: 70,
      history: []
    },
    testNotice: "TEST MODE — Cash withdrawal is currently disabled. All balances are virtual TEST COINS."
  });
});

app.get("/api/host-frames", (req, res) => {
  res.json({
    success: true,
    frames: serverHostFrames
  });
});

app.post("/api/host-frames/toggle", (req, res) => {
  const { frameId, isEnabled } = req.body;
  const frame = serverHostFrames.find(f => f.id === frameId);
  if (!frame) {
    return res.status(404).json({ success: false, error: "Frame not found." });
  }

  frame.isEnabled = Boolean(isEnabled);
  res.json({
    success: true,
    message: `Frame ${frame.name} is now ${frame.isEnabled ? 'Enabled' : 'Disabled'}.`,
    frame,
    frames: serverHostFrames
  });
});

// ==========================================
// ATOMIC GIFT SENDING & HOST EARNINGS TRANSACTION
// ==========================================
app.post("/api/gifts/send", (req, res) => {
  const {
    senderId = 'USR-882941',
    target = 'Self',
    targetUserId,
    targetHostId,
    giftId = 'g1',
    giftName = 'Virtual Gift',
    giftIcon = '🎁',
    multiplier = 1,
    totalCost = 1000,
    reward = 0,
    roomType = 'PARTY_LIVE',
    seatNumber,
    liveRoomId = 'ROOM-401'
  } = req.body;

  const cost = Math.max(0, Number(totalCost) || 0);
  const mult = Math.max(1, Number(multiplier) || 1);
  const luckyReward = Math.max(0, Number(reward) || 0);

  // 1. Get or create sender in serverUsers
  let sender = serverUsers[senderId];
  if (!sender) {
    sender = {
      id: senderId,
      name: `User ${senderId}`,
      username: `user_${senderId.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 245000,
      diamondBalance: 18500,
      vipLevel: 8,
      status: 'Active'
    };
    serverUsers[senderId] = sender;
  }

  // 2. Validate sender balance
  if (sender.coinBalance < cost) {
    return res.status(400).json({
      success: false,
      error: `Insufficient TEST COINS! Cost: ${cost.toLocaleString()} TC, Available: ${sender.coinBalance.toLocaleString()} TC.`
    });
  }

  // 3. Normalized identifiers
  const normalizedTarget = String(target).trim().toLowerCase();
  const normalizedSenderId = String(sender.id).trim().toLowerCase();
  const normalizedSenderName = String(sender.name).trim().toLowerCase();

  const isSelfGift = 
    normalizedTarget === 'self' ||
    normalizedTarget.includes('self') ||
    normalizedTarget === normalizedSenderId ||
    normalizedTarget === normalizedSenderName ||
    targetUserId === sender.id;

  const prevSenderBalance = sender.coinBalance;
  const newSenderBalance = Math.max(0, prevSenderBalance - cost + luckyReward);
  sender.coinBalance = newSenderBalance;

  const nowTimestamp = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const txId = `TX-GFT-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

  // Calculate sender withdrawable diamonds earned from sending gifts (1:1 conversion + lucky bonus)
  const diamondRate = serverWalletSettings?.coinToDiamondRate || 1.0;
  let senderDiamondsAwarded = Math.floor(cost * diamondRate);
  if (luckyReward > 0) {
    senderDiamondsAwarded += Math.floor(luckyReward * 0.25);
  }
  sender.diamondBalance = (sender.diamondBalance || 0) + senderDiamondsAwarded;

  // ==========================================
  // Case A: SELF-GIFT
  // ==========================================
  if (isSelfGift) {
    const selfTx: ServerWalletTx = {
      id: txId,
      userId: sender.id,
      userName: sender.name,
      senderId: sender.id,
      senderName: sender.name,
      receiverId: sender.id,
      recipientName: sender.name,
      type: 'SELF_GIFT_RECEIVED',
      amountCoins: -cost + luckyReward,
      amountDiamonds: senderDiamondsAwarded,
      previousBalance: prevSenderBalance,
      newBalance: sender.coinBalance,
      timestamp: nowTimestamp,
      status: 'Completed',
      notes: `🎁 Self-Gift: Sent ${mult}x ${giftName} to Self (+${senderDiamondsAwarded.toLocaleString()} 💎 to Withdrawable Wallet)`,
      TEST_MODE: true
    };
    serverWalletTransactions.unshift(selfTx);

    return res.json({
      success: true,
      isSelfGift: true,
      senderBalance: sender.coinBalance,
      senderDiamonds: sender.diamondBalance,
      diamondsEarned: senderDiamondsAwarded,
      transaction: selfTx,
      message: `🎉 Self-Gift Success! Converted ${cost.toLocaleString()} Coins into +${senderDiamondsAwarded.toLocaleString()} Withdrawable Diamonds!`
    });
  }

  // ==========================================
  // Case B: GIFT TO HOST (CRITICAL REQUIREMENT: HOST EARNINGS WALLET)
  // ==========================================
  // Identify host if target is a host ID, host name, or 'Host (Seat 1)' / live room broadcaster
  let hostTarget: any = null;
  if (targetHostId && serverHosts[targetHostId]) {
    hostTarget = serverHosts[targetHostId];
  } else {
    // Search serverHosts by ID or Name
    hostTarget = Object.values(serverHosts).find(
      h => h.id.toLowerCase() === normalizedTarget ||
           h.name.toLowerCase() === normalizedTarget ||
           h.username.toLowerCase() === normalizedTarget ||
           normalizedTarget.includes(h.name.toLowerCase()) ||
           normalizedTarget.includes('host') ||
           normalizedTarget.includes('seat 1')
    );
  }

  // Fallback to default active host if sending to room host
  if (!hostTarget && (normalizedTarget.includes('host') || normalizedTarget.includes('dj') || normalizedTarget.includes('anya'))) {
    hostTarget = serverHosts['HST-901'];
  }

  if (hostTarget) {
    // Determine Host Commission (default 70% or configured on host/type)
    const commRate = (hostTarget.earningsWallet?.commissionRate || 70) / 100;
    const hostEarningAmount = Math.floor(cost * commRate);

    // Initialize Host Earnings Wallet if missing
    if (!hostTarget.earningsWallet) {
      hostTarget.earningsWallet = {
        totalEarnedCoins: 0,
        availableEarnings: 0,
        pendingEarnings: 0,
        giftEarnings: 0,
        luckyGiftEarnings: 0,
        redPacketEarnings: 0,
        commissionRate: Math.round(commRate * 100),
        history: []
      };
    }

    const hostPrevEarnings = hostTarget.earningsWallet.totalEarnedCoins || 0;
    const hostNewEarnings = hostPrevEarnings + hostEarningAmount;

    // Atomically credit Host Earnings Wallet
    hostTarget.earningsWallet.totalEarnedCoins = hostNewEarnings;
    hostTarget.earningsWallet.availableEarnings = (hostTarget.earningsWallet.availableEarnings || 0) + hostEarningAmount;
    
    const isLuckyGift = giftId?.toLowerCase().includes('lck') || giftId === 'g1' || giftId === 'g2' || giftId === 'g4' || giftId === 'g6';
    const isRedPacket = giftId?.toLowerCase().includes('red') || giftId === 'g8';

    if (isLuckyGift) {
      hostTarget.earningsWallet.luckyGiftEarnings = (hostTarget.earningsWallet.luckyGiftEarnings || 0) + hostEarningAmount;
    } else if (isRedPacket) {
      hostTarget.earningsWallet.redPacketEarnings = (hostTarget.earningsWallet.redPacketEarnings || 0) + hostEarningAmount;
    } else {
      hostTarget.earningsWallet.giftEarnings = (hostTarget.earningsWallet.giftEarnings || 0) + hostEarningAmount;
    }

    hostTarget.giftsReceived = (hostTarget.giftsReceived || 0) + mult;
    hostTarget.diamonds = hostNewEarnings; // Sync diamonds counter
    hostTarget.xp = (hostTarget.xp || 0) + cost;
    hostTarget.hostLevel = Math.min(10, 1 + Math.floor((hostTarget.xp || 0) / 15000));

    // Record Host Earnings Ledger Entry
    const hostLedgerEntry = {
      id: `HL-TX-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      transactionId: txId,
      senderId: sender.id,
      senderName: sender.name,
      receiverHostId: hostTarget.id,
      receiverHostName: hostTarget.name,
      giftId,
      giftName,
      giftIcon,
      giftPrice: cost,
      multiplier: mult,
      senderPrevBalance: prevSenderBalance,
      senderNewBalance: sender.coinBalance,
      hostEarningAmount,
      hostPrevEarnings,
      hostNewEarnings,
      sourceType: isLuckyGift ? 'LUCKY_GIFT' : isRedPacket ? 'RED_PACKET' : 'GIFT',
      timestamp: nowTimestamp,
      liveRoomId: hostTarget.liveRoomId || liveRoomId,
      status: 'COMPLETED',
      TEST_MODE: true
    };

    hostTarget.earningsWallet.history.unshift(hostLedgerEntry);
    serverHostEarningsLedger.unshift(hostLedgerEntry);

    // Record standard wallet tx
    const senderTx: ServerWalletTx = {
      id: txId,
      userId: sender.id,
      userName: sender.name,
      senderId: sender.id,
      senderName: sender.name,
      receiverId: hostTarget.id,
      recipientName: hostTarget.name,
      type: 'GIFT_SENT_TO_HOST',
      amountCoins: -cost + luckyReward,
      amountDiamonds: senderDiamondsAwarded,
      previousBalance: prevSenderBalance,
      newBalance: sender.coinBalance,
      timestamp: nowTimestamp,
      status: 'Completed',
      notes: `🎁 Sent ${mult}x ${giftName} to Host ${hostTarget.name} (+${senderDiamondsAwarded.toLocaleString()} 💎 to Withdrawable Wallet)`,
      TEST_MODE: true
    };
    serverWalletTransactions.unshift(senderTx);

    return res.json({
      success: true,
      isSelfGift: false,
      isHostGift: true,
      hostId: hostTarget.id,
      hostName: hostTarget.name,
      hostTag: hostTarget.hostTag || 'NORMAL',
      hostEarningAmount,
      hostTotalEarnings: hostNewEarnings,
      senderBalance: sender.coinBalance,
      senderDiamonds: sender.diamondBalance,
      diamondsEarned: senderDiamondsAwarded,
      transaction: senderTx,
      hostLedgerEntry,
      message: `🎁 Sent ${mult}x ${giftName} to Host ${hostTarget.name}! +${senderDiamondsAwarded.toLocaleString()} 💎 added to Withdrawable Wallet!`
    });
  }

  // ==========================================
  // Case C: GIFT TO ANOTHER USER
  // ==========================================
  let receiverId = targetUserId || 'USR-8002';
  let receiver = serverUsers[receiverId] || {
    id: receiverId,
    name: target || 'User',
    username: target ? target.toLowerCase().replace(/\s+/g, '_') : 'user',
    coinBalance: 50000,
    diamondBalance: 10000,
    vipLevel: 5,
    status: 'Active'
  };
  serverUsers[receiverId] = receiver;

  const userEarnedDiamonds = Math.floor(cost * (serverWalletSettings?.coinToDiamondRate || 1.0));
  receiver.diamondBalance = (receiver.diamondBalance || 0) + userEarnedDiamonds;

  const giftTx: ServerWalletTx = {
    id: txId,
    userId: sender.id,
    userName: sender.name,
    senderId: sender.id,
    senderName: sender.name,
    receiverId: receiver.id,
    recipientName: receiver.name,
    type: 'GIFT_SENT',
    amountCoins: -cost + luckyReward,
    amountDiamonds: senderDiamondsAwarded,
    previousBalance: prevSenderBalance,
    newBalance: sender.coinBalance,
    timestamp: nowTimestamp,
    status: 'Completed',
    notes: `🎁 Sent ${mult}x ${giftName} to ${receiver.name} (+${senderDiamondsAwarded.toLocaleString()} 💎 to Withdrawable Wallet)`,
    TEST_MODE: true
  };
  serverWalletTransactions.unshift(giftTx);

  return res.json({
    success: true,
    isSelfGift: false,
    senderBalance: sender.coinBalance,
    senderDiamonds: sender.diamondBalance,
    diamondsEarned: senderDiamondsAwarded,
    receiverId: receiver.id,
    receiverName: receiver.name,
    transaction: giftTx,
    message: `🎁 Sent ${mult}x ${giftName} to ${receiver.name}! +${senderDiamondsAwarded.toLocaleString()} 💎 added to Withdrawable Wallet!`
  });
});


// ==========================================
// 4.10 LEVEL SETTINGS ENDPOINTS (1–100)
// ==========================================
app.get("/api/levels/settings", (req, res) => {
  res.json({
    success: true,
    settings: serverLevelSettings
  });
});

app.post("/api/levels/settings", (req, res) => {
  const { baseXpMultiplier, growthRate, xpPerCoinSpent } = req.body;
  if (baseXpMultiplier !== undefined) serverLevelSettings.baseXpMultiplier = Number(baseXpMultiplier);
  if (growthRate !== undefined) serverLevelSettings.growthRate = Number(growthRate);
  if (xpPerCoinSpent !== undefined) serverLevelSettings.xpPerCoinSpent = Number(xpPerCoinSpent);

  res.json({
    success: true,
    message: "Level progression configuration updated.",
    settings: serverLevelSettings
  });
});


let serverCasinoTransactions: ServerCasinoTx[] = [
  {
    id: 'CTX-DICE-1001',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    gameId: 'GM-09',
    gameName: 'DiceRolling',
    category: 'Dice',
    bet: 10000,
    result: 'Dice: [4, 5] Sum: 9 (Target: OVER_7)',
    reward: 20000,
    multiplier: 2.0,
    outcome: 'WIN',
    previousBalance: 100000000,
    newBalance: 100010000,
    timestamp: new Date(Date.now() - 1000 * 60 * 3).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: 97.5,
    isTestMode: true,
    TEST_MODE: true
  },
  {
    id: 'CTX-SLOT-1002',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    gameId: 'GM-01',
    gameName: 'OlympusSlot',
    category: 'Slots',
    bet: 50000,
    result: 'Zeus Lightning 4.5x Scatter',
    reward: 225000,
    multiplier: 4.5,
    outcome: 'WIN',
    previousBalance: 99950000,
    newBalance: 100175000,
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: 96.5,
    isTestMode: true,
    TEST_MODE: true
  },
  {
    id: 'CTX-CARD-1003',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    gameId: 'GM-02',
    gameName: 'TeenPattiPro',
    category: 'Cards',
    bet: 25000,
    result: 'Dealer Pair 10s vs High Card',
    reward: 0,
    multiplier: 0,
    outcome: 'LOSS',
    previousBalance: 100175000,
    newBalance: 100150000,
    timestamp: new Date(Date.now() - 1000 * 60 * 25).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: 97.2,
    isTestMode: true,
    TEST_MODE: true
  }
];

// 1. Authoritative Dice Roll Game Engine
app.post("/api/casino/dice/roll", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins, 
    betType = "OVER_7", 
    targetValue = 7,
    currentBalance = 100000000,
    rtpRate = 97.5 
  } = req.body;

  const bet = Number(betCoins);

  // Validate bet amount & enforce Owner Game Bet Settings
  if (!bet || isNaN(bet) || bet <= 0) {
    return res.status(400).json({ 
      success: false, 
      error: "Invalid bet amount. Bet must be greater than 0 TEST COINS." 
    });
  }

  if (serverGameBetSettings.enforceButtonsOnly && !serverGameBetSettings.allowedBetButtons.includes(bet)) {
    return res.status(400).json({
      success: false,
      error: `Bet amount ${bet.toLocaleString()} TEST COINS is not allowed. Allowed presets: ${serverGameBetSettings.allowedBetButtons.map(b => `${(b >= 1000 ? `${b/1000}K` : b)}`).join(', ')} TEST COINS.`
    });
  }

  if (bet < serverGameBetSettings.minBet || bet > serverGameBetSettings.maxBet) {
    return res.status(400).json({
      success: false,
      error: `Bet must be between ${serverGameBetSettings.minBet.toLocaleString()} and ${serverGameBetSettings.maxBet.toLocaleString()} TEST COINS.`
    });
  }

  // Server-side balance verification
  if (currentBalance < bet) {
    return res.status(400).json({ 
      success: false, 
      error: "Insufficient TEST COIN balance! Please recharge test coins in your Wallet." 
    });
  }

  // Authoritative Server-side Random Number Generation (1-6 for each dice)
  const dice1 = Math.floor(Math.random() * 6) + 1;
  const dice2 = Math.floor(Math.random() * 6) + 1;
  const sum = dice1 + dice2;
  const isDoubles = dice1 === dice2;

  let isWin = false;
  let multiplier = 0;

  // Evaluate win logic based on selected bet target
  switch (betType) {
    case 'UNDER_7':
      if (sum < 7) {
        isWin = true;
        multiplier = 2.0;
      }
      break;

    case 'OVER_7':
      if (sum > 7) {
        isWin = true;
        multiplier = 2.0;
      }
      break;

    case 'EXACT_7':
      if (sum === 7) {
        isWin = true;
        multiplier = 5.8;
      }
      break;

    case 'EVEN':
      if (sum % 2 === 0) {
        isWin = true;
        multiplier = 1.96;
      }
      break;

    case 'ODD':
      if (sum % 2 !== 0) {
        isWin = true;
        multiplier = 1.96;
      }
      break;

    case 'DOUBLES':
      if (isDoubles) {
        isWin = true;
        multiplier = 5.5;
      }
      break;

    case 'EXACT_SUM':
      if (sum === Number(targetValue)) {
        isWin = true;
        // Exact sum multipliers based on probability
        const sumMultipliers: Record<number, number> = {
          2: 30.0, 12: 30.0,
          3: 15.0, 11: 15.0,
          4: 10.0, 10: 10.0,
          5: 7.0,   9: 7.0,
          6: 5.5,   8: 5.5,
          7: 5.8
        };
        multiplier = sumMultipliers[Number(targetValue)] || 5.0;
      }
      break;

    default:
      if (sum > 7) {
        isWin = true;
        multiplier = 2.0;
      }
      break;
  }

  // Calculate virtual reward
  const reward = isWin ? Math.floor(bet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  const txId = `CTX-DICE-${Math.floor(100000 + Math.random() * 900000)}`;
  const resultDescription = `Dice: [${dice1}, ${dice2}] = Sum ${sum} (${betType}${betType === 'EXACT_SUM' ? ` ${targetValue}` : ''})`;

  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-09',
    gameName: 'DiceRolling',
    category: 'Dice',
    bet,
    result: resultDescription,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: Number(rtpRate),
    isTestMode: true,
    TEST_MODE: true
  };

  // Record in server-side transaction ledger
  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) {
    serverCasinoTransactions.pop();
  }

  res.json({
    success: true,
    dice1,
    dice2,
    sum,
    isDoubles,
    outcome: isWin ? 'WIN' : 'LOSS',
    multiplier: isWin ? multiplier : 0,
    reward,
    bet,
    previousBalance,
    newBalance,
    transaction: tx,
    message: isWin 
      ? `🎉 WIN! Dice landed on [${dice1}, ${dice2}] Sum ${sum}. Won +${reward.toLocaleString()} TEST COINS!`
      : `💥 LOSS. Dice landed on [${dice1}, ${dice2}] Sum ${sum}. Deducted ${bet.toLocaleString()} TEST COINS.`
  });
});

// 2. Play Generic Casino TEST round (Slots, Cards, Fishing, Arcade, etc.)
app.post("/api/casino/play", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    gameId = "GM-01", 
    gameName = "Casino Game", 
    category = "Slots", 
    betCoins, 
    currentBalance = 100000000, 
    rtpRate = 96.5 
  } = req.body;

  const bet = Number(betCoins);

  if (!bet || isNaN(bet) || bet <= 0) {
    return res.status(400).json({ success: false, error: "Invalid test bet amount" });
  }

  if (serverGameBetSettings.enforceButtonsOnly && !serverGameBetSettings.allowedBetButtons.includes(bet)) {
    return res.status(400).json({
      success: false,
      error: `Bet amount ${bet.toLocaleString()} TEST COINS is not allowed. Allowed presets: ${serverGameBetSettings.allowedBetButtons.map(b => `${(b >= 1000 ? `${b/1000}K` : b)}`).join(', ')} TEST COINS.`
    });
  }

  if (bet < serverGameBetSettings.minBet || bet > serverGameBetSettings.maxBet) {
    return res.status(400).json({
      success: false,
      error: `Bet must be between ${serverGameBetSettings.minBet.toLocaleString()} and ${serverGameBetSettings.maxBet.toLocaleString()} TEST COINS.`
    });
  }

  if (currentBalance < bet) {
    return res.status(400).json({ 
      success: false, 
      error: "Insufficient TEST COIN balance! Please recharge test coins in your Wallet." 
    });
  }

  // Calculate outcome based on configured RTP
  const effectiveRtp = Math.max(80, Math.min(99, Number(rtpRate)));
  const winProb = (effectiveRtp / 100) * 0.48;
  const isWin = Math.random() < winProb;

  let multiplier = 0;
  let reward = 0;

  if (isWin) {
    // Generate realistic multiplier distribution
    const rand = Math.random();
    if (rand < 0.65) {
      multiplier = Number((1.2 + Math.random() * 1.8).toFixed(2)); // 1.2x - 3.0x
    } else if (rand < 0.90) {
      multiplier = Number((3.0 + Math.random() * 5.0).toFixed(2)); // 3.0x - 8.0x
    } else {
      multiplier = Number((8.0 + Math.random() * 25.0).toFixed(2)); // 8.0x - 33.0x Jackpot
    }
    reward = Math.floor(bet * multiplier);
  }

  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;
  const txId = `CTX-${gameId.replace('GM-', '')}-${Math.floor(100000 + Math.random() * 900000)}`;

  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId,
    gameName,
    category,
    bet,
    result: isWin ? `${multiplier}x Payout Win` : `Round Finished (No Hit)`,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? "WIN" : "LOSS",
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: effectiveRtp,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) {
    serverCasinoTransactions.pop();
  }

  res.json({
    success: true,
    outcome: isWin ? 'WIN' : 'LOSS',
    multiplier: isWin ? multiplier : 0,
    reward,
    bet,
    previousBalance,
    newBalance,
    transaction: tx,
    message: isWin 
      ? `🎉 BIG WIN! ${gameName} multiplier ${multiplier}x (+${reward.toLocaleString()} TEST COINS)`
      : `💥 Round completed. Bet ${bet.toLocaleString()} TEST COINS deducted.`
  });
});

// 3. Get Casino Transactions Ledger
app.get("/api/casino/transactions", (req, res) => {
  const { filter, gameId } = req.query;

  let filtered = [...serverCasinoTransactions];

  if (filter === 'WIN' || filter === 'LOSS') {
    filtered = filtered.filter(tx => tx.outcome === filter);
  }

  if (gameId && gameId !== 'All') {
    filtered = filtered.filter(tx => tx.gameId === gameId || tx.gameName.toLowerCase() === String(gameId).toLowerCase());
  }

  res.json({
    success: true,
    totalCount: filtered.length,
    transactions: filtered
  });
});

// 4. Reset TEST Game Data (Owner control)
app.post("/api/casino/reset", (req, res) => {
  serverCasinoTransactions = [
    {
      id: 'CTX-DICE-0001',
      userId: 'USR-882941',
      userName: 'Aarav Mehta',
      gameId: 'GM-09',
      gameName: 'DiceRolling',
      category: 'Dice',
      bet: 10000,
      result: 'Reset Initial Baseline',
      reward: 20000,
      multiplier: 2.0,
      outcome: 'WIN',
      previousBalance: 100000000,
      newBalance: 100010000,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      rtpSetting: 97.5,
      isTestMode: true,
      TEST_MODE: true
    }
  ];

  res.json({
    success: true,
    message: "TEST game transactions and statistics ledger reset successfully."
  });
});

// ==========================================
// 4.11 DEDICATED DIYO LIVE GAME CENTER BACKEND ENGINE
// ==========================================

interface ServerGameConfigItem {
  id: string;
  name: string;
  category: string;
  enabled: boolean;
  isFrozen: boolean;
  minBet: number;
  maxBet: number;
  allowedBets: number[];
  rtpRate: number;
  totalRounds: number;
  totalWagered: number;
  totalWon: number;
  suspiciousCount: number;
  description: string;
}

let serverGamesConfig: Record<string, ServerGameConfigItem> = {
  teen_patti: {
    id: 'teen_patti',
    name: 'Teen Patti Pro',
    category: 'Cards',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 100000,
    allowedBets: [1000, 2000, 5000, 10000, 20000, 30000, 50000, 100000],
    rtpRate: 97.2,
    totalRounds: 15420,
    totalWagered: 185040000,
    totalWon: 179858880,
    suspiciousCount: 0,
    description: '3-Card Poker with Live Table, Blind/Seen mode, Private Rooms, and Royal Showdowns.'
  },
  greedy_77: {
    id: 'greedy_77',
    name: 'Greedy 77 Slots',
    category: 'Slots',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 100000,
    allowedBets: [1000, 2000, 5000, 10000, 20000, 30000, 50000, 100000],
    rtpRate: 96.8,
    totalRounds: 42100,
    totalWagered: 421000000,
    totalWon: 407528000,
    suspiciousCount: 1,
    description: 'Classic 3-Reel Vegas Slot with 777 Jackpot, Gold Bars, Diamonds, and 777x Mega Multiplier.'
  },
  furut: {
    id: 'furut',
    name: 'Furut Party Wheel',
    category: 'Arcade',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 100000,
    allowedBets: [1000, 2000, 5000, 10000, 20000, 30000, 50000, 100000],
    rtpRate: 96.5,
    totalRounds: 28900,
    totalWagered: 289000000,
    totalWon: 278885000,
    suspiciousCount: 0,
    description: '8-Sector Neon Fruit Wheel with Watermelon, Cherry, Bell, and 100x Crown Jackpot.'
  },
  lucky_box: {
    id: 'lucky_box',
    name: 'Lucky Box Mystery',
    category: 'Mystery',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 50000,
    allowedBets: [1000, 5000, 20000, 50000],
    rtpRate: 98.0,
    totalRounds: 53200,
    totalWagered: 319200000,
    totalWon: 312816000,
    suspiciousCount: 0,
    description: 'Bronze, Silver, Gold, and Royal Diamond Mystery Boxes plus Daily Free Mystery Box.'
  },
  red_packet: {
    id: 'red_packet',
    name: 'Red Packet Wealth',
    category: 'Community',
    enabled: true,
    isFrozen: false,
    minBet: 5000,
    maxBet: 500000,
    allowedBets: [5000, 10000, 20000, 50000, 100000, 500000],
    rtpRate: 100.0,
    totalRounds: 9800,
    totalWagered: 196000000,
    totalWon: 196000000,
    suspiciousCount: 0,
    description: 'Peer-to-peer virtual coin red packets with lucky random grab and equal split.'
  },
  lava_game: {
    id: 'lava_game',
    name: 'Lava Game Multiplier',
    category: 'Crash & Multiplier',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000, 250000],
    rtpRate: 97.2,
    totalRounds: 18400,
    totalWagered: 184000000,
    totalWon: 178848000,
    suspiciousCount: 0,
    description: '10-Level Volcanic Tower Climb with up to 250x exponential safe cashout multipliers.'
  },
  slots: {
    id: 'slots',
    name: 'Vegas Royal 777 Slots',
    category: 'Slots',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000, 250000],
    rtpRate: 96.6,
    totalRounds: 34200,
    totalWagered: 342000000,
    totalWon: 330372000,
    suspiciousCount: 0,
    description: '5-Reel 25-Payline Vegas Slot with 10 Free Spins, Wild Stars, and 777x Grand Jackpots.'
  },
  tiger_game: {
    id: 'tiger_game',
    name: 'Dragon vs Tiger Fortune',
    category: 'Table Arena',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000],
    rtpRate: 97.5,
    totalRounds: 21900,
    totalWagered: 219000000,
    totalWon: 213525000,
    suspiciousCount: 0,
    description: 'Fast-paced Asian Arena Card Showdown with 2x Side payouts and 9x Tie Jackpot.'
  },
  mahjong: {
    id: 'mahjong',
    name: 'Mahjong Ways Cascade',
    category: 'Cascade & Tiles',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000, 250000],
    rtpRate: 96.9,
    totalRounds: 16800,
    totalWagered: 168000000,
    totalWon: 162792000,
    suspiciousCount: 0,
    description: '1024-Ways Cascading Mahjong with Gold Transforming Tiles and 10x Combo Multipliers.'
  },
  magic_slots: {
    id: 'magic_slots',
    name: 'Magic Slots Spellbook',
    category: 'Fantasy Slots',
    enabled: true,
    isFrozen: false,
    minBet: 1000,
    maxBet: 250000,
    allowedBets: [1000, 5000, 10000, 25000, 50000, 100000, 250000],
    rtpRate: 96.8,
    totalRounds: 19500,
    totalWagered: 195000000,
    totalWon: 188760000,
    suspiciousCount: 0,
    description: 'Mystic Archmage Spellbook with Arcane Free Spins and 1000x Max Mythic Payout.'
  }
};

// Daily Free Box Claims tracking by User ID: userId -> timestamp string
let serverDailyFreeBoxClaims: Record<string, string> = {};

// Helper: Evaluate 3-Card Teen Patti Hand Rank (Score higher is better)
function evaluateTeenPattiHand(cards: { suit: string; value: number; label: string }[]) {
  const vals = cards.map(c => c.value).sort((a, b) => a - b);
  const suits = cards.map(c => c.suit);
  const isFlush = suits[0] === suits[1] && suits[1] === suits[2];
  
  // Check sequence
  let isSequence = false;
  if (vals[2] - vals[1] === 1 && vals[1] - vals[0] === 1) isSequence = true;
  if (vals[0] === 2 && vals[1] === 3 && vals[2] === 14) isSequence = true; // A-2-3

  const isTrio = vals[0] === vals[1] && vals[1] === vals[2];
  const isPair = vals[0] === vals[1] || vals[1] === vals[2] || vals[0] === vals[2];

  let rankType = 'High Card';
  let rankScore = 100000 + vals[2] * 100 + vals[1] * 10 + vals[0];

  if (isTrio) {
    rankType = 'Trail (Set/Trio)';
    rankScore = 600000 + vals[0] * 100;
  } else if (isFlush && isSequence) {
    rankType = 'Pure Sequence';
    rankScore = 500000 + vals[2] * 100;
  } else if (isSequence) {
    rankType = 'Sequence';
    rankScore = 400000 + vals[2] * 100;
  } else if (isFlush) {
    rankType = 'Color (Flush)';
    rankScore = 300000 + vals[2] * 100 + vals[1] * 10 + vals[0];
  } else if (isPair) {
    rankType = 'Pair';
    const pairVal = (vals[0] === vals[1]) ? vals[0] : (vals[1] === vals[2] ? vals[1] : vals[0]);
    const kicker = (vals[0] === pairVal && vals[1] === pairVal) ? vals[2] : (vals[1] === pairVal && vals[2] === pairVal ? vals[0] : vals[1]);
    rankScore = 200000 + pairVal * 100 + kicker;
  }

  return { rankType, rankScore };
}

// 1. TEEN PATTI PLAY ENDPOINT (Server-Authoritative Multi-Hand)
app.post("/api/games/teen-patti/round", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    currentBalance = 100000000,
    actionType = "CHAAL", // "CHAAL", "SHOW", "BLIND"
    isPrivate = false,
    roomCode = ""
  } = req.body;

  const config = serverGamesConfig.teen_patti;
  if (!config.enabled || config.isFrozen) {
    return res.status(403).json({ success: false, error: "Teen Patti is temporarily under maintenance or disabled." });
  }

  const bet = Number(betCoins);
  if (!config.allowedBets.includes(bet)) {
    return res.status(400).json({ success: false, error: `Invalid bet amount. Allowed bets: ${config.allowedBets.map(b => `${b/1000}K`).join(', ')}` });
  }

  if (currentBalance < bet) {
    return res.status(400).json({ success: false, error: "Insufficient virtual coin balance! Please recharge virtual test coins." });
  }

  // Create Standard 52-Card Deck
  const suits = ['♠', '♥', '♦', '♣'];
  const values = [
    { value: 2, label: '2' }, { value: 3, label: '3' }, { value: 4, label: '4' }, { value: 5, label: '5' },
    { value: 6, label: '6' }, { value: 7, label: '7' }, { value: 8, label: '8' }, { value: 9, label: '9' },
    { value: 10, label: '10' }, { value: 11, label: 'J' }, { value: 12, label: 'Q' }, { value: 13, label: 'K' }, { value: 14, label: 'A' }
  ];
  const deck: { suit: string; value: number; label: string; id: string }[] = [];
  for (const s of suits) {
    for (const v of values) {
      deck.push({ suit: s, value: v.value, label: v.label, id: `${v.label}${s}` });
    }
  }

  // Fisher-Yates Shuffle with Cryptographic randomness
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  // Deal 3 cards to Player + 3 Opponents
  const playerHand = [deck.pop()!, deck.pop()!, deck.pop()!];
  const opp1Hand = [deck.pop()!, deck.pop()!, deck.pop()!]; // Vikram
  const opp2Hand = [deck.pop()!, deck.pop()!, deck.pop()!]; // Priya
  const opp3Hand = [deck.pop()!, deck.pop()!, deck.pop()!]; // Rahul

  const playerEval = evaluateTeenPattiHand(playerHand);
  const opp1Eval = evaluateTeenPattiHand(opp1Hand);
  const opp2Eval = evaluateTeenPattiHand(opp2Hand);
  const opp3Eval = evaluateTeenPattiHand(opp3Hand);

  // Determine highest scoring hand
  const allHands = [
    { name: userName || 'You', eval: playerEval, isUser: true },
    { name: 'Vikram', eval: opp1Eval, isUser: false },
    { name: 'Priya', eval: opp2Eval, isUser: false },
    { name: 'Rahul', eval: opp3Eval, isUser: false }
  ];
  allHands.sort((a, b) => b.eval.rankScore - a.eval.rankScore);

  const isWin = allHands[0].isUser;
  const potSize = bet * 4; // 4 seats pot
  const houseCommission = Math.floor(potSize * 0.05); // 5% house rake
  const winPayout = potSize - houseCommission;

  const reward = isWin ? winPayout : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  // Update Config Stats
  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-TP-${Math.floor(100000 + Math.random() * 900000)}`;
  const roundId = `RND-TP-${Date.now().toString().slice(-6)}`;
  const resultText = isWin 
    ? `Won Showdown with ${playerEval.rankType}! Beats ${allHands[1].name}'s ${allHands[1].eval.rankType}`
    : `Lost to ${allHands[0].name}'s ${allHands[0].eval.rankType} (Your hand: ${playerEval.rankType})`;

  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-02',
    gameName: 'Teen Patti Pro',
    category: 'Cards',
    bet,
    result: resultText,
    reward,
    multiplier: isWin ? Number((reward / bet).toFixed(2)) : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    roundId,
    transaction: tx,
    isWin,
    winnerName: allHands[0].name,
    playerHand,
    playerRank: playerEval.rankType,
    opponents: [
      { name: 'Vikram', hand: opp1Hand, rank: opp1Eval.rankType, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150' },
      { name: 'Priya', hand: opp2Hand, rank: opp2Eval.rankType, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150' },
      { name: 'Rahul', hand: opp3Hand, rank: opp3Eval.rankType, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150' }
    ],
    potSize,
    houseCommission,
    payout: reward,
    newBalance,
    isPrivate,
    roomCode: roomCode || 'ROOM-882'
  });
});

// 2. GREEDY 77 SLOTS SPIN ENDPOINT
app.post("/api/games/greedy-77/spin", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    currentBalance = 100000000 
  } = req.body;

  const config = serverGamesConfig.greedy_77;
  if (!config.enabled || config.isFrozen) {
    return res.status(403).json({ success: false, error: "Greedy 77 is temporarily under maintenance." });
  }

  const bet = Number(betCoins);
  if (!config.allowedBets.includes(bet)) {
    return res.status(400).json({ success: false, error: `Invalid bet. Allowed: ${config.allowedBets.map(b => `${b/1000}K`).join(', ')}` });
  }

  if (currentBalance < bet) {
    return res.status(400).json({ success: false, error: "Insufficient virtual coin balance!" });
  }

  // Symbol distribution: 777 (Jackpot), Gold 7, Diamond, Bar, Bell, Cherry, Blank
  const symbols = [
    { id: '777_JACKPOT', label: '777 🔥', mult3: 777, weight: 1 },
    { id: 'GOLD_7', label: '7 👑', mult3: 77, weight: 3 },
    { id: 'DIAMOND', label: '💎', mult3: 50, weight: 6 },
    { id: 'BAR', label: '🪙 BAR', mult3: 20, weight: 12 },
    { id: 'BELL', label: '🔔', mult3: 10, weight: 20 },
    { id: 'CHERRY', label: '🍒', mult3: 5, weight: 35 },
    { id: 'STAR', label: '⭐', mult3: 2, weight: 45 }
  ];

  // Weighted random pick
  const totalWeight = symbols.reduce((acc, s) => acc + s.weight, 0);
  function pickSymbol() {
    let rand = Math.random() * totalWeight;
    for (const s of symbols) {
      if (rand < s.weight) return s;
      rand -= s.weight;
    }
    return symbols[symbols.length - 1];
  }

  // Authoritative server RTP calculation
  const winChance = (config.rtpRate / 100) * 0.44;
  const isForcedWin = Math.random() < winChance;

  let reel1 = pickSymbol();
  let reel2 = pickSymbol();
  let reel3 = pickSymbol();

  if (isForcedWin) {
    // Pick winning combo based on distribution
    const winRand = Math.random();
    if (winRand < 0.005) {
      reel1 = reel2 = reel3 = symbols[0]; // 777x JACKPOT!
    } else if (winRand < 0.03) {
      reel1 = reel2 = reel3 = symbols[1]; // 77x
    } else if (winRand < 0.10) {
      reel1 = reel2 = reel3 = symbols[2]; // 50x
    } else if (winRand < 0.25) {
      reel1 = reel2 = reel3 = symbols[3]; // 20x
    } else if (winRand < 0.55) {
      reel1 = reel2 = reel3 = symbols[4]; // 10x
    } else {
      reel1 = reel2 = reel3 = symbols[5]; // 5x
    }
  }

  let multiplier = 0;
  let isWin = false;
  let winDescription = 'No Match';

  if (reel1.id === reel2.id && reel2.id === reel3.id) {
    multiplier = reel1.mult3;
    isWin = true;
    winDescription = `TRIPLE ${reel1.label}! (${multiplier}X Mega Payout)`;
  } else if (reel1.id === '777_JACKPOT' || reel2.id === '777_JACKPOT' || reel3.id === '777_JACKPOT') {
    multiplier = 2;
    isWin = true;
    winDescription = `Wild 777 Hit! (2X Payout)`;
  } else if (reel1.id === 'CHERRY' || reel2.id === 'CHERRY') {
    multiplier = 1.5;
    isWin = true;
    winDescription = `Cherry Match! (1.5X Payout)`;
  }

  const reward = isWin ? Math.floor(bet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-G77-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-03',
    gameName: 'Greedy 77 Slots',
    category: 'Slots',
    bet,
    result: `[${reel1.label} | ${reel2.label} | ${reel3.label}] - ${winDescription}`,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    reels: [reel1, reel2, reel3],
    isWin,
    multiplier,
    reward,
    winDescription,
    newBalance,
    transaction: tx
  });
});

// 3. FURUT (FRUIT PARTY WHEEL) SPIN ENDPOINT
app.post("/api/games/furut/spin", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    selectedSymbolId = "WATERMELON",
    currentBalance = 100000000 
  } = req.body;

  const config = serverGamesConfig.furut;
  if (!config.enabled || config.isFrozen) {
    return res.status(403).json({ success: false, error: "Furut Party Wheel is temporarily under maintenance." });
  }

  const bet = Number(betCoins);
  if (!config.allowedBets.includes(bet)) {
    return res.status(400).json({ success: false, error: `Invalid bet. Allowed: ${config.allowedBets.map(b => `${b/1000}K`).join(', ')}` });
  }

  if (currentBalance < bet) {
    return res.status(400).json({ success: false, error: "Insufficient virtual coin balance!" });
  }

  const fruitSectors = [
    { index: 0, id: 'CROWN', name: 'SR Crown', emoji: '👑', multiplier: 100, weight: 1 },
    { index: 1, id: 'CHERRY', name: 'Cherry', emoji: '🍒', multiplier: 2, weight: 35 },
    { index: 2, id: 'ORANGE', name: 'Orange', emoji: '🍊', multiplier: 5, weight: 20 },
    { index: 3, id: 'STRAWBERRY', name: 'Strawberry', emoji: '🍓', multiplier: 10, weight: 12 },
    { index: 4, id: 'LUCKY_77', name: 'Lucky 77', emoji: '🎰', multiplier: 50, weight: 2 },
    { index: 5, id: 'BELL', name: 'Golden Bell', emoji: '🔔', multiplier: 25, weight: 6 },
    { index: 6, id: 'GRAPE', name: 'Grape', emoji: '🍇', multiplier: 15, weight: 9 },
    { index: 7, id: 'WATERMELON', name: 'Watermelon', emoji: '🍉', multiplier: 20, weight: 7 }
  ];

  // Weighted wheel selection
  const totalWeight = fruitSectors.reduce((acc, f) => acc + f.weight, 0);
  let rand = Math.random() * totalWeight;
  let winningSector = fruitSectors[0];
  for (const s of fruitSectors) {
    if (rand < s.weight) {
      winningSector = s;
      break;
    }
    rand -= s.weight;
  }

  // Check if player selected the winning sector
  const isMatch = winningSector.id === selectedSymbolId;
  const isWin = isMatch;
  const multiplier = isWin ? winningSector.multiplier : 0;
  const reward = isWin ? Math.floor(bet * multiplier) : 0;

  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-FRT-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-05',
    gameName: 'Furut Party Wheel',
    category: 'Arcade',
    bet,
    result: `Landed on ${winningSector.emoji} ${winningSector.name} (${winningSector.multiplier}X) - Your Pick: ${selectedSymbolId}`,
    reward,
    multiplier,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    landingIndex: winningSector.index,
    winningSector,
    isWin,
    multiplier,
    reward,
    newBalance,
    transaction: tx
  });
});

// 4. LUCKY BOX OPEN ENDPOINT (Bronze, Silver, Gold, Royal Diamond & Daily Free)
app.post("/api/games/lucky-box/open", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    boxTier = "BRONZE", // "FREE", "BRONZE", "SILVER", "GOLD", "ROYAL_DIAMOND"
    currentBalance = 100000000 
  } = req.body;

  const config = serverGamesConfig.lucky_box;
  if (!config.enabled || config.isFrozen) {
    return res.status(403).json({ success: false, error: "Lucky Box system is temporarily under maintenance." });
  }

  const boxTiersConfig: Record<string, { cost: number; name: string; icon: string; minReward: number; maxReward: number; extraGift?: string }> = {
    FREE: { cost: 0, name: 'Daily Free Mystery Box', icon: '🎁', minReward: 500, maxReward: 3000 },
    BRONZE: { cost: 1000, name: 'Bronze Mystery Box', icon: '📦', minReward: 500, maxReward: 5000, extraGift: '🌹 Rose' },
    SILVER: { cost: 5000, name: 'Silver Fortune Box', icon: '🥈', minReward: 3000, maxReward: 25000, extraGift: '💖 Heart Confetti' },
    GOLD: { cost: 20000, name: 'Gold Emperor Box', icon: '🥇', minReward: 15000, maxReward: 100000, extraGift: '👑 Imperial Crown' },
    ROYAL_DIAMOND: { cost: 50000, name: 'Royal Diamond Vault Box', icon: '👑', minReward: 40000, maxReward: 500000, extraGift: '🐉 Golden Dragon' }
  };

  const selectedTier = boxTiersConfig[boxTier] || boxTiersConfig.BRONZE;
  const cost = selectedTier.cost;

  // Daily Free Box Check (24h cooldown)
  if (boxTier === 'FREE') {
    const lastClaim = serverDailyFreeBoxClaims[userId];
    if (lastClaim) {
      const lastTime = new Date(lastClaim).getTime();
      const now = Date.now();
      const elapsedHours = (now - lastTime) / (1000 * 60 * 60);
      if (elapsedHours < 24) {
        const remainingHours = Math.ceil(24 - elapsedHours);
        return res.status(400).json({ 
          success: false, 
          error: `Daily Free Box already claimed! Next free box available in ${remainingHours} hours.` 
        });
      }
    }
    serverDailyFreeBoxClaims[userId] = new Date().toISOString();
  } else {
    if (currentBalance < cost) {
      return res.status(400).json({ success: false, error: "Insufficient virtual coins to open this box!" });
    }
  }

  // Generate random reward
  const isJackpot = Math.random() < 0.08;
  let coinsWon = 0;
  if (isJackpot) {
    coinsWon = selectedTier.maxReward;
  } else {
    coinsWon = Math.floor(selectedTier.minReward + Math.random() * (selectedTier.maxReward - selectedTier.minReward));
  }

  // Round to nice hundreds
  coinsWon = Math.max(100, Math.floor(coinsWon / 100) * 100);

  const vipDaysReward = isJackpot ? (boxTier === 'ROYAL_DIAMOND' ? 7 : 3) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - cost + coinsWon;

  config.totalRounds += 1;
  config.totalWagered += cost;
  config.totalWon += coinsWon;

  const txId = `CTX-LBX-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-LBX',
    gameName: selectedTier.name,
    category: 'Mystery',
    bet: cost,
    result: `Unboxed ${coinsWon.toLocaleString()} TEST COINS ${vipDaysReward > 0 ? `+ ${vipDaysReward} VIP Days` : ''} ${selectedTier.extraGift ? `+ ${selectedTier.extraGift}` : ''}`,
    reward: coinsWon,
    multiplier: cost > 0 ? Number((coinsWon / cost).toFixed(2)) : 1,
    outcome: coinsWon >= cost ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    boxTier,
    boxName: selectedTier.name,
    coinsWon,
    vipDaysReward,
    extraGift: selectedTier.extraGift,
    isJackpot,
    cost,
    newBalance,
    transaction: tx,
    nextFreeAvailableAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
  });
});

// 5. GET ACTIVE RED PACKETS FEED
app.get("/api/games/red-packet/active", (req, res) => {
  res.json({
    success: true,
    packets: serverRedPackets.filter(p => p.status === 'ACTIVE' && !p.isExpired)
  });
});

// ==========================================
// 5.1 LAVA GAME (VOLCANIC CLIMB MULTIPLIER) ENDPOINTS
// ==========================================
app.post("/api/games/lava/start", (req, res) => {
  const { userId = "USR-882941", userName = "Aarav Mehta", betCoins = 10000 } = req.body;
  const config = serverGamesConfig.lava_game;
  config.totalRounds += 1;
  config.totalWagered += Number(betCoins);

  res.json({
    success: true,
    message: "Volcanic expedition started! Watch out for sudden eruptions.",
    currentStep: 0,
    multiplier: 1.0
  });
});

app.post("/api/games/lava/step", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    step = 1, 
    safeOdds = 0.9 
  } = req.body;

  const config = serverGamesConfig.lava_game;
  const bet = Number(betCoins);

  // Volcanic RNG
  const rand = Math.random();
  const erupted = rand >= Number(safeOdds);

  let tx: ServerCasinoTx | null = null;
  if (erupted) {
    const txId = `CTX-LAV-${Math.floor(100000 + Math.random() * 900000)}`;
    tx = {
      id: txId,
      userId,
      userName,
      gameId: 'GM-LAVA',
      gameName: 'Lava Game Multiplier',
      category: 'Crash & Multiplier',
      bet,
      result: `Erupted at Step ${step}`,
      reward: 0,
      multiplier: 0,
      outcome: 'LOSS',
      previousBalance: 0,
      newBalance: 0,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      rtpSetting: config.rtpRate,
      isTestMode: true,
      TEST_MODE: true
    };
    serverCasinoTransactions.unshift(tx);
    if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();
  }

  res.json({
    success: true,
    erupted,
    step,
    transaction: tx
  });
});

app.post("/api/games/lava/cashout", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    stepReached = 5, 
    multiplier = 4.8, 
    payout = 48000 
  } = req.body;

  const config = serverGamesConfig.lava_game;
  const bet = Number(betCoins);
  const reward = Number(payout);

  config.totalWon += reward;

  const txId = `CTX-LAV-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-LAVA',
    gameName: 'Lava Game Multiplier',
    category: 'Crash & Multiplier',
    bet,
    result: `Safe Cashout at Step ${stepReached} (${multiplier}X)`,
    reward,
    multiplier: Number(multiplier),
    outcome: 'WIN',
    previousBalance: 0,
    newBalance: reward,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };
  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    reward,
    multiplier,
    transaction: tx
  });
});

// ==========================================
// 5.2 VEGAS ROYAL 777 SLOTS (5-REEL 25-PAYLINE) ENDPOINT
// ==========================================
app.post("/api/games/slots/spin", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    isFreeSpin = false, 
    currentBalance = 1000000 
  } = req.body;

  const config = serverGamesConfig.slots;
  const bet = isFreeSpin ? 0 : Number(betCoins);

  const slotSymbols = ['7️⃣', '💎', '👑', '🪙', '🔔', '🍒', '⭐', '⚡'];
  
  // Generate 5x3 Grid
  const grid: string[][] = [];
  for (let r = 0; r < 3; r++) {
    const row: string[] = [];
    for (let c = 0; c < 5; c++) {
      const sym = slotSymbols[Math.floor(Math.random() * slotSymbols.length)];
      row.push(sym);
    }
    grid.push(row);
  }

  // Count top symbols
  const flat = grid.flat();
  const sevensCount = flat.filter(s => s === '7️⃣').length;
  const diamondsCount = flat.filter(s => s === '💎').length;
  const crownsCount = flat.filter(s => s === '👑').length;
  const scattersCount = flat.filter(s => s === '⚡').length;

  let isWin = false;
  let multiplier = 0;
  let winDescription = 'No winning payline';
  let freeSpinsAwarded = 0;

  if (scattersCount >= 3) {
    freeSpinsAwarded = 10;
    multiplier += 20;
    isWin = true;
    winDescription = `⚡ 3+ SCATTERS TRIGGERED! 10 FREE SPINS + 20X!`;
  }

  if (sevensCount >= 4) {
    multiplier += 50;
    isWin = true;
    winDescription = `🔥 MEGA 777 HIT! ${sevensCount}x Sevens (50X Payout)`;
  } else if (diamondsCount >= 4) {
    multiplier += 25;
    isWin = true;
    winDescription = `💎 DIAMOND FEVER! (25X Payout)`;
  } else if (crownsCount >= 4) {
    multiplier += 15;
    isWin = true;
    winDescription = `👑 ROYAL CROWN COMBO! (15X Payout)`;
  } else if (Math.random() < 0.38) {
    multiplier += 3.5;
    isWin = true;
    winDescription = `✨ 5-Line Match Combo (3.5X Payout)`;
  }

  const effectiveBet = Number(betCoins);
  const reward = isWin ? Math.floor(effectiveBet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-SLT-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-SLOTS',
    gameName: 'Vegas Royal 777 Slots',
    category: 'Slots',
    bet: effectiveBet,
    result: winDescription,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    grid,
    isWin,
    multiplier,
    reward,
    freeSpinsAwarded,
    winDescription,
    newBalance,
    transaction: tx
  });
});

// ==========================================
// 5.3 DRAGON VS TIGER ARENA ENDPOINT
// ==========================================
app.post("/api/games/tiger/deal", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    bets = { DRAGON: 0, TIGER: 0, TIE: 0, TIGER_PAIR: 0 }, 
    totalBet = 10000, 
    currentBalance = 1000000 
  } = req.body;

  const config = serverGamesConfig.tiger_game;
  const betSum = Number(totalBet);

  const suits = ['♠', '♥', '♦', '♣'];
  const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

  const dRankIndex = Math.floor(Math.random() * ranks.length);
  const tRankIndex = Math.floor(Math.random() * ranks.length);

  const dragonCard = {
    rank: ranks[dRankIndex],
    suit: suits[Math.floor(Math.random() * suits.length)],
    value: dRankIndex + 2
  };

  const tigerCard = {
    rank: ranks[tRankIndex],
    suit: suits[Math.floor(Math.random() * suits.length)],
    value: tRankIndex + 2
  };

  let winner: 'DRAGON' | 'TIGER' | 'TIE' = 'TIE';
  if (dragonCard.value > tigerCard.value) winner = 'DRAGON';
  else if (tigerCard.value > dragonCard.value) winner = 'TIGER';

  let totalPayout = 0;
  let message = '';

  if (winner === 'DRAGON') {
    if (bets.DRAGON > 0) totalPayout += bets.DRAGON * 2;
    message = `🐉 DRAGON WINS (${dragonCard.rank} vs ${tigerCard.rank})!`;
  } else if (winner === 'TIGER') {
    if (bets.TIGER > 0) totalPayout += bets.TIGER * 2;
    message = `🐯 TIGER WINS (${tigerCard.rank} vs ${dragonCard.rank})!`;
  } else {
    // TIE -> 9x Payout
    if (bets.TIE > 0) totalPayout += bets.TIE * 9;
    // Push half back on Dragon / Tiger on tie
    if (bets.DRAGON > 0) totalPayout += Math.floor(bets.DRAGON * 0.5);
    if (bets.TIGER > 0) totalPayout += Math.floor(bets.TIGER * 0.5);
    message = `🤝 EXACT TIE MATCH (${dragonCard.rank} = ${tigerCard.rank})! 9X TIE JACKPOT!`;
  }

  const isWin = totalPayout > 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - betSum + totalPayout;

  config.totalRounds += 1;
  config.totalWagered += betSum;
  config.totalWon += totalPayout;

  const txId = `CTX-TGR-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-TIGER',
    gameName: 'Dragon vs Tiger Fortune',
    category: 'Table Arena',
    bet: betSum,
    result: message,
    reward: totalPayout,
    multiplier: isWin ? Number((totalPayout / betSum).toFixed(2)) : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    cards: { dragon: dragonCard, tiger: tigerCard },
    winner,
    totalPayout,
    message,
    newBalance,
    transaction: tx
  });
});

// ==========================================
// 5.4 MAHJONG WAYS CASCADE ENDPOINT
// ==========================================
app.post("/api/games/mahjong/cascade", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    currentBalance = 1000000 
  } = req.body;

  const config = serverGamesConfig.mahjong;
  const bet = Number(betCoins);

  const tiles = [
    { id: 'RED_DRAGON', label: '中', name: 'Red Dragon', color: 'text-red-500', mult: 50, isGold: false },
    { id: 'GREEN_DRAGON', label: '發', name: 'Green Dragon', color: 'text-emerald-500', mult: 40, isGold: false },
    { id: 'WHITE_DRAGON', label: '白', name: 'White Dragon', color: 'text-blue-400', mult: 30, isGold: false },
    { id: 'EIGHT_WAN', label: '八萬', name: '8 Character', color: 'text-amber-400', mult: 15, isGold: true },
    { id: 'FIVE_BAMBOO', label: '伍索', name: '5 Bamboo', color: 'text-emerald-400', mult: 10, isGold: false },
    { id: 'FOUR_DOT', label: '四筒', name: '4 Dot', color: 'text-cyan-400', mult: 8, isGold: false },
    { id: 'GOLDEN_INGOT', label: '元寶', name: 'Golden Ingot', color: 'text-yellow-300', mult: 100, isGold: true },
    { id: 'WILD_TILES', label: '百搭', name: 'Wild Tile', color: 'text-purple-400', mult: 200, isGold: true }
  ];

  // 5x4 Grid
  const grid: any[][] = [];
  for (let r = 0; r < 4; r++) {
    const row: any[] = [];
    for (let c = 0; c < 5; c++) {
      const t = { ...tiles[Math.floor(Math.random() * tiles.length)] };
      // 15% chance to transform into gold tile
      if (Math.random() < 0.15) t.isGold = true;
      row.push(t);
    }
    grid.push(row);
  }

  // Cascading combo engine (1x -> 2x -> 3x -> 5x -> 10x)
  const isWin = Math.random() < 0.46;
  const comboCount = isWin ? Math.floor(1 + Math.random() * 4) : 0;
  const multiplierSteps = [0, 1, 2, 3, 5, 10];
  const multiplier = isWin ? multiplierSteps[Math.min(comboCount, 5)] * (Math.random() < 0.2 ? 5 : 2) : 0;

  const reward = isWin ? Math.floor(bet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const message = isWin 
    ? `🀄 ${comboCount}x Consecutive Mahjong Cascades! (${multiplier}X Payout)` 
    : 'No tile combinations connected';

  const txId = `CTX-MHJ-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-MAHJONG',
    gameName: 'Mahjong Ways Cascade',
    category: 'Cascade & Tiles',
    bet,
    result: message,
    reward,
    multiplier,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    grid,
    comboCount: Math.max(1, comboCount),
    isWin,
    multiplier,
    reward,
    message,
    newBalance,
    transaction: tx
  });
});

// ==========================================
// 5.5 MAGIC SLOTS & SPELLBOOK ENDPOINT
// ==========================================
app.post("/api/games/magic-slots/spin", (req, res) => {
  const { 
    userId = "USR-882941", 
    userName = "Aarav Mehta", 
    betCoins = 10000, 
    isFreeSpin = false, 
    currentBalance = 1000000 
  } = req.body;

  const config = serverGamesConfig.magic_slots;
  const bet = isFreeSpin ? 0 : Number(betCoins);

  const magicSymbols = ['🧙‍♂️', '📖', '🔮', '🦅', '🧪', '💍', '🎩', '📜'];

  // 5x3 Grid
  const grid: string[][] = [];
  for (let r = 0; r < 3; r++) {
    const row: string[] = [];
    for (let c = 0; c < 5; c++) {
      row.push(magicSymbols[Math.floor(Math.random() * magicSymbols.length)]);
    }
    grid.push(row);
  }

  const flat = grid.flat();
  const wizardCount = flat.filter(s => s === '🧙‍♂️').length;
  const spellbookCount = flat.filter(s => s === '📖').length;
  const orbCount = flat.filter(s => s === '🔮').length;

  let isWin = false;
  let multiplier = 0;
  let winDescription = 'Spell energy dissipated';
  let freeSpinsAwarded = 0;

  if (orbCount >= 3) {
    freeSpinsAwarded = 10;
    multiplier += 25;
    isWin = true;
    winDescription = `🔮 3+ ARCANE CRYSTAL ORBS! 10 FREE CASTS + 25X!`;
  }

  if (wizardCount >= 3) {
    multiplier += 50;
    isWin = true;
    winDescription = `🧙‍♂️ GRAND ARCHMAGE WILD SPELL! (50X Payout)`;
  } else if (spellbookCount >= 3) {
    multiplier += 20;
    isWin = true;
    winDescription = `📖 ANCIENT SPELLBOOK AWAKENED! (20X Payout)`;
  } else if (Math.random() < 0.38) {
    multiplier += 4.5;
    isWin = true;
    winDescription = `✨ Arcane Elemental Match (4.5X Payout)`;
  }

  const effectiveBet = Number(betCoins);
  const reward = isWin ? Math.floor(effectiveBet * multiplier) : 0;
  const previousBalance = Number(currentBalance);
  const newBalance = previousBalance - bet + reward;

  config.totalRounds += 1;
  config.totalWagered += bet;
  config.totalWon += reward;

  const txId = `CTX-MAG-${Math.floor(100000 + Math.random() * 900000)}`;
  const tx: ServerCasinoTx = {
    id: txId,
    userId,
    userName,
    gameId: 'GM-MAGIC',
    gameName: 'Magic Slots Spellbook',
    category: 'Fantasy Slots',
    bet: effectiveBet,
    result: winDescription,
    reward,
    multiplier: isWin ? multiplier : 0,
    outcome: isWin ? 'WIN' : 'LOSS',
    previousBalance,
    newBalance,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    rtpSetting: config.rtpRate,
    isTestMode: true,
    TEST_MODE: true
  };

  serverCasinoTransactions.unshift(tx);
  if (serverCasinoTransactions.length > 500) serverCasinoTransactions.pop();

  res.json({
    success: true,
    grid,
    isWin,
    multiplier,
    reward,
    freeSpinsAwarded,
    winDescription,
    newBalance,
    transaction: tx
  });
});

// 6. ADMIN GAME CENTER MANAGEMENT CONFIG & STATS
app.get("/api/games/admin/config", (req, res) => {
  res.json({
    success: true,
    configs: serverGamesConfig
  });
});

app.post("/api/games/admin/config", (req, res) => {
  const { gameId, enabled, isFrozen, minBet, maxBet, rtpRate } = req.body;
  if (!serverGamesConfig[gameId]) {
    return res.status(404).json({ success: false, error: `Game ${gameId} not found.` });
  }

  const target = serverGamesConfig[gameId];
  if (enabled !== undefined) target.enabled = Boolean(enabled);
  if (isFrozen !== undefined) target.isFrozen = Boolean(isFrozen);
  if (minBet !== undefined && !isNaN(Number(minBet))) target.minBet = Number(minBet);
  if (maxBet !== undefined && !isNaN(Number(maxBet))) target.maxBet = Number(maxBet);
  if (rtpRate !== undefined && !isNaN(Number(rtpRate))) target.rtpRate = Number(rtpRate);

  res.json({
    success: true,
    message: `Settings for ${target.name} updated successfully by Administrator.`,
    game: target
  });
});

// 7. GET SUSPICIOUS GAME ACTIVITY / INTEGRITY LOGS
app.get("/api/games/admin/suspicious", (req, res) => {
  const suspiciousList = serverCasinoTransactions
    .filter(tx => tx.bet >= 50000 || tx.multiplier >= 50 || tx.reward >= 500000)
    .slice(0, 50);

  res.json({
    success: true,
    totalSuspicious: suspiciousList.length,
    alerts: suspiciousList
  });
});



// ==========================================
// 5. OWNER TEST WALLET & COIN SELLER SYSTEM
// ==========================================

let serverOwnerTestCoinBalance = 500000000; // 500,000,000 TEST COINS

let serverCoinSellers: any[] = [
  {
    id: 'CS-7001',
    name: 'Kabir Singhania',
    username: 'kabir_coins_official',
    contact: 'kabir.coins@srlive.io / +91 99881 12233',
    phone: '+91 99881 12233',
    email: 'kabir.coins@srlive.io',
    status: 'Active',
    testCoinBalance: 25000000,
    totalDistributed: 85000000,
    dailyLimit: 50000000,
    singleTransferLimit: 15000000,
    lastActivity: '10 mins ago',
    createdDate: '2025-02-01',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    notes: 'Primary APAC Verified Test Coin Seller'
  },
  {
    id: 'CS-7002',
    name: 'Zara Chen',
    username: 'zara_coin_distro',
    contact: 'zara.c@srlive.io / +65 8123 4567',
    phone: '+65 8123 4567',
    email: 'zara.c@srlive.io',
    status: 'Active',
    testCoinBalance: 15000000,
    totalDistributed: 42000000,
    dailyLimit: 30000000,
    singleTransferLimit: 10000000,
    lastActivity: '2 hours ago',
    createdDate: '2025-03-12',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    notes: 'Singapore & SEA Sandbox Partner'
  },
  {
    id: 'CS-7003',
    name: 'Alexander Sterling',
    username: 'alex_test_coins',
    contact: 'alex.s@srlive.io / +44 7911 123456',
    phone: '+44 7911 123456',
    email: 'alex.s@srlive.io',
    status: 'Suspended',
    testCoinBalance: 5000000,
    totalDistributed: 18000000,
    dailyLimit: 20000000,
    singleTransferLimit: 5000000,
    lastActivity: '3 days ago',
    createdDate: '2025-04-18',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    notes: 'Audit under review for unusual test volume'
  }
];

let serverOwnerToSellerTxs: any[] = [
  {
    id: 'CTX-OWNER-7001',
    type: 'OWNER_TO_SELLER',
    ownerId: 'OWNER-001',
    sellerId: 'CS-7001',
    sellerName: 'Kabir Singhania (kabir_coins_official)',
    amount: 10000000,
    previousOwnerBalance: 500000000,
    newOwnerBalance: 490000000,
    previousSellerBalance: 15000000,
    newSellerBalance: 25000000,
    timestamp: new Date(Date.now() - 1000 * 60 * 60).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'OWNER-001',
    TEST_MODE: true,
    notes: 'Initial test coin allocation to authorized seller'
  },
  {
    id: 'CTX-OWNER-7002',
    type: 'OWNER_TO_SELLER',
    ownerId: 'OWNER-001',
    sellerId: 'CS-7002',
    sellerName: 'Zara Chen (zara_coin_distro)',
    amount: 15000000,
    previousOwnerBalance: 490000000,
    newOwnerBalance: 475000000,
    previousSellerBalance: 0,
    newSellerBalance: 15000000,
    timestamp: new Date(Date.now() - 1000 * 60 * 180).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'OWNER-001',
    TEST_MODE: true,
    notes: 'Authorized test liquidity distribution'
  }
];

let serverSellerToUserTxs: any[] = [
  {
    id: 'CTX-SELLER-9001',
    sellerId: 'CS-7001',
    sellerName: 'Kabir Singhania',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    amount: 5000000,
    previousSellerBalance: 30000000,
    newSellerBalance: 25000000,
    previousUserBalance: 240000,
    newUserBalance: 5240000,
    timestamp: new Date(Date.now() - 1000 * 60 * 30).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'CS-7001',
    TEST_MODE: true,
    notes: 'Test coins distributed for QA game testing'
  },
  {
    id: 'CTX-SELLER-9002',
    sellerId: 'CS-7001',
    sellerName: 'Kabir Singhania',
    userId: 'USR-8002',
    userName: 'Meera Patel',
    amount: 2000000,
    previousSellerBalance: 32000000,
    newSellerBalance: 30000000,
    previousUserBalance: 85000,
    newUserBalance: 2085000,
    timestamp: new Date(Date.now() - 1000 * 60 * 120).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'CS-7001',
    TEST_MODE: true,
    notes: 'VIP user test coins recharge'
  }
];

// Mock User Database for server validation and virtual wallet operations
export interface ServerUserRecord {
  id: string; // 7-Digit sequential ID (0000001, 0000002, etc.)
  name: string;
  username: string;
  email?: string;
  phone?: string;
  coinBalance: number;
  diamondBalance: number;
  boltBalance?: number;
  vipLevel: number;
  svipLevel?: number;
  userLevel?: number;
  role?: string;
  status: string;
  avatar?: string;
  hostTag?: string;
  avatarFrameId?: string;
  avatarFrameUrl?: string;
  countryCode?: string;
  countryFlag?: string;
  countryName?: string;
  bio?: string;
  joinedDate?: string;
  lastActive?: string;
  totalSpentCoins?: number;
  totalRechargedUSD?: number;
  deviceType?: string;
  registrationDate?: string;
  lastLogin?: string;
}

// 7-Digit Sequential User ID Counter (Backend-generated, permanent, non-reusable)
let serverUserIdCounter = 5; // Starts with 5 pre-seeded users (0000001 - 0000005)
let serverDeletedUserIds: string[] = [];

// Auth Identifier Linking map (email, phone, providerId -> 7-digit User ID)
let serverAuthAccounts: Record<string, {
  userId: string;
  provider: string;
  identifier: string;
  linkedAt: string;
}> = {
  'aarav.mehta@gmail.com': { userId: '0000001', provider: 'google', identifier: 'aarav.mehta@gmail.com', linkedAt: '2025-01-20' },
  'rohan.joshi@gmail.com': { userId: '0000002', provider: 'email', identifier: 'rohan.joshi@gmail.com', linkedAt: '2025-01-25' },
  'meera.patel@gmail.com': { userId: '0000003', provider: 'email', identifier: 'meera.patel@gmail.com', linkedAt: '2025-02-01' },
  'zoya.khan@gmail.com': { userId: '0000004', provider: 'email', identifier: 'zoya.khan@gmail.com', linkedAt: '2025-02-10' },
  'david.miller@gmail.com': { userId: '0000005', provider: 'email', identifier: 'david.miller@gmail.com', linkedAt: '2025-02-15' }
};

let serverUsers: Record<string, ServerUserRecord> = {
  '0000001': {
    id: '0000001',
    name: 'Aarav Mehta',
    username: 'aarav_vip',
    email: 'aarav.mehta@gmail.com',
    coinBalance: 5700000,
    diamondBalance: 286500,
    boltBalance: 286500,
    vipLevel: 8,
    svipLevel: 2,
    userLevel: 42,
    role: 'SUPER_ADMIN',
    hostTag: 'CELEBRATE',
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    avatarFrameId: 'FRM-HT-01',
    countryCode: 'NP',
    countryFlag: '🇳🇵',
    countryName: 'Nepal',
    bio: 'Live • Laugh • Share with DIYO LIVE VIP Global Community ❤️',
    joinedDate: '2025-01-20',
    registrationDate: '2025-01-20',
    lastActive: 'Just now',
    lastLogin: 'Just now',
    totalSpentCoins: 3500000,
    totalRechargedUSD: 8500
  },
  '0000002': {
    id: '0000002',
    name: 'Rohan Joshi',
    username: 'rohan_star',
    email: 'rohan.joshi@gmail.com',
    coinBalance: 120000,
    diamondBalance: 8500,
    boltBalance: 8500,
    vipLevel: 5,
    userLevel: 28,
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    countryCode: 'IN',
    countryFlag: '🇮🇳',
    countryName: 'India',
    bio: 'Music and Gaming enthusiast on DIYO LIVE!',
    joinedDate: '2025-01-25',
    registrationDate: '2025-01-25',
    lastActive: '5m ago',
    lastLogin: '5m ago',
    totalSpentCoins: 650000
  },
  '0000003': {
    id: '0000003',
    name: 'Meera Patel',
    username: 'meera_queen',
    email: 'meera.patel@gmail.com',
    coinBalance: 85000,
    diamondBalance: 12000,
    boltBalance: 12000,
    vipLevel: 6,
    userLevel: 35,
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    countryCode: 'NP',
    countryFlag: '🇳🇵',
    countryName: 'Nepal',
    bio: 'Broadcasting vibes & positive energy ✨',
    joinedDate: '2025-02-01',
    registrationDate: '2025-02-01',
    lastActive: '12m ago',
    lastLogin: '12m ago',
    totalSpentCoins: 890000
  },
  '0000004': {
    id: '0000004',
    name: 'Zoya Khan',
    username: 'zoya_live',
    email: 'zoya.khan@gmail.com',
    coinBalance: 450000,
    diamondBalance: 35000,
    boltBalance: 35000,
    vipLevel: 7,
    userLevel: 39,
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    countryCode: 'AE',
    countryFlag: '🇦🇪',
    countryName: 'UAE',
    bio: 'VIP DIYO LIVE Gifter & Party Host 🎉',
    joinedDate: '2025-02-10',
    registrationDate: '2025-02-10',
    lastActive: '25m ago',
    lastLogin: '25m ago',
    totalSpentCoins: 2100000
  },
  '0000005': {
    id: '0000005',
    name: 'David Miller',
    username: 'david_gamer',
    email: 'david.miller@gmail.com',
    coinBalance: 15000,
    diamondBalance: 1200,
    boltBalance: 1200,
    vipLevel: 3,
    userLevel: 15,
    status: 'Active',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    countryCode: 'US',
    countryFlag: '🇺🇸',
    countryName: 'USA',
    bio: 'Casual gamer exploring DIYO LIVE rooms!',
    joinedDate: '2025-02-15',
    registrationDate: '2025-02-15',
    lastActive: '40m ago',
    lastLogin: '40m ago',
    totalSpentCoins: 45000
  }
};

// Owner configurable wallet settings
let serverWalletSettings = {
  userTransferEnabled: true,
  virtualExchangeEnabled: true,
  minTransferAmount: 100,
  maxTransferAmount: 10000000,
  coinToDiamondRate: 1.0, // 1 TEST COIN = 1 Virtual Diamond (100 coins = 100 diamonds)
  testModeNotice: "TEST MODE — Cash withdrawal is disabled. All transactions use virtual TEST COINS and virtual Diamonds with no real-money cash value."
};

let serverWalletTransactions: any[] = [
  {
    id: 'TX-TEST-INIT-001',
    type: 'USER_TRANSFER_RECEIVED',
    senderId: 'USR-8001',
    senderName: 'Rohan Joshi',
    receiverId: 'USR-882941',
    receiverName: 'Aarav Mehta',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    amountCoins: 25000,
    amountDiamonds: 0,
    previousReceiverBalance: 220000,
    newReceiverBalance: 245000,
    previousCoinBalance: 220000,
    newCoinBalance: 245000,
    status: 'Completed',
    timestamp: '10:15:20 AM',
    notes: 'Received Test Coins for party live room gifting test',
    TEST_MODE: true
  },
  {
    id: 'TX-TEST-INIT-002',
    type: 'VIRTUAL_EXCHANGE',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    senderId: 'USR-882941',
    senderName: 'Aarav Mehta',
    amountCoins: -10000,
    amountDiamonds: 10000,
    exchangeRate: 1.0,
    previousCoinBalance: 255000,
    newCoinBalance: 245000,
    previousDiamondBalance: 8500,
    newDiamondBalance: 18500,
    status: 'Completed',
    timestamp: '09:40:12 AM',
    notes: 'Exchanged 10,000 TEST COINS into 10,000 Virtual Diamonds (Test Mode)',
    TEST_MODE: true
  }
];

// 5.1 Get Owner Test Wallet Status
app.get("/api/owner/test-wallet", (req, res) => {
  res.json({
    success: true,
    ownerTestCoinBalance: serverOwnerTestCoinBalance,
    totalSellers: serverCoinSellers.length,
    activeSellers: serverCoinSellers.filter(s => s.status === 'Active').length,
    totalDistributedToSellers: serverOwnerToSellerTxs
      .filter(tx => tx.type === 'OWNER_TO_SELLER')
      .reduce((sum, tx) => sum + tx.amount, 0),
    totalReclaimedFromSellers: serverOwnerToSellerTxs
      .filter(tx => tx.type === 'RECLAIM_FROM_SELLER')
      .reduce((sum, tx) => sum + tx.amount, 0),
    transactions: serverOwnerToSellerTxs
  });
});

// 5.2 Owner -> Coin Seller Transfer (Atomic Server-side Transaction)
app.post("/api/owner/transfer-to-seller", (req, res) => {
  const { sellerId, amountCoins, notes } = req.body;
  const amount = Number(amountCoins);

  if (!sellerId) {
    return res.status(400).json({ success: false, error: "Seller ID is required." });
  }

  if (!amount || isNaN(amount) || amount <= 0) {
    return res.status(400).json({ success: false, error: "Transfer amount must be greater than 0 TEST COINS." });
  }

  if (serverOwnerTestCoinBalance < amount) {
    return res.status(400).json({
      success: false,
      error: `Insufficient Owner Test Coins! Available: ${serverOwnerTestCoinBalance.toLocaleString()} TEST COINS.`
    });
  }

  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: `Coin Seller with ID "${sellerId}" not found.` });
  }

  if (seller.status !== 'Active') {
    return res.status(400).json({ success: false, error: `Cannot transfer to seller in "${seller.status}" status.` });
  }

  // Execute Atomic Transfer
  const prevOwnerBal = serverOwnerTestCoinBalance;
  const newOwnerBal = prevOwnerBal - amount;
  const prevSellerBal = seller.testCoinBalance;
  const newSellerBal = prevSellerBal + amount;

  serverOwnerTestCoinBalance = newOwnerBal;
  seller.testCoinBalance = newSellerBal;
  seller.lastActivity = 'Just now';

  const txId = `CTX-OWNER-${Math.floor(100000 + Math.random() * 900000)}`;
  const txRecord = {
    id: txId,
    type: 'OWNER_TO_SELLER',
    ownerId: 'OWNER-001',
    sellerId: seller.id,
    sellerName: `${seller.name} (${seller.username})`,
    amount,
    previousOwnerBalance: prevOwnerBal,
    newOwnerBalance: newOwnerBal,
    previousSellerBalance: prevSellerBal,
    newSellerBalance: newSellerBal,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'OWNER',
    TEST_MODE: true,
    notes: notes || `Distributed ${amount.toLocaleString()} TEST COINS to ${seller.name}`
  };

  serverOwnerToSellerTxs.unshift(txRecord);

  res.json({
    success: true,
    message: `✅ Successfully sent ${amount.toLocaleString()} TEST COINS to Seller "${seller.name}".`,
    ownerBalance: newOwnerBal,
    sellerBalance: newSellerBal,
    transaction: txRecord
  });
});

// 5.3 Owner Reclaim Unused Test Coins from Seller
app.post("/api/owner/reclaim-from-seller", (req, res) => {
  const { sellerId, amountCoins, notes } = req.body;
  const amount = Number(amountCoins);

  if (!sellerId) {
    return res.status(400).json({ success: false, error: "Seller ID is required." });
  }

  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: `Coin Seller "${sellerId}" not found.` });
  }

  if (!amount || isNaN(amount) || amount <= 0) {
    return res.status(400).json({ success: false, error: "Reclaim amount must be greater than 0 TEST COINS." });
  }

  if (seller.testCoinBalance < amount) {
    return res.status(400).json({
      success: false,
      error: `Seller only has ${seller.testCoinBalance.toLocaleString()} TEST COINS available to reclaim.`
    });
  }

  // Execute Atomic Reclaim
  const prevOwnerBal = serverOwnerTestCoinBalance;
  const newOwnerBal = prevOwnerBal + amount;
  const prevSellerBal = seller.testCoinBalance;
  const newSellerBal = prevSellerBal - amount;

  serverOwnerTestCoinBalance = newOwnerBal;
  seller.testCoinBalance = newSellerBal;
  seller.lastActivity = 'Just now';

  const txId = `CTX-RECLAIM-${Math.floor(100000 + Math.random() * 900000)}`;
  const txRecord = {
    id: txId,
    type: 'RECLAIM_FROM_SELLER',
    ownerId: 'OWNER-001',
    sellerId: seller.id,
    sellerName: `${seller.name} (${seller.username})`,
    amount,
    previousOwnerBalance: prevOwnerBal,
    newOwnerBalance: newOwnerBal,
    previousSellerBalance: prevSellerBal,
    newSellerBalance: newSellerBal,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    operator: 'OWNER',
    TEST_MODE: true,
    notes: notes || `Reclaimed ${amount.toLocaleString()} unused TEST COINS back to Owner Treasury`
  };

  serverOwnerToSellerTxs.unshift(txRecord);

  res.json({
    success: true,
    message: `✅ Successfully reclaimed ${amount.toLocaleString()} TEST COINS from "${seller.name}".`,
    ownerBalance: newOwnerBal,
    sellerBalance: newSellerBal,
    transaction: txRecord
  });
});

// 5.4 Get Coin Sellers List
app.get("/api/coin-sellers", (req, res) => {
  res.json({
    success: true,
    sellers: serverCoinSellers
  });
});

// 5.5 Create New Coin Seller
app.post("/api/coin-sellers/create", (req, res) => {
  const { name, username, phone, email, initialCoins = 0, dailyLimit = 50000000, singleLimit = 10000000, notes } = req.body;

  if (!name || !username) {
    return res.status(400).json({ success: false, error: "Name and username are required." });
  }

  const existing = serverCoinSellers.find(s => s.username.toLowerCase() === String(username).toLowerCase());
  if (existing) {
    return res.status(400).json({ success: false, error: `Username "@${username}" is already taken by an existing seller.` });
  }

  const allocAmount = Number(initialCoins);
  if (allocAmount > 0 && serverOwnerTestCoinBalance < allocAmount) {
    return res.status(400).json({
      success: false,
      error: `Cannot allocate ${allocAmount.toLocaleString()} coins. Owner only has ${serverOwnerTestCoinBalance.toLocaleString()} TEST COINS.`
    });
  }

  const newSellerId = `CS-${Math.floor(7000 + Math.random() * 900)}`;
  const newSeller = {
    id: newSellerId,
    name,
    username,
    contact: `${email || phone || 'seller@srlive.io'}`,
    phone: phone || '+91 99000 11223',
    email: email || `${username}@srlive.io`,
    status: 'Active',
    testCoinBalance: allocAmount > 0 ? allocAmount : 0,
    totalDistributed: 0,
    dailyLimit: Number(dailyLimit) || 50000000,
    singleTransferLimit: Number(singleLimit) || 10000000,
    lastActivity: 'Created just now',
    createdDate: new Date().toISOString().split('T')[0],
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    notes: notes || 'Authorized test coin seller'
  };

  if (allocAmount > 0) {
    serverOwnerTestCoinBalance -= allocAmount;
    serverOwnerToSellerTxs.unshift({
      id: `CTX-OWNER-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'OWNER_TO_SELLER',
      ownerId: 'OWNER-001',
      sellerId: newSellerId,
      sellerName: `${name} (${username})`,
      amount: allocAmount,
      previousOwnerBalance: serverOwnerTestCoinBalance + allocAmount,
      newOwnerBalance: serverOwnerTestCoinBalance,
      previousSellerBalance: 0,
      newSellerBalance: allocAmount,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      operator: 'OWNER',
      TEST_MODE: true,
      notes: 'Initial test coin grant at seller creation'
    });
  }

  serverCoinSellers.unshift(newSeller);

  res.json({
    success: true,
    message: `✅ Created Coin Seller "${name}" successfully.`,
    seller: newSeller,
    ownerBalance: serverOwnerTestCoinBalance
  });
});

// 5.6 Update Coin Seller Status
app.post("/api/coin-sellers/status", (req, res) => {
  const { sellerId, status } = req.body;
  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: "Seller not found." });
  }

  seller.status = status;
  seller.lastActivity = 'Status changed just now';

  res.json({
    success: true,
    message: `Seller status updated to "${status}".`,
    seller
  });
});

// 5.7 Update Coin Seller Limits
app.post("/api/coin-sellers/limits", (req, res) => {
  const { sellerId, dailyLimit, singleTransferLimit } = req.body;
  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: "Seller not found." });
  }

  if (dailyLimit !== undefined) seller.dailyLimit = Number(dailyLimit);
  if (singleTransferLimit !== undefined) seller.singleTransferLimit = Number(singleTransferLimit);
  seller.lastActivity = 'Limits updated';

  res.json({
    success: true,
    message: `Updated transfer limits for ${seller.name}.`,
    seller
  });
});

// 5.8 COIN SELLER -> USER Transfer (Atomic Server-side Transaction)
app.post("/api/coin-sellers/transfer-to-user", (req, res) => {
  const { sellerId, targetUserId, amountCoins, notes } = req.body;
  const amount = Number(amountCoins);

  // Security Check 1: Validate input
  if (!sellerId || !targetUserId) {
    return res.status(400).json({ success: false, error: "Seller ID and Target User ID are required." });
  }

  if (!amount || isNaN(amount) || amount <= 0) {
    return res.status(400).json({ success: false, error: "Transfer amount must be greater than 0 TEST COINS." });
  }

  // Security Check 2: Verify Seller
  const seller = serverCoinSellers.find(s => s.id === sellerId);
  if (!seller) {
    return res.status(404).json({ success: false, error: "Unauthorized: Coin Seller not registered." });
  }

  if (seller.status !== 'Active') {
    return res.status(403).json({ success: false, error: `Transfer rejected: Seller account is currently ${seller.status}.` });
  }

  // Security Check 3: Check Seller Balance
  if (seller.testCoinBalance < amount) {
    return res.status(400).json({
      success: false,
      error: `Transfer failed: Insufficient seller balance. Available: ${seller.testCoinBalance.toLocaleString()} TEST COINS.`
    });
  }

  // Security Check 4: Check Transfer Limits
  if (seller.singleTransferLimit && amount > seller.singleTransferLimit) {
    return res.status(400).json({
      success: false,
      error: `Transfer exceeds seller's single transaction limit of ${seller.singleTransferLimit.toLocaleString()} TEST COINS.`
    });
  }

  // Find or instantiate recipient user
  let targetUser = serverUsers[targetUserId];
  if (!targetUser) {
    targetUser = {
      id: targetUserId,
      name: `User ${targetUserId}`,
      username: `user_${targetUserId.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 0,
      diamondBalance: 0,
      vipLevel: 1,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      status: 'Active'
    };
    serverUsers[targetUserId] = targetUser;
  }

  // Atomic Balance Mutation
  const prevSellerBalance = seller.testCoinBalance;
  const newSellerBalance = prevSellerBalance - amount;
  const prevUserBalance = targetUser.coinBalance;
  const newUserBalance = prevUserBalance + amount;

  seller.testCoinBalance = newSellerBalance;
  seller.totalDistributed += amount;
  seller.lastActivity = 'Just now';
  targetUser.coinBalance = newUserBalance;

  const txId = `CTX-SELLER-${Math.floor(100000 + Math.random() * 900000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  const txRecord = {
    id: txId,
    sellerId: seller.id,
    sellerName: seller.name,
    userId: targetUser.id,
    userName: targetUser.name,
    amount,
    previousSellerBalance: prevSellerBalance,
    newSellerBalance: newSellerBalance,
    previousUserBalance: prevUserBalance,
    newUserBalance: newUserBalance,
    timestamp,
    operator: seller.id,
    TEST_MODE: true,
    notes: notes || `Transferred ${amount.toLocaleString()} TEST COINS to user ${targetUser.name}`
  };

  serverSellerToUserTxs.unshift(txRecord);
  if (serverSellerToUserTxs.length > 500) {
    serverSellerToUserTxs.pop();
  }

  res.json({
    success: true,
    message: `🎉 Successfully transferred ${amount.toLocaleString()} TEST COINS to ${targetUser.name} (${targetUser.id}).`,
    transaction: txRecord,
    sellerBalance: newSellerBalance,
    userBalance: newUserBalance
  });
});

// 5.9 Get Seller Transactions
app.get("/api/coin-sellers/transactions", (req, res) => {
  const { sellerId, userId } = req.query;
  let filtered = [...serverSellerToUserTxs];

  if (sellerId) {
    filtered = filtered.filter(tx => tx.sellerId === sellerId);
  }
  if (userId) {
    filtered = filtered.filter(tx => tx.userId === userId);
  }

  res.json({
    success: true,
    totalCount: filtered.length,
    transactions: filtered
  });
});

// ==========================================
// 5.10 DIYO LIVE TEST WALLET & TRANSFER ENGINE
// ==========================================

// Get Platform Wallet Configuration
app.get("/api/wallet/settings", (req, res) => {
  res.json({
    success: true,
    settings: serverWalletSettings
  });
});

// Update Platform Wallet Configuration (Owner Controls)
app.post("/api/wallet/settings", (req, res) => {
  const { 
    userTransferEnabled, 
    virtualExchangeEnabled, 
    minTransferAmount, 
    maxTransferAmount, 
    coinToDiamondRate 
  } = req.body;

  if (userTransferEnabled !== undefined) {
    serverWalletSettings.userTransferEnabled = Boolean(userTransferEnabled);
  }
  if (virtualExchangeEnabled !== undefined) {
    serverWalletSettings.virtualExchangeEnabled = Boolean(virtualExchangeEnabled);
  }
  if (minTransferAmount !== undefined && !isNaN(Number(minTransferAmount))) {
    serverWalletSettings.minTransferAmount = Math.max(1, Number(minTransferAmount));
  }
  if (maxTransferAmount !== undefined && !isNaN(Number(maxTransferAmount))) {
    serverWalletSettings.maxTransferAmount = Math.max(serverWalletSettings.minTransferAmount, Number(maxTransferAmount));
  }
  if (coinToDiamondRate !== undefined && !isNaN(Number(coinToDiamondRate))) {
    serverWalletSettings.coinToDiamondRate = Math.max(0.01, Number(coinToDiamondRate));
  }

  res.json({
    success: true,
    message: "Platform Wallet Transfer & Virtual Exchange settings updated successfully.",
    settings: serverWalletSettings
  });
});

// Get User Directory with Test Balances
app.get("/api/wallet/users", (req, res) => {
  res.json({
    success: true,
    users: Object.values(serverUsers)
  });
});

// Get Single User Wallet & Transaction History
app.get("/api/wallet/user/:userId", (req, res) => {
  const { userId } = req.params;
  const user = serverUsers[userId];
  if (!user) {
    return res.status(404).json({ success: false, error: "User not found." });
  }

  const userTxs = serverWalletTransactions.filter(
    tx => tx.userId === userId || tx.senderId === userId || tx.receiverId === userId || tx.recipientId === userId
  );

  res.json({
    success: true,
    user,
    transactions: userTxs
  });
});

// USER -> USER TEST COIN TRANSFER (Server-Side Atomic Processing)
app.post("/api/wallet/transfer", (req, res) => {
  const { senderId, receiverId, targetUserId, amount, notes } = req.body;
  const targetId = receiverId || targetUserId;
  const transferAmount = Number(amount);

  // 1. Check Feature Toggle
  if (!serverWalletSettings.userTransferEnabled) {
    return res.status(403).json({
      success: false,
      error: "User-to-User Transfer is currently disabled by the Platform Owner."
    });
  }

  // 2. Validate Input Parameters
  if (!senderId || !targetId) {
    return res.status(400).json({
      success: false,
      error: "Both Sender ID and Recipient User ID are required."
    });
  }

  // Normalize ID (handle 7-digit sequential '0000001', raw numbers '1', username, or email)
  const normalizeId = (idStr: string) => {
    const raw = String(idStr).trim();
    if (serverUsers[raw]) return raw;
    
    // Check if unpadded number e.g. "1" -> "0000001"
    if (/^\d+$/.test(raw)) {
      const padded = raw.padStart(7, '0');
      if (serverUsers[padded]) return padded;
    }

    // Check auth accounts mapping (email / phone)
    if (serverAuthAccounts[raw.toLowerCase()]) {
      return serverAuthAccounts[raw.toLowerCase()].userId;
    }

    // Look up by username or name
    const byUsername = Object.values(serverUsers).find(
      u => u.username.toLowerCase() === raw.toLowerCase().replace('@', '') ||
           u.name.toLowerCase() === raw.toLowerCase() ||
           (u.email && u.email.toLowerCase() === raw.toLowerCase()) ||
           (u.phone && u.phone.replace(/[^0-9]/g, '') === raw.replace(/[^0-9]/g, ''))
    );
    if (byUsername) return byUsername.id;
    return raw;
  };

  const senderKey = normalizeId(senderId);
  const receiverKey = normalizeId(targetId);

  // 3. Sender != Receiver validation
  if (senderKey === receiverKey) {
    return res.status(400).json({
      success: false,
      error: "Cannot transfer TEST COINS to yourself. Please specify a different recipient."
    });
  }

  // 4. Validate Transfer Amount
  if (!transferAmount || isNaN(transferAmount) || transferAmount <= 0) {
    return res.status(400).json({
      success: false,
      error: "Transfer amount must be a positive integer."
    });
  }

  if (transferAmount < serverWalletSettings.minTransferAmount) {
    return res.status(400).json({
      success: false,
      error: `Minimum transfer amount is ${serverWalletSettings.minTransferAmount.toLocaleString()} TEST COINS.`
    });
  }

  if (transferAmount > serverWalletSettings.maxTransferAmount) {
    return res.status(400).json({
      success: false,
      error: `Maximum transfer limit is ${serverWalletSettings.maxTransferAmount.toLocaleString()} TEST COINS per transaction.`
    });
  }

  // 5. Verify Sender Exists & Balance
  const sender = serverUsers[senderKey];
  if (!sender) {
    return res.status(404).json({
      success: false,
      error: `Sender account "${senderId}" not found.`
    });
  }

  if (sender.status === 'Banned' || sender.status === 'Suspended') {
    return res.status(403).json({
      success: false,
      error: `Sender account is currently ${sender.status}. Transfer rejected.`
    });
  }

  if (sender.coinBalance < transferAmount) {
    return res.status(400).json({
      success: false,
      error: `Insufficient balance! You have ${sender.coinBalance.toLocaleString()} TEST COINS, but tried to send ${transferAmount.toLocaleString()} TEST COINS.`
    });
  }

  // 6. Verify or Instantiate Recipient
  let receiver = serverUsers[receiverKey];
  if (!receiver) {
    receiver = {
      id: receiverKey.startsWith('USR-') ? receiverKey : `USR-${receiverKey}`,
      name: `User ${receiverKey}`,
      username: `user_${receiverKey.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 0,
      diamondBalance: 0,
      vipLevel: 1,
      status: 'Active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    };
    serverUsers[receiver.id] = receiver;
  }

  if (receiver.status === 'Banned') {
    return res.status(403).json({
      success: false,
      error: `Recipient account "${receiver.name}" is banned from receiving coins.`
    });
  }

  // 7. Atomic Balance Mutation (Server Authoritative)
  const prevSenderBalance = sender.coinBalance;
  const newSenderBalance = prevSenderBalance - transferAmount;
  const prevReceiverBalance = receiver.coinBalance;
  const newReceiverBalance = prevReceiverBalance + transferAmount;

  sender.coinBalance = newSenderBalance;
  receiver.coinBalance = newReceiverBalance;

  // 8. Generate Unique Atomic Transaction ID
  const txId = `TX-TRANSFER-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fullDateTime = `${new Date().toISOString().split('T')[0]} ${timestamp}`;

  // Log Sender Transaction Record
  const senderTx = {
    id: `${txId}-SENT`,
    type: 'USER_TRANSFER_SENT',
    userId: sender.id,
    userName: sender.name,
    senderId: sender.id,
    senderName: sender.name,
    receiverId: receiver.id,
    receiverName: receiver.name,
    recipientId: receiver.id,
    recipientName: receiver.name,
    amountCoins: -transferAmount,
    amountDiamonds: 0,
    previousBalance: prevSenderBalance,
    newBalance: newSenderBalance,
    previousSenderBalance: prevSenderBalance,
    newSenderBalance: newSenderBalance,
    status: 'Completed',
    timestamp: fullDateTime,
    notes: notes || `Transferred to ${receiver.name} (${receiver.id})`,
    TEST_MODE: true
  };

  // Log Receiver Transaction Record
  const receiverTx = {
    id: `${txId}-RECV`,
    type: 'USER_TRANSFER_RECEIVED',
    userId: receiver.id,
    userName: receiver.name,
    senderId: sender.id,
    senderName: sender.name,
    receiverId: receiver.id,
    receiverName: receiver.name,
    recipientId: receiver.id,
    recipientName: receiver.name,
    amountCoins: transferAmount,
    amountDiamonds: 0,
    previousBalance: prevReceiverBalance,
    newBalance: newReceiverBalance,
    previousReceiverBalance: prevReceiverBalance,
    newReceiverBalance: newReceiverBalance,
    status: 'Completed',
    timestamp: fullDateTime,
    notes: notes || `Received from ${sender.name} (${sender.id})`,
    TEST_MODE: true
  };

  serverWalletTransactions.unshift(senderTx);
  serverWalletTransactions.unshift(receiverTx);

  if (serverWalletTransactions.length > 1000) {
    serverWalletTransactions.length = 1000;
  }

  res.json({
    success: true,
    message: `🎉 Successfully sent ${transferAmount.toLocaleString()} TEST COINS to ${receiver.name}!`,
    transactionId: txId,
    senderTransaction: senderTx,
    receiverTransaction: receiverTx,
    senderBalance: newSenderBalance,
    receiverBalance: newReceiverBalance,
    sender: { id: sender.id, name: sender.name, coinBalance: newSenderBalance },
    receiver: { id: receiver.id, name: receiver.name, coinBalance: newReceiverBalance }
  });
});

// VIRTUAL EXCHANGE (TEST COINS -> Virtual Diamonds)
app.post("/api/wallet/exchange", (req, res) => {
  const { userId, coinAmount } = req.body;
  const amountToExchange = Number(coinAmount);

  // 1. Check Feature Toggle
  if (!serverWalletSettings.virtualExchangeEnabled) {
    return res.status(403).json({
      success: false,
      error: "Virtual Exchange is currently disabled by Platform Owner."
    });
  }

  // 2. Validate Input
  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  if (!amountToExchange || isNaN(amountToExchange) || amountToExchange <= 0) {
    return res.status(400).json({
      success: false,
      error: "Exchange amount must be a positive integer."
    });
  }

  const user = serverUsers[userId];
  if (!user) {
    return res.status(404).json({ success: false, error: "User not found." });
  }

  if (user.coinBalance < amountToExchange) {
    return res.status(400).json({
      success: false,
      error: `Insufficient TEST COINS! Available: ${user.coinBalance.toLocaleString()} 🪙, requested: ${amountToExchange.toLocaleString()} 🪙.`
    });
  }

  // 3. Compute Diamonds Received using Owner-configured exchange rate
  const rate = serverWalletSettings.coinToDiamondRate || 1.0;
  const diamondsReceived = Math.floor(amountToExchange * rate);

  if (diamondsReceived <= 0) {
    return res.status(400).json({
      success: false,
      error: "Exchange resulted in 0 diamonds. Please enter a larger amount."
    });
  }

  // 4. Atomic Balance Mutation
  const prevCoins = user.coinBalance;
  const newCoins = prevCoins - amountToExchange;
  const prevDiamonds = user.diamondBalance || 0;
  const newDiamonds = prevDiamonds + diamondsReceived;

  user.coinBalance = newCoins;
  user.diamondBalance = newDiamonds;

  // 5. Log Transaction
  const txId = `TX-EXCHANGE-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fullDateTime = `${new Date().toISOString().split('T')[0]} ${timestamp}`;

  const exchangeTx = {
    id: txId,
    type: 'VIRTUAL_EXCHANGE',
    userId: user.id,
    userName: user.name,
    senderId: user.id,
    senderName: user.name,
    amountCoins: -amountToExchange,
    amountDiamonds: diamondsReceived,
    exchangeRate: rate,
    previousCoinBalance: prevCoins,
    newCoinBalance: newCoins,
    previousDiamondBalance: prevDiamonds,
    newDiamondBalance: newDiamonds,
    status: 'Completed',
    timestamp: fullDateTime,
    notes: `Exchanged ${amountToExchange.toLocaleString()} TEST COINS into ${diamondsReceived.toLocaleString()} Virtual Diamonds (Rate: 1:${rate})`,
    TEST_MODE: true
  };

  serverWalletTransactions.unshift(exchangeTx);

  res.json({
    success: true,
    message: `✨ Exchanged ${amountToExchange.toLocaleString()} TEST COINS into ${diamondsReceived.toLocaleString()} Virtual Diamonds! (TEST ONLY - NO CASH VALUE)`,
    transaction: exchangeTx,
    coinBalance: newCoins,
    diamondBalance: newDiamonds,
    diamondsReceived
  });
});

// FAUCET / SANDBOX TEST COINS TOP-UP
app.post("/api/wallet/recharge", (req, res) => {
  const { userId, amountCoins = 50000 } = req.body;
  const rechargeAmount = Number(amountCoins);

  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  let user = serverUsers[userId];
  if (!user) {
    user = {
      id: userId,
      name: `User ${userId}`,
      username: `user_${userId.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 0,
      diamondBalance: 0,
      vipLevel: 1,
      status: 'Active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    };
    serverUsers[userId] = user;
  }

  const prevBalance = user.coinBalance;
  const newBalance = prevBalance + rechargeAmount;
  user.coinBalance = newBalance;

  const txId = `TX-FAUCET-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fullDateTime = `${new Date().toISOString().split('T')[0]} ${timestamp}`;

  const rechargeTx = {
    id: txId,
    type: 'FAUCET_RECHARGE',
    userId: user.id,
    userName: user.name,
    amountCoins: rechargeAmount,
    amountDiamonds: 0,
    previousCoinBalance: prevBalance,
    newCoinBalance: newBalance,
    status: 'Completed',
    timestamp: fullDateTime,
    notes: `Instant Sandbox Faucet +${rechargeAmount.toLocaleString()} Free TEST COINS`,
    TEST_MODE: true
  };

  serverWalletTransactions.unshift(rechargeTx);

  res.json({
    success: true,
    message: `🎉 Free Test Top-Up: +${rechargeAmount.toLocaleString()} TEST COINS added!`,
    coinBalance: newBalance,
    transaction: rechargeTx
  });
});

// GET ALL WALLET TRANSACTIONS (Filtered)
app.get("/api/wallet/transactions", (req, res) => {
  const { type, userId, search } = req.query;
  let filtered = [...serverWalletTransactions];

  if (type && type !== 'ALL') {
    filtered = filtered.filter(tx => tx.type === type);
  }

  if (userId) {
    filtered = filtered.filter(tx => tx.userId === userId || tx.senderId === userId || tx.receiverId === userId || tx.recipientId === userId);
  }

  if (search) {
    const q = String(search).toLowerCase();
    filtered = filtered.filter(tx => 
      (tx.id || '').toLowerCase().includes(q) ||
      (tx.senderName || '').toLowerCase().includes(q) ||
      (tx.receiverName || '').toLowerCase().includes(q) ||
      (tx.userName || '').toLowerCase().includes(q) ||
      (tx.notes || '').toLowerCase().includes(q)
    );
  }

  res.json({
    success: true,
    totalCount: filtered.length,
    transactions: filtered
  });
});

// ==========================================
// 5.11 REAL MONEY WITHDRAWAL ENGINE (eSewa, Bank, ePay, USD)
// ==========================================

export interface ServerWithdrawalRecord {
  id: string;
  userId: string;
  userName: string;
  method: 'ESEWA' | 'BANK' | 'EPAY' | 'USD';
  methodLabel: string;
  diamondAmount: number;
  fiatAmountUSD: number;
  fiatAmountLocal: number;
  currency: 'USD' | 'NPR' | 'INR';
  exchangeRate: number; // e.g. 1000 diamonds = $1.00 USD
  accountDetails: {
    esewaId?: string;
    accountHolderName?: string;
    bankName?: string;
    accountNumber?: string;
    ifscOrSwiftCode?: string;
    branchName?: string;
    epayId?: string;
    payoutTypeUSD?: 'USDT_TRC20' | 'USDT_ERC20' | 'PAYPAL' | 'WIRE';
    usdtAddress?: string;
    paypalEmail?: string;
  };
  processingFeeUSD: number;
  netPayoutUSD: number;
  netPayoutLocal: number;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'REJECTED' | 'CANCELLED';
  txHash?: string;
  referenceCode: string;
  submittedAt: string;
  processedAt?: string;
  notes?: string;
}

let serverWithdrawalSettings = {
  withdrawalEnabled: true,
  minDiamondsToWithdraw: 5000, // 5,000 Diamonds = $5.00 USD
  maxDiamondsPerWithdrawal: 5000000, // 5,000,000 Diamonds = $5,000 USD
  diamondToUsdRate: 1000, // 1,000 Diamonds = $1.00 USD
  conversionRates: {
    USD: 1.0,
    NPR: 135.0, // 1 USD = 135 NPR (eSewa / Nepal Bank)
    INR: 88.0   // 1 USD = 88 INR (ePay / India)
  },
  supportedMethods: [
    {
      id: 'ESEWA',
      name: 'eSewa Mobile Wallet',
      currency: 'NPR',
      feePercent: 0.0,
      minUSD: 5,
      processingTime: 'Instant / Within 2 hours',
      icon: '📱',
      badge: 'POPULAR (Nepal / South Asia)'
    },
    {
      id: 'BANK',
      name: 'Direct Bank Transfer',
      currency: 'NPR',
      feePercent: 1.5,
      minUSD: 20,
      processingTime: '1 - 24 Hours',
      icon: '🏦',
      badge: 'DOMESTIC & GLOBAL'
    },
    {
      id: 'EPAY',
      name: 'ePay Digital Wallet',
      currency: 'USD',
      feePercent: 1.0,
      minUSD: 10,
      processingTime: 'Instant',
      icon: '💳',
      badge: 'FAST PAYOUT'
    },
    {
      id: 'USD',
      name: 'USD Payout (USDT / Crypto / PayPal)',
      currency: 'USD',
      feePercent: 0.0,
      minUSD: 10,
      processingTime: '5 - 30 Minutes',
      icon: '💵',
      badge: 'GLOBAL NO-FEE (USDT TRC20)'
    }
  ]
};

let serverWithdrawals: ServerWithdrawalRecord[] = [
  {
    id: 'WD-ESEWA-8921',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    method: 'ESEWA',
    methodLabel: 'eSewa Mobile Wallet (9841029384)',
    diamondAmount: 25000,
    fiatAmountUSD: 25.0,
    fiatAmountLocal: 3375.0,
    currency: 'NPR',
    exchangeRate: 1000,
    accountDetails: {
      esewaId: '9841029384',
      accountHolderName: 'Aarav Mehta'
    },
    processingFeeUSD: 0,
    netPayoutUSD: 25.0,
    netPayoutLocal: 3375.0,
    status: 'COMPLETED',
    txHash: 'ESEWA-TXN-99482103',
    referenceCode: 'ESW-99482',
    submittedAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    processedAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    notes: 'Payout successfully settled to eSewa account 9841029384.'
  },
  {
    id: 'WD-USD-5012',
    userId: 'USR-882941',
    userName: 'Aarav Mehta',
    method: 'USD',
    methodLabel: 'USD USDT TRC-20',
    diamondAmount: 50000,
    fiatAmountUSD: 50.0,
    fiatAmountLocal: 50.0,
    currency: 'USD',
    exchangeRate: 1000,
    accountDetails: {
      payoutTypeUSD: 'USDT_TRC20',
      usdtAddress: 'TXn871KaB92MopQrZ21KLa90vVnmQ19p02',
      accountHolderName: 'Aarav Mehta'
    },
    processingFeeUSD: 0,
    netPayoutUSD: 50.0,
    netPayoutLocal: 50.0,
    status: 'COMPLETED',
    txHash: '0x8f27ab194e90812bca01289cfb1900192',
    referenceCode: 'USDT-5012',
    submittedAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    processedAt: new Date(Date.now() - 1000 * 60 * 60 * 23).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    notes: 'USDT TRC20 on-chain transfer verified.'
  }
];

// 1. Get Withdrawal Settings & Live Conversion Rates
app.get("/api/wallet/withdrawal/settings", (req, res) => {
  res.json({
    success: true,
    settings: serverWithdrawalSettings
  });
});

// 2. Process Real Money Withdrawal Request (Atomic Diamond Deduction)
app.post(["/api/wallet/withdraw", "/api/withdrawals/create"], (req, res) => {
  const { 
    userId = 'USR-882941', 
    diamonds, 
    method, 
    accountDetails, 
    notes 
  } = req.body;

  const diamondAmount = Number(diamonds);

  // 1. Check system toggle
  if (!serverWithdrawalSettings.withdrawalEnabled) {
    return res.status(403).json({
      success: false,
      error: "Withdrawal system is temporarily undergoing scheduled maintenance."
    });
  }

  // 2. Validate diamond amount
  if (!diamondAmount || isNaN(diamondAmount) || diamondAmount <= 0) {
    return res.status(400).json({
      success: false,
      error: "Please specify a valid diamond amount to withdraw."
    });
  }

  if (diamondAmount < serverWithdrawalSettings.minDiamondsToWithdraw) {
    return res.status(400).json({
      success: false,
      error: `Minimum withdrawal is ${serverWithdrawalSettings.minDiamondsToWithdraw.toLocaleString()} Diamonds ($${(serverWithdrawalSettings.minDiamondsToWithdraw / serverWithdrawalSettings.diamondToUsdRate).toFixed(2)} USD).`
    });
  }

  if (diamondAmount > serverWithdrawalSettings.maxDiamondsPerWithdrawal) {
    return res.status(400).json({
      success: false,
      error: `Maximum withdrawal limit is ${serverWithdrawalSettings.maxDiamondsPerWithdrawal.toLocaleString()} Diamonds per transaction.`
    });
  }

  // 3. Validate user & balance
  let user = serverUsers[userId];
  if (!user) {
    user = {
      id: userId,
      name: `User ${userId}`,
      username: `user_${userId.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      coinBalance: 245000,
      diamondBalance: 18500,
      vipLevel: 8,
      status: 'Active'
    };
    serverUsers[userId] = user;
  }

  if (user.status === 'Banned' || user.status === 'Suspended') {
    return res.status(403).json({
      success: false,
      error: `Account is currently ${user.status}. Withdrawals are locked.`
    });
  }

  if (user.diamondBalance < diamondAmount) {
    return res.status(400).json({
      success: false,
      error: `Insufficient Diamond balance! You have ${user.diamondBalance.toLocaleString()} Diamonds, but requested ${diamondAmount.toLocaleString()} Diamonds.`
    });
  }

  // 4. Validate Method & Account Details
  const validMethods = ['ESEWA', 'BANK', 'EPAY', 'USD'];
  if (!validMethods.includes(method)) {
    return res.status(400).json({
      success: false,
      error: `Invalid withdrawal method "${method}". Supported methods: eSewa, Bank Transfer, ePay, USD (USDT/PayPal).`
    });
  }

  const details = accountDetails || {};
  let methodLabel = '';
  let currency: 'USD' | 'NPR' | 'INR' = 'USD';

  if (method === 'ESEWA') {
    if (!details.esewaId || details.esewaId.trim().length < 8) {
      return res.status(400).json({
        success: false,
        error: "Please provide a valid eSewa ID / Mobile Number (e.g. 98XXXXXXXX)."
      });
    }
    if (!details.accountHolderName || details.accountHolderName.trim().length < 2) {
      return res.status(400).json({
        success: false,
        error: "Please enter the full account holder name registered on eSewa."
      });
    }
    methodLabel = `eSewa ID: ${details.esewaId} (${details.accountHolderName})`;
    currency = 'NPR';
  } else if (method === 'BANK') {
    if (!details.bankName || details.bankName.trim().length < 2) {
      return res.status(400).json({ success: false, error: "Please enter your Bank Name." });
    }
    if (!details.accountNumber || details.accountNumber.trim().length < 6) {
      return res.status(400).json({ success: false, error: "Please enter a valid Bank Account Number." });
    }
    if (!details.accountHolderName || details.accountHolderName.trim().length < 2) {
      return res.status(400).json({ success: false, error: "Please enter the Bank Account Holder Full Name." });
    }
    methodLabel = `${details.bankName} - A/C: ${details.accountNumber} (${details.accountHolderName})`;
    currency = 'NPR';
  } else if (method === 'EPAY') {
    if (!details.epayId || details.epayId.trim().length < 5) {
      return res.status(400).json({ success: false, error: "Please enter your valid ePay Wallet ID / Registered Phone/Email." });
    }
    if (!details.accountHolderName || details.accountHolderName.trim().length < 2) {
      return res.status(400).json({ success: false, error: "Please enter your full registered name for ePay." });
    }
    methodLabel = `ePay Wallet: ${details.epayId} (${details.accountHolderName})`;
    currency = 'USD';
  } else if (method === 'USD') {
    const payoutType = details.payoutTypeUSD || 'USDT_TRC20';
    if (payoutType === 'PAYPAL') {
      if (!details.paypalEmail || !details.paypalEmail.includes('@')) {
        return res.status(400).json({ success: false, error: "Please enter a valid PayPal Email address." });
      }
      methodLabel = `PayPal: ${details.paypalEmail}`;
    } else {
      if (!details.usdtAddress || details.usdtAddress.trim().length < 20) {
        return res.status(400).json({ success: false, error: "Please enter a valid USDT Wallet Address." });
      }
      methodLabel = `USD USDT (${payoutType.replace('_', ' ')}): ${details.usdtAddress.slice(0, 8)}...${details.usdtAddress.slice(-6)}`;
    }
    currency = 'USD';
  }

  // 5. Calculations
  const fiatAmountUSD = Number((diamondAmount / serverWithdrawalSettings.diamondToUsdRate).toFixed(2));
  const rate = serverWithdrawalSettings.conversionRates[currency] || 1.0;
  const fiatAmountLocal = Number((fiatAmountUSD * rate).toFixed(2));

  const methodConfig = serverWithdrawalSettings.supportedMethods.find(m => m.id === method);
  const feePercent = methodConfig ? methodConfig.feePercent : 0.0;
  const processingFeeUSD = Number(((fiatAmountUSD * feePercent) / 100).toFixed(2));
  const netPayoutUSD = Number((fiatAmountUSD - processingFeeUSD).toFixed(2));
  const netPayoutLocal = Number((netPayoutUSD * rate).toFixed(2));

  // 6. Atomic Balance Mutation
  const prevDiamonds = user.diamondBalance;
  const newDiamonds = prevDiamonds - diamondAmount;
  user.diamondBalance = newDiamonds;

  // 7. Generate Withdrawal Record
  const wdId = `WD-${method}-${Math.floor(100000 + Math.random() * 900000)}`;
  const refCode = `${method.slice(0, 3)}-${Math.floor(10000 + Math.random() * 90000)}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fullDateTime = `${new Date().toISOString().split('T')[0]} ${timestamp}`;

  const withdrawalRecord: ServerWithdrawalRecord = {
    id: wdId,
    userId: user.id,
    userName: user.name,
    method,
    methodLabel,
    diamondAmount,
    fiatAmountUSD,
    fiatAmountLocal,
    currency,
    exchangeRate: serverWithdrawalSettings.diamondToUsdRate,
    accountDetails: details,
    processingFeeUSD,
    netPayoutUSD,
    netPayoutLocal,
    status: 'PROCESSING', // Auto-queued into processing
    referenceCode: refCode,
    submittedAt: fullDateTime,
    txHash: `TXN-${refCode}-${Date.now().toString(36).toUpperCase()}`,
    notes: notes || `Withdrawal payout to ${methodLabel}`
  };

  serverWithdrawals.unshift(withdrawalRecord);

  // 8. Log into wallet transactions ledger
  const walletTx = {
    id: `TX-${wdId}`,
    type: 'Payout',
    userId: user.id,
    userName: user.name,
    amountCoins: 0,
    amountDiamonds: -diamondAmount,
    fiatAmountUSD: netPayoutUSD,
    paymentMethod: methodLabel,
    paymentChannel: method,
    previousBalance: user.coinBalance,
    newBalance: user.coinBalance,
    previousDiamondBalance: prevDiamonds,
    newDiamondBalance: newDiamonds,
    status: 'Processing',
    timestamp: fullDateTime,
    notes: `Withdrew ${diamondAmount.toLocaleString()} Diamonds ➔ $${netPayoutUSD.toFixed(2)} USD (${netPayoutLocal.toLocaleString()} ${currency}) via ${method}`,
    TEST_MODE: false
  };

  serverWalletTransactions.unshift(walletTx);

  res.json({
    success: true,
    message: `✅ Withdrawal request of ${diamondAmount.toLocaleString()} Diamonds ($${netPayoutUSD.toFixed(2)} USD / ${netPayoutLocal.toLocaleString()} ${currency}) submitted successfully!`,
    withdrawal: withdrawalRecord,
    newDiamondBalance: newDiamonds,
    user: {
      id: user.id,
      name: user.name,
      diamondBalance: newDiamonds,
      coinBalance: user.coinBalance
    }
  });
});

// 3. Get User Withdrawal History
app.get("/api/wallet/withdrawals", (req, res) => {
  const { userId } = req.query;
  let list = [...serverWithdrawals];
  if (userId) {
    list = list.filter(w => w.userId === userId);
  }
  res.json({
    success: true,
    totalCount: list.length,
    withdrawals: list
  });
});

// 4. Cancel Pending Withdrawal (Atomic Diamond Refund)
app.post("/api/wallet/withdrawal/cancel", (req, res) => {
  const { withdrawalId, userId } = req.body;

  const wd = serverWithdrawals.find(w => w.id === withdrawalId);
  if (!wd) {
    return res.status(404).json({ success: false, error: "Withdrawal request not found." });
  }

  if (wd.status === 'COMPLETED') {
    return res.status(400).json({ success: false, error: "Cannot cancel a payout that has already completed." });
  }

  if (wd.status === 'CANCELLED') {
    return res.status(400).json({ success: false, error: "This withdrawal request is already cancelled." });
  }

  const user = serverUsers[wd.userId];
  if (user) {
    user.diamondBalance += wd.diamondAmount;
  }

  wd.status = 'CANCELLED';
  wd.notes = 'Cancelled by user. Diamonds refunded to wallet.';

  // Log refund transaction
  serverWalletTransactions.unshift({
    id: `TX-REFUND-${wd.id}`,
    type: 'Admin_Adjustment',
    userId: wd.userId,
    userName: wd.userName,
    amountCoins: 0,
    amountDiamonds: wd.diamondAmount,
    status: 'Completed',
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    notes: `Refund for cancelled withdrawal ${wd.id}`,
    TEST_MODE: false
  });

  res.json({
    success: true,
    message: `Withdrawal ${withdrawalId} cancelled. +${wd.diamondAmount.toLocaleString()} Diamonds refunded.`,
    withdrawal: wd,
    newDiamondBalance: user ? user.diamondBalance : 0
  });
});

// 5. Update Withdrawal Status (Owner / Admin Action)
app.post("/api/owner/withdrawal/status", (req, res) => {
  const { withdrawalId, status, txHash, notes } = req.body;
  const wd = serverWithdrawals.find(w => w.id === withdrawalId);
  if (!wd) {
    return res.status(404).json({ success: false, error: "Withdrawal request not found." });
  }

  wd.status = status;
  if (txHash) wd.txHash = txHash;
  if (notes) wd.notes = notes;
  if (status === 'COMPLETED') {
    wd.processedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  res.json({
    success: true,
    message: `Withdrawal status updated to ${status}.`,
    withdrawal: wd
  });
});

// ==========================================
// 6. PARTY LIVE — 20 SEATS & SIR CROWN
// ==========================================

let serverPartyRoom = {
  id: 'PARTY-2001',
  title: '🎉 DIYO LIVE Royal 20-Seat Lounge & Musical Party',
  ownerId: 'USR-882941',
  ownerName: 'Aarav Mehta (SR Creator)',
  ownerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  crownHolderId: 'USR-882941',
  crownHolderName: 'Aarav Mehta',
  crownTitle: '👑 SIR CROWN',
  totalSeats: 20,
  viewerCount: 2480,
  totalGiftsReceivedCoins: 890000,
  startedAt: '2026-08-15 04:00 UTC',
  status: 'Active',
  category: 'Music & Hangout',
  seats: Array.from({ length: 20 }, (_, idx) => {
    const seatNum = idx + 1;
    if (seatNum === 1) {
      return {
        seatNumber: 1,
        userId: 'USR-882941',
        userName: 'Aarav Mehta',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        isOwner: true,
        hasSirCrown: true, // Only room owner gets Sir Crown
        isMuted: false,
        isCameraOn: true,
        isMicOn: true,
        isLocked: false,
        vipLevel: 8,
        diamondsEarned: 45000,
        joinedAt: 'Room Start'
      };
    } else if (seatNum === 2) {
      return {
        seatNumber: 2,
        userId: 'USR-8002',
        userName: 'Meera Patel',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        isOwner: false,
        hasSirCrown: false,
        isMuted: false,
        isCameraOn: true,
        isMicOn: true,
        isLocked: false,
        vipLevel: 6,
        diamondsEarned: 18000,
        joinedAt: '12m ago'
      };
    } else if (seatNum === 3) {
      return {
        seatNumber: 3,
        userId: 'HST-901',
        userName: 'Ananya Sharma',
        avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
        isOwner: false,
        hasSirCrown: false,
        isMuted: false,
        isCameraOn: false,
        isMicOn: true,
        isLocked: false,
        vipLevel: 7,
        diamondsEarned: 32000,
        joinedAt: '25m ago'
      };
    } else if (seatNum === 4) {
      return {
        seatNumber: 4,
        userId: 'USR-8004',
        userName: 'David Miller',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        isOwner: false,
        hasSirCrown: false,
        isMuted: true,
        isCameraOn: false,
        isMicOn: false,
        isLocked: false,
        vipLevel: 4,
        diamondsEarned: 5200,
        joinedAt: '40m ago'
      };
    } else if (seatNum === 5) {
      return {
        seatNumber: 5,
        userId: 'HST-904',
        userName: 'Elena Rostova',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
        isOwner: false,
        hasSirCrown: false,
        isMuted: false,
        isCameraOn: true,
        isMicOn: true,
        isLocked: false,
        vipLevel: 5,
        diamondsEarned: 12400,
        joinedAt: '8m ago'
      };
    }
    return {
      seatNumber: seatNum,
      isOwner: false,
      hasSirCrown: false,
      isMuted: false,
      isCameraOn: false,
      isMicOn: false,
      isLocked: false
    };
  })
};

// 6.1 Get Party Live Room State
app.get("/api/party-live/room", (req, res) => {
  res.json({
    success: true,
    room: serverPartyRoom
  });
});

// 6.2 Party Seat Actions (Take Seat, Leave Seat, Mute, Transfer Crown)
app.post("/api/party-live/seat/action", (req, res) => {
  const { action, seatNumber, user, targetSeat } = req.body;
  const seatNum = Number(seatNumber);

  if (action === 'TAKE_SEAT') {
    if (seatNum < 1 || seatNum > 20) {
      return res.status(400).json({ success: false, error: "Invalid seat number (1-20)." });
    }

    const currentSeat = serverPartyRoom.seats[seatNum - 1];
    if (currentSeat.userId && currentSeat.userId !== user?.id) {
      return res.status(400).json({ success: false, error: `Seat #${seatNum} is already occupied.` });
    }

    // Is this user the room owner?
    const isOwner = user?.id === serverPartyRoom.ownerId;
    // Seat 1 is strictly for room owner, or if owner takes seat 1
    if (seatNum === 1 && !isOwner) {
      return res.status(403).json({ success: false, error: "Seat #1 is reserved exclusively for the 👑 SIR CROWN Room Owner." });
    }

    serverPartyRoom.seats[seatNum - 1] = {
      seatNumber: seatNum,
      userId: user.id,
      userName: user.name,
      avatar: user.avatar,
      isOwner: isOwner,
      hasSirCrown: isOwner && seatNum === 1,
      isMuted: false,
      isCameraOn: true,
      isMicOn: true,
      isLocked: false,
      vipLevel: user.vipLevel || 1,
      diamondsEarned: 0,
      joinedAt: 'Just now'
    };
  } else if (action === 'LEAVE_SEAT') {
    if (seatNum < 1 || seatNum > 20) {
      return res.status(400).json({ success: false, error: "Invalid seat number." });
    }
    const isOwner = serverPartyRoom.seats[seatNum - 1]?.isOwner;
    serverPartyRoom.seats[seatNum - 1] = {
      seatNumber: seatNum,
      isOwner: false,
      hasSirCrown: false,
      isMuted: false,
      isCameraOn: false,
      isMicOn: false,
      isLocked: false
    };
  } else if (action === 'TOGGLE_MUTE') {
    if (serverPartyRoom.seats[seatNum - 1]) {
      serverPartyRoom.seats[seatNum - 1].isMuted = !serverPartyRoom.seats[seatNum - 1].isMuted;
      serverPartyRoom.seats[seatNum - 1].isMicOn = !serverPartyRoom.seats[seatNum - 1].isMuted;
    }
  } else if (action === 'TOGGLE_CAMERA') {
    if (serverPartyRoom.seats[seatNum - 1]) {
      serverPartyRoom.seats[seatNum - 1].isCameraOn = !serverPartyRoom.seats[seatNum - 1].isCameraOn;
    }
  } else if (action === 'TRANSFER_CROWN') {
    // Official Ownership transfer -> Sir Crown moves to new owner
    const newOwnerUser = user;
    if (newOwnerUser && newOwnerUser.id) {
      serverPartyRoom.ownerId = newOwnerUser.id;
      serverPartyRoom.ownerName = newOwnerUser.name;
      serverPartyRoom.crownHolderId = newOwnerUser.id;
      serverPartyRoom.crownHolderName = newOwnerUser.name;
      
      // Update seat 1
      serverPartyRoom.seats[0] = {
        seatNumber: 1,
        userId: newOwnerUser.id,
        userName: newOwnerUser.name,
        avatar: newOwnerUser.avatar,
        isOwner: true,
        hasSirCrown: true,
        isMuted: false,
        isCameraOn: true,
        isMicOn: true,
        isLocked: false,
        vipLevel: newOwnerUser.vipLevel || 8,
        diamondsEarned: 50000,
        joinedAt: 'Transferred Ownership'
      };
    }
  }

  res.json({
    success: true,
    room: serverPartyRoom
  });
});


// ==========================================
// 7. HOST TYPES, TAGS & FRAMES MANAGEMENT
// ==========================================
let serverAuditLogs: any[] = [];

const FRAME_MAP: Record<string, { frameId: string; frameName: string; previewUrl: string }> = {
  CELEBRATE: {
    frameId: 'FRM-HT-01',
    frameName: 'Celebrate Host Frame',
    previewUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150'
  },
  TALENT: {
    frameId: 'FRM-HT-02',
    frameName: 'Talent Host Frame',
    previewUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150'
  },
  SINGER: {
    frameId: 'FRM-HT-03',
    frameName: 'Singer Host Frame',
    previewUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150'
  },
  NORMAL: {
    frameId: 'FRM-HT-04',
    frameName: 'Normal Host Frame',
    previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150'
  }
};

app.get("/api/hosts/types", (req, res) => {
  res.json({
    success: true,
    hostTypes: [
      {
        tag: 'CELEBRATE',
        name: 'Celebrate Host',
        tagLabel: '🎉 CELEBRATE HOST',
        badgeIcon: '🎉',
        frameName: 'Celebrate Host Frame',
        frameId: 'FRM-HT-01'
      },
      {
        tag: 'TALENT',
        name: 'Talent Host',
        tagLabel: '⭐ TALENT HOST',
        badgeIcon: '⭐',
        frameName: 'Talent Host Frame',
        frameId: 'FRM-HT-02'
      },
      {
        tag: 'SINGER',
        name: 'Singer Host',
        tagLabel: '🎤 SINGER HOST',
        badgeIcon: '🎤',
        frameName: 'Singer Host Frame',
        frameId: 'FRM-HT-03'
      },
      {
        tag: 'NORMAL',
        name: 'Normal Host',
        tagLabel: '👤 NORMAL HOST',
        badgeIcon: '👤',
        frameName: 'Normal Host Frame',
        frameId: 'FRM-HT-04'
      }
    ]
  });
});

app.post("/api/hosts/assign-type", (req, res) => {
  const { hostId, hostTag, operatorRole = 'OWNER', operatorId = 'OWNER-001' } = req.body;
  
  // Security check: only Owner / Admin can assign host types
  const allowedRoles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'Owner', 'Super Admin', 'Admin'];
  if (!allowedRoles.includes(operatorRole)) {
    return res.status(403).json({
      success: false,
      error: "Unauthorized: Only authorized Owner/Admin accounts can assign Host Types."
    });
  }

  const validTags = ['CELEBRATE', 'TALENT', 'SINGER', 'NORMAL'];
  const normalizedTag = (hostTag || 'NORMAL').toUpperCase().replace(/\s+HOST$/i, '').trim();

  if (!validTags.includes(normalizedTag)) {
    return res.status(400).json({
      success: false,
      error: `Invalid Host Tag. Allowed values: ${validTags.join(', ')}`
    });
  }

  const targetHost = serverHosts[hostId];
  if (!targetHost) {
    // Create or mock host record if missing
    serverHosts[hostId] = {
      id: hostId,
      name: hostId.replace('HST-', 'Host '),
      username: `host_${hostId.toLowerCase()}`,
      agencyId: 'AG-01',
      agencyName: 'Starlight Elite Talent',
      managerId: 'MGR-301',
      managerName: 'Rahul Verma',
      status: 'Active',
      onlineStatus: 'Online',
      liveStatus: 'Live',
      followers: 12000,
      giftsReceived: 5400,
      diamonds: 320000,
      earningsUSD: 320.00,
      totalLiveHours: 85,
      lastLive: 'Just now',
      verificationStatus: 'Verified',
      streamCategory: 'entertainment',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      hostTag: normalizedTag as any,
      hostTypeId: `HT-${normalizedTag}`,
      avatarFrameId: FRAME_MAP[normalizedTag]?.frameId,
      avatarFrameUrl: FRAME_MAP[normalizedTag]?.previewUrl,
      hostLevel: 5,
      xp: 24000
    };
  } else {
    targetHost.hostTag = normalizedTag as any;
    targetHost.hostTypeId = `HT-${normalizedTag}`;
    targetHost.avatarFrameId = FRAME_MAP[normalizedTag]?.frameId;
    targetHost.avatarFrameUrl = FRAME_MAP[normalizedTag]?.previewUrl;
  }

  // Also synchronize user profile if user exists with same ID or username
  if (serverUsers[hostId]) {
    serverUsers[hostId].hostTag = normalizedTag as any;
    serverUsers[hostId].avatarFrameId = FRAME_MAP[normalizedTag]?.frameId;
    serverUsers[hostId].avatarFrameUrl = FRAME_MAP[normalizedTag]?.previewUrl;
  }

  // Record audit log
  serverAuditLogs.unshift({
    id: `AUDIT-HT-${Date.now()}`,
    operatorId: operatorId,
    operatorName: 'Authorized Admin',
    operatorRole: operatorRole as any,
    action: 'ASSIGN_HOST_TYPE',
    actionType: 'HOST_MANAGEMENT',
    targetId: hostId,
    targetRole: 'HOST',
    details: `Assigned official Host Type ${normalizedTag} (Frame: ${FRAME_MAP[normalizedTag]?.frameName}) to Host ${hostId}`,
    ipAddress: '127.0.0.1 (Authorized)',
    status: 'SUCCESS',
    timestamp: new Date().toISOString()
  });

  return res.json({
    success: true,
    message: `✅ Host ${hostId} successfully assigned Host Type: ${normalizedTag}`,
    host: serverHosts[hostId],
    assignedTag: normalizedTag,
    assignedFrame: FRAME_MAP[normalizedTag]
  });
});

app.get("/api/hosts/:hostId", (req, res) => {
  const host = serverHosts[req.params.hostId];
  if (!host) {
    return res.status(404).json({ success: false, error: "Host not found." });
  }
  res.json({ success: true, host });
});

// =========================================================================
// 8. AUTOMATIC UNIQUE 7-DIGIT SEQUENTIAL USER ID ENGINE & AUTH LINKING
// =========================================================================

// 8.1 Public / Client counter check
app.get("/api/auth/current-counter", (req, res) => {
  res.json({
    success: true,
    currentCounter: serverUserIdCounter,
    latestUserId: String(serverUserIdCounter).padStart(7, '0'),
    nextAvailableId: String(serverUserIdCounter + 1).padStart(7, '0'),
    totalRegisteredUsers: Object.keys(serverUsers).length,
    startingId: '0000001',
    idFormat: '7-Digit Sequential (0000001 - 9999999)'
  });
});

// 8.2 Admin User ID & Registration Statistics
app.get("/api/admin/user-id-stats", (req, res) => {
  const usersList = Object.values(serverUsers);
  res.json({
    success: true,
    currentCounter: serverUserIdCounter,
    latestUserId: String(serverUserIdCounter).padStart(7, '0'),
    nextAvailableId: String(serverUserIdCounter + 1).padStart(7, '0'),
    startingId: '0000001',
    idFormat: '7-Digit Sequential (0000001 - 9999999)',
    totalRegisteredUsers: usersList.length,
    activeUsersCount: usersList.filter(u => u.status === 'Active').length,
    mutedUsersCount: usersList.filter(u => u.status === 'Muted').length,
    bannedUsersCount: usersList.filter(u => u.status === 'Banned' || u.status === 'Suspended').length,
    totalDeletedAccounts: serverDeletedUserIds.length,
    deletedUserIdsAudit: serverDeletedUserIds,
    isPermanentSequential: true,
    reuseAllowed: false,
    rules: {
      backendGenerated: true,
      clientChoiceForbidden: true,
      sequentialDigits: 7,
      authLinkingPreserved: true,
      deletedIdsNeverReused: true
    }
  });
});

// 8.3 Backend Registration or Login with Auth Linking
app.post("/api/auth/register-or-login", (req, res) => {
  const {
    provider = 'google', // 'google' | 'phone' | 'facebook' | 'email'
    identifier, // email or phone or social account ID
    email,
    phone,
    name,
    avatar,
    countryCode = 'NP',
    countryFlag = '🇳🇵',
    countryName = 'Nepal',
    bio
  } = req.body;

  // Determine lookup key for auth linking
  const cleanEmail = email ? String(email).trim().toLowerCase() : '';
  const cleanPhone = phone ? String(phone).replace(/[^0-9+]/g, '') : '';
  const cleanIdentifier = identifier ? String(identifier).trim().toLowerCase() : (cleanEmail || cleanPhone);

  if (!cleanIdentifier && !cleanEmail && !cleanPhone && !name) {
    return res.status(400).json({ success: false, error: "Identifier or credentials required." });
  }

  // 1. Check if auth is already linked to an existing account
  let linkedUserId: string | null = null;

  if (cleanEmail && serverAuthAccounts[cleanEmail]) {
    linkedUserId = serverAuthAccounts[cleanEmail].userId;
  } else if (cleanPhone && serverAuthAccounts[cleanPhone]) {
    linkedUserId = serverAuthAccounts[cleanPhone].userId;
  } else if (cleanIdentifier && serverAuthAccounts[cleanIdentifier]) {
    linkedUserId = serverAuthAccounts[cleanIdentifier].userId;
  } else {
    // Check direct match in serverUsers by email or phone
    const existing = Object.values(serverUsers).find(
      u => (cleanEmail && u.email && u.email.toLowerCase() === cleanEmail) ||
           (cleanPhone && u.phone && u.phone.replace(/[^0-9]/g, '') === cleanPhone.replace(/[^0-9]/g, ''))
    );
    if (existing) {
      linkedUserId = existing.id;
    }
  }

  // Case A: Existing account found -> DO NOT create new ID. Keep original permanent 7-digit ID.
  if (linkedUserId && serverUsers[linkedUserId]) {
    const existingUser = serverUsers[linkedUserId];
    existingUser.lastActive = 'Just now';
    existingUser.lastLogin = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (avatar && !existingUser.avatar) existingUser.avatar = avatar;

    // Ensure mapping exists
    if (cleanEmail) serverAuthAccounts[cleanEmail] = { userId: existingUser.id, provider, identifier: cleanEmail, linkedAt: existingUser.registrationDate || '2025-01-20' };
    if (cleanPhone) serverAuthAccounts[cleanPhone] = { userId: existingUser.id, provider, identifier: cleanPhone, linkedAt: existingUser.registrationDate || '2025-01-20' };

    return res.json({
      success: true,
      isNewUser: false,
      message: `Welcome back, ${existingUser.name}! Account retrieved with permanent ID #${existingUser.id}.`,
      user: existingUser,
      assignedId: existingUser.id
    });
  }

  // Case B: Brand New Registration -> Atomically generate next 7-digit sequential ID
  serverUserIdCounter += 1;
  const new7DigitId = String(serverUserIdCounter).padStart(7, '0');

  const defaultAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80'
  ];
  const chosenAvatar = avatar || defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];
  const displayName = name || (cleanEmail ? cleanEmail.split('@')[0] : `SR Star ${new7DigitId.slice(-4)}`);
  const displayUsername = (displayName).toLowerCase().replace(/[^a-z0-9]/g, '_') + `_${new7DigitId.slice(-3)}`;

  const newUserRecord: ServerUserRecord = {
    id: new7DigitId,
    name: displayName,
    username: displayUsername,
    email: cleanEmail || `${new7DigitId}@srlive.io`,
    phone: cleanPhone || '',
    coinBalance: 0, // Genuine 100% Zero-State fresh user
    diamondBalance: 0,
    boltBalance: 0,
    vipLevel: 0,
    svipLevel: 0,
    userLevel: 1,
    role: 'USER',
    status: 'Active',
    avatar: chosenAvatar,
    countryCode: countryCode || 'NP',
    countryFlag: countryFlag || '🇳🇵',
    countryName: countryName || 'Nepal',
    bio: bio || 'Live • Laugh • Share with DIYO LIVE Global Community ❤️',
    joinedDate: new Date().toISOString().split('T')[0],
    registrationDate: new Date().toISOString().split('T')[0],
    lastActive: 'Just now',
    lastLogin: 'Just now',
    totalSpentCoins: 0,
    totalRechargedUSD: 0,
    deviceType: 'Android APK'
  };

  serverUsers[new7DigitId] = newUserRecord;

  // Register in auth linking map
  const linkDate = new Date().toISOString().split('T')[0];
  if (cleanEmail) serverAuthAccounts[cleanEmail] = { userId: new7DigitId, provider, identifier: cleanEmail, linkedAt: linkDate };
  if (cleanPhone) serverAuthAccounts[cleanPhone] = { userId: new7DigitId, provider, identifier: cleanPhone, linkedAt: linkDate };
  if (cleanIdentifier) serverAuthAccounts[cleanIdentifier] = { userId: new7DigitId, provider, identifier: cleanIdentifier, linkedAt: linkDate };

  return res.json({
    success: true,
    isNewUser: true,
    message: `🎉 New account registered! Assigned permanent sequential User ID #${new7DigitId}.`,
    user: newUserRecord,
    assignedId: new7DigitId,
    sequentialNumber: serverUserIdCounter
  });
});

// 8.4 User Search by 7-digit ID, username, or name
app.get("/api/users/search", (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  if (!q) {
    return res.json({ success: true, users: Object.values(serverUsers) });
  }

  // Exact 7-digit match or partial match
  const results = Object.values(serverUsers).filter(u => {
    return u.id === q ||
           u.id.includes(q) ||
           u.username.toLowerCase().includes(q) ||
           u.name.toLowerCase().includes(q) ||
           (u.email && u.email.toLowerCase().includes(q)) ||
           (u.phone && u.phone.includes(q));
  });

  res.json({
    success: true,
    query: q,
    count: results.length,
    users: results
  });
});

// 8.5 Get Single User Dossier by ID
app.get("/api/users/:userId", (req, res) => {
  const { userId } = req.params;
  const normalizedKey = String(userId).trim();
  const paddedKey = /^\d+$/.test(normalizedKey) ? normalizedKey.padStart(7, '0') : normalizedKey;

  const user = serverUsers[normalizedKey] || serverUsers[paddedKey] || Object.values(serverUsers).find(
    u => u.username.toLowerCase() === normalizedKey.toLowerCase()
  );

  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID "${userId}" not found.` });
  }

  res.json({ success: true, user });
});

// 8.6 Admin Delete / Deactivate User (Strict Rule: ID is NEVER recycled)
app.post("/api/admin/users/delete", (req, res) => {
  const { userId, operatorRole = 'OWNER' } = req.body;
  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  const paddedKey = /^\d+$/.test(String(userId).trim()) ? String(userId).trim().padStart(7, '0') : String(userId).trim();
  const user = serverUsers[paddedKey];

  if (!user) {
    return res.status(404).json({ success: false, error: `User ID #${userId} not found.` });
  }

  // Record deleted ID in audit trail to guarantee it is NEVER recycled
  if (!serverDeletedUserIds.includes(user.id)) {
    serverDeletedUserIds.push(user.id);
  }

  // Delete from active serverUsers
  delete serverUsers[user.id];

  // Note: serverUserIdCounter is INTENTIONALLY NOT decremented
  res.json({
    success: true,
    message: `Account #${user.id} (${user.name}) deleted. ID #${user.id} retired permanently and will NEVER be reused.`,
    deletedUserId: user.id,
    currentCounterRemains: serverUserIdCounter,
    nextAvailableIdRemains: String(serverUserIdCounter + 1).padStart(7, '0')
  });
});

// 8.7 Admin Update User Status
app.post("/api/admin/users/status", (req, res) => {
  const { userId, status } = req.body;
  const paddedKey = /^\d+$/.test(String(userId).trim()) ? String(userId).trim().padStart(7, '0') : String(userId).trim();
  const user = serverUsers[paddedKey];

  if (!user) {
    return res.status(404).json({ success: false, error: `User ID #${userId} not found.` });
  }

  user.status = status;
  res.json({
    success: true,
    message: `User #${user.id} status updated to ${status}.`,
    user
  });
});

// 8.8 Admin & Super Admin Instant Ban Power
app.post("/api/admin/users/ban", (req, res) => {
  const { userId, reason = 'Terms of Service Violation', duration = 'Permanent', operator = 'Admin / Super Admin' } = req.body;
  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  const paddedKey = /^\d+$/.test(String(userId).trim()) ? String(userId).trim().padStart(7, '0') : String(userId).trim();
  const user = serverUsers[paddedKey] || Object.values(serverUsers).find(
    u => u.username.toLowerCase() === String(userId).toLowerCase() || u.id === String(userId)
  );

  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID #${userId} not found in database.` });
  }

  user.status = 'Banned';
  (user as any).banReason = reason;
  (user as any).banDuration = duration;
  (user as any).bannedAt = new Date().toISOString();
  (user as any).bannedBy = operator;

  res.json({
    success: true,
    message: `⛔ User #${user.id} (${user.name}) has been BANNED successfully by ${operator}. Reason: ${reason}`,
    user
  });
});

// 8.9 Admin & Super Admin Instant Unban Power
app.post("/api/admin/users/unban", (req, res) => {
  const { userId, operator = 'Admin / Super Admin' } = req.body;
  if (!userId) {
    return res.status(400).json({ success: false, error: "User ID is required." });
  }

  const paddedKey = /^\d+$/.test(String(userId).trim()) ? String(userId).trim().padStart(7, '0') : String(userId).trim();
  const user = serverUsers[paddedKey] || Object.values(serverUsers).find(
    u => u.username.toLowerCase() === String(userId).toLowerCase() || u.id === String(userId)
  );

  if (!user) {
    return res.status(404).json({ success: false, error: `User with ID #${userId} not found in database.` });
  }

  user.status = 'Active';
  delete (user as any).banReason;
  delete (user as any).banDuration;
  (user as any).unbannedAt = new Date().toISOString();
  (user as any).unbannedBy = operator;

  res.json({
    success: true,
    message: `✅ User #${user.id} (${user.name}) has been UNBANNED and restored to Active status by ${operator}.`,
    user
  });
});

// 8.10 Get Banned Users Registry
app.get("/api/admin/users/banned", (req, res) => {
  const banned = Object.values(serverUsers).filter(u => u.status === 'Banned' || u.status === 'Suspended');
  res.json({
    success: true,
    count: banned.length,
    bannedUsers: banned
  });
});


async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DIYO LIVE Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
