import React, { useState, useRef, useEffect } from 'react';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Monitor, 
  Play, 
  Square, 
  Radio, 
  Sliders, 
  Layers, 
  Download, 
  Copy, 
  Check, 
  Eye, 
  EyeOff, 
  Sparkles, 
  Activity, 
  Settings, 
  Volume2,
  Tv,
  AlertCircle
} from 'lucide-react';
import { playSoundFX } from '../utils/audioSynth';
import confetti from 'canvas-confetti';
import { HOST_TYPE_DEFINITIONS } from '../data/mockOwnerData';
import { HostTagType } from '../types/ownerTypes';
import { HostTagBadge } from './HostTagBadge';
import { Award, Zap } from 'lucide-react';

export const HostLevelProgress: React.FC<{
  hostTag?: HostTagType;
  level?: number;
  xp?: number;
  giftsReceived?: number;
  onSimulateGift?: (xpGain: number) => void;
}> = ({
  hostTag = 'CELEBRATE',
  level = 7,
  xp: initialXp = 45000,
  giftsReceived: initialGifts = 1240,
  onSimulateGift
}) => {
  const [currentLevel, setCurrentLevel] = useState(level);
  const [currentXp, setCurrentXp] = useState(initialXp);
  const [totalGifts, setTotalGifts] = useState(initialGifts);

  const hostType = HOST_TYPE_DEFINITIONS.find(t => t.tag === hostTag) || HOST_TYPE_DEFINITIONS[0];
  const xpPerLevel = 15000;
  const nextLevelXp = currentLevel * xpPerLevel;
  const currentTierXp = currentXp % xpPerLevel;
  const progressPercent = Math.min(100, Math.round((currentTierXp / xpPerLevel) * 100));

  const handleTestGiftXP = (amount: number) => {
    const newXp = currentXp + amount;
    const newLevel = Math.min(10, 1 + Math.floor(newXp / xpPerLevel));
    setCurrentXp(newXp);
    setTotalGifts(prev => prev + 1);

    if (newLevel > currentLevel) {
      setCurrentLevel(newLevel);
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
      playSoundFX('reward');
    } else {
      playSoundFX('coin');
    }

    if (onSimulateGift) {
      onSimulateGift(amount);
    }
  };

  return (
    <div className={`rounded-2xl border p-4 ${hostType.badgeBg} ${hostType.badgeBorder} shadow-xl space-y-3`}>
      {/* Header */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="text-xl">{hostType.badgeIcon}</span>
          <div>
            <div className="flex items-center gap-1.5">
              <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border bg-black/40 ${hostType.badgeBorder} ${hostType.badgeText}`}>
                {hostType.tagLabel}
              </span>
              <span className="text-xs font-black text-white px-2 py-0.5 bg-rose-600/30 border border-rose-500/40 rounded-full">
                Level {currentLevel} / 10
              </span>
            </div>
            <p className="text-[11px] text-neutral-300 font-medium mt-0.5">Broadcaster Mastery & Gift Progression</p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-bold text-neutral-400 uppercase block">Gifts Received</span>
          <span className="text-sm font-black text-amber-300 font-mono">🎁 {totalGifts.toLocaleString()}</span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[11px] font-mono">
          <span className="text-neutral-300 font-bold">{currentTierXp.toLocaleString()} XP</span>
          <span className="text-amber-400 font-bold">{progressPercent}% • Next Lvl at {xpPerLevel.toLocaleString()} XP</span>
        </div>
        <div className="w-full bg-neutral-950/80 rounded-full h-3 p-0.5 border border-white/10 overflow-hidden">
          <div 
            className="h-full rounded-full bg-gradient-to-r from-amber-500 via-rose-500 to-pink-500 transition-all duration-500 shadow-md"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Level Perks & Test Gift Trigger */}
      <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/10 flex-wrap text-[11px]">
        <div className="flex items-center gap-1.5 text-neutral-300">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>Frame Aura: <span className="font-bold text-white">{hostType.frameName.split(' ')[0]}</span></span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => handleTestGiftXP(1000)}
            className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg font-bold text-[10px] transition-all"
            title="Receive test Rose Gift (+1,000 XP)"
          >
            +1K XP (Rose 🌹)
          </button>
          <button
            onClick={() => handleTestGiftXP(5000)}
            className="px-2.5 py-1 bg-rose-600/30 hover:bg-rose-600/40 text-rose-300 border border-rose-500/40 rounded-lg font-bold text-[10px] transition-all"
            title="Receive test Rocket Gift (+5,000 XP)"
          >
            +5K XP (Rocket 🚀)
          </button>
        </div>
      </div>
    </div>
  );
};

export interface BroadcastStudioProps {
  onGoLive?: (channel: any) => void;
}

export const BroadcastStudio: React.FC<BroadcastStudioProps> = ({ onGoLive }) => {
  // Broadcaster Tag & Level State
  const [broadcasterTag, setBroadcasterTag] = useState<HostTagType>('CELEBRATE');
  const [broadcasterLevel, setBroadcasterLevel] = useState(7);
  const [broadcasterXp, setBroadcasterXp] = useState(45000);
  const [giftsCount, setGiftsCount] = useState(1240);

  // Media streams
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [isLiveBroadcasting, setIsLiveBroadcasting] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);

  // Studio Controls
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [layoutMode, setLayoutMode] = useState<'camera' | 'screen' | 'pip' | 'sidebyside'>('camera');
  
  // Lower third overlay
  const [lowerThirdEnabled, setLowerThirdEnabled] = useState(true);
  const [lowerThirdHeadline, setLowerThirdHeadline] = useState('🔴 DIYO LIVE SPECIAL: AI & Creative Tech Showcase');
  const [lowerThirdSubtext, setLowerThirdSubtext] = useState('Broadcasting worldwide from DIYO LIVE Creator Studio');

  // Broadcast settings
  const [streamTitle, setStreamTitle] = useState('My Ultra HD Live Broadcast');
  const [category, setCategory] = useState('tech');
  const [resolution, setResolution] = useState('1080p60 (8.5 Mbps)');
  const [streamKey] = useState('live_sr_' + Math.random().toString(36).substring(2, 12));
  const [showStreamKey, setShowStreamKey] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  // Time & audio VU meter
  const [broadcastSeconds, setBroadcastSeconds] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);

  const videoPreviewRef = useRef<HTMLVideoElement | null>(null);
  const screenPreviewRef = useRef<HTMLVideoElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const animationFrameRef = useRef<number | null>(null);

  // Request camera and microphone access
  const startCamera = async () => {
    try {
      if (cameraStream) {
        cameraStream.getTracks().forEach((t) => t.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 1280, height: 720 },
        audio: true
      });
      setCameraStream(stream);
      if (videoPreviewRef.current) {
        videoPreviewRef.current.srcObject = stream;
      }
      setupAudioMeter(stream);
    } catch (err) {
      console.warn('Could not access camera/mic:', err);
    }
  };

  // Screen share capture
  const startScreenShare = async () => {
    try {
      if (screenStream) {
        screenStream.getTracks().forEach((t) => t.stop());
      }
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      });
      setScreenStream(stream);
      if (screenPreviewRef.current) {
        screenPreviewRef.current.srcObject = stream;
      }
      setLayoutMode('screen');
      stream.getVideoTracks()[0].onended = () => {
        setScreenStream(null);
        setLayoutMode('camera');
      };
    } catch (err) {
      console.warn('Screen share cancelled or failed:', err);
    }
  };

  // Real-time Audio Level VU meter
  const setupAudioMeter = (stream: MediaStream) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 32;
      source.connect(analyser);

      const buffer = new Uint8Array(analyser.frequencyBinCount);

      const updateMeter = () => {
        analyser.getByteFrequencyData(buffer);
        let sum = 0;
        for (let i = 0; i < buffer.length; i++) {
          sum += buffer[i];
        }
        const avg = sum / buffer.length;
        setAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
        animationFrameRef.current = requestAnimationFrame(updateMeter);
      };
      updateMeter();
    } catch {
      // Ignore
    }
  };

  // Toggle Video/Audio tracks
  const toggleCameraTrack = () => {
    if (cameraStream) {
      const vTrack = cameraStream.getVideoTracks()[0];
      if (vTrack) {
        vTrack.enabled = !vTrack.enabled;
        setVideoEnabled(vTrack.enabled);
      }
    }
  };

  const toggleMicTrack = () => {
    if (cameraStream) {
      const aTrack = cameraStream.getAudioTracks()[0];
      if (aTrack) {
        aTrack.enabled = !aTrack.enabled;
        setAudioEnabled(aTrack.enabled);
      }
    }
  };

  // Start / End Live Broadcast
  const handleToggleBroadcast = () => {
    if (!isLiveBroadcasting) {
      setIsLiveBroadcasting(true);
      setBroadcastSeconds(0);
      playSoundFX('superchat');
      confetti({ particleCount: 50, spread: 80 });

      if (onGoLive) {
        const newStreamChannel = {
          id: 'host-live-' + Date.now(),
          title: streamTitle || 'My Ultra HD Live Broadcast',
          broadcasterName: 'Salam Star Host',
          broadcasterAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
          broadcasterBadge: 'Verified' as const,
          broadcasterFollowers: '124K',
          category: category as any,
          viewersCount: 1,
          likesCount: 0,
          streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
          fallbackVideoUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
          isLive: true,
          startedAt: 'Just now',
          resolution: resolution.split(' ')[0],
          fps: 60,
          bitrate: '8.5 Mbps',
          description: lowerThirdHeadline,
          tags: ['Live', 'SRLive', category, broadcasterTag],
          bannerUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=1200&auto=format&fit=crop&q=80',
          thumbnailUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80',
          multiCamAngles: [],
          hostTag: broadcasterTag
        };
        onGoLive(newStreamChannel);
      }
    } else {
      setIsLiveBroadcasting(false);
      playSoundFX('notification');
    }
  };

  // Start / Stop Local Recording
  const handleToggleRecording = () => {
    const streamToRecord = screenStream || cameraStream;
    if (!streamToRecord) {
      alert('Please enable camera or screen share first to record!');
      return;
    }

    if (!isRecording) {
      recordedChunksRef.current = [];
      try {
        const recorder = new MediaRecorder(streamToRecord, {
          mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
            ? 'video/webm;codecs=vp9'
            : 'video/webm'
        });

        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) {
            recordedChunksRef.current.push(e.data);
          }
        };

        recorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          setRecordedVideoUrl(url);
          playSoundFX('notification');
        };

        recorder.start(1000);
        mediaRecorderRef.current = recorder;
        setIsRecording(true);
        playSoundFX('click');
      } catch (err) {
        console.error('Recording error:', err);
      }
    } else {
      if (mediaRecorderRef.current) {
        mediaRecorderRef.current.stop();
        setIsRecording(false);
      }
    }
  };

  // Broadcast duration timer
  useEffect(() => {
    let interval: any = null;
    if (isLiveBroadcasting) {
      interval = setInterval(() => {
        setBroadcastSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isLiveBroadcasting]);

  // Clean up media on unmount
  useEffect(() => {
    startCamera();
    return () => {
      if (cameraStream) cameraStream.getTracks().forEach((t) => t.stop());
      if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  const formatTimer = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs > 0 ? hrs + ':' : ''}${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const copyKey = () => {
    navigator.clipboard.writeText(streamKey);
    setCopiedKey(true);
    playSoundFX('notification');
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      {/* Studio Header Banner */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-rose-950/40 border border-neutral-800 rounded-3xl p-5 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-600 to-red-500 flex items-center justify-center shadow-lg shadow-rose-600/30">
            <Radio className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-black text-white font-['Outfit'] tracking-wide">
                SR BROADCAST STUDIO
              </h2>
              <HostTagBadge tag={broadcasterTag} size="xs" />
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">
                PRO CREATOR ROOM
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              Live WebRTC broadcast encoder, multi-source compositor & local session recorder
            </p>
          </div>
        </div>

        {/* Live Status & Master Broadcast Button */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          {isLiveBroadcasting && (
            <div className="flex items-center gap-2 bg-neutral-950 px-3.5 py-1.5 rounded-xl border border-rose-500/50 shadow-lg">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span className="text-xs font-mono font-bold text-rose-400">
                LIVE ON AIR: {formatTimer(broadcastSeconds)}
              </span>
            </div>
          )}

          <button
            id="btn-studio-golive"
            onClick={handleToggleBroadcast}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-xl ${
              isLiveBroadcasting
                ? 'bg-red-600 hover:bg-red-700 text-white shadow-red-600/40 animate-pulse'
                : 'bg-gradient-to-r from-rose-600 via-red-600 to-amber-500 hover:from-rose-500 hover:to-amber-400 text-white shadow-rose-600/30'
            }`}
          >
            {isLiveBroadcasting ? (
              <>
                <Square className="w-4 h-4 fill-white" />
                <span>End Broadcast</span>
              </>
            ) : (
              <>
                <Radio className="w-4 h-4" />
                <span>Go Live Now</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Broadcaster Level Progress Component */}
      <HostLevelProgress 
        hostTag={broadcasterTag} 
        level={broadcasterLevel} 
        xp={broadcasterXp}
        giftsReceived={giftsCount}
        onSimulateGift={(gain) => {
          setBroadcasterXp(prev => prev + gain);
          setGiftsCount(prev => prev + 1);
        }}
      />

      {/* Main Studio Grid: Monitor on Left, Control Room on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Broadcast Monitor Canvas Viewport */}
        <div className="lg:col-span-2 space-y-4">
          <div className="relative aspect-video bg-neutral-950 rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl">
            
            {/* Screen Share Layer */}
            {screenStream && (layoutMode === 'screen' || layoutMode === 'pip') && (
              <video
                ref={screenPreviewRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain"
              />
            )}

            {/* Camera Layer */}
            {cameraStream && (
              <video
                ref={videoPreviewRef}
                autoPlay
                playsInline
                muted
                className={`${
                  layoutMode === 'pip' && screenStream
                    ? 'absolute bottom-4 right-4 w-48 aspect-video rounded-xl border-2 border-rose-500 shadow-2xl object-cover z-20'
                    : 'w-full h-full object-cover'
                } ${!videoEnabled ? 'opacity-0' : 'opacity-100'}`}
              />
            )}

            {/* Camera disabled overlay */}
            {!videoEnabled && layoutMode === 'camera' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-neutral-950 text-neutral-500">
                <VideoOff className="w-12 h-12 mb-2 text-neutral-600" />
                <p className="text-xs font-semibold">Camera is turned off</p>
              </div>
            )}

            {/* Live On-Screen Lower-Third Banner Overlay */}
            {lowerThirdEnabled && (
              <div className="absolute bottom-6 left-6 right-6 z-30 pointer-events-none animate-in slide-in-from-bottom-2">
                <div className="bg-gradient-to-r from-neutral-950/95 via-neutral-900/90 to-transparent border-l-4 border-rose-600 px-4 py-2.5 rounded-r-xl shadow-2xl backdrop-blur-md max-w-xl">
                  <p className="text-xs font-black text-white uppercase tracking-wider truncate">
                    {lowerThirdHeadline}
                  </p>
                  <p className="text-[10px] text-neutral-300 font-medium truncate mt-0.5">
                    {lowerThirdSubtext}
                  </p>
                </div>
              </div>
            )}

            {/* Top Overlay HUD in Monitor */}
            <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-30">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-neutral-950/80 border border-neutral-700 text-white backdrop-blur-md">
                  FEED: {layoutMode.toUpperCase()}
                </span>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-neutral-950/80 border border-neutral-700 text-emerald-400 backdrop-blur-md">
                  ● 1080p 60FPS
                </span>
              </div>

              {isRecording && (
                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600 text-white text-[10px] font-black animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-white" />
                  <span>REC ACTIVE</span>
                </div>
              )}
            </div>

          </div>

          {/* Quick Studio Deck Controls Bar */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-3 flex items-center justify-between flex-wrap gap-3">
            
            {/* Camera / Mic / Screen Toggles */}
            <div className="flex items-center gap-2">
              <button
                id="studio-btn-toggle-cam"
                onClick={toggleCameraTrack}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all border ${
                  videoEnabled
                    ? 'bg-neutral-800 hover:bg-neutral-700 text-white border-neutral-700'
                    : 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                }`}
              >
                {videoEnabled ? <Video className="w-4 h-4 text-emerald-400" /> : <VideoOff className="w-4 h-4" />}
                <span>{videoEnabled ? 'Cam On' : 'Cam Off'}</span>
              </button>

              <button
                id="studio-btn-toggle-mic"
                onClick={toggleMicTrack}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all border ${
                  audioEnabled
                    ? 'bg-neutral-800 hover:bg-neutral-700 text-white border-neutral-700'
                    : 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                }`}
              >
                {audioEnabled ? <Mic className="w-4 h-4 text-emerald-400" /> : <MicOff className="w-4 h-4" />}
                <span>{audioEnabled ? 'Mic On' : 'Muted'}</span>
              </button>

              <button
                id="studio-btn-screenshare"
                onClick={startScreenShare}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all border ${
                  screenStream
                    ? 'bg-rose-600 text-white border-rose-500 shadow-md'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-white border-neutral-700'
                }`}
              >
                <Monitor className="w-4 h-4" />
                <span>{screenStream ? 'Sharing Screen' : 'Share Screen'}</span>
              </button>
            </div>

            {/* Layout Switchers */}
            <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-xs">
              <button
                onClick={() => setLayoutMode('camera')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                  layoutMode === 'camera' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Camera
              </button>
              <button
                onClick={() => setLayoutMode('screen')}
                disabled={!screenStream}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all disabled:opacity-30 ${
                  layoutMode === 'screen' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Screen
              </button>
              <button
                onClick={() => setLayoutMode('pip')}
                disabled={!screenStream}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all disabled:opacity-30 ${
                  layoutMode === 'pip' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                PiP Overlay
              </button>
            </div>

            {/* Local Recorder Trigger */}
            <div className="flex items-center gap-2">
              <button
                id="studio-btn-record"
                onClick={handleToggleRecording}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                  isRecording
                    ? 'bg-red-600 text-white animate-pulse'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700'
                }`}
              >
                {isRecording ? <Square className="w-3.5 h-3.5 fill-white" /> : <div className="w-3 h-3 rounded-full bg-red-500" />}
                <span>{isRecording ? 'Stop Recording' : 'Record Session'}</span>
              </button>

              {recordedVideoUrl && (
                <a
                  href={recordedVideoUrl}
                  download="sr-live-broadcast.webm"
                  className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-all"
                  title="Download Recording"
                >
                  <Download className="w-4 h-4" />
                </a>
              )}
            </div>

          </div>

          {/* Audio VU Level Meter */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-3.5 flex items-center gap-4">
            <div className="flex items-center gap-2 text-xs font-bold text-neutral-300">
              <Volume2 className="w-4 h-4 text-emerald-400" />
              <span>Mic VU Level:</span>
            </div>
            <div className="flex-1 h-3 bg-neutral-950 rounded-full overflow-hidden p-0.5 border border-neutral-800">
              <div
                className="h-full rounded-full transition-all duration-75 bg-gradient-to-r from-emerald-500 via-amber-400 to-rose-500"
                style={{ width: `${audioLevel}%` }}
              />
            </div>
            <span className="text-xs font-mono text-neutral-400 w-12 text-right">{audioLevel}%</span>
          </div>

        </div>

        {/* Right Col: Studio Configuration & Ingest Details */}
        <div className="space-y-4">
          
          {/* Stream Metadata Card */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-neutral-800 text-xs font-bold text-white uppercase tracking-wider">
              <Settings className="w-4 h-4 text-rose-500" />
              <span>Broadcast Details</span>
            </div>

            <div>
              <label className="text-[11px] text-neutral-400 font-medium">Broadcast Title</label>
              <input
                type="text"
                value={streamTitle ?? ''}
                onChange={(e) => setStreamTitle(e.target.value)}
                className="w-full mt-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-neutral-400 font-medium">Category</label>
                <select
                  value={category ?? 'tech'}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full mt-1 bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                >
                  <option value="sports">Sports</option>
                  <option value="tech">Tech & Science</option>
                  <option value="gaming">Gaming</option>
                  <option value="music">Music</option>
                  <option value="news">News</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-neutral-400 font-medium">Encoder Profile</label>
                <select
                  value={resolution ?? '1080p60 (8.5 Mbps)'}
                  onChange={(e) => setResolution(e.target.value)}
                  className="w-full mt-1 bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                >
                  <option value="4K 60 (18.5 Mbps)">4K Ultra (18.5M)</option>
                  <option value="1080p60 (8.5 Mbps)">1080p60 (8.5M)</option>
                  <option value="720p60 (4.5 Mbps)">720p60 (4.5M)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Lower Third Banner Customizer */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-amber-400" /> Lower-Third Graphic
              </span>
              <input
                type="checkbox"
                checked={lowerThirdEnabled}
                onChange={(e) => setLowerThirdEnabled(e.target.checked)}
                className="w-4 h-4 accent-rose-500 cursor-pointer"
              />
            </div>

            <div>
              <label className="text-[11px] text-neutral-400 font-medium">Headline</label>
              <input
                type="text"
                value={lowerThirdHeadline ?? ''}
                onChange={(e) => setLowerThirdHeadline(e.target.value)}
                className="w-full mt-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-neutral-400 font-medium">Subtext / Location</label>
              <input
                type="text"
                value={lowerThirdSubtext ?? ''}
                onChange={(e) => setLowerThirdSubtext(e.target.value)}
                className="w-full mt-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>

          {/* RTMP / OBS Ingest Credentials */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 space-y-3 text-xs">
            <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 pb-2 border-b border-neutral-800">
              <Radio className="w-4 h-4 text-rose-400" /> OBS / External Ingest
            </span>

            <div>
              <label className="text-[11px] text-neutral-400 font-medium">Server URL</label>
              <div className="flex items-center gap-1 mt-1">
                <input
                  type="text"
                  readOnly
                  value="rtmp://live.srlive.tv/app"
                  className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs font-mono text-neutral-300"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] text-neutral-400 font-medium">Stream Key</label>
              <div className="flex items-center gap-1.5 mt-1">
                <input
                  type={showStreamKey ? 'text' : 'password'}
                  readOnly
                  value={streamKey}
                  className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs font-mono text-neutral-300"
                />
                <button
                  onClick={() => setShowStreamKey(!showStreamKey)}
                  className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
                  title="Show/Hide Key"
                >
                  {showStreamKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={copyKey}
                  className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
                  title="Copy Stream Key"
                >
                  {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
