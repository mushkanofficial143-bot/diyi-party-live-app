import React, { useState } from 'react';
import { Scissors, Download, Share2, Sparkles, Check, Play } from 'lucide-react';
import { StreamChannel } from '../types';
import { playSoundFX } from '../utils/audioSynth';
import { LiveStreamFeedCanvas } from './LiveStreamFeedCanvas';
import confetti from 'canvas-confetti';

interface ClipMakerModalProps {
  isOpen: boolean;
  onClose: () => void;
  channel: StreamChannel;
  onSaveClip: (clip: { title: string; duration: string; url: string }) => void;
}

export const ClipMakerModal: React.FC<ClipMakerModalProps> = ({
  isOpen,
  onClose,
  channel,
  onSaveClip
}) => {
  const [clipTitle, setClipTitle] = useState(`Highlight: ${(channel?.title || 'Live Stream').substring(0, 35)}...`);
  const [clipDuration, setClipDuration] = useState<'15s' | '30s' | '60s'>('30s');
  const [isGenerated, setIsGenerated] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [videoError, setVideoError] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = () => {
    setIsGenerated(true);
    playSoundFX('superchat');
    confetti({ particleCount: 35, spread: 60 });
    onSaveClip({
      title: clipTitle,
      duration: clipDuration,
      url: channel.streamUrl
    });
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href + '#clip-' + Date.now());
    setIsCopied(true);
    playSoundFX('notification');
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-950 border border-neutral-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in zoom-in-95">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Scissors className="w-5 h-5 text-rose-500" />
            <h2 className="text-base font-bold text-white font-['Outfit']">Clip Live Highlight</h2>
          </div>
          <button onClick={onClose} className="text-xs text-neutral-400 hover:text-white">✕</button>
        </div>

        {/* Video Preview Snapshot */}
        <div className="relative aspect-video rounded-xl overflow-hidden bg-black border border-neutral-800">
          {!videoError ? (
            <video
              src={channel.streamUrl}
              autoPlay
              loop
              muted
              playsInline
              onError={(e) => {
                e.preventDefault();
                setVideoError(true);
              }}
              className="w-full h-full object-cover"
            >
              <source src={channel.streamUrl} type="video/mp4" />
            </video>
          ) : (
            <LiveStreamFeedCanvas
              category={channel.category}
              title={channel.title}
              broadcasterName={channel.broadcasterName}
              isPlaying={true}
              angleLabel="CLIP RECORDER"
            />
          )}
          <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/80 text-rose-400 text-[10px] font-mono font-bold z-10">
            TRIM: Last {clipDuration}
          </div>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <label className="text-neutral-300 font-semibold">Clip Title</label>
            <input
              type="text"
              value={clipTitle}
              onChange={(e) => setClipTitle(e.target.value)}
              className="w-full mt-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:border-rose-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="text-neutral-300 font-semibold">Length</label>
            <div className="grid grid-cols-3 gap-2 mt-1">
              {(['15s', '30s', '60s'] as const).map((len) => (
                <button
                  key={len}
                  onClick={() => setClipDuration(len)}
                  className={`py-1.5 rounded-xl font-bold transition-all ${
                    clipDuration === len
                      ? 'bg-rose-600 text-white shadow-md'
                      : 'bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  {len}
                </button>
              ))}
            </div>
          </div>

          {isGenerated ? (
            <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl space-y-2.5">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Check className="w-4 h-4" />
                <span>Clip created successfully!</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyLink}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl border border-neutral-700 font-semibold"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>{isCopied ? 'Link Copied!' : 'Share Clip Link'}</span>
                </button>
                <a
                  href={channel.streamUrl}
                  download="sr-live-clip.mp4"
                  className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl"
                  title="Download Clip File"
                >
                  <Download className="w-4 h-4" />
                </a>
              </div>
            </div>
          ) : (
            <button
              onClick={handleGenerate}
              className="w-full py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold rounded-xl shadow-lg shadow-rose-600/30 transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Publish & Save Highlight</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
