import React, { useState } from 'react';
import { Radio, Play, Sparkles, Check, AlertCircle } from 'lucide-react';
import { StreamChannel } from '../types';
import { playSoundFX } from '../utils/audioSynth';

interface CustomStreamModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddStream: (stream: StreamChannel) => void;
}

export const CustomStreamModal: React.FC<CustomStreamModalProps> = ({
  isOpen,
  onClose,
  onAddStream
}) => {
  const [streamUrl, setStreamUrl] = useState('');
  const [title, setTitle] = useState('');
  const [broadcaster, setBroadcaster] = useState('');
  const [category, setCategory] = useState<'sports' | 'music' | 'news' | 'gaming' | 'tech'>('sports');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!streamUrl.trim()) return;

    const newChannel: StreamChannel = {
      id: 'custom-' + Date.now(),
      title: title.trim() || 'Custom Live Stream Feed',
      broadcasterName: broadcaster.trim() || 'External Broadcaster',
      broadcasterAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      broadcasterBadge: 'Verified',
      broadcasterFollowers: '1.2K',
      category: category,
      viewersCount: Math.floor(1200 + Math.random() * 8000),
      likesCount: Math.floor(500 + Math.random() * 3000),
      streamUrl: streamUrl.trim(),
      fallbackVideoUrl: streamUrl.trim(),
      isLive: true,
      startedAt: 'Just now',
      resolution: '1080p60 (Direct Ingest)',
      fps: 60,
      bitrate: '9.0 Mbps',
      description: 'Custom added live stream feed with ultra low latency direct playback.',
      tags: ['CustomStream', 'DirectFeed', 'Live'],
      bannerUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&auto=format&fit=crop&q=80',
      thumbnailUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&auto=format&fit=crop&q=80',
      multiCamAngles: [
        {
          id: 'custom-main',
          name: 'Direct Stream Angle',
          shortLabel: 'DIRECT',
          videoUrl: streamUrl.trim(),
          thumbnail: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=200&auto=format&fit=crop&q=80',
          description: 'Live source feed'
        }
      ]
    };

    playSoundFX('superchat');
    onAddStream(newChannel);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-950 border border-neutral-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in zoom-in-95">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-rose-500" />
            <h2 className="text-base font-bold text-white font-['Outfit']">Play Custom Stream URL</h2>
          </div>
          <button onClick={onClose} className="text-xs text-neutral-400 hover:text-white">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="text-neutral-300 font-semibold">Stream URL (HLS .m3u8 or MP4 / WebM)</label>
            <input
              type="url"
              required
              placeholder="https://example.com/live/playlist.m3u8 or video.mp4"
              value={streamUrl}
              onChange={(e) => setStreamUrl(e.target.value)}
              className="w-full mt-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-white placeholder-neutral-500 focus:border-rose-500 focus:outline-none font-mono"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-neutral-300 font-semibold">Stream Title</label>
              <input
                type="text"
                placeholder="e.g. My Football Stream"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full mt-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-white placeholder-neutral-500 focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-neutral-300 font-semibold">Broadcaster Name</label>
              <input
                type="text"
                placeholder="e.g. SR TV Network"
                value={broadcaster}
                onChange={(e) => setBroadcaster(e.target.value)}
                className="w-full mt-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-white placeholder-neutral-500 focus:border-rose-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-neutral-300 font-semibold">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className="w-full mt-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:border-rose-500 focus:outline-none"
            >
              <option value="sports">Sports & Cricket</option>
              <option value="gaming">Gaming & Esports</option>
              <option value="music">Music & DJ</option>
              <option value="news">News & World</option>
              <option value="tech">Tech & Science</option>
            </select>
          </div>

          {/* Quick preset examples */}
          <div className="pt-2 border-t border-neutral-800/80 space-y-1.5">
            <span className="text-[11px] text-neutral-400 font-medium">Quick Test Feeds:</span>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => setStreamUrl('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4')}
                className="px-2 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-[10px] text-neutral-300"
              >
                Sample 4K Stream
              </button>
              <button
                type="button"
                onClick={() => setStreamUrl('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4')}
                className="px-2 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-[10px] text-neutral-300"
              >
                Sci-Fi 60FPS Stream
              </button>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold shadow-lg shadow-rose-600/25"
            >
              Launch Live Stream
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
