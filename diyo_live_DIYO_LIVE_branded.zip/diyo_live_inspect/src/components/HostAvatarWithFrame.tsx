import React from 'react';
import { HostTagType } from '../types/ownerTypes';
import { SRLiveRoleFrame, SRLiveRoleType } from './frames/SRLiveRoleFrame';
import { MASTER_FRAME_CATALOG } from '../data/mockFramesData';

interface HostAvatarWithFrameProps {
  avatarUrl: string;
  hostTag?: HostTagType | string | null;
  role?: SRLiveRoleType | string | null;
  frameUrl?: string | null;
  frameId?: string | null;
  vipLevel?: number;
  isOnline?: boolean;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  alt?: string;
  className?: string;
  isLive?: boolean;
  isSpeaking?: boolean;
  showGiftEffect?: boolean;
}

/**
 * HostAvatarWithFrame:
 * Universal high-performance profile frame renderer for DIYO LIVE:
 * - 6 Official Roles (Super Admin, Admin, Agency, Manager, Coin Seller, My Add)
 * - 14 Categories (VIP 1-8, Host, Country, Royal, Fire, Flower, Love, Limited, Event, Achievement, Free, Hot, New, Premium)
 * - Party Live effects: Speaking audio wave glow, Gift particle burst, VIP entrance sheen.
 */
export const HostAvatarWithFrame: React.FC<HostAvatarWithFrameProps> = ({
  avatarUrl,
  hostTag,
  role,
  frameUrl,
  frameId,
  vipLevel = 1,
  size = 'md',
  alt = 'User Avatar',
  className = '',
  isLive = false,
  isSpeaking = false,
  showGiftEffect = false
}) => {
  // Check explicit 6-Role frames
  const isExplicitRoleFrame = frameId && frameId.startsWith('FRM-ROLE-');
  let roleKey = role ? role.toUpperCase().replace(/[\s-]+/g, '_') : null;
  if (roleKey === 'OWNER') roleKey = 'SUPER_ADMIN';
  if (isExplicitRoleFrame) {
    roleKey = frameId.replace('FRM-ROLE-', '');
  }

  const isExplicitHostOrVipOrCustomFrame = frameId && !isExplicitRoleFrame && (
    frameId.startsWith('FRM-VIP-') ||
    frameId.startsWith('FRM-HOST-') ||
    frameId.startsWith('FRM-CTRY-') ||
    frameId.startsWith('FRM-ROYAL-') ||
    frameId.startsWith('FRM-FIRE-') ||
    frameId.startsWith('FRM-FLOWER-') ||
    frameId.startsWith('FRM-LOVE-') ||
    frameId.startsWith('FRM-LTD-') ||
    frameId.startsWith('FRM-EVT-') ||
    frameId.startsWith('FRM-ACH-') ||
    frameId.startsWith('FRM-FREE-') ||
    frameId.startsWith('FRM-HOT-') ||
    frameId.startsWith('FRM-NEW-') ||
    frameId.startsWith('FRM-PREM-') ||
    frameId.startsWith('FRM-HT-') ||
    ['FRM-01', 'FRM-02', 'FRM-03', 'FRM-04', 'FRM-05'].includes(frameId)
  );

  const isOfficialRole = Boolean(
    isExplicitRoleFrame || 
    (!isExplicitHostOrVipOrCustomFrame && roleKey && [
      'SUPER_ADMIN',
      'ADMIN',
      'AGENCY',
      'MANAGER',
      'COIN_SELLER',
      'MY_ADD'
    ].includes(roleKey))
  );

  if (isOfficialRole && roleKey) {
    return (
      <div className="relative inline-flex items-center justify-center">
        <SRLiveRoleFrame
          role={roleKey as SRLiveRoleType}
          avatarUrl={avatarUrl}
          size={size}
          isLive={isLive}
          className={className}
        />
        {/* Speaking Audio Glow */}
        {isSpeaking && (
          <div className="absolute inset-0 rounded-full border-2 border-cyan-400 animate-ping pointer-events-none opacity-80" />
        )}
        {/* Gift Burst Effect */}
        {showGiftEffect && (
          <div className="absolute -inset-2 rounded-full border-2 border-amber-300 animate-spin pointer-events-none z-30" style={{ animationDuration: '2s' }}>
            <span className="absolute -top-1 left-1/2 text-xs">✨</span>
            <span className="absolute -bottom-1 right-0 text-xs">🎁</span>
          </div>
        )}
      </div>
    );
  }

  // Size definitions
  const containerSizes = {
    xs: 'w-8 h-8',
    sm: 'w-10 h-10',
    md: 'w-14 h-14',
    lg: 'w-20 h-20',
    xl: 'w-24 h-24',
    '2xl': 'w-32 h-32'
  };

  const avatarSizes = {
    xs: 'w-6 h-6',
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-16 h-16',
    xl: 'w-20 h-20',
    '2xl': 'w-26 h-26'
  };

  // Find matching frame in catalog
  const matchedCatalogFrame = frameId ? MASTER_FRAME_CATALOG.find(f => f.id === frameId) : null;

  // Normalized host tag
  const normTag = hostTag ? hostTag.toUpperCase().replace(/\s+HOST$/i, '').trim() : null;

  // Frame resolution
  const isCelebrate = normTag === 'CELEBRATE' || frameId === 'FRM-HOST-CELEBRATE' || frameId === 'FRM-HT-01';
  const isTalent = normTag === 'TALENT' || frameId === 'FRM-HOST-TALENT' || frameId === 'FRM-HT-02';
  const isSinger = normTag === 'SINGER' || frameId === 'FRM-HOST-SINGER' || frameId === 'FRM-HT-03';
  const isNormal = normTag === 'NORMAL' || frameId === 'FRM-HOST-NORMAL' || frameId === 'FRM-HT-04';

  // VIP Frames
  const isVip10 = frameId === 'FRM-VIP-10' || (vipLevel >= 10 && !frameId && !isCelebrate && !isTalent && !isSinger && !isNormal);
  const isVip9 = frameId === 'FRM-VIP-09' || (vipLevel === 9 && !frameId && !isCelebrate && !isTalent && !isSinger && !isNormal);
  const isVip8 = frameId === 'FRM-VIP-08' || frameId === 'FRM-ROYAL-01' || frameId === 'FRM-01' || (vipLevel === 8 && !frameId && !isCelebrate && !isTalent && !isSinger && !isNormal);
  const isVip7 = frameId === 'FRM-VIP-07';
  const isVip6 = frameId === 'FRM-VIP-06';
  const isVip5 = frameId === 'FRM-VIP-05';
  const isVip4 = frameId === 'FRM-VIP-04';
  const isVip3 = frameId === 'FRM-VIP-03';
  const isVip2 = frameId === 'FRM-VIP-02';
  const isVip1 = frameId === 'FRM-VIP-01' || frameId === 'FRM-05';

  // Country Frames
  const isNepal = frameId === 'FRM-CTRY-NP';
  const isIndia = frameId === 'FRM-CTRY-IN';
  const isBangladesh = frameId === 'FRM-CTRY-BD';
  const isPakistan = frameId === 'FRM-CTRY-PK';
  const isPhilippines = frameId === 'FRM-CTRY-PH';

  // Fire / Flower / Love / Limited / Event
  const isFireDragon = frameId === 'FRM-FIRE-01' || frameId === 'FRM-02';
  const isSakura = frameId === 'FRM-FLOWER-01' || frameId === 'FRM-04';
  const isLoveCupid = frameId === 'FRM-LOVE-01';
  const isAnniversary = frameId === 'FRM-EVT-01';
  const isLimitedPhantom = frameId === 'FRM-LTD-01';
  const isCyberHolo = frameId === 'FRM-NEW-01' || frameId === 'FRM-03';
  const isAchievement7d = frameId === 'FRM-ACH-01';

  return (
    <div className={`relative inline-flex items-center justify-center flex-shrink-0 ${containerSizes[size]} ${className}`}>
      
      {/* Speaking Audio Glow Animation */}
      {isSpeaking && (
        <div className="absolute -inset-1.5 rounded-full border-2 border-cyan-400 animate-ping pointer-events-none opacity-90 z-20" />
      )}

      {/* Gift Sparkle Burst Animation */}
      {showGiftEffect && (
        <div className="absolute -inset-2 rounded-full border-2 border-amber-300 animate-spin pointer-events-none z-30" style={{ animationDuration: '1.5s' }}>
          <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 text-xs drop-shadow">🎁</span>
          <span className="absolute -bottom-1 right-0 text-xs drop-shadow">✨</span>
          <span className="absolute top-1/2 -left-1.5 text-xs drop-shadow">💎</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. CELEBRATE HOST FRAME                                                  */}
      {/* ========================================================================= */}
      {isCelebrate && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-amber-400/90 shadow-[0_0_16px_rgba(251,191,36,0.7)] animate-pulse" />
          <div className="absolute -inset-1 rounded-full border border-yellow-300/40 animate-spin" style={{ animationDuration: '12s' }} />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] filter">
            👑
          </span>
          <span className="absolute -bottom-1.5 right-0 text-[10px] leading-none drop-shadow">
            🎉
          </span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-black text-[7px] font-black uppercase tracking-tighter shadow">
              CELEBRATE
            </span>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. TALENT HOST FRAME                                                     */}
      {/* ========================================================================= */}
      {isTalent && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-fuchsia-400 shadow-[0_0_16px_rgba(217,70,239,0.7)]" />
          <div className="absolute -inset-1 rounded-full border border-purple-500/50 animate-ping" style={{ animationDuration: '3s' }} />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs text-amber-300 leading-none drop-shadow-[0_0_8px_rgba(251,191,36,0.9)]">
            ⭐
          </span>
          <span className="absolute -bottom-1 left-0 text-[10px] text-fuchsia-300 leading-none drop-shadow">
            ⚡
          </span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-gradient-to-r from-purple-600 to-fuchsia-500 text-white text-[7px] font-black uppercase tracking-tighter shadow">
              TALENT
            </span>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. SINGER HOST FRAME                                                     */}
      {/* ========================================================================= */}
      {isSinger && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-cyan-400 shadow-[0_0_16px_rgba(34,211,238,0.7)]" />
          <div className="absolute -inset-1 rounded-full border border-blue-400/40 animate-pulse" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">
            🎤
          </span>
          <span className="absolute -bottom-1 right-0 text-[10px] leading-none drop-shadow animate-bounce">
            🎵
          </span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-neutral-950 text-[7px] font-black uppercase tracking-tighter shadow">
              SINGER
            </span>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. NORMAL HOST FRAME                                                     */}
      {/* ========================================================================= */}
      {isNormal && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-emerald-400/90 shadow-[0_0_12px_rgba(52,211,153,0.5)]" />
          <span className="absolute -top-1.5 right-0 text-[11px] leading-none drop-shadow">
            👤
          </span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5A. VIP 10 CELESTIAL SUPREME GOD INFINITY FRAME                          */}
      {/* ========================================================================= */}
      {isVip10 && !isCelebrate && !isTalent && !isSinger && !isNormal && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-pink-400 shadow-[0_0_24px_rgba(236,72,153,1)] animate-pulse" />
          <div className="absolute -inset-2 rounded-full border border-amber-300/80 animate-spin" style={{ animationDuration: '8s' }} />
          <div className="absolute -inset-1 rounded-full border-2 border-purple-400/50" />
          <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-base leading-none drop-shadow-[0_0_12px_rgba(236,72,153,1)] animate-bounce" style={{ animationDuration: '1.5s' }}>
            🌟
          </span>
          <span className="absolute -bottom-1.5 right-0 text-[10px] drop-shadow">💎</span>
          <span className="absolute -bottom-1.5 left-0 text-[10px] drop-shadow">✨</span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.2 rounded-full bg-gradient-to-r from-pink-500 via-purple-600 to-amber-400 text-white text-[7px] font-black uppercase tracking-tighter shadow-lg border border-pink-200">
              VIP 10 GOD
            </span>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5B. VIP 9 SOLAR PHOENIX OVERLORD FRAME                                    */}
      {/* ========================================================================= */}
      {isVip9 && !isCelebrate && !isTalent && !isSinger && !isNormal && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-orange-400 shadow-[0_0_22px_rgba(249,115,22,1)]" />
          <div className="absolute -inset-1.5 rounded-full border border-amber-400/60 animate-pulse" />
          <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-sm leading-none drop-shadow-[0_0_10px_rgba(249,115,22,1)] animate-bounce" style={{ animationDuration: '2s' }}>
            ⚡
          </span>
          <span className="absolute -bottom-1 right-0 text-[10px] drop-shadow">🦅</span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-gradient-to-r from-orange-500 via-amber-400 to-yellow-400 text-black text-[7px] font-black uppercase tracking-tighter shadow border border-amber-200">
              VIP 9 SOLAR
            </span>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. VIP 8 / ROYAL IMPERIAL SOVEREIGN CROWN                                */}
      {/* ========================================================================= */}
      {isVip8 && !isCelebrate && !isTalent && !isSinger && !isNormal && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-amber-300 shadow-[0_0_20px_rgba(252,211,77,0.9)]" />
          <div className="absolute -inset-1.5 rounded-full border border-yellow-400/50 animate-pulse" />
          <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-sm leading-none drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)] animate-bounce" style={{ animationDuration: '2s' }}>
            👑
          </span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-black text-[7px] font-black uppercase tracking-tighter shadow border border-amber-200">
              VIP 8 KING
            </span>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. VIP 7 GALAXY LORD                                                     */}
      {/* ========================================================================= */}
      {isVip7 && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-indigo-400 shadow-[0_0_18px_rgba(99,102,241,0.9)]" />
          <div className="absolute -inset-1 rounded-full border border-purple-500/60 animate-spin" style={{ animationDuration: '14s' }} />
          <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 text-xs leading-none drop-shadow">
            🌌
          </span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1 py-0.2 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-[7px] font-black uppercase tracking-tighter shadow">
              VIP 7
            </span>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. VIP 6 CYBER DRAGON                                                    */}
      {/* ========================================================================= */}
      {isVip6 && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-fuchsia-500 shadow-[0_0_18px_rgba(236,72,153,0.9)] animate-pulse" />
          <span className="absolute -top-2 left-1 text-xs leading-none drop-shadow">🐉</span>
          <span className="absolute -bottom-1 right-0 text-[10px] leading-none drop-shadow">🔥</span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1 py-0.2 rounded-full bg-gradient-to-r from-fuchsia-600 to-pink-500 text-white text-[7px] font-black uppercase tracking-tighter shadow">
              VIP 6
            </span>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. VIP 5 DIAMOND / VIP 4 RUBY / VIP 3 SAPPHIRE / VIP 2 / VIP 1          */}
      {/* ========================================================================= */}
      {isVip5 && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.8)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">✨</span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1 py-0.2 rounded-full bg-purple-600 text-white text-[7px] font-black uppercase">
              VIP 5
            </span>
          )}
        </div>
      )}

      {isVip4 && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-rose-500 shadow-[0_0_15px_rgba(239,68,68,0.8)] animate-pulse" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">🔴</span>
        </div>
      )}

      {isVip3 && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.8)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">🔷</span>
        </div>
      )}

      {isVip2 && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-sky-400 shadow-[0_0_12px_rgba(56,189,248,0.7)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">💎</span>
        </div>
      )}

      {isVip1 && !isVip8 && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-yellow-400/80 shadow-[0_0_12px_rgba(250,204,21,0.6)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">⭐</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 9. COUNTRY FRAMES (Nepal, India, Bangladesh, Pakistan, Philippines)     */}
      {/* ========================================================================= */}
      {isNepal && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-red-500 shadow-[0_0_16px_rgba(239,68,68,0.8)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">🇳🇵</span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-gradient-to-r from-red-600 to-blue-700 text-white text-[7px] font-black uppercase tracking-tighter shadow">
              NEPAL
            </span>
          )}
        </div>
      )}

      {isIndia && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-orange-500 shadow-[0_0_16px_rgba(249,115,22,0.8)]" />
          <div className="absolute -inset-1 rounded-full border border-emerald-400/40 animate-spin" style={{ animationDuration: '16s' }} />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">🇮🇳</span>
          {size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-gradient-to-r from-orange-500 via-white to-emerald-600 text-black text-[7px] font-black uppercase tracking-tighter shadow">
              BHARAT
            </span>
          )}
        </div>
      )}

      {isBangladesh && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.8)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">🇧🇩</span>
        </div>
      )}

      {isPakistan && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-green-600 shadow-[0_0_15px_rgba(34,197,94,0.8)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">🇵🇰</span>
        </div>
      )}

      {isPhilippines && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.8)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">🇵🇭</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 10. FIRE / FLOWER / LOVE / LIMITED / NEW / ACHIEVEMENT                   */}
      {/* ========================================================================= */}
      {isFireDragon && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.9)] animate-pulse" />
          <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 text-xs leading-none">🔥</span>
          <span className="absolute -bottom-1.5 right-0 text-xs leading-none">🐉</span>
        </div>
      )}

      {isSakura && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-pink-400 shadow-[0_0_15px_rgba(244,114,182,0.7)]" />
          <span className="absolute -top-2 left-1 text-xs leading-none">🌸</span>
          <span className="absolute -bottom-1.5 right-1 text-xs leading-none animate-pulse">🌸</span>
        </div>
      )}

      {isLoveCupid && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-pink-500 shadow-[0_0_15px_rgba(236,72,153,0.8)] animate-pulse" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">💖</span>
          <span className="absolute -bottom-1 right-0 text-xs leading-none">🏹</span>
        </div>
      )}

      {isAnniversary && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-amber-400 shadow-[0_0_16px_rgba(251,191,36,0.8)]" />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none animate-bounce">🎆</span>
        </div>
      )}

      {isLimitedPhantom && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-purple-400 shadow-[0_0_18px_rgba(168,85,247,0.9)]" />
          <div className="absolute -inset-1 rounded-full border border-indigo-500/60 animate-spin" style={{ animationDuration: '10s' }} />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">⏳</span>
        </div>
      )}

      {isCyberHolo && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-cyan-400 shadow-[0_0_18px_rgba(34,211,238,0.8)]" />
          <span className="absolute -top-2 right-0 text-[11px] leading-none">💎</span>
          <span className="absolute -bottom-1 left-0 text-[10px] leading-none">⚡</span>
        </div>
      )}

      {isAchievement7d && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-yellow-400 shadow-[0_0_16px_rgba(234,179,8,0.8)]" />
          <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 text-xs leading-none">🏆</span>
        </div>
      )}

      {/* Fallback generic catalog match styling */}
      {!isCelebrate && !isTalent && !isSinger && !isNormal && !isVip8 && !isVip7 && !isVip6 && !isVip5 && !isVip4 && !isVip3 && !isVip2 && !isVip1 && !isNepal && !isIndia && !isBangladesh && !isPakistan && !isPhilippines && !isFireDragon && !isSakura && !isLoveCupid && !isAnniversary && !isLimitedPhantom && !isCyberHolo && !isAchievement7d && matchedCatalogFrame && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className={`absolute inset-0 rounded-full border-2 ${matchedCatalogFrame.borderStyle} shadow-[0_0_15px_${matchedCatalogFrame.glowColor}]`} />
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs leading-none">
            {matchedCatalogFrame.iconEmoji}
          </span>
          {matchedCatalogFrame.bottomNameplateText && size !== 'xs' && size !== 'sm' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1 py-0.2 rounded-full bg-neutral-900 border border-neutral-700 text-white text-[6px] font-bold uppercase truncate max-w-[50px]">
              {matchedCatalogFrame.bottomNameplateText}
            </span>
          )}
        </div>
      )}

      {/* Custom Frame URL fallback */}
      {frameUrl && (
        <img
          src={frameUrl}
          alt="Frame"
          className="absolute inset-0 w-full h-full object-contain pointer-events-none z-10"
        />
      )}

      {/* Center Avatar Photo Cutout */}
      <img
        src={avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
        alt={alt}
        className={`${avatarSizes[size]} rounded-full object-cover shadow-inner relative z-0 border border-black/40`}
      />

      {/* LIVE Indicator Pill */}
      {isLive && (
        <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-rose-600 text-[8px] font-black text-white px-1.5 py-0.2 rounded-full uppercase tracking-tighter border border-rose-400 shadow z-20">
          LIVE
        </span>
      )}
    </div>
  );
};
