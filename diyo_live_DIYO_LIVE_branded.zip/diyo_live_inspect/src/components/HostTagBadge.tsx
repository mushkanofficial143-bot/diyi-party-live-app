import React from 'react';
import { HostTagType } from '../types/ownerTypes';

interface HostTagBadgeProps {
  tag?: HostTagType | string | null;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  showIcon?: boolean;
  className?: string;
  glow?: boolean;
}

/**
 * HostTagBadge:
 * Renders the 4 official DIYO Host Tags with completely separate visual designs,
 * colors, icons, borders, gradients, and typographic styling.
 * 
 * 1. 🎉 CELEBRATE HOST
 * 2. ⭐ TALENT HOST
 * 3. 🎤 SINGER HOST
 * 4. 👤 NORMAL HOST
 */
export const HostTagBadge: React.FC<HostTagBadgeProps> = ({
  tag,
  size = 'md',
  showIcon = true,
  className = '',
  glow = true
}) => {
  if (!tag) return null;

  const normalizedTag = tag.toUpperCase().replace(/\s+HOST$/i, '').trim();

  // Size configurations
  const sizeClasses = {
    xs: 'px-2 py-0.5 text-[10px] gap-1 rounded-md font-black tracking-wider shadow-sm',
    sm: 'px-2.5 py-1 text-[11px] gap-1.5 rounded-lg font-black tracking-wider shadow-md',
    md: 'px-3 py-1 text-xs gap-2 rounded-xl font-black tracking-widest shadow-lg',
    lg: 'px-4 py-1.5 text-sm gap-2.5 rounded-2xl font-black tracking-widest shadow-xl'
  };

  const iconSizes = {
    xs: 'text-[11px]',
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };

  // 1. CELEBRATE HOST: Royal Amber, Gold & Ruby Red with sparkling confetti/crown theme
  if (normalizedTag === 'CELEBRATE' || normalizedTag === '🎉 CELEBRATE HOST') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-amber-400 via-yellow-400 to-rose-600 
          text-black font-black tracking-widest uppercase
          border-2 border-yellow-200 
          ${glow ? 'shadow-[0_0_16px_rgba(245,158,11,0.7)]' : ''}
          relative overflow-hidden group ${className}`}
        title="🎉 CELEBRATE HOST - Official Festive Event Broadcaster"
      >
        {/* Shimmer beam */}
        <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
        
        {showIcon && <span className={`${iconSizes[size]} leading-none drop-shadow font-black`}>🎉</span>}
        <span className="relative font-black drop-shadow-[0_1px_2px_rgba(255,255,255,0.8)]">CELEBRATE HOST</span>
        <span className="text-xs leading-none font-black drop-shadow">👑</span>
      </span>
    );
  }

  // 2. TALENT HOST: Cyberpunk Neon Purple, Fuchsia & Electric Star theme
  if (normalizedTag === 'TALENT' || normalizedTag === '⭐ TALENT HOST') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-purple-900 via-fuchsia-800 to-pink-900
          text-white font-black tracking-widest uppercase
          border-2 border-fuchsia-300 
          ${glow ? 'shadow-[0_0_18px_rgba(217,70,239,0.7)]' : ''}
          relative overflow-hidden ${className}`}
        title="⭐ TALENT HOST - Official Variety & Performance Broadcaster"
      >
        {/* Neon pulse glow */}
        <span className="absolute inset-0 bg-gradient-to-r from-fuchsia-500/25 via-purple-500/30 to-pink-500/25" />
        
        {showIcon && <span className={`${iconSizes[size]} text-amber-300 leading-none drop-shadow-[0_0_10px_rgba(251,191,36,0.9)] font-black`}>⭐</span>}
        <span className="relative font-black text-amber-200 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
          TALENT HOST
        </span>
        <span className="text-xs text-amber-300 font-black leading-none drop-shadow">⚡</span>
      </span>
    );
  }

  // 3. SINGER HOST: Deep Ocean Cyan, Electric Blue & Harmonic Equalizer theme
  if (normalizedTag === 'SINGER' || normalizedTag === '🎤 SINGER HOST') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-cyan-900 via-blue-800 to-teal-900
          text-white font-black tracking-widest uppercase
          border-2 border-cyan-300 
          ${glow ? 'shadow-[0_0_18px_rgba(6,182,212,0.7)]' : ''}
          relative overflow-hidden ${className}`}
        title="🎤 SINGER HOST - Official Vocal & Music Broadcaster"
      >
        {/* Equalizer animation vibe */}
        <span className="absolute inset-0 bg-gradient-to-r from-cyan-400/25 via-blue-400/25 to-transparent" />
        
        {showIcon && <span className={`${iconSizes[size]} text-cyan-200 leading-none drop-shadow-[0_0_10px_rgba(34,211,238,0.9)] font-black`}>🎤</span>}
        <span className="relative font-black text-cyan-100 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
          SINGER HOST
        </span>
        <span className="text-xs text-cyan-300 font-black leading-none drop-shadow">🎵</span>
      </span>
    );
  }

  // 4. NORMAL HOST: Refined Emerald, Teal & Gunmetal Silver Shield theme
  if (normalizedTag === 'NORMAL' || normalizedTag === '👤 NORMAL HOST') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-emerald-900 via-slate-900 to-teal-900
          text-emerald-100 font-black tracking-widest uppercase
          border-2 border-emerald-400 
          ${glow ? 'shadow-[0_0_16px_rgba(16,185,129,0.6)]' : ''}
          relative overflow-hidden ${className}`}
        title="👤 NORMAL HOST - Official Verified Live Broadcaster"
      >
        {showIcon && <span className={`${iconSizes[size]} text-emerald-300 leading-none font-black drop-shadow`}>👤</span>}
        <span className="relative font-black text-emerald-200 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
          NORMAL HOST
        </span>
        <span className="text-xs text-emerald-300 font-black leading-none drop-shadow">✓</span>
      </span>
    );
  }

  // Fallback for custom or general string
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-black tracking-wider uppercase bg-neutral-800 text-white border-2 border-neutral-600 shadow-md ${className}`}>
      {tag}
    </span>
  );
};
