import React, { useRef, useEffect } from 'react';
import { StreamCategory } from '../types';

interface LiveStreamFeedCanvasProps {
  category: StreamCategory;
  title: string;
  broadcasterName: string;
  isPlaying: boolean;
  angleLabel?: string;
  currentTime?: number;
}

export const LiveStreamFeedCanvas: React.FC<LiveStreamFeedCanvasProps> = ({
  category,
  title,
  broadcasterName,
  isPlaying,
  angleLabel = 'MAIN CAM',
  currentTime = 0
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;

    const render = () => {
      frame++;
      const w = canvas.width;
      const h = canvas.height;
      const t = Date.now() * 0.002;

      // 1. Dark Stadium/Studio Backdrop with Ambient Vignette
      const bgGrad = ctx.createRadialGradient(w / 2, h / 2, 50, w / 2, h / 2, Math.max(w, h));
      if (category === 'sports') {
        bgGrad.addColorStop(0, '#0a2318');
        bgGrad.addColorStop(0.5, '#05150e');
        bgGrad.addColorStop(1, '#020704');
      } else if (category === 'gaming') {
        bgGrad.addColorStop(0, '#1e0c29');
        bgGrad.addColorStop(0.5, '#0d0514');
        bgGrad.addColorStop(1, '#040108');
      } else if (category === 'tech') {
        bgGrad.addColorStop(0, '#0a1a2f');
        bgGrad.addColorStop(0.5, '#050c17');
        bgGrad.addColorStop(1, '#020509');
      } else if (category === 'music' || category === 'radio') {
        bgGrad.addColorStop(0, '#2d0c24');
        bgGrad.addColorStop(0.5, '#130410');
        bgGrad.addColorStop(1, '#060105');
      } else {
        bgGrad.addColorStop(0, '#141419');
        bgGrad.addColorStop(0.5, '#0a0a0d');
        bgGrad.addColorStop(1, '#040405');
      }
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // 2. Dynamic Scene Rendering based on Category
      if (category === 'sports') {
        // Football / Sports Arena Rendering
        // Field perspective lines
        ctx.strokeStyle = 'rgba(74, 222, 128, 0.15)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        // Pitch grid
        for (let i = 0; i <= 6; i++) {
          const y = h * 0.4 + i * (h * 0.1);
          ctx.moveTo(w * 0.1 - i * 20, y);
          ctx.lineTo(w * 0.9 + i * 20, y);
        }
        ctx.stroke();

        // Center circle & penalty box
        ctx.beginPath();
        ctx.ellipse(w / 2, h * 0.65, 140, 55, 0, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(74, 222, 128, 0.25)';
        ctx.lineWidth = 3;
        ctx.stroke();

        // Animated Ball Motion with glow
        const ballX = w / 2 + Math.sin(t * 1.5) * (w * 0.35);
        const ballY = h * 0.65 + Math.cos(t * 2.2) * (h * 0.18);

        // Ball Shadow
        ctx.beginPath();
        ctx.ellipse(ballX, ballY + 12, 14, 6, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.fill();

        // Ball
        const ballGrad = ctx.createRadialGradient(ballX - 3, ballY - 3, 2, ballX, ballY, 12);
        ballGrad.addColorStop(0, '#ffffff');
        ballGrad.addColorStop(0.7, '#e2e8f0');
        ballGrad.addColorStop(1, '#64748b');
        ctx.fillStyle = ballGrad;
        ctx.beginPath();
        ctx.arc(ballX, ballY, 10, 0, Math.PI * 2);
        ctx.fill();

        // Animated Players (Moving dots with jersey numbers and trail)
        for (let p = 0; p < 8; p++) {
          const px = w * 0.2 + (p * (w * 0.09)) + Math.sin(t + p * 1.2) * 25;
          const py = h * 0.52 + (p % 3) * 45 + Math.cos(t * 1.1 + p) * 15;
          const isTeamA = p % 2 === 0;

          ctx.fillStyle = isTeamA ? '#ef4444' : '#3b82f6';
          ctx.beginPath();
          ctx.arc(px, py, 6, 0, Math.PI * 2);
          ctx.fill();

          // Player name tag
          ctx.fillStyle = 'rgba(255,255,255,0.7)';
          ctx.font = '9px monospace';
          ctx.fillText(isTeamA ? `RMA #${p + 7}` : `MC #${p + 3}`, px - 16, py - 9);
        }

        // Broadcast Live Score Overlay
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(w * 0.05, h * 0.12, 280, 52, 10);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 13px sans-serif';
        ctx.fillText('MADRID 2 - 1 LONDON', w * 0.05 + 16, h * 0.12 + 24);
        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 11px monospace';
        const matchSec = Math.floor(currentTime % 3600);
        const matchMin = 78 + Math.floor(matchSec / 60);
        ctx.fillText(`● 88:24 • 2ND HALF (+4')`, w * 0.05 + 16, h * 0.12 + 42);

      } else if (category === 'gaming') {
        // Cyberpunk / Esports HUD & Radar
        // Radar Circle
        const radarX = w / 2;
        const radarY = h / 2;
        ctx.strokeStyle = 'rgba(244, 63, 94, 0.2)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(radarX, radarY, 130, 0, Math.PI * 2);
        ctx.arc(radarX, radarY, 80, 0, Math.PI * 2);
        ctx.stroke();

        // Radar Sweep Line
        const sweepAngle = t * 2;
        ctx.beginPath();
        ctx.moveTo(radarX, radarY);
        ctx.lineTo(radarX + Math.cos(sweepAngle) * 130, radarY + Math.sin(sweepAngle) * 130);
        ctx.strokeStyle = 'rgba(244, 63, 94, 0.8)';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Tactical Target Blips
        for (let b = 0; b < 5; b++) {
          const bx = radarX + Math.cos(b * 1.3) * (50 + (b * 15));
          const by = radarY + Math.sin(b * 1.3) * (50 + (b * 15));
          ctx.fillStyle = b === 0 ? '#10b981' : '#f43f5e';
          ctx.beginPath();
          ctx.arc(bx, by, 5, 0, Math.PI * 2);
          ctx.fill();
        }

        // Kill Feed Graphic
        ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
        ctx.fillRect(w - 240, h * 0.12, 210, 36);
        ctx.fillStyle = '#f43f5e';
        ctx.font = 'bold 11px monospace';
        ctx.fillText('⚡ AceSquad [Wingman] ProGamer_X', w - 230, h * 0.12 + 22);

      } else if (category === 'tech') {
        // Space Orbit & Rocket Telemetry Visualizer
        // Starfield Particles
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        for (let s = 0; s < 40; s++) {
          const sx = (s * 37 + (frame * 0.5)) % w;
          const sy = (s * 43) % h;
          const sSize = (s % 3 === 0) ? 2 : 1;
          ctx.fillRect(sx, sy, sSize, sSize);
        }

        // Planet Earth curvature
        ctx.beginPath();
        ctx.arc(w / 2, h * 1.6, h * 0.9, 0, Math.PI * 2);
        const earthGrad = ctx.createRadialGradient(w / 2, h * 1.6, 50, w / 2, h * 1.6, h * 0.9);
        earthGrad.addColorStop(0, '#1e3a8a');
        earthGrad.addColorStop(0.7, '#0284c7');
        earthGrad.addColorStop(1, '#38bdf8');
        ctx.fillStyle = earthGrad;
        ctx.fill();

        // Starship Booster Trajectory Rocket Flame
        const rx = w * 0.55 + Math.sin(t * 0.8) * 30;
        const ry = h * 0.38 + Math.cos(t * 0.8) * 15;

        // Plasma Flame
        const flameGrad = ctx.createLinearGradient(rx, ry + 15, rx, ry + 70);
        flameGrad.addColorStop(0, '#ffffff');
        flameGrad.addColorStop(0.3, '#f59e0b');
        flameGrad.addColorStop(0.8, '#ef4444');
        flameGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = flameGrad;
        ctx.beginPath();
        ctx.moveTo(rx - 8, ry + 15);
        ctx.lineTo(rx + 8, ry + 15);
        ctx.lineTo(rx + Math.sin(frame * 0.5) * 4, ry + 65 + Math.random() * 10);
        ctx.closePath();
        ctx.fill();

        // Rocket Body
        ctx.fillStyle = '#e2e8f0';
        ctx.beginPath();
        ctx.roundRect(rx - 7, ry - 35, 14, 50, 4);
        ctx.fill();

        // Telemetry readout
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.fillRect(w * 0.05, h * 0.12, 220, 70);
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 11px monospace';
        ctx.fillText(`ALTITUDE: ${(142.4 + Math.sin(t) * 2).toFixed(1)} km`, w * 0.05 + 14, h * 0.12 + 22);
        ctx.fillText(`VELOCITY: ${(7820 + Math.sin(t * 2) * 50).toFixed(0)} km/h`, w * 0.05 + 14, h * 0.12 + 42);
        ctx.fillStyle = '#10b981';
        ctx.fillText(`STAGE: ORBITAL GLIDE (T+ 08:42)`, w * 0.05 + 14, h * 0.12 + 60);

      } else {
        // Music / News / Lo-Fi Studio Sound Waves Visualizer
        const bars = 36;
        const barWidth = w / bars;
        for (let b = 0; b < bars; b++) {
          const freq = Math.sin(t * 3 + b * 0.3) * 0.5 + 0.5;
          const bh = 20 + freq * (h * 0.45);
          const bx = b * barWidth;
          const by = (h - bh) / 2;

          const barGrad = ctx.createLinearGradient(0, by, 0, by + bh);
          barGrad.addColorStop(0, '#f43f5e');
          barGrad.addColorStop(0.5, '#fb923c');
          barGrad.addColorStop(1, '#a855f7');

          ctx.fillStyle = barGrad;
          ctx.beginPath();
          ctx.roundRect(bx + 2, by, barWidth - 4, bh, 4);
          ctx.fill();
        }

        // Audio Frequency Ring in center
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, 70 + Math.sin(t * 4) * 12, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(244, 63, 94, 0.6)';
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      // 3. Global Broadcast Studio Watermark & Angle Badge
      ctx.fillStyle = 'rgba(244, 63, 94, 0.9)';
      ctx.beginPath();
      ctx.roundRect(w - 140, h - 34, 125, 22, 6);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText(`DIYO LIVE 4K • ${angleLabel}`, w - 170, h - 19);

      if (isPlaying) {
        animFrameRef.current = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [category, isPlaying, angleLabel, currentTime]);

  return (
    <canvas
      ref={canvasRef}
      width={960}
      height={540}
      className="w-full h-full object-cover block"
    />
  );
};
