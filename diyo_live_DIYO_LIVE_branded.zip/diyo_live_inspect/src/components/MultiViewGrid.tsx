import React, { useState } from 'react';
import { 
  Grid3X3, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Radio, 
  Layers, 
  Sparkles,
  RefreshCw,
  Tv
} from 'lucide-react';
import { StreamChannel } from '../types';
import { playSoundFX } from '../utils/audioSynth';

interface MultiViewGridProps {
  channels: StreamChannel[];
  onSelectMainChannel: (channel: StreamChannel) => void;
}

const MultiViewTile: React.FC<{
  channel: StreamChannel;
  slotIndex: number;
  hasAudio: boolean;
  onToggleAudio: () => void;
  onSelectMain: () => void;
  onSlotChannelChange: (channelId: string) => void;
  allChannels: StreamChannel[];
}> = ({
  channel,
  slotIndex,
  hasAudio,
  onToggleAudio,
  onSelectMain,
  onSlotChannelChange,
  allChannels
}) => {
  const [videoError, setVideoError] = useState(false);

  return (
    <div
      className={`relative bg-neutral-950 rounded-2xl overflow-hidden border transition-all shadow-xl group ${
        hasAudio
          ? 'border-rose-500 ring-2 ring-rose-500/40 shadow-rose-600/10'
          : 'border-neutral-800 hover:border-neutral-700'
      }`}
    >
      {/* Top Slot Header Bar */}
      <div className="bg-neutral-900/90 border-b border-neutral-800/80 px-3 py-2 flex items-center justify-between gap-2 z-10 relative">
        {/* Channel Selector Dropdown */}
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300 font-mono">
            FEED #{slotIndex + 1}
          </span>
          <select
            value={channel?.id}
            onChange={(e) => onSlotChannelChange(e.target.value)}
            className="bg-neutral-950 border border-neutral-800 rounded-lg px-2 py-1 text-xs text-white font-medium focus:border-rose-500 focus:outline-none flex-1 truncate"
          >
            {(allChannels || []).map((c) => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>
        </div>

        {/* Audio Switcher & Expand */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onToggleAudio}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold transition-all ${
              hasAudio
                ? 'bg-rose-600 text-white shadow-md'
                : 'bg-neutral-800 text-neutral-400 hover:text-white'
            }`}
            title={hasAudio ? 'Audio Playing' : 'Click to hear audio'}
          >
            {hasAudio ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline text-[10px]">{hasAudio ? 'AUDIO ON' : 'MUTE'}</span>
          </button>

          <button
            onClick={onSelectMain}
            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white"
            title="Open as Main Single Stream"
          >
            <Maximize className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Video Player or Interactive Canvas */}
      <div 
        className="relative aspect-video bg-black cursor-pointer overflow-hidden"
        onClick={onToggleAudio}
      >
        {!videoError ? (
          <video
            src={channel.streamUrl}
            autoPlay
            loop
            playsInline
            muted={!hasAudio}
            onError={(e) => {
              e.preventDefault();
              setVideoError(true);
            }}
            className="w-full h-full object-cover"
          >
            <source src={channel.streamUrl} type="video/mp4" />
          </video>
        ) : (
          <div className="w-full h-full relative bg-neutral-950 flex flex-col items-center justify-center">
            <img 
              src={channel.thumbnailUrl} 
              alt={channel.title} 
              className="w-full h-full object-cover opacity-40 blur-sm" 
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center bg-black/60">
              <Tv className="w-6 h-6 text-rose-500 mb-1" />
              <p className="text-[11px] font-bold text-white truncate max-w-full">{channel.title}</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setVideoError(false);
                }}
                className="mt-2 px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold flex items-center gap-1 shadow"
              >
                <RefreshCw className="w-3 h-3" /> Reconnect
              </button>
            </div>
          </div>
        )}

        {/* Live Badge in corner */}
        <div className="absolute bottom-3 left-3 flex items-center gap-2 pointer-events-none z-10">
          <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-rose-600 text-white flex items-center gap-1 shadow">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
            LIVE 4K
          </span>
          <span className="px-2 py-0.5 rounded-full text-[9px] font-medium bg-neutral-950/80 text-white backdrop-blur-md">
            {channel.broadcasterName}
          </span>
        </div>

        {hasAudio && (
          <div className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-rose-600 text-white text-[9px] font-bold shadow-lg animate-pulse z-10">
            🔊 ACTIVE AUDIO
          </div>
        )}
      </div>
    </div>
  );
};

export const MultiViewGrid: React.FC<MultiViewGridProps> = ({
  channels,
  onSelectMainChannel
}) => {
  // Slots: 4 quadrant indices mapped to channel IDs
  const [slots, setSlots] = useState<string[]>([
    channels[0]?.id || '',
    channels[1]?.id || '',
    channels[2]?.id || '',
    channels[3]?.id || ''
  ]);

  // Which slot has the unmuted active audio feed
  const [activeAudioSlot, setActiveAudioSlot] = useState<number>(0);
  const [gridCount, setGridCount] = useState<2 | 3 | 4>(4);

  const handleSlotChannelChange = (slotIndex: number, channelId: string) => {
    setSlots((prev) => {
      const next = [...prev];
      next[slotIndex] = channelId;
      return next;
    });
    playSoundFX('click');
  };

  const handleToggleAudio = (slotIndex: number) => {
    setActiveAudioSlot(slotIndex);
    playSoundFX('click');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-4">
      {/* Top Header & Layout Switcher */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center">
            <Grid3X3 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white font-['Outfit'] flex items-center gap-2">
              QUAD MULTI-VIEW MONITOR
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">
                MULTI-FEED
              </span>
            </h2>
            <p className="text-xs text-neutral-400">
              Watch up to 4 simultaneous live broadcasts. Click any stream to switch audio focus.
            </p>
          </div>
        </div>

        {/* Layout Mode Selector (2-split, 3-split, 4-split) */}
        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-between sm:justify-end">
          <span className="text-xs text-neutral-400 font-semibold">Layout:</span>
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-xs">
            {[2, 3, 4].map((num) => (
              <button
                key={num}
                onClick={() => setGridCount(num as any)}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  gridCount === num ? 'bg-rose-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                }`}
              >
                {num} Feeds
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Dynamic Grid Layout */}
      <div className={`grid gap-4 ${
        gridCount === 2 
          ? 'grid-cols-1 md:grid-cols-2' 
          : gridCount === 3 
          ? 'grid-cols-1 md:grid-cols-3' 
          : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-2'
      }`}>
        {(slots || []).slice(0, gridCount).map((channelId, idx) => {
          const currentChan = (channels || []).find((c) => c.id === channelId) || (channels || [])[idx % (channels || []).length] || { id: 'fallback', title: 'Live Stream' } as any;
          const hasAudio = activeAudioSlot === idx;

          return (
            <MultiViewTile
              key={`${idx}-${currentChan?.id || idx}`}
              channel={currentChan}
              slotIndex={idx}
              hasAudio={hasAudio}
              onToggleAudio={() => handleToggleAudio(idx)}
              onSelectMain={() => onSelectMainChannel(currentChan)}
              onSlotChannelChange={(cId) => handleSlotChannelChange(idx, cId)}
              allChannels={channels}
            />
          );
        })}
      </div>
    </div>
  );
};
