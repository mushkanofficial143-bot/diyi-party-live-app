import React, { useState } from 'react';
import { 
  Radio, 
  Tv, 
  Video, 
  Grid3X3, 
  Search, 
  PlusCircle, 
  Bell, 
  Volume2, 
  SlidersHorizontal,
  Flame,
  Globe,
  Sparkles,
  UserCheck,
  Crown,
  Image as ImageIcon,
  MessageSquare,
  User,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';
import { StreamCategory } from '../types';
import { UserRole, UserAccount } from '../types/ownerTypes';
import { HostTagBadge } from './HostTagBadge';
import { HostAvatarWithFrame } from './HostAvatarWithFrame';

export type MainNavTab = 'home' | 'browse' | 'video_live' | 'party_live' | 'message' | 'me' | 'studio' | 'moment' | 'multiview' | 'radio' | 'owner';

interface NavbarProps {
  activeTab: MainNavTab;
  setActiveTab: (tab: MainNavTab) => void;
  onOpenGoLive: () => void;
  selectedCategory: StreamCategory;
  setSelectedCategory: (cat: StreamCategory) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenCustomStream: () => void;
  onOpenVideoAnalyzer?: () => void;
  unreadNotifications: number;
  currentRole: UserRole;
  currentUser: UserAccount;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenGoLive,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
  onOpenCustomStream,
  onOpenVideoAnalyzer,
  unreadNotifications,
  currentRole,
  currentUser
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-neutral-950/95 backdrop-blur-md border-b border-neutral-800/80 px-3 lg:px-6 py-2.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 sm:gap-4">
        
        {/* Brand & Logo */}
        <div className="flex items-center gap-4 lg:gap-6 flex-shrink-0">
          <div 
            id="nav-brand-logo"
            onClick={() => setActiveTab('browse')}
            className="flex items-center gap-2.5 cursor-pointer group select-none"
          >
            <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-amber-400 p-0.5 shadow-lg shadow-emerald-900/40 group-hover:shadow-emerald-900/60 transition-all">
              <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
                <Radio className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 border-2 border-neutral-950"></span>
              </span>
            </div>
            
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-['Outfit'] font-black text-lg sm:text-xl tracking-wider text-white">
                  🏆 DIYO <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-400">LIVE</span>
                </span>
                <span className="hidden lg:inline text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase tracking-widest font-mono">
                  PRO
                </span>
              </div>
              <span className="text-[9px] text-neutral-400 -mt-0.5 font-mono tracking-tight hidden sm:block">
                MULTI-SEAT PARTY & SOCIAL
              </span>
            </div>
          </div>

          {/* Primary View Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-neutral-900/90 p-1 rounded-2xl border border-neutral-800">
            
            {/* 1. Home / Browse Streams */}
            <button
              id="nav-tab-home"
              onClick={() => setActiveTab('browse')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'browse' || activeTab === 'home'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950/50'
                  : 'text-neutral-300 hover:text-white hover:bg-neutral-800/60'
              }`}
            >
              <Tv className="w-3.5 h-3.5 text-emerald-400" />
              <span>Home</span>
            </button>



            {/* 3. Party Live (20 Seats + Sir Crown) */}
            <button
              id="nav-tab-party-live"
              onClick={() => setActiveTab('party_live')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'party_live'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 font-black shadow-md shadow-amber-950/50'
                  : 'text-amber-300 hover:text-white hover:bg-neutral-800/60'
              }`}
            >
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>Party Live</span>
              <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">20</span>
            </button>

            {/* 5. Music Lounge */}
            <button
              id="nav-tab-radio"
              onClick={() => setActiveTab('radio')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'radio'
                  ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-md shadow-rose-950/50'
                  : 'text-rose-300 hover:text-white hover:bg-neutral-800/60'
              }`}
            >
              <Radio className="w-3.5 h-3.5 text-rose-400" />
              <span>Music Jukebox</span>
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
            </button>

            {/* 6. Messages */}
            <button
              id="nav-tab-messages"
              onClick={() => setActiveTab('message')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all relative ${
                activeTab === 'message'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950/50'
                  : 'text-neutral-300 hover:text-white hover:bg-neutral-800/60'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-teal-300" />
              <span>Messages</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            </button>

            {/* Permanent Owner Panel Button - Never removable */}
            <button
              id="nav-tab-owner-permanent"
              onClick={() => setActiveTab('owner')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all ${
                activeTab === 'owner'
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 shadow-lg shadow-amber-500/30'
                  : 'bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20'
              }`}
              title="DIYO LIVE Owner Panel (Permanent & Protected)"
            >
              <Crown className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>Owner Panel</span>
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            </button>

            {/* 6. Profile / Me */}
            <button
              id="nav-tab-me"
              onClick={() => setActiveTab('me')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'me'
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-neutral-950 shadow-md shadow-amber-950/50 font-black'
                  : 'text-neutral-300 hover:text-white hover:bg-neutral-800/60'
              }`}
            >
              <User className="w-3.5 h-3.5 text-amber-400" />
              <span>Me</span>
            </button>

            {/* More Broadcast Tools Dropdown (Moment, Studio, Multi-View, Radio, Owner) */}
            <div className="relative">
              <button
                onClick={() => setShowMoreMenu(!showMoreMenu)}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  ['moment', 'studio', 'multiview', 'radio', 'owner'].includes(activeTab)
                    ? 'bg-neutral-800 text-white border border-neutral-700'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <span>More</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {showMoreMenu && (
                <div className="absolute left-0 mt-2 w-48 bg-neutral-900 border border-neutral-800 rounded-2xl p-1.5 shadow-2xl z-50 animate-in fade-in space-y-0.5">
                  <button
                    onClick={() => { setActiveTab('moment'); setShowMoreMenu(false); }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-neutral-300 hover:text-white hover:bg-neutral-800 flex items-center gap-2"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Moments</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('multiview'); setShowMoreMenu(false); }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-neutral-300 hover:text-white hover:bg-neutral-800 flex items-center gap-2"
                  >
                    <Grid3X3 className="w-3.5 h-3.5 text-teal-400" />
                    <span>Quad Multi-View</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('radio'); setShowMoreMenu(false); }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-neutral-300 hover:text-white hover:bg-neutral-800 flex items-center gap-2"
                  >
                    <Radio className="w-3.5 h-3.5 text-amber-400" />
                    <span>Audio Lounge</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('studio'); setShowMoreMenu(false); }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-neutral-300 hover:text-white hover:bg-neutral-800 flex items-center gap-2"
                  >
                    <Video className="w-3.5 h-3.5 text-rose-400" />
                    <span>Studio Controls</span>
                  </button>

                  {onOpenVideoAnalyzer && (
                    <button
                      onClick={() => { onOpenVideoAnalyzer(); setShowMoreMenu(false); }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-indigo-300 hover:bg-indigo-500/10 flex items-center gap-2"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                      <span>Gemini Video AI</span>
                    </button>
                  )}

                  <div className="pt-1 border-t border-neutral-800">
                    <button
                      onClick={() => { setActiveTab('owner'); setShowMoreMenu(false); }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-black text-amber-400 hover:bg-amber-500/10 flex items-center gap-2"
                    >
                      <Crown className="w-3.5 h-3.5 text-amber-400" />
                      <span>Owner Panel</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </nav>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-xs lg:max-w-sm hidden sm:block">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="search-streams-input"
              type="text"
              placeholder="Search streams, hosts, games..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-all"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-neutral-500 hover:text-neutral-300"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Actions & Profile Pill */}
        <div className="flex items-center gap-2">
          {/* AI Video Analyzer Button */}
          {onOpenVideoAnalyzer && (
            <button
              id="btn-video-analyzer"
              onClick={onOpenVideoAnalyzer}
              className="hidden sm:flex items-center gap-1.5 bg-gradient-to-r from-indigo-950/80 to-purple-950/80 hover:from-indigo-900/80 hover:to-purple-900/80 border border-indigo-500/40 text-indigo-200 hover:text-white text-xs font-bold px-3 py-1.5 rounded-xl transition-all shadow-md shadow-indigo-950/50 active:scale-95"
              title="Analyze video stream with Gemini 3.1 Pro"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
              <span>AI Video Analyzer</span>
            </button>
          )}

          {/* Custom Stream Input Button */}
          <button
            id="btn-custom-stream"
            onClick={onOpenCustomStream}
            className="hidden lg:flex items-center gap-1.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium px-3 py-1.5 rounded-xl transition-all"
            title="Play custom HLS or MP4 stream URL"
          >
            <PlusCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Custom Stream</span>
          </button>

          {/* Notification Button */}
          <div className="relative">
            <button
              id="btn-notifications"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-all"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifications > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-neutral-900 border border-neutral-800 rounded-2xl p-3 shadow-2xl z-50 animate-in fade-in">
                <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">Live Alerts & Reminders</span>
                  <span className="text-[10px] text-emerald-400 font-mono">3 Active</span>
                </div>
                <div className="divide-y divide-neutral-800/60 mt-1 max-h-64 overflow-y-auto">
                  <div className="py-2 px-1 flex items-start gap-2.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-medium text-white">Championship Final just hit 40,000 live viewers!</p>
                      <p className="text-[10px] text-neutral-400 mt-0.5">2 minutes ago • SR Sports</p>
                    </div>
                  </div>
                  <div className="py-2 px-1 flex items-start gap-2.5">
                    <span className="w-2 h-2 rounded-full bg-amber-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-medium text-white">VIP Daily Gift Check-in is ready to claim (+3,000 🪙)</p>
                      <p className="text-[10px] text-neutral-400 mt-0.5">Today • Reward Center</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* User Profile Pill -> Switches to Me tab */}
          <div 
            onClick={() => setActiveTab('me')}
            className="flex items-center gap-2 pl-2 border-l border-neutral-800 cursor-pointer group select-none"
            title="Open Profile / Me Screen"
          >
            <div className="relative flex items-center justify-center">
              <HostAvatarWithFrame
                avatarUrl={currentUser.avatar}
                frameUrl={currentUser.avatarFrameUrl}
                frameId={currentUser.avatarFrameId}
                role={currentUser.role || currentRole}
                hostTag={currentUser.hostTag}
                size="xs"
                vipLevel={currentUser.vipLevel}
              />
            </div>
            
            <div className="hidden xl:flex flex-col text-left">
              <div className="flex items-center gap-1">
                <span className="text-[11px] font-bold text-white group-hover:text-emerald-300 transition-colors">
                  {currentUser.name}
                </span>
                {currentUser.hostTag && (
                  <HostTagBadge tag={currentUser.hostTag} size="xs" />
                )}
              </div>
              <span className="text-[9px] font-mono text-yellow-400 font-bold">
                {(currentUser.coinBalance ?? 0).toLocaleString()} 🪙
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* Mobile Subnav for tabs */}
      <div className="flex md:hidden items-center justify-around pt-2 border-t border-neutral-800/80 mt-2 gap-1 overflow-x-auto">
        <button
          onClick={() => setActiveTab('browse')}
          className={`flex-1 py-1.5 text-center text-xs font-bold rounded-xl ${
            activeTab === 'browse' ? 'bg-emerald-600 text-white' : 'text-neutral-400'
          }`}
        >
          Room
        </button>
        <button
          onClick={() => setActiveTab('moment')}
          className={`flex-1 py-1.5 text-center text-xs font-bold rounded-xl ${
            activeTab === 'moment' ? 'bg-emerald-600 text-white' : 'text-neutral-400'
          }`}
        >
          Moment
        </button>
        <button
          onClick={() => setActiveTab('radio')}
          className={`flex-1 py-1.5 text-center text-xs font-bold rounded-xl ${
            activeTab === 'radio' ? 'bg-rose-600 text-white' : 'text-rose-400'
          }`}
        >
          Music 🎵
        </button>
        <button
          onClick={() => setActiveTab('message')}
          className={`flex-1 py-1.5 text-center text-xs font-bold rounded-xl ${
            activeTab === 'message' ? 'bg-emerald-600 text-white' : 'text-neutral-400'
          }`}
        >
          Message
        </button>
        <button
          onClick={() => setActiveTab('me')}
          className={`flex-1 py-1.5 text-center text-xs font-black rounded-xl ${
            activeTab === 'me' ? 'bg-amber-500 text-neutral-950' : 'text-amber-400'
          }`}
        >
          Me
        </button>
        <button
          onClick={() => setActiveTab('owner')}
          className={`flex-1 py-1.5 text-center text-xs font-bold rounded-xl flex items-center justify-center gap-1 ${
            activeTab === 'owner' ? 'bg-amber-500 text-neutral-950' : 'text-amber-400'
          }`}
        >
          <Crown className="w-3 h-3" />
        </button>
      </div>
    </header>
  );
};
