import React, { useState } from 'react';
import { 
  Calendar, 
  Bell, 
  BellRing, 
  Film, 
  Play, 
  Clock, 
  Eye, 
  Tag, 
  Check, 
  Sparkles,
  ChevronRight,
  Globe,
  Zap
} from 'lucide-react';
import { ScheduledEvent, VideoHighlight, StreamChannel, StreamCategory } from '../types';
import { playSoundFX } from '../utils/audioSynth';
import { LiveStreamFeedCanvas } from './LiveStreamFeedCanvas';
import { HostTagBadge } from './HostTagBadge';
import { HostAvatarWithFrame } from './HostAvatarWithFrame';
import { SUPPORTED_COUNTRIES } from '../data/countryData';

interface ScheduleAndHighlightsProps {
  schedule: ScheduledEvent[];
  highlights: VideoHighlight[];
  channels: StreamChannel[];
  selectedCategory: StreamCategory;
  onSelectChannel: (channel: StreamChannel) => void;
  onSetReminder: (id: string) => void;
}

export const ScheduleAndHighlights: React.FC<ScheduleAndHighlightsProps> = ({
  schedule,
  highlights,
  channels,
  selectedCategory,
  onSelectChannel,
  onSetReminder
}) => {
  const [activeTab, setActiveTab] = useState<'channels' | 'schedule' | 'highlights'>('channels');
  const [selectedCountryFilter, setSelectedCountryFilter] = useState<string>('ALL');
  const [previewHighlight, setPreviewHighlight] = useState<VideoHighlight | null>(null);
  const [highlightVideoError, setHighlightVideoError] = useState(false);

  const filteredChannels = (channels || []).filter((c) => {
    const matchesCategory = selectedCategory === 'all' || c.category === selectedCategory;
    const matchesCountry = selectedCountryFilter === 'ALL' || c.countryCode === selectedCountryFilter;
    return matchesCategory && matchesCountry;
  });

  const filteredHighlights = selectedCategory === 'all'
    ? (highlights || [])
    : (highlights || []).filter((h) => h.category === selectedCategory);

  const filteredSchedule = selectedCategory === 'all'
    ? (schedule || [])
    : (schedule || []).filter((s) => s.category === selectedCategory);

  return (
    <div className="space-y-6">
      
      {/* Section Header & Sub-Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setActiveTab('channels')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'channels'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
                : 'text-neutral-400 hover:text-white bg-neutral-900'
            }`}
          >
            Live Channels ({filteredChannels.length})
          </button>

          <button
            onClick={() => setActiveTab('schedule')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'schedule'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
                : 'text-neutral-400 hover:text-white bg-neutral-900'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Broadcast Schedule</span>
          </button>

          <button
            onClick={() => setActiveTab('highlights')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'highlights'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
                : 'text-neutral-400 hover:text-white bg-neutral-900'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>VOD & Highlights</span>
          </button>
        </div>

        <span className="text-xs text-neutral-500 font-mono">
          DIYO LIVE DIRECT FEED
        </span>
      </div>

      {/* Country Filters Bar for Live Streams */}
      {activeTab === 'channels' && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => {
              setSelectedCountryFilter('ALL');
              playSoundFX('click');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-xs font-bold transition-all shrink-0 border ${
              selectedCountryFilter === 'ALL'
                ? 'bg-emerald-500 text-neutral-950 border-emerald-400 shadow-md shadow-emerald-950/40'
                : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white hover:bg-neutral-850'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>All Countries</span>
          </button>

          {SUPPORTED_COUNTRIES.map((country) => (
            <button
              key={country.code}
              onClick={() => {
                setSelectedCountryFilter(country.code);
                playSoundFX('click');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-xs font-bold transition-all shrink-0 border ${
                selectedCountryFilter === country.code
                  ? 'bg-amber-500 text-neutral-950 border-amber-400 shadow-md shadow-amber-950/40 font-black'
                  : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:text-white hover:bg-neutral-850'
              }`}
            >
              <span className="text-sm">{country.flag}</span>
              <span>{country.name}</span>
            </button>
          ))}
        </div>
      )}

      {/* Tab 1: Live Channels Catalog */}
      {activeTab === 'channels' && (
        filteredChannels.length === 0 ? (
          <div className="py-20 text-center bg-neutral-900/60 border border-neutral-800 rounded-3xl p-6">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Zap className="w-8 h-8 animate-pulse" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 font-['Outfit']">No one is live right now.</h3>
            <p className="text-sm text-neutral-400 max-w-md mx-auto">
              When an authenticated host starts a real live broadcast or Party Live session, it will appear here automatically in real-time.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredChannels.map((chan) => (
              <div
                key={chan.id}
                onClick={() => {
                  onSelectChannel(chan);
                  playSoundFX('click');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-rose-500/50 rounded-2xl overflow-hidden cursor-pointer transition-all duration-200 group shadow-lg hover:shadow-2xl hover:shadow-rose-600/10 flex flex-col"
              >
                {/* Thumbnail Container */}
                <div className="relative aspect-video bg-black overflow-hidden">
                  <img
                    src={chan.thumbnailUrl}
                    alt={chan.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Live Badge & Country Flag */}
                  <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                    <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black shadow-lg">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                      <span>LIVE</span>
                    </div>
                    <span className="text-base drop-shadow-md bg-neutral-950/70 px-1.5 py-0.5 rounded-full border border-neutral-700/60" title={chan.countryName}>
                      {chan.countryFlag || '🇮🇳'}
                    </span>
                  </div>

                  {/* Viewers Pill */}
                  <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-neutral-950/85 backdrop-blur-md border border-neutral-700/60 text-white text-[10px] font-mono font-bold">
                    {(chan.viewersCount ?? 0).toLocaleString()} watching
                  </div>

                  {/* Multi-Cam Indicator */}
                  {chan.multiCamAngles && chan.multiCamAngles.length > 1 && (
                    <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-full bg-neutral-950/90 text-rose-400 border border-rose-500/40 text-[9px] font-bold">
                      {chan.multiCamAngles.length} Angles
                    </div>
                  )}
                </div>

                {/* Channel Meta Information */}
                <div className="p-3.5 flex items-start gap-3 flex-1">
                  <div className="flex-shrink-0 mt-0.5">
                    <HostAvatarWithFrame
                      avatarUrl={chan.broadcasterAvatar}
                      frameUrl={chan.avatarFrameUrl}
                      frameId={chan.avatarFrameId}
                      hostTag={chan.hostTag || 'CELEBRATE'}
                      size="sm"
                      isOnline={chan.isLive}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="text-xs font-bold text-white group-hover:text-rose-400 transition-colors line-clamp-2 leading-snug">
                      {chan.title}
                    </h3>
                    <div className="flex items-center gap-1.5 mt-1.5 flex-wrap text-[11px] text-neutral-400">
                      <span className="truncate font-semibold text-white flex items-center gap-1">
                        <span>{chan.countryFlag || '🇮🇳'}</span>
                        <span>{chan.broadcasterName}</span>
                      </span>
                      <HostTagBadge tag={chan.hostTag || 'CELEBRATE'} size="xs" />
                      {chan.hostUserId && (
                        <span className="text-[10px] font-mono text-amber-400 bg-neutral-950 px-1 rounded border border-neutral-800">
                          {chan.hostUserId}
                        </span>
                      )}
                      <span className="text-neutral-600">•</span>
                      <span className="text-rose-400 font-medium capitalize">{chan.category}</span>
                    </div>

                    <div className="flex items-center gap-1 mt-2 flex-wrap">
                      {(chan.tags || []).slice(0, 3).map((tag) => (
                        <span key={tag} className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {/* Tab 2: Broadcast Schedule */}
      {activeTab === 'schedule' && (
        <div className="space-y-3">
          {filteredSchedule.map((item) => (
            <div
              key={item.id}
              className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-neutral-700 transition-all shadow-md"
            >
              <div className="flex items-center gap-4">
                <img
                  src={item.thumbnailUrl}
                  alt={item.title}
                  className="w-20 h-14 rounded-xl object-cover flex-shrink-0"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30 uppercase">
                      {item.category}
                    </span>
                    <span className="text-xs text-neutral-400 font-mono font-semibold">
                      {item.scheduledTime}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white mt-1">{item.title}</h3>
                  <p className="text-xs text-neutral-400 mt-0.5 line-clamp-1">{item.description}</p>
                </div>
              </div>

              {/* Set Reminder Button */}
              <button
                onClick={() => {
                  onSetReminder(item.id);
                  playSoundFX('notification');
                }}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all flex-shrink-0 ${
                  item.isReminderSet
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white border border-neutral-700'
                }`}
              >
                {item.isReminderSet ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Reminder Set</span>
                  </>
                ) : (
                  <>
                    <Bell className="w-3.5 h-3.5" />
                    <span>Notify Me</span>
                  </>
                )}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: VOD Highlights Gallery */}
      {activeTab === 'highlights' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredHighlights.map((hl) => (
            <div
              key={hl.id}
              onClick={() => {
                setHighlightVideoError(false);
                setPreviewHighlight(hl);
              }}
              className="bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-amber-500/50 rounded-2xl overflow-hidden cursor-pointer transition-all duration-200 group shadow-lg flex flex-col"
            >
              <div className="relative aspect-video bg-black">
                <img src={hl.thumbnailUrl} alt={hl.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-10 h-10 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-xl">
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  </div>
                </div>
                <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-white text-[10px] font-mono font-bold">
                  {hl.duration}
                </span>
              </div>

              <div className="p-3 flex-1 flex flex-col justify-between">
                <h3 className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-2">
                  {hl.title}
                </h3>
                <div className="flex items-center justify-between text-[11px] text-neutral-400 mt-2">
                  <span>{hl.channelName}</span>
                  <span>{hl.views} • {hl.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Video Highlight Playback Modal */}
      {previewHighlight && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-neutral-950 border border-neutral-800 rounded-3xl p-5 max-w-2xl w-full shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Highlight Replay</span>
              <button
                onClick={() => setPreviewHighlight(null)}
                className="text-xs text-neutral-400 hover:text-white"
              >
                ✕ Close
              </button>
            </div>

            <div className="relative aspect-video rounded-2xl overflow-hidden bg-black border border-neutral-800">
              {!highlightVideoError ? (
                <video
                  src={previewHighlight.videoUrl}
                  autoPlay
                  controls
                  onError={(e) => {
                    e.preventDefault();
                    setHighlightVideoError(true);
                  }}
                  className="w-full h-full object-contain"
                >
                  <source src={previewHighlight.videoUrl} type="video/mp4" />
                </video>
              ) : (
                <LiveStreamFeedCanvas
                  category={previewHighlight.category}
                  title={previewHighlight.title}
                  broadcasterName={previewHighlight.channelName}
                  isPlaying={true}
                  angleLabel="VOD REPLAY"
                />
              )}
            </div>

            <div>
              <h2 className="text-base font-bold text-white">{previewHighlight.title}</h2>
              <p className="text-xs text-neutral-400 mt-1">
                {previewHighlight.channelName} • {previewHighlight.views} • {previewHighlight.date}
              </p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
