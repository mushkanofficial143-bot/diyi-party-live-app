import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  Settings, 
  Layers, 
  Share2, 
  Radio, 
  Activity, 
  RotateCcw, 
  Scissors, 
  PictureInPicture2, 
  Heart, 
  Flame, 
  Rocket, 
  Sparkles, 
  ThumbsUp, 
  Check, 
  Eye, 
  Users, 
  Wifi, 
  Info,
  Tv,
  Camera,
  CameraOff,
  ScreenShare,
  RefreshCw,
  Link as LinkIcon
} from 'lucide-react';
import Hls from 'hls.js';
import { StreamChannel, MultiCamAngle, FloatingReaction } from '../types';
import { playSoundFX } from '../utils/audioSynth';
import { HostTagBadge } from './HostTagBadge';
import { HostAvatarWithFrame } from './HostAvatarWithFrame';
import confetti from 'canvas-confetti';

interface StreamPlayerProps {
  channel: StreamChannel;
  onOpenClipMaker: () => void;
  onLikeStream: () => void;
  likesCount: number;
}

export const StreamPlayer: React.FC<StreamPlayerProps> = ({
  channel,
  onOpenClipMaker,
  onLikeStream,
  likesCount
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const playerContainerRef = useRef<HTMLDivElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  // Player state
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [volume, setVolume] = useState(0.8);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isTheaterMode, setIsTheaterMode] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [controlsTimeout, setControlsTimeout] = useState<any>(null);
  const [hasVideoError, setHasVideoError] = useState(false);
  const [isLoadingStream, setIsLoadingStream] = useState(false);

  // Real Hardware Streaming Inputs
  const [isUsingWebcam, setIsUsingWebcam] = useState(false);
  const [isUsingScreenShare, setIsUsingScreenShare] = useState(false);
  const [showCustomUrlDialog, setShowCustomUrlDialog] = useState(false);
  const [customStreamInput, setCustomStreamInput] = useState('');
  const [activeCustomStreamUrl, setActiveCustomStreamUrl] = useState<string | null>(null);

  // Multi-Cam Angle & Stream Configuration
  const [activeAngle, setActiveAngle] = useState<MultiCamAngle>(
    channel.multiCamAngles[0] || {
      id: 'default',
      name: 'Main Broadcast',
      shortLabel: 'MAIN',
      videoUrl: channel.streamUrl,
      thumbnail: channel.thumbnailUrl,
      description: 'Default stream angle'
    }
  );

  const [selectedQuality, setSelectedQuality] = useState('Auto (4K UHD)');
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [showMultiCamMenu, setShowMultiCamMenu] = useState(false);
  const [showTelemetryHUD, setShowTelemetryHUD] = useState(false);
  const [isLiveSynced, setIsLiveSynced] = useState(true);
  const [dvrOffset, setDvrOffset] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(100);

  // Floating Reactions
  const [floatingReactions, setFloatingReactions] = useState<FloatingReaction[]>([]);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isLiked, setIsLiked] = useState(false);

  // Real Telemetry simulation
  const [bitrateSim, setBitrateSim] = useState(14.8);
  const [fpsSim, setFpsSim] = useState(60);
  const [latencySim, setLatencySim] = useState(820);

  // Stop local hardware stream
  const stopHardwareStreams = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }
    setIsUsingWebcam(false);
    setIsUsingScreenShare(false);
  };

  // Toggle Live Webcam directly in player
  const toggleLocalWebcam = async () => {
    if (isUsingWebcam) {
      stopHardwareStreams();
      loadActiveStreamSource();
      playSoundFX('click');
      return;
    }

    try {
      stopHardwareStreams();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: 60 } },
        audio: true
      });
      localStreamRef.current = stream;
      setIsUsingWebcam(true);
      setIsUsingScreenShare(false);
      setHasVideoError(false);
      
      if (videoRef.current) {
        if (hlsRef.current) {
          hlsRef.current.destroy();
          hlsRef.current = null;
        }
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      playSoundFX('superchat');
      confetti({ particleCount: 30, spread: 60 });
    } catch (err) {
      console.warn('Could not open webcam:', err);
      playSoundFX('notification');
    }
  };

  // Toggle Screen Share directly in player
  const toggleScreenShare = async () => {
    if (isUsingScreenShare) {
      stopHardwareStreams();
      loadActiveStreamSource();
      playSoundFX('click');
      return;
    }

    try {
      stopHardwareStreams();
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 60 },
        audio: true
      });
      localStreamRef.current = stream;
      setIsUsingScreenShare(true);
      setIsUsingWebcam(false);
      setHasVideoError(false);

      if (videoRef.current) {
        if (hlsRef.current) {
          hlsRef.current.destroy();
          hlsRef.current = null;
        }
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }

      stream.getVideoTracks()[0].onended = () => {
        stopHardwareStreams();
        loadActiveStreamSource();
      };
      playSoundFX('reward');
    } catch (err) {
      console.warn('Could not share screen:', err);
    }
  };

  // Apply custom stream URL
  const handleApplyCustomStream = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customStreamInput.trim()) return;
    stopHardwareStreams();
    setActiveCustomStreamUrl(customStreamInput.trim());
    setShowCustomUrlDialog(false);
    playSoundFX('superchat');
  };

  // Load stream source
  const loadActiveStreamSource = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isUsingWebcam || isUsingScreenShare) {
      return;
    }

    video.srcObject = null;
    const streamSource = activeCustomStreamUrl || activeAngle.videoUrl || channel.streamUrl;
    if (!streamSource) return;

    setHasVideoError(false);
    setIsLoadingStream(true);

    if (streamSource.includes('.m3u8') && Hls.isSupported()) {
      if (hlsRef.current) {
        hlsRef.current.destroy();
      }
      const hls = new Hls({
        liveSyncDurationCount: 3,
        enableWorker: true
      });
      hls.loadSource(streamSource);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setIsLoadingStream(false);
        video.play().catch(() => {
          video.muted = true;
          setIsMuted(true);
          video.play().catch(() => {});
        });
      });
      hls.on(Hls.Events.ERROR, () => {
        // Fallback to MP4 or backup stream
        if (channel.fallbackVideoUrl && channel.fallbackVideoUrl !== streamSource) {
          video.src = channel.fallbackVideoUrl;
          video.load();
          video.play().catch(() => {});
        } else {
          setHasVideoError(true);
        }
        setIsLoadingStream(false);
      });
      hlsRef.current = hls;
    } else {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      video.src = streamSource;
      video.load();
      video.play()
        .then(() => {
          setIsPlaying(true);
          setIsLoadingStream(false);
        })
        .catch(() => {
          video.muted = true;
          setIsMuted(true);
          video.play().catch(() => {});
          setIsLoadingStream(false);
        });
    }
  };

  // Switch stream source when channel or angle changes
  useEffect(() => {
    stopHardwareStreams();
    setActiveCustomStreamUrl(null);
    if (channel.multiCamAngles && channel.multiCamAngles.length > 0) {
      setActiveAngle(channel.multiCamAngles[0]);
    }
    setIsLiveSynced(true);
    setDvrOffset(0);
    setHasVideoError(false);
  }, [channel.id]);

  useEffect(() => {
    loadActiveStreamSource();

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      stopHardwareStreams();
    };
  }, [activeAngle, channel.streamUrl, activeCustomStreamUrl]);

  // Telemetry jitter simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setBitrateSim(Number((14.2 + Math.random() * 1.2).toFixed(2)));
      setFpsSim(Math.random() > 0.1 ? 60 : 59);
      setLatencySim(Math.floor(780 + Math.random() * 90));
      if (isPlaying) {
        setCurrentTime((prev) => prev + 1);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeout) clearTimeout(controlsTimeout);
    const timeout = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3500);
    setControlsTimeout(timeout);
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (isPlaying) {
      if (video) video.pause();
      setIsPlaying(false);
    } else {
      if (video) video.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) {
      setIsMuted(!isMuted);
      return;
    }
    video.muted = !video.muted;
    setIsMuted(video.muted);
    if (!video.muted && video.volume === 0) {
      video.volume = 0.8;
      setVolume(0.8);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    const video = videoRef.current;
    if (video) {
      video.volume = val;
      video.muted = val === 0;
      setIsMuted(val === 0);
    }
    setVolume(val);
  };

  const toggleFullscreen = () => {
    if (!playerContainerRef.current) return;
    if (!document.fullscreenElement) {
      playerContainerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const togglePiP = async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled) {
        await video.requestPictureInPicture();
      }
    } catch {
      // Ignore PiP error
    }
  };

  const syncToLive = () => {
    const video = videoRef.current;
    if (video && video.duration) {
      video.currentTime = video.duration;
    }
    setIsLiveSynced(true);
    setDvrOffset(0);
    playSoundFX('click');
  };

  const rewind10s = () => {
    const video = videoRef.current;
    if (video) {
      video.currentTime = Math.max(0, video.currentTime - 10);
    }
    setIsLiveSynced(false);
    setDvrOffset((prev) => prev + 10);
    playSoundFX('click');
  };

  const triggerReaction = (emoji: string) => {
    playSoundFX('reaction');
    const newReaction: FloatingReaction = {
      id: Math.random().toString(),
      emoji,
      x: 70 + Math.random() * 25,
      speed: 1.8 + Math.random() * 0.8
    };
    setFloatingReactions((prev) => [...prev.slice(-15), newReaction]);

    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((r) => r.id !== newReaction.id));
    }, 2200);
  };

  const handleLike = () => {
    if (!isLiked) {
      setIsLiked(true);
      onLikeStream();
      triggerReaction('❤️');
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8, x: 0.2 }
      });
    }
  };

  const handleCopyShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    playSoundFX('notification');
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="flex flex-col gap-3">
      {/* Video Player Main Viewport */}
      <div 
        id="sr-stream-player-container"
        ref={playerContainerRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setShowControls(false)}
        className={`relative w-full aspect-video bg-black rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl group select-none transition-all ${
          isTheaterMode ? 'max-h-[85vh]' : ''
        }`}
      >
        {/* Core Video Element */}
        <video
          id="sr-live-video"
          ref={videoRef}
          className="w-full h-full object-contain cursor-pointer"
          onClick={togglePlay}
          onError={(e) => {
            e.preventDefault();
            setHasVideoError(true);
          }}
          onTimeUpdate={() => {
            if (videoRef.current) {
              setCurrentTime(videoRef.current.currentTime);
              setDuration(videoRef.current.duration || 100);
            }
          }}
          onEnded={() => {
            if (videoRef.current && !isUsingWebcam && !isUsingScreenShare) {
              videoRef.current.currentTime = 0;
              videoRef.current.play().catch(() => {});
            }
          }}
          playsInline
          autoPlay
          muted={isMuted}
        />

        {/* Real Broadcast Standby Screen (Shown only when stream source fails) */}
        {hasVideoError && (
          <div className="absolute inset-0 bg-neutral-950 flex flex-col items-center justify-center p-6 text-center z-10 space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-rose-500 shadow-lg">
              <Tv className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Live Broadcast Standby</h3>
              <p className="text-xs text-neutral-400 max-w-md mt-1">
                The broadcaster feed is connecting or switching bandwidth. You can retry or switch sources below.
              </p>
            </div>
            <div className="flex items-center gap-2.5 flex-wrap justify-center">
              <button
                onClick={loadActiveStreamSource}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-lg"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Stream</span>
              </button>
              <button
                onClick={toggleLocalWebcam}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold border border-neutral-700 transition-all"
              >
                <Camera className="w-3.5 h-3.5 text-amber-400" />
                <span>Switch to My Camera</span>
              </button>
              <button
                onClick={() => setShowCustomUrlDialog(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold border border-neutral-700 transition-all"
              >
                <LinkIcon className="w-3.5 h-3.5 text-rose-400" />
                <span>Enter Stream URL</span>
              </button>
            </div>
          </div>
        )}

        {/* Top Badges & Live Status */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-20">
          <div className="flex items-center gap-2 pointer-events-auto">
            {/* Live Indicator Pill */}
            <button
              id="btn-live-sync"
              onClick={syncToLive}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold transition-all shadow-lg ${
                isLiveSynced
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'bg-neutral-800/90 text-amber-400 hover:bg-neutral-700 border border-amber-500/40'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span>{isUsingWebcam ? 'MY LIVE WEBCAM' : isUsingScreenShare ? 'MY SCREEN BROADCAST' : isLiveSynced ? 'LIVE 4K' : `-00:${dvrOffset < 10 ? '0' : ''}${dvrOffset} (SYNC)`}</span>
            </button>

            {/* Active Multi-Cam Label */}
            {!isUsingWebcam && !isUsingScreenShare && (
              <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full bg-neutral-950/80 backdrop-blur-md border border-neutral-700/60 text-xs font-semibold text-neutral-200 shadow-md">
                <Layers className="w-3.5 h-3.5 text-rose-400" />
                <span>{activeAngle.shortLabel}</span>
              </div>
            )}

            {/* Viewer Count */}
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-neutral-950/80 backdrop-blur-md border border-neutral-700/60 text-xs font-medium text-neutral-300 shadow-md">
              <Users className="w-3.5 h-3.5 text-rose-500" />
              <span className="font-mono font-bold text-white">{(channel?.viewersCount ?? 0).toLocaleString()}</span>
              <span className="hidden md:inline text-neutral-400 text-[10px]">watching</span>
            </div>
          </div>

          {/* Top Right Real Hardware Stream Toggles */}
          <div className="flex items-center gap-2 pointer-events-auto">
            {/* Live Webcam Toggle Button */}
            <button
              onClick={toggleLocalWebcam}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all backdrop-blur-md border shadow-md ${
                isUsingWebcam
                  ? 'bg-rose-600 text-white border-rose-500 shadow-rose-600/30'
                  : 'bg-neutral-900/85 text-neutral-200 hover:text-white border-neutral-700/80 hover:bg-neutral-800'
              }`}
              title="Broadcast or test your live device camera"
            >
              {isUsingWebcam ? <CameraOff className="w-3.5 h-3.5" /> : <Camera className="w-3.5 h-3.5 text-amber-400" />}
              <span>{isUsingWebcam ? 'Exit Camera' : 'My Camera'}</span>
            </button>

            {/* Screen Share Toggle */}
            <button
              onClick={toggleScreenShare}
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all backdrop-blur-md border shadow-md ${
                isUsingScreenShare
                  ? 'bg-emerald-600 text-white border-emerald-500 shadow-emerald-600/30'
                  : 'bg-neutral-900/85 text-neutral-200 hover:text-white border-neutral-700/80 hover:bg-neutral-800'
              }`}
              title="Broadcast your screen/game/window live"
            >
              <ScreenShare className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isUsingScreenShare ? 'Stop Share' : 'Screen Share'}</span>
            </button>

            {/* Multi-Cam Angle Switcher Pill */}
            {!isUsingWebcam && !isUsingScreenShare && channel.multiCamAngles && channel.multiCamAngles.length > 1 && (
              <button
                id="btn-toggle-multicam"
                onClick={() => setShowMultiCamMenu(!showMultiCamMenu)}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all backdrop-blur-md border ${
                  showMultiCamMenu
                    ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-600/30'
                    : 'bg-neutral-900/85 text-neutral-200 hover:text-white border-neutral-700/80 hover:bg-neutral-800'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Multi-Cam ({channel.multiCamAngles.length})</span>
              </button>
            )}

            {/* Telemetry HUD Toggle */}
            <button
              id="btn-toggle-telemetry"
              onClick={() => setShowTelemetryHUD(!showTelemetryHUD)}
              className={`p-1.5 rounded-full text-xs font-medium transition-all backdrop-blur-md border ${
                showTelemetryHUD
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50'
                  : 'bg-neutral-900/85 text-neutral-400 hover:text-neutral-200 border-neutral-700/80'
              }`}
              title="Toggle Live Stream Diagnostic HUD"
            >
              <Activity className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Telemetry HUD Overlay */}
        {showTelemetryHUD && (
          <div className="absolute top-14 left-3 bg-neutral-950/90 backdrop-blur-md border border-neutral-800 rounded-xl p-3 text-[11px] font-mono text-neutral-300 z-30 shadow-2xl max-w-xs animate-in fade-in">
            <div className="flex items-center justify-between pb-1.5 border-b border-neutral-800 font-bold text-white">
              <span className="flex items-center gap-1 text-emerald-400">
                <Wifi className="w-3 h-3" /> REALTIME STREAM TELEMETRY
              </span>
              <span className="text-[10px] text-neutral-500">LIVE</span>
            </div>
            <div className="space-y-1 mt-2">
              <div className="flex justify-between">
                <span className="text-neutral-400">Feed Source:</span>
                <span className="text-white font-semibold">{isUsingWebcam ? 'WebCam HD' : isUsingScreenShare ? 'Screen Ingest' : 'HLS/AV1 Stream'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Codec & Res:</span>
                <span className="text-white font-semibold">{channel.resolution}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Ingest Bitrate:</span>
                <span className="text-emerald-400 font-semibold">{bitrateSim} Mbps</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">FPS / Frame Drop:</span>
                <span className="text-white">{fpsSim} fps / 0.00%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Edge Latency:</span>
                <span className="text-rose-400 font-semibold">{latencySim} ms (Ultra-Low)</span>
              </div>
            </div>
          </div>
        )}

        {/* Custom Stream URL Dialog */}
        {showCustomUrlDialog && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-md z-40 flex items-center justify-center p-4">
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 max-w-md w-full shadow-2xl space-y-4 animate-in zoom-in-95">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <Radio className="w-4 h-4 text-rose-500" />
                  <span className="text-sm font-bold text-white">Direct Stream / OBS Ingest URL</span>
                </div>
                <button onClick={() => setShowCustomUrlDialog(false)} className="text-xs text-neutral-400 hover:text-white">✕</button>
              </div>
              <form onSubmit={handleApplyCustomStream} className="space-y-3">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-300">Enter HLS (.m3u8) or Direct MP4 URL</label>
                  <input
                    type="url"
                    required
                    placeholder="https://my-server.com/live/stream.m3u8"
                    value={customStreamInput}
                    onChange={(e) => setCustomStreamInput(e.target.value)}
                    className="w-full mt-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-rose-500 focus:outline-none font-mono"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowCustomUrlDialog(false)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold text-neutral-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-md"
                  >
                    Play Stream
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Multi-Cam Angle Floating Drawer Overlay */}
        {showMultiCamMenu && channel.multiCamAngles && (
          <div className="absolute bottom-16 left-3 right-3 sm:right-auto bg-neutral-950/95 backdrop-blur-xl border border-neutral-700/90 rounded-2xl p-3 z-30 shadow-2xl animate-in fade-in slide-in-from-bottom-2 max-w-xl">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-rose-500" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">Switch Multi-Cam Feed</span>
              </div>
              <button 
                onClick={() => setShowMultiCamMenu(false)}
                className="text-xs text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(channel?.multiCamAngles || []).map((angle) => {
                const isActive = activeAngle.id === angle.id;
                return (
                  <button
                    key={angle.id}
                    id={`btn-cam-${angle.id}`}
                    onClick={() => {
                      setActiveAngle(angle);
                      setShowMultiCamMenu(false);
                      playSoundFX('click');
                    }}
                    className={`relative rounded-xl overflow-hidden text-left p-1 transition-all border ${
                      isActive
                        ? 'border-rose-500 bg-rose-500/10 ring-2 ring-rose-500/40'
                        : 'border-neutral-800 bg-neutral-900/90 hover:border-neutral-700 hover:bg-neutral-800'
                    }`}
                  >
                    <div className="relative aspect-video rounded-lg overflow-hidden bg-black mb-1.5">
                      <img
                        src={angle.thumbnail}
                        alt={angle.name}
                        className="w-full h-full object-cover"
                      />
                      {isActive && (
                        <div className="absolute inset-0 bg-rose-600/30 flex items-center justify-center">
                          <span className="text-[10px] font-black bg-rose-600 text-white px-1.5 py-0.5 rounded shadow">
                            ACTIVE
                          </span>
                        </div>
                      )}
                    </div>
                    <p className="text-[11px] font-bold text-white truncate px-1">{angle.name}</p>
                    <p className="text-[9px] text-neutral-400 truncate px-1">{angle.description}</p>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Floating Flying Reactions Layer */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
          {(floatingReactions || []).map((r) => (
            <div
              key={r.id}
              className="absolute text-3xl float-reaction-bubble"
              style={{
                left: `${r.x}%`,
                bottom: '15%'
              }}
            >
              {r.emoji}
            </div>
          ))}
        </div>

        {/* Bottom Control Bar */}
        <div 
          className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-neutral-950 via-neutral-950/80 to-transparent pt-10 pb-3 px-4 z-20 transition-opacity duration-300 ${
            showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          {/* DVR Timeline Scrubber */}
          <div className="relative mb-3 flex items-center gap-2 group/scrubber">
            <span className="text-[10px] font-mono text-neutral-400">
              {isLiveSynced ? 'LIVE' : `-00:${dvrOffset < 10 ? '0' : ''}${dvrOffset}`}
            </span>
            <div className="relative flex-1 flex items-center h-4 cursor-pointer">
              <div className="w-full h-1 bg-neutral-700/80 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-rose-600 to-red-500 rounded-full"
                  style={{ width: `${Math.min(100, (currentTime / (duration || 1)) * 100)}%` }}
                />
              </div>
              <input
                type="range"
                min={0}
                max={duration || 100}
                value={currentTime}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  if (videoRef.current) {
                    videoRef.current.currentTime = val;
                  }
                  setCurrentTime(val);
                  setIsLiveSynced(false);
                  setDvrOffset(Math.max(0, Math.round(duration - val)));
                }}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>
            <span className="text-[10px] font-mono text-neutral-400">
              {Math.floor(currentTime / 60)}:{Math.floor(currentTime % 60).toString().padStart(2, '0')}
            </span>
          </div>

          {/* Controls Bottom Row */}
          <div className="flex items-center justify-between gap-3">
            {/* Left Controls: Play, 10s Rewind, Volume */}
            <div className="flex items-center gap-3">
              <button
                id="btn-player-playpause"
                onClick={togglePlay}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
              </button>

              <button
                id="btn-player-rewind10"
                onClick={rewind10s}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md"
                title="Rewind 10s (DVR)"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Volume & Slider */}
              <div className="flex items-center gap-2 group/vol">
                <button
                  id="btn-player-mute"
                  onClick={toggleMute}
                  className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-16 h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-rose-500"
                />
              </div>
            </div>

            {/* Middle Quick Reaction Buttons on Stream */}
            <div className="hidden lg:flex items-center gap-1 bg-neutral-900/80 backdrop-blur-md px-2 py-1 rounded-full border border-neutral-800">
              <button 
                onClick={() => triggerReaction('🔥')} 
                className="hover:scale-125 transition-transform px-1 text-sm" 
                title="Send Fire"
              >
                🔥
              </button>
              <button 
                onClick={() => triggerReaction('❤️')} 
                className="hover:scale-125 transition-transform px-1 text-sm" 
                title="Send Heart"
              >
                ❤️
              </button>
              <button 
                onClick={() => triggerReaction('🚀')} 
                className="hover:scale-125 transition-transform px-1 text-sm" 
                title="Send Rocket"
              >
                🚀
              </button>
              <button 
                onClick={() => triggerReaction('👏')} 
                className="hover:scale-125 transition-transform px-1 text-sm" 
                title="Send Clap"
              >
                👏
              </button>
              <button 
                onClick={() => triggerReaction('💯')} 
                className="hover:scale-125 transition-transform px-1 text-sm" 
                title="Send 100"
              >
                💯
              </button>
            </div>

            {/* Right Controls: Custom URL, Clip, Quality, PiP, Fullscreen */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowCustomUrlDialog(true)}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md hidden md:block"
                title="Enter Custom Stream URL or OBS feed"
              >
                <LinkIcon className="w-4 h-4 text-rose-400" />
              </button>

              {/* Clip Maker Trigger */}
              <button
                id="btn-player-clip"
                onClick={onOpenClipMaker}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-md transition-all"
                title="Clip Highlight (Last 30s)"
              >
                <Scissors className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden sm:inline">Clip</span>
              </button>

              {/* Quality Menu Selector */}
              <div className="relative">
                <button
                  id="btn-player-quality"
                  onClick={() => setShowQualityMenu(!showQualityMenu)}
                  className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md"
                  title="Resolution & Quality"
                >
                  <Settings className="w-4 h-4" />
                </button>

                {showQualityMenu && (
                  <div className="absolute bottom-12 right-0 bg-neutral-950 border border-neutral-800 rounded-xl p-1.5 shadow-2xl min-w-[150px] z-50 animate-in fade-in">
                    <p className="text-[10px] uppercase font-bold text-neutral-400 px-2 py-1 border-b border-neutral-800">
                      Stream Quality
                    </p>
                    {['Auto (4K UHD)', '1080p60 HDR', '720p60', '480p Low Data', 'Audio Only'].map((q) => (
                      <button
                        key={q}
                        onClick={() => {
                          setSelectedQuality(q);
                          setShowQualityMenu(false);
                        }}
                        className={`w-full flex items-center justify-between px-2.5 py-1.5 text-xs rounded-lg text-left transition-all ${
                          selectedQuality === q ? 'bg-rose-600 text-white font-bold' : 'text-neutral-300 hover:bg-neutral-800'
                        }`}
                      >
                        <span>{q}</span>
                        {selectedQuality === q && <Check className="w-3 h-3" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Picture-in-Picture */}
              <button
                id="btn-player-pip"
                onClick={togglePiP}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md hidden sm:block"
                title="Picture in Picture"
              >
                <PictureInPicture2 className="w-4 h-4" />
              </button>

              {/* Fullscreen */}
              <button
                id="btn-player-fullscreen"
                onClick={toggleFullscreen}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md"
                title="Fullscreen"
              >
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stream Info Bar & Broadcaster Profile Header */}
      <div className="bg-neutral-900/70 border border-neutral-800/80 rounded-2xl p-4 transition-all">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Broadcaster Avatar & Title */}
          <div className="flex items-start gap-3.5">
            <div className="relative">
              <HostAvatarWithFrame
                avatarUrl={channel.broadcasterAvatar}
                frameUrl={channel.avatarFrameUrl}
                frameId={channel.avatarFrameId}
                hostTag={channel.hostTag || 'CELEBRATE'}
                size="md"
                isOnline={true}
              />
              <span className="absolute -bottom-1 -right-1 px-1.5 py-0.2 bg-rose-600 text-white text-[9px] font-extrabold rounded-full border-2 border-neutral-900">
                LIVE
              </span>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-base sm:text-lg font-bold text-white leading-snug">
                  {channel.title}
                </h1>
                <HostTagBadge tag={channel.hostTag || 'CELEBRATE'} size="xs" glow={true} />
              </div>

              <div className="flex items-center gap-2 mt-1 flex-wrap text-xs text-neutral-400">
                <span className="font-semibold text-white hover:text-rose-400 cursor-pointer transition-colors flex items-center gap-1.5">
                  <span className="text-base" title={channel.countryName || 'Country'}>
                    {channel.countryFlag || '🇮🇳'}
                  </span>
                  <span>{channel.broadcasterName}</span>
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-neutral-800 text-rose-400 border border-neutral-700">
                  {channel.broadcasterBadge}
                </span>
                {channel.hostUserId && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-neutral-800/80 text-amber-300 border border-amber-500/30">
                    ID: {channel.hostUserId}
                  </span>
                )}
                {channel.boltBalance && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-teal-500/10 text-teal-300 border border-teal-500/30 flex items-center gap-0.5">
                    ⚡ {channel.boltBalance.toLocaleString()}
                  </span>
                )}
                <span>•</span>
                <span>{channel.broadcasterFollowers} followers</span>
                <span>•</span>
                <span className="text-neutral-400">Started {channel.startedAt}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons: Like, Follow, Share */}
          <div className="flex items-center gap-2.5 self-end md:self-center">
            {/* Like Stream Button */}
            <button
              id="btn-like-stream"
              onClick={handleLike}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                isLiked
                  ? 'bg-rose-600 text-white shadow-rose-600/30'
                  : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white border border-neutral-700'
              }`}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-white' : ''}`} />
              <span>{(likesCount ?? 0).toLocaleString()}</span>
            </button>

            {/* Follow / Subscribe */}
            <button
              id="btn-follow-broadcaster"
              onClick={() => {
                playSoundFX('notification');
                confetti({ particleCount: 25, spread: 50 });
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/25"
            >
              <Sparkles className="w-4 h-4" />
              <span>Follow</span>
            </button>

            {/* Share Button */}
            <button
              id="btn-share-stream"
              onClick={handleCopyShare}
              className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 hover:text-white transition-all"
              title="Share Stream"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Tags & Description Collapse */}
        <div className="mt-3 pt-3 border-t border-neutral-800/80 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider mr-1">Tags:</span>
            {(channel?.tags || []).map((tag) => (
              <span 
                key={tag} 
                className="px-2 py-0.5 rounded-lg bg-neutral-800/80 hover:bg-neutral-700/80 text-neutral-300 text-[11px] font-medium border border-neutral-700/50 cursor-pointer transition-colors"
              >
                #{tag}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-2 text-[11px] text-neutral-400 font-mono">
            <span className="text-emerald-400">● {channel.bitrate}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
