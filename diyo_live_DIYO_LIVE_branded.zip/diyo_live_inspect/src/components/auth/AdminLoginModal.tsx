import React, { useState } from 'react';
import { ShieldCheck, Lock, Mail, KeyRound, AlertTriangle, CheckCircle, Sparkles, X } from 'lucide-react';
import { UserRole } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessLogin: (role: UserRole) => void;
  currentRole: UserRole;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onSuccessLogin,
  currentRole
}) => {
  const [email, setEmail] = useState('srliveindia@gmail.com');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const cleanEmail = email.trim().toLowerCase();

      // Authorized Owner Login Check
      if (cleanEmail === 'srliveindia@gmail.com') {
        setShowSuccess(true);
        playSoundFX('superchat');
        setTimeout(() => {
          onSuccessLogin('OWNER');
          setShowSuccess(false);
          onClose();
        }, 1000);
      } else if (cleanEmail.includes('admin') || cleanEmail.includes('superadmin')) {
        setShowSuccess(true);
        playSoundFX('success');
        setTimeout(() => {
          onSuccessLogin('SUPER_ADMIN');
          setShowSuccess(false);
          onClose();
        }, 1000);
      } else {
        setAuthError('Unauthorized administrator account. Please verify credentials.');
        playSoundFX('alert');
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-md bg-neutral-900 border border-amber-500/40 rounded-3xl p-6 shadow-2xl shadow-amber-950/40 text-neutral-100 overflow-hidden">
        
        {/* Background Ambient Glow */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-rose-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="btn-close-admin-login"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-white rounded-full bg-neutral-800/60 hover:bg-neutral-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-amber-300 p-0.5 shadow-lg shadow-amber-500/25">
            <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-amber-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-['Outfit'] text-lg font-black text-white">DIYO LIVE Owner Login</h2>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black">
                MASTER PORTAL
              </span>
            </div>
            <p className="text-xs text-neutral-400">Secure owner management gateway</p>
          </div>
        </div>

        {showSuccess ? (
          <div className="py-8 text-center space-y-3 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center mx-auto text-emerald-400 shadow-xl shadow-emerald-950/50">
              <CheckCircle className="w-8 h-8 animate-bounce" />
            </div>
            <h3 className="text-base font-black text-emerald-400">Authorized Owner Verified!</h3>
            <p className="text-xs text-neutral-300">Granting full DIYO LIVE Master Executive privileges...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Email Field */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <span>Authorized Owner Email</span>
              </label>
              <div className="relative">
                <input
                  id="admin-login-email-input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="srliveindia@gmail.com"
                  required
                  className="w-full bg-neutral-950 border border-neutral-700/80 focus:border-amber-500 rounded-2xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all font-mono"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Security Master Passkey</span>
              </label>
              <div className="relative">
                <input
                  id="admin-login-password-input"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-neutral-950 border border-neutral-700/80 focus:border-amber-500 rounded-2xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all font-mono"
                />
              </div>
            </div>

            {/* Error Message */}
            {authError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-300">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{authError}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              id="btn-admin-login-submit"
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-amber-600 hover:from-amber-400 hover:via-rose-400 hover:to-amber-500 text-neutral-950 font-black text-xs tracking-wider uppercase transition-all shadow-lg shadow-amber-950/50 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>Verify & Unlock Owner Panel</span>
                </>
              )}
            </button>

            {/* Security Notice */}
            <div className="p-3 rounded-2xl bg-neutral-950/60 border border-neutral-800 text-[11px] text-neutral-400 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-amber-300">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Protected Enterprise Gateway</span>
              </div>
              <p>
                Owner login grants complete read/write access to user balances, hosts, live streams, coin seller ledger, and platform settings.
              </p>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
