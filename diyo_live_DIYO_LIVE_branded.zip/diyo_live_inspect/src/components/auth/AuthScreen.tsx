import React, { useState, useEffect } from 'react';
import { 
  Radio, 
  Smartphone, 
  Mail, 
  Lock, 
  User, 
  ShieldCheck, 
  ArrowRight, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  RefreshCw,
  Crown,
  ChevronDown
} from 'lucide-react';
import { UserAccount } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface AuthScreenProps {
  onLoginSuccess: (user: UserAccount) => void;
}

interface CountryOption {
  code: string;
  dialCode: string;
  name: string;
  flag: string;
}

const COUNTRIES: CountryOption[] = [
  { code: 'NP', dialCode: '+977', name: 'Nepal', flag: '🇳🇵' },
  { code: 'IN', dialCode: '+91', name: 'India', flag: '🇮🇳' },
  { code: 'BD', dialCode: '+880', name: 'Bangladesh', flag: '🇧🇩' },
  { code: 'PK', dialCode: '+92', name: 'Pakistan', flag: '🇵🇰' },
  { code: 'PH', dialCode: '+63', name: 'Philippines', flag: '🇵🇭' },
  { code: 'AE', dialCode: '+971', name: 'United Arab Emirates', flag: '🇦🇪' },
  { code: 'SA', dialCode: '+966', name: 'Saudi Arabia', flag: '🇸🇦' },
  { code: 'US', dialCode: '+1', name: 'United States', flag: '🇺🇸' },
  { code: 'GB', dialCode: '+44', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'MY', dialCode: '+60', name: 'Malaysia', flag: '🇲🇾' },
  { code: 'ID', dialCode: '+62', name: 'Indonesia', flag: '🇮🇩' },
];

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLoginSuccess }) => {
  const [authMethod, setAuthMethod] = useState<'google' | 'phone' | 'facebook' | 'email'>('google');
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  
  // Phone + OTP State
  const [selectedCountry, setSelectedCountry] = useState<CountryOption>(COUNTRIES[0]);
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpStep, setOtpStep] = useState<'enter_phone' | 'enter_otp'>('enter_phone');
  const [otpCode, setOtpCode] = useState(['', '', '', '', '', '']);
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [timer, setTimer] = useState<number>(60);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  // Email / Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Status & Loaders
  const [isLoading, setIsLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Timer countdown for OTP
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    } else if (timer === 0) {
      setIsTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timer]);

  // Helper to construct / link account with backend-authoritative 7-digit sequential ID
  const createOrLoadUser = async (provider: 'google' | 'phone' | 'facebook' | 'email', payload: {
    name?: string;
    email?: string;
    phone?: string;
    avatar?: string;
  }): Promise<UserAccount> => {
    try {
      const response = await fetch('/api/auth/register-or-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          identifier: payload.email || payload.phone || `user_${provider}`,
          email: payload.email,
          phone: payload.phone,
          name: payload.name,
          avatar: payload.avatar,
          countryCode: selectedCountry.code,
          countryFlag: selectedCountry.flag,
          countryName: selectedCountry.name
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.user) {
          const user: UserAccount = {
            id: data.user.id, // Permanent Backend 7-digit ID (e.g. 0000001, 0000002)
            name: data.user.name,
            username: data.user.username,
            email: data.user.email || `${data.user.id}@srlive.io`,
            phone: data.user.phone || payload.phone,
            avatar: data.user.avatar || payload.avatar,
            role: data.user.role || (data.user.id === '0000001' ? 'SUPER_ADMIN' : 'USER'),
            hostTag: data.user.hostTag || (data.user.id === '0000001' ? 'CELEBRATE' : undefined),
            avatarFrameId: data.user.avatarFrameId || (data.user.id === '0000001' ? 'FRM-ROLE-SUPER-ADMIN' : undefined),
            vipLevel: data.user.vipLevel ?? 0,
            svipLevel: data.user.svipLevel ?? 0,
            coinBalance: data.user.coinBalance ?? 0,
            diamondBalance: data.user.diamondBalance ?? 0,
            boltBalance: data.user.boltBalance ?? 0,
            userLevel: data.user.userLevel || 1,
            followersCount: data.user.followersCount ?? 0,
            followingCount: data.user.followingCount ?? 0,
            countryCode: data.user.countryCode || selectedCountry.code,
            countryFlag: data.user.countryFlag || selectedCountry.flag,
            countryName: data.user.countryName || selectedCountry.name,
            bio: data.user.bio || 'Live • Laugh • Share with DIYO VIP Global Community ❤️',
            totalRechargedUSD: data.user.totalRechargedUSD || 0,
            totalSpentCoins: data.user.totalSpentCoins || 0,
            status: data.user.status || 'Active',
            deviceType: 'Android APK',
            joinedDate: data.user.joinedDate || new Date().toISOString().split('T')[0],
            lastActive: 'Just now',
            registrationDate: data.user.registrationDate || new Date().toISOString().split('T')[0],
            lastLogin: 'Just now'
          };
          localStorage.setItem('srlive_current_user', JSON.stringify(user));
          return user;
        }
      }
    } catch (e) {
      console.warn('Backend user registration check failed, using local sequence fallback:', e);
    }

    // Local sequence fallback if server is unreachable
    const savedUsersRaw = localStorage.getItem('srlive_users_db');
    let usersDb: Record<string, UserAccount> = {};
    if (savedUsersRaw) {
      try { usersDb = JSON.parse(savedUsersRaw); } catch (e) {}
    }

    const identifierKey = payload.email || payload.phone || `user_${provider}_${Date.now()}`;
    if (usersDb[identifierKey]) {
      const existing = usersDb[identifierKey];
      existing.lastLogin = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      localStorage.setItem('srlive_users_db', JSON.stringify(usersDb));
      return existing;
    }

    const currentCount = Object.keys(usersDb).length + 6;
    const fallback7DigitId = String(currentCount).padStart(7, '0');

    const defaultAvatars = [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80'
    ];

    const randomAvatar = defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];

    const newUser: UserAccount = {
      id: fallback7DigitId,
      name: payload.name || (payload.email ? payload.email.split('@')[0] : `SR Star ${fallback7DigitId.slice(-4)}`),
      username: (payload.name || payload.email || `user_${fallback7DigitId.slice(-4)}`).toLowerCase().replace(/[^a-z0-9]/g, '_'),
      email: payload.email || `${fallback7DigitId}@srlive.io`,
      phone: payload.phone,
      avatar: payload.avatar || randomAvatar,
      role: 'USER',
      vipLevel: 0,
      svipLevel: 0,
      coinBalance: 0,
      diamondBalance: 0,
      boltBalance: 0,
      userLevel: 1,
      followersCount: 0,
      followingCount: 0,
      countryCode: selectedCountry.code,
      countryFlag: selectedCountry.flag,
      countryName: selectedCountry.name,
      bio: 'Live • Laugh • Share with DIYO VIP Global Community ❤️',
      totalRechargedUSD: 0,
      totalSpentCoins: 0,
      status: 'Active',
      deviceType: 'Android APK',
      joinedDate: new Date().toISOString().split('T')[0],
      lastActive: 'Just now',
      registrationDate: new Date().toISOString().split('T')[0],
      lastLogin: 'Just now'
    };

    usersDb[identifierKey] = newUser;
    localStorage.setItem('srlive_users_db', JSON.stringify(usersDb));
    return newUser;
  };

  // Google Login Flow
  const handleGoogleLogin = async () => {
    setErrorMsg(null);
    setIsLoading(true);
    setLoadingText('Connecting to Google Identity Services...');
    playSoundFX('click');

    setTimeout(async () => {
      setLoadingText('Verifying Google OAuth Token & Generating Unique 7-Digit ID...');
      const googleUser = await createOrLoadUser('google', {
        name: 'Aarav Mehta',
        email: 'aarav.mehta@gmail.com',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
      });
      setIsLoading(false);
      setSuccessMsg(`Welcome, ${googleUser.name}! (User ID: #${googleUser.id})`);
      playSoundFX('win');
      setTimeout(() => {
        onLoginSuccess(googleUser);
      }, 700);
    }, 600);
  };

  // Facebook Login Flow
  const handleFacebookLogin = async () => {
    setErrorMsg(null);
    setIsLoading(true);
    setLoadingText('Connecting to Facebook Authentication API...');
    playSoundFX('click');

    setTimeout(async () => {
      setLoadingText('Verifying Facebook Profile & Generating Unique 7-Digit ID...');
      const fbUser = await createOrLoadUser('facebook', {
        name: 'Elena Rostova',
        email: 'elena.rostova@facebook.com',
        avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80'
      });
      setIsLoading(false);
      setSuccessMsg(`Welcome, ${fbUser.name}! (User ID: #${fbUser.id})`);
      playSoundFX('win');
      setTimeout(() => {
        onLoginSuccess(fbUser);
      }, 700);
    }, 600);
  };

  // Phone: Send OTP
  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (!cleanNumber || cleanNumber.length < 7) {
      setErrorMsg('Please enter a valid mobile number.');
      playSoundFX('alert');
      return;
    }

    setIsLoading(true);
    setLoadingText(`Sending SMS OTP to ${selectedCountry.dialCode} ${cleanNumber}...`);
    playSoundFX('click');

    // Generate secure 6-digit OTP
    const mockCode = String(Math.floor(100000 + Math.random() * 900000));
    setGeneratedOtp(mockCode);

    setTimeout(() => {
      setIsLoading(false);
      setOtpStep('enter_otp');
      setTimer(60);
      setIsTimerRunning(true);
      setSuccessMsg(`OTP sent to ${selectedCountry.dialCode} ${cleanNumber}. (Verification Code: ${mockCode})`);
      playSoundFX('coin');
    }, 800);
  };

  // Phone: Handle OTP Digit Change
  const handleOtpDigitChange = (index: number, value: string) => {
    if (value.length > 1) {
      value = value.slice(-1);
    }
    const newOtp = [...otpCode];
    newOtp[index] = value;
    setOtpCode(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-digit-${index + 1}`);
      if (nextInput) nextInput.focus();
    }
  };

  // Phone: Verify OTP
  const handleVerifyOtp = async () => {
    const entered = otpCode.join('');
    if (entered.length < 6) {
      setErrorMsg('Please enter the complete 6-digit OTP.');
      playSoundFX('alert');
      return;
    }

    setIsLoading(true);
    setLoadingText('Verifying SMS OTP & Registering Sequential User ID...');
    playSoundFX('click');

    const fullPhone = `${selectedCountry.dialCode}${phoneNumber.replace(/[^0-9]/g, '')}`;
    const phoneUser = await createOrLoadUser('phone', {
      name: `SR Star (${fullPhone.slice(-4)})`,
      phone: fullPhone
    });

    setIsLoading(false);
    setSuccessMsg(`Mobile Verified! User ID Assigned: #${phoneUser.id}`);
    playSoundFX('win');
    setTimeout(() => {
      onLoginSuccess(phoneUser);
    }, 700);
  };

  // Email / Password Form Submit
  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!email || !password) {
      setErrorMsg('Please provide both email and password.');
      playSoundFX('alert');
      return;
    }

    if (mode === 'signup' && !name) {
      setErrorMsg('Please enter your display name.');
      playSoundFX('alert');
      return;
    }

    setIsLoading(true);
    setLoadingText(mode === 'signup' ? 'Backend Generating 7-Digit Sequential ID...' : 'Authenticating credentials...');
    playSoundFX('click');

    const emailUser = await createOrLoadUser('email', {
      name: name || email.split('@')[0],
      email: email
    });

    setIsLoading(false);
    setSuccessMsg(mode === 'signup' ? `🎉 Account Created! User ID #${emailUser.id}` : `✨ Welcome Back! (ID #${emailUser.id})`);
    playSoundFX('win');
    setTimeout(() => {
      onLoginSuccess(emailUser);
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#070913] flex flex-col justify-between overflow-y-auto font-sans text-white pb-safe-bottom pt-safe-top">
      
      {/* Ambient background glows */}
      <div className="fixed -top-32 -left-32 w-80 h-80 bg-purple-600/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="fixed top-1/3 -right-32 w-80 h-80 bg-cyan-500/15 rounded-full blur-[100px] pointer-events-none" />
      <div className="fixed -bottom-20 left-1/4 w-80 h-80 bg-amber-500/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-md mx-auto px-6 py-8 flex-1 flex flex-col justify-center">
        
        {/* Brand Logo & Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-tr from-purple-600 via-indigo-500 to-cyan-400 p-0.5 shadow-2xl shadow-purple-900/50 mb-4 animate-bounce duration-1000">
            <div className="w-full h-full bg-[#0b0f24] rounded-[22px] flex items-center justify-center">
              <Radio className="w-10 h-10 text-cyan-400 animate-pulse" />
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 mb-1">
            <h1 className="text-2xl font-black tracking-tight font-['Outfit']">
              🏆 TROPHY <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300">PARTY LIVE</span>
            </h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-amber-500 to-yellow-400 text-black shadow-md flex items-center gap-1">
              <Crown className="w-3 h-3 fill-black" /> VIP
            </span>
          </div>
          <p className="text-xs text-neutral-400 max-w-xs mx-auto">
            Multi-Seat Party Rooms • 26 Games • Lucky Gifts • PK Battles
          </p>
        </div>

        {/* Card Frame */}
        <div className="bg-[#0e1330]/90 backdrop-blur-xl border border-purple-500/20 rounded-3xl p-6 shadow-2xl shadow-black/80 relative">
          
          {/* Status Messages */}
          {errorMsg && (
            <div className="mb-4 p-3 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Login Mode Selector Tabs */}
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#070914] rounded-2xl border border-white/5 mb-6">
            <button
              onClick={() => { setAuthMethod('google'); playSoundFX('click'); }}
              className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                authMethod === 'google' || authMethod === 'facebook'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black shadow-lg shadow-purple-900/40'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Social</span>
            </button>
            <button
              onClick={() => { setAuthMethod('phone'); setOtpStep('enter_phone'); playSoundFX('click'); }}
              className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                authMethod === 'phone'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black shadow-lg shadow-purple-900/40'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span>Mobile OTP</span>
            </button>
            <button
              onClick={() => { setAuthMethod('email'); playSoundFX('click'); }}
              className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                authMethod === 'email'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black shadow-lg shadow-purple-900/40'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Mail className="w-3.5 h-3.5 text-pink-400" />
              <span>Email/ID</span>
            </button>
          </div>

          {/* TAB 1: SOCIAL (Google & Facebook) */}
          {(authMethod === 'google' || authMethod === 'facebook') && (
            <div className="space-y-3 animate-in fade-in">
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={isLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-neutral-100 text-neutral-900 font-bold text-xs flex items-center justify-center gap-3 shadow-xl transition-all active:scale-95 disabled:opacity-50"
              >
                {/* Official Google SVG */}
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Continue with Google</span>
              </button>

              <button
                type="button"
                onClick={handleFacebookLogin}
                disabled={isLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-[#1877F2] hover:bg-[#166fe5] text-white font-bold text-xs flex items-center justify-center gap-3 shadow-xl transition-all active:scale-95 disabled:opacity-50"
              >
                {/* Official Facebook SVG */}
                <svg className="w-5 h-5 fill-white" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
                <span>Continue with Facebook</span>
              </button>

              <div className="pt-3 text-center">
                <p className="text-[11px] text-neutral-400">
                  Fast & Secure 1-Tap Login via Firebase Authentication
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: MOBILE NUMBER + OTP */}
          {authMethod === 'phone' && (
            <div className="space-y-4 animate-in fade-in">
              {otpStep === 'enter_phone' ? (
                <form onSubmit={handleSendOtp} className="space-y-4">
                  <div>
                    <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">
                      Country & Mobile Number
                    </label>
                    
                    <div className="flex gap-2">
                      {/* Country Code Dropdown */}
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => setIsCountryDropdownOpen(!isCountryDropdownOpen)}
                          className="h-11 px-3 bg-[#070914] border border-white/10 rounded-2xl flex items-center gap-1.5 text-xs font-bold hover:border-purple-500 transition-all"
                        >
                          <span className="text-base">{selectedCountry.flag}</span>
                          <span className="font-mono text-neutral-200">{selectedCountry.dialCode}</span>
                          <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
                        </button>

                        {isCountryDropdownOpen && (
                          <div className="absolute top-12 left-0 z-30 w-56 max-h-56 overflow-y-auto bg-[#0b0f24] border border-purple-500/30 rounded-2xl shadow-2xl p-1.5 space-y-0.5">
                            {COUNTRIES.map((c) => (
                              <button
                                key={c.code}
                                type="button"
                                onClick={() => {
                                  setSelectedCountry(c);
                                  setIsCountryDropdownOpen(false);
                                }}
                                className="w-full px-2.5 py-1.5 rounded-xl text-left text-xs hover:bg-purple-600/30 flex items-center justify-between transition-all"
                              >
                                <span className="flex items-center gap-2">
                                  <span>{c.flag}</span>
                                  <span className="truncate">{c.name}</span>
                                </span>
                                <span className="font-mono text-[11px] text-neutral-400">{c.dialCode}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Phone Input */}
                      <div className="relative flex-1">
                        <Smartphone className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="tel"
                          placeholder="98XXXXXXXX"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          required
                          className="w-full h-11 bg-[#070914] border border-white/10 rounded-2xl pl-10 pr-4 text-xs font-mono text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500 transition-all"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-purple-900/50 active:scale-95 disabled:opacity-50"
                  >
                    <span>Send 6-Digit OTP</span>
                    <ArrowRight className="w-4 h-4 stroke-[3]" />
                  </button>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-xs text-neutral-300">
                      Enter the 6-digit verification code sent to
                    </p>
                    <p className="text-xs font-mono font-bold text-cyan-400 mt-0.5">
                      {selectedCountry.dialCode} {phoneNumber}
                    </p>
                  </div>

                  {/* 6 Digit Input boxes */}
                  <div className="flex justify-between gap-1.5 max-w-xs mx-auto">
                    {otpCode.map((digit, i) => (
                      <input
                        key={i}
                        id={`otp-digit-${i}`}
                        type="text"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleOtpDigitChange(i, e.target.value)}
                        className="w-11 h-12 bg-[#070914] border border-purple-500/40 rounded-xl text-center text-lg font-black font-mono text-cyan-300 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all"
                      />
                    ))}
                  </div>

                  {/* Resend OTP timer */}
                  <div className="flex items-center justify-between text-[11px] pt-1">
                    <button
                      type="button"
                      onClick={() => setOtpStep('enter_phone')}
                      className="text-neutral-400 hover:text-white underline"
                    >
                      Change Number
                    </button>
                    {isTimerRunning ? (
                      <span className="text-neutral-500 font-mono">Resend in {timer}s</span>
                    ) : (
                      <button
                        type="button"
                        onClick={handleSendOtp}
                        className="text-cyan-400 font-bold hover:underline flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" /> Resend OTP
                      </button>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleVerifyOtp}
                    disabled={isLoading}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/40 active:scale-95 disabled:opacity-50"
                  >
                    <span>Verify & Enter DIYO LIVE</span>
                    <ArrowRight className="w-4 h-4 stroke-[3]" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: EMAIL / PASSWORD / SIGNUP */}
          {authMethod === 'email' && (
            <form onSubmit={handleEmailAuth} className="space-y-3.5 animate-in fade-in">
              <div className="flex items-center justify-center gap-4 border-b border-white/5 pb-2">
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className={`text-xs font-bold pb-1 border-b-2 transition-all ${
                    mode === 'login' ? 'border-purple-400 text-white' : 'border-transparent text-neutral-400'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setMode('signup')}
                  className={`text-xs font-bold pb-1 border-b-2 transition-all ${
                    mode === 'signup' ? 'border-purple-400 text-white' : 'border-transparent text-neutral-400'
                  }`}
                >
                  Create Account
                </button>
              </div>

              {mode === 'signup' && (
                <div>
                  <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">
                    Display Name
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="e.g. Star Broadcaster"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full h-11 bg-[#070914] border border-white/10 rounded-2xl pl-10 pr-4 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500 transition-all"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    placeholder="name@trophyparty.live"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full h-11 bg-[#070914] border border-white/10 rounded-2xl pl-10 pr-4 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500 transition-all"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
                    Password
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => alert('Password reset verification link sent to email.')}
                      className="text-[10px] text-purple-400 hover:underline"
                    >
                      Forgot?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full h-11 bg-[#070914] border border-white/10 rounded-2xl pl-10 pr-10 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-purple-900/50 active:scale-95 disabled:opacity-50 mt-1"
              >
                <span>{mode === 'signup' ? 'Create DIYO LIVE Account' : 'Sign In with Email'}</span>
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </button>
            </form>
          )}

          {/* Loading Indicator Overlay */}
          {isLoading && (
            <div className="absolute inset-0 bg-black/85 backdrop-blur-sm rounded-3xl flex flex-col items-center justify-center p-6 text-center z-20 animate-in fade-in">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-0.5 animate-spin mb-3">
                <div className="w-full h-full bg-[#0b0f24] rounded-[14px]" />
              </div>
              <p className="text-xs font-bold text-white">{loadingText || 'Authenticating...'}</p>
              <p className="text-[10px] text-neutral-400 mt-1 font-mono">Secured by DIYO LIVE Identity Engine</p>
            </div>
          )}

        </div>

        {/* Security & Verification Footer */}
        <div className="mt-6 text-center space-y-1.5">
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-neutral-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>256-Bit SSL Encrypted • Anti-Fraud Protection</span>
          </div>
          <p className="text-[10px] text-neutral-500">
            By continuing, you agree to DIYO LIVE's Community Standards & Privacy Policy
          </p>
        </div>

      </div>

    </div>
  );
};
