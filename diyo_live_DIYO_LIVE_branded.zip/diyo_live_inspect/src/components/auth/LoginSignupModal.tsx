import React, { useState } from 'react';
import { 
  X, 
  Radio, 
  Mail, 
  Lock, 
  User, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  Smartphone,
  Eye,
  EyeOff,
  CheckCircle2
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface LoginSignupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessLogin?: (userData: { name: string; username: string; email: string }) => void;
}

export const LoginSignupModal: React.FC<LoginSignupModalProps> = ({
  isOpen,
  onClose,
  onSuccessLogin
}) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'phone'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState('');
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrPhone) {
      alert('Please enter your email, username or phone number');
      return;
    }
    setIsLoading(true);
    playSoundFX('click');

    setTimeout(() => {
      setIsLoading(false);
      setSuccessMsg(
        mode === 'signup' 
          ? '🎉 Welcome to DIYO LIVE! Account created successfully.' 
          : '✨ Welcome back to DIYO LIVE!'
      );
      playSoundFX('win');

      if (onSuccessLogin) {
        onSuccessLogin({
          name: name || (emailOrPhone.includes('@') ? emailOrPhone.split('@')[0] : emailOrPhone),
          username: (name || emailOrPhone).toLowerCase().replace(/[^a-z0-9]/g, '_'),
          email: emailOrPhone.includes('@') ? emailOrPhone : `${emailOrPhone}@diyolive.com`
        });
      }

      setTimeout(() => {
        setSuccessMsg(null);
        onClose();
      }, 1200);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-emerald-500/30 rounded-3xl w-full max-w-md overflow-hidden flex flex-col shadow-2xl shadow-emerald-950/40 relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Top Header Banner */}
        <div className="p-6 text-center border-b border-neutral-800/80 bg-gradient-to-b from-emerald-950/40 to-neutral-900/30">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-amber-400 p-0.5 shadow-xl shadow-emerald-900/40 flex items-center justify-center mb-3">
            <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center">
              <Radio className="w-7 h-7 text-emerald-400 animate-pulse" />
            </div>
          </div>

          <h2 className="font-['Outfit'] text-xl font-black text-white tracking-wide">
            🏆 DIYO <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-400">LIVE</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {mode === 'signup' 
              ? 'Join millions of creators & live stream fans worldwide' 
              : 'Sign in to access 4K streams, party rooms & 3D games'}
          </p>

          {/* Mode Switch Tabs */}
          <div className="flex items-center bg-neutral-950 p-1 rounded-2xl border border-neutral-800 mt-4 max-w-xs mx-auto">
            <button
              type="button"
              onClick={() => { setMode('login'); playSoundFX('click'); }}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
                mode === 'login'
                  ? 'bg-emerald-500 text-neutral-950 font-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setMode('signup'); playSoundFX('click'); }}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
                mode === 'signup'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-neutral-950 font-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Sign Up
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {successMsg && (
            <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {mode === 'signup' && (
            <div>
              <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">
                Full Name / Nickname
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="e.g. Star Creator"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-all"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">
              Email, Phone or SR ID
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="name@example.com or +91..."
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                required
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
                Password
              </label>
              {mode === 'login' && (
                <button
                  type="button"
                  onClick={() => alert('Password reset link sent to your registered contact.')}
                  className="text-[11px] text-emerald-400 hover:underline"
                >
                  Forgot?
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-amber-400 hover:from-emerald-400 hover:to-amber-300 text-neutral-950 font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 active:scale-95 disabled:opacity-50 mt-2"
          >
            {isLoading ? (
              <span>Authenticating...</span>
            ) : (
              <>
                <span>{mode === 'signup' ? 'Create DIYO Account' : 'Sign In to DIYO LIVE'}</span>
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </>
            )}
          </button>

          {/* Social / Quick login */}
          <div className="pt-3 border-t border-neutral-800/80 text-center space-y-2">
            <p className="text-[11px] text-neutral-500 font-mono">
              Official Entertainment Network • 100% Secure
            </p>
            <div className="flex items-center justify-center gap-2 text-[11px] text-neutral-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>DIYO LIVE Verified Authentication</span>
            </div>
          </div>
        </form>

      </div>
    </div>
  );
};
