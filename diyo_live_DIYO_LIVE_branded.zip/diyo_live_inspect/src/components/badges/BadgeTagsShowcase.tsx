import React, { useState } from 'react';
import { 
  Crown, 
  Star, 
  Mic2, 
  Radio, 
  Zap, 
  ShieldCheck, 
  Briefcase, 
  Building2, 
  Coins, 
  Sparkles, 
  Copy, 
  Check, 
  Eye,
  Layers,
  Award,
  Download,
  Image as ImageIcon
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import srLiveProfileFramesImg from '../../assets/images/sr_live_profile_frames_1787214787934.jpg';

export interface BadgeTagConfig {
  id: string;
  name: string;
  category: 'HOST' | 'ADMIN' | 'ORGANIZATION' | 'FINANCIAL';
  primaryColor: string;
  secondaryColor: string;
  accentGlow: string;
  borderStyle: string;
  badgeBg: string;
  textColor: string;
  icon3D: React.ReactNode;
  iconName: string;
  description: string;
  authorityLevel: number;
}

export const BADGE_TAGS_CONFIG: BadgeTagConfig[] = [
  {
    id: 'BADGE-01',
    name: 'CELEBRITY HOST',
    category: 'HOST',
    primaryColor: '#8b5cf6',
    secondaryColor: '#f59e0b',
    accentGlow: 'rgba(168, 85, 247, 0.4)',
    borderStyle: 'border-purple-500/50 shadow-purple-500/30',
    badgeBg: 'bg-gradient-to-r from-purple-950 via-purple-900 to-amber-950',
    textColor: 'text-amber-300',
    icon3D: <Crown className="w-4 h-4 text-amber-400 fill-amber-400 drop-shadow-[0_2px_8px_rgba(245,158,11,0.8)]" />,
    iconName: 'Glowing 3D Crown',
    description: 'Elite top-tier verified celebrity broadcaster with exclusive room privileges and golden banner aura.',
    authorityLevel: 2
  },
  {
    id: 'BADGE-02',
    name: 'TALENT HOST',
    category: 'HOST',
    primaryColor: '#ec4899',
    secondaryColor: '#f43f5e',
    accentGlow: 'rgba(236, 72, 153, 0.4)',
    borderStyle: 'border-pink-500/50 shadow-pink-500/30',
    badgeBg: 'bg-gradient-to-r from-pink-950 via-pink-900 to-rose-900',
    textColor: 'text-pink-200',
    icon3D: <Star className="w-4 h-4 text-pink-400 fill-pink-400 drop-shadow-[0_2px_8px_rgba(236,72,153,0.8)]" />,
    iconName: 'Gleaming 3D Star',
    description: 'High-energy variety streamer with star performances, PK battles, and showcase features.',
    authorityLevel: 2
  },
  {
    id: 'BADGE-03',
    name: 'SINGER HOST',
    category: 'HOST',
    primaryColor: '#06b6d4',
    secondaryColor: '#3b82f6',
    accentGlow: 'rgba(6, 182, 212, 0.4)',
    borderStyle: 'border-cyan-500/50 shadow-cyan-500/30',
    badgeBg: 'bg-gradient-to-r from-cyan-950 via-cyan-900 to-blue-950',
    textColor: 'text-cyan-200',
    icon3D: <Mic2 className="w-4 h-4 text-cyan-300 drop-shadow-[0_2px_8px_rgba(6,182,212,0.8)]" />,
    iconName: '3D Vocal Microphone',
    description: 'Musical acoustic virtuoso with active audio equalizer room effects and HD sound studio audio.',
    authorityLevel: 2
  },
  {
    id: 'BADGE-04',
    name: 'OFFICIAL HOST',
    category: 'HOST',
    primaryColor: '#10b981',
    secondaryColor: '#14b8a6',
    accentGlow: 'rgba(16, 185, 129, 0.4)',
    borderStyle: 'border-emerald-500/50 shadow-emerald-500/30',
    badgeBg: 'bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-950',
    textColor: 'text-emerald-200',
    icon3D: <Radio className="w-4 h-4 text-emerald-300 drop-shadow-[0_2px_8px_rgba(16,185,129,0.8)]" />,
    iconName: '3D Broadcast Mic',
    description: 'Platform-contracted verified official broadcaster with priority frontpage algorithm ranking.',
    authorityLevel: 2
  },
  {
    id: 'BADGE-05',
    name: 'SUPER ADMIN',
    category: 'ADMIN',
    primaryColor: '#ef4444',
    secondaryColor: '#000000',
    accentGlow: 'rgba(239, 68, 68, 0.5)',
    borderStyle: 'border-red-600/60 shadow-red-600/40',
    badgeBg: 'bg-gradient-to-r from-neutral-950 via-red-950 to-neutral-950',
    textColor: 'text-red-300',
    icon3D: <Zap className="w-4 h-4 text-red-500 fill-red-500 drop-shadow-[0_2px_8px_rgba(239,68,68,0.9)]" />,
    iconName: '3D Lightning Shield',
    description: 'Highest tier moderation executive with global ban, instant room takeover, and treasury override power.',
    authorityLevel: 4
  },
  {
    id: 'BADGE-06',
    name: 'ADMIN',
    category: 'ADMIN',
    primaryColor: '#3b82f6',
    secondaryColor: '#94a3b8',
    accentGlow: 'rgba(59, 130, 246, 0.4)',
    borderStyle: 'border-blue-500/50 shadow-blue-500/30',
    badgeBg: 'bg-gradient-to-r from-blue-950 via-slate-900 to-blue-950',
    textColor: 'text-blue-200',
    icon3D: <ShieldCheck className="w-4 h-4 text-blue-400 fill-blue-400/30 drop-shadow-[0_2px_8px_rgba(59,130,246,0.8)]" />,
    iconName: '3D Security Shield',
    description: 'Core live moderation and dispute resolution officer enforcing platform community rules.',
    authorityLevel: 3
  },
  {
    id: 'BADGE-07',
    name: 'MANAGER',
    category: 'ORGANIZATION',
    primaryColor: '#f97316',
    secondaryColor: '#ea580c',
    accentGlow: 'rgba(249, 115, 22, 0.4)',
    borderStyle: 'border-orange-500/50 shadow-orange-500/30',
    badgeBg: 'bg-gradient-to-r from-orange-950 via-amber-950 to-orange-950',
    textColor: 'text-orange-200',
    icon3D: <Briefcase className="w-4 h-4 text-orange-400 drop-shadow-[0_2px_8px_rgba(249,115,22,0.8)]" />,
    iconName: '3D Amber Briefcase',
    description: 'Agency talent coordinator managing host rosters, targets, performance analytics, and support.',
    authorityLevel: 3
  },
  {
    id: 'BADGE-08',
    name: 'AGENCY',
    category: 'ORGANIZATION',
    primaryColor: '#e2e8f0',
    secondaryColor: '#64748b',
    accentGlow: 'rgba(226, 232, 240, 0.3)',
    borderStyle: 'border-slate-400/50 shadow-slate-400/20',
    badgeBg: 'bg-gradient-to-r from-slate-950 via-slate-900 to-zinc-900',
    textColor: 'text-slate-200',
    icon3D: <Building2 className="w-4 h-4 text-slate-300 drop-shadow-[0_2px_8px_rgba(226,232,240,0.7)]" />,
    iconName: '3D Architectural Building',
    description: 'Registered talent agency franchise managing multiple broadcaster contracts and group earnings.',
    authorityLevel: 3
  },
  {
    id: 'BADGE-09',
    name: 'COIN SELLER',
    category: 'FINANCIAL',
    primaryColor: '#eab308',
    secondaryColor: '#f59e0b',
    accentGlow: 'rgba(234, 179, 8, 0.5)',
    borderStyle: 'border-yellow-500/60 shadow-yellow-500/30',
    badgeBg: 'bg-gradient-to-r from-amber-950 via-yellow-950 to-amber-900',
    textColor: 'text-yellow-300',
    icon3D: <Coins className="w-4 h-4 text-yellow-400 fill-yellow-400 drop-shadow-[0_2px_8px_rgba(234,179,8,0.9)]" />,
    iconName: '3D Stacked Gold Coins',
    description: 'Official Treasury-authorized Test Coin distributor for bulk user wallet recharges.',
    authorityLevel: 2
  }
];

export const BadgeTagsShowcase: React.FC = () => {
  const [selectedBadge, setSelectedBadge] = useState<BadgeTagConfig>(BADGE_TAGS_CONFIG[0]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopyTag = (badge: BadgeTagConfig) => {
    navigator.clipboard.writeText(badge.name);
    setCopiedId(badge.id);
    playSoundFX('success');
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-neutral-900 via-purple-950/40 to-neutral-900 border border-neutral-800 relative overflow-hidden shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-black uppercase tracking-wider border border-amber-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                9 High-Impact 3D UI Badge Tags Catalog
              </span>
            </div>
            <h2 className="text-xl lg:text-2xl font-black text-white uppercase tracking-wider font-['Outfit']">
              Modern 3D Glossy UI Badge Tags Design Matrix
            </h2>
            <p className="text-xs text-neutral-300 max-w-2xl">
              Glossy glassmorphism aesthetics with 3D embossed lighting, metallic specular highlights, and real-time interactive role tag styling across live rooms and broadcaster profiles.
            </p>
          </div>
        </div>
      </div>

      {/* 3x3 Grid of 9 3D Glossy Badge Tags */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {BADGE_TAGS_CONFIG.map((badge) => {
          const isSelected = selectedBadge.id === badge.id;

          return (
            <div
              key={badge.id}
              onClick={() => {
                setSelectedBadge(badge);
                playSoundFX('click');
              }}
              className={`p-5 rounded-2xl border transition-all cursor-pointer relative overflow-hidden group ${
                isSelected
                  ? 'bg-neutral-900 border-amber-500 shadow-xl ring-2 ring-amber-500/30'
                  : 'bg-neutral-950/80 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/60'
              }`}
            >
              {/* Subtle Ambient Radial Glow */}
              <div 
                className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-3xl opacity-20 pointer-events-none transition-opacity group-hover:opacity-40"
                style={{ backgroundColor: badge.primaryColor }}
              />

              <div className="flex items-start justify-between gap-2 relative z-10 mb-4">
                <span className="text-[10px] font-mono text-neutral-400 font-bold">
                  #{badge.id} • {badge.category}
                </span>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCopyTag(badge);
                  }}
                  title="Copy tag name"
                  className="p-1 rounded-lg bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 text-xs transition-colors"
                >
                  {copiedId === badge.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              {/* 3D Glossy Pill Badge Component */}
              <div className="flex items-center justify-center py-4 my-1">
                <div 
                  className={`px-5 py-2.5 rounded-full border-2 ${badge.borderStyle} ${badge.badgeBg} flex items-center gap-2.5 shadow-xl backdrop-blur-md transition-transform group-hover:scale-110 relative overflow-hidden`}
                  style={{ boxShadow: `0 10px 25px -3px ${badge.accentGlow}` }}
                >
                  {/* Glossy highlight streak overlay */}
                  <div className="absolute inset-0 bg-gradient-to-b from-white/35 via-transparent to-black/30 pointer-events-none" />

                  <span className="relative z-10">{badge.icon3D}</span>

                  <span className={`relative z-10 text-xs font-black tracking-widest uppercase font-['Outfit'] ${badge.textColor} drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]`}>
                    {badge.name}
                  </span>
                </div>
              </div>

              {/* Spec Details */}
              <div className="pt-3 border-t border-neutral-800/80 text-xs space-y-1.5 relative z-10">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-400">3D Icon Asset:</span>
                  <span className="text-neutral-200 font-medium">{badge.iconName}</span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-400">Color Spectrum:</span>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: badge.primaryColor }} />
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: badge.secondaryColor }} />
                  </div>
                </div>
                <p className="text-[11px] text-neutral-400 pt-1 line-clamp-2">
                  {badge.description}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Badge Live Simulator Card */}
      <div className="p-5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-400" />
            <h4 className="text-sm font-black text-white uppercase tracking-wider">
              Live Room & Profile Tag Simulator: {selectedBadge.name}
            </h4>
          </div>
          <span className="text-xs text-neutral-400 font-mono">
            Authority Rank: Level {selectedBadge.authorityLevel}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          
          {/* Surface 1: Broadcaster Stream Header */}
          <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
            <span className="text-[10px] font-bold uppercase text-neutral-400">1. Live Stream Broadcaster Header</span>
            <div className="p-2.5 rounded-xl bg-black/60 border border-white/10 flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full border-2 border-amber-400 overflow-hidden relative">
                <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150" alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white text-xs">Aarav Mehta</span>
                  <div className={`px-2 py-0.5 rounded-full border ${selectedBadge.borderStyle} ${selectedBadge.badgeBg} flex items-center gap-1 text-[9px] font-bold ${selectedBadge.textColor}`}>
                    {selectedBadge.icon3D}
                    <span>{selectedBadge.name}</span>
                  </div>
                </div>
                <span className="text-[10px] text-amber-400 font-mono">💎 24,500 diamonds</span>
              </div>
            </div>
          </div>

          {/* Surface 2: Live Chat Message Bubble */}
          <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
            <span className="text-[10px] font-bold uppercase text-neutral-400">2. Real-Time Chat Message Bubble</span>
            <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <div className={`px-1.5 py-0.2 rounded-full border ${selectedBadge.borderStyle} ${selectedBadge.badgeBg} flex items-center gap-1 text-[9px] font-bold ${selectedBadge.textColor}`}>
                  {selectedBadge.icon3D}
                  <span>{selectedBadge.name}</span>
                </div>
                <span className="font-bold text-white text-[11px]">Aarav Mehta:</span>
              </div>
              <p className="text-[11px] text-neutral-300">
                Welcome everyone to the official DIYO LIVE broadcast! 🚀🎉
              </p>
            </div>
          </div>

          {/* Surface 3: User Profile Badge Showcase */}
          <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
            <span className="text-[10px] font-bold uppercase text-neutral-400">3. Verified Profile Honor Tag</span>
            <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-white text-[11px]">Primary Role Tag</span>
              </div>
              <div className={`px-2.5 py-0.5 rounded-full border ${selectedBadge.borderStyle} ${selectedBadge.badgeBg} flex items-center gap-1.5 text-[10px] font-bold ${selectedBadge.textColor}`}>
                {selectedBadge.icon3D}
                <span>{selectedBadge.name}</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Official DIYO LIVE 6-Role Profile Frame Collection */}
      <div className="p-6 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-5 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <ImageIcon className="w-5 h-5 text-amber-400" />
              <h3 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
                Official DIYO LIVE Profile Frame Collection (2×3 Grid)
              </h3>
            </div>
            <p className="text-xs text-neutral-400">
              High-definition 3D gold and gemstone avatar frames for Super Admin, Admin, Agency, Manager, Coin Seller, and My Add with hollow cutout centers for user avatars.
            </p>
          </div>

          <a
            href={srLiveProfileFramesImg}
            download="SR_LIVE_Official_Profile_Frames_Collection.jpg"
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all hover:scale-105 active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download Master Sheet (4K)</span>
          </a>
        </div>

        {/* High Res Frame Image Presentation */}
        <div className="rounded-xl overflow-hidden border border-neutral-700 bg-neutral-950 p-2 shadow-inner group relative">
          <img
            src={srLiveProfileFramesImg}
            alt="Official DIYO LIVE 6-Role Profile Frames Collection"
            referrerPolicy="no-referrer"
            className="w-full h-auto object-cover rounded-lg transition-transform duration-300 group-hover:scale-[1.01]"
          />
        </div>

        {/* 6 Roles Breakdown */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-xs pt-1">
          <div className="p-2.5 rounded-xl bg-neutral-950 border border-red-900/40 text-center space-y-1">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-red-500 mb-0.5"></span>
            <p className="font-black text-red-400 tracking-wider">1. SUPER ADMIN</p>
            <p className="text-[10px] text-neutral-400">Crimson & Gold with Fiery Wings & SA Crown</p>
          </div>

          <div className="p-2.5 rounded-xl bg-neutral-950 border border-blue-900/40 text-center space-y-1">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-blue-500 mb-0.5"></span>
            <p className="font-black text-blue-400 tracking-wider">2. ADMIN</p>
            <p className="text-[10px] text-neutral-400">Sapphire & Gold with Blue Angelic Wings</p>
          </div>

          <div className="p-2.5 rounded-xl bg-neutral-950 border border-purple-900/40 text-center space-y-1">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-purple-500 mb-0.5"></span>
            <p className="font-black text-purple-400 tracking-wider">3. AGENCY</p>
            <p className="text-[10px] text-neutral-400">Royal Purple & Gold with Amethyst Gems</p>
          </div>

          <div className="p-2.5 rounded-xl bg-neutral-950 border border-emerald-900/40 text-center space-y-1">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 mb-0.5"></span>
            <p className="font-black text-emerald-400 tracking-wider">4. MANAGER</p>
            <p className="text-[10px] text-neutral-400">Emerald & Gold with Royal Laurel Ornaments</p>
          </div>

          <div className="p-2.5 rounded-xl bg-neutral-950 border border-amber-900/40 text-center space-y-1">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-yellow-500 mb-0.5"></span>
            <p className="font-black text-yellow-400 tracking-wider">5. COIN SELLER</p>
            <p className="text-[10px] text-neutral-400">Pure Gold & Obsidian with Stacks of Coins</p>
          </div>

          <div className="p-2.5 rounded-xl bg-neutral-950 border border-cyan-900/40 text-center space-y-1">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-cyan-400 mb-0.5"></span>
            <p className="font-black text-cyan-300 tracking-wider">6. MY ADD</p>
            <p className="text-[10px] text-neutral-400">Futuristic Neon Cyan & Magenta Cyber Wings</p>
          </div>
        </div>
      </div>

    </div>
  );
};
