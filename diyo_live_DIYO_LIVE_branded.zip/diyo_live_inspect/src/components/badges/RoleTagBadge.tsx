import React from 'react';
import { Crown, ShieldCheck, Briefcase, Building2, Coins, Megaphone, Zap } from 'lucide-react';
import { UserRole } from '../../types/ownerTypes';
import { SRLiveRoleType } from '../frames/SRLiveRoleFrame';

interface RoleTagBadgeProps {
  role?: UserRole | SRLiveRoleType | string | null;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  showIcon?: boolean;
  glow?: boolean;
  className?: string;
}

export const RoleTagBadge: React.FC<RoleTagBadgeProps> = ({
  role,
  size = 'md',
  showIcon = true,
  glow = true,
  className = ''
}) => {
  if (!role) return null;

  let normRole = role.toUpperCase().replace(/[\s-]+/g, '_').trim();
  if (normRole === 'OWNER') normRole = 'SUPER_ADMIN';

  // Size configurations
  const sizeClasses = {
    xs: 'px-2 py-0.5 text-[9px] gap-1 rounded-md font-black tracking-wider shadow-sm',
    sm: 'px-2.5 py-0.5 text-[10px] gap-1.5 rounded-lg font-black tracking-wider shadow-md',
    md: 'px-3 py-1 text-xs gap-1.5 rounded-xl font-black tracking-widest shadow-lg',
    lg: 'px-4 py-1.5 text-sm gap-2 rounded-2xl font-black tracking-widest shadow-xl'
  };

  const iconSizes = {
    xs: 'w-2.5 h-2.5',
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4 h-4'
  };

  // 0. OWNER (Supreme Founder & Root)
  if (normRole === 'OWNER') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-amber-950 via-yellow-900 to-amber-950 
          text-amber-200 font-black tracking-widest uppercase
          border-2 border-amber-400 
          ${glow ? 'shadow-[0_0_20px_rgba(245,158,11,0.9)] animate-pulse' : ''}
          relative overflow-hidden group ${className}`}
        title="👑 TROPHY PARTY SUPREME OWNER - Absolute Platform Founder"
      >
        <span className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-300/30 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
        {showIcon && <Crown className={`${iconSizes[size]} text-amber-300 fill-amber-300 drop-shadow-[0_0_8px_rgba(245,158,11,1)]`} />}
        <span className="relative font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] text-amber-200">👑 TROPHY PARTY OWNER 👑</span>
      </span>
    );
  }

  // 1. SUPER ADMIN
  if (normRole === 'SUPER_ADMIN') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-red-950 via-rose-900 to-red-950 
          text-amber-200 font-black tracking-widest uppercase
          border border-amber-400/80 
          ${glow ? 'shadow-[0_0_14px_rgba(239,68,68,0.7)]' : ''}
          relative overflow-hidden group ${className}`}
        title="👑 SUPER ADMIN - Global Platform Authority"
      >
        <span className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-400/20 to-transparent -translate-x-full animate-[shimmer_2.5s_infinite]" />
        {showIcon && <Crown className={`${iconSizes[size]} text-amber-400 fill-amber-400 drop-shadow`} />}
        <span className="relative font-black drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">SUPER ADMIN</span>
        <span className="text-[10px] text-amber-400 font-black">★</span>
      </span>
    );
  }

  // 2. ADMIN
  if (normRole === 'ADMIN') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-blue-950 via-indigo-900 to-blue-950 
          text-yellow-200 font-black tracking-widest uppercase
          border border-yellow-400/80 
          ${glow ? 'shadow-[0_0_14px_rgba(59,130,246,0.7)]' : ''}
          relative overflow-hidden group ${className}`}
        title="🛡️ ADMIN - Official Platform Moderation Officer"
      >
        <span className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-400/20 to-transparent -translate-x-full animate-[shimmer_2.5s_infinite]" />
        {showIcon && <ShieldCheck className={`${iconSizes[size]} text-yellow-300 fill-yellow-300/30 drop-shadow`} />}
        <span className="relative font-black drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">ADMIN</span>
        <span className="text-[10px] text-yellow-300 font-black">🛡️</span>
      </span>
    );
  }

  // 3. MANAGER
  if (normRole === 'MANAGER') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-emerald-950 via-teal-900 to-emerald-950 
          text-emerald-200 font-black tracking-widest uppercase
          border border-yellow-400/70 
          ${glow ? 'shadow-[0_0_14px_rgba(16,185,129,0.7)]' : ''}
          relative overflow-hidden group ${className}`}
        title="💼 MANAGER - Guild & Agency Operations Lead"
      >
        {showIcon && <Briefcase className={`${iconSizes[size]} text-yellow-300 drop-shadow`} />}
        <span className="relative font-black drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">MANAGER</span>
        <span className="text-[10px] text-emerald-300 font-black">✦</span>
      </span>
    );
  }

  // 4. AGENCY
  if (normRole === 'AGENCY') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-purple-950 via-fuchsia-900 to-purple-950 
          text-amber-200 font-black tracking-widest uppercase
          border border-amber-300/80 
          ${glow ? 'shadow-[0_0_14px_rgba(168,85,247,0.7)]' : ''}
          relative overflow-hidden group ${className}`}
        title="🏢 AGENCY - Official Talent Guild Agency"
      >
        {showIcon && <Building2 className={`${iconSizes[size]} text-amber-300 drop-shadow`} />}
        <span className="relative font-black drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">AGENCY</span>
        <span className="text-[10px] text-purple-300 font-black">🏢</span>
      </span>
    );
  }

  // 5. COIN SELLER
  if (normRole === 'COIN_SELLER') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-neutral-950 via-amber-950 to-neutral-950 
          text-yellow-300 font-black tracking-widest uppercase
          border border-yellow-400 
          ${glow ? 'shadow-[0_0_14px_rgba(234,179,8,0.8)]' : ''}
          relative overflow-hidden group ${className}`}
        title="🪙 COIN SELLER - Authorized Coin Merchant"
      >
        {showIcon && <Coins className={`${iconSizes[size]} text-yellow-400 fill-yellow-400 drop-shadow`} />}
        <span className="relative font-black drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">COIN SELLER</span>
        <span className="text-[10px] text-yellow-400 font-black">🪙</span>
      </span>
    );
  }

  // 6. MY ADD
  if (normRole === 'MY_ADD') {
    return (
      <span
        className={`inline-flex items-center select-none ${sizeClasses[size]} 
          bg-gradient-to-r from-cyan-950 via-purple-950 to-pink-950 
          text-cyan-200 font-black tracking-widest uppercase
          border border-cyan-300/80 
          ${glow ? 'shadow-[0_0_14px_rgba(6,182,212,0.8)]' : ''}
          relative overflow-hidden group ${className}`}
        title="📢 MY ADD - Official Platform Promoter"
      >
        {showIcon && <Megaphone className={`${iconSizes[size]} text-pink-300 drop-shadow`} />}
        <span className="relative font-black drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">MY ADD</span>
        <span className="text-[10px] text-cyan-300 font-black">⚡</span>
      </span>
    );
  }

  return null;
};
