import React from 'react';
import { Crown, Star, Shield, Sparkles, Flame, Zap } from 'lucide-react';

export type VipTierCategory = 
  | 'bronze' 
  | 'silver' 
  | 'gold' 
  | 'platinum' 
  | 'diamond' 
  | 'dragon' 
  | 'galaxy' 
  | 'emperor' 
  | 'solar' 
  | 'celestial';

export interface VipBadgeProps {
  level?: number;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  showIcon?: boolean;
  className?: string;
  glow?: boolean;
  animate?: boolean;
}

export function getVipTier(level?: number): {
  tier: VipTierCategory;
  tierName: string;
  title: string;
  badgeLabel: string;
  emoji: string;
} {
  const lvl = typeof level === 'number' && level > 0 ? level : 1;

  if (lvl >= 10) {
    return {
      tier: 'celestial',
      tierName: 'Celestial Supreme God',
      title: 'Apex Deity',
      badgeLabel: `VIP ${lvl}`,
      emoji: '🌟'
    };
  }
  if (lvl === 9) {
    return {
      tier: 'solar',
      tierName: 'Solar Sovereign',
      title: 'Sun Monarch',
      badgeLabel: 'VIP 9',
      emoji: '⚡'
    };
  }
  if (lvl === 8) {
    return {
      tier: 'emperor',
      tierName: 'Imperial Emperor',
      title: 'Supreme Royal Sovereign',
      badgeLabel: 'VIP 8',
      emoji: '👑'
    };
  }
  if (lvl === 7) {
    return {
      tier: 'galaxy',
      tierName: 'Galaxy Lord',
      title: 'Astral Ruler',
      badgeLabel: 'VIP 7',
      emoji: '🌌'
    };
  }
  if (lvl === 6) {
    return {
      tier: 'dragon',
      tierName: 'Dragon Overlord',
      title: 'Dragon Monarch',
      badgeLabel: 'VIP 6',
      emoji: '🐉'
    };
  }
  if (lvl === 5) {
    return {
      tier: 'diamond',
      tierName: 'Diamond Prince',
      title: 'Diamond Nobility',
      badgeLabel: 'VIP 5',
      emoji: '💎'
    };
  }
  if (lvl === 4) {
    return {
      tier: 'platinum',
      tierName: 'Platinum Duke',
      title: 'Platinum Duke',
      badgeLabel: 'VIP 4',
      emoji: '🔷'
    };
  }
  if (lvl === 3) {
    return {
      tier: 'gold',
      tierName: 'Golden Baron',
      title: 'Golden Baron',
      badgeLabel: 'VIP 3',
      emoji: '🥇'
    };
  }
  if (lvl === 2) {
    return {
      tier: 'silver',
      tierName: 'Silver Guardian',
      title: 'Silver Guardian',
      badgeLabel: 'VIP 2',
      emoji: '🥈'
    };
  }
  return {
    tier: 'bronze',
    tierName: 'Bronze Noble',
    title: 'Bronze Noble',
    badgeLabel: 'VIP 1',
    emoji: '🥉'
  };
}

export const VipBadge: React.FC<VipBadgeProps> = ({
  level = 1,
  size = 'sm',
  showLabel = true,
  showIcon = true,
  className = '',
  glow = true,
  animate = false
}) => {
  if (!level || level <= 0) return null;

  const { tier, badgeLabel, tierName, emoji } = getVipTier(level);

  const sizeClasses = {
    xs: 'px-1.5 py-0.2 text-[9px] gap-0.5 rounded font-black tracking-wider',
    sm: 'px-2 py-0.5 text-[10px] gap-1 rounded-md font-black tracking-wider',
    md: 'px-2.5 py-1 text-xs gap-1.5 rounded-lg font-black tracking-widest',
    lg: 'px-3.5 py-1.5 text-sm gap-2 rounded-xl font-black tracking-widest'
  };

  const iconSizes = {
    xs: 'w-2.5 h-2.5',
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4 h-4'
  };

  // VIP 10: CELESTIAL SUPREME GOD
  if (tier === 'celestial') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-pink-600 via-purple-600 to-amber-400 
          text-white font-black uppercase
          border border-pink-200 
          ${glow ? 'shadow-[0_0_16px_rgba(236,72,153,0.9)]' : 'shadow-md'}
          relative overflow-hidden group ${animate ? 'animate-pulse' : ''} ${className}`}
        title={`🌟 ${tierName} (Level ${level})`}
      >
        <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none" />
        {showIcon && <Sparkles className={`${iconSizes[size]} text-amber-200 fill-amber-300`} />}
        <span className="relative font-black drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none drop-shadow">{emoji}</span>
      </span>
    );
  }

  // VIP 9: SOLAR SOVEREIGN
  if (tier === 'solar') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-orange-600 via-amber-500 to-yellow-400 
          text-black font-black uppercase
          border border-amber-200 
          ${glow ? 'shadow-[0_0_14px_rgba(245,158,11,0.85)]' : 'shadow-md'}
          relative overflow-hidden group ${className}`}
        title={`⚡ ${tierName} (Level ${level})`}
      >
        {showIcon && <Zap className={`${iconSizes[size]} text-black fill-black`} />}
        <span className="relative font-black tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none">{emoji}</span>
      </span>
    );
  }

  // VIP 8: IMPERIAL EMPEROR
  if (tier === 'emperor') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 
          text-neutral-950 font-black uppercase
          border-2 border-yellow-100 
          ${glow ? 'shadow-[0_0_14px_rgba(234,179,8,0.8)]' : 'shadow-md'}
          relative overflow-hidden group ${className}`}
        title={`👑 ${tierName} (Level ${level})`}
      >
        {showIcon && <Crown className={`${iconSizes[size]} fill-neutral-950 text-neutral-950`} />}
        <span className="relative font-black tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none">{emoji}</span>
      </span>
    );
  }

  // VIP 7: GALAXY LORD
  if (tier === 'galaxy') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-indigo-700 via-purple-600 to-cyan-600 
          text-white font-black uppercase
          border border-indigo-300/80 
          ${glow ? 'shadow-[0_0_12px_rgba(99,102,241,0.7)]' : 'shadow-sm'}
          relative overflow-hidden group ${className}`}
        title={`🌌 ${tierName} (Level ${level})`}
      >
        {showIcon && <Sparkles className={`${iconSizes[size]} text-cyan-200 fill-cyan-300`} />}
        <span className="relative font-black tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none">{emoji}</span>
      </span>
    );
  }

  // VIP 6: DRAGON OVERLORD
  if (tier === 'dragon') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-rose-700 via-red-600 to-amber-600 
          text-white font-black uppercase
          border border-rose-400/80 
          ${glow ? 'shadow-[0_0_12px_rgba(244,63,94,0.7)]' : 'shadow-sm'}
          relative overflow-hidden group ${className}`}
        title={`🐉 ${tierName} (Level ${level})`}
      >
        {showIcon && <Flame className={`${iconSizes[size]} text-amber-300 fill-amber-400`} />}
        <span className="relative font-black tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none">{emoji}</span>
      </span>
    );
  }

  // VIP 5: DIAMOND PRINCE
  if (tier === 'diamond') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-purple-700 via-pink-600 to-indigo-700 
          text-white font-black uppercase
          border border-purple-300/80 
          ${glow ? 'shadow-[0_0_12px_rgba(192,132,252,0.7)]' : 'shadow-sm'}
          relative overflow-hidden group ${className}`}
        title={`💎 ${tierName} (Level ${level})`}
      >
        {showIcon && <Crown className={`${iconSizes[size]} text-pink-200 fill-pink-300`} />}
        <span className="relative font-black tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none">{emoji}</span>
      </span>
    );
  }

  // VIP 4: PLATINUM DUKE
  if (tier === 'platinum') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-sky-700 via-blue-600 to-indigo-700 
          text-white font-black uppercase
          border border-sky-300/80 
          ${glow ? 'shadow-[0_0_10px_rgba(56,189,248,0.6)]' : 'shadow-sm'}
          relative overflow-hidden group ${className}`}
        title={`🔷 ${tierName} (Level ${level})`}
      >
        {showIcon && <Star className={`${iconSizes[size]} text-sky-200 fill-sky-300`} />}
        <span className="relative font-black tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none">{emoji}</span>
      </span>
    );
  }

  // VIP 3: GOLDEN BARON
  if (tier === 'gold') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-700 
          text-neutral-950 font-black uppercase
          border border-yellow-200 
          ${glow ? 'shadow-[0_0_10px_rgba(234,179,8,0.6)]' : 'shadow-sm'}
          relative overflow-hidden group ${className}`}
        title={`🥇 ${tierName} (Level ${level})`}
      >
        {showIcon && <Crown className={`${iconSizes[size]} text-neutral-950 fill-neutral-950`} />}
        <span className="relative font-black tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none">{emoji}</span>
      </span>
    );
  }

  // VIP 2: SILVER GUARDIAN
  if (tier === 'silver') {
    return (
      <span
        className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
          bg-gradient-to-r from-slate-700 via-slate-500 to-zinc-700 
          text-white font-black uppercase
          border border-slate-300/70 
          ${glow ? 'shadow-[0_0_8px_rgba(226,232,240,0.5)]' : 'shadow-sm'}
          relative overflow-hidden group ${className}`}
        title={`🥈 ${tierName} (Level ${level})`}
      >
        {showIcon && <Star className={`${iconSizes[size]} text-slate-200 fill-slate-200`} />}
        <span className="relative font-black tracking-wider">
          {showLabel ? badgeLabel : `V${level}`}
        </span>
        <span className="text-[10px] leading-none">{emoji}</span>
      </span>
    );
  }

  // VIP 1: BRONZE NOBLE
  return (
    <span
      className={`inline-flex items-center select-none font-sans ${sizeClasses[size]} 
        bg-gradient-to-r from-[#78350f] via-[#92400e] to-[#451a03] 
        text-amber-100 font-black uppercase
        border border-amber-500/70 
        ${glow ? 'shadow-[0_0_8px_rgba(217,119,6,0.45)]' : 'shadow-sm'}
        relative overflow-hidden group ${className}`}
      title={`🥉 ${tierName} (Level ${level})`}
    >
      {showIcon && <Shield className={`${iconSizes[size]} text-amber-300 fill-amber-500/40`} />}
      <span className="relative font-black tracking-wider">
        {showLabel ? badgeLabel : `V${level}`}
      </span>
      <span className="text-[10px] leading-none">{emoji}</span>
    </span>
  );
};
