import React, { useEffect, useState } from 'react';
import { Radio, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onFinish?: () => void;
  duration?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  duration = 2000
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [fadeProgress, setFadeProgress] = useState(false);

  useEffect(() => {
    const fadeTimer = setTimeout(() => {
      setFadeProgress(true);
    }, duration - 400);

    const endTimer = setTimeout(() => {
      setIsVisible(false);
      if (onFinish) onFinish();
    }, duration);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(endTimer);
    };
  }, [duration, onFinish]);

  if (!isVisible) return null;

  return (
    <div
      id="sr-live-splash-screen"
      className={`fixed inset-0 z-[100] bg-neutral-950 flex flex-col items-center justify-center p-6 select-none transition-opacity duration-400 ${
        fadeProgress ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Glow Effects */}
      <div className="absolute w-72 h-72 rounded-full bg-gradient-to-tr from-emerald-600/30 via-teal-500/20 to-amber-500/20 blur-3xl pointer-events-none animate-pulse" />

      {/* Main Logo Container */}
      <div className="relative flex flex-col items-center gap-5 z-10">
        <div className="relative flex items-center justify-center w-24 h-24 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-amber-400 p-1 shadow-2xl shadow-emerald-900/60 animate-bounce-subtle">
          <div className="w-full h-full bg-neutral-950 rounded-[22px] flex items-center justify-center">
            <Radio className="w-12 h-12 text-emerald-400 animate-pulse" />
          </div>
          <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-5 w-5 bg-emerald-500 border-2 border-neutral-950" />
          </span>
        </div>

        {/* Title */}
        <div className="text-center space-y-1.5">
          <h1 className="font-['Outfit'] text-2xl sm:text-3xl font-black tracking-wider text-white">
            🏆 DIYO <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-400">LIVE</span>
          </h1>
          <p className="text-xs text-neutral-400 font-mono tracking-widest uppercase">
            Multi-Seat Party Rooms & PK Battles
          </p>
        </div>

        {/* Loading Spinner / Progress */}
        <div className="w-48 h-1.5 bg-neutral-900 rounded-full overflow-hidden mt-6 border border-neutral-800">
          <div className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400 rounded-full animate-[progress_1.8s_ease-in-out_infinite]" />
        </div>

        {/* Android / Play Store label badge */}
        <div className="flex items-center gap-2 mt-4 px-3 py-1 rounded-full bg-neutral-900/80 border border-neutral-800 text-[10px] text-neutral-400 font-mono">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>Official Android & Play Store Edition</span>
        </div>
      </div>

      {/* Footer copyright */}
      <div className="absolute bottom-6 text-center text-[10px] text-neutral-600 font-mono">
        © 2026 DIYO LIVE. Powered by DIYO LIVE Entertainment Pvt. Ltd.
      </div>
    </div>
  );
};
