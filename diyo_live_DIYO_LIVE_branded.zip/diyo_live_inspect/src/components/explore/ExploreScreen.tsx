import React, { useState } from 'react';
import { PartyLiveHomeScreen } from './PartyLiveHomeScreen';
import { MOCK_LIVE_ROOMS } from '../../data/mockOwnerData';

interface ExploreScreenProps {
  onSelectStream: (streamId: string) => void;
  onOpenGoLive: () => void;
  onOpenVideoLive: () => void;
  onOpenPartyLive: () => void;
  onOpenLeaderboard?: () => void;
  banners?: any[];
  liveRooms?: any[];
}

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  onSelectStream,
  onOpenGoLive,
  onOpenVideoLive,
  onOpenPartyLive,
  onOpenLeaderboard,
  banners = [],
  liveRooms = MOCK_LIVE_ROOMS
}) => {
  return (
    <PartyLiveHomeScreen
      banners={banners}
      liveRooms={liveRooms}
      onSelectRoom={onSelectStream}
      onOpenGoLive={onOpenGoLive}
      onOpenVideoLive={onOpenVideoLive}
      onOpenPartyLive={onOpenPartyLive}
      onOpenLeaderboard={onOpenLeaderboard || (() => {})}
      onOpenSearch={() => {
        // Trigger search modal or scroll to search
      }}
      onOpenCalendar={() => {
        // Open events calendar
      }}
    />
  );
};
