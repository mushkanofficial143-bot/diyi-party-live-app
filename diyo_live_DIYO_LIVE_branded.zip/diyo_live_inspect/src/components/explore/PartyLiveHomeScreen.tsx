import React, { useState, useEffect } from 'react';
import {
  Search,
  Trophy,
  Crown,
  Flame,
  Star,
  Sparkles,
  Radio,
  Calendar,
  Home,
  Users,
  Compass,
  ChevronRight,
  ShieldCheck,
  Gift,
  Heart,
  Globe,
  Tv,
  Play,
  Zap,
  Bell,
  X,
  Video
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { RankLeaderboardModal } from '../profile/RankLeaderboardModal';

interface PartyLiveHomeScreenProps {
  banners: any[];
  liveRooms: any[];
  onSelectRoom: (roomId: string) => void;
  onOpenGoLive: () => void;
  onOpenVideoLive: () => void;
  onOpenPartyLive: () => void;
  onOpenLeaderboard: () => void;
  onOpenSearch: () => void;
  onOpenCalendar: () => void;
}

export const PartyLiveHomeScreen: React.FC<PartyLiveHomeScreenProps> = ({
  banners = [],
  liveRooms = [],
  onSelectRoom,
  onOpenGoLive,
  onOpenVideoLive,
  onOpenPartyLive,
  onOpenLeaderboard,
  onOpenSearch,
  onOpenCalendar
}) => {
  const [topNavTab, setTopNavTab] = useState<'Mine' | 'Party' | 'Events'>('Party');
  const [categoryFilter, setCategoryFilter] = useState<'Popular' | 'New'>('Popular');
  const [activeBannerIndex, setActiveBannerIndex] = useState(0);
  const [isRankModalOpen, setIsRankModalOpen] = useState(false);
  const [rankingSubTab, setRankingSubTab] = useState<'GIFT' | 'FRIENDS' | 'FAMILY'>('GIFT');
  const [rankingPeriod, setRankingPeriod] = useState<'Daily' | 'Weekly' | 'Monthly' | 'All Time'>('Daily');

  // Live Activity Ticker notification
  const [activityTicker, setActivityTicker] = useState<{
    avatar: string;
    username: string;
    action: string;
    giftName: string;
  } | null>({
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
    username: 'SR Angel',
    action: 'sent a Golden Castle 🏰',
    giftName: 'Golden Castle'
  });

  // Auto-rotate banners
  useEffect(() => {
    const activeBanners = banners.filter(b => b.active);
    if (activeBanners.length <= 1) return;
    const timer = setInterval(() => {
      setActiveBannerIndex(prev => (prev + 1) % activeBanners.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [banners]);

  // Rotate activity ticker items
  useEffect(() => {
    const tickerItems = [
      { avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', username: 'Vikram Rajput', action: 'sent a Diamond Yacht 🛥️', giftName: 'Diamond Yacht' },
      { avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100', username: 'Pooja Verma', action: 'unlocked VIP 8 Status 👑', giftName: 'VIP 8' },
      { avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', username: 'Kabir Khan', action: 'joined Agency Guild AG-01 ⭐', giftName: 'Guild Join' }
    ];
    let idx = 0;
    const timer = setInterval(() => {
      idx = (idx + 1) % tickerItems.length;
      setActivityTicker(tickerItems[idx]);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const activeBanners = banners.filter(b => b.active);
  const currentBanner = activeBanners[activeBannerIndex] || {
    id: 'default-1',
    title: '🏆 DIYO Global Gala 2026',
    description: 'Join elite voice rooms & win 1,000,000+ diamonds daily!',
    imageUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80'
  };

  const recommendedRooms = liveRooms.filter(r => r.isRecommended || r.recommendRank);
  const displayedRooms = liveRooms.filter(r => {
    if (categoryFilter === 'New') return r.roomStatus === 'Active' && (r.tag?.includes('New') || r.createdAt);
    return true; // Popular
  });

  return (
    <div
      id="party-live-home-screen"
      className="w-full max-w-md md:max-w-lg mx-auto min-h-screen bg-[#070913] text-white pt-safe-top pb-56 select-none animate-in fade-in"
    >
      {/* ========================================================================= */}
      {/* 1. TOP HEADER / MAIN NAVIGATION                                           */}
      {/* ========================================================================= */}
      <header className="sticky top-0 z-40 bg-[#070913]/95 backdrop-blur-2xl px-4 pt-3 pb-2.5 flex items-center justify-between border-b border-white/10 shadow-lg">
        
        {/* 3 Main Tabs: Mine | Party | Events */}
        <div className="flex items-center gap-1.5 bg-[#11152d] p-1 rounded-full border border-white/10">
          {(['Mine', 'Party', 'Events'] as const).map((tab) => {
            const isSelected = topNavTab === tab;
            return (
              <button
                key={tab}
                onClick={() => {
                  playSoundFX('click');
                  setTopNavTab(tab);
                  if (tab === 'Events') {
                    onOpenCalendar();
                  }
                }}
                className={`relative px-3.5 py-1.5 rounded-full text-xs font-black tracking-wide transition-all ${
                  isSelected
                    ? 'bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 text-white shadow-md shadow-rose-950/60 scale-105'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {tab}
                {isSelected && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-amber-300 rounded-full animate-pulse" />
                )}
              </button>
            );
          })}
        </div>

        {/* Right-side Icons: Calendar, Room Home, Search */}
        <div className="flex items-center gap-2">
          {/* Calendar / Events */}
          <button
            onClick={() => {
              playSoundFX('click');
              onOpenCalendar();
            }}
            className="w-9 h-9 rounded-full bg-[#11152d] border border-white/10 flex items-center justify-center text-amber-400 hover:bg-amber-500/20 transition-all shadow-sm"
            title="Events Calendar"
          >
            <Calendar className="w-4 h-4" />
          </button>

          {/* Home / Room */}
          <button
            onClick={() => {
              playSoundFX('click');
              onOpenPartyLive();
            }}
            className="w-9 h-9 rounded-full bg-[#11152d] border border-white/10 flex items-center justify-center text-cyan-400 hover:bg-cyan-500/20 transition-all shadow-sm"
            title="Party Room Home"
          >
            <Home className="w-4 h-4" />
          </button>

          {/* Search Icon */}
          <button
            onClick={() => {
              playSoundFX('click');
              onOpenSearch();
            }}
            className="w-9 h-9 rounded-full bg-[#11152d] border border-white/10 flex items-center justify-center text-rose-400 hover:bg-rose-500/20 transition-all shadow-sm"
            title="Search Users, Rooms & Hosts"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Go Live Broadcast Button */}
          <button
            onClick={() => {
              playSoundFX('superchat');
              onOpenGoLive();
            }}
            className="px-3 py-1.5 rounded-full bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 text-white text-xs font-black shadow-lg shadow-rose-950/60 flex items-center gap-1.5 active:scale-95 transition-all animate-pulse"
            title="Go Live (Video or Party)"
          >
            <Video className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Go Live</span>
          </button>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* 3. LIVE ACTIVITY / REWARD NOTIFICATION TICKER                             */}
      {/* ========================================================================= */}
      {activityTicker && (
        <div className="px-4 pt-2.5">
          <div className="bg-gradient-to-r from-amber-500/15 via-purple-600/15 to-rose-500/15 border border-amber-500/30 rounded-2xl p-2.5 flex items-center justify-between shadow-md backdrop-blur-md animate-in slide-in-from-top-2">
            <div className="flex items-center gap-2.5">
              <img src={activityTicker.avatar} alt="" className="w-7 h-7 rounded-full object-cover ring-2 ring-amber-400/60" />
              <div className="text-xs">
                <span className="font-bold text-amber-300">{activityTicker.username}</span>{' '}
                <span className="text-neutral-300">{activityTicker.action}</span>
              </div>
            </div>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40">
              🎁 Live Gift
            </span>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. TOP PREMIUM BANNER SLIDER                                              */}
      {/* ========================================================================= */}
      <div className="px-4 pt-3">
        <div className="relative w-full h-36 sm:h-42 rounded-3xl overflow-hidden shadow-2xl border border-white/15 group">
          <img
            src={currentBanner.imageUrl || currentBanner.image}
            alt={currentBanner.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#070913] via-[#070913]/30 to-transparent p-4 flex flex-col justify-end">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-400 bg-black/40 px-2 py-0.5 rounded-full w-fit mb-1">
              ✨ Featured Event
            </span>
            <h2 className="text-sm sm:text-base font-black text-white drop-shadow-md">
              {currentBanner.title}
            </h2>
            <p className="text-[11px] text-neutral-300 line-clamp-1">
              {currentBanner.description}
            </p>
          </div>

          {/* Pagination Dots */}
          {activeBanners.length > 1 && (
            <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full">
              {activeBanners.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveBannerIndex(idx)}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === activeBannerIndex ? 'w-5 bg-amber-400' : 'w-1.5 bg-white/50'
                  }`}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. RANKING SECTION (3 Premium Cards)                                      */}
      {/* ========================================================================= */}
      <div className="px-4 pt-4">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs sm:text-sm font-black tracking-wide text-white">Global Leaderboard Rankings</h3>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              setIsRankModalOpen(true);
            }}
            className="text-[11px] font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            View All <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 3 Ranking Cards */}
        <div className="grid grid-cols-3 gap-2.5">
          {/* 1. Gift Ranking */}
          <div
            onClick={() => {
              playSoundFX('superchat');
              setRankingSubTab('GIFT');
              setIsRankModalOpen(true);
            }}
            className="p-3 rounded-2xl bg-gradient-to-br from-amber-500/20 via-[#11152d] to-[#070913] border border-amber-500/40 shadow-lg cursor-pointer hover:border-amber-400 transition-all group flex flex-col items-center text-center"
          >
            <div className="w-10 h-10 rounded-full bg-amber-500 text-neutral-950 flex items-center justify-center font-black shadow-md mb-2 group-hover:scale-110 transition-transform">
              🎁
            </div>
            <span className="text-xs font-black text-amber-300">Gift Rank</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">Top Gifters</span>
          </div>

          {/* 2. Best Friends */}
          <div
            onClick={() => {
              playSoundFX('superchat');
              setRankingSubTab('FRIENDS');
              setIsRankModalOpen(true);
            }}
            className="p-3 rounded-2xl bg-gradient-to-br from-rose-500/20 via-[#11152d] to-[#070913] border border-rose-500/40 shadow-lg cursor-pointer hover:border-rose-400 transition-all group flex flex-col items-center text-center"
          >
            <div className="w-10 h-10 rounded-full bg-rose-500 text-white flex items-center justify-center font-black shadow-md mb-2 group-hover:scale-110 transition-transform">
              ❤️
            </div>
            <span className="text-xs font-black text-rose-300">Best Friends</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">CP Ranks</span>
          </div>

          {/* 3. Family */}
          <div
            onClick={() => {
              playSoundFX('superchat');
              setRankingSubTab('FAMILY');
              setIsRankModalOpen(true);
            }}
            className="p-3 rounded-2xl bg-gradient-to-br from-purple-600/20 via-[#11152d] to-[#070913] border border-purple-500/40 shadow-lg cursor-pointer hover:border-purple-400 transition-all group flex flex-col items-center text-center"
          >
            <div className="w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center font-black shadow-md mb-2 group-hover:scale-110 transition-transform">
              🏰
            </div>
            <span className="text-xs font-black text-purple-300">Family Guild</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">Top Families</span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 6. FEATURED / RECOMMENDED PARTY ROOMS                                     */}
      {/* ========================================================================= */}
      {recommendedRooms.length > 0 && (
        <div className="px-4 pt-4">
          <div className="flex items-center gap-2 mb-2.5">
            <Crown className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs sm:text-sm font-black tracking-wide text-white">Recommended Party Rooms</h3>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
            {recommendedRooms.map((room, idx) => (
              <div
                key={room.roomId || room.id}
                onClick={() => {
                  playSoundFX('click');
                  onSelectRoom(room.roomId || room.id);
                }}
                className="flex-shrink-0 w-36 sm:w-40 bg-[#11152d] rounded-2xl border border-amber-500/40 overflow-hidden shadow-xl cursor-pointer hover:border-amber-400 transition-all group"
              >
                <div className="relative h-32 sm:h-36">
                  <img src={room.roomImage || room.cover} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-amber-500 text-neutral-950 font-black text-[9px]">
                    Rank #{idx + 1}
                  </span>
                  <span className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-full text-[9px] font-bold text-cyan-300 flex items-center gap-1">
                    👥 {room.onlineCount || 14}
                  </span>
                </div>
                <div className="p-2.5">
                  <h4 className="text-xs font-black text-white truncate">{room.roomName || room.name}</h4>
                  <p className="text-[10px] text-neutral-400 truncate">Host: {room.ownerName || room.host}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. POPULAR / NEW FILTER & 7. PARTY ROOM DISCOVERY LIST                    */}
      {/* ========================================================================= */}
      <div className="px-4 pt-4 pb-20">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-rose-500" />
            <h3 className="text-xs sm:text-sm font-black tracking-wide text-white">Party Live Rooms</h3>
          </div>

          {/* Popular / New Toggle Tabs */}
          <div className="flex bg-[#11152d] p-1 rounded-full border border-white/10">
            {(['Popular', 'New'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => {
                  playSoundFX('click');
                  setCategoryFilter(cat);
                }}
                className={`px-3 py-1 rounded-full text-[10px] font-black uppercase transition-all ${
                  categoryFilter === cat
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {cat === 'Popular' ? '🔥 Popular' : 'New'}
              </button>
            ))}
          </div>
        </div>

        {/* Room Grid / List */}
        {displayedRooms.length === 0 ? (
          <div className="p-8 text-center bg-[#11152d]/60 rounded-3xl border border-white/10 my-4">
            <Radio className="w-10 h-10 text-neutral-500 mx-auto mb-2 animate-pulse" />
            <p className="text-xs font-bold text-neutral-300">No active rooms in this category right now.</p>
            <p className="text-[10px] text-neutral-500 mt-1">Start your own Party Live room instantly!</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {displayedRooms.map((room) => (
              <div
                key={room.roomId || room.id}
                onClick={() => {
                  playSoundFX('click');
                  onSelectRoom(room.roomId || room.id);
                }}
                className="bg-[#11152d] rounded-2xl border border-white/10 overflow-hidden shadow-xl cursor-pointer hover:border-cyan-400 transition-all group flex flex-col"
              >
                <div className="relative h-36 sm:h-40">
                  <img
                    src={room.roomImage || room.cover || 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600'}
                    alt=""
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent p-2.5 flex flex-col justify-between">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded-full bg-black/50 backdrop-blur-md text-[9px] font-bold text-white flex items-center gap-1">
                        {room.countryFlag || '🇳🇵'} {room.country || 'Nepal'}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-rose-500/80 backdrop-blur-md text-[9px] font-black text-white flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                        {room.onlineCount || 18} Live
                      </span>
                    </div>

                    <div>
                      <span className="text-[9px] font-bold text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded-md border border-cyan-500/30">
                        ID: {room.roomId || room.id}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3 flex flex-col justify-between flex-1">
                  <div>
                    <h4 className="text-xs font-black text-white truncate">{room.roomName || room.name}</h4>
                    <p className="text-[10px] text-neutral-400 truncate mt-0.5">Host: {room.ownerName || room.host}</p>
                  </div>
                  <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-white/10">
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                      👑 Official
                    </span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">
                      ⭐ VIP
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Global Leaderboard Modal */}
      <RankLeaderboardModal
        isOpen={isRankModalOpen}
        onClose={() => setIsRankModalOpen(false)}
      />

      {/* Footer inside Home scroll */}
      <footer className="bg-neutral-950/80 border-t border-white/10 py-6 px-4 mt-8 text-center text-xs text-neutral-400">
        <div className="max-w-md md:max-w-lg mx-auto flex flex-col items-center justify-center gap-1.5">
          <div className="flex items-center gap-2">
            <span className="font-['Outfit'] font-black text-sm text-white">DIYO LIVE</span>
            <span className="text-neutral-500">•</span>
            <span className="text-neutral-400">Ultra Low Latency Broadcast Network</span>
          </div>
          <p className="text-[10px] text-neutral-500">© 2026 DIYO LIVE. All streams broadcast in 4K UHD & AV1 encoder standard.</p>
        </div>
      </footer>
    </div>
  );
};
