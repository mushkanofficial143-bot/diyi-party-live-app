import React, { useState, useRef } from 'react';
import { 
  SRLiveRoleFrame, 
  SRLiveRoleType, 
  SR_LIVE_FRAME_THEMES 
} from './SRLiveRoleFrame';
import { 
  Sparkles, 
  Crown, 
  Shield, 
  Building, 
  Briefcase, 
  Coins, 
  Zap, 
  Upload, 
  Camera, 
  Download, 
  RotateCcw, 
  Check, 
  Eye, 
  Sliders, 
  Users, 
  Radio, 
  MessageSquare, 
  Award,
  Layers,
  Image as ImageIcon
} from 'lucide-react';
import srLiveProfileFramesImg from '../../assets/images/sr_live_profile_frames_1787214787934.jpg';
import srIsolatedFramesImg from '../../assets/images/sr_role_frames_isolated_1787215269083.jpg';

// Individual 3D Rendered Frames
import superAdminFrameImg from '../../assets/images/sr_live_super_admin_frame_1787215827118.jpg';
import adminFrameImg from '../../assets/images/sr_live_admin_frame_1787215842575.jpg';
import agencyFrameImg from '../../assets/images/sr_live_agency_frame_1787215856940.jpg';
import managerFrameImg from '../../assets/images/sr_live_manager_frame_1787215873845.jpg';
import coinSellerFrameImg from '../../assets/images/sr_live_coin_seller_frame_1787215885687.jpg';
import myAddFrameImg from '../../assets/images/sr_live_my_add_frame_1787215898071.jpg';

export const ROLE_3D_FRAME_ASSETS: Record<SRLiveRoleType, string> = {
  SUPER_ADMIN: superAdminFrameImg,
  ADMIN: adminFrameImg,
  AGENCY: agencyFrameImg,
  MANAGER: managerFrameImg,
  COIN_SELLER: coinSellerFrameImg,
  MY_ADD: myAddFrameImg
};

const SAMPLE_AVATARS = [
  { id: 'av-1', name: 'Alina (Singer)', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300' },
  { id: 'av-2', name: 'David (Producer)', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300' },
  { id: 'av-3', name: 'Sophia (Host)', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300' },
  { id: 'av-4', name: 'Marcus (Gamer)', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300' },
  { id: 'av-5', name: 'Elena (Creator)', url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300' }
];

export const ProfileFrameStudio: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState<SRLiveRoleType>('SUPER_ADMIN');
  const [currentAvatarUrl, setCurrentAvatarUrl] = useState<string>(SAMPLE_AVATARS[0].url);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [isLiveActive, setIsLiveActive] = useState<boolean>(true);
  const [isAnimated, setIsAnimated] = useState<boolean>(true);
  const [previewSurface, setPreviewSurface] = useState<'studio' | 'stream' | 'party' | 'chat' | 'profile'>('studio');
  const [copiedRole, setCopiedRole] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const activeTheme = SR_LIVE_FRAME_THEMES[selectedRole];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCurrentAvatarUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCopySpec = (roleKey: string) => {
    const spec = JSON.stringify(SR_LIVE_FRAME_THEMES[roleKey as SRLiveRoleType], null, 2);
    navigator.clipboard.writeText(spec);
    setCopiedRole(roleKey);
    setTimeout(() => setCopiedRole(null), 2000);
  };

  return (
    <div className="space-y-8 animate-in fade-in pb-12">
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-amber-950/40 border border-amber-500/30 relative overflow-hidden shadow-2xl">
        <div className="absolute right-0 top-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Crown className="w-3.5 h-3.5" />
              <span>Official DIYO LIVE Profile Frame System</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              6-Role Luxury Avatar Frame System
            </h2>
            <p className="text-sm text-neutral-300 leading-relaxed">
              Engineered with a pristine circular photo cutout that guarantees zero face obstruction, 3D gold filigree, ornate wings, the top <span className="text-amber-300 font-bold">DIYO LIVE</span> plaque, and bottom exact role nameplates.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <a
              href={srLiveProfileFramesImg}
              download="SR_LIVE_Profile_Frames_Master_Sheet.jpg"
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-extrabold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all hover:scale-105 active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Download 2×3 Master Sheet</span>
            </a>
            <a
              href={srIsolatedFramesImg}
              download="SR_LIVE_Isolated_Frames.jpg"
              className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs flex items-center gap-2 border border-neutral-700 transition-all"
            >
              <ImageIcon className="w-4 h-4 text-cyan-400" />
              <span>Isolated Cutouts</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Studio Interactive Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: 6 Role Selector Cards (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400" />
              <span>Select Official Role Frame</span>
            </h3>
            <span className="text-[11px] text-neutral-400">6 Verified Roles</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
            {(Object.keys(SR_LIVE_FRAME_THEMES) as SRLiveRoleType[]).map((roleKey) => {
              const theme = SR_LIVE_FRAME_THEMES[roleKey];
              const isSelected = selectedRole === roleKey;

              const getRoleIcon = () => {
                switch(roleKey) {
                  case 'SUPER_ADMIN': return <Crown className="w-4 h-4 text-red-400" />;
                  case 'ADMIN': return <Shield className="w-4 h-4 text-blue-400" />;
                  case 'AGENCY': return <Building className="w-4 h-4 text-purple-400" />;
                  case 'MANAGER': return <Briefcase className="w-4 h-4 text-emerald-400" />;
                  case 'COIN_SELLER': return <Coins className="w-4 h-4 text-yellow-400" />;
                  case 'MY_ADD': return <Zap className="w-4 h-4 text-cyan-400" />;
                }
              };

              return (
                <button
                  key={roleKey}
                  onClick={() => setSelectedRole(roleKey)}
                  className={`p-3.5 rounded-2xl border text-left transition-all relative overflow-hidden flex items-center justify-between gap-3 group ${
                    isSelected 
                      ? 'bg-neutral-900 border-amber-400/90 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400/50' 
                      : 'bg-neutral-950/70 border-neutral-800/80 hover:bg-neutral-900 hover:border-neutral-700'
                  }`}
                >
                  {/* Left Role Info */}
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center shadow-inner shrink-0 group-hover:scale-110 transition-transform">
                      {getRoleIcon()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-xs text-white uppercase tracking-wider">
                          {theme.label}
                        </span>
                        {isSelected && (
                          <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-black text-[9px] font-black">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-400 line-clamp-1 mt-0.5">
                        {theme.gemType}
                      </p>
                    </div>
                  </div>

                  {/* Right Miniature Frame Preview */}
                  <div className="shrink-0">
                    <SRLiveRoleFrame
                      role={roleKey}
                      avatarUrl={currentAvatarUrl}
                      size="xs"
                      animated={false}
                    />
                  </div>
                </button>
              );
            })}
          </div>

          {/* Photo Customizer & Live Controls */}
          <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-amber-400" />
              <span>Test Photo Insertion & Cropping</span>
            </h4>

            {/* Custom Photo Upload Button */}
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-2.5 px-3 rounded-xl bg-neutral-950 border border-neutral-700 hover:border-amber-400/80 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all hover:bg-neutral-900 shadow-md"
              >
                <Upload className="w-4 h-4 text-amber-400" />
                <span>Upload Custom Profile Photo</span>
              </button>
            </div>

            {/* Preset Avatar Selector */}
            <div className="space-y-1.5">
              <span className="text-[10px] uppercase font-bold text-neutral-500 tracking-wider block">
                Or pick a sample avatar:
              </span>
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {SAMPLE_AVATARS.map((av) => (
                  <button
                    key={av.id}
                    onClick={() => setCurrentAvatarUrl(av.url)}
                    className={`relative w-9 h-9 rounded-full overflow-hidden border-2 transition-all shrink-0 ${
                      currentAvatarUrl === av.url ? 'border-amber-400 scale-110 shadow-md' : 'border-neutral-700 opacity-70 hover:opacity-100'
                    }`}
                    title={av.name}
                  >
                    <img src={av.url} alt={av.name} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Live Toggles */}
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800/80 text-xs">
              <label className="flex items-center gap-2 cursor-pointer text-neutral-300 font-medium">
                <input
                  type="checkbox"
                  checked={isAnimated}
                  onChange={(e) => setIsAnimated(e.target.checked)}
                  className="rounded border-neutral-700 bg-neutral-950 text-amber-500 focus:ring-amber-500/20"
                />
                <span>3D Aura & Shimmer</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-neutral-300 font-medium">
                <input
                  type="checkbox"
                  checked={isLiveActive}
                  onChange={(e) => setIsLiveActive(e.target.checked)}
                  className="rounded border-neutral-700 bg-neutral-950 text-rose-500 focus:ring-rose-500/20"
                />
                <span>LIVE Stream Tag</span>
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: High-Res Interactive Visualizer & App-Surface Simulator (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Surface Switcher Tabs */}
          <div className="flex items-center gap-1.5 p-1.5 bg-neutral-950 rounded-2xl border border-neutral-800 overflow-x-auto">
            <button
              onClick={() => setPreviewSurface('studio')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
                previewSurface === 'studio' ? 'bg-amber-500 text-black shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>SVG/CSS Studio (3XL)</span>
            </button>
            <button
              onClick={() => setPreviewSurface('render_3d')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
                previewSurface === 'render_3d' ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-900" />
              <span>3D Standalone Render</span>
            </button>
            <button
              onClick={() => setPreviewSurface('stream')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
                previewSurface === 'stream' ? 'bg-neutral-800 text-white border border-neutral-700' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Radio className="w-3.5 h-3.5 text-rose-400" />
              <span>Broadcaster Header</span>
            </button>
            <button
              onClick={() => setPreviewSurface('party')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
                previewSurface === 'party' ? 'bg-neutral-800 text-white border border-neutral-700' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-purple-400" />
              <span>20-Seat Party Stage</span>
            </button>
            <button
              onClick={() => setPreviewSurface('chat')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
                previewSurface === 'chat' ? 'bg-neutral-800 text-white border border-neutral-700' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
              <span>Live Chat Bubble</span>
            </button>
          </div>

          {/* Canvas Rendering Area */}
          <div className="p-8 rounded-3xl bg-gradient-to-b from-neutral-900 to-neutral-950 border border-neutral-800 min-h-[380px] flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
            
            {/* Background Grid Accent */}
            <div className="absolute inset-0 bg-[radial-gradient(#333_1px,transparent_1px)] [background-size:16px_16px] opacity-30 pointer-events-none" />

            {/* 1. STUDIO INSPECTOR MODE */}
            {previewSurface === 'studio' && (
              <div className="flex flex-col items-center justify-center space-y-6 animate-in zoom-in-95 duration-200">
                <SRLiveRoleFrame
                  role={selectedRole}
                  avatarUrl={currentAvatarUrl}
                  size="3xl"
                  animated={isAnimated}
                  isLive={isLiveActive}
                />

                {/* Specs Box */}
                <div className="text-center space-y-1 pt-4">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-neutral-900 border border-neutral-700 text-xs font-bold text-neutral-200">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: activeTheme.primaryColor }} />
                    <span>{activeTheme.title} — {activeTheme.gemType}</span>
                  </div>
                  <p className="text-xs text-neutral-400 max-w-md">
                    {activeTheme.description}
                  </p>
                </div>
              </div>
            )}

            {/* 1.5 3D STANDALONE RENDER WITH REALTIME USER PHOTO EMBED */}
            {previewSurface === 'render_3d' && (
              <div className="flex flex-col items-center justify-center space-y-6 animate-in zoom-in-95 duration-200">
                <div className="relative w-72 h-72 sm:w-80 sm:h-80 flex items-center justify-center group">
                  {/* Real-time photo embedded inside the circular transparent center */}
                  <div className="w-[142px] h-[142px] sm:w-[158px] sm:h-[158px] rounded-full overflow-hidden absolute z-0 shadow-inner">
                    <img
                      src={currentAvatarUrl}
                      alt="User Avatar"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* 3D High-Gloss Frame Overlay (Wings, Crown, DIYO LIVE plaque, and Role Nameplate) */}
                  <img
                    src={ROLE_3D_FRAME_ASSETS[selectedRole]}
                    alt={`${activeTheme.title} 3D Frame`}
                    className="w-full h-full object-contain relative z-10 pointer-events-none drop-shadow-[0_10px_25px_rgba(0,0,0,0.8)]"
                  />
                </div>

                {/* Direct Role Asset Download & Specs */}
                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <a
                    href={ROLE_3D_FRAME_ASSETS[selectedRole]}
                    download={`SR_LIVE_${selectedRole}_3D_Frame.jpg`}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 text-black font-extrabold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download {activeTheme.label} 3D Asset</span>
                  </a>
                  <span className="text-xs text-neutral-400">
                    Standalone 3D 8K Render with Circular Cutout
                  </span>
                </div>
              </div>
            )}

            {/* 2. BROADCASTER HEADER STREAM MODE */}
            {previewSurface === 'stream' && (
              <div className="w-full max-w-md p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <SRLiveRoleFrame
                      role={selectedRole}
                      avatarUrl={currentAvatarUrl}
                      size="sm"
                      isLive={true}
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">Alina_Official</span>
                        <span className="text-[10px] font-black px-1.5 py-0.2 rounded bg-amber-400 text-black">
                          {activeTheme.initials}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-400 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                        <span>12.4K Viewers</span>
                      </p>
                    </div>
                  </div>
                  <button className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30">
                    + Follow
                  </button>
                </div>
                <div className="p-2.5 rounded-xl bg-neutral-950 text-xs text-neutral-300 border border-neutral-800/80">
                  🎙️ "Welcome everyone to tonight's official DIYO LIVE Showcase stream!"
                </div>
              </div>
            )}

            {/* 3. 20-SEAT VOICE PARTY STAGE MODE */}
            {previewSurface === 'party' && (
              <div className="w-full max-w-md p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-4 animate-in fade-in">
                <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider block text-center">
                  20-Seat Voice Party Room Seat #1 (Host Throne)
                </span>
                <div className="flex items-center justify-center gap-6 py-2">
                  <div className="flex flex-col items-center space-y-1">
                    <SRLiveRoleFrame
                      role={selectedRole}
                      avatarUrl={currentAvatarUrl}
                      size="md"
                      isLive={true}
                    />
                    <span className="text-xs font-bold text-white mt-1">Host (You)</span>
                    <span className="text-[9px] text-amber-300 font-mono">👑 Seat #1</span>
                  </div>

                  <div className="flex flex-col items-center space-y-1 opacity-50">
                    <div className="w-14 h-14 rounded-full border-2 border-dashed border-neutral-700 flex items-center justify-center text-xs text-neutral-500 font-bold">
                      Seat 2
                    </div>
                    <span className="text-xs text-neutral-500">Empty</span>
                    <span className="text-[9px] text-neutral-600 font-mono">Seat #2</span>
                  </div>

                  <div className="flex flex-col items-center space-y-1 opacity-50">
                    <div className="w-14 h-14 rounded-full border-2 border-dashed border-neutral-700 flex items-center justify-center text-xs text-neutral-500 font-bold">
                      Seat 3
                    </div>
                    <span className="text-xs text-neutral-500">Empty</span>
                    <span className="text-[9px] text-neutral-600 font-mono">Seat #3</span>
                  </div>
                </div>
              </div>
            )}

            {/* 4. REAL-TIME LIVE CHAT BUBBLE MODE */}
            {previewSurface === 'chat' && (
              <div className="w-full max-w-md p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-2.5 animate-in fade-in">
                <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider block">
                  Live Chat Message Stream Preview
                </span>

                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex items-start gap-3">
                  <div className="shrink-0 -mt-1">
                    <SRLiveRoleFrame
                      role={selectedRole}
                      avatarUrl={currentAvatarUrl}
                      size="xs"
                      showNameplate={false}
                    />
                  </div>
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-white">Alina_SR</span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-gradient-to-r from-amber-400 to-yellow-500 text-black">
                        {activeTheme.label}
                      </span>
                      <span className="text-[10px] text-neutral-500">Just now</span>
                    </div>
                    <p className="text-xs text-neutral-200">
                      Hello everyone! Excited to host the official live streaming session tonight! 🎉✨
                    </p>
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* Design Specs & Metadata Sheet */}
          <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <span>Theme Specifications ({activeTheme.title})</span>
              </h4>
              <button
                onClick={() => handleCopySpec(selectedRole)}
                className="text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
              >
                {copiedRole === selectedRole ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <span>Copy Specs JSON</span>
                )}
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 font-bold block">Primary Color</span>
                <span className="font-mono font-bold text-white">{activeTheme.primaryColor}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 font-bold block">Accent Color</span>
                <span className="font-mono font-bold text-amber-300">{activeTheme.accentColor}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 font-bold block">Gems / Ornaments</span>
                <span className="font-bold text-neutral-300 truncate block">{activeTheme.gemType}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 font-bold block">Crown Monogram</span>
                <span className="font-bold text-amber-400">{activeTheme.crownInsignia}</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
