import React from 'react';

export type SRLiveRoleType = 
  | 'SUPER_ADMIN' 
  | 'ADMIN' 
  | 'AGENCY' 
  | 'MANAGER' 
  | 'COIN_SELLER' 
  | 'MY_ADD';

export interface SRLiveRoleFrameProps {
  role: SRLiveRoleType;
  avatarUrl?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
  showNameplate?: boolean;
  showBrandingPlaque?: boolean;
  animated?: boolean;
  className?: string;
  isLive?: boolean;
  onClick?: () => void;
}

export interface RoleFrameTheme {
  id: SRLiveRoleType;
  title: string;
  label: string;
  initials: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  glowColor: string;
  ringBorderClass: string;
  wingGradient: string;
  plaqueColor: string;
  nameplateBg: string;
  nameplateBorder: string;
  textColor: string;
  description: string;
  gemType: string;
  crownInsignia: string;
}

export const SR_LIVE_FRAME_THEMES: Record<SRLiveRoleType, RoleFrameTheme> = {
  SUPER_ADMIN: {
    id: 'SUPER_ADMIN',
    title: 'Super Admin',
    label: 'SUPER ADMIN',
    initials: 'SA',
    primaryColor: '#DC2626', // Red
    secondaryColor: '#B91C1C',
    accentColor: '#F59E0B', // Gold
    glowColor: 'rgba(239, 68, 68, 0.75)',
    ringBorderClass: 'border-amber-400',
    wingGradient: 'from-amber-500 via-rose-600 to-red-800',
    plaqueColor: 'from-amber-400 via-yellow-300 to-amber-500',
    nameplateBg: 'bg-gradient-to-r from-red-950 via-rose-900 to-red-950',
    nameplateBorder: 'border-amber-400',
    textColor: 'text-amber-200',
    description: 'Crimson red and gold with fiery wings, royal SA crown, and ruby gems',
    gemType: 'Ruby Diamonds',
    crownInsignia: 'SA'
  },
  ADMIN: {
    id: 'ADMIN',
    title: 'Admin',
    label: 'ADMIN',
    initials: 'A',
    primaryColor: '#2563EB', // Royal Blue
    secondaryColor: '#1D4ED8',
    accentColor: '#FCD34D', // Gold
    glowColor: 'rgba(59, 130, 246, 0.75)',
    ringBorderClass: 'border-yellow-300',
    wingGradient: 'from-sky-400 via-blue-600 to-indigo-900',
    plaqueColor: 'from-amber-400 via-yellow-200 to-amber-500',
    nameplateBg: 'bg-gradient-to-r from-blue-950 via-indigo-900 to-blue-950',
    nameplateBorder: 'border-yellow-300',
    textColor: 'text-yellow-100',
    description: 'Sapphire blue and gold with angelic blue-white wings and sapphire crystals',
    gemType: 'Sapphire Crystals',
    crownInsignia: 'A'
  },
  AGENCY: {
    id: 'AGENCY',
    title: 'Agency',
    label: 'AGENCY',
    initials: 'AG',
    primaryColor: '#9333EA', // Royal Purple
    secondaryColor: '#7E22CE',
    accentColor: '#FBBF24', // Gold
    glowColor: 'rgba(168, 85, 247, 0.75)',
    ringBorderClass: 'border-amber-300',
    wingGradient: 'from-amber-400 via-purple-600 to-fuchsia-950',
    plaqueColor: 'from-amber-400 via-yellow-300 to-amber-500',
    nameplateBg: 'bg-gradient-to-r from-purple-950 via-fuchsia-900 to-purple-950',
    nameplateBorder: 'border-amber-300',
    textColor: 'text-amber-200',
    description: 'Royal purple, violet and gold with regal wings and amethyst gemstones',
    gemType: 'Amethyst Gems',
    crownInsignia: 'AG'
  },
  MANAGER: {
    id: 'MANAGER',
    title: 'Manager',
    label: 'MANAGER',
    initials: 'M',
    primaryColor: '#059669', // Emerald Green
    secondaryColor: '#047857',
    accentColor: '#F59E0B', // Gold
    glowColor: 'rgba(16, 185, 129, 0.75)',
    ringBorderClass: 'border-yellow-300',
    wingGradient: 'from-emerald-400 via-teal-600 to-green-950',
    plaqueColor: 'from-amber-400 via-yellow-300 to-amber-500',
    nameplateBg: 'bg-gradient-to-r from-emerald-950 via-teal-900 to-emerald-950',
    nameplateBorder: 'border-yellow-300',
    textColor: 'text-emerald-200',
    description: 'Emerald green and gold with green-gold wings and royal laurel leaf motifs',
    gemType: 'Emerald Ornaments',
    crownInsignia: 'M'
  },
  COIN_SELLER: {
    id: 'COIN_SELLER',
    title: 'Coin Seller',
    label: 'COIN SELLER',
    initials: '$',
    primaryColor: '#EAB308', // Pure Gold
    secondaryColor: '#CA8A04',
    accentColor: '#1E3A8A', // Dark Blue
    glowColor: 'rgba(234, 179, 8, 0.85)',
    ringBorderClass: 'border-yellow-400',
    wingGradient: 'from-yellow-300 via-amber-500 to-blue-950',
    plaqueColor: 'from-yellow-300 via-amber-200 to-yellow-500',
    nameplateBg: 'bg-gradient-to-r from-neutral-950 via-amber-950 to-neutral-950',
    nameplateBorder: 'border-yellow-400',
    textColor: 'text-yellow-300',
    description: 'Pure wealth gold and dark blue with stacked 3D gold coins and gold-blue wings',
    gemType: '3D Gold Coins & Gems',
    crownInsignia: '🪙'
  },
  MY_ADD: {
    id: 'MY_ADD',
    title: 'My Add',
    label: 'MY ADD',
    initials: 'SR',
    primaryColor: '#06B6D4', // Neon Cyan
    secondaryColor: '#EC4899', // Magenta Pink
    accentColor: '#A855F7', // Purple
    glowColor: 'rgba(6, 182, 212, 0.85)',
    ringBorderClass: 'border-cyan-300',
    wingGradient: 'from-cyan-400 via-pink-500 to-purple-800',
    plaqueColor: 'from-cyan-300 via-pink-300 to-purple-400',
    nameplateBg: 'bg-gradient-to-r from-cyan-950 via-purple-950 to-pink-950',
    nameplateBorder: 'border-cyan-300',
    textColor: 'text-cyan-200',
    description: 'Futuristic neon cyan, magenta pink and glowing cyber crystal wings with SR crown',
    gemType: 'Cyber Prism Crystals',
    crownInsignia: 'SR'
  }
};

/**
 * SRLiveRoleFrame:
 * Official DIYO LIVE Role Profile Frame System with clean, circular photo cutout area.
 * Zero obstruction over the user's face, pristine 3D gold filigree, ornate wings,
 * top DIYO LIVE plaque, and bottom exact role nameplate.
 */
export const SRLiveRoleFrame: React.FC<SRLiveRoleFrameProps> = ({
  role,
  avatarUrl = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
  size = 'md',
  showNameplate = true,
  showBrandingPlaque = true,
  animated = true,
  className = '',
  isLive = false,
  onClick
}) => {
  const theme = SR_LIVE_FRAME_THEMES[role] || SR_LIVE_FRAME_THEMES.SUPER_ADMIN;

  // Responsive container & photo sizing
  const sizeMap = {
    xs: {
      container: 'w-12 h-14',
      photoBox: 'w-8 h-8',
      plaqueText: 'text-[6px] px-1 py-0',
      nameplateText: 'text-[6px] px-1 py-0.2',
      crownSize: 'text-[8px] -top-1.5',
      wingsScale: 'scale-50',
      badgeOffset: '-bottom-1'
    },
    sm: {
      container: 'w-16 h-18',
      photoBox: 'w-11 h-11',
      plaqueText: 'text-[7px] px-1.5 py-0.2',
      nameplateText: 'text-[7px] px-1.5 py-0.5',
      crownSize: 'text-[10px] -top-2',
      wingsScale: 'scale-75',
      badgeOffset: '-bottom-1.5'
    },
    md: {
      container: 'w-24 h-28',
      photoBox: 'w-16 h-16',
      plaqueText: 'text-[8px] px-2 py-0.5',
      nameplateText: 'text-[8px] px-2 py-0.5',
      crownSize: 'text-xs -top-2.5',
      wingsScale: 'scale-90',
      badgeOffset: '-bottom-2'
    },
    lg: {
      container: 'w-32 h-36',
      photoBox: 'w-22 h-22',
      plaqueText: 'text-[9px] px-2.5 py-0.5',
      nameplateText: 'text-[9px] px-2.5 py-0.5',
      crownSize: 'text-sm -top-3',
      wingsScale: 'scale-100',
      badgeOffset: '-bottom-2.5'
    },
    xl: {
      container: 'w-44 h-48',
      photoBox: 'w-30 h-30',
      plaqueText: 'text-[10px] px-3 py-0.5',
      nameplateText: 'text-[10px] px-3 py-1',
      crownSize: 'text-base -top-3.5',
      wingsScale: 'scale-125',
      badgeOffset: '-bottom-3'
    },
    '2xl': {
      container: 'w-56 h-60',
      photoBox: 'w-38 h-38',
      plaqueText: 'text-xs px-3.5 py-1',
      nameplateText: 'text-xs px-4 py-1',
      crownSize: 'text-lg -top-4',
      wingsScale: 'scale-150',
      badgeOffset: '-bottom-3.5'
    },
    '3xl': {
      container: 'w-72 h-80',
      photoBox: 'w-50 h-50',
      plaqueText: 'text-sm px-4 py-1.5',
      nameplateText: 'text-sm px-5 py-1.5',
      crownSize: 'text-xl -top-5',
      wingsScale: 'scale-[1.8]',
      badgeOffset: '-bottom-4'
    }
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  return (
    <div 
      onClick={onClick}
      className={`relative inline-flex flex-col items-center justify-center select-none flex-shrink-0 ${currentSize.container} ${onClick ? 'cursor-pointer hover:scale-105 transition-transform' : ''} ${className}`}
      title={`DIYO LIVE Official Profile Frame - ${theme.title}`}
    >
      {/* 1. SCULPTED 3D WINGS LAYER (Positioned Outside Photo Area) */}
      <div 
        className={`absolute inset-0 pointer-events-none z-0 flex items-center justify-center transform ${currentSize.wingsScale}`}
      >
        {/* Left Wing SVG */}
        <svg className="w-1/2 h-full absolute -left-3 top-0 opacity-90 filter drop-shadow-md overflow-visible" viewBox="0 0 100 100" fill="none">
          <defs>
            <linearGradient id={`wing-left-${role}`} x1="100%" y1="50%" x2="0%" y2="50%">
              <stop offset="0%" stopColor="#F59E0B" />
              <stop offset="50%" stopColor={theme.primaryColor} />
              <stop offset="100%" stopColor={theme.secondaryColor} />
            </linearGradient>
          </defs>
          <path 
            d="M80 50 C50 30, 20 15, 0 35 C10 50, 35 60, 55 65 C40 70, 25 80, 10 90 C35 90, 60 75, 80 55 Z" 
            fill={`url(#wing-left-${role})`}
            stroke="#FEF08A"
            strokeWidth="1.5"
          />
          {/* Feather accents */}
          <path d="M70 45 C45 32, 25 30, 10 40" stroke="#FFFFFF" strokeWidth="1" strokeOpacity="0.6" fill="none" />
          <path d="M65 55 C45 52, 30 58, 20 70" stroke="#FEF08A" strokeWidth="1" strokeOpacity="0.7" fill="none" />
        </svg>

        {/* Right Wing SVG */}
        <svg className="w-1/2 h-full absolute -right-3 top-0 opacity-90 filter drop-shadow-md overflow-visible" viewBox="0 0 100 100" fill="none">
          <defs>
            <linearGradient id={`wing-right-${role}`} x1="0%" y1="50%" x2="100%" y2="50%">
              <stop offset="0%" stopColor="#F59E0B" />
              <stop offset="50%" stopColor={theme.primaryColor} />
              <stop offset="100%" stopColor={theme.secondaryColor} />
            </linearGradient>
          </defs>
          <path 
            d="M20 50 C50 30, 80 15, 100 35 C90 50, 65 60, 45 65 C60 70, 75 80, 90 90 C65 90, 40 75, 20 55 Z" 
            fill={`url(#wing-right-${role})`}
            stroke="#FEF08A"
            strokeWidth="1.5"
          />
          {/* Feather accents */}
          <path d="M30 45 C55 32, 75 30, 90 40" stroke="#FFFFFF" strokeWidth="1" strokeOpacity="0.6" fill="none" />
          <path d="M35 55 C55 52, 70 58, 80 70" stroke="#FEF08A" strokeWidth="1" strokeOpacity="0.7" fill="none" />
        </svg>
      </div>

      {/* 2. GLOWING AMBIENT AURA RING */}
      <div 
        className={`absolute rounded-full pointer-events-none z-10 ${currentSize.photoBox} ${animated ? 'animate-pulse' : ''}`}
        style={{
          boxShadow: `0 0 18px 2px ${theme.glowColor}, inset 0 0 10px rgba(255,255,255,0.3)`
        }}
      />

      {/* 3. REVOLVING SPECULAR ACCENT RING */}
      {animated && (
        <div 
          className={`absolute rounded-full border border-yellow-200/40 pointer-events-none z-10 ${currentSize.photoBox} scale-110 animate-spin`}
          style={{ animationDuration: '14s' }}
        />
      )}

      {/* 4. THE CLEAN CIRCULAR USER PHOTO CONTAINER (ZERO OBSTRUCTION OVER FACE) */}
      <div 
        className={`relative z-10 ${currentSize.photoBox} rounded-full overflow-hidden border-2 ${theme.ringBorderClass} bg-neutral-950 flex items-center justify-center shadow-2xl`}
      >
        <img
          src={avatarUrl}
          alt={`DIYO LIVE ${theme.title} Avatar`}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover rounded-full"
        />
      </div>

      {/* 5. TOP CROWN WITH INITIALS & "DIYO LIVE" OFFICIAL BRANDING PLAQUE */}
      {showBrandingPlaque && (
        <div className={`absolute ${currentSize.crownSize} left-1/2 -translate-x-1/2 z-30 flex flex-col items-center pointer-events-none`}>
          {/* 3D Royal Crown Emblem */}
          <div className="relative flex items-center justify-center drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
            <span className="text-amber-300 font-black leading-none drop-shadow filter">
              👑
            </span>
            {/* Crown Monogram */}
            <span className="absolute text-[7px] font-black text-black tracking-tighter bg-amber-300 px-0.5 rounded -bottom-0.5 scale-90 border border-black/40">
              {theme.crownInsignia}
            </span>
          </div>

          {/* DIYO LIVE Gold Plaque */}
          <div className={`mt-0.5 bg-gradient-to-r ${theme.plaqueColor} text-black font-black tracking-widest uppercase rounded-full shadow-lg border border-yellow-100 flex items-center gap-1 ${currentSize.plaqueText} leading-none drop-shadow`}>
            <span className="text-[6px] text-amber-900 font-black">★</span>
            <span>DIYO LIVE</span>
            <span className="text-[6px] text-amber-900 font-black">★</span>
          </div>
        </div>
      )}

      {/* 6. BOTTOM EXACT ROLE NAMEPLATE BANNER */}
      {showNameplate && (
        <div 
          className={`absolute ${currentSize.badgeOffset} left-1/2 -translate-x-1/2 z-30 pointer-events-none flex items-center justify-center whitespace-nowrap`}
        >
          <div 
            className={`${theme.nameplateBg} ${theme.textColor} border-2 ${theme.nameplateBorder} font-black tracking-wider uppercase rounded-full shadow-2xl flex items-center gap-1 ${currentSize.nameplateText} leading-none drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]`}
            style={{ boxShadow: `0 4px 12px ${theme.glowColor}` }}
          >
            {/* Left Gem Dot */}
            <span className="w-1.5 h-1.5 rounded-full bg-amber-300 shadow-sm animate-ping" style={{ animationDuration: '3s' }} />
            
            {/* Exact Role Label */}
            <span>{theme.label}</span>
            
            {/* Right Gem Dot */}
            <span className="w-1.5 h-1.5 rounded-full bg-amber-300 shadow-sm" />
          </div>
        </div>
      )}

      {/* 7. OPTIONAL LIVE INDICATOR */}
      {isLive && (
        <span className="absolute top-1 right-0 bg-rose-600 text-[7px] font-black text-white px-1.5 py-0.2 rounded-full uppercase tracking-tighter border border-rose-300 shadow-lg z-40 animate-pulse">
          LIVE
        </span>
      )}
    </div>
  );
};
