/**
 * DIYO LIVE - Game WebView & Native Bridge Controller
 * Replicates the Flutter GameWebView architecture in React/TypeScript:
 * - Loads game sessions with signed launch URLs
 * - Implements 'NativeBridge' message listener (PLACE_BET, GET_BALANCE, CLOSE_GAME, REQUEST_RECHARGE)
 * - Listens to WebSocket game events and relays to iframe window.onNativeEvent
 */

import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Coins, Sparkles, RefreshCcw, ShieldCheck, Zap } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface GameWebViewModalProps {
  gameCode: string;
  gameTitle?: string;
  roomId?: string;
  userCoins: number;
  onUpdateCoins: (delta: number) => void;
  onClose: () => void;
  onRequestRecharge: () => void;
}

export const GameWebViewModal: React.FC<GameWebViewModalProps> = ({
  gameCode,
  gameTitle = 'SR Interactive Mini-Game',
  roomId,
  userCoins,
  onUpdateCoins,
  onClose,
  onRequestRecharge,
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [sessionUrl, setSessionUrl] = useState<string>('');
  const [bridgeLogs, setBridgeLogs] = useState<string[]>([]);

  useEffect(() => {
    // 1. Initialize Game Session (simulating backend short-lived signed token session)
    const initSession = async () => {
      try {
        setIsLoading(true);
        await new Promise((r) => setTimeout(r, 600));
        const mockLaunchUrl = `https://games.srlive.app/embed/${gameCode}?room=${roomId || 'default'}&token=tok_${Math.random().toString(36).substring(7)}`;
        setSessionUrl(mockLaunchUrl);
        setIsLoading(false);
        playSoundFX('click');
      } catch (err) {
        console.error('Failed to launch game session:', err);
        setIsLoading(false);
      }
    };

    initSession();

    // 2. Setup window message listener for NativeBridge (simulating Flutter addJavaScriptChannel)
    const handleMessage = (event: MessageEvent) => {
      if (!event.data || typeof event.data !== 'object') return;
      const msg = event.data;

      if (msg.channel === 'NativeBridge') {
        handleBridgeMessage(msg.payload);
      }
    };

    window.addEventListener('message', handleMessage);

    // 3. Setup simulated WebSocket game event listener
    const interval = setInterval(() => {
      const mockEvent = { type: 'ROUND_UPDATE', roundId: 'rd_' + Date.now(), multiplier: (Math.random() * 3 + 1).toFixed(2) };
      if (iframeRef.current && iframeRef.current.contentWindow) {
        try {
          iframeRef.current.contentWindow.postMessage({ channel: 'game:event', payload: mockEvent }, '*');
        } catch (e) {
          // ignore cross-origin frame errors if sandbox
        }
      }
    }, 10000);

    return () => {
      window.removeEventListener('message', handleMessage);
      clearInterval(interval);
    };
  }, [gameCode, roomId]);

  const handleBridgeMessage = (msg: { type: string; id: string; option?: string; amount?: number; roundId?: string; clientTxnId?: string }) => {
    setBridgeLogs((prev) => [`[Bridge] Received: ${msg.type}`, ...prev.slice(0, 15)]);

    switch (msg.type) {
      case 'PLACE_BET': {
        const amount = msg.amount || 100;
        if (userCoins < amount) {
          playSoundFX('alert');
          replyBridge(msg.id, { success: false, error: 'INSUFFICIENT_FUNDS' });
          onRequestRecharge();
          return;
        }

        playSoundFX('win');
        onUpdateCoins(-amount);
        confetti({ particleCount: 25, spread: 60, origin: { y: 0.8 } });

        const wonAmount = amount * (Math.random() > 0.4 ? 2 : 0);
        if (wonAmount > 0) {
          onUpdateCoins(wonAmount);
        }

        replyBridge(msg.id, {
          success: true,
          txnId: msg.clientTxnId || 'txn_' + Date.now(),
          deducted: amount,
          won: wonAmount,
          balance: userCoins - amount + wonAmount
        });
        break;
      }

      case 'GET_BALANCE': {
        replyBridge(msg.id, { coins: userCoins.toString() });
        break;
      }

      case 'CLOSE_GAME': {
        playSoundFX('click');
        onClose();
        break;
      }

      case 'REQUEST_RECHARGE': {
        playSoundFX('click');
        onRequestRecharge();
        break;
      }

      default:
        console.warn('Unknown bridge message type:', msg.type);
    }
  };

  const replyBridge = (id: string, payload: any) => {
    if (iframeRef.current && iframeRef.current.contentWindow) {
      iframeRef.current.contentWindow.postMessage({ channel: '__bridgeResolve', id, payload }, '*');
    }
  };

  return (
    <div className="fixed inset-0 z-[110] bg-black/95 flex flex-col items-center justify-between animate-in fade-in duration-300">
      
      {/* Top Navigation Bar */}
      <div className="w-full h-14 bg-gradient-to-r from-purple-950/90 via-[#1c102c]/95 to-purple-950/90 border-b border-amber-500/30 px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-black/40 border border-amber-400/40 text-amber-300 flex items-center justify-center hover:bg-amber-500/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xl">🎮</span>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">{gameTitle}</h2>
              <span className="text-[10px] text-amber-400 font-medium flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" /> Secure Game Session ({gameCode})
              </span>
            </div>
          </div>
        </div>

        {/* User Balance & Recharge */}
        <div className="flex items-center gap-3">
          <div className="bg-black/60 border border-amber-400/50 px-3 py-1.5 rounded-full flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400 animate-spin" />
            <span className="text-sm font-black text-amber-300">{userCoins.toLocaleString()}</span>
          </div>
          <button
            onClick={onRequestRecharge}
            className="px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-600 text-neutral-950 font-black text-xs shadow hover:opacity-95 transition-opacity"
          >
            + Recharge
          </button>
        </div>
      </div>

      {/* Main Game Stage / WebView Container */}
      <div className="flex-1 w-full relative flex items-center justify-center bg-[#070913] overflow-hidden">
        {isLoading ? (
          <div className="flex flex-col items-center gap-3">
            <RefreshCcw className="w-10 h-10 text-amber-400 animate-spin" />
            <span className="text-sm font-bold text-amber-300 tracking-wider">Establishing Secure Game Bridge...</span>
          </div>
        ) : (
          <div className="w-full h-full relative flex flex-col items-center justify-center">
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-500 via-purple-600 to-indigo-700 border-2 border-amber-300 shadow-[0_0_50px_rgba(245,158,11,0.5)] flex items-center justify-center text-4xl mb-4 animate-bounce">
                🎲
              </div>
              <h3 className="text-xl font-black text-amber-300 mb-2">{gameTitle} Arena</h3>
              <p className="text-xs text-slate-300 max-w-md mb-6">
                Connected via NativeBridge & WebSocket channel. Place your bets and win massive DIYO coins!
              </p>

              <div className="flex gap-4">
                <button
                  onClick={() => handleBridgeMessage({ type: 'PLACE_BET', id: 'b_' + Date.now(), amount: 500, option: 'RED', clientTxnId: 'txn_' + Date.now() })}
                  className="px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-amber-600 font-black text-white shadow-xl hover:scale-105 transition-transform flex items-center gap-2"
                >
                  <Zap className="w-4 h-4" /> Place Test Bet (500 Coins)
                </button>
                <button
                  onClick={onClose}
                  className="px-6 py-3 rounded-2xl bg-neutral-800 border border-slate-600 font-bold text-slate-200 hover:bg-neutral-700 transition-colors"
                >
                  Exit Game
                </button>
              </div>

              {/* Bridge debug console */}
              <div className="mt-8 w-full max-w-md bg-black/80 border border-slate-800 rounded-xl p-3 text-left font-mono text-[10px] text-emerald-400 max-h-32 overflow-y-auto">
                <div className="font-bold text-slate-400 mb-1">NativeBridge Communication Log:</div>
                {bridgeLogs.length === 0 ? (
                  <div className="text-slate-600">No bridge messages yet...</div>
                ) : (
                  bridgeLogs.map((log, idx) => <div key={idx}>{log}</div>)
                )}
              </div>
            </div>

            <iframe
              ref={iframeRef}
              src={sessionUrl}
              title={gameCode}
              className="w-full h-full border-0 opacity-0 pointer-events-none"
            />
          </div>
        )}
      </div>

    </div>
  );
};
