import React, { useState } from 'react';
import { ArrowLeft, Sparkles, Disc, Apple } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { TrophyFruitPartyScreen } from './TrophyFruitPartyScreen';
import { WheelOfFortuneScreen } from './WheelOfFortuneScreen';

interface SRGameCenterHubProps {
  userCoins: number;
  onUpdateCoins: (delta: number) => void;
  onClose: () => void;
}

type GameType = 'FRUIT_PARTY' | 'WHEEL_FORTUNE';

export const SRGameCenterHub: React.FC<SRGameCenterHubProps> = ({
  userCoins,
  onUpdateCoins,
  onClose,
}) => {
  const [activeGame, setActiveGame] = useState<GameType>('FRUIT_PARTY');

  // Render FRUIT_PARTY
  if (activeGame === 'FRUIT_PARTY') {
    return (
      <div className="fixed inset-0 z-[100] bg-[#070913] flex flex-col">
        {/* Top bar with game switcher */}
        <div className="bg-[#0e1629] border-b border-amber-500/30 px-4 py-2.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 text-neutral-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <span className="text-xs font-black text-amber-300 uppercase tracking-widest font-['Outfit']">🏆 DIYO Arcade Hub</span>
          </div>
          <div className="flex items-center gap-1.5">
            {[
              { id: 'FRUIT_PARTY', label: '🍓 DIYO Fruit Party', icon: Apple },
              { id: 'WHEEL_FORTUNE', label: '🎡 Wheel of Fortune', icon: Disc },
            ].map((g) => (
              <button
                key={g.id}
                onClick={() => { playSoundFX('click'); setActiveGame(g.id as GameType); }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  activeGame === g.id
                    ? 'bg-amber-500 text-neutral-950 shadow-md font-black'
                    : 'bg-white/5 text-neutral-300 hover:bg-white/10'
                }`}
              >
                <span>{g.label}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-hidden">
          <TrophyFruitPartyScreen
            userCoins={userCoins}
            onUpdateCoins={onUpdateCoins}
            onClose={onClose}
          />
        </div>
      </div>
    );
  }

  // Render WHEEL_FORTUNE
  if (activeGame === 'WHEEL_FORTUNE') {
    return (
      <div className="fixed inset-0 z-[100] bg-[#070913] flex flex-col">
        {/* Top bar with game switcher */}
        <div className="bg-[#0e1629] border-b border-amber-500/30 px-4 py-2.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 text-neutral-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <span className="text-xs font-black text-amber-300 uppercase tracking-widest font-['Outfit']">🏆 DIYO Arcade Hub</span>
          </div>
          <div className="flex items-center gap-1.5">
            {[
              { id: 'FRUIT_PARTY', label: '🍓 DIYO Fruit Party', icon: Apple },
              { id: 'WHEEL_FORTUNE', label: '🎡 Wheel of Fortune', icon: Disc },
            ].map((g) => (
              <button
                key={g.id}
                onClick={() => { playSoundFX('click'); setActiveGame(g.id as GameType); }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  activeGame === g.id
                    ? 'bg-amber-500 text-neutral-950 shadow-md font-black'
                    : 'bg-white/5 text-neutral-300 hover:bg-white/10'
                }`}
              >
                <span>{g.label}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-hidden">
          <WheelOfFortuneScreen
            userCoins={userCoins}
            onUpdateCoins={onUpdateCoins}
            onClose={onClose}
          />
        </div>
      </div>
    );
  }

  return null;
};
