import React, { useState } from 'react';
import { Sparkles, Trophy, RotateCcw, ArrowLeft, ShieldCheck, Coins, Zap, Award } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface SRLuckyJackpotGameProps {
  userCoins: number;
  onUpdateCoins: (delta: number) => void;
  onClose: () => void;
}

interface PrizeSegment {
  id: number;
  label: string;
  multiplier: number;
  color: string;
  probability: number;
}

const PRIZES: PrizeSegment[] = [
  { id: 1, label: '2X WIN', multiplier: 2, color: 'from-amber-500 to-yellow-400', probability: 0.40 },
  { id: 2, label: '5X MEGA', multiplier: 5, color: 'from-emerald-500 to-teal-400', probability: 0.25 },
  { id: 3, label: '10X ULTRA', multiplier: 10, color: 'from-cyan-500 to-blue-500', probability: 0.15 },
  { id: 4, label: 'TRY AGAIN', multiplier: 0, color: 'from-neutral-700 to-neutral-800', probability: 0.10 },
  { id: 5, label: '20X ROYAL', multiplier: 20, color: 'from-purple-600 to-indigo-600', probability: 0.07 },
  { id: 6, label: '100X JACKPOT', multiplier: 100, color: 'from-rose-600 to-amber-500', probability: 0.03 },
];

export const SRLuckyJackpotGame: React.FC<SRLuckyJackpotGameProps> = ({
  userCoins,
  onUpdateCoins,
  onClose,
}) => {
  const [selectedBet, setSelectedBet] = useState<number>(1000);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const [lastResult, setLastResult] = useState<{
    prize: PrizeSegment;
    wonCoins: number;
    transactionId: string;
  } | null>(null);

  const betOptions = [100, 500, 1000, 5000, 10000];

  const handleSpin = () => {
    if (isSpinning) return;
    if (userCoins < selectedBet) {
      playSoundFX('alert');
      alert('⚠️ Insufficient DIYO coins! Please recharge or claim test coins from admin.');
      return;
    }

    playSoundFX('click');
    setIsSpinning(true);
    setLastResult(null);

    // 1. Deduct bet instantly
    onUpdateCoins(-selectedBet);

    // 2. Determine winning prize based on weighted probability
    const rand = Math.random();
    let cumulative = 0;
    let winningPrize = PRIZES[0];
    for (const prize of PRIZES) {
      cumulative += prize.probability;
      if (rand <= cumulative) {
        winningPrize = prize;
        break;
      }
    }

    // Calculate wheel rotation angle (full spins + segment offset)
    const segmentDegree = 360 / PRIZES.length;
    const prizeIndex = PRIZES.findIndex(p => p.id === winningPrize.id);
    const extraSpins = 5 * 360; // 5 full rotations
    const targetAngle = rotationAngle + extraSpins + (360 - (prizeIndex * segmentDegree + segmentDegree / 2));

    setRotationAngle(targetAngle);

    setTimeout(() => {
      setIsSpinning(false);
      const wonCoins = selectedBet * winningPrize.multiplier;
      if (wonCoins > 0) {
        playSoundFX('success');
        onUpdateCoins(wonCoins);
      } else {
        playSoundFX('click');
      }

      setLastResult({
        prize: winningPrize,
        wonCoins,
        transactionId: `TX-GAME-${Math.floor(100000 + Math.random() * 900000)}`,
      });
    }, 3000);
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0e1b] text-white overflow-y-auto">
      {/* Game Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#13182e] border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 text-neutral-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-sm font-black tracking-tight font-['Outfit'] bg-gradient-to-r from-amber-300 via-yellow-400 to-orange-400 bg-clip-text text-transparent flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
              <span>DIYO Lucky Jackpot Royale</span>
            </h2>
            <p className="text-[10px] text-neutral-400 font-mono">Provably Fair • 100% Virtual Coins</p>
          </div>
        </div>

        {/* User Balance Pill */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/30">
          <Coins className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-xs font-bold text-amber-300 font-mono">{userCoins.toLocaleString()}</span>
        </div>
      </div>

      {/* Main Wheel Stage */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 max-w-md mx-auto w-full">
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 my-4 flex items-center justify-center">
          {/* Pointer */}
          <div className="absolute -top-3 z-30 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[22px] border-t-amber-400 drop-shadow-[0_2px_8px_rgba(245,158,11,0.8)]" />

          {/* Wheel Container */}
          <div
            className="w-full h-full rounded-full border-4 border-amber-400/60 shadow-[0_0_30px_rgba(245,158,11,0.3)] relative overflow-hidden transition-transform ease-out duration-[3000ms]"
            style={{ transform: `rotate(${rotationAngle}deg)` }}
          >
            {PRIZES.map((prize, idx) => {
              const angle = idx * (360 / PRIZES.length);
              return (
                <div
                  key={prize.id}
                  className={`absolute inset-0 bg-gradient-to-br ${prize.color} flex items-start justify-center pt-6 text-xs font-black uppercase tracking-wider text-neutral-950 border-r border-black/20`}
                  style={{
                    clipPath: 'polygon(50% 50%, 0 0, 100% 0)',
                    transform: `rotate(${angle}deg)`,
                    transformOrigin: '50% 50%',
                  }}
                >
                  <span className="transform rotate-90 mt-4 drop-shadow-[0_1px_2px_rgba(255,255,255,0.6)]">
                    {prize.label}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Center Hub */}
          <div className="absolute z-20 w-16 h-16 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 border-4 border-neutral-950 shadow-xl flex items-center justify-center">
            <Trophy className="w-7 h-7 text-neutral-950" />
          </div>
        </div>

        {/* Bet Selection Controls */}
        <div className="w-full mt-4 space-y-3 bg-[#13182e]/80 border border-white/10 rounded-2xl p-4 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Select Bet Amount</span>
            <span className="text-amber-400 font-bold font-mono">Max Win: {(selectedBet * 100).toLocaleString()} Coins</span>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {betOptions.map((bet) => (
              <button
                key={bet}
                disabled={isSpinning}
                onClick={() => {
                  playSoundFX('click');
                  setSelectedBet(bet);
                }}
                className={`py-2 rounded-xl font-mono text-xs font-bold transition-all ${
                  selectedBet === bet
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 shadow-lg shadow-amber-500/30 scale-105'
                    : 'bg-white/5 text-neutral-300 hover:bg-white/10 border border-white/10'
                }`}
              >
                {bet >= 1000 ? `${bet / 1000}K` : bet}
              </button>
            ))}
          </div>

          {/* Spin Action Button */}
          <button
            disabled={isSpinning}
            onClick={handleSpin}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-neutral-950 font-black text-sm tracking-wider uppercase shadow-[0_4px_20px_rgba(16,185,129,0.4)] hover:brightness-110 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Zap className={`w-4 h-4 fill-neutral-950 ${isSpinning ? 'animate-bounce' : ''}`} />
            <span>{isSpinning ? 'Spinning Wheel...' : `Spin Now (${selectedBet.toLocaleString()} Coins)`}</span>
          </button>
        </div>

        {/* Result Overlay Card */}
        {lastResult && (
          <div className="w-full mt-4 p-4 rounded-2xl bg-[#18203c] border border-amber-500/40 text-center animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-center gap-1.5 text-amber-400 font-black text-sm mb-1">
              <Award className="w-4 h-4" />
              <span>{lastResult.wonCoins > 0 ? 'CONGRATULATIONS! YOU WON!' : 'ROUND COMPLETED'}</span>
            </div>
            <p className="text-2xl font-black font-mono text-white mb-1">
              {lastResult.wonCoins > 0 ? `+${lastResult.wonCoins.toLocaleString()} Coins` : '0 Coins'}
            </p>
            <div className="flex items-center justify-center gap-2 text-[10px] text-neutral-400 font-mono">
              <span>Prize: {lastResult.prize.label}</span>
              <span>•</span>
              <span>{lastResult.transactionId}</span>
            </div>
          </div>
        )}
      </div>

      {/* Footer Security Note */}
      <div className="px-4 py-3 bg-[#0d1226] border-t border-white/5 text-center shrink-0">
        <p className="text-[10px] text-neutral-400 font-mono flex items-center justify-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Secured by DIYO Server-Authoritative RNG Engine</span>
        </p>
      </div>
    </div>
  );
};
