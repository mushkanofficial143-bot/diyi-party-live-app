import React, { useState } from 'react';
import { ArrowLeft, Sparkles, Coins, Disc, Trophy, RotateCcw } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface WheelOfFortuneProps {
  userCoins: number;
  onUpdateCoins: (delta: number) => void;
  onClose: () => void;
}

const WHEEL_SEGMENTS = [
  { label: '50x', multiplier: 50, color: '#f59e0b' },
  { label: '2x', multiplier: 2, color: '#ef4444' },
  { label: '0.5x', multiplier: 0.5, color: '#6366f1' },
  { label: '3x', multiplier: 3, color: '#f97316' },
  { label: '0x', multiplier: 0, color: '#64748b' },
  { label: '5x', multiplier: 5, color: '#22c55e' },
  { label: '0.5x', multiplier: 0.5, color: '#8b5cf6' },
  { label: '10x', multiplier: 10, color: '#eab308' },
  { label: '0x', multiplier: 0, color: '#475569' },
  { label: '1.5x', multiplier: 1.5, color: '#a855f7' },
  { label: '2x', multiplier: 2, color: '#dc2626' },
  { label: '0x', multiplier: 0, color: '#334155' },
];

export const WheelOfFortuneScreen: React.FC<WheelOfFortuneProps> = ({
  userCoins,
  onUpdateCoins,
  onClose,
}) => {
  const [selectedBet, setSelectedBet] = useState<number>(100000);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [rotation, setRotation] = useState<number>(0);
  const [lastResult, setLastResult] = useState<{ label: string; win: number } | null>(null);

  const betOptions = [1000, 10000, 20000, 50000, 100000, 500000, 1000000];

  const handleSpin = () => {
    if (isSpinning) return;
    if (userCoins < selectedBet) {
      playSoundFX('alert');
      alert('⚠️ Insufficient DIYO coins! Please recharge or claim test coins from wallet.');
      return;
    }

    playSoundFX('click');
    setIsSpinning(true);
    setLastResult(null);

    // Deduct bet
    onUpdateCoins(-selectedBet);

    // Random spin angle (at least 5 full turns + random segment)
    const segmentAngle = 360 / WHEEL_SEGMENTS.length;
    const winningIndex = Math.floor(Math.random() * WHEEL_SEGMENTS.length);
    // Calculate rotation so winningIndex lands at top indicator
    const extraSpins = 360 * 6;
    const targetAngle = rotation + extraSpins + (360 - (winningIndex * segmentAngle + segmentAngle / 2));

    setRotation(targetAngle);

    setTimeout(() => {
      setIsSpinning(false);
      const segment = WHEEL_SEGMENTS[winningIndex];
      const winAmount = Math.floor(selectedBet * segment.multiplier);

      if (winAmount > 0) {
        playSoundFX('success');
        confetti({ particleCount: 70, spread: 80, origin: { y: 0.5 } });
        onUpdateCoins(winAmount);
      } else {
        playSoundFX('click');
      }

      setLastResult({ label: segment.label, win: winAmount });
    }, 3500);
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0e1b] text-white overflow-y-auto select-none font-['Plus_Jakarta_Sans',sans-serif]">
      
      {/* Top Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#13182e] border-b border-amber-500/25 shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 text-neutral-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <Disc className="w-4 h-4 animate-spin" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight font-['Outfit'] bg-gradient-to-r from-amber-300 via-yellow-400 to-orange-400 bg-clip-text text-transparent">
                Wheel of Fortune
              </h2>
              <p className="text-[10px] text-neutral-400">DIYO Official Wheel</p>
            </div>
          </div>
        </div>

        {/* Balance */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/30">
          <Coins className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-xs font-bold text-amber-300 font-mono">{userCoins.toLocaleString()}</span>
        </div>
      </div>

      {/* Main Game Stage */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 max-w-md mx-auto w-full">
        
        {/* Wheel Container */}
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 my-2 flex items-center justify-center">
          {/* Pointer indicator at top */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-30 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[22px] border-t-amber-300 filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" />

          {/* Golden Outer Rim */}
          <div className="absolute inset-0 rounded-full border-[10px] border-amber-500/90 shadow-[0_0_35px_rgba(245,158,11,0.5)] bg-[#0f1428] overflow-hidden">
            
            {/* Spinning Wheel Disk */}
            <div
              className="w-full h-full rounded-full relative transition-all ease-out"
              style={{
                transform: `rotate(${rotation}deg)`,
                transitionDuration: isSpinning ? '3.5s' : '0s',
              }}
            >
              {WHEEL_SEGMENTS.map((seg, idx) => {
                const angle = (360 / WHEEL_SEGMENTS.length) * idx;
                return (
                  <div
                    key={idx}
                    className="absolute top-0 left-1/2 w-1/2 h-full origin-left flex items-center justify-end pr-4 text-xs font-black text-white"
                    style={{
                      transform: `rotate(${angle}deg)`,
                      backgroundColor: seg.color,
                      clipPath: 'polygon(0 0, 100% 35%, 100% 65%, 0 100%)',
                      borderRight: '1px solid rgba(255,255,255,0.2)',
                    }}
                  >
                    <span className="transform rotate-90 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] font-['Outfit'] text-xs sm:text-sm font-black">
                      {seg.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Center Hub */}
          <div className="absolute z-20 w-12 h-12 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-300 border-2 border-white shadow-xl flex items-center justify-center text-neutral-950 font-black text-xs">
            TP
          </div>
        </div>

        {/* Win / Status Banner */}
        <div className="w-full bg-[#13182e]/90 border border-amber-500/40 rounded-2xl p-3 text-center my-3 shadow-[0_8px_20px_rgba(0,0,0,0.4)]">
          {lastResult ? (
            <div className="animate-in fade-in zoom-in duration-200">
              <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">{lastResult.label} Win!</span>
              <div className="text-base sm:text-lg font-black text-white font-mono mt-0.5">
                {lastResult.win > 0 ? `+${lastResult.win.toLocaleString()} Coins! 🎉` : `0 Coins (Try Again)`}
              </div>
            </div>
          ) : (
            <div className="text-xs font-bold text-amber-300">
              {isSpinning ? '🎡 Wheel is spinning...' : 'Select spin amount and press SPIN!'}
            </div>
          )}
        </div>

        {/* Spin Amount Chips Selector */}
        <div className="w-full bg-[#13182e]/90 border border-white/10 rounded-2xl p-3.5 mb-3 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Spin Amount</span>
            <span className="text-xs font-black text-amber-300 font-mono">{selectedBet.toLocaleString()} Coins</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-7">
            {betOptions.map((amt) => {
              const isSelected = selectedBet === amt;
              return (
                <button
                  key={amt}
                  onClick={() => {
                    playSoundFX('click');
                    setSelectedBet(amt);
                  }}
                  className={`py-1.5 px-1 rounded-xl text-[11px] font-black font-mono transition-all ${
                    isSelected
                      ? 'bg-amber-500 text-neutral-950 shadow-lg scale-105 border border-amber-300'
                      : 'bg-white/5 text-neutral-300 hover:bg-white/10 border border-white/5'
                  }`}
                >
                  {amt >= 1000000 ? `${amt / 1000000}M` : amt >= 1000 ? `${amt / 1000}K` : amt}
                </button>
              );
            })}
          </div>
        </div>

        {/* Big Spin Button */}
        <button
          onClick={handleSpin}
          disabled={isSpinning}
          className={`w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-neutral-950 font-black text-base uppercase tracking-wider shadow-[0_0_25px_rgba(245,158,11,0.5)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer ${
            isSpinning ? 'opacity-60 cursor-not-allowed animate-pulse' : ''
          }`}
        >
          <Disc className={`w-5 h-5 ${isSpinning ? 'animate-spin' : ''}`} />
          <span>{isSpinning ? 'SPINNING...' : 'SPIN WHEEL'}</span>
        </button>

      </div>
    </div>
  );
};
