import React, { useState } from 'react';
import { 
  Sparkles, 
  X, 
  Flame, 
  Crown, 
  Zap, 
  ShieldCheck, 
  History, 
  Gift, 
  ChevronRight,
  TrendingUp,
  Volume2
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';
import { LuckyComboBanner } from './LuckyComboBanner';

export type LuckyBoxMultiplierOption = '10X' | '20X' | '30X' | '50X' | '100X';

export interface LuckyBoxWinEvent {
  boxId: string;
  senderName: string;
  multiplier: LuckyBoxMultiplierOption;
  multiplierTimes: number; // e.g. 800, 945, 1305, 580, 424080
  icon: string; // '🍉', '💋', '👑', '💎', '🪙'
  wonCoins: number;
  wonDiamonds: number;
  timestamp: string;
}

interface LuckyBoxChestOpeningProps {
  isOpen: boolean;
  onClose: () => void;
  userCoinBalance: number;
  userDiamondBalance?: number;
  currentUserName?: string;
  onUpdateUserBalance?: (newCoins: number, newDiamonds: number) => void;
  onBroadcastWin?: (win: LuckyBoxWinEvent) => void;
}

export const LuckyBoxChestOpening: React.FC<LuckyBoxChestOpeningProps> = ({
  isOpen,
  onClose,
  userCoinBalance,
  userDiamondBalance = 18500,
  currentUserName = 'DIYO LIVE Stream',
  onUpdateUserBalance,
  onBroadcastWin
}) => {
  const [selectedMultiplier, setSelectedMultiplier] = useState<LuckyBoxMultiplierOption>('20X');
  const [baseBetCoins, setBaseBetCoins] = useState<number>(1000);
  const [isOpening, setIsOpening] = useState(false);
  const [showWinReveal, setShowWinReveal] = useState(false);
  const [lastWin, setLastWin] = useState<LuckyBoxWinEvent | null>(null);

  if (!isOpen) return null;

  const multiplierValues: Record<LuckyBoxMultiplierOption, number> = {
    '10X': 10,
    '20X': 20,
    '30X': 30,
    '50X': 50,
    '100X': 100
  };

  const currentMultNum = multiplierValues[selectedMultiplier];
  const totalCost = baseBetCoins * currentMultNum;

  // Multiplier color themes
  const multiplierColors: Record<LuckyBoxMultiplierOption, { bg: string; border: string; text: string; glow: string }> = {
    '10X': {
      bg: 'from-amber-600 to-yellow-600',
      border: 'border-amber-400',
      text: 'text-amber-200',
      glow: 'shadow-amber-500/40'
    },
    '20X': {
      bg: 'from-emerald-600 to-teal-700',
      border: 'border-emerald-400',
      text: 'text-emerald-200',
      glow: 'shadow-emerald-500/40'
    },
    '30X': {
      bg: 'from-blue-600 to-cyan-600',
      border: 'border-cyan-400',
      text: 'text-cyan-200',
      glow: 'shadow-cyan-500/40'
    },
    '50X': {
      bg: 'from-purple-600 to-pink-600',
      border: 'border-purple-400',
      text: 'text-purple-200',
      glow: 'shadow-purple-500/40'
    },
    '100X': {
      bg: 'from-rose-600 via-amber-500 to-yellow-400',
      border: 'border-yellow-300',
      text: 'text-yellow-100',
      glow: 'shadow-yellow-500/60'
    }
  };

  const handleOpenChest = () => {
    if (userCoinBalance < totalCost) {
      playSoundFX('click');
      alert(`Insufficient Coins! Need ${totalCost.toLocaleString()} Coins. You have ${userCoinBalance.toLocaleString()} Coins.`);
      return;
    }

    setIsOpening(true);
    setShowWinReveal(false);
    playSoundFX('magic');

    // Deduct cost
    const afterCostBalance = userCoinBalance - totalCost;
    if (onUpdateUserBalance) {
      onUpdateUserBalance(afterCostBalance, userDiamondBalance);
    }

    // Chest shaking animation & audio build up
    setTimeout(() => {
      playSoundFX('superchat');
    }, 600);

    setTimeout(() => {
      // Calculate authentic high multiplier outcomes:
      // Possible outcomes: 10x, 20x, 35x, 50x, 80x, 100x, 580x, 800x, 945x, 1305x, 424080x!
      const outcomeOptions = [
        { mult: 800, icon: '🍉', isJackpot: true },
        { mult: 945, icon: '🍉', isJackpot: true },
        { mult: 1305, icon: '💋', isJackpot: true },
        { mult: 580, icon: '💋', isJackpot: true },
        { mult: 35, icon: '👑', isJackpot: false },
        { mult: 50, icon: '💎', isJackpot: false },
        { mult: 100, icon: '🪙', isJackpot: true },
        { mult: 424080, icon: '💎', isJackpot: true }
      ];

      // Weight jackpot higher for excitement in test mode
      const selectedOutcome = outcomeOptions[Math.floor(Math.random() * outcomeOptions.length)];
      const wonCoins = Math.round(totalCost * (selectedOutcome.mult > 1000 ? 5.5 : selectedOutcome.mult * 0.4));
      const wonDiamonds = Math.round(wonCoins * 0.4);

      const newCoins = afterCostBalance + wonCoins;
      const newDiamonds = userDiamondBalance + wonDiamonds;

      if (onUpdateUserBalance) {
        onUpdateUserBalance(newCoins, newDiamonds);
      }

      const winEvent: LuckyBoxWinEvent = {
        boxId: `LBOX-${Date.now()}`,
        senderName: currentUserName,
        multiplier: selectedMultiplier,
        multiplierTimes: selectedOutcome.mult,
        icon: selectedOutcome.icon,
        wonCoins,
        wonDiamonds,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setLastWin(winEvent);
      setIsOpening(false);
      setShowWinReveal(true);

      // Explosive confetti and fanfare audio
      playSoundFX('win');
      confetti({
        particleCount: selectedOutcome.mult >= 500 ? 150 : 80,
        spread: 100,
        origin: { y: 0.6 }
      });

      if (onBroadcastWin) {
        onBroadcastWin(winEvent);
      }
    }, 1400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#1f1633] via-[#130d22] to-[#0a0714] border-2 border-amber-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-purple-950/80 text-white overflow-hidden animate-in zoom-in-95">
        
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-32 bg-gradient-to-b from-amber-500/25 to-transparent blur-2xl pointer-events-none" />

        {/* Top Header Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-purple-500/20 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-neutral-950 font-black shadow-lg shadow-amber-500/30">
              <Gift className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-200 to-yellow-400 font-['Outfit'] tracking-wide">
                  LUCKY BOX 10X - 100X
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-black border border-amber-500/40 uppercase">
                  JACKPOT ACTIVE
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">Open lucky gift chests with massive 800X - 424080X multipliers!</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-neutral-900/90 border border-neutral-700/80 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Multiplier Quick Tabs (10X, 20X, 30X, 50X, 100X) */}
        <div className="mt-4 relative z-10">
          <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider block mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-amber-300">
              <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>Select Multiplier Mode</span>
            </span>
            <span className="text-[11px] font-mono text-neutral-400">
              Balance: <strong className="text-yellow-400">{userCoinBalance.toLocaleString()}</strong> 🪙
            </span>
          </label>

          <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
            {(['10X', '20X', '30X', '50X', '100X'] as LuckyBoxMultiplierOption[]).map((mult) => {
              const isSelected = selectedMultiplier === mult;
              const theme = multiplierColors[mult];

              return (
                <button
                  key={mult}
                  onClick={() => {
                    setSelectedMultiplier(mult);
                    playSoundFX('click');
                  }}
                  className={`relative py-2.5 px-1 rounded-2xl flex flex-col items-center justify-center transition-all border font-black active:scale-95 ${
                    isSelected
                      ? `bg-gradient-to-b ${theme.bg} ${theme.border} text-white shadow-lg ${theme.glow} scale-105 ring-2 ring-white/50`
                      : 'bg-neutral-900/80 border-neutral-700/80 text-neutral-400 hover:text-white hover:border-neutral-500'
                  }`}
                >
                  <span className="text-sm sm:text-base font-black tracking-wider drop-shadow">
                    {mult}
                  </span>
                  <span className="text-[9px] opacity-80 mt-0.5">
                    {multiplierValues[mult]}x Odds
                  </span>
                  {isSelected && (
                    <span className="absolute -top-1.5 -right-1 flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-300" />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Center Animated Chest Stage */}
        <div className="my-5 py-4 px-3 rounded-2xl bg-gradient-to-b from-[#2a1e45]/50 to-[#140e24]/70 border border-purple-500/30 flex flex-col items-center justify-center relative min-h-[190px]">
          
          {/* Radiant god-rays background during opening or win */}
          {(isOpening || showWinReveal) && (
            <div className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none">
              <div className="w-96 h-96 rounded-full bg-gradient-to-r from-amber-500/30 via-yellow-300/20 to-purple-600/30 blur-2xl animate-spin" />
            </div>
          )}

          {!showWinReveal ? (
            /* Chest Visual */
            <div className="flex flex-col items-center relative z-10">
              <div className={`text-6xl sm:text-7xl transition-transform duration-300 ${isOpening ? 'animate-bounce scale-110' : 'hover:scale-105'}`}>
                {isOpening ? '💥' : '🎁'}
              </div>

              <div className="mt-3 text-center">
                <div className="text-sm font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5 justify-center">
                  <Sparkles className="w-4 h-4 text-yellow-400 animate-spin" />
                  <span>{selectedMultiplier} Golden Mystery Box</span>
                  <Sparkles className="w-4 h-4 text-yellow-400 animate-spin" />
                </div>
                <div className="text-xs text-neutral-300 font-bold mt-1">
                  Cost: <span className="text-yellow-400 font-mono font-black">{totalCost.toLocaleString()} Coins</span> • Max Win: <span className="text-emerald-400 font-mono font-black">{(totalCost * currentMultNum).toLocaleString()} Coins</span>
                </div>
              </div>
            </div>
          ) : (
            /* Win Reveal Burst (Matching Screenshot: 35 TIMES, 800 TIMES, 945 TIMES, 1305 TIMES, x 424080) */
            <div className="flex flex-col items-center justify-center text-center animate-in zoom-in-75 relative z-10 py-2 w-full">
              {/* Authentic Screenshot Lucky Combo Banner */}
              <LuckyComboBanner
                data={{
                  senderName: currentUserName,
                  senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
                  recipientName: 'Room VIPs',
                  recipientAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150',
                  multiplierNumber: lastWin?.multiplierTimes || 35,
                  multiplierLabel: 'TIMES',
                  comboMultiplier: (lastWin?.multiplierTimes || 35) >= 500 ? ((lastWin?.multiplierTimes || 35) * 10).toString() : '424080',
                  giftIconType: 'coconut',
                  giftName: 'Lucky Mystery Box'
                }}
              />

              <div className="flex items-center gap-3 mt-3">
                <div className="px-3 py-1 rounded-xl bg-neutral-900/90 border border-yellow-500/40 text-xs font-bold text-yellow-300 font-mono">
                  +{(lastWin?.wonCoins ?? 0).toLocaleString()} Coins 🪙
                </div>
                <div className="px-3 py-1 rounded-xl bg-neutral-900/90 border border-cyan-500/40 text-xs font-bold text-cyan-300 font-mono">
                  +{(lastWin?.wonDiamonds ?? 0).toLocaleString()} 💎
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Base Bet Selector */}
        <div className="flex items-center justify-between bg-neutral-900/80 border border-neutral-800 rounded-2xl p-2.5 mb-4 relative z-10">
          <span className="text-xs font-bold text-neutral-300">Base Bet:</span>
          <div className="flex items-center gap-1.5">
            {[500, 1000, 5000, 10000].map((amount) => (
              <button
                key={amount}
                onClick={() => {
                  setBaseBetCoins(amount);
                  playSoundFX('click');
                }}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold font-mono transition-all ${
                  baseBetCoins === amount
                    ? 'bg-amber-500 text-neutral-950 font-black shadow-md'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                {amount.toLocaleString()}
              </button>
            ))}
          </div>
        </div>

        {/* Bottom Open Button */}
        <div className="flex items-center gap-3 relative z-10">
          <button
            disabled={isOpening}
            onClick={handleOpenChest}
            className={`flex-1 py-3.5 rounded-2xl font-black text-sm tracking-wider uppercase flex items-center justify-center gap-2 transition-all active:scale-95 shadow-xl ${
              isOpening
                ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-neutral-950 shadow-amber-500/40 hover:brightness-110 border-2 border-yellow-200'
            }`}
          >
            {isOpening ? (
              <>
                <Sparkles className="w-5 h-5 animate-spin text-amber-400" />
                <span>Opening {selectedMultiplier} Chest...</span>
              </>
            ) : (
              <>
                <span>Open {selectedMultiplier} Lucky Box ({totalCost.toLocaleString()} 🪙)</span>
                <ChevronRight className="w-5 h-5 stroke-[3]" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
