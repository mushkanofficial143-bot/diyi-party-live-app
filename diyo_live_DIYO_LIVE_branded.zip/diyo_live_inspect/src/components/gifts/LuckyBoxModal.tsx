import React, { useState } from 'react';
import { 
  Gift, 
  Sparkles, 
  CheckCircle, 
  History, 
  HelpCircle, 
  X, 
  ChevronRight, 
  ShieldCheck, 
  Zap, 
  Award,
  Lock,
  ArrowRight
} from 'lucide-react';
import { LuckyBoxConfig, LuckyBoxItem, LuckyBoxMultiplier } from '../../types/ownerTypes';
import { DEFAULT_LUCKY_BOX_CONFIG, INITIAL_LUCKY_BOX_HISTORY } from '../../data/platformFeaturesData';

interface LuckyBoxModalProps {
  isOpen: boolean;
  onClose: () => void;
  senderId?: string;
  senderName?: string;
  receiverId: string;
  receiverName: string;
  userCoinBalance: number;
  onSendSuccess?: (box: LuckyBoxItem, newBalance: number) => void;
  config?: LuckyBoxConfig;
  liveLuckyBoxHistory?: LuckyBoxItem[];
  onOpenBox?: (boxId: string) => Promise<any>;
}

export const LuckyBoxModal: React.FC<LuckyBoxModalProps> = ({
  isOpen,
  onClose,
  senderId = 'USR-882941',
  senderName = 'Aarav Mehta',
  receiverId,
  receiverName,
  userCoinBalance,
  onSendSuccess,
  config = DEFAULT_LUCKY_BOX_CONFIG,
  liveLuckyBoxHistory = INITIAL_LUCKY_BOX_HISTORY,
  onOpenBox
}) => {
  const [activeTab, setActiveTab] = useState<'SEND' | 'OPEN' | 'HISTORY'>('SEND');
  const [selectedMultiplier, setSelectedMultiplier] = useState<LuckyBoxMultiplier>('20X');
  const [baseCostCoins, setBaseCostCoins] = useState<number>(1000);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successBox, setSuccessBox] = useState<LuckyBoxItem | null>(null);
  const [openingBoxId, setOpeningBoxId] = useState<string | null>(null);
  const [revealedReward, setRevealedReward] = useState<{ boxId: string; reward: number; multiplier: string } | null>(null);

  if (!isOpen) return null;

  const multiplierMultipliers: Record<LuckyBoxMultiplier, number> = {
    '10X': 10,
    '20X': 20,
    '30X': 30,
    '50X': 50,
    '100X': 100
  };

  const multNumber = multiplierMultipliers[selectedMultiplier] || 20;
  const totalCost = baseCostCoins * multNumber;
  const potentialMaxReward = totalCost * multNumber;

  const isMultiplierEnabled = config.multipliers[selectedMultiplier] ?? true;

  const handleSendLuckyBox = async () => {
    setErrorMsg(null);
    if (!config.enabled) {
      setErrorMsg('Lucky Box feature is currently disabled by Platform Owner.');
      return;
    }
    if (!isMultiplierEnabled) {
      setErrorMsg(`Multiplier ${selectedMultiplier} is currently disabled by Platform Owner.`);
      return;
    }
    if (userCoinBalance < totalCost) {
      setErrorMsg(`Insufficient TEST COINS! Cost: ${(totalCost ?? 0).toLocaleString()} TEST COINS. You have: ${(userCoinBalance ?? 0).toLocaleString()} TEST COINS.`);
      return;
    }

    setIsSubmitting(true);
    try {
      // Call server API for atomic authoritative deduction
      const res = await fetch('/api/lucky-box/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId,
          receiverId,
          multiplier: selectedMultiplier,
          baseCost: baseCostCoins
        })
      });

      const data = await res.json();
      if (data.success) {
        setSuccessBox(data.luckyBox);
        if (onSendSuccess) {
          onSendSuccess(data.luckyBox, data.senderBalance);
        }
      } else {
        setErrorMsg(data.error || 'Failed to send Lucky Box');
      }
    } catch (err: any) {
      // Fallback local simulation if backend unavailable
      const newBox: LuckyBoxItem = {
        id: `LB-${Date.now()}`,
        senderId,
        senderName,
        receiverId,
        receiverName,
        multiplier: selectedMultiplier,
        multiplierNumber: multNumber,
        costCoins: totalCost,
        potentialMaxRewardCoins: potentialMaxReward,
        opened: false,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        TEST_MODE: true
      };
      setSuccessBox(newBox);
      if (onSendSuccess) {
        onSendSuccess(newBox, userCoinBalance - totalCost);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenLuckyBox = async (box: LuckyBoxItem) => {
    setOpeningBoxId(box.id);
    setErrorMsg(null);
    try {
      if (onOpenBox) {
        const res = await onOpenBox(box.id);
        if (res?.wonRewardCoins) {
          setRevealedReward({
            boxId: box.id,
            reward: res.wonRewardCoins,
            multiplier: box.multiplier
          });
        }
      } else {
        const res = await fetch('/api/lucky-box/open', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            boxId: box.id,
            receiverId: box.receiverId
          })
        });
        const data = await res.json();
        if (data.success) {
          setRevealedReward({
            boxId: box.id,
            reward: data.wonRewardCoins,
            multiplier: box.multiplier
          });
        } else {
          setErrorMsg(data.error || 'Failed to open Lucky Box');
        }
      }
    } catch (err: any) {
      // Fallback client simulation
      const fallbackReward = Math.floor(box.costCoins * (0.8 + Math.random() * (box.multiplierNumber * 0.5)));
      setRevealedReward({
        boxId: box.id,
        reward: fallbackReward,
        multiplier: box.multiplier
      });
    } finally {
      setOpeningBoxId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        id="lucky-box-modal-container"
        className="relative w-full max-w-lg bg-neutral-900 border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden text-neutral-100 flex flex-col max-h-[90vh]"
      >
        {/* Header Banner */}
        <div className="relative px-6 py-4 bg-gradient-to-r from-amber-950 via-yellow-950/80 to-neutral-900 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-2xl shadow-inner shadow-amber-500/30">
              🎁
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-amber-200 tracking-wide">SR LUCKY BOX</h3>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  TEST COINS
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                To: <span className="text-amber-400 font-semibold">{receiverName}</span>
              </p>
            </div>
          </div>
          <button 
            id="close-lucky-box-modal-btn"
            onClick={onClose} 
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Compliance & Test Notice */}
        <div className="px-6 py-1.5 bg-amber-500/10 border-b border-amber-500/20 flex items-center justify-between text-[11px] text-amber-300">
          <span className="flex items-center gap-1.5 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            TEST MODE — Virtual TEST COINS only. No real money.
          </span>
          <span className="font-mono text-neutral-400">
            Bal: <strong className="text-amber-300">{(userCoinBalance ?? 0).toLocaleString()}</strong> TC
          </span>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-neutral-800 bg-neutral-950/60 px-6 pt-2 gap-2">
          <button
            id="lucky-box-tab-send"
            onClick={() => { setActiveTab('SEND'); setSuccessBox(null); }}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'SEND'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Send Lucky Box
          </button>
          <button
            id="lucky-box-tab-open"
            onClick={() => setActiveTab('OPEN')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'OPEN'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Open Box ({liveLuckyBoxHistory.filter(b => !b.opened).length})
          </button>
          <button
            id="lucky-box-tab-history"
            onClick={() => setActiveTab('HISTORY')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'HISTORY'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            History & Logs
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {errorMsg && (
            <div className="p-3 bg-red-950/50 border border-red-500/50 rounded-xl text-red-300 text-xs flex items-center justify-between">
              <span>{errorMsg}</span>
              <button onClick={() => setErrorMsg(null)} className="text-red-400 hover:text-red-200">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* TAB 1: SEND LUCKY BOX */}
          {activeTab === 'SEND' && (
            <>
              {successBox ? (
                <div className="p-6 bg-gradient-to-b from-amber-950/40 to-neutral-900 border border-amber-500/40 rounded-2xl text-center space-y-4 animate-scale-up">
                  <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-4xl shadow-lg shadow-amber-500/30">
                    🎁
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-amber-300">Lucky Box Dispatched!</h4>
                    <p className="text-xs text-neutral-300 mt-1">
                      Sent <strong className="text-amber-400">{successBox.multiplier} Lucky Box</strong> to{' '}
                      <strong>{successBox.receiverName}</strong>!
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs bg-neutral-950/80 p-3 rounded-xl border border-neutral-800">
                    <div className="text-neutral-400">Total Deducted:</div>
                    <div className="text-right font-mono text-amber-300">{(successBox.costCoins ?? 0).toLocaleString()} TC</div>
                    <div className="text-neutral-400">Potential Max Reward:</div>
                    <div className="text-right font-mono text-emerald-400">{(successBox.potentialMaxRewardCoins ?? 0).toLocaleString()} TC</div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSuccessBox(null)}
                      className="flex-1 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold transition-colors"
                    >
                      Send Another
                    </button>
                    <button
                      onClick={() => setActiveTab('HISTORY')}
                      className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-xl text-xs transition-colors"
                    >
                      View Live History
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* Multiplier Selection (10X, 20X, 30X, 50X, 100X) */}
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                      Select Multiplier Tier
                    </label>
                    <div className="grid grid-cols-5 gap-2">
                      {(['10X', '20X', '30X', '50X', '100X'] as LuckyBoxMultiplier[]).map((mult) => {
                        const enabled = config.multipliers[mult] ?? true;
                        const isSelected = selectedMultiplier === mult;
                        return (
                          <button
                            key={mult}
                            id={`multiplier-btn-${mult}`}
                            disabled={!enabled}
                            onClick={() => setSelectedMultiplier(mult)}
                            className={`relative flex flex-col items-center justify-center p-3 rounded-xl border transition-all text-center ${
                              !enabled
                                ? 'bg-neutral-950/40 border-neutral-800 text-neutral-600 cursor-not-allowed opacity-50'
                                : isSelected
                                ? 'bg-gradient-to-b from-amber-500/30 to-amber-950/60 border-amber-400 text-amber-200 shadow-lg shadow-amber-500/20 scale-[1.03]'
                                : 'bg-neutral-950/60 border-neutral-800 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-800'
                            }`}
                          >
                            {!enabled && (
                              <Lock className="w-3 h-3 absolute top-1 right-1 text-neutral-500" />
                            )}
                            <span className="text-sm font-black tracking-tight">{mult}</span>
                            <span className="text-[10px] text-neutral-400 mt-0.5">
                              {multiplierMultipliers[mult]}x Max
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Base Cost Selector */}
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                      Base Investment Tier
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[1000, 2500, 5000].map((cost) => (
                        <button
                          key={cost}
                          onClick={() => setBaseCostCoins(cost)}
                          className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all ${
                            baseCostCoins === cost
                              ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                              : 'bg-neutral-950/50 border-neutral-800 text-neutral-400 hover:bg-neutral-800'
                          }`}
                        >
                          {(cost ?? 0).toLocaleString()} TC Base
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Summary Card */}
                  <div className="p-4 bg-gradient-to-br from-neutral-950 to-neutral-900 border border-neutral-800 rounded-xl space-y-2.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-neutral-400">Selected Lucky Multiplier:</span>
                      <span className="font-bold text-amber-300">{selectedMultiplier}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-neutral-400">Total Sending Cost:</span>
                      <span className="font-mono font-bold text-white text-sm">
                        {(totalCost ?? 0).toLocaleString()} TEST COINS
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs pt-2 border-t border-neutral-800/80">
                      <span className="text-neutral-400 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
                        Potential Max Virtual Reward:
                      </span>
                      <span className="font-mono font-bold text-emerald-400 text-sm">
                        Up to {(potentialMaxReward ?? 0).toLocaleString()} TC
                      </span>
                    </div>
                  </div>

                  {/* Send CTA Button */}
                  <button
                    id="submit-send-lucky-box-btn"
                    disabled={isSubmitting || !isMultiplierEnabled || userCoinBalance < totalCost}
                    onClick={handleSendLuckyBox}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-neutral-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <span className="animate-spin text-lg">⏳</span>
                    ) : (
                      <>
                        <span>Send {selectedMultiplier} Lucky Box ({(totalCost ?? 0).toLocaleString()} TC)</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </>
              )}
            </>
          )}

          {/* TAB 2: RECEIVER OPEN BOX */}
          {activeTab === 'OPEN' && (
            <div className="space-y-4">
              {revealedReward && (
                <div className="p-5 bg-gradient-to-b from-yellow-950/60 to-neutral-900 border-2 border-yellow-400 rounded-2xl text-center space-y-3 animate-scale-up">
                  <div className="text-4xl animate-bounce">🎊</div>
                  <h4 className="text-lg font-extrabold text-yellow-300">Congratulations!</h4>
                  <p className="text-xs text-neutral-300">
                    You opened a <strong className="text-amber-400">{revealedReward.multiplier} Lucky Box</strong> and won:
                  </p>
                  <div className="text-2xl font-black font-mono text-emerald-400 bg-black/60 py-2.5 px-4 rounded-xl border border-emerald-500/40 inline-block shadow-lg shadow-emerald-500/20">
                    +{((revealedReward?.reward) ?? 0).toLocaleString()} TEST COINS
                  </div>
                  <p className="text-[11px] text-neutral-400">Credited automatically to your virtual test balance.</p>
                  <button
                    onClick={() => setRevealedReward(null)}
                    className="mt-2 py-2 px-6 bg-yellow-500 hover:bg-yellow-400 text-neutral-950 font-bold text-xs rounded-xl transition-colors"
                  >
                    Claim & Close
                  </button>
                </div>
              )}

              <div className="space-y-2.5">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  Unopened Received Boxes
                </h4>
                {(liveLuckyBoxHistory || []).filter(b => !b.opened).length === 0 ? (
                  <div className="p-8 text-center bg-neutral-950/50 rounded-xl border border-neutral-800 text-neutral-500 text-xs">
                    No pending Lucky Boxes waiting to be opened.
                  </div>
                ) : (
                  (liveLuckyBoxHistory || [])
                    .filter(b => !b.opened)
                    .map((box) => (
                      <div
                        key={box.id}
                        className="p-3.5 bg-neutral-950/80 border border-amber-500/30 rounded-xl flex items-center justify-between gap-3 hover:border-amber-400/60 transition-all"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-xl">
                            🎁
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white">{box.multiplier} Lucky Box</span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">
                                Up to {(box.potentialMaxRewardCoins ?? 0).toLocaleString()} TC
                              </span>
                            </div>
                            <p className="text-[11px] text-neutral-400 mt-0.5">
                              From: <strong className="text-neutral-200">{box.senderName}</strong> • {box.createdAt}
                            </p>
                          </div>
                        </div>

                        <button
                          id={`open-lucky-box-btn-${box.id}`}
                          disabled={openingBoxId === box.id}
                          onClick={() => handleOpenLuckyBox(box)}
                          className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-neutral-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
                        >
                          {openingBoxId === box.id ? (
                            <span className="animate-spin">⏳</span>
                          ) : (
                            <>
                              <span>Open</span>
                              <Zap className="w-3.5 h-3.5" />
                            </>
                          )}
                        </button>
                      </div>
                    ))
                )}
              </div>
            </div>
          )}

          {/* TAB 3: HISTORY */}
          {activeTab === 'HISTORY' && (
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Lucky Box Distribution Ledger
              </h4>
              <div className="space-y-2">
                {(liveLuckyBoxHistory || []).map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-neutral-950/70 border border-neutral-800 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-amber-300">{item.multiplier} Box</span>
                        <span className="text-neutral-400 font-mono text-[11px]">({(item.costCoins ?? 0).toLocaleString()} TC)</span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                            item.opened
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {item.opened ? 'OPENED' : 'UNOPENED'}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-400 mt-1">
                        {item.senderName} ➔ {item.receiverName} • {item.createdAt}
                      </p>
                    </div>

                    <div className="text-right">
                      {item.opened ? (
                        <div>
                          <div className="text-emerald-400 font-bold font-mono">
                            +{(item.wonRewardCoins ?? 0).toLocaleString()} TC
                          </div>
                          <div className="text-[10px] text-neutral-500">{item.openedAt}</div>
                        </div>
                      ) : (
                        <div className="text-neutral-500 font-mono text-[11px]">
                          Max: {(item.potentialMaxRewardCoins ?? 0).toLocaleString()} TC
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
