import React from 'react';
import { Sparkles } from 'lucide-react';

export interface LuckyComboBannerData {
  id?: string;
  senderName?: string;
  senderAvatar?: string;
  recipientName?: string;
  recipientAvatar?: string;
  multiplierNumber: number | string; // e.g. 35, 800, 945, 1305, 580, 100
  multiplierLabel?: string; // 'TIMES'
  comboMultiplier: number | string; // e.g. 424080, 80000, 94500, 130500
  giftIconType?: 'coconut' | 'diamond' | 'crown' | 'watermelon' | 'kiss';
  giftName?: string; // 'Coconut Drink', 'Lucky Diamond'
  onClose?: () => void;
  onClick?: () => void;
}

interface LuckyComboBannerProps {
  data?: LuckyComboBannerData;
  className?: string;
}

const defaultData: LuckyComboBannerData = {
  senderName: 'Antara Ch...',
  senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
  recipientName: 'Gloria Gasp',
  recipientAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150',
  multiplierNumber: 35,
  multiplierLabel: 'TIMES',
  comboMultiplier: '424080',
  giftIconType: 'coconut',
  giftName: 'Coconut'
};

export const LuckyComboBanner: React.FC<LuckyComboBannerProps> = ({
  data = defaultData,
  className = ''
}) => {
  const bannerData = { ...defaultData, ...data };

  return (
    <div 
      onClick={bannerData.onClick}
      className={`relative w-full max-w-2xl mx-auto select-none pointer-events-auto cursor-pointer animate-in zoom-in-95 duration-500 ${className}`}
    >
      {/* Background Soft Glow Aura */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-600/30 via-cyan-400/30 to-amber-500/30 blur-xl rounded-full pointer-events-none" />

      {/* Main Horizontal Ribbon Frame (Matching Screenshot) */}
      <div className="relative flex items-center justify-between min-h-[58px] sm:min-h-[64px] px-1 sm:px-2">
        
        {/* ================= LEFT SECTION: SENDER AVATAR WITH DOUBLE "NEW" STARS ================= */}
        <div className="relative z-30 flex-shrink-0 flex items-center">
          {/* Avatar Container with Ornate Purple/Pink Glow Ring */}
          <div className="relative w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 flex items-center justify-center">
            
            {/* Ornate Neon Star Crest (Double NEW NEW Ribbon) */}
            <div className="absolute -top-3.5 -left-2 z-40 flex items-center -space-x-1 filter drop-shadow-[0_0_8px_rgba(244,114,182,0.9)]">
              <div className="relative flex flex-col items-center">
                <span className="text-[10px] sm:text-xs">⭐</span>
                <span className="px-1.5 py-0.2 rounded-full bg-gradient-to-r from-fuchsia-600 via-pink-500 to-purple-600 border border-white/80 text-[7px] sm:text-[8px] font-black text-white uppercase tracking-tighter shadow-lg shadow-pink-500/80 -mt-1 leading-tight">
                  NEW
                </span>
              </div>
              <div className="relative flex flex-col items-center -mt-1">
                <span className="text-[10px] sm:text-xs">⭐</span>
                <span className="px-1.5 py-0.2 rounded-full bg-gradient-to-r from-pink-500 to-rose-600 border border-white/80 text-[7px] sm:text-[8px] font-black text-white uppercase tracking-tighter shadow-lg shadow-pink-500/80 -mt-1 leading-tight">
                  NEW
                </span>
              </div>
            </div>

            {/* Glowing Circular Avatar Frame */}
            <div className="relative w-full h-full rounded-full p-[2.5px] bg-gradient-to-tr from-pink-500 via-purple-400 to-cyan-300 ring-2 ring-pink-300 shadow-[0_0_15px_rgba(236,72,153,0.75)]">
              <div className="w-full h-full rounded-full overflow-hidden bg-neutral-950">
                <img
                  src={bannerData.senderAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                  alt={bannerData.senderName || 'Sender'}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Bottom Crystal Ring Base */}
            <div className="absolute -bottom-1 w-10 sm:w-12 h-2 rounded-full bg-gradient-to-r from-pink-400 via-cyan-300 to-purple-400 opacity-90 blur-[1px]" />
          </div>
        </div>

        {/* ================= CENTER-LEFT: TRANSLUCENT BANNER + ANGEL WINGS + 3D DIAMOND + HEXAGON BADGE ================= */}
        <div className="relative z-20 flex-1 flex items-center -ml-2 sm:-ml-3 mr-1">
          
          {/* Translucent Cyan Ribbon Background Bar */}
          <div className="relative w-full flex items-center bg-gradient-to-r from-cyan-400/35 via-sky-500/30 to-transparent backdrop-blur-md rounded-2xl sm:rounded-3xl border-y border-l border-cyan-300/60 py-1 sm:py-1.5 pl-3 pr-2 shadow-[0_0_20px_rgba(34,211,238,0.35)]">
            
            {/* SENDER LABEL ("Send ...") */}
            <div className="hidden xs:flex flex-col text-[9px] sm:text-[10px] font-black text-cyan-100 font-sans tracking-wide drop-shadow pr-1 truncate max-w-[55px] sm:max-w-[70px]">
              <span className="opacity-90">Send</span>
              <span className="text-white font-extrabold truncate">{bannerData.senderName || 'VIP'}</span>
            </div>

            {/* CENTER 3D DIAMOND WITH SUNBURST RAYS & HEXAGON "35 TIMES" BADGE */}
            <div className="relative flex flex-col items-center justify-center mx-auto sm:mx-2 my-auto">
              
              {/* Radiant Sunburst God-Rays Behind Diamond */}
              <div className="absolute -top-4 w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-b from-yellow-300/50 via-amber-400/25 to-transparent rounded-full blur-sm pointer-events-none animate-pulse" />

              {/* Angel Wings Left & Right of Diamond */}
              <div className="absolute -top-2 flex items-center justify-between w-24 sm:w-28 pointer-events-none opacity-90">
                <span className="text-sm sm:text-base transform -scale-x-100 filter drop-shadow-[0_0_6px_rgba(255,255,255,0.9)]">🪽</span>
                <span className="text-sm sm:text-base filter drop-shadow-[0_0_6px_rgba(255,255,255,0.9)]">🪽</span>
              </div>

              {/* 3D Violet Diamond Gem */}
              <div className="relative z-20 -mb-2.5 filter drop-shadow-[0_0_12px_rgba(192,132,252,0.95)]">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg transform rotate-45 bg-gradient-to-tr from-purple-700 via-fuchsia-500 to-cyan-200 border border-white flex items-center justify-center shadow-lg">
                  <div className="w-5 h-5 sm:w-6 sm:h-6 rounded bg-gradient-to-br from-white/90 via-purple-300/60 to-purple-900/80 flex items-center justify-center">
                    <Sparkles className="w-3 h-3 text-white transform -rotate-45 animate-spin" />
                  </div>
                </div>
              </div>

              {/* Blue Hexagonal Badge with Glowing Yellow "35 TIMES" */}
              <div className="relative z-30 mt-1 px-3 sm:px-4 py-0.5 rounded-xl sm:rounded-2xl bg-gradient-to-b from-blue-600 via-indigo-700 to-blue-900 border-2 border-yellow-300 shadow-[0_0_18px_rgba(59,130,246,0.9)] flex flex-col items-center justify-center min-w-[72px] sm:min-w-[84px]">
                
                {/* 3D Yellow Multiplier Number (e.g. 35) */}
                <div className="flex items-center gap-0.5">
                  <span className="text-xs text-cyan-200 opacity-90">✦</span>
                  <span className="text-base sm:text-lg md:text-xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-yellow-400 to-amber-500 font-['Outfit'] tracking-tight drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] leading-none">
                    {bannerData.multiplierNumber}
                  </span>
                  <span className="text-xs text-cyan-200 opacity-90">✦</span>
                </div>

                {/* Subtitle "TIMES" in Bright Golden Font */}
                <span className="text-[8px] sm:text-[9px] font-black text-yellow-300 uppercase tracking-widest leading-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] -mt-0.5">
                  {bannerData.multiplierLabel || 'TIMES'}
                </span>
              </div>
            </div>

            {/* ================= CENTER GIFT: 3D COCONUT DRINK WITH PURPLE FLOWER & STRAW ================= */}
            <div className="relative z-30 flex items-center mx-1 sm:mx-2">
              <div className="relative w-9 h-9 sm:w-11 sm:h-11 flex items-center justify-center filter drop-shadow-[0_0_12px_rgba(34,197,94,0.7)] animate-bounce duration-1000">
                {/* Fresh Coconut Shell Visual */}
                <div className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-tr from-lime-600 via-emerald-500 to-green-300 border-2 border-lime-200 flex items-center justify-center shadow-inner overflow-hidden">
                  <div className="w-5 h-5 rounded-full bg-gradient-to-b from-amber-100 via-yellow-50 to-white/90 shadow-inner flex items-center justify-center">
                    {/* Straw */}
                    <div className="w-1 h-4 bg-amber-400 transform rotate-12 -mt-1 rounded-sm border border-amber-600" />
                  </div>
                </div>
                {/* Tropical Purple Flower on Coconut */}
                <span className="absolute -top-1.5 -left-1.5 text-xs sm:text-sm filter drop-shadow-[0_0_4px_rgba(217,70,239,0.9)]">
                  🌺
                </span>
              </div>
            </div>

            {/* ================= RECIPIENT AVATAR (in celestial frame) ================= */}
            {bannerData.recipientAvatar && (
              <div className="relative z-20 flex-shrink-0 flex items-center pr-1">
                <div className="relative w-9 h-9 sm:w-11 sm:h-11 rounded-full p-[2px] bg-gradient-to-tr from-purple-600 via-indigo-400 to-pink-500 ring-1 ring-purple-300 shadow-[0_0_10px_rgba(168,85,247,0.7)]">
                  <img
                    src={bannerData.recipientAvatar}
                    alt={bannerData.recipientName || 'Recipient'}
                    className="w-full h-full rounded-full object-cover"
                  />
                  <span className="absolute -top-1 -right-1 px-1 py-0.2 rounded-full bg-pink-600 border border-white text-[6px] font-black text-white uppercase">
                    NEW
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ================= RIGHT SECTION: MASSIVE 3D GOLDEN "x 424080" TYPOGRAPHY ================= */}
        <div className="relative z-30 flex-shrink-0 flex items-center pl-1 sm:pl-2 pr-1">
          <div className="relative flex items-center">
            
            {/* Golden Specular Ambient Glow */}
            <div className="absolute inset-0 bg-amber-400/30 blur-lg rounded-full pointer-events-none" />

            {/* Giant "x 424080" Combo Multiplier with 3D Extrusion */}
            <div className="relative flex items-center font-['Outfit'] font-black tracking-tight text-right">
              {/* 'x' prefix */}
              <span className="text-xl sm:text-2xl md:text-3xl text-yellow-400 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] mr-1 font-sans">
                x
              </span>

              {/* Combo Number (424080) */}
              <span className="text-2xl sm:text-3xl md:text-4xl lg:text-[40px] leading-none font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-100 via-yellow-400 to-amber-600 drop-shadow-[0_3px_6px_rgba(0,0,0,0.9)] filter drop-shadow-[0_0_15px_rgba(250,204,21,0.9)]">
                {bannerData.comboMultiplier}
              </span>
            </div>

            {/* Sparkling Star Particle on Right */}
            <span className="text-yellow-300 text-sm sm:text-base animate-ping ml-1">
              ✨
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
