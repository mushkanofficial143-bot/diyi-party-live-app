/**
 * DIYO LIVE - Exact Reference Video Gift & Combo Re-creation
 * Matches the uploaded video precisely:
 * - Top horizontal glowing notification pill with user avatar, name, gift artwork, combo, and coin winnings
 * - Center large 3D glowing milestone numbers (10, 20, 30, 50...) with blue/cyan 3D shading
 * - Bottom right "Combo long press" glowing action indicator
 */

import React, { useEffect } from 'react';
import { Crown, Coins, Heart } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface LuckyGift3DEffectProps {
  isOpen: boolean;
  onClose: () => void;
  giftName: string;
  giftIcon?: string;
  giftImage?: string;
  senderName?: string;
  senderAvatar?: string;
  quantity: number;
  multiplier?: number | string;
  rewardCoins?: number;
  isLuckyHit?: boolean;
}

export const LuckyGift3DEffect: React.FC<LuckyGift3DEffectProps> = ({
  isOpen,
  onClose,
  giftName,
  giftIcon = '🎁',
  giftImage,
  senderName = 'Ngawang Chonzey',
  senderAvatar,
  quantity,
  multiplier,
  rewardCoins,
  isLuckyHit = false
}) => {
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        onClose();
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const showMilestonePop = quantity >= 5 && quantity % 5 === 0;

  return (
    <div
      id="live-stream-gift-video-reference-overlay"
      className="absolute inset-0 z-[95] flex flex-col items-center justify-between pointer-events-none p-4 py-16 select-none overflow-hidden"
    >
      {/* 1. TOP HORIZONTAL NOTIFICATION BANNER (Matching Video Top Banner) */}
      <div className="relative z-25 w-full max-w-lg bg-gradient-to-r from-[#170c26]/95 via-[#2b1847]/98 to-[#170c26]/95 border-2 border-amber-400/90 rounded-2xl p-2.5 shadow-[0_15px_45px_rgba(0,0,0,0.9),0_0_30px_rgba(245,158,11,0.5)] flex items-center justify-between gap-3 animate-in slide-in-from-top-8 duration-300 pointer-events-auto">
        
        {/* Left: Crown, User Avatar & Name */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="relative">
            <div className="w-10 h-10 rounded-full border-2 border-amber-400 overflow-hidden bg-purple-950 shadow">
              {senderAvatar ? (
                <img src={senderAvatar} alt={senderName} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-tr from-amber-500 to-pink-600 text-white font-bold text-xs">
                  {senderName.charAt(0)}
                </div>
              )}
            </div>
            <div className="absolute -top-1 -right-1 text-[10px]">👑</div>
          </div>

          <div className="flex flex-col">
            <span className="text-xs font-black text-amber-200 tracking-tight max-w-[100px] truncate">
              {senderName}
            </span>
            <span className="text-[9px] text-amber-400/90 font-bold">
              {isLuckyHit ? 'Lucky Win 🎉' : 'Combo Active'}
            </span>
          </div>
        </div>

        {/* Center: Gift Icon & Combo xXX */}
        <div className="flex items-center gap-2 bg-black/50 px-3 py-1 rounded-xl border border-amber-400/40">
          <div className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-purple-700 to-indigo-900 border border-amber-300 flex items-center justify-center shadow">
            {giftImage ? (
              <img src={giftImage} alt={giftName} className="w-6 h-6 object-contain" />
            ) : (
              <span className="text-lg">{giftIcon}</span>
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] text-white/70 leading-none">Gift Combo</span>
            <span className="text-sm font-black text-amber-300 font-['Outfit']">
              ×{quantity}
            </span>
          </div>
        </div>

        {/* Right Side: Coin Rewards */}
        <div className="flex flex-col items-end shrink-0">
          <div className="flex items-center gap-1 text-xs sm:text-sm font-black text-amber-300 drop-shadow">
            <Coins className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            <span>+{rewardCoins ? rewardCoins.toLocaleString() : (quantity * 500).toLocaleString()}</span>
          </div>
          <span className="text-[10px] font-black text-cyan-300 bg-cyan-950/80 px-1.5 rounded border border-cyan-400/50">
            {multiplier ? `${multiplier}` : `×${quantity} times`}
          </span>
        </div>

      </div>

      {/* 2. CENTER LARGE 3D MILESTONE NUMBER POP (Matching Video Center 10, 20, 30, 50...) */}
      <div className="relative z-10 flex flex-col items-center justify-center my-auto pointer-events-none animate-pop-in-3d">
        {showMilestonePop ? (
          <div className="relative flex items-center justify-center">
            {/* Radial Blue/Cyan/Gold Glowing Backdrop */}
            <div className="absolute w-48 h-48 rounded-full bg-gradient-to-tr from-cyan-500/35 via-blue-600/35 to-amber-500/35 blur-3xl animate-ping" />
            
            {/* Large 3D Blue/Cyan Typography matching reference video */}
            <h1 className="text-8xl sm:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-b from-cyan-200 via-blue-400 to-indigo-600 drop-shadow-[0_15px_35px_rgba(0,0,0,0.95)] font-['Outfit'] tracking-tighter">
              {quantity}
            </h1>
          </div>
        ) : (
          <div className="relative flex items-center justify-center">
            <div className="absolute w-32 h-32 rounded-full bg-pink-500/20 blur-2xl animate-pulse" />
            <div className="flex items-center gap-2 text-2xl font-black text-pink-200 bg-black/70 px-5 py-2.5 rounded-full border border-pink-500/50 shadow-2xl backdrop-blur-md">
              <Heart className="w-6 h-6 text-pink-400 fill-pink-400 animate-bounce" />
              <span>{giftName} ×{quantity}</span>
            </div>
          </div>
        )}
      </div>

      {/* 3. BOTTOM RIGHT COMBO LONG PRESS INTERACTIVE BUTTON (Matching Video Reference) */}
      <div className="self-end relative z-25 pointer-events-auto mb-16 mr-2">
        <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-rose-600 via-pink-600 to-amber-500 border-4 border-amber-300 shadow-[0_10px_30px_rgba(244,63,94,0.6)] flex flex-col items-center justify-center text-white text-center cursor-pointer animate-pulse hover:scale-105 active:scale-95 transition-transform">
          <span className="text-[10px] font-black uppercase tracking-tighter leading-none">Combo</span>
          <span className="text-xs font-extrabold leading-tight">long press</span>
          <span className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-amber-400 text-neutral-950 font-black text-xs flex items-center justify-center border border-white shadow">
            ×{quantity}
          </span>
        </div>
      </div>

    </div>
  );
};




