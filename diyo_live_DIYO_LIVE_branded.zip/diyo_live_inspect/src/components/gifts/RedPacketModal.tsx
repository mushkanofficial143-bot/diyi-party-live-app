import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  ShieldCheck, 
  Send, 
  Users, 
  History, 
  Gift, 
  CheckCircle,
  Clock,
  ArrowRight
} from 'lucide-react';
import { RedPacketItem, RedPacketSettings, RedPacketClaim } from '../../types/ownerTypes';
import { DEFAULT_RED_PACKET_SETTINGS, INITIAL_RED_PACKETS } from '../../data/platformFeaturesData';

interface RedPacketModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId?: string;
  userName?: string;
  userAvatar?: string;
  userCoinBalance: number;
  config?: RedPacketSettings;
  redPackets?: RedPacketItem[];
  onDistributeSuccess?: (packet: RedPacketItem, newBalance: number) => void;
  onClaimSuccess?: (packetId: string, amount: number, newBalance: number) => void;
}

export const RedPacketModal: React.FC<RedPacketModalProps> = ({
  isOpen,
  onClose,
  userId = 'USR-882941',
  userName = 'Aarav Mehta',
  userAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
  userCoinBalance,
  config = DEFAULT_RED_PACKET_SETTINGS,
  redPackets = INITIAL_RED_PACKETS,
  onDistributeSuccess,
  onClaimSuccess
}) => {
  const [activeTab, setActiveTab] = useState<'SEND' | 'ACTIVE' | 'HISTORY'>('SEND');
  const [totalCoins, setTotalCoins] = useState<number>(50000);
  const [totalPackets, setTotalPackets] = useState<number>(5);
  const [message, setMessage] = useState<string>('🎉 Good luck & happy streaming! Enjoy free Test Coins!');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successPacket, setSuccessPacket] = useState<RedPacketItem | null>(null);

  // Claiming state
  const [claimingPacketId, setClaimingPacketId] = useState<string | null>(null);
  const [claimedResult, setClaimedResult] = useState<{ amount: number; packetId: string } | null>(null);

  if (!isOpen) return null;

  const handleCreateRedPacket = async () => {
    setErrorMsg(null);
    if (!config.enabled) {
      setErrorMsg('Red Packet feature is currently disabled by Platform Owner.');
      return;
    }
    if (totalCoins < (config.minAmountCoins ?? 1000)) {
      setErrorMsg(`Minimum Red Packet amount is ${(config.minAmountCoins ?? 1000).toLocaleString()} TEST COINS.`);
      return;
    }
    if (totalCoins > (config.maxAmountCoins ?? 5000000)) {
      setErrorMsg(`Maximum Red Packet amount is ${(config.maxAmountCoins ?? 5000000).toLocaleString()} TEST COINS.`);
      return;
    }
    if (userCoinBalance < totalCoins) {
      setErrorMsg(`Insufficient TEST COIN balance! You have ${(userCoinBalance ?? 0).toLocaleString()} TEST COINS.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/red-packet/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: userId,
          totalCoins,
          totalPackets,
          message
        })
      });
      const data = await res.json();
      if (data.success) {
        setSuccessPacket(data.redPacket);
        if (onDistributeSuccess) {
          onDistributeSuccess(data.redPacket, data.senderBalance);
        }
      } else {
        setErrorMsg(data.error || 'Failed to create Red Packet');
      }
    } catch (err: any) {
      // Local fallback simulation
      const newPacket: RedPacketItem = {
        id: `RP-${Date.now()}`,
        senderId: userId,
        senderName: userName,
        senderAvatar: userAvatar,
        totalCoins,
        totalPackets,
        remainingCoins: totalCoins,
        remainingPackets: totalPackets,
        message,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        expiresAt: new Date(Date.now() + 30 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isExpired: false,
        claims: [],
        status: 'ACTIVE',
        TEST_MODE: true
      };
      setSuccessPacket(newPacket);
      if (onDistributeSuccess) {
        onDistributeSuccess(newPacket, userCoinBalance - totalCoins);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClaimPacket = async (packet: RedPacketItem) => {
    setErrorMsg(null);
    setClaimingPacketId(packet.id);
    try {
      const res = await fetch('/api/red-packet/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          packetId: packet.id,
          userId,
          userName
        })
      });
      const data = await res.json();
      if (data.success) {
        setClaimedResult({
          amount: data.amountClaimed,
          packetId: packet.id
        });
        if (onClaimSuccess) {
          onClaimSuccess(packet.id, data.amountClaimed, data.userBalance);
        }
      } else {
        setErrorMsg(data.error || 'Failed to claim Red Packet');
      }
    } catch (err: any) {
      // Local fallback simulation
      const fallbackAmount = Math.max(500, Math.floor(packet.remainingCoins / Math.max(1, packet.remainingPackets)));
      setClaimedResult({
        amount: fallbackAmount,
        packetId: packet.id
      });
      if (onClaimSuccess) {
        onClaimSuccess(packet.id, fallbackAmount, userCoinBalance + fallbackAmount);
      }
    } finally {
      setClaimingPacketId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        id="red-packet-modal-container"
        className="relative w-full max-w-lg bg-neutral-900 border border-rose-600/30 rounded-2xl shadow-2xl overflow-hidden text-neutral-100 flex flex-col max-h-[90vh]"
      >
        {/* Header Banner */}
        <div className="relative px-6 py-4 bg-gradient-to-r from-rose-950 via-red-950 to-neutral-900 border-b border-rose-600/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600/20 border border-rose-500/40 flex items-center justify-center text-2xl shadow-inner shadow-rose-600/40">
              🧧
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-rose-200 tracking-wide">VIRTUAL RED PACKET</h3>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40">
                  TEST COINS
                </span>
              </div>
              <p className="text-xs text-neutral-400">Distribute lucky virtual coins to room members</p>
            </div>
          </div>
          <button 
            id="close-red-packet-modal-btn"
            onClick={onClose} 
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Compliance & Test Notice */}
        <div className="px-6 py-1.5 bg-rose-500/10 border-b border-rose-500/20 flex items-center justify-between text-[11px] text-rose-300">
          <span className="flex items-center gap-1.5 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
            TEST MODE — Virtual TEST COINS only. No real cash value.
          </span>
          <span className="font-mono text-neutral-400">
            Bal: <strong className="text-rose-300">{(userCoinBalance ?? 0).toLocaleString()}</strong> TC
          </span>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-neutral-800 bg-neutral-950/60 px-6 pt-2 gap-2">
          <button
            id="red-packet-tab-send"
            onClick={() => { setActiveTab('SEND'); setSuccessPacket(null); }}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'SEND'
                ? 'border-rose-500 text-rose-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Send Red Packet
          </button>
          <button
            id="red-packet-tab-active"
            onClick={() => setActiveTab('ACTIVE')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'ACTIVE'
                ? 'border-rose-500 text-rose-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Live Room Packets ({redPackets.filter(p => p.status === 'ACTIVE').length})
          </button>
          <button
            id="red-packet-tab-history"
            onClick={() => setActiveTab('HISTORY')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === 'HISTORY'
                ? 'border-rose-500 text-rose-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Packet History
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {errorMsg && (
            <div className="p-3 bg-red-950/50 border border-red-500/50 rounded-xl text-red-300 text-xs flex items-center justify-between">
              <span>{errorMsg}</span>
              <button onClick={() => setErrorMsg(null)} className="text-red-400 hover:text-red-200">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* TAB 1: SEND RED PACKET */}
          {activeTab === 'SEND' && (
            <>
              {successPacket ? (
                <div className="p-6 bg-gradient-to-b from-rose-950/40 to-neutral-900 border border-rose-500/40 rounded-2xl text-center space-y-4 animate-scale-up">
                  <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-600/20 border border-rose-500/50 flex items-center justify-center text-4xl shadow-lg shadow-rose-600/30">
                    🧧
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-rose-300">Red Packet Distributed!</h4>
                    <p className="text-xs text-neutral-300 mt-1">
                      Broadcasting to live room viewers for <strong className="text-rose-400">{successPacket.totalPackets} grabbers</strong>!
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs bg-neutral-950/80 p-3 rounded-xl border border-neutral-800">
                    <div className="text-neutral-400">Total Coins:</div>
                    <div className="text-right font-mono text-rose-300">{(successPacket.totalCoins ?? 0).toLocaleString()} TC</div>
                    <div className="text-neutral-400">Recipients:</div>
                    <div className="text-right font-mono text-white">{successPacket.totalPackets} Claimers</div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSuccessPacket(null)}
                      className="flex-1 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold transition-colors"
                    >
                      Send Another
                    </button>
                    <button
                      onClick={() => setActiveTab('ACTIVE')}
                      className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs transition-colors"
                    >
                      View Live Room
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* Preset Amount Selector */}
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                      Total TEST COIN Pool
                    </label>
                    <div className="grid grid-cols-4 gap-2 mb-2">
                      {[10000, 25000, 50000, 100000].map((amt) => (
                        <button
                          key={amt}
                          onClick={() => setTotalCoins(amt)}
                          className={`py-2 rounded-xl border text-xs font-bold transition-all ${
                            totalCoins === amt
                              ? 'bg-rose-600/30 border-rose-400 text-rose-200 shadow-md shadow-rose-600/20'
                              : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:bg-neutral-800'
                          }`}
                        >
                          {amt >= 1000 ? `${amt / 1000}K` : amt} TC
                        </button>
                      ))}
                    </div>
                    <input
                      type="number"
                      value={totalCoins}
                      onChange={(e) => setTotalCoins(Math.max(0, Number(e.target.value)))}
                      min={config.minAmountCoins}
                      max={config.maxAmountCoins}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-rose-500"
                    />
                  </div>

                  {/* Number of Receivers */}
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                      Number of Receivers (Packets)
                    </label>
                    <div className="grid grid-cols-4 gap-2 mb-2">
                      {[3, 5, 10, 20].map((n) => (
                        <button
                          key={n}
                          onClick={() => setTotalPackets(n)}
                          className={`py-2 rounded-xl border text-xs font-bold transition-all ${
                            totalPackets === n
                              ? 'bg-rose-600/30 border-rose-400 text-rose-200'
                              : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:bg-neutral-800'
                          }`}
                        >
                          {n} People
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Custom Message */}
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                      Greeting Message
                    </label>
                    <input
                      type="text"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Best wishes for everyone in the room!"
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-rose-500"
                    />
                  </div>

                  {/* Distribution Summary */}
                  <div className="p-4 bg-gradient-to-br from-neutral-950 to-neutral-900 border border-neutral-800 rounded-xl space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Total Deduction:</span>
                      <span className="font-mono font-bold text-white text-sm">{(totalCoins ?? 0).toLocaleString()} TEST COINS</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Estimated Average per Grab:</span>
                      <span className="font-mono text-rose-300 font-bold">~{(Math.round((totalCoins || 0) / (totalPackets || 1)) ?? 0).toLocaleString()} TC</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-neutral-500 pt-1 border-t border-neutral-800">
                      <span>Expires in 30 minutes if unclaimed</span>
                      <span>Random lucky allocation</span>
                    </div>
                  </div>

                  {/* Submit CTA */}
                  <button
                    id="submit-send-red-packet-btn"
                    disabled={isSubmitting || userCoinBalance < totalCoins}
                    onClick={handleCreateRedPacket}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-rose-600 via-red-500 to-rose-700 hover:from-rose-500 hover:to-red-600 text-white font-black text-sm uppercase tracking-wider shadow-lg shadow-rose-600/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <span className="animate-spin text-lg">⏳</span>
                    ) : (
                      <>
                        <span>Distribute Red Packet ({(totalCoins ?? 0).toLocaleString()} TC)</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </>
              )}
            </>
          )}

          {/* TAB 2: ACTIVE ROOM PACKETS */}
          {activeTab === 'ACTIVE' && (
            <div className="space-y-4">
              {claimedResult && (
                <div className="p-5 bg-gradient-to-b from-rose-950/60 to-neutral-900 border-2 border-rose-500 rounded-2xl text-center space-y-3 animate-scale-up">
                  <div className="text-4xl animate-bounce">🧧</div>
                  <h4 className="text-lg font-extrabold text-rose-300">Lucky Red Packet Claimed!</h4>
                  <p className="text-xs text-neutral-300">You grabbed:</p>
                  <div className="text-2xl font-black font-mono text-emerald-400 bg-black/60 py-2.5 px-4 rounded-xl border border-emerald-500/40 inline-block">
                    +{(claimedResult.amount ?? 0).toLocaleString()} TEST COINS
                  </div>
                  <p className="text-[11px] text-neutral-400">Directly added to your virtual wallet balance.</p>
                  <button
                    onClick={() => setClaimedResult(null)}
                    className="mt-2 py-2 px-6 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl transition-colors"
                  >
                    Great!
                  </button>
                </div>
              )}

              <div className="space-y-3">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  Active Red Packets in Live Room
                </h4>
                {redPackets.filter(p => p.status === 'ACTIVE').length === 0 ? (
                  <div className="p-8 text-center bg-neutral-950/50 rounded-xl border border-neutral-800 text-neutral-500 text-xs">
                    No active Red Packets right now. Be the first to send one!
                  </div>
                ) : (
                  redPackets
                    .filter(p => p.status === 'ACTIVE')
                    .map((packet) => {
                      const hasClaimed = packet.claims.some(c => c.userId === userId);
                      return (
                        <div
                          key={packet.id}
                          className="p-4 bg-gradient-to-br from-neutral-950 to-neutral-900 border border-rose-500/30 rounded-2xl space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-xl bg-rose-600/20 border border-rose-500/40 flex items-center justify-center text-2xl">
                                🧧
                              </div>
                              <div>
                                <h5 className="text-xs font-bold text-white">{packet.senderName}'s Red Packet</h5>
                                <p className="text-[11px] text-rose-300/80 italic mt-0.5">"{packet.message}"</p>
                              </div>
                            </div>

                            <button
                              id={`claim-red-packet-btn-${packet.id}`}
                              disabled={hasClaimed || packet.remainingPackets <= 0 || claimingPacketId === packet.id}
                              onClick={() => handleClaimPacket(packet)}
                              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                                hasClaimed
                                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
                                  : 'bg-gradient-to-r from-rose-600 to-red-500 hover:from-rose-500 hover:to-red-400 text-white shadow-rose-600/30'
                              }`}
                            >
                              {claimingPacketId === packet.id ? (
                                <span className="animate-spin">⏳</span>
                              ) : hasClaimed ? (
                                'Claimed'
                              ) : (
                                'Grab Packet'
                              )}
                            </button>
                          </div>

                          {/* Progress bar */}
                          <div className="space-y-1.5 pt-2 border-t border-neutral-800">
                            <div className="flex justify-between text-[11px] text-neutral-400">
                              <span>Remaining: <strong className="text-rose-300">{(packet.remainingCoins ?? 0).toLocaleString()} TC</strong></span>
                              <span>{packet.remainingPackets} of {packet.totalPackets} left</span>
                            </div>
                            <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-rose-500 rounded-full transition-all"
                                style={{ width: `${(packet.remainingPackets / packet.totalPackets) * 100}%` }}
                              />
                            </div>
                          </div>

                          {/* Claims list */}
                          {(packet.claims || []).length > 0 && (
                            <div className="pt-2 border-t border-neutral-800/60 space-y-1.5">
                              <span className="text-[10px] uppercase font-semibold text-neutral-500 tracking-wider">
                                Recent Grabbers ({(packet.claims || []).length})
                              </span>
                              <div className="flex flex-wrap gap-1.5">
                                {(packet.claims || []).map((claim) => (
                                  <span
                                    key={claim.id}
                                    className="px-2 py-0.5 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 flex items-center gap-1"
                                  >
                                    <span>{claim.userName}:</span>
                                    <strong className="text-emerald-400 font-mono">+{(claim.amountCoins ?? 0).toLocaleString()} TC</strong>
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })
                )}
              </div>
            </div>
          )}

          {/* TAB 3: HISTORY */}
          {activeTab === 'HISTORY' && (
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Red Packet Archive
              </h4>
              <div className="space-y-2">
                {(redPackets || []).map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-neutral-950/70 border border-neutral-800 rounded-xl space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-rose-300">{item.senderName}</span>
                        <span className="text-neutral-400 font-mono text-[11px]">({(item.totalCoins ?? 0).toLocaleString()} TC)</span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                            item.status === 'COMPLETED'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {item.status}
                        </span>
                      </div>
                      <span className="text-neutral-500 text-[10px]">{item.createdAt}</span>
                    </div>
                    <div className="text-[11px] text-neutral-400">
                      Total Grabbers: {(item.claims || []).length} / {item.totalPackets}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
