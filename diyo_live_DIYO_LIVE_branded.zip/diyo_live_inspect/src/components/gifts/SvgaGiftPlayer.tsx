import React, { useEffect, useState, useRef } from 'react';

export interface SvgaGiftPlayerProps {
  svgaUrl: string;
  onComplete?: () => void;
  width?: string | number;
  height?: string | number;
}

export const SvgaGiftPlayer: React.FC<SvgaGiftPlayerProps> = ({
  svgaUrl,
  onComplete,
  width = '100%',
  height = '100%'
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(true);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    setLoading(true);
    setIsPlaying(true);

    // Simulate SVGA loading & playback lifecycle matching the Flutter version
    const loadTimer = setTimeout(() => {
      setLoading(false);
      // 5 seconds playback duration
      timerRef.current = window.setTimeout(() => {
        setIsPlaying(false);
        if (onComplete) {
          onComplete();
        }
      }, 5000);
    }, 400);

    return () => {
      clearTimeout(loadTimer);
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [svgaUrl]);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-4 bg-emerald-950/40 rounded-xl animate-pulse">
        <div className="w-8 h-8 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="relative flex items-center justify-center overflow-hidden" style={{ width, height }}>
      {isPlaying ? (
        <div className="relative w-full h-full flex flex-col items-center justify-center animate-in zoom-in-95 duration-300">
          {/* Animated SVGA Gift / Effect Canvas simulation */}
          <div className="absolute inset-0 bg-gradient-to-t from-amber-500/20 via-emerald-500/10 to-transparent rounded-2xl animate-pulse" />
          <div className="relative z-10 flex flex-col items-center gap-2">
            <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-amber-500 to-emerald-400 flex items-center justify-center shadow-2xl shadow-amber-500/50 animate-bounce">
              <span className="text-4xl">🎁</span>
            </div>
            <span className="text-xs font-bold text-amber-300 tracking-wider bg-black/60 px-3 py-1 rounded-full border border-amber-500/40">
              SVGA Animation Playing...
            </span>
          </div>
        </div>
      ) : null}
    </div>
  );
};
