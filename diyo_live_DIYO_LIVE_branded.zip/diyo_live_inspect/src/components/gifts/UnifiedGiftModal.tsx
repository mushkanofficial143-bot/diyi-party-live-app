import React, { useState } from 'react';
import { 
  X, 
  Gift, 
  Sparkles, 
  ShieldCheck, 
  Send, 
  ChevronRight, 
  Coins,
  Crown,
  Flame,
  Star,
  Zap
} from 'lucide-react';
import { GiftItem, GiftCategory, LuckyBoxConfig, RedPacketSettings, LuckyBoxItem, RedPacketItem } from '../../types/ownerTypes';
import { DEFAULT_GIFTS_CATALOG, DEFAULT_LUCKY_BOX_CONFIG, DEFAULT_RED_PACKET_SETTINGS } from '../../data/platformFeaturesData';
import { LuckyBoxModal } from './LuckyBoxModal';
import { RedPacketModal } from './RedPacketModal';

interface UnifiedGiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  senderId?: string;
  senderName?: string;
  recipientId: string;
  recipientName: string;
  userCoinBalance: number;
  gifts?: GiftItem[];
  luckyBoxConfig?: LuckyBoxConfig;
  redPacketConfig?: RedPacketSettings;
  onSendGiftSuccess?: (gift: GiftItem, recipientId: string, count: number, newBalance: number) => void;
  onSendLuckyBoxSuccess?: (box: LuckyBoxItem, newBalance: number) => void;
  onDistributeRedPacketSuccess?: (packet: RedPacketItem, newBalance: number) => void;
}

export const UnifiedGiftModal: React.FC<UnifiedGiftModalProps> = ({
  isOpen,
  onClose,
  senderId = 'USR-882941',
  senderName = 'Aarav Mehta',
  recipientId,
  recipientName,
  userCoinBalance,
  gifts = DEFAULT_GIFTS_CATALOG,
  luckyBoxConfig = DEFAULT_LUCKY_BOX_CONFIG,
  redPacketConfig = DEFAULT_RED_PACKET_SETTINGS,
  onSendGiftSuccess,
  onSendLuckyBoxSuccess,
  onDistributeRedPacketSuccess
}) => {
  const [selectedCategory, setSelectedCategory] = useState<GiftCategory>('ALL');
  const [selectedGift, setSelectedGift] = useState<GiftItem | null>(null);
  const [giftCount, setGiftCount] = useState<number>(1);
  const [isSending, setIsSending] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastSentGift, setLastSentGift] = useState<GiftItem | null>(null);

  // Sub-modal triggers
  const [showLuckyBoxModal, setShowLuckyBoxModal] = useState<boolean>(false);
  const [showRedPacketModal, setShowRedPacketModal] = useState<boolean>(false);

  if (!isOpen) return null;

  const categories: GiftCategory[] = ['ALL', 'FLAGS', 'POPULAR', 'VIP', 'SPECIAL', 'LUCKY', 'RED PACKET'];

  const filteredGifts = (gifts || []).filter((gift) => {
    if (!gift.isActive && gift.isActive !== undefined) return false;
    if (selectedCategory === 'ALL') return true;
    return gift.category?.toUpperCase() === selectedCategory.toUpperCase();
  });

  const totalCost = selectedGift ? selectedGift.coinPrice * giftCount : 0;

  const handleSendGift = async () => {
    if (!selectedGift) return;
    setErrorMessage(null);

    // If it's a Lucky Box item and clicked send, route to Lucky Box modal
    if (selectedGift.isLuckyBox) {
      setShowLuckyBoxModal(true);
      return;
    }

    // If it's a Red Packet item and clicked send, route to Red Packet modal
    if (selectedGift.isRedPacket) {
      setShowRedPacketModal(true);
      return;
    }

    if (userCoinBalance < totalCost) {
      setErrorMessage(`Insufficient TEST COINS! Cost: ${(totalCost ?? 0).toLocaleString()} TC. Balance: ${(userCoinBalance ?? 0).toLocaleString()} TC.`);
      return;
    }

    setIsSending(true);
    try {
      const res = await fetch('/api/gifts/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId,
          receiverId: recipientId,
          giftId: selectedGift.id,
          count: giftCount
        })
      });

      const data = await res.json();
      if (data.success) {
        setLastSentGift(selectedGift);
        if (onSendGiftSuccess) {
          onSendGiftSuccess(selectedGift, recipientId, giftCount, data.senderBalance);
        }
      } else {
        // Fallback local execution
        setLastSentGift(selectedGift);
        if (onSendGiftSuccess) {
          onSendGiftSuccess(selectedGift, recipientId, giftCount, userCoinBalance - totalCost);
        }
      }
    } catch (err: any) {
      setLastSentGift(selectedGift);
      if (onSendGiftSuccess) {
        onSendGiftSuccess(selectedGift, recipientId, giftCount, userCoinBalance - totalCost);
      }
    } finally {
      setIsSending(false);
      setTimeout(() => setLastSentGift(null), 2500);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
        <div 
          id="unified-gift-modal-container"
          className="relative w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden text-neutral-100 flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="px-6 py-4 bg-gradient-to-r from-neutral-950 via-neutral-900 to-neutral-950 border-b border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-2xl">
                🎁
              </div>
              <div>
                <h3 className="text-base font-bold text-white tracking-wide">Send Virtual Gift</h3>
                <p className="text-xs text-neutral-400">
                  Recipient: <span className="text-amber-400 font-semibold">{recipientName}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full text-xs font-mono text-amber-300">
                <Coins className="w-3.5 h-3.5" />
                <span>{(userCoinBalance ?? 0).toLocaleString()} TEST COINS</span>
              </div>
              <button 
                id="close-unified-gift-modal-btn"
                onClick={onClose} 
                className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Test Notice Banner */}
          <div className="px-6 py-1.5 bg-neutral-950 border-b border-neutral-800/80 flex items-center justify-between text-[11px] text-amber-400">
            <span className="flex items-center gap-1.5 font-medium">
              <ShieldCheck className="w-3.5 h-3.5" />
              TEST MODE — Virtual TEST COINS only. No real currency.
            </span>
            <span className="sm:hidden font-mono">
              Bal: <strong>{(userCoinBalance ?? 0).toLocaleString()}</strong> TC
            </span>
          </div>

          {/* Category Filter Tabs (ALL, POPULAR, VIP, SPECIAL, LUCKY, RED PACKET) */}
          <div className="flex items-center overflow-x-auto scrollbar-none px-6 py-2.5 bg-neutral-950/60 border-b border-neutral-800 gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`gift-cat-btn-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => {
                  setSelectedCategory(cat);
                  setSelectedGift(null);
                }}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  selectedCategory === cat
                    ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                    : 'bg-neutral-900 text-neutral-400 hover:bg-neutral-800 hover:text-neutral-200 border border-neutral-800'
                }`}
              >
                {cat === 'POPULAR' && <Flame className="w-3 h-3 text-red-500" />}
                {cat === 'VIP' && <Crown className="w-3 h-3 text-yellow-400" />}
                {cat === 'SPECIAL' && <Sparkles className="w-3 h-3 text-purple-400" />}
                {cat === 'LUCKY' && <Zap className="w-3 h-3 text-amber-400" />}
                {cat === 'RED PACKET' && <span>🧧</span>}
                <span>{cat}</span>
              </button>
            ))}
          </div>

          {selectedCategory === 'RED PACKET' && (
            <div className="mx-6 mt-3 p-3 bg-gradient-to-r from-rose-950/60 to-red-950/40 border border-rose-500/40 rounded-2xl flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">🧧</span>
                <div>
                  <h4 className="text-xs font-bold text-rose-200">Virtual Red Packet Distributor</h4>
                  <p className="text-[11px] text-neutral-400">Rain down lucky test coins for multiple room members to grab simultaneously.</p>
                </div>
              </div>
              <button
                id="launch-red-packet-flow-btn"
                onClick={() => setShowRedPacketModal(true)}
                className="px-3.5 py-1.5 bg-gradient-to-r from-rose-600 to-red-500 text-white font-bold text-xs rounded-xl shadow hover:from-rose-500 hover:to-red-400 transition-all flex items-center gap-1 whitespace-nowrap"
              >
                <span>Distribute</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Gifts Grid */}
          <div className="p-6 overflow-y-auto flex-1 space-y-4">
            {errorMessage && (
              <div className="p-3 bg-red-950/50 border border-red-500/50 rounded-xl text-red-300 text-xs flex justify-between">
                <span>{errorMessage}</span>
                <button onClick={() => setErrorMessage(null)} className="text-red-400">✕</button>
              </div>
            )}

            {lastSentGift && (
              <div className="p-3 bg-emerald-950/50 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs text-center animate-scale-up">
                🎉 Successfully sent <strong>{lastSentGift.name}</strong> to {recipientName}!
              </div>
            )}

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
              {filteredGifts.map((gift) => {
                const isSelected = selectedGift?.id === gift.id;
                return (
                  <button
                    key={gift.id}
                    id={`gift-card-${gift.id}`}
                    onClick={() => {
                      setSelectedGift(gift);
                      if (gift.isLuckyBox) {
                        setShowLuckyBoxModal(true);
                      } else if (gift.isRedPacket) {
                        setShowRedPacketModal(true);
                      }
                    }}
                    className={`relative p-3 rounded-2xl border transition-all flex flex-col items-center justify-between text-center group ${
                      isSelected
                        ? 'bg-gradient-to-b from-amber-500/20 to-neutral-900 border-amber-400 shadow-lg shadow-amber-500/20 scale-[1.03]'
                        : 'bg-neutral-950/60 border-neutral-800/80 hover:border-neutral-700 hover:bg-neutral-900/90'
                    }`}
                  >
                    {/* Badge */}
                    {gift.isLucky && (
                      <span className="absolute top-1.5 left-1.5 text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {gift.luckyMultiplierMax ? `${gift.luckyMultiplierMax}X` : 'LUCKY'}
                      </span>
                    )}
                    {gift.category === 'VIP' && (
                      <span className="absolute top-1.5 left-1.5 text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-yellow-500/20 text-yellow-300 border border-yellow-500/30">
                        VIP
                      </span>
                    )}
                    {gift.isRedPacket && (
                      <span className="absolute top-1.5 left-1.5 text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        ROOM
                      </span>
                    )}

                    {/* Icon */}
                    <div className="text-3xl my-2 transform group-hover:scale-110 transition-transform">
                      {gift.icon}
                    </div>

                    {/* Info */}
                    <div className="w-full">
                      <div className="text-xs font-semibold text-neutral-200 truncate w-full">
                        {gift.name.replace(/^[^\s]+\s/, '')}
                      </div>
                      <div className="text-xs font-mono font-bold text-amber-300 mt-1">
                        {(gift.coinPrice ?? 0).toLocaleString()} TC
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Footer Controls & Send CTA */}
          <div className="px-6 py-4 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between gap-4">
            {/* Multiplier / Quantity */}
            <div className="flex items-center gap-1.5 bg-neutral-900 p-1 rounded-xl border border-neutral-800">
              {[1, 5, 10, 99].map((cnt) => (
                <button
                  key={cnt}
                  onClick={() => setGiftCount(cnt)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    giftCount === cnt
                      ? 'bg-amber-500 text-neutral-950'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  x{cnt}
                </button>
              ))}
            </div>

            {/* Send Button */}
            <button
              id="send-virtual-gift-submit-btn"
              disabled={!selectedGift || isSending || userCoinBalance < totalCost}
              onClick={handleSendGift}
              className="flex-1 py-3 px-5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isSending ? (
                <span className="animate-spin text-base">⏳</span>
              ) : selectedGift ? (
                <>
                  <span>
                    Send {selectedGift.isLuckyBox ? 'Lucky Box' : selectedGift.isRedPacket ? 'Red Packet' : selectedGift.name} ({(totalCost ?? 0).toLocaleString()} TC)
                  </span>
                  <Send className="w-3.5 h-3.5" />
                </>
              ) : (
                <span>Select a Gift</span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Lucky Box Modal Subflow */}
      {showLuckyBoxModal && (
        <LuckyBoxModal
          isOpen={showLuckyBoxModal}
          onClose={() => setShowLuckyBoxModal(false)}
          senderId={senderId}
          senderName={senderName}
          receiverId={recipientId}
          receiverName={recipientName}
          userCoinBalance={userCoinBalance}
          config={luckyBoxConfig}
          onSendSuccess={(box, newBalance) => {
            if (onSendLuckyBoxSuccess) onSendLuckyBoxSuccess(box, newBalance);
          }}
        />
      )}

      {/* Red Packet Modal Subflow */}
      {showRedPacketModal && (
        <RedPacketModal
          isOpen={showRedPacketModal}
          onClose={() => setShowRedPacketModal(false)}
          userId={senderId}
          userName={senderName}
          userCoinBalance={userCoinBalance}
          config={redPacketConfig}
          onDistributeSuccess={(packet, newBalance) => {
            if (onDistributeRedPacketSuccess) onDistributeRedPacketSuccess(packet, newBalance);
          }}
        />
      )}
    </>
  );
};
