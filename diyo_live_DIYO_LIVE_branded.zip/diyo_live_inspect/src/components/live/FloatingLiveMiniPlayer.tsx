import React from 'react';
import { Maximize2, X, Eye, Mic, MicOff, Video, VideoOff, Radio, Volume2 } from 'lucide-react';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';
import { HostTagBadge } from '../HostTagBadge';
import { playSoundFX } from '../../utils/audioSynth';

export interface MinimizedLiveSessionData {
  hostId: string;
  hostName: string;
  hostAvatar: string;
  hostTag?: string;
  avatarFrameId?: string;
  vipLevel?: number;
  viewerCount: number;
  diamondsEarned: number;
  duration: number;
  isMicOn: boolean;
  isCameraOn: boolean;
  isPkActive?: boolean;
  mediaStream?: MediaStream | null;
  roomType: 'video_live' | 'party_live';
}

interface FloatingLiveMiniPlayerProps {
  session: MinimizedLiveSessionData;
  onExpand: () => void;
  onClose: () => void;
  onToggleMic?: () => void;
}

export const FloatingLiveMiniPlayer: React.FC<FloatingLiveMiniPlayerProps> = ({
  session,
  onExpand,
  onClose,
  onToggleMic
}) => {
  const videoRef = React.useRef<HTMLVideoElement | null>(null);

  React.useEffect(() => {
    if (videoRef.current && session.mediaStream && session.isCameraOn) {
      videoRef.current.srcObject = session.mediaStream;
    }
  }, [session.mediaStream, session.isCameraOn]);

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div
      id="floating-live-mini-player"
      style={{
        bottom: 'calc(max(env(safe-area-inset-bottom, 0px), 16px) + 78px)'
      }}
      className="fixed right-3 sm:right-4 z-50 w-44 sm:w-52 bg-neutral-950/95 border border-rose-500/50 rounded-2xl overflow-hidden shadow-2xl shadow-rose-950/60 backdrop-blur-xl animate-in slide-in-from-bottom-4 transition-all duration-300 select-none group"
    >
      {/* Video or Avatar Canvas */}
      <div 
        onClick={() => {
          playSoundFX('click');
          onExpand();
        }}
        className="relative h-28 sm:h-32 w-full bg-neutral-900 overflow-hidden cursor-pointer flex items-center justify-center"
      >
        {session.isCameraOn && session.mediaStream ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="flex flex-col items-center justify-center p-2 text-center">
            <HostAvatarWithFrame
              avatarUrl={session.hostAvatar}
              frameId={session.avatarFrameId || 'FRM-HOST-CELEBRATE'}
              hostTag={session.hostTag as any || 'CELEBRATE'}
              size="sm"
              vipLevel={session.vipLevel || 8}
            />
            <span className="text-[10px] text-neutral-300 font-bold mt-1 truncate max-w-[120px]">
              {session.hostName}
            </span>
          </div>
        )}

        {/* Live Badge & Viewers */}
        <div className="absolute top-2 left-2 flex items-center gap-1 z-10">
          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-rose-600/90 text-[9px] font-black text-white shadow-sm font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
            <span>LIVE</span>
          </div>
          <div className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-black/70 text-[9px] font-bold text-white font-mono">
            <Eye className="w-2.5 h-2.5 text-emerald-400" />
            <span>{session.viewerCount.toLocaleString()}</span>
          </div>
        </div>

        {/* Duration Timer */}
        <div className="absolute bottom-2 left-2 px-1.5 py-0.5 rounded bg-black/75 text-[9px] font-mono text-amber-300 font-bold">
          ⏱️ {formatTimer(session.duration)}
        </div>

        {/* Hover Overlay with Tap to Expand prompt */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
          <div className="flex items-center gap-1 bg-black/80 px-2 py-1 rounded-full text-[10px] font-bold">
            <Maximize2 className="w-3 h-3 text-rose-400" />
            <span>Tap to Expand</span>
          </div>
        </div>
      </div>

      {/* Mini Controls Bar */}
      <div className="px-2.5 py-2 bg-neutral-900/90 flex items-center justify-between gap-1 text-xs border-t border-white/10">
        <div className="flex items-center gap-1 min-w-0">
          <span className="text-[11px] font-black text-white truncate max-w-[80px]">
            {session.hostName}
          </span>
          {session.hostTag && <HostTagBadge tag={session.hostTag as any} size="xs" />}
        </div>

        <div className="flex items-center gap-1">
          {onToggleMic && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                playSoundFX('click');
                onToggleMic();
              }}
              className={`p-1 rounded-full text-white transition-colors ${
                session.isMicOn ? 'bg-emerald-500/30 text-emerald-300' : 'bg-rose-500/30 text-rose-300'
              }`}
              title={session.isMicOn ? 'Mic is Active' : 'Mic is Muted'}
            >
              {session.isMicOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
            </button>
          )}

          <button
            onClick={(e) => {
              e.stopPropagation();
              playSoundFX('click');
              onExpand();
            }}
            className="p-1 rounded-full bg-neutral-800 hover:bg-neutral-700 text-white transition-colors"
            title="Expand Full Screen"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              playSoundFX('click');
              onClose();
            }}
            className="p-1 rounded-full bg-rose-600/30 hover:bg-rose-600 text-rose-300 hover:text-white transition-colors"
            title="Close / End Live"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
