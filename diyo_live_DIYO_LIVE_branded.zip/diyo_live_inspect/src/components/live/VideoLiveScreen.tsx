import React, { useState, useRef, useEffect } from 'react';
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  Play,
  Square,
  Sparkles,
  Eye,
  Gift,
  Send,
  Swords,
  Heart,
  Share2,
  Settings,
  Volume2,
  Users,
  Crown,
  Zap,
  Flame,
  X,
  Smile,
  RefreshCw,
  Sliders,
  MessageSquare,
  ShieldCheck,
  Radio,
  Trophy,
  Star,
  Minimize2,
  AlertTriangle,
  Wifi,
  WifiOff,
  HelpCircle,
  Camera,
  RotateCw,
  Gamepad2,
  MoreHorizontal,
  Power
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';
import { GiftItem, HostTagType } from '../../types/ownerTypes';
import { BottomGiftSheet } from '../gifts/BottomGiftSheet';
import { HostTagBadge } from '../HostTagBadge';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';
import { VipBadge } from '../badges/VipBadge';
import { androidLiveStreamService } from '../../services/androidLiveStreamService';
import { MinimizedLiveSessionData } from './FloatingLiveMiniPlayer';

interface FloatingHeart {
  id: number;
  x: number;
  color: string;
  size: number;
}

interface VideoLiveScreenProps {
  currentUser?: {
    id: string;
    name: string;
    avatar: string;
    coinBalance?: number;
    diamondBalance?: number;
    vipLevel?: number;
    level?: number;
    hostTag?: HostTagType | string;
    avatarFrameUrl?: string;
    avatarFrameId?: string;
    role?: string;
  };
  onClose?: () => void;
  onOpenPartyLive?: () => void;
  onUpdateUserBalance?: (newCoins: number, newDiamonds: number) => void;
  onMinimizeLive?: (session: MinimizedLiveSessionData) => void;
  initialStream?: MediaStream | null;
}

export const VideoLiveScreen: React.FC<VideoLiveScreenProps> = ({
  currentUser = {
    id: 'HST-901',
    name: 'Aarav Mehta',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    coinBalance: 245000,
    diamondBalance: 18500,
    vipLevel: 8,
    level: 42,
    hostTag: 'CELEBRATE',
    avatarFrameId: 'FRM-HOST-CELEBRATE',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150',
    role: 'HOST'
  },
  onClose,
  onOpenPartyLive,
  onUpdateUserBalance,
  onMinimizeLive,
  initialStream
}) => {
  // Broadcaster Media State
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(initialStream || null);
  const [isLive, setIsLive] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [activeFilter, setActiveFilter] = useState<'normal' | 'beauty' | 'warm' | 'cyber' | 'glow'>('beauty');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isSwitchingCamera, setIsSwitchingCamera] = useState(false);

  // Android Permission & Error Diagnostics State
  const [permissionStatus, setPermissionStatus] = useState<'checking' | 'granted' | 'denied' | 'error'>('checking');
  const [permissionErrorMessage, setPermissionErrorMessage] = useState<string | null>(null);
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [isVoiceOnlyMode, setIsVoiceOnlyMode] = useState(false);

  // Reconnection & Network State
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [reconnectCountdown, setReconnectCountdown] = useState(30);
  const [isOffline, setIsOffline] = useState(false);
  const [reconnectFailed, setReconnectFailed] = useState(false);

  // End Live Confirmation & Session Summary
  const [showEndLiveConfirm, setShowEndLiveConfirm] = useState(false);
  const [showSessionSummary, setShowSessionSummary] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showShareToast, setShowShareToast] = useState(false);
  const [videoQuality, setVideoQuality] = useState<'480p' | '720p' | '1080p'>('720p');
  const [finalSessionStats, setFinalSessionStats] = useState<{
    duration: number;
    diamonds: number;
    viewers: number;
    likes: number;
  } | null>(null);

  // Stats & Tickers
  const [liveDuration, setLiveDuration] = useState(148);
  const [viewerCount, setViewerCount] = useState(1842);
  const [diamondsEarned, setDiamondsEarned] = useState(128500);
  const [likeCount, setLikeCount] = useState(4820);
  const [isFollowing, setIsFollowing] = useState(false);
  const [audioLevel, setAudioLevel] = useState(42);

  // PK Battle State
  const [isPkBattleActive, setIsPkBattleActive] = useState(false);
  const [pkTimeLeft, setPkTimeLeft] = useState(180);
  const [myPkScore, setMyPkScore] = useState(16500);
  const [opponentPkScore, setOpponentPkScore] = useState(14200);
  const [opponentInfo] = useState({
    name: 'Riya Sharma',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    vip: 7,
    diamonds: 94000
  });

  // Gift & Games Modals
  const [showGiftSheet, setShowGiftSheet] = useState(false);
  const [activeBanner, setActiveBanner] = useState<{ text: string; icon: string } | null>(null);

  // Floating Hearts
  const [hearts, setHearts] = useState<FloatingHeart[]>([]);

  // Chat comments
  const [chatMessages, setChatMessages] = useState<Array<{
    id: string;
    sender: string;
    avatar?: string;
    text: string;
    vip?: number;
    level?: number;
    isGift?: boolean;
    giftIcon?: string;
    isSystem?: boolean;
  }>>([
    {
      id: 'sys-1',
      sender: 'DIYO LIVE Official',
      text: '🌟 Welcome to DIYO LIVE Room! Tap heart to show love & send virtual gifts!',
      isSystem: true
    },
    {
      id: 'msg-1',
      sender: 'Vikram Rajput',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100',
      text: 'Namaste Aarav bhai! Looking sharp with that Celebrate Frame! 🔥',
      vip: 8,
      level: 45
    },
    {
      id: 'msg-2',
      sender: 'Pooja Verma',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
      text: 'Love the stream quality! Sending you some love ❤️✨',
      vip: 5,
      level: 28
    },
    {
      id: 'msg-3',
      sender: 'Kabir Khan',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100',
      text: 'PK Battle match karo na kisi ke sath! ⚔️',
      vip: 6,
      level: 33
    }
  ]);
  const [chatInput, setChatInput] = useState('');

  const videoRef = useRef<HTMLVideoElement>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const cleanupAudioMeterRef = useRef<(() => void) | null>(null);

  // --------------------------------------------------------------------------
  // INITIALIZE HARDWARE CAMERA & MICROPHONE VIA ANDROID SERVICE
  // --------------------------------------------------------------------------
  const initializeMediaStream = async (targetFacing: 'user' | 'environment' = 'user') => {
    setPermissionStatus('checking');
    setPermissionErrorMessage(null);

    if (cameraStream) {
      if (videoRef.current) {
        videoRef.current.srcObject = cameraStream;
      }
      setPermissionStatus('granted');
      setupAudioVisualizer(cameraStream);
      return;
    }

    const res = await androidLiveStreamService.startLiveStream(targetFacing);

    if (res.success && res.stream) {
      setCameraStream(res.stream);
      setPermissionStatus('granted');
      setShowPermissionModal(false);
      setIsVoiceOnlyMode(Boolean(res.isAudioOnly));

      if (videoRef.current) {
        videoRef.current.srcObject = res.stream;
      }
      setupAudioVisualizer(res.stream);
    } else {
      setPermissionStatus('denied');
      setPermissionErrorMessage(
        res.errorMessage || 'Camera or Microphone permission was denied. Please allow access in Android Settings.'
      );
      setShowPermissionModal(true);
    }
  };

  const handleQualityChange = async (quality: '480p' | '720p' | '1080p') => {
    setVideoQuality(quality);
    await androidLiveStreamService.setVideoQuality(quality);
    setShowMoreMenu(false);
    playSoundFX('click');
    setActiveBanner({ text: `Stream Quality switched to ${quality}`, icon: '⚡' });
    setTimeout(() => setActiveBanner(null), 2500);
  };

  const setupAudioVisualizer = (stream: MediaStream) => {
    if (cleanupAudioMeterRef.current) {
      cleanupAudioMeterRef.current();
    }
    cleanupAudioMeterRef.current = androidLiveStreamService.getAudioLevelMeter((level) => {
      setAudioLevel(level);
    });
  };

  useEffect(() => {
    initializeMediaStream(facingMode);

    // Network handover and offline listeners
    const unbindNetwork = androidLiveStreamService.onNetworkChange((isOnline) => {
      if (!isOnline) {
        setIsOffline(true);
        setIsReconnecting(true);
        setReconnectCountdown(30);
      } else {
        setIsOffline(false);
        setIsReconnecting(false);
        setReconnectFailed(false);
        setActiveBanner({ text: 'Stream Reconnected Successfully!', icon: '✅' });
        setTimeout(() => setActiveBanner(null), 3000);
      }
    });

    // Android App backgrounding / visibility change
    const unbindVisibility = androidLiveStreamService.onVisibilityChange((isVisible) => {
      if (isVisible && videoRef.current && cameraStream && isCameraOn) {
        videoRef.current.play().catch(() => {});
      }
    });

    return () => {
      unbindNetwork();
      unbindVisibility();
      if (cleanupAudioMeterRef.current) {
        cleanupAudioMeterRef.current();
      }
    };
  }, []);

  // Reconnection Countdown Timer
  useEffect(() => {
    let timer: any = null;
    if (isReconnecting && !reconnectFailed) {
      timer = setInterval(() => {
        setReconnectCountdown((prev) => {
          if (prev <= 1) {
            setReconnectFailed(true);
            setIsReconnecting(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isReconnecting, reconnectFailed]);

  // Duration & Viewer Fluctuations
  useEffect(() => {
    let interval: any = null;
    if (isLive && !isReconnecting && !showSessionSummary) {
      interval = setInterval(() => {
        setLiveDuration((prev) => prev + 1);
        setViewerCount((prev) => Math.max(200, prev + Math.floor(Math.random() * 9) - 4));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isLive, isReconnecting, showSessionSummary]);

  // PK Timer
  useEffect(() => {
    let pkInterval: any = null;
    if (isPkBattleActive) {
      pkInterval = setInterval(() => {
        setPkTimeLeft((prev) => {
          if (prev <= 1) {
            setIsPkBattleActive(false);
            playSoundFX('win');
            confetti({ particleCount: 100, spread: 80 });
            return 180;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (pkInterval) clearInterval(pkInterval);
    };
  }, [isPkBattleActive]);

  // Auto-scroll chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages]);

  // --------------------------------------------------------------------------
  // LIVE ROOM HARDWARE CONTROLS
  // --------------------------------------------------------------------------
  const toggleCamera = () => {
    const nextState = androidLiveStreamService.toggleCamera();
    setIsCameraOn(nextState);
    playSoundFX('click');
  };

  const toggleMic = () => {
    const nextState = androidLiveStreamService.toggleMicrophone();
    setIsMicOn(nextState);
    playSoundFX('click');
  };

  const flipCamera = async () => {
    setIsSwitchingCamera(true);
    playSoundFX('click');
    const result = await androidLiveStreamService.switchCamera();
    setFacingMode(result.facing);
    if (result.success && result.stream) {
      setCameraStream(result.stream);
      if (videoRef.current) {
        videoRef.current.srcObject = result.stream;
      }
      setupAudioVisualizer(result.stream);
    }
    setIsSwitchingCamera(false);
  };

  const handleRefreshStream = async () => {
    playSoundFX('click');
    setActiveBanner({ text: 'Refreshing stream connection...', icon: '🔄' });
    await initializeMediaStream(facingMode);
    setTimeout(() => {
      setActiveBanner({ text: 'Stream refreshed & stabilized!', icon: '✨' });
      setTimeout(() => setActiveBanner(null), 2500);
    }, 800);
  };

  const cycleFilter = () => {
    const filters: Array<'normal' | 'beauty' | 'warm' | 'cyber' | 'glow'> = ['beauty', 'warm', 'cyber', 'glow', 'normal'];
    const currentIndex = filters.indexOf(activeFilter);
    const nextFilter = filters[(currentIndex + 1) % filters.length];
    setActiveFilter(nextFilter);
    playSoundFX('magic');
  };

  // --------------------------------------------------------------------------
  // MINIMIZE LIVE ROOM (FLOATING PIP PLAYER - DOES NOT END STREAM)
  // --------------------------------------------------------------------------
  const handleMinimizeLive = () => {
    playSoundFX('click');
    if (onMinimizeLive) {
      onMinimizeLive({
        hostId: currentUser.id,
        hostName: currentUser.name,
        hostAvatar: currentUser.avatar,
        hostTag: currentUser.hostTag,
        avatarFrameId: currentUser.avatarFrameId,
        vipLevel: currentUser.vipLevel,
        viewerCount,
        diamondsEarned,
        duration: liveDuration,
        isMicOn,
        isCameraOn,
        isPkActive: isPkBattleActive,
        mediaStream: cameraStream,
        roomType: 'video_live'
      });
    } else if (onClose) {
      onClose();
    }
  };

  // --------------------------------------------------------------------------
  // END LIVE FLOW WITH CONFIRMATION & SESSION SUMMARY (HOST ONLY)
  // --------------------------------------------------------------------------
  const handleRequestEndLive = () => {
    playSoundFX('click');
    setShowEndLiveConfirm(true);
  };

  const handleConfirmEndLive = () => {
    setShowEndLiveConfirm(false);
    setIsLive(false);

    // Save final stats
    const stats = {
      duration: liveDuration,
      diamonds: diamondsEarned,
      viewers: viewerCount,
      likes: likeCount
    };
    setFinalSessionStats(stats);
    setShowSessionSummary(true);

    // Stop all media tracks & release hardware
    androidLiveStreamService.stopCurrentStream(true);
    setCameraStream(null);
    playSoundFX('win');
  };

  const handleCloseSessionSummary = () => {
    setShowSessionSummary(false);
    if (onClose) {
      onClose();
    }
  };

  const triggerFloatingHeart = () => {
    const heartColors = ['#f43f5e', '#ec4899', '#a855f7', '#06b6d4', '#eab308', '#10b981'];
    const color = heartColors[Math.floor(Math.random() * heartColors.length)];
    const newHeart: FloatingHeart = {
      id: Date.now() + Math.random(),
      x: Math.floor(Math.random() * 60) - 30,
      color,
      size: Math.floor(Math.random() * 12) + 22
    };

    setHearts((prev) => [...prev.slice(-15), newHeart]);
    setLikeCount((prev) => prev + 1);
    playSoundFX('reaction');

    setTimeout(() => {
      setHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 1800);
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim()) return;

    setChatMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        sender: currentUser.name,
        avatar: currentUser.avatar,
        text: chatInput.trim(),
        vip: currentUser.vipLevel || 8,
        level: currentUser.level || 42
      }
    ]);
    setChatInput('');
    playSoundFX('click');
  };

  const formatTimer = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}:${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Determine if user is broadcaster host
  const isHost = !currentUser.role || currentUser.role === 'HOST' || currentUser.role === 'OWNER' || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN';

  return (
    <div
      id="video-live-screen-container"
      className="fixed inset-0 z-40 bg-neutral-950 text-white flex flex-col justify-between overflow-hidden select-none font-['Outfit']"
    >
      {/* ========================================================================= */}
      {/* 1. BACKGROUND VIDEO FEED / STREAM CANVAS (EDGE-TO-EDGE FULL SCREEN)        */}
      {/* ========================================================================= */}
      <div
        className="absolute inset-0 w-full h-full overflow-hidden cursor-pointer"
        onDoubleClick={triggerFloatingHeart}
      >
        {/* Real Live Stream Video Element - occupies full screen without play buttons */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`w-full h-full object-cover scale-x-[-1] transition-all duration-300 ${
            !isCameraOn || isVoiceOnlyMode ? 'hidden' : ''
          } ${
            activeFilter === 'beauty'
              ? 'brightness-110 contrast-105 saturate-110'
              : activeFilter === 'warm'
              ? 'sepia-[0.25] saturate-125 brightness-105'
              : activeFilter === 'cyber'
              ? 'hue-rotate-30 saturate-150'
              : activeFilter === 'glow'
              ? 'brightness-120 drop-shadow-[0_0_15px_rgba(236,72,153,0.3)]'
              : ''
          }`}
        />

        {/* Clean Voice Stream Backdrop if Camera is Off */}
        {(!isCameraOn || isVoiceOnlyMode) && (
          <div className="absolute inset-0 w-full h-full bg-gradient-to-b from-[#090b1a] via-[#0d102b] to-[#060710] flex flex-col items-center justify-center">
            <div className="relative mb-6">
              <div className="absolute -inset-8 bg-gradient-to-tr from-purple-600/30 via-indigo-600/30 to-amber-500/20 rounded-full blur-2xl animate-pulse" />
              <HostAvatarWithFrame
                avatarUrl={currentUser.avatar}
                frameId={currentUser.avatarFrameId || 'FRM-HOST-CELEBRATE'}
                hostTag={currentUser.hostTag || 'CELEBRATE'}
                size="2xl"
                vipLevel={currentUser.vipLevel || 8}
                isOnline={true}
              />
            </div>
            <div className="text-center px-4 space-y-1.5 z-10">
              <h2 className="text-xl font-black text-white font-['Outfit'] tracking-wide">
                {currentUser.name}
              </h2>
              <div className="flex items-center justify-center gap-1.5 text-xs text-amber-300/90 font-mono">
                <span className="text-neutral-400">ID:</span>
                <span className="font-bold">{currentUser.id}</span>
              </div>
              <p className="text-xs text-neutral-400 flex items-center justify-center gap-1.5 pt-1">
                <VideoOff className="w-3.5 h-3.5 text-rose-400" />
                <span>Camera is currently off • High Fidelity Voice Stream Active</span>
              </p>
            </div>
          </div>
        )}

        {/* Cinematic Vignette & Gradient Overlays for high readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black/90 pointer-events-none" />
      </div>

      {/* ========================================================================= */}
      {/* 2. RECONNECTION & NETWORK HANDOVER BANNER                                  */}
      {/* ========================================================================= */}
      {isReconnecting && (
        <div className="relative z-50 bg-amber-500 text-neutral-950 px-4 py-2 text-xs font-black flex items-center justify-between shadow-2xl animate-pulse">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4" />
            <span>Reconnecting stream... Please wait ({reconnectCountdown}s)</span>
          </div>
          <button
            onClick={() => initializeMediaStream(facingMode)}
            className="px-2.5 py-1 bg-black text-white text-[10px] rounded-lg font-bold"
          >
            Retry Now
          </button>
        </div>
      )}

      {reconnectFailed && (
        <div className="relative z-50 bg-rose-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-between shadow-2xl">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            <span>Connection lost. Please check your network.</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setReconnectFailed(false);
                setIsReconnecting(true);
                setReconnectCountdown(30);
                initializeMediaStream(facingMode);
              }}
              className="px-2.5 py-1 bg-white text-rose-600 text-[10px] rounded-lg font-black"
            >
              Reconnect
            </button>
            <button
              onClick={handleRequestEndLive}
              className="px-2.5 py-1 bg-black/40 hover:bg-black/60 text-white text-[10px] rounded-lg font-bold"
            >
              End Live
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. TOP BAR: Host Avatar, Name, ID, VIP, Level, Follow, Viewers, MINIMIZE, END LIVE */}
      {/* ========================================================================= */}
      <header className="relative z-30 pt-safe-top pt-2.5 px-3 flex items-center justify-between gap-2 pointer-events-none">
        
        {/* Left: Complete Host Profile Pill with Avatar, Name, ID, VIP Badge, Level Badge & Follow */}
        <div className="flex items-center gap-1.5 pointer-events-auto bg-[#0d1127]/85 backdrop-blur-xl rounded-full pl-0.5 pr-2 py-0.5 border border-purple-500/30 shadow-[0_4px_20px_rgba(0,0,0,0.6)] ring-1 ring-white/10 scale-90 sm:scale-95 origin-top-left">
          {/* Host Avatar with Frame */}
          <div className="relative shrink-0 scale-90">
            <HostAvatarWithFrame
              avatarUrl={currentUser.avatar}
              frameId={currentUser.avatarFrameId || 'FRM-HOST-CELEBRATE'}
              hostTag={currentUser.hostTag || 'CELEBRATE'}
              size="xs"
              vipLevel={currentUser.vipLevel || 8}
            />
          </div>

          {/* Host Info: Name, ID, Level Badge, VIP Badge */}
          <div className="flex flex-col min-w-0 pr-0.5">
            <div className="flex items-center gap-1">
              <span className="text-[10px] font-black text-white truncate max-w-[70px] sm:max-w-[100px] drop-shadow-sm">
                {currentUser.name}
              </span>
              {/* VIP Badge */}
              <VipBadge level={currentUser.vipLevel || 8} size="xs" />
              {/* Level Badge */}
              <span className="text-[7.5px] font-black px-1 py-0.1 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 font-mono shadow-sm">
                Lv.{currentUser.level || 42}
              </span>
            </div>
            
            <div className="flex items-center gap-1.5 text-[8.5px]">
              <span className="text-neutral-400 font-mono">
                ID: <span className="text-cyan-300 font-semibold">{currentUser.id}</span>
              </span>
              <span className="text-amber-300 font-mono font-bold flex items-center gap-0.5">
                💎 {(diamondsEarned ?? 0).toLocaleString()}
              </span>
            </div>
          </div>

          {/* Follow Button */}
          <button
            onClick={() => {
              setIsFollowing(!isFollowing);
              playSoundFX('click');
            }}
            className={`shrink-0 px-2 py-0.5 rounded-full text-[9px] font-black uppercase transition-all active:scale-95 shadow-md ${
              isFollowing
                ? 'bg-neutral-800/90 text-neutral-300 border border-neutral-700'
                : 'bg-gradient-to-r from-rose-500 via-pink-500 to-purple-600 text-white shadow-rose-950/60 ring-1 ring-white/20 hover:brightness-110'
            }`}
          >
            {isFollowing ? '✓' : '+ Follow'}
          </button>
        </div>

        {/* Right Header Area: Viewer Count, Live Badge, MINIMIZE, INSTANT CLOSE (X) */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          
          {/* Viewer Count Pill */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#0d1127]/85 backdrop-blur-xl border border-white/15 text-xs font-bold text-white shadow-[0_4px_15px_rgba(0,0,0,0.5)] ring-1 ring-white/5">
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-mono text-[11px] font-black text-cyan-200">{(viewerCount ?? 0).toLocaleString()}</span>
          </div>

          {/* Live Timer Pill */}
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-rose-600/90 backdrop-blur-md text-white text-[9.5px] font-mono font-bold shadow-md shadow-rose-950/50">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
            <span>{formatTimer(liveDuration)}</span>
          </div>

          {/* MINIMIZE Button - Keeps stream alive, launches floating PIP */}
          <button
            id="btn-minimize-video-live"
            onClick={handleMinimizeLive}
            className="p-1.5 rounded-full bg-[#0e1630]/90 hover:bg-[#131d40] backdrop-blur-xl border border-cyan-500/40 text-cyan-300 shadow-lg shadow-cyan-950/30 transition-all active:scale-95"
            title="Minimize Live Room"
          >
            <Minimize2 className="w-3.5 h-3.5 text-cyan-400" />
          </button>

          {/* INSTANT CLOSE / EXIT (X) BUTTON - Clear, compact, and prominent */}
          <button
            id="btn-close-video-live"
            onClick={() => {
              playSoundFX('click');
              if (onClose) onClose();
              else handleRequestEndLive();
            }}
            className="w-7 h-7 rounded-full bg-rose-600 hover:bg-rose-500 backdrop-blur-xl border border-rose-400 flex items-center justify-center text-white shadow-lg shadow-rose-950/60 transition-all active:scale-95"
            title="Close Live Stream"
          >
            <X className="w-4 h-4 stroke-[3]" />
          </button>

        </div>

      </header>

      {/* ========================================================================= */}
      {/* 4. FLOATING PK BATTLE ARENA (IF PK MODE ACTIVE)                           */}
      {/* ========================================================================= */}
      {isPkBattleActive && (
        <div className="relative z-30 mx-3 mt-1.5 bg-[#0a0e24]/85 backdrop-blur-xl border border-purple-500/40 rounded-2xl p-2.5 text-white shadow-2xl animate-in slide-in-from-top-3">
          <div className="flex items-center justify-between mb-1.5 text-xs font-bold">
            <div className="flex items-center gap-1.5 text-rose-400">
              <Swords className="w-4 h-4 animate-bounce" />
              <span className="font-black font-['Outfit'] tracking-wide">PK BATTLE ARENA</span>
            </div>
            <div className="font-mono text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/30 text-[10px] font-black">
              ⏱️ {formatTimer(pkTimeLeft)}
            </div>
          </div>

          {/* Split PK Score Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-mono font-black">
              <span className="text-cyan-400 flex items-center gap-1">
                You: {(myPkScore ?? 0).toLocaleString()}
              </span>
              <span className="text-rose-400 flex items-center gap-1">
                {opponentInfo.name}: {(opponentPkScore ?? 0).toLocaleString()}
              </span>
            </div>

            <div className="h-3 w-full bg-neutral-900 rounded-full overflow-hidden flex border border-neutral-700 shadow-inner">
              <div
                className="bg-gradient-to-r from-cyan-500 to-teal-400 transition-all duration-300 flex items-center justify-end pr-1"
                style={{ width: `${(myPkScore / (myPkScore + opponentPkScore)) * 100}%` }}
              >
                <span className="text-[8px] font-black text-black">🔵</span>
              </div>
              <div
                className="bg-gradient-to-l from-rose-500 to-pink-500 transition-all duration-300 flex items-center justify-start pl-1"
                style={{ width: `${(opponentPkScore / (myPkScore + opponentPkScore)) * 100}%` }}
              >
                <span className="text-[8px] font-black text-white">🔴</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. FLOATING BANNER NOTIFICATIONS                                          */}
      {/* ========================================================================= */}
      {activeBanner && (
        <div className="relative z-30 mx-4 mt-2 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 px-3 py-1.5 rounded-full shadow-2xl flex items-center justify-center gap-2 animate-bounce">
          <span className="text-base">{activeBanner.icon}</span>
          <span className="text-xs font-black font-['Outfit'] tracking-wide">
            {activeBanner.text}
          </span>
        </div>
      )}

      {/* Share Toast */}
      {showShareToast && (
        <div className="relative z-30 mx-auto mt-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-black px-4 py-1.5 rounded-full shadow-xl animate-in fade-in">
          🔗 Live Room Link Copied to Clipboard!
        </div>
      )}

      {/* Floating Hearts Rising Animation Area */}
      <div className="absolute right-5 bottom-20 z-20 pointer-events-none h-64 w-20 overflow-hidden flex flex-col justify-end items-center">
        {hearts.map((h) => (
          <div
            key={h.id}
            className="absolute bottom-0 animate-float-heart"
            style={{
              transform: `translateX(${h.x}px)`,
              color: h.color
            }}
          >
            <Heart
              style={{ width: `${h.size}px`, height: `${h.size}px`, fill: h.color }}
              className="drop-shadow-lg"
            />
          </div>
        ))}
      </div>

      {/* ========================================================================= */}
      {/* 6. BOTTOM OVERLAY: CHAT, RIGHT VERTICAL CONTROLS & BOTTOM ACTION ROW       */}
      {/* ========================================================================= */}
      <div className="relative z-30 px-3 pb-safe-bottom pb-2.5 space-y-2 pointer-events-none">
        
        {/* Middle Row: Chat on the Left + Compact Right Side Vertical Controls */}
        <div className="flex items-end justify-between gap-3">
          
          {/* Chat Messages Area - Positioned neatly above the input row */}
          <div
            ref={chatScrollRef}
            className="flex-1 max-w-[260px] sm:max-w-xs max-h-52 overflow-y-auto space-y-1.5 pointer-events-auto scrollbar-none pr-1 mask-gradient-top"
          >
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`p-2 rounded-2xl backdrop-blur-xl transition-all text-xs inline-block max-w-full ${
                  msg.isSystem
                    ? 'bg-amber-500/20 border border-amber-500/40 text-amber-200 shadow-md'
                    : msg.isGift
                    ? 'bg-gradient-to-r from-pink-600/40 via-purple-600/40 to-indigo-600/40 border border-pink-500/40 text-pink-100 shadow-lg'
                    : 'bg-[#0a0e24]/75 border border-white/10 text-neutral-200 shadow-md ring-1 ring-white/5'
                }`}
              >
                <div className="flex items-center gap-1.5 flex-wrap">
                  {msg.level && (
                    <span className="text-[8px] font-black px-1.5 py-0.2 rounded-full bg-cyan-500/30 text-cyan-300 font-mono">
                      Lv.{msg.level}
                    </span>
                  )}
                  {msg.vip && <VipBadge level={msg.vip} size="xs" />}
                  <span className="font-black text-white text-[11px]">
                    {msg.sender}:
                  </span>
                  <span className="text-[11px] text-neutral-100 break-words font-medium">
                    {msg.text}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* RIGHT SIDE VERTICAL CONTROLS (Compact, dark transparent glass-style with DIYO LIVE purple/blue/gold accents) */}
          {/* 1. Camera switch, 2. Effects, 3. Refresh/reconnect, 4. Microphone, 5. Game, 6. Gift / Actions */}
          <aside
            id="right-vertical-controls"
            aria-label="Live Stream Vertical Controls"
            className="flex flex-col items-center gap-2 pointer-events-auto"
          >
            {/* 1. Camera Switch (Front / Rear) */}
            <button
              id="btn-ctrl-switch-camera"
              onClick={flipCamera}
              disabled={isSwitchingCamera}
              className={`w-9 h-9 rounded-full bg-[#0a0e24]/85 hover:bg-[#121940] backdrop-blur-xl border border-cyan-400/40 flex items-center justify-center text-cyan-300 transition-transform active:scale-90 shadow-[0_4px_15px_rgba(0,0,0,0.6)] ring-1 ring-white/10 ${
                isSwitchingCamera ? 'animate-spin text-amber-400' : ''
              }`}
              title={`Camera Switch (Currently: ${facingMode === 'user' ? 'Front' : 'Rear'})`}
            >
              <RotateCw className="w-4 h-4" />
            </button>

            {/* 2. Visual Effects & Beauty Filters */}
            <button
              id="btn-ctrl-effects"
              onClick={cycleFilter}
              className="w-9 h-9 rounded-full bg-[#0a0e24]/85 hover:bg-[#121940] backdrop-blur-xl border border-purple-400/40 flex items-center justify-center text-purple-300 transition-transform active:scale-90 shadow-[0_4px_15px_rgba(0,0,0,0.6)] ring-1 ring-white/10"
              title={`Effects & Beauty Filter: ${activeFilter}`}
            >
              <Sparkles className="w-4 h-4" />
            </button>

            {/* 3. Refresh / Reconnect Live Stream */}
            <button
              id="btn-ctrl-refresh"
              onClick={handleRefreshStream}
              className="w-9 h-9 rounded-full bg-[#0a0e24]/85 hover:bg-[#121940] backdrop-blur-xl border border-amber-400/40 flex items-center justify-center text-amber-300 transition-transform active:scale-90 shadow-[0_4px_15px_rgba(0,0,0,0.6)] ring-1 ring-white/10"
              title="Refresh / Reconnect Stream"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* 4. Microphone Toggle with Live Audio Visualizer Pulse */}
            <button
              id="btn-ctrl-mic"
              onClick={toggleMic}
              className={`relative w-9 h-9 rounded-full backdrop-blur-xl border flex items-center justify-center transition-transform active:scale-90 shadow-[0_4px_15px_rgba(0,0,0,0.6)] ring-1 ring-white/10 ${
                isMicOn
                  ? 'bg-[#0a0e24]/85 border-emerald-400/50 text-emerald-400'
                  : 'bg-rose-600/40 border-rose-500 text-rose-300'
              }`}
              title={isMicOn ? 'Mute Microphone' : 'Unmute Microphone'}
            >
              {isMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              {isMicOn && audioLevel > 15 && (
                <span
                  className="absolute -inset-1 rounded-full border border-emerald-400/60 animate-ping pointer-events-none"
                  style={{ opacity: audioLevel / 100 }}
                />
              )}
            </button>

            {/* Camera ON / OFF Toggle */}
            <button
              id="btn-ctrl-camera-toggle"
              onClick={toggleCamera}
              className={`w-9 h-9 rounded-full backdrop-blur-xl border flex items-center justify-center transition-transform active:scale-90 shadow-[0_4px_15px_rgba(0,0,0,0.6)] ring-1 ring-white/10 ${
                isCameraOn
                  ? 'bg-[#0a0e24]/85 border-cyan-400/40 text-cyan-400'
                  : 'bg-rose-600/40 border-rose-500 text-rose-300'
              }`}
              title={isCameraOn ? 'Turn Camera Off' : 'Turn Camera On'}
            >
              {isCameraOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
            </button>


            {/* 6. Gift / Other Actions (PK Battle Challenge) */}
            <button
              id="btn-ctrl-pk"
              onClick={() => {
                if (isPkBattleActive) {
                  setIsPkBattleActive(false);
                } else {
                  setIsPkBattleActive(true);
                  playSoundFX('superchat');
                }
              }}
              className={`w-9 h-9 rounded-full flex items-center justify-center backdrop-blur-xl border transition-transform active:scale-90 shadow-[0_4px_15px_rgba(0,0,0,0.6)] ring-1 ring-white/10 ${
                isPkBattleActive
                  ? 'bg-rose-600 border-rose-400 text-white animate-pulse shadow-rose-900/50'
                  : 'bg-[#0a0e24]/85 border-rose-400/40 text-rose-400 hover:bg-[#121940]'
              }`}
              title="PK Battle Challenge"
            >
              <Swords className="w-4 h-4" />
            </button>

            {/* Heart Like Button */}
            <button
              id="btn-ctrl-heart-like"
              onClick={triggerFloatingHeart}
              className="relative w-9 h-9 rounded-full bg-gradient-to-tr from-pink-500 to-rose-600 text-white flex items-center justify-center shadow-lg shadow-pink-950/60 transition-transform active:scale-125"
              title="Send Heart Likes"
            >
              <Heart className="w-4 h-4 fill-white" />
              <span className="absolute -top-1.5 -right-1 px-1 rounded-full bg-neutral-950 text-[7.5px] font-mono font-bold text-pink-400 border border-pink-500">
                {(likeCount ?? 0) > 999 ? `${(likeCount / 1000).toFixed(1)}k` : likeCount}
              </span>
            </button>
          </aside>

        </div>

        {/* ========================================================================= */}
        {/* BOTTOM ACTION ROW: Message input, Emoji, Small Game button, Gifts, More/Actions */}
        {/* ========================================================================= */}
        <div
          id="bottom-action-row"
          className="flex items-center gap-1.5 pointer-events-auto bg-[#0a0e24]/90 backdrop-blur-2xl p-1.5 rounded-full border border-white/15 shadow-[0_8px_30px_rgba(0,0,0,0.85)] ring-1 ring-white/10"
        >
          
          {/* Message Input with integrated emoji and submit button */}
          <form
            onSubmit={handleSendMessage}
            className="flex-1 flex items-center bg-black/40 rounded-full px-3 py-1 border border-white/10 focus-within:border-cyan-400 transition-colors"
          >
            <input
              type="text"
              placeholder="Say something nice..."
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              className="w-full bg-transparent text-xs text-white placeholder-neutral-400 focus:outline-none pr-1"
            />
            {chatInput.trim() ? (
              <button
                type="submit"
                className="p-1 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white hover:brightness-110 transition-colors shadow-sm"
              >
                <Send className="w-3 h-3" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setChatInput((prev) => prev + ' ❤️');
                  playSoundFX('click');
                }}
                className="text-neutral-400 hover:text-amber-300 transition-colors"
                title="Add Emoji"
              >
                <Smile className="w-4 h-4" />
              </button>
            )}
          </form>

          {/* Gifts Button (🎁 Full Gift Sheet) */}
          <button
            id="btn-bottom-gifts"
            onClick={() => {
              setShowGiftSheet(true);
              playSoundFX('superchat');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 text-white font-black text-xs shadow-md shadow-purple-950/50 transition-transform active:scale-95 shrink-0"
            title="Send Virtual Gifts"
          >
            <Gift className="w-3.5 h-3.5 fill-white" />
            <span className="text-[11px]">Gifts</span>
          </button>

          {/* More / Actions Button (Share, Party Live Switch, Stream Settings) */}
          <div className="relative">
            <button
              id="btn-bottom-more-actions"
              onClick={() => {
                setShowMoreMenu(!showMoreMenu);
                playSoundFX('click');
              }}
              className="p-1.5 rounded-full bg-[#121838] hover:bg-[#1a2350] text-neutral-300 hover:text-white border border-white/10 transition-transform active:scale-95 shadow-sm"
              title="More Actions"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>

            {/* Floating More Actions Menu Popover */}
            {showMoreMenu && (
              <div className="absolute bottom-12 right-0 w-48 bg-[#0d122d]/95 backdrop-blur-2xl border border-purple-500/40 rounded-2xl p-2 shadow-2xl space-y-1.5 z-50 text-xs animate-in slide-in-from-bottom-2 ring-1 ring-white/10">
                {/* Dynamic Video Quality Selector (480p, 720p, 1080p) */}
                <div className="p-1.5 bg-black/40 rounded-xl border border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-neutral-400 font-bold px-0.5">
                    <span className="flex items-center gap-1">
                      <Wifi className="w-3 h-3 text-cyan-400" />
                      <span>Stream Quality</span>
                    </span>
                    <span className="text-cyan-300 font-mono font-black">{videoQuality}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    {(['480p', '720p', '1080p'] as const).map((q) => (
                      <button
                        key={q}
                        onClick={() => handleQualityChange(q)}
                        className={`py-1 rounded-lg text-[10px] font-black transition-all ${
                          videoQuality === q
                            ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-950/50'
                            : 'bg-white/5 text-neutral-300 hover:bg-white/15'
                        }`}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Share Stream */}
                <button
                  onClick={() => {
                    setShowMoreMenu(false);
                    setShowShareToast(true);
                    playSoundFX('click');
                    setTimeout(() => setShowShareToast(false), 3000);
                  }}
                  className="w-full flex items-center gap-2 p-2 rounded-xl hover:bg-white/10 text-neutral-200 hover:text-white text-left font-bold"
                >
                  <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Share Stream</span>
                </button>

                {/* Switch to Party Live Lounge */}
                {onOpenPartyLive && (
                  <button
                    onClick={() => {
                      setShowMoreMenu(false);
                      playSoundFX('click');
                      onOpenPartyLive();
                    }}
                    className="w-full flex items-center gap-2 p-2 rounded-xl hover:bg-white/10 text-amber-300 hover:text-amber-200 text-left font-bold"
                  >
                    <Crown className="w-3.5 h-3.5 text-amber-400" />
                    <span>Party Live Lounge</span>
                  </button>
                )}

                {/* Minimize Live Room */}
                <button
                  onClick={() => {
                    setShowMoreMenu(false);
                    handleMinimizeLive();
                  }}
                  className="w-full flex items-center gap-2 p-2 rounded-xl hover:bg-white/10 text-cyan-300 hover:text-cyan-200 text-left font-bold"
                >
                  <Minimize2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Minimize Stream</span>
                </button>
              </div>
            )}
          </div>

        </div>

      </div>

      {/* ========================================================================= */}
      {/* 7. ANDROID PERMISSION DENIED / RETRY MODAL                                 */}
      {/* ========================================================================= */}
      {showPermissionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-sm bg-[#0e122b] border border-purple-500/30 rounded-3xl p-5 shadow-2xl text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <Camera className="w-7 h-7" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-base font-black text-white font-['Outfit']">
                Camera & Audio Permission Required
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {permissionErrorMessage ||
                  'DIYO LIVE needs access to your Camera and Microphone to broadcast video & audio on Android.'}
              </p>
            </div>

            <div className="p-3 bg-black/50 rounded-2xl border border-white/10 text-left text-[11px] text-neutral-300 space-y-1.5">
              <div className="font-bold text-amber-300 flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5" />
                <span>How to enable on Android:</span>
              </div>
              <ol className="list-decimal list-inside space-y-1 text-neutral-400 text-[10px]">
                <li>Tap <strong>Grant Permissions</strong> below to trigger prompt</li>
                <li>Or open <strong>Settings &gt; Apps &gt; DIYO LIVE</strong></li>
                <li>Tap <strong>Permissions</strong> and set Camera &amp; Mic to <strong>Allow</strong></li>
              </ol>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={() => initializeMediaStream(facingMode)}
                className="w-full py-2.5 rounded-full bg-gradient-to-r from-rose-500 via-pink-500 to-purple-600 text-white font-black text-xs shadow-lg shadow-rose-950/50 hover:brightness-110 active:scale-95 transition-all"
              >
                Grant Permissions &amp; Retry
              </button>

              <button
                onClick={() => {
                  setIsVoiceOnlyMode(true);
                  setShowPermissionModal(false);
                }}
                className="w-full py-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs transition-all"
              >
                Continue in Voice Mode
              </button>

              {onClose && (
                <button
                  onClick={onClose}
                  className="text-xs text-neutral-500 hover:text-neutral-300 pt-1"
                >
                  Cancel and Return
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. END LIVE CONFIRMATION MODAL (Host Confirmation)                         */}
      {/* ========================================================================= */}
      {showEndLiveConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-xs bg-[#0e122b] border border-rose-500/40 rounded-3xl p-5 shadow-2xl text-center space-y-4">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <Square className="w-5 h-5 fill-rose-400" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-black text-white font-['Outfit']">
                End Live Stream?
              </h3>
              <p className="text-xs text-neutral-400">
                Are you sure you want to end this live broadcast? All viewers will be disconnected and session statistics will be generated.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowEndLiveConfirm(false)}
                className="flex-1 py-2.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmEndLive}
                className="flex-1 py-2.5 rounded-full bg-gradient-to-r from-rose-600 to-red-600 text-white font-black text-xs shadow-lg shadow-rose-950/60 transition-all hover:brightness-110 active:scale-95"
              >
                End Live
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 9. LIVE SESSION SUMMARY REPORT                                            */}
      {/* ========================================================================= */}
      {showSessionSummary && finalSessionStats && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in">
          <div className="w-full max-w-sm bg-[#0e122b] border border-rose-500/40 rounded-3xl p-6 shadow-2xl text-center space-y-5">
            <div className="relative">
              <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-pink-500 p-0.5 shadow-xl">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <span className="absolute bottom-0 right-1/2 translate-x-6 text-base">👑</span>
            </div>

            <div className="space-y-1">
              <h2 className="text-lg font-black text-white font-['Outfit']">
                Live Broadcast Summary
              </h2>
              <p className="text-xs text-neutral-400">
                Great stream, {currentUser.name}! Here are your results.
              </p>
            </div>

            {/* 4 Metrics Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-2xl bg-black/60 border border-white/10">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Duration</span>
                <span className="text-base font-black text-white font-mono">{formatTimer(finalSessionStats.duration)}</span>
              </div>
              <div className="p-3 rounded-2xl bg-black/60 border border-white/10">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Diamonds</span>
                <span className="text-base font-black text-amber-300 font-mono">+{finalSessionStats.diamonds.toLocaleString()} 💎</span>
              </div>
              <div className="p-3 rounded-2xl bg-black/60 border border-white/10">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Peak Viewers</span>
                <span className="text-base font-black text-cyan-300 font-mono">{finalSessionStats.viewers.toLocaleString()} 👁️</span>
              </div>
              <div className="p-3 rounded-2xl bg-black/60 border border-white/10">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Total Likes</span>
                <span className="text-base font-black text-pink-400 font-mono">{finalSessionStats.likes.toLocaleString()} ❤️</span>
              </div>
            </div>

            <button
              onClick={handleCloseSessionSummary}
              className="w-full py-3 rounded-full bg-gradient-to-r from-rose-500 via-pink-500 to-purple-600 text-white font-black text-xs shadow-xl shadow-pink-950/50 hover:brightness-110 active:scale-95 transition-all"
            >
              Back to Home
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 10. MODALS: BOTTOM GIFT SHEET & LUCK GAME MODAL                            */}
      {/* ========================================================================= */}
      <BottomGiftSheet
        isOpen={showGiftSheet}
        onClose={() => setShowGiftSheet(false)}
        initialCoins={currentUser.coinBalance || 245000}
        initialDiamonds={currentUser.diamondBalance || 18500}
        senderId={currentUser.id}
        senderName={currentUser.name}
        roomType="VIDEO_LIVE"
        roomSeats={['Host', 'Self', 'Opponent PK Streamer']}
        onSendSuccess={({ gift, target, multiplier, reward, totalCost, newBalance, newDiamonds, diamondsEarned, isSelfGift }) => {
          const isLuckyWin = (reward ?? 0) > 0;
          const diamondsToAdd = diamondsEarned || totalCost;
          setDiamondsEarned((prev) => prev + diamondsToAdd);

          const finalDiamondsBalance =
            newDiamonds !== undefined ? newDiamonds : (currentUser.diamondBalance || 0) + diamondsToAdd;

          if (onUpdateUserBalance) {
            onUpdateUserBalance(newBalance, finalDiamondsBalance);
          }

          let msgText = '';
          if (isSelfGift) {
            msgText = isLuckyWin
              ? `🎁 Sent ${multiplier}x ${gift.name} to Self (LUCKY HIT +${(reward ?? 0).toLocaleString()} TC & +${(diamondsEarned ?? 0).toLocaleString()} 💎!)`
              : `🎁 Sent ${multiplier}x ${gift.name} to Self → Converted +${(diamondsEarned ?? 0).toLocaleString()} Withdrawable Diamonds 💎!`;
          } else if (isLuckyWin) {
            msgText = `🎁 Sent ${multiplier}x ${gift.name} to ${target} with a LUCKY WIN of +${(reward ?? 0).toLocaleString()} TC!`;
            setActiveBanner({ text: `LUCKY HIT! ${target} received ${multiplier}x ${gift.name}!`, icon: '🎰' });
            setTimeout(() => setActiveBanner(null), 4000);
          } else {
            msgText = `🎁 Sent ${multiplier}x ${gift.name} (${gift.icon}) to ${target}!`;
          }

          setChatMessages((prev) => [
            ...prev,
            {
              id: Math.random().toString(),
              sender: currentUser.name,
              avatar: currentUser.avatar,
              text: msgText,
              vip: currentUser.vipLevel || 8,
              level: currentUser.level || 42,
              isGift: true,
              giftIcon: gift.icon
            }
          ]);
        }}
      />

      {/* Floating Heart CSS Animation */}
      <style>{`
        @keyframes floatHeart {
          0% {
            opacity: 1;
            transform: translateY(0) scale(0.8) rotate(0deg);
          }
          50% {
            opacity: 0.9;
            transform: translateY(-100px) scale(1.1) rotate(15deg);
          }
          100% {
            opacity: 0;
            transform: translateY(-220px) scale(1.3) rotate(-15deg);
          }
        }
        .animate-float-heart {
          animation: floatHeart 1.8s ease-out forwards;
        }
        .mask-gradient-top {
          mask-image: linear-gradient(to bottom, transparent, black 15%);
          -webkit-mask-image: linear-gradient(to bottom, transparent, black 15%);
        }
      `}</style>

    </div>
  );
};

