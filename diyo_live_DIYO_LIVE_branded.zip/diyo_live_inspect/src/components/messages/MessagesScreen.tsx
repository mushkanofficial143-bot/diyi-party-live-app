import React, { useState } from 'react';
import { 
  MessageSquare, 
  Send, 
  Search, 
  ShieldCheck, 
  Crown, 
  Sparkles, 
  Gift, 
  CheckCheck, 
  Bell, 
  Headphones, 
  Users,
  ChevronLeft
} from 'lucide-react';
import { DirectMessageConversation, INITIAL_CONVERSATIONS } from '../../data/mockMessagesData';
import { playSoundFX } from '../../utils/audioSynth';

interface MessagesScreenProps {
  currentUserName: string;
  currentUserAvatar: string;
}

export const MessagesScreen: React.FC<MessagesScreenProps> = ({
  currentUserName,
  currentUserAvatar
}) => {
  const [conversations, setConversations] = useState<DirectMessageConversation[]>(INITIAL_CONVERSATIONS);
  const [selectedConvId, setSelectedConvId] = useState<string>('CONV-02');
  const [inputText, setInputText] = useState<string>('');
  const [searchFilter, setSearchFilter] = useState<string>('');

  const activeConv = conversations.find(c => c.id === selectedConvId) || conversations[0];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeConv) return;

    const newMsg = {
      id: `msg-${Date.now()}`,
      sender: 'me' as const,
      text: inputText.trim(),
      time: 'Just now'
    };

    setConversations(prev => prev.map(c => {
      if (c.id === activeConv.id) {
        return {
          ...c,
          lastMessage: inputText.trim(),
          lastMessageTime: 'Just now',
          unreadCount: 0,
          messages: [...c.messages, newMsg]
        };
      }
      return c;
    }));

    setInputText('');
    playSoundFX('click');
  };

  const q = (searchFilter || '').toLowerCase();
  const filteredConversations = (conversations || []).filter(c => 
    !q ||
    (c.senderName || '').toLowerCase().includes(q) ||
    (c.lastMessage || '').toLowerCase().includes(q)
  );

  return (
    <div className="w-full max-w-5xl mx-auto h-[calc(100vh-140px)] min-h-[550px] rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-2xl overflow-hidden flex flex-col md:flex-row animate-in fade-in">
      
      {/* Left Sidebar: Conversations List */}
      <div className={`w-full md:w-80 lg:w-96 border-r border-neutral-800 flex flex-col bg-neutral-950/60 ${selectedConvId && 'hidden md:flex'}`}>
        
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-black text-white flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-emerald-400" />
              <span>MESSAGES</span>
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold">
              {conversations.reduce((acc, curr) => acc + curr.unreadCount, 0)} Unread
            </span>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search chats & contacts..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Conversation List Items */}
        <div className="flex-1 overflow-y-auto divide-y divide-neutral-800/60">
          {filteredConversations.map((c) => {
            const isSelected = selectedConvId === c.id;
            return (
              <div
                key={c.id}
                onClick={() => {
                  setSelectedConvId(c.id);
                  setConversations(prev => prev.map(item => item.id === c.id ? { ...item, unreadCount: 0 } : item));
                }}
                className={`p-3.5 flex items-start gap-3 cursor-pointer transition-all ${
                  isSelected ? 'bg-neutral-800/80 border-l-4 border-emerald-500' : 'hover:bg-neutral-900/60'
                }`}
              >
                <div className="relative flex-shrink-0">
                  <img
                    src={c.senderAvatar}
                    alt={c.senderName}
                    className="w-11 h-11 rounded-full object-cover border border-neutral-700"
                  />
                  {c.isOnline && (
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-neutral-950" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white truncate flex items-center gap-1">
                      {c.senderName}
                      {c.isOfficial && <ShieldCheck className="w-3 h-3 text-emerald-400 flex-shrink-0" />}
                    </h4>
                    <span className="text-[10px] text-neutral-500 font-mono flex-shrink-0">{c.lastMessageTime}</span>
                  </div>

                  <p className="text-[11px] text-neutral-400 truncate mt-0.5">{c.lastMessage}</p>

                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] text-neutral-500 font-mono">{c.senderRole}</span>
                    {c.unreadCount > 0 && (
                      <span className="ml-auto px-1.5 py-0.2 rounded-full bg-emerald-500 text-neutral-950 font-black font-mono text-[9px]">
                        {c.unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Right Pane: Active Chat Window */}
      {activeConv ? (
        <div className={`flex-1 flex flex-col bg-neutral-900/40 ${!selectedConvId && 'hidden md:flex'}`}>
          
          {/* Active Chat Header */}
          <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/70">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setSelectedConvId('')}
                className="md:hidden p-1.5 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <div className="relative">
                <img
                  src={activeConv.senderAvatar}
                  alt={activeConv.senderName}
                  className="w-10 h-10 rounded-full object-cover border border-emerald-500/40"
                />
                {activeConv.isOnline && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-neutral-950" />
                )}
              </div>

              <div>
                <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                  {activeConv.senderName}
                  {activeConv.isOfficial && <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">Official</span>}
                  {activeConv.senderVipLevel && <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">VIP {activeConv.senderVipLevel}</span>}
                </h3>
                <p className="text-[10px] text-neutral-400">{activeConv.senderRole} • {activeConv.isOnline ? 'Active Now' : 'Offline'}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-300 font-bold">
                View Profile
              </button>
            </div>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            {(activeConv.messages || []).map((m) => {
              const isMe = m.sender === 'me';
              return (
                <div
                  key={m.id}
                  className={`flex items-end gap-2.5 ${isMe ? 'justify-end' : 'justify-start'}`}
                >
                  {!isMe && (
                    <img
                      src={activeConv.senderAvatar}
                      alt={activeConv.senderName}
                      className="w-7 h-7 rounded-full object-cover flex-shrink-0"
                    />
                  )}

                  <div
                    className={`max-w-sm sm:max-w-md p-3.5 rounded-2xl text-xs space-y-1 ${
                      isMe
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-br-none shadow-md shadow-emerald-950/40'
                        : 'bg-neutral-800/90 text-neutral-200 rounded-bl-none border border-neutral-700/60'
                    }`}
                  >
                    <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
                    <div className={`flex items-center gap-1 text-[9px] font-mono ${isMe ? 'text-emerald-200 justify-end' : 'text-neutral-400'}`}>
                      <span>{m.time}</span>
                      {isMe && <CheckCheck className="w-3 h-3 text-emerald-200" />}
                    </div>
                  </div>

                  {isMe && (
                    <img
                      src={currentUserAvatar}
                      alt="Me"
                      className="w-7 h-7 rounded-full object-cover flex-shrink-0 border border-emerald-500"
                    />
                  )}
                </div>
              );
            })}
          </div>

          {/* Message Input Bar */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-neutral-800 bg-neutral-950/80 flex items-center gap-2">
            <input
              type="text"
              placeholder={`Send message to ${activeConv.senderName}...`}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 px-4 py-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
            />
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-amber-500 hover:from-emerald-500 hover:to-amber-400 disabled:opacity-40 text-white transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-neutral-500 text-xs">
          Select a conversation from the left to start messaging.
        </div>
      )}

    </div>
  );
};
