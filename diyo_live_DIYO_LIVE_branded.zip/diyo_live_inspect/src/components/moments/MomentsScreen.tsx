import React, { useState } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Send, 
  Gift, 
  Sparkles, 
  Image as ImageIcon, 
  CheckCircle2, 
  Flame, 
  Crown,
  MoreHorizontal
} from 'lucide-react';
import { MomentPost, INITIAL_MOMENTS } from '../../data/mockMomentsData';
import { playSoundFX } from '../../utils/audioSynth';

interface MomentsScreenProps {
  currentUserName: string;
  currentUserAvatar: string;
  onSendGiftClick?: (hostName: string) => void;
}

export const MomentsScreen: React.FC<MomentsScreenProps> = ({
  currentUserName,
  currentUserAvatar,
  onSendGiftClick
}) => {
  const [moments, setMoments] = useState<MomentPost[]>(INITIAL_MOMENTS);
  const [filterTag, setFilterTag] = useState<string>('All');
  const [newPostText, setNewPostText] = useState<string>('');
  const [newPostImage, setNewPostImage] = useState<string>('');
  const [isPosting, setIsPosting] = useState<boolean>(false);
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState<string>('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const tags = ['All', '#SRLive', '#DJSet', '#ElectronicVibes', '#Esports', '#BGMIPro', '#LoFiBeats', '#RelaxMusic', '#CreatorLife', '#BollywoodVibes'];

  const handleLike = (id: string) => {
    setMoments(prev => prev.map(m => {
      if (m.id === id) {
        const nextLiked = !m.isLiked;
        playSoundFX(nextLiked ? 'win' : 'click');
        return {
          ...m,
          isLiked: nextLiked,
          likesCount: nextLiked ? m.likesCount + 1 : Math.max(0, m.likesCount - 1)
        };
      }
      return m;
    }));
  };

  const handleAddComment = (postId: string) => {
    if (!commentInput.trim()) return;

    setMoments(prev => prev.map(m => {
      if (m.id === postId) {
        const newCm = {
          id: `cm-${Date.now()}`,
          userName: currentUserName,
          avatar: currentUserAvatar,
          vipLevel: 8,
          text: commentInput.trim(),
          timeAgo: 'Just now'
        };
        return {
          ...m,
          commentsCount: m.commentsCount + 1,
          comments: [...m.comments, newCm]
        };
      }
      return m;
    }));
    setCommentInput('');
    playSoundFX('click');
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim()) return;

    const newMoment: MomentPost = {
      id: `MOM-${Date.now()}`,
      authorId: 'USR-882941',
      authorName: currentUserName,
      authorAvatar: currentUserAvatar,
      authorRole: 'VIP Pioneer',
      authorVipLevel: 8,
      isVerified: true,
      timeAgo: 'Just now',
      content: newPostText.trim(),
      mediaType: 'image',
      mediaUrl: newPostImage || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80',
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      tags: ['#SRLive', '#CreatorLife'],
      comments: []
    };

    setMoments([newMoment, ...moments]);
    setNewPostText('');
    setNewPostImage('');
    setIsPosting(false);
    playSoundFX('win');
    setToastMsg('✨ Moment published to DIYO LIVE Community!');
    setTimeout(() => setToastMsg(null), 3000);
  };

  const filteredMoments = filterTag === 'All'
    ? (moments || [])
    : (moments || []).filter(m => (m.tags || []).includes(filterTag));

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 pb-20 animate-in fade-in">
      
      {/* Toast */}
      {toastMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Post Publisher Card */}
      <div className="p-4 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-3">
        <div className="flex items-center gap-3">
          <img
            src={currentUserAvatar}
            alt={currentUserName}
            className="w-10 h-10 rounded-full object-cover border border-emerald-500/50"
          />
          <div className="flex-1">
            <input
              type="text"
              placeholder="Share your live moments, thoughts, or highlights..."
              value={newPostText}
              onChange={(e) => setNewPostText(e.target.value)}
              onFocus={() => setIsPosting(true)}
              className="w-full px-4 py-2.5 rounded-2xl bg-neutral-950 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-all"
            />
          </div>
        </div>

        {isPosting && (
          <form onSubmit={handleCreatePost} className="space-y-3 pt-2 border-t border-neutral-800 animate-in fade-in">
            <div className="space-y-1">
              <input
                type="url"
                placeholder="Optional image URL (e.g. Unsplash or direct photo link)"
                value={newPostImage}
                onChange={(e) => setNewPostImage(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-2 text-xs text-neutral-400">
                <span className="flex items-center gap-1"><Sparkles className="w-3.5 h-3.5 text-amber-400" /> Public Community Feed</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPosting(false)}
                  className="px-3.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newPostText.trim()}
                  className="px-5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-amber-500 hover:from-emerald-500 hover:to-amber-400 disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider shadow-md transition-all flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Publish</span>
                </button>
              </div>
            </div>
          </form>
        )}
      </div>

      {/* Tags Filter Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {tags.map((t) => (
          <button
            key={t}
            onClick={() => setFilterTag(t)}
            className={`flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
              filterTag === t
                ? 'bg-emerald-500 text-neutral-950 font-black shadow-md shadow-emerald-950/40'
                : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Feed List */}
      <div className="space-y-4">
        {filteredMoments.map((moment) => (
          <div
            key={moment.id}
            className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-3.5 transition-all hover:border-neutral-700"
          >
            {/* Author Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src={moment.authorAvatar}
                    alt={moment.authorName}
                    className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500/50 shadow-md"
                  />
                  {moment.authorVipLevel && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-amber-400 border border-neutral-950 flex items-center justify-center">
                      <Crown className="w-3 h-3 text-neutral-950 fill-neutral-950" />
                    </div>
                  )}
                </div>

                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-sm font-black text-white">{moment.authorName}</h3>
                    {moment.isVerified && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                    )}
                    {moment.authorVipLevel && (
                      <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300">
                        VIP {moment.authorVipLevel}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-neutral-400">{moment.authorRole} • {moment.timeAgo}</p>
                </div>
              </div>

              <button className="text-neutral-500 hover:text-neutral-300">
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </div>

            {/* Post Content */}
            <p className="text-xs sm:text-sm text-neutral-200 leading-relaxed whitespace-pre-wrap">
              {moment.content}
            </p>

            {/* Post Media Image if any */}
            {moment.mediaUrl && (
              <div className="rounded-2xl overflow-hidden border border-neutral-800 max-h-96 bg-black">
                <img
                  src={moment.mediaUrl}
                  alt="Post Attachment"
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {/* Tags */}
            {moment.tags && (moment.tags || []).length > 0 && (
              <div className="flex items-center gap-2 flex-wrap">
                {(moment.tags || []).map((tg, idx) => (
                  <span key={idx} className="text-[11px] font-semibold text-emerald-400 hover:underline cursor-pointer">
                    {tg}
                  </span>
                ))}
              </div>
            )}

            {/* Post Engagement Bar */}
            <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs text-neutral-400">
              
              {/* Like Button */}
              <button
                onClick={() => handleLike(moment.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                  moment.isLiked ? 'bg-rose-500/20 text-rose-400 font-bold' : 'hover:bg-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                <Heart className={`w-4 h-4 ${moment.isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                <span className="font-mono">{moment.likesCount}</span>
              </button>

              {/* Comment Button */}
              <button
                onClick={() => setActiveCommentPostId(activeCommentPostId === moment.id ? null : moment.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:bg-neutral-800 text-neutral-400 hover:text-white transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="font-mono">{moment.commentsCount}</span>
              </button>

              {/* Gift on Moment */}
              <button
                onClick={() => {
                  playSoundFX('win');
                  setToastMsg(`🎁 Sent virtual appreciation gift to ${moment.authorName}!`);
                  setTimeout(() => setToastMsg(null), 2500);
                  if (onSendGiftClick) onSendGiftClick(moment.authorName);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:bg-amber-500/20 text-amber-400 transition-all font-semibold"
              >
                <Gift className="w-4 h-4" />
                <span>Gift</span>
              </button>

              {/* Share */}
              <button
                onClick={() => {
                  navigator.clipboard.writeText(window.location.href);
                  playSoundFX('click');
                  setToastMsg('🔗 Moment link copied to clipboard!');
                  setTimeout(() => setToastMsg(null), 2500);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:bg-neutral-800 text-neutral-400 hover:text-white transition-all"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>

            {/* Comments Thread Expanded */}
            {activeCommentPostId === moment.id && (
              <div className="pt-3 border-t border-neutral-800/60 space-y-2.5 animate-in fade-in">
                {moment.comments && (moment.comments || []).map((cm) => (
                  <div key={cm.id} className="flex items-start gap-2.5 p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/80 text-xs">
                    <img src={cm.avatar} alt={cm.userName} className="w-7 h-7 rounded-full object-cover" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white flex items-center gap-1.5">
                          {cm.userName}
                          {cm.vipLevel && (
                            <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
                              VIP {cm.vipLevel}
                            </span>
                          )}
                        </span>
                        <span className="text-[10px] text-neutral-500 font-mono">{cm.timeAgo}</span>
                      </div>
                      <p className="text-neutral-300 mt-0.5">{cm.text}</p>
                    </div>
                  </div>
                ))}

                {/* Comment Input */}
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    placeholder="Write a supportive reply..."
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleAddComment(moment.id);
                    }}
                    className="flex-1 px-3.5 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    onClick={() => handleAddComment(moment.id)}
                    className="p-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold transition-all"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

          </div>
        ))}
      </div>

    </div>
  );
};
