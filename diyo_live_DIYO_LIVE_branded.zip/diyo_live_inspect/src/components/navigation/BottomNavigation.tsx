import React from 'react';
import { Home, Gamepad2, MessageSquare, User } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { useAndroidInsets } from '../../utils/useAndroidInsets';

export type NavScreen = 'browse' | 'explore' | 'video_live' | 'party_live' | 'message' | 'wallet' | 'me' | 'owner' | 'moment' | 'games';

interface BottomNavigationProps {
  activeTab: string;
  onSelectTab: (tab: NavScreen) => void;
  onOpenGoLive?: () => void;
  unreadMessagesCount?: number;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab,
  onSelectTab,
}) => {
  const { isKeyboardOpen, safeBottom } = useAndroidInsets();

  const isHomeActive = activeTab === 'browse' || activeTab === 'explore' || activeTab === 'home';
  const isGameActive = activeTab === 'games';
  const isMsgActive = activeTab === 'message' || activeTab === 'moment';
  const isProfileActive = activeTab === 'me' || activeTab === 'owner' || activeTab === 'wallet';

  const navItems = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      isActive: isHomeActive,
      onClick: () => onSelectTab('browse'),
      activeGradient: 'from-blue-600 to-indigo-600',
      activeBorder: 'border-cyan-400/60',
      activeGlow: 'shadow-[0_0_14px_rgba(59,130,246,0.5)]',
      textColor: 'text-cyan-300'
    },
    {
      id: 'game',
      label: 'Game',
      icon: Gamepad2,
      isActive: isGameActive,
      onClick: () => onSelectTab('games'),
      activeGradient: 'from-amber-500 to-orange-600',
      activeBorder: 'border-amber-400/70',
      activeGlow: 'shadow-[0_0_14px_rgba(245,158,11,0.5)]',
      textColor: 'text-amber-200'
    },
    {
      id: 'msg',
      label: 'Msg',
      icon: MessageSquare,
      isActive: isMsgActive,
      onClick: () => onSelectTab('message'),
      activeGradient: 'from-purple-600 to-pink-600',
      activeBorder: 'border-purple-400/70',
      activeGlow: 'shadow-[0_0_14px_rgba(168,85,247,0.5)]',
      textColor: 'text-purple-200',
      badge: '2'
    },
    {
      id: 'me',
      label: 'Me',
      icon: User,
      isActive: isProfileActive,
      onClick: () => onSelectTab('me'),
      activeGradient: 'from-emerald-600 to-teal-600',
      activeBorder: 'border-emerald-400/60',
      activeGlow: 'shadow-[0_0_14px_rgba(16,185,129,0.5)]',
      textColor: 'text-emerald-300'
    },
  ];

  return (
    <aside
      id="bottom-navigation-wrapper"
      style={{
        // Dynamically compute safe insets: keeps nav bar strictly above Android gesture bar (16-24px),
        // Android 3-button bar (48-56px), or hardware bezels on all aspect ratios.
        // Hides smoothly when virtual keyboard opens to allow free typing space.
        bottom: isKeyboardOpen ? '-120px' : `calc(max(env(safe-area-inset-bottom, 0px), ${safeBottom}px) + 8px)`,
        transform: isKeyboardOpen ? 'translateY(150%)' : 'translateY(0)',
        opacity: isKeyboardOpen ? 0 : 1,
        transition: 'transform 0.25s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.2s ease, bottom 0.25s ease'
      }}
      className="fixed left-0 right-0 z-50 px-2 sm:px-4 pointer-events-none flex justify-center will-change-transform"
      aria-label="Main Navigation Container"
    >
      <nav
        id="bottom-navigation-bar"
        aria-label="DIYO Bottom Navigation"
        className="pointer-events-auto w-full max-w-lg bg-[#090d1f]/95 backdrop-blur-2xl border border-white/15 rounded-full p-1.5 shadow-[0_16px_40px_rgba(0,0,0,0.9)] flex items-center justify-between gap-1 select-none ring-1 ring-white/10"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              id={`btn-bottom-nav-${item.id}`}
              onClick={() => {
                playSoundFX('click');
                item.onClick();
              }}
              className={`relative flex-1 min-h-[46px] sm:min-h-[48px] flex items-center justify-center transition-all duration-200 rounded-full cursor-pointer group active:scale-95 ${
                item.isActive
                  ? `px-2 sm:px-3 py-1 bg-gradient-to-r ${item.activeGradient} border ${item.activeBorder} ${item.activeGlow} text-white shadow-md`
                  : 'px-1.5 sm:px-2 py-1 text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
              }`}
              title={item.label}
              aria-label={item.label}
              aria-current={item.isActive ? 'page' : undefined}
            >
              <div className="flex flex-col items-center justify-center gap-0.5 sm:gap-1 text-center w-full min-w-0">
                <div className="relative flex items-center justify-center">
                  <Icon
                    className={`w-4 h-4 sm:w-4.5 sm:h-4.5 transition-transform duration-200 group-hover:scale-110 ${
                      item.isActive
                        ? 'text-white stroke-[2.4] drop-shadow-sm'
                        : 'stroke-[1.8] group-hover:text-white'
                    }`}
                  />
                  {item.badge && !item.isActive && (
                    <span className="absolute -top-1 -right-2 flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500" />
                    </span>
                  )}
                </div>

                <span
                  className={`text-[8.5px] xs:text-[9.5px] sm:text-[10.5px] font-['Outfit'] font-black tracking-tight uppercase whitespace-nowrap overflow-hidden text-ellipsis max-w-[64px] sm:max-w-none ${
                    item.isActive
                      ? 'text-white drop-shadow-sm'
                      : 'text-neutral-400 group-hover:text-neutral-200'
                  }`}
                >
                  {item.label}
                </span>
              </div>
            </button>
          );
        })}
      </nav>
    </aside>
  );
};

