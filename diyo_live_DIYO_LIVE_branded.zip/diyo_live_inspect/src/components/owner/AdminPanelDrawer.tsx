import React, { useState } from 'react';
import {
  Crown,
  X,
  ChevronRight,
  ChevronLeft,
  Home,
  Users,
  User,
  UserCheck,
  Gift,
  Gamepad2,
  Radio,
  Coins,
  FileText,
  Trophy,
  Building2,
  Settings,
  BarChart3,
  ShieldCheck,
  Award,
  Bell,
  LogOut,
  Search,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Plus,
  Edit,
  Trash2,
  Eye,
  Sliders,
  DollarSign,
  TrendingUp,
  Tv,
  VolumeX,
  Volume2,
  Ban,
  ShieldAlert,
  Send,
  RefreshCw,
  Clock,
  Gem,
  Lock,
  ArrowRight,
  Layers,
  HeartHandshake,
  Cpu,
  Globe
} from 'lucide-react';
import {
  UserAccount,
  HostAccount,
  AgencyAccount,
  GiftItem,
  WalletTransaction,
  LiveRoomAccount,
  ModerationReport,
  NotificationItem,
  UserRole,
  HostTagType,
  VipTierConfig,
  PlatformSettings
} from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';
import { HostTagBadge } from '../HostTagBadge';
import { UserBanUnbanPowerHub } from './UserBanUnbanPowerHub';

export interface AdminPanelDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount;
  currentRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  // Platform data
  users: UserAccount[];
  hosts: HostAccount[];
  agencies: AgencyAccount[];
  gifts: GiftItem[];
  liveRooms: LiveRoomAccount[];
  transactions: WalletTransaction[];
  reports: ModerationReport[];
  notifications: NotificationItem[];
  vipConfigs?: VipTierConfig[];
  platformSettings?: PlatformSettings;
  // Handlers
  onUpdateUsers?: (users: UserAccount[]) => void;
  onUpdateHosts?: (hosts: HostAccount[]) => void;
  onUpdateAgencies?: (agencies: AgencyAccount[]) => void;
  onUpdateGifts?: (gifts: GiftItem[]) => void;
  onUpdateLiveRooms?: (rooms: LiveRoomAccount[]) => void;
  onUpdateTransactions?: (txs: WalletTransaction[]) => void;
  onUpdateReports?: (reports: ModerationReport[]) => void;
  onUpdateNotifications?: (notifications: NotificationItem[]) => void;
  onUpdateSettings?: (settings: PlatformSettings) => void;
  onNavigateTab?: (tab: string) => void;
  initialTab?: string;
}

export const AdminPanelDrawer: React.FC<AdminPanelDrawerProps> = ({
  isOpen,
  onClose,
  currentUser,
  currentRole,
  onChangeRole,
  users = [],
  hosts = [],
  agencies = [],
  gifts = [],
  liveRooms = [],
  transactions = [],
  reports = [],
  notifications = [],
  vipConfigs = [],
  platformSettings,
  onUpdateUsers,
  onUpdateHosts,
  onUpdateAgencies,
  onUpdateGifts,
  onUpdateLiveRooms,
  onUpdateTransactions,
  onUpdateReports,
  onUpdateNotifications,
  onUpdateSettings,
  onNavigateTab,
  initialTab = 'dashboard'
}) => {
  const [activeMenuId, setActiveMenuId] = useState<string>(initialTab);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected item filters / sub-state
  const [selectedUserFilter, setSelectedUserFilter] = useState<'ALL' | 'ACTIVE' | 'MUTED' | 'BANNED'>('ALL');
  const [selectedHostTagFilter, setSelectedHostTagFilter] = useState<string>('ALL');
  const [selectedGiftCategoryFilter, setSelectedGiftCategoryFilter] = useState<string>('ALL');
  const [selectedTxTypeFilter, setSelectedTxTypeFilter] = useState<string>('ALL');
  const [selectedReportFilter, setSelectedReportFilter] = useState<string>('ALL');

  // Sub-action Modals
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isCreateGiftOpen, setIsCreateGiftOpen] = useState(false);
  const [isCreateNoticeOpen, setIsCreateNoticeOpen] = useState(false);
  const [newNoticeTitle, setNewNoticeTitle] = useState('');
  const [newNoticeBody, setNewNoticeBody] = useState('');
  const [newNoticeTarget, setNewNoticeTarget] = useState<'All' | 'Hosts' | 'Users' | 'Agencies'>('All');

  // Coin Adjustment Modal
  const [adjustCoinUser, setAdjustCoinUser] = useState<UserAccount | null>(null);
  const [adjustCoinAmount, setAdjustCoinAmount] = useState<string>('10000');

  // Staff Hiring & Roles State
  const [hireRole, setHireRole] = useState<'OFFICIAL' | 'MANAGER' | 'SUPER_ADMIN' | 'ADMIN_BD' | 'AGENCY' | 'COIN_SELLER'>('OFFICIAL');
  const [hireName, setHireName] = useState('');
  const [hireUsername, setHireUsername] = useState('');
  const [hireEmail, setHireEmail] = useState('');
  const [hirePhone, setHirePhone] = useState('');
  const [hireAllocation, setHireAllocation] = useState('1000000');
  const [hiredStaffList, setHiredStaffList] = useState<any[]>([
    { id: 'OFF-001', role: 'OFFICIAL', name: 'Aarav Sharma', username: 'aarav_official', email: 'official@sr.live', status: 'Active', date: '2026-09-01' },
    { id: 'MGR-101', role: 'MANAGER', name: 'Vikram Rao', username: 'vikram_mgr', email: 'manager@sr.live', status: 'Active', date: '2026-09-02' },
    { id: 'SA-501', role: 'SUPER_ADMIN', name: 'Priya Sen', username: 'priya_sa', email: 'superadmin@sr.live', status: 'Active', date: '2026-09-03' },
    { id: 'BD-301', role: 'ADMIN_BD', name: 'Rohan Mehta', username: 'rohan_bd', email: 'bd@sr.live', status: 'Active', date: '2026-09-04' },
    { id: 'AG-01', role: 'AGENCY', name: 'Apex Media Guild', username: 'apex_agency', email: 'agency@sr.live', status: 'Active', date: '2026-09-05' },
    { id: 'CS-901', role: 'COIN_SELLER', name: 'Karan Patel', username: 'karan_coins', email: 'seller@sr.live', status: 'Active', date: '2026-09-06' },
  ]);

  // Daily Missions State & Creator
  const [missionTitle, setMissionTitle] = useState('');
  const [missionType, setMissionType] = useState<'User Daily' | 'Host Milestone' | 'Viewer Event' | 'Games Quest'>('User Daily');
  const [missionReward, setMissionReward] = useState('1,000 Coins');
  const [missionRequirement, setMissionRequirement] = useState('');
  const [dailyMissionsList, setDailyMissionsList] = useState<any[]>([
    { title: 'Daily Check-In Bonus', reward: '500 Coins', requirement: 'Login once daily', type: 'User Daily' },
    { title: 'Stream 2 Hours Milestone', reward: '10,000 Diamonds', requirement: 'Broadcast >= 120 mins', type: 'Host Milestone' },
    { title: 'Send 10,000 Coins Gift', reward: 'VIP Noble Frame (3 Days)', requirement: 'Gift volume >= 10K', type: 'Viewer Event' },
    { title: 'Play 5 Casino / Arcade Games', reward: '1,000 Lucky Coins', requirement: '5 Game rounds', type: 'Games Quest' }
  ]);

  const handleCreateMission = (e: React.FormEvent) => {
    e.preventDefault();
    if (!missionTitle || !missionRequirement) return;
    const newMission = {
      title: missionTitle,
      reward: missionReward,
      requirement: missionRequirement,
      type: missionType
    };
    setDailyMissionsList([newMission, ...dailyMissionsList]);
    showToast(`🎯 Successfully created daily mission: "${missionTitle}"!`);
    setMissionTitle('');
    setMissionRequirement('');
  };

  const handleHireSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hireName || !hireUsername) return;
    const prefix = hireRole === 'OFFICIAL' ? 'OFF' : hireRole === 'MANAGER' ? 'MGR' : hireRole === 'SUPER_ADMIN' ? 'SA' : hireRole === 'ADMIN_BD' ? 'BD' : hireRole === 'AGENCY' ? 'AG' : 'CS';
    const newId = `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newMember = {
      id: newId,
      role: hireRole,
      name: hireName,
      username: hireUsername,
      email: hireEmail || `${hireUsername}@sr.live`,
      phone: hirePhone || '+91 9876543210',
      status: 'Active',
      allocation: hireAllocation,
      date: new Date().toISOString().split('T')[0]
    };
    setHiredStaffList([newMember, ...hiredStaffList]);
    showToast(`🎉 Successfully hired & created ${hireRole} account: ${hireName} (${newId})!`);
    setHireName('');
    setHireUsername('');
    setHireEmail('');
    setHirePhone('');
  };

  const showToast = (msg: string) => {
    playSoundFX('notification');
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  if (!isOpen) return null;

  // 16 Admin Menu Items definitions with matching colorful modern icons
  const adminMenuItems = [
    {
      id: 'dashboard',
      num: 1,
      label: 'Dashboard',
      icon: Home,
      color: 'from-blue-500 to-cyan-500',
      iconColor: 'text-cyan-400',
      badge: 'LIVE',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
    },
    {
      id: 'users',
      num: 2,
      label: 'User Management',
      icon: Users,
      color: 'from-purple-500 to-indigo-500',
      iconColor: 'text-indigo-400',
      badge: users.length.toString(),
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
    },
    {
      id: 'hosts',
      num: 3,
      label: 'Host Management',
      icon: User,
      color: 'from-pink-500 to-rose-500',
      iconColor: 'text-pink-400',
      badge: `${hosts.length} Hosts`,
      badgeColor: 'bg-pink-500/20 text-pink-300 border-pink-500/30'
    },
    {
      id: 'gifts',
      num: 4,
      label: 'Gift Management',
      icon: Gift,
      color: 'from-amber-500 to-yellow-500',
      iconColor: 'text-amber-400',
      badge: `${gifts.length} Gifts`,
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30'
    },
    {
      id: 'games',
      num: 5,
      label: 'Game Management',
      icon: Gamepad2,
      color: 'from-emerald-500 to-teal-500',
      iconColor: 'text-emerald-400',
      badge: '26 Games',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
    },
    {
      id: 'live_rooms',
      num: 6,
      label: 'Live Room Control',
      icon: Radio,
      color: 'from-rose-500 to-red-600',
      iconColor: 'text-rose-400',
      badge: `${liveRooms.length} Live`,
      badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30'
    },
    {
      id: 'wallet',
      num: 7,
      label: 'Coin & Wallet',
      icon: Coins,
      color: 'from-yellow-500 to-amber-600',
      iconColor: 'text-yellow-400',
      badge: 'Treasury',
      badgeColor: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
    },
    {
      id: 'transactions',
      num: 8,
      label: 'Transaction Records',
      icon: FileText,
      color: 'from-cyan-500 to-blue-600',
      iconColor: 'text-cyan-400',
      badge: `${transactions.length} Logs`,
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
    },
    {
      id: 'tasks',
      num: 9,
      label: 'Task & Reward',
      icon: Trophy,
      color: 'from-purple-500 to-pink-600',
      iconColor: 'text-purple-400',
      badge: 'Rewards',
      badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30'
    },
    {
      id: 'agencies',
      num: 10,
      label: 'Agency Management',
      icon: Building2,
      color: 'from-teal-500 to-emerald-600',
      iconColor: 'text-teal-400',
      badge: `${agencies.length} Guilds`,
      badgeColor: 'bg-teal-500/20 text-teal-300 border-teal-500/30'
    },
    {
      id: 'hiring_staff',
      num: 11,
      label: 'Staff Hiring & Roles',
      icon: UserCheck,
      color: 'from-emerald-500 to-teal-600',
      iconColor: 'text-emerald-300',
      badge: `${hiredStaffList.length} Staff`,
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
    },
    {
      id: 'settings',
      num: 11,
      label: 'System Settings',
      icon: Settings,
      color: 'from-slate-500 to-neutral-600',
      iconColor: 'text-slate-300',
      badge: 'Config',
      badgeColor: 'bg-slate-500/20 text-slate-300 border-slate-500/30'
    },
    {
      id: 'reports_analytics',
      num: 12,
      label: 'Reports & Analytics',
      icon: BarChart3,
      color: 'from-violet-500 to-purple-600',
      iconColor: 'text-violet-400',
      badge: 'HD Charts',
      badgeColor: 'bg-violet-500/20 text-violet-300 border-violet-500/30'
    },
    {
      id: 'moderation',
      num: 13,
      label: 'Content Moderation',
      icon: ShieldCheck,
      color: 'from-red-500 to-rose-600',
      iconColor: 'text-red-400',
      badge: `${reports.filter(r => r.status === 'Pending').length} Pending`,
      badgeColor: 'bg-red-500/20 text-red-300 border-red-500/30'
    },
    {
      id: 'vip_level',
      num: 14,
      label: 'VIP & Level',
      icon: Award,
      color: 'from-amber-400 to-yellow-500',
      iconColor: 'text-amber-300',
      badge: 'VIP 1–8',
      badgeColor: 'bg-amber-400/20 text-amber-300 border-amber-400/30'
    },
    {
      id: 'notices',
      num: 15,
      label: 'Notice & Message',
      icon: Bell,
      color: 'from-blue-400 to-indigo-500',
      iconColor: 'text-blue-300',
      badge: `${notifications.length} Sent`,
      badgeColor: 'bg-blue-400/20 text-blue-300 border-blue-400/30'
    },
    {
      id: 'logout',
      num: 16,
      label: 'Logout & Roles',
      icon: LogOut,
      color: 'from-rose-500 to-red-700',
      iconColor: 'text-rose-400',
      badge: currentRole,
      badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30'
    }
  ];

  // User Actions
  const handleToggleBlockUser = (userId: string) => {
    if (!onUpdateUsers) return;
    const updated = users.map(u => {
      if (u.id === userId) {
        const nextStatus = u.status === 'Banned' ? 'Active' : 'Banned';
        showToast(nextStatus === 'Banned' ? `⛔ User ${u.name} blocked` : `✅ User ${u.name} unblocked`);
        return { ...u, status: nextStatus };
      }
      return u;
    });
    onUpdateUsers(updated);
  };

  const handleToggleVerifyUser = (userId: string) => {
    if (!onUpdateUsers) return;
    const updated = users.map(u => {
      if (u.id === userId) {
        const next = !u.isVerified;
        showToast(next ? `🌟 Verified badge granted to ${u.name}` : `Unverified ${u.name}`);
        return { ...u, isVerified: next };
      }
      return u;
    });
    onUpdateUsers(updated);
  };

  // Host Actions
  const handleAssignHostTag = (hostId: string, tag: HostTagType) => {
    if (!onUpdateHosts) return;
    const updated = hosts.map(h => {
      if (h.id === hostId) {
        showToast(`🏷️ Host ${h.name} updated to tag: ${tag}`);
        return { ...h, hostTag: tag };
      }
      return h;
    });
    onUpdateHosts(updated);
  };

  // Gift Actions
  const handleToggleGift = (giftId: string) => {
    if (!onUpdateGifts) return;
    const updated = gifts.map(g => {
      if (g.id === giftId) {
        const next = !g.isActive;
        showToast(next ? `✨ Gift ${g.name} enabled` : `Gift ${g.name} disabled`);
        return { ...g, isActive: next };
      }
      return g;
    });
    onUpdateGifts(updated);
  };

  // Live Room Actions
  const handleEndLiveRoom = (roomId: string) => {
    if (!onUpdateLiveRooms) return;
    const updated = liveRooms.filter(r => r.id !== roomId);
    onUpdateLiveRooms(updated);
    showToast(`🛑 Live stream ${roomId} terminated by Admin`);
  };

  // Notice Dispatcher
  const handleSendNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoticeTitle.trim()) return;
    const newNotif: NotificationItem = {
      id: `NTF-${Date.now()}`,
      title: newNoticeTitle.trim(),
      message: newNoticeBody.trim() || 'Official announcement from DIYO LIVE Admin Management Team.',
      targetAudience: newNoticeTarget,
      timestamp: 'Just now',
      readCount: 0,
      sentBy: `Admin (${currentUser.name})`
    };
    if (onUpdateNotifications) {
      onUpdateNotifications([newNotif, ...notifications]);
    }
    setNewNoticeTitle('');
    setNewNoticeBody('');
    setIsCreateNoticeOpen(false);
    showToast(`📢 Announcement "${newNotif.title}" broadcasted to ${newNoticeTarget}!`);
  };

  // Coin Adjustment
  const handleConfirmCoinAdjustment = () => {
    if (!adjustCoinUser || !onUpdateUsers) return;
    const delta = Number(adjustCoinAmount) || 0;
    const updated = users.map(u => {
      if (u.id === adjustCoinUser.id) {
        return { ...u, coinBalance: Math.max(0, u.coinBalance + delta) };
      }
      return u;
    });
    onUpdateUsers(updated);

    if (onUpdateTransactions) {
      const newTx: WalletTransaction = {
        id: `TXN-ADM-${Date.now()}`,
        type: 'MANUAL_ADJUSTMENT',
        senderId: 'ADMIN-TREASURY',
        senderName: 'DIYO LIVE Admin Vault',
        recipientId: adjustCoinUser.id,
        recipientName: adjustCoinUser.name,
        amountCoins: delta,
        amountDiamonds: 0,
        status: 'Completed',
        timestamp: 'Just now',
        paymentChannel: 'Admin Direct Grant',
        txHash: `0xADM${Math.random().toString(16).substring(2, 10)}`
      };
      onUpdateTransactions([newTx, ...transactions]);
    }

    showToast(`🪙 Injected ${delta.toLocaleString()} coins into ${adjustCoinUser.name}'s wallet`);
    setAdjustCoinUser(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex animate-in fade-in duration-300">
      
      {/* 1. Backdrop Overlay (Right Side Remains Visible With Dark Blur) */}
      <div 
        onClick={() => {
          playSoundFX('click');
          onClose();
        }}
        className="fixed inset-0 bg-[#030612]/75 backdrop-blur-sm transition-opacity"
      />

      {/* 2. Left-Side Sliding Admin Panel Drawer (Android DIYO LIVE Style) */}
      <div className="relative w-full max-w-[94vw] sm:max-w-xl md:max-w-2xl lg:max-w-4xl h-full bg-[#070b19] border-r-2 border-gradient-to-b from-purple-500/50 via-cyan-500/30 to-amber-500/50 shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-300 overflow-hidden">
        
        {/* ========================================================================= */}
        {/* A. DRAWER HEADER                                                          */}
        {/* ========================================================================= */}
        <div className="px-4 sm:px-6 py-4 bg-gradient-to-r from-[#0c142c] via-[#101938] to-[#171138] border-b border-[#1f2d52] flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
            {/* Royal Crown / Shield Icon with Gold + Purple Neon Border */}
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-400 via-pink-500 to-cyan-400 p-0.5 shadow-lg shadow-amber-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-[#070b19] rounded-[14px] flex items-center justify-center">
                <Crown className="w-6 h-6 text-amber-400 fill-amber-400 animate-pulse" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-['Outfit'] font-black text-base sm:text-lg tracking-wider text-white">
                  ADMIN PANEL
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-black text-[9px] font-mono shadow">
                  DIYO LIVE
                </span>
              </div>
              <p className="text-[11px] text-cyan-300 font-medium tracking-wide flex items-center gap-1.5">
                <span>Full Control</span>
                <span className="text-amber-400">•</span>
                <span className="text-pink-400">Better Growth</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Refresh */}
            <button
              onClick={() => {
                playSoundFX('notification');
                showToast('🔄 Admin state synchronized with DIYO LIVE cloud');
              }}
              className="p-2 rounded-xl bg-[#11192e] hover:bg-[#16203a] text-neutral-400 hover:text-white border border-[#1d2a4d] transition-colors cursor-pointer"
              title="Refresh Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* Close X Button */}
            <button
              id="btn-close-admin-drawer"
              onClick={() => {
                playSoundFX('click');
                onClose();
              }}
              className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 hover:text-white border border-rose-500/30 transition-colors cursor-pointer"
              title="Close Admin Panel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* B. DRAWER BODY: Split Layout (Left Menu Nav + Right Sub-Screen Workspace)  */}
        {/* ========================================================================= */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          
          {/* 1. LEFT ADMIN MENU LIST (Scrollable 16 Items) */}
          <div className="w-full md:w-64 lg:w-72 bg-[#080d1e] border-r border-[#16203a] p-3 flex flex-col justify-between flex-shrink-0 overflow-y-auto divide-y divide-[#131b33] pb-32 [-webkit-overflow-scrolling:touch]">
            
            <div className="space-y-1 pb-3">
              <div className="px-2 py-1.5 flex items-center justify-between text-[11px] font-bold text-neutral-400">
                <span className="uppercase tracking-wider font-mono">16 Management Modules</span>
                <span className="text-amber-400 font-mono">Rank #{currentRole === 'OWNER' ? 7 : 6}</span>
              </div>

              {/* 16 Menu Items */}
              {adminMenuItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = activeMenuId === item.id;
                return (
                  <button
                    key={item.id}
                    id={`btn-admin-menu-${item.id}`}
                    onClick={() => {
                      setActiveMenuId(item.id);
                      playSoundFX('click');
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer group ${
                      isActive
                        ? 'bg-gradient-to-r from-amber-500/20 via-purple-500/20 to-cyan-500/20 text-white border-2 border-amber-400/60 shadow-lg shadow-amber-950/40'
                        : 'text-neutral-300 hover:text-white hover:bg-[#11192e] border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {/* Colorful Rounded Icon Background */}
                      <div className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${item.color} p-0.5 flex-shrink-0 shadow-md`}>
                        <div className="w-full h-full bg-[#080d1e] rounded-[10px] flex items-center justify-center">
                          <IconComponent className={`w-4 h-4 ${item.iconColor}`} />
                        </div>
                      </div>

                      <div className="text-left truncate">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono text-neutral-500">{item.num}.</span>
                          <span className="truncate">{item.label}</span>
                        </div>
                      </div>
                    </div>

                    {/* Badge */}
                    <div className="flex items-center gap-1 flex-shrink-0 ml-1">
                      {item.badge && (
                        <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full font-bold border ${item.badgeColor}`}>
                          {item.badge}
                        </span>
                      )}
                      <ChevronRight className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400 translate-x-0.5' : 'text-neutral-600 group-hover:text-neutral-300'} transition-transform`} />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Bottom Current Role Switcher */}
            <div className="pt-3">
              <div className="p-3 rounded-2xl bg-[#0c142c] border border-[#1d2a4d] space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-[10px] text-neutral-400 font-bold">
                  <span>Authorized Role:</span>
                  <span className="text-amber-300 font-mono">{currentRole}</span>
                </div>
                <select
                  value={currentRole}
                  onChange={(e) => {
                    const newRole = e.target.value as UserRole;
                    onChangeRole(newRole);
                    playSoundFX('notification');
                    showToast(`Switched active Admin role to ${newRole}`);
                  }}
                  className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-2 py-1.5 text-xs text-white font-bold focus:outline-none focus:border-amber-400 cursor-pointer"
                >
                  <option value="OWNER">👑 Master Owner</option>
                  <option value="OFFICIAL">⭐ Official</option>
                  <option value="MANAGER">👔 Agency Manager</option>
                  <option value="SUPER_ADMIN">🛡️ Super Admin</option>
                  <option value="ADMIN">🛡️ Admin / BD</option>
                  <option value="AGENCY">🏢 Guild Agency</option>
                  <option value="COIN_SELLER">🪙 Coin Seller</option>
                  <option value="HOST">🎤 Host Dashboard</option>
                </select>
              </div>
            </div>

          </div>

          {/* 2. RIGHT MANAGEMENT WORKSPACE SCREEN */}
          <div className="flex-1 bg-[#070b19] p-4 sm:p-6 pb-36 overflow-y-auto space-y-5 min-h-0 [-webkit-overflow-scrolling:touch]">
            
            {/* ========================================================================= */}
            {/* 1. DASHBOARD OVERVIEW                                                     */}
            {/* ========================================================================= */}
            {activeMenuId === 'dashboard' && (
              <div className="space-y-5 animate-in fade-in">
                {/* Header */}
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Home className="w-5 h-5 text-cyan-400" />
                      <span>DIYO LIVE Executive Dashboard</span>
                    </h3>
                    <p className="text-xs text-neutral-400">High-performance metrics, active rooms, financial treasury & live charts.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold font-mono">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      <span>420 Live Rooms</span>
                    </span>
                  </div>
                </div>

                {/* 10 Key Metric Cards Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                  
                  {/* 1. Total Users */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg">
                    <span className="text-[10px] font-bold text-neutral-400 uppercase font-mono">Total Users</span>
                    <div className="text-lg font-black text-white font-mono mt-1">1,482,900</div>
                    <span className="text-[9px] text-emerald-400 font-bold">+12.4% this week</span>
                  </div>

                  {/* 2. Online Users */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-cyan-500/40 shadow-lg">
                    <span className="text-[10px] font-bold text-cyan-400 uppercase font-mono">Online Users</span>
                    <div className="text-lg font-black text-white font-mono mt-1">124,580</div>
                    <span className="text-[9px] text-cyan-300 font-bold">Real-time pulse</span>
                  </div>

                  {/* 3. Total Hosts */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg">
                    <span className="text-[10px] font-bold text-neutral-400 uppercase font-mono">Total Hosts</span>
                    <div className="text-lg font-black text-pink-400 font-mono mt-1">8,420</div>
                    <span className="text-[9px] text-pink-300 font-bold">4 Host categories</span>
                  </div>

                  {/* 4. Online Hosts */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-rose-500/40 shadow-lg">
                    <span className="text-[10px] font-bold text-rose-400 uppercase font-mono">Online Hosts</span>
                    <div className="text-lg font-black text-white font-mono mt-1">1,850</div>
                    <span className="text-[9px] text-rose-300 font-bold">Broadcasting live</span>
                  </div>

                  {/* 5. Total Gifts */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg">
                    <span className="text-[10px] font-bold text-amber-400 uppercase font-mono">Total Gifts</span>
                    <div className="text-lg font-black text-white font-mono mt-1">{gifts.length || 184}</div>
                    <span className="text-[9px] text-amber-300 font-bold">5 Country flags</span>
                  </div>

                  {/* 6. Total Coins */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-yellow-500/40 shadow-lg">
                    <span className="text-[10px] font-bold text-yellow-400 uppercase font-mono">Total Coins</span>
                    <div className="text-lg font-black text-yellow-300 font-mono mt-1">4.82B 🪙</div>
                    <span className="text-[9px] text-yellow-400 font-bold">Vault circulation</span>
                  </div>

                  {/* 7. Total Diamonds */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-cyan-500/40 shadow-lg">
                    <span className="text-[10px] font-bold text-cyan-400 uppercase font-mono">Total Diamonds</span>
                    <div className="text-lg font-black text-cyan-300 font-mono mt-1">1.25B 💎</div>
                    <span className="text-[9px] text-cyan-400 font-bold">Host earnings pool</span>
                  </div>

                  {/* 8. Active Live Rooms */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-emerald-500/40 shadow-lg">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase font-mono">Active Rooms</span>
                    <div className="text-lg font-black text-white font-mono mt-1">{liveRooms.length || 420}</div>
                    <span className="text-[9px] text-emerald-300 font-bold">Video & Party Live</span>
                  </div>

                  {/* 9. Agencies */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg">
                    <span className="text-[10px] font-bold text-teal-400 uppercase font-mono">Agencies</span>
                    <div className="text-lg font-black text-white font-mono mt-1">{agencies.length || 64}</div>
                    <span className="text-[9px] text-teal-300 font-bold">Guild networks</span>
                  </div>

                  {/* 10. Sellers */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-purple-500/40 shadow-lg">
                    <span className="text-[10px] font-bold text-purple-400 uppercase font-mono">Coin Sellers</span>
                    <div className="text-lg font-black text-white font-mono mt-1">38</div>
                    <span className="text-[9px] text-purple-300 font-bold">Official merchants</span>
                  </div>

                </div>

                {/* HD Statistics and Charts Section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  
                  {/* Revenue & Growth Chart Card */}
                  <div className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <TrendingUp className="w-4 h-4 text-emerald-400" />
                        <span>Daily Platform Revenue & Coin Sales (7 Days)</span>
                      </span>
                      <span className="text-[10px] text-amber-300 font-mono font-bold">$184,520 USD</span>
                    </div>

                    {/* Chart Bar Visualization */}
                    <div className="h-32 flex items-end gap-2 pt-4 px-2 border-b border-[#16203a]">
                      {[
                        { day: 'Mon', coins: 65, fill: 'from-cyan-500 to-blue-600' },
                        { day: 'Tue', coins: 82, fill: 'from-cyan-500 to-blue-600' },
                        { day: 'Wed', coins: 74, fill: 'from-cyan-500 to-blue-600' },
                        { day: 'Thu', coins: 90, fill: 'from-cyan-500 to-blue-600' },
                        { day: 'Fri', coins: 110, fill: 'from-amber-400 to-pink-500' },
                        { day: 'Sat', coins: 135, fill: 'from-amber-400 to-pink-500' },
                        { day: 'Sun', coins: 150, fill: 'from-amber-400 to-yellow-500' }
                      ].map((bar, idx) => (
                        <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group">
                          <div 
                            style={{ height: `${(bar.coins / 150) * 100}%` }}
                            className={`w-full rounded-t-lg bg-gradient-to-t ${bar.fill} transition-all group-hover:brightness-125 shadow`}
                          />
                          <span className="text-[9px] text-neutral-400 font-mono">{bar.day}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-neutral-400">
                      <span>Average Daily Users: <strong>1.4M Active</strong></span>
                      <span className="text-emerald-400"><strong>+24.6%</strong> Net Retention</span>
                    </div>
                  </div>

                  {/* Active Streams & Live Broadcasters Feed */}
                  <div className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
                        <span>Live Broadcasts & 20-Seat Lounges</span>
                      </span>
                      <button
                        onClick={() => setActiveMenuId('live_rooms')}
                        className="text-[10px] text-cyan-400 font-bold hover:underline"
                      >
                        Manage All
                      </button>
                    </div>

                    <div className="space-y-2 max-h-36 overflow-y-auto pr-1 divide-y divide-[#16203a]">
                      {(hosts.slice(0, 4) || []).map((h) => (
                        <div key={h.id} className="pt-2 first:pt-0 flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2 min-w-0">
                            <img src={h.avatar} alt={h.name} className="w-7 h-7 rounded-full object-cover border border-pink-500" />
                            <div className="truncate">
                              <div className="font-bold text-white truncate">{h.name}</div>
                              <span className="text-[10px] text-neutral-400 font-mono">ID: {h.id} • {h.agencyName || 'Apex Guild'}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <HostTagBadge tag={h.hostTag || 'CELEBRATE'} size="sm" />
                            <span className="text-[10px] font-mono text-emerald-400 font-bold">1.2K 👥</span>
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>

                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 2. USER MANAGEMENT                                                        */}
            {/* ========================================================================= */}
            {activeMenuId === 'users' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Users className="w-5 h-5 text-indigo-400" />
                      <span>User Management & VIP Accounts</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Search users, inspect VIP levels, coin/diamond balances, block, mute & verify accounts.</p>
                  </div>
                </div>

                {/* Toolbar */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                  <div className="relative w-full sm:w-72">
                    <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search User ID, Name, Username..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-[#0c142c] border border-[#1d2a4d] rounded-xl pl-8 pr-3 py-2 text-white placeholder-neutral-500 focus:outline-none focus:border-indigo-400"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
                    {['ALL', 'ACTIVE', 'MUTED', 'BANNED'].map((st) => (
                      <button
                        key={st}
                        onClick={() => setSelectedUserFilter(st as any)}
                        className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                          selectedUserFilter === st
                            ? 'bg-indigo-600 text-white shadow'
                            : 'bg-[#0c142c] text-neutral-400 hover:text-white border border-[#1d2a4d]'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Users Table / Cards */}
                <div className="bg-[#0c142c] border border-[#1d2a4d] rounded-3xl overflow-hidden shadow-xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#080d1e] text-neutral-400 uppercase text-[10px] font-bold border-b border-[#1d2a4d]">
                        <tr>
                          <th className="p-3.5">User Profile & ID</th>
                          <th className="p-3.5">VIP Tier</th>
                          <th className="p-3.5">Country</th>
                          <th className="p-3.5">Coins Balance</th>
                          <th className="p-3.5">Diamonds</th>
                          <th className="p-3.5">Social</th>
                          <th className="p-3.5">Status</th>
                          <th className="p-3.5 text-right">Admin Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#16203a] text-neutral-200">
                        {users
                          .filter((u) => {
                            const matchFilter = selectedUserFilter === 'ALL' || u.status?.toUpperCase() === selectedUserFilter;
                            const matchQuery =
                              !searchQuery ||
                              u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                              u.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                              (u.username && u.username.toLowerCase().includes(searchQuery.toLowerCase()));
                            return matchFilter && matchQuery;
                          })
                          .map((u) => (
                            <tr key={u.id} className="hover:bg-[#11192e]/60 transition-colors">
                              <td className="p-3.5">
                                <div className="flex items-center gap-2.5">
                                  <HostAvatarWithFrame
                                    avatarUrl={u.avatar}
                                    frameId={u.avatarFrameId}
                                    frameUrl={u.avatarFrameUrl}
                                    role={u.role}
                                    hostTag={u.hostTag}
                                    vipLevel={u.vipLevel}
                                    size="xs"
                                  />
                                  <div>
                                    <div className="font-bold text-white flex items-center gap-1">
                                      <span>{u.name}</span>
                                      {u.isVerified && <CheckCircle2 className="w-3 h-3 text-cyan-400" />}
                                    </div>
                                    <span className="text-[10px] text-neutral-400 font-mono">ID: {u.id}</span>
                                  </div>
                                </div>
                              </td>

                              <td className="p-3.5">
                                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-black text-[10px] border border-amber-500/40">
                                  VIP {u.vipLevel || 8}
                                </span>
                              </td>

                              <td className="p-3.5">
                                <span className="text-base" title={u.countryName || 'India'}>
                                  {u.countryFlag || '🇮🇳'}
                                </span>
                              </td>

                              <td className="p-3.5 font-mono font-bold text-yellow-400">
                                {(u.coinBalance || 0).toLocaleString()} 🪙
                              </td>

                              <td className="p-3.5 font-mono font-bold text-cyan-300">
                                {(u.diamondBalance || 0).toLocaleString()} 💎
                              </td>

                              <td className="p-3.5 text-[10px] text-neutral-400 font-mono">
                                <span>{u.followingCount || 7} Follow / {u.followersCount || 8} Fans</span>
                              </td>

                              <td className="p-3.5">
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  u.status === 'Banned'
                                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                    : u.status === 'Muted'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                }`}>
                                  {u.status || 'Active'}
                                </span>
                              </td>

                              <td className="p-3.5 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  {/* Inject / Adjust Coins */}
                                  <button
                                    onClick={() => setAdjustCoinUser(u)}
                                    className="p-1.5 rounded-lg bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-300 border border-yellow-500/30 transition-colors"
                                    title="Adjust Coins"
                                  >
                                    <Coins className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Verify Toggle */}
                                  <button
                                    onClick={() => handleToggleVerifyUser(u.id)}
                                    className="p-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition-colors"
                                    title="Toggle Verification Badge"
                                  >
                                    <ShieldCheck className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Block / Unblock */}
                                  <button
                                    onClick={() => handleToggleBlockUser(u.id)}
                                    className={`p-1.5 rounded-lg transition-colors border ${
                                      u.status === 'Banned'
                                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                                        : 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border-rose-500/30'
                                    }`}
                                    title={u.status === 'Banned' ? 'Unblock User' : 'Block User'}
                                  >
                                    <Ban className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 3. HOST MANAGEMENT (4 Colored Tags: Normal, Celebrate, Talent, Singer)    */}
            {/* ========================================================================= */}
            {activeMenuId === 'hosts' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <User className="w-5 h-5 text-pink-400" />
                      <span>Host Management & Category Tags</span>
                    </h3>
                    <p className="text-xs text-neutral-400">
                      Manage stream creators across 4 official tags (Normal, Celebrate, Talent, Singer) + Verified badges.
                    </p>
                  </div>
                </div>

                {/* Host Category Tag Filter Pills */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {[
                    { id: 'ALL', label: 'All Hosts' },
                    { id: 'NORMAL', label: 'Normal Host', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' },
                    { id: 'CELEBRATE', label: 'Celebrate Host', color: 'text-pink-400 bg-pink-500/10 border-pink-500/30' },
                    { id: 'TALENT', label: 'Talent Host', color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30' },
                    { id: 'SINGER', label: 'Singer Host', color: 'text-purple-400 bg-purple-500/10 border-purple-500/30' },
                    { id: 'VERIFIED', label: 'Verified Creator', color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' }
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedHostTagFilter(cat.id)}
                      className={`px-3 py-1.5 rounded-2xl text-xs font-bold border transition-all whitespace-nowrap cursor-pointer ${
                        selectedHostTagFilter === cat.id
                          ? 'bg-pink-600 text-white border-pink-400 shadow-md'
                          : 'bg-[#0c142c] text-neutral-300 border-[#1d2a4d] hover:text-white'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Hosts Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {hosts
                    .filter((h) => {
                      if (selectedHostTagFilter === 'ALL') return true;
                      if (selectedHostTagFilter === 'VERIFIED') return h.verificationStatus?.includes('Verified');
                      return h.hostTag === selectedHostTagFilter;
                    })
                    .map((h) => (
                      <div
                        key={h.id}
                        className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg space-y-3"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <HostAvatarWithFrame
                              avatarUrl={h.avatar}
                              frameId="FRM-CYBER-NEON"
                              role="HOST"
                              hostTag={h.hostTag || 'CELEBRATE'}
                              size="md"
                              isLive={h.liveStatus === 'Live'}
                            />
                            <div>
                              <div className="flex items-center gap-1.5">
                                <h4 className="font-bold text-white text-sm">{h.name}</h4>
                                <span className="text-[10px] text-neutral-400 font-mono">({h.id})</span>
                              </div>
                              <p className="text-[11px] text-neutral-400">{h.agencyName || 'Apex Royalty Guild'}</p>
                              <div className="mt-1">
                                <HostTagBadge tag={h.hostTag || 'CELEBRATE'} size="sm" />
                              </div>
                            </div>
                          </div>

                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            h.liveStatus === 'Live'
                              ? 'bg-rose-600 text-white animate-pulse shadow'
                              : 'bg-neutral-800 text-neutral-400'
                          }`}>
                            {h.liveStatus === 'Live' ? '🔴 Live Now' : 'Off-Air'}
                          </span>
                        </div>

                        {/* Host Metrics Bar */}
                        <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-[#16203a] text-xs">
                          <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                            <span className="text-[10px] text-neutral-400 block font-mono">Live Hours</span>
                            <span className="font-black text-white font-mono">{h.totalLiveHours || 142} hrs</span>
                          </div>
                          <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                            <span className="text-[10px] text-neutral-400 block font-mono">Diamonds</span>
                            <span className="font-black text-cyan-300 font-mono">{(h.diamonds || 48500).toLocaleString()} 💎</span>
                          </div>
                          <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                            <span className="text-[10px] text-neutral-400 block font-mono">Followers</span>
                            <span className="font-black text-pink-300 font-mono">{h.followers || 1240}</span>
                          </div>
                        </div>

                        {/* Tag Switcher Bar */}
                        <div className="flex items-center justify-between pt-1 text-xs">
                          <span className="text-[10px] text-neutral-400 font-bold">Assign Host Tag:</span>
                          <div className="flex items-center gap-1">
                            {(['NORMAL', 'CELEBRATE', 'TALENT', 'SINGER'] as HostTagType[]).map((tag) => (
                              <button
                                key={tag}
                                onClick={() => handleAssignHostTag(h.id, tag)}
                                className={`px-2 py-0.5 rounded-lg text-[9px] font-bold border transition-colors cursor-pointer ${
                                  h.hostTag === tag
                                    ? 'bg-pink-500 text-white border-pink-400'
                                    : 'bg-[#11192e] text-neutral-400 border-[#1d2a4d] hover:text-white'
                                }`}
                              >
                                {tag}
                              </button>
                            ))}
                          </div>
                        </div>

                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 4. GIFT MANAGEMENT (Flags: 🇳🇵, 🇮🇳, 🇧🇩, 🇵🇰, 🇵🇭 + Add/Edit Gifts)            */}
            {/* ========================================================================= */}
            {activeMenuId === 'gifts' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Gift className="w-5 h-5 text-amber-400" />
                      <span>Gift Management & National Flags</span>
                    </h3>
                    <p className="text-xs text-neutral-400">
                      Gifts catalog, animated SFX, coin pricing, diamond payouts, and Nepal 🇳🇵, India 🇮🇳, Bangladesh 🇧🇩, Pakistan 🇵🇰, Philippines 🇵🇭.
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      playSoundFX('click');
                      showToast('➕ New Gift Creation Studio Opened');
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-black text-xs flex items-center gap-1.5 shadow"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Gift</span>
                  </button>
                </div>

                {/* Category Filters */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                  {['ALL', 'POPULAR', 'FLAGS', 'VIP', 'SPECIAL', 'LUCKY', 'RED PACKET'].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedGiftCategoryFilter(cat)}
                      className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
                        selectedGiftCategoryFilter === cat
                          ? 'bg-amber-500 text-neutral-950 font-black shadow'
                          : 'bg-[#0c142c] text-neutral-400 hover:text-white border border-[#1d2a4d]'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Gifts Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {gifts
                    .filter((g) => selectedGiftCategoryFilter === 'ALL' || g.category?.toUpperCase() === selectedGiftCategoryFilter)
                    .map((g) => (
                      <div
                        key={g.id}
                        className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg flex flex-col justify-between group hover:border-amber-500/40 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-mono uppercase text-amber-300 px-1.5 py-0.5 rounded bg-amber-500/20">
                            {g.category || 'POPULAR'}
                          </span>
                          <button
                            onClick={() => handleToggleGift(g.id)}
                            className={`text-[10px] font-bold cursor-pointer ${g.isActive ? 'text-emerald-400' : 'text-neutral-500'}`}
                          >
                            {g.isActive ? 'Active' : 'Disabled'}
                          </button>
                        </div>

                        {/* Gift Icon Display */}
                        <div className="py-4 text-center">
                          <span className="text-4xl group-hover:scale-125 transition-transform duration-300 inline-block drop-shadow-md">
                            {g.icon}
                          </span>
                          <h4 className="font-bold text-white text-xs mt-2 truncate">{g.name}</h4>
                        </div>

                        {/* Price & Value */}
                        <div className="pt-2 border-t border-[#16203a] flex items-center justify-between text-xs font-mono">
                          <span className="text-yellow-400 font-bold">{g.coinPrice} 🪙</span>
                          <span className="text-cyan-300 font-bold">{g.diamondValue} 💎</span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 5. GAME MANAGEMENT (Teen Patti, 777 Slots, Fruit Roulette, Greedy, Aviator)*/}
            {/* ========================================================================= */}
            {activeMenuId === 'games' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Gamepad2 className="w-5 h-5 text-emerald-400" />
                      <span>Game Management & Bet Control Engine</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Configure house edges, RTP limits, bet sliders, active games & live histories.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {[
                    { id: 'teen_patti', name: 'Teen Patti Royal', icon: '🃏', rtp: '97.5%', bets: '100 - 50,000', active: true },
                    { id: 'slots_777', name: '777 Vegas Slots', icon: '🎰', rtp: '96.2%', bets: '50 - 100,000', active: true },
                    { id: 'fruit_roulette', name: 'Fruit Roulette 3D', icon: '🍉', rtp: '98.0%', bets: '200 - 75,000', active: true },
                    { id: 'greedy_box', name: 'Greedy Box Hunter', icon: '💎', rtp: '95.8%', bets: '500 - 250,000', active: true },
                    { id: 'lucky_wheel', name: 'Lucky Fortune Wheel', icon: '🎡', rtp: '96.5%', bets: '100 - 20,000', active: true },
                    { id: 'aviator', name: 'Aviator Turbo Rocket', icon: '🚀', rtp: '97.0%', bets: '100 - 50,000', active: true }
                  ].map((gm) => (
                    <div key={gm.id} className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <span className="text-3xl">{gm.icon}</span>
                          <div>
                            <h4 className="font-bold text-white text-xs">{gm.name}</h4>
                            <span className="text-[10px] text-emerald-400 font-mono">RTP: {gm.rtp}</span>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[9px] border border-emerald-500/30">
                          Active
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-[#080d1e] border border-[#16203a] text-xs space-y-1">
                        <div className="flex items-center justify-between text-neutral-400 text-[10px]">
                          <span>Bet Limits:</span>
                          <span className="text-yellow-400 font-mono font-bold">{gm.bets} 🪙</span>
                        </div>
                        <div className="flex items-center justify-between text-neutral-400 text-[10px]">
                          <span>House Margin:</span>
                          <span className="text-cyan-300 font-mono font-bold">2.5%</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => showToast(`🎮 Settings updated for ${gm.name}`)}
                          className="flex-1 py-1.5 rounded-xl bg-[#11192e] hover:bg-[#16203a] text-neutral-300 hover:text-white text-[11px] font-bold border border-[#1d2a4d] transition-colors cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Sliders className="w-3 h-3" />
                          <span>Configure</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 6. LIVE ROOM CONTROL (Mute, Remove User, End Live, Moderation)             */}
            {/* ========================================================================= */}
            {activeMenuId === 'live_rooms' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Radio className="w-5 h-5 text-rose-500" />
                      <span>Live Room Control & Broadcast Moderation</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Real-time room monitoring, spectator mutes, user kickout, and instant emergency termination.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {liveRooms.map((room) => (
                    <div key={room.id} className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img src={room.hostAvatar} alt={room.hostName} className="w-10 h-10 rounded-2xl object-cover border border-rose-500" />
                          <div>
                            <h4 className="font-bold text-white text-xs">{room.title}</h4>
                            <p className="text-[11px] text-neutral-400">{room.hostName} • ID: {room.id}</p>
                          </div>
                        </div>

                        <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white font-bold text-[10px] animate-pulse">
                          🔴 LIVE ({room.currentViewers} 👥)
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center text-xs">
                        <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                          <span className="text-[10px] text-neutral-400 block font-mono">Gifts</span>
                          <span className="font-black text-amber-400 font-mono">{room.totalGiftsCoinValue.toLocaleString()} 🪙</span>
                        </div>
                        <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                          <span className="text-[10px] text-neutral-400 block font-mono">Category</span>
                          <span className="font-black text-cyan-300 uppercase font-mono">{room.category}</span>
                        </div>
                        <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                          <span className="text-[10px] text-neutral-400 block font-mono">Status</span>
                          <span className="font-black text-emerald-400 font-mono">Healthy</span>
                        </div>
                      </div>

                      {/* Admin Room Control Actions */}
                      <div className="grid grid-cols-3 gap-2 pt-1">
                        <button
                          onClick={() => showToast(`🔇 Room ${room.id} chat muted for 5 minutes`)}
                          className="py-1.5 rounded-xl bg-[#11192e] hover:bg-[#16203a] text-neutral-300 hover:text-white text-[11px] font-bold border border-[#1d2a4d] transition-colors flex items-center justify-center gap-1"
                        >
                          <VolumeX className="w-3 h-3" />
                          <span>Mute Chat</span>
                        </button>
                        <button
                          onClick={() => showToast(`⚠️ Warning dispatched to room ${room.id}`)}
                          className="py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-[11px] font-bold border border-amber-500/30 transition-colors flex items-center justify-center gap-1"
                        >
                          <AlertTriangle className="w-3 h-3" />
                          <span>Warn Room</span>
                        </button>
                        <button
                          onClick={() => handleEndLiveRoom(room.id)}
                          className="py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-white text-[11px] font-bold border border-rose-500/40 transition-colors flex items-center justify-center gap-1"
                        >
                          <Ban className="w-3 h-3" />
                          <span>End Live</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 7. COIN & WALLET (User, Host, Admin Wallet & Direct Balances)              */}
            {/* ========================================================================= */}
            {activeMenuId === 'wallet' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Coins className="w-5 h-5 text-yellow-400" />
                      <span>Coin & Treasury Wallet Management</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Admin reserve pool, platform liquidity, exchange rate controls & direct adjustments.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-yellow-500/40 shadow-xl space-y-1">
                    <span className="text-[10px] font-bold text-yellow-400 uppercase font-mono">Admin Master Vault</span>
                    <div className="text-2xl font-black text-yellow-300 font-mono">500,000,000 🪙</div>
                    <p className="text-[10px] text-neutral-400">Available reserve for test & seller distribution</p>
                  </div>
                  <div className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-cyan-500/40 shadow-xl space-y-1">
                    <span className="text-[10px] font-bold text-cyan-400 uppercase font-mono">Host Diamond Vault</span>
                    <div className="text-2xl font-black text-cyan-300 font-mono">1,250,000,000 💎</div>
                    <p className="text-[10px] text-neutral-400">Diamond earnings pool for creator cashouts</p>
                  </div>
                  <div className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-emerald-500/40 shadow-xl space-y-1">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase font-mono">User Circulating Balance</span>
                    <div className="text-2xl font-black text-emerald-300 font-mono">4,820,000,000 🪙</div>
                    <p className="text-[10px] text-neutral-400">Held in consumer viewer balances</p>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 8. TRANSACTION RECORDS (Filterable audit logs)                             */}
            {/* ========================================================================= */}
            {activeMenuId === 'transactions' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <FileText className="w-5 h-5 text-cyan-400" />
                      <span>Transaction Records & Financial Audit</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Filter by User, Host, Gift, Recharge, Coin transfers, and transaction IDs.</p>
                  </div>
                </div>

                <div className="bg-[#0c142c] border border-[#1d2a4d] rounded-3xl overflow-hidden shadow-xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#080d1e] text-neutral-400 uppercase text-[10px] font-bold border-b border-[#1d2a4d]">
                        <tr>
                          <th className="p-3.5">Tx ID & Date</th>
                          <th className="p-3.5">Type</th>
                          <th className="p-3.5">Sender</th>
                          <th className="p-3.5">Recipient</th>
                          <th className="p-3.5">Amount</th>
                          <th className="p-3.5">Channel</th>
                          <th className="p-3.5 text-right">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#16203a] text-neutral-200">
                        {transactions.slice(0, 15).map((tx) => (
                          <tr key={tx.id} className="hover:bg-[#11192e]/60 transition-colors">
                            <td className="p-3.5 font-mono">
                              <div className="font-bold text-white">{tx.id}</div>
                              <span className="text-[10px] text-neutral-400">{tx.timestamp}</span>
                            </td>
                            <td className="p-3.5">
                              <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[9px] font-bold">
                                {tx.type}
                              </span>
                            </td>
                            <td className="p-3.5 text-neutral-300">{tx.senderName || tx.senderId || 'Platform'}</td>
                            <td className="p-3.5 text-neutral-300">{tx.recipientName || tx.recipientId || 'Recipient'}</td>
                            <td className="p-3.5 font-mono font-bold text-yellow-400">
                              {tx.amountCoins ? `${tx.amountCoins.toLocaleString()} 🪙` : `${tx.amountDiamonds?.toLocaleString()} 💎`}
                            </td>
                            <td className="p-3.5 text-[11px] text-neutral-400">{tx.paymentChannel || 'In-App'}</td>
                            <td className="p-3.5 text-right">
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px] border border-emerald-500/30">
                                {tx.status || 'Completed'}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 9. TASK & REWARD / DAILY MISSIONS                                         */}
            {/* ========================================================================= */}
            {activeMenuId === 'tasks' && (
              <div className="space-y-5 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-purple-400" />
                      <span>Daily Mission & Task Reward System</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Create and set daily missions for users and broadcasters to complete for coin & diamond rewards.</p>
                  </div>
                </div>

                {/* Create New Daily Mission Form */}
                <form onSubmit={handleCreateMission} className="p-4 rounded-3xl bg-[#0c142c] border border-purple-500/40 shadow-xl space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center justify-center font-bold text-xs">
                      🎯
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-xs">Publish New Daily Mission / Quest</h4>
                      <p className="text-[10px] text-neutral-400">Set completion rules and coin rewards for community users or broadcasters.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-neutral-300 mb-1">Mission Title</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Share Live Stream"
                        value={missionTitle}
                        onChange={(e) => setMissionTitle(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-purple-400"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-neutral-300 mb-1">Mission Category</label>
                      <select
                        value={missionType}
                        onChange={(e) => setMissionType(e.target.value as any)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white font-bold text-xs focus:outline-none focus:border-purple-400"
                      >
                        <option value="User Daily">User Daily Quest</option>
                        <option value="Host Milestone">Host Live Milestone</option>
                        <option value="Viewer Event">Viewer Event Task</option>
                        <option value="Games Quest">Games & Arcade Quest</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-neutral-300 mb-1">Coin / Reward Amount</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 5,000 Coins / 500 Diamonds"
                        value={missionReward}
                        onChange={(e) => setMissionReward(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white text-xs font-mono focus:outline-none focus:border-purple-400"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-neutral-300 mb-1">Completion Rule / Requirement</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Share stream to 3 groups"
                        value={missionRequirement}
                        onChange={(e) => setMissionRequirement(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-purple-400"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-black text-xs shadow-lg shadow-purple-950/50 hover:brightness-110 transition-all cursor-pointer flex items-center gap-2"
                    >
                      <span>🚀 Publish Daily Mission</span>
                    </button>
                  </div>
                </form>

                {/* Missions List */}
                <div className="space-y-3">
                  <h4 className="font-bold text-white text-sm">Active Daily Missions & Quests ({dailyMissionsList.length})</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {dailyMissionsList.map((tsk, idx) => (
                      <div key={idx} className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">{tsk.type}</span>
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">Active</span>
                        </div>
                        <h4 className="font-bold text-white text-xs">{tsk.title}</h4>
                        <p className="text-[11px] text-neutral-400">{tsk.requirement}</p>
                        <div className="pt-2 border-t border-[#16203a] flex items-center justify-between text-xs">
                          <span className="text-yellow-400 font-bold font-mono">Reward: {tsk.reward}</span>
                          <button
                            onClick={() => showToast(`Task reward settings updated for "${tsk.title}"`)}
                            className="text-[10px] text-cyan-400 font-bold hover:underline cursor-pointer"
                          >
                            Edit Task
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 10. AGENCY MANAGEMENT                                                     */}
            {/* ========================================================================= */}
            {activeMenuId === 'agencies' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Building2 className="w-5 h-5 text-teal-400" />
                      <span>Agency Guilds & Commission Management</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Review agency managers, onboarded host rosters, performance scores & revenue cuts.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {agencies.map((ag) => (
                    <div key={ag.id} className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <img src={ag.logo} alt={ag.name} className="w-10 h-10 rounded-2xl object-cover border border-teal-500" />
                          <div>
                            <h4 className="font-bold text-white text-xs">{ag.name}</h4>
                            <span className="text-[10px] text-neutral-400 font-mono">Code: {ag.code} • {ag.ownerOrManager}</span>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                          {ag.status || 'Active'}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center text-xs">
                        <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                          <span className="text-[10px] text-neutral-400 block font-mono">Hosts</span>
                          <span className="font-black text-white font-mono">{ag.numberOfHosts || 12}</span>
                        </div>
                        <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                          <span className="text-[10px] text-neutral-400 block font-mono">Commission</span>
                          <span className="font-black text-amber-400 font-mono">{ag.commissionRate || 15}%</span>
                        </div>
                        <div className="p-2 rounded-xl bg-[#080d1e] border border-[#16203a]">
                          <span className="text-[10px] text-neutral-400 block font-mono">Performance</span>
                          <span className="font-black text-cyan-300 font-mono">{ag.hostPerformanceScore || 95}/100</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* STAFF HIRING & ROLES MANAGEMENT                                            */}
            {/* ========================================================================= */}
            {activeMenuId === 'hiring_staff' && (
              <div className="space-y-5 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <UserCheck className="w-5 h-5 text-emerald-400" />
                      <span>Executive Staff Hiring & Role Onboarding Portal</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Hire and provision Official, Manager, Super Admin, BD Agency, Agency, and Coin Seller accounts.</p>
                  </div>
                </div>

                {/* Hire / Add Staff Form Card */}
                <form onSubmit={handleHireSubmit} className="p-5 rounded-3xl bg-[#0c142c] border border-emerald-500/40 shadow-xl space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center justify-center font-bold">
                      ➕
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-sm">Hire New Official / Staff / Partner</h4>
                      <p className="text-[11px] text-neutral-400">Select target role and configure credentials & permissions instantly.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-neutral-300 mb-1">Select Role to Hire / Add</label>
                      <select
                        value={hireRole}
                        onChange={(e) => setHireRole(e.target.value as any)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white font-bold text-xs focus:outline-none focus:border-emerald-400"
                      >
                        <option value="OFFICIAL">⭐ Official (Platform Staff)</option>
                        <option value="MANAGER">👔 Talent Manager</option>
                        <option value="SUPER_ADMIN">🛡️ Super Admin</option>
                        <option value="ADMIN_BD">💼 BD Agency / Business Dev</option>
                        <option value="AGENCY">🏢 Partner Guild Agency</option>
                        <option value="COIN_SELLER">🪙 Authorized Coin Seller</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-neutral-300 mb-1">Full Name / Agency Name</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Alok Verma / Apex Guild"
                        value={hireName}
                        onChange={(e) => setHireName(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-400"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-neutral-300 mb-1">Username / Guild Code</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. alok_official"
                        value={hireUsername}
                        onChange={(e) => setHireUsername(e.target.value.toLowerCase().replace(/\s+/g, '_'))}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white text-xs font-mono focus:outline-none focus:border-emerald-400"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-neutral-300 mb-1">Email Address</label>
                      <input
                        type="email"
                        placeholder="staff@sr.live"
                        value={hireEmail}
                        onChange={(e) => setHireEmail(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-400"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-neutral-300 mb-1">Phone Number</label>
                      <input
                        type="text"
                        placeholder="+91 9876543210"
                        value={hirePhone}
                        onChange={(e) => setHirePhone(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-400"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-neutral-300 mb-1">Initial Coin / Commission Allocation</label>
                      <input
                        type="text"
                        placeholder="e.g. 5,000,000 Coins / 20%"
                        value={hireAllocation}
                        onChange={(e) => setHireAllocation(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white text-xs font-mono focus:outline-none focus:border-emerald-400"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-neutral-950 font-black text-xs shadow-lg shadow-emerald-950/50 hover:brightness-110 transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <span>🚀 Hire & Provision Account</span>
                    </button>
                  </div>
                </form>

                {/* Hired Staff Directory List */}
                <div className="space-y-3">
                  <h4 className="font-bold text-white text-sm">Active Hired Staff & Partners Roster ({hiredStaffList.length})</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {hiredStaffList.map((staff) => (
                      <div key={staff.id} className="p-4 rounded-2xl bg-[#0c142c] border border-[#1d2a4d] shadow-lg flex items-center justify-between gap-3 text-xs">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{staff.name}</span>
                            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold border border-emerald-500/30">
                              {staff.role}
                            </span>
                          </div>
                          <p className="text-[11px] text-neutral-400 font-mono">ID: {staff.id} • @{staff.username}</p>
                          <p className="text-[10px] text-neutral-500">Email: {staff.email} • Hired: {staff.date}</p>
                        </div>
                        <div className="text-right">
                          <span className="inline-block px-2.5 py-1 rounded-xl bg-cyan-500/15 text-cyan-300 font-mono text-[10px] font-bold border border-cyan-500/30">
                            {staff.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 11. SYSTEM SETTINGS                                                       */}
            {/* ========================================================================= */}
            {activeMenuId === 'settings' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Settings className="w-5 h-5 text-slate-300" />
                      <span>DIYO LIVE System Governance & Config</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Maintenance mode, video encoding thresholds, live servers & security policies.</p>
                  </div>
                </div>

                <div className="p-4 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-[#1d2a4d] shadow-xl space-y-4 text-xs">
                  <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                    <div>
                      <span className="font-bold text-white block">Maintenance Mode</span>
                      <p className="text-[10px] text-neutral-400">Lock app for non-admin viewers during scheduled upgrades.</p>
                    </div>
                    <button
                      onClick={() => showToast('Maintenance Mode toggled')}
                      className="px-3 py-1 rounded-full bg-[#11192e] text-neutral-400 hover:text-white font-bold border border-[#1d2a4d]"
                    >
                      Disabled
                    </button>
                  </div>

                  <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                    <div>
                      <span className="font-bold text-white block">TDS / Platform Withholding Tax</span>
                      <p className="text-[10px] text-neutral-400">Standard creator cashout taxation compliance.</p>
                    </div>
                    <span className="font-mono font-bold text-amber-400">5.0% - 10.0%</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white block">Live Stream Max Bitrate</span>
                      <p className="text-[10px] text-neutral-400">4K AV1 & 1080p 60FPS Low-Latency Ingress</p>
                    </div>
                    <span className="font-mono font-bold text-cyan-300">8,500 kbps</span>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 12. REPORTS & ANALYTICS                                                   */}
            {/* ========================================================================= */}
            {activeMenuId === 'reports_analytics' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-violet-400" />
                      <span>HD Reports, Live Hours & Revenue Analytics</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Granular breakdowns of daily users, new registrations, live hours streamed, and gifts.</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="p-3.5 rounded-2xl bg-[#0c142c] border border-[#1d2a4d]">
                    <span className="text-[10px] text-neutral-400 block font-mono">Daily Active (DAU)</span>
                    <span className="text-lg font-black text-white font-mono">1,482,900</span>
                  </div>
                  <div className="p-3.5 rounded-2xl bg-[#0c142c] border border-[#1d2a4d]">
                    <span className="text-[10px] text-neutral-400 block font-mono">Total Live Hours</span>
                    <span className="text-lg font-black text-pink-400 font-mono">248,500 hrs</span>
                  </div>
                  <div className="p-3.5 rounded-2xl bg-[#0c142c] border border-[#1d2a4d]">
                    <span className="text-[10px] text-neutral-400 block font-mono">Total Gifts Exchanged</span>
                    <span className="text-lg font-black text-amber-400 font-mono">42.8M 🎁</span>
                  </div>
                  <div className="p-3.5 rounded-2xl bg-[#0c142c] border border-[#1d2a4d]">
                    <span className="text-[10px] text-neutral-400 block font-mono">Monthly Revenue</span>
                    <span className="text-lg font-black text-emerald-400 font-mono">$4,850,200</span>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 13. CONTENT MODERATION                                                    */}
            {/* ========================================================================= */}
            {activeMenuId === 'moderation' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-red-400" />
                      <span>Content Moderation & Incident Reports</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Stream violations, inappropriate chats, toxic actor bans & report resolutions.</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {reports.map((rep) => (
                    <div key={rep.id} className="p-4 rounded-3xl bg-[#0c142c] border border-[#1d2a4d] shadow-lg flex items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{rep.targetName}</span>
                          <span className="text-[10px] text-neutral-400 font-mono">Reported by: {rep.reportedByName}</span>
                          <span className="px-2 py-0.2 rounded-full bg-rose-500/20 text-rose-300 text-[9px] font-bold">
                            {rep.reason}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-400 mt-1">{rep.notes || 'Automated AI flag triggered for chat moderation.'}</p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => showToast(`Report ${rep.id} marked resolved`)}
                          className="px-3 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow"
                        >
                          Resolve
                        </button>
                        <button
                          onClick={() => showToast(`Report ${rep.id} dismissed`)}
                          className="px-3 py-1 rounded-xl bg-[#11192e] text-neutral-400 hover:text-white font-bold text-xs border border-[#1d2a4d]"
                        >
                          Dismiss
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 14. VIP & LEVEL MATRIX                                                    */}
            {/* ========================================================================= */}
            {activeMenuId === 'vip_level' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Award className="w-5 h-5 text-amber-300" />
                      <span>VIP 1–VIP 8 Nobility Matrix & Level Privileges</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Unlock requirements, custom neon frames, anti-kick guards & entrance effects.</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((lvl) => (
                    <div key={lvl} className="p-3.5 rounded-3xl bg-gradient-to-b from-[#0c142c] to-[#080d1d] border border-amber-500/40 shadow-lg text-center space-y-2">
                      <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-black border border-amber-500/40">
                        <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                        <span>VIP {lvl}</span>
                      </div>
                      <span className="text-[10px] text-neutral-400 block font-mono">Requirement: {(lvl * 50000).toLocaleString()} 🪙</span>
                      <p className="text-[10px] text-cyan-300 font-bold">
                        {lvl >= 7 ? '👑 Supreme Crown + Anti-Kick' : lvl >= 4 ? '✨ Gold Entry + Custom Frame' : '💬 Noble Chat Badge'}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 15. NOTICE & MESSAGE (System Announcements & Broadcasts)                  */}
            {/* ========================================================================= */}
            {activeMenuId === 'notices' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <Bell className="w-5 h-5 text-blue-300" />
                      <span>Notice & Push Announcement Broadcast Center</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Dispatch system banners, host notifications, and targeted push alerts.</p>
                  </div>

                  <button
                    onClick={() => setIsCreateNoticeOpen(!isCreateNoticeOpen)}
                    className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Create Notice</span>
                  </button>
                </div>

                {/* Create Notice Form Drawer Card */}
                {isCreateNoticeOpen && (
                  <form onSubmit={handleSendNotice} className="p-4 rounded-3xl bg-[#0c142c] border border-blue-500/40 shadow-xl space-y-3 text-xs animate-in fade-in">
                    <h4 className="font-bold text-white">Broadcast New Push Notification</h4>
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="Announcement Title..."
                        value={newNoticeTitle}
                        onChange={(e) => setNewNoticeTitle(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white placeholder-neutral-500 focus:outline-none focus:border-blue-400"
                        required
                      />
                      <textarea
                        placeholder="Message Body / Announcement Details..."
                        value={newNoticeBody}
                        onChange={(e) => setNewNoticeBody(e.target.value)}
                        className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white placeholder-neutral-500 focus:outline-none focus:border-blue-400 h-20 resize-none"
                      />
                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-neutral-400">Target Audience:</span>
                          {(['All', 'Hosts', 'Users', 'Agencies'] as const).map((tgt) => (
                            <button
                              type="button"
                              key={tgt}
                              onClick={() => setNewNoticeTarget(tgt)}
                              className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                                newNoticeTarget === tgt
                                  ? 'bg-blue-600 text-white border-blue-400'
                                  : 'bg-[#11192e] text-neutral-400 border-[#1d2a4d]'
                              }`}
                            >
                              {tgt}
                            </button>
                          ))}
                        </div>

                        <button
                          type="submit"
                          className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-bold text-xs shadow cursor-pointer flex items-center gap-1.5"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Dispatch Alert</span>
                        </button>
                      </div>
                    </div>
                  </form>
                )}

                {/* Notifications History List */}
                <div className="space-y-2.5">
                  {notifications.map((n) => (
                    <div key={n.id} className="p-3.5 rounded-2xl bg-[#0c142c] border border-[#1d2a4d] shadow flex items-start justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{n.title}</span>
                          <span className="px-2 py-0.2 rounded-full bg-blue-500/20 text-blue-300 text-[9px] font-mono font-bold">
                            Target: {n.targetAudience}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-300 mt-1">{n.message}</p>
                        <span className="text-[10px] text-neutral-500 font-mono mt-1 block">{n.timestamp} • Sent by: {n.sentBy}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 16. LOGOUT & ROLES SWITCH                                                 */}
            {/* ========================================================================= */}
            {activeMenuId === 'logout' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-[#16203a]">
                  <div>
                    <h3 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                      <LogOut className="w-5 h-5 text-rose-400" />
                      <span>Admin Session & Role Governance</span>
                    </h3>
                    <p className="text-xs text-neutral-400">Current authenticated account: {currentUser.name} ({currentUser.id})</p>
                  </div>
                </div>

                <div className="p-6 rounded-3xl bg-[#0c142c] border border-[#1d2a4d] shadow-xl text-center space-y-4 max-w-md mx-auto">
                  <div className="w-16 h-16 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto shadow-lg">
                    <LogOut className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-base">Close Admin Panel Session</h4>
                    <p className="text-xs text-neutral-400 mt-1">Return to the standard DIYO LIVE user view or switch roles.</p>
                  </div>
                  <div className="flex items-center gap-3 pt-2">
                    <button
                      onClick={() => {
                        playSoundFX('click');
                        onClose();
                      }}
                      className="flex-1 py-2.5 rounded-2xl bg-[#11192e] text-neutral-300 hover:text-white font-bold text-xs border border-[#1d2a4d]"
                    >
                      Return to DIYO LIVE
                    </button>
                    <button
                      onClick={() => {
                        playSoundFX('notification');
                        showToast('Logged out of Admin Session');
                        onClose();
                      }}
                      className="flex-1 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 text-white font-bold text-xs shadow-lg shadow-rose-950/40"
                    >
                      Lock & Exit
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>

      {/* Coin Adjustment Modal */}
      {adjustCoinUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-5 rounded-3xl bg-[#0c142c] border-2 border-yellow-500/50 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <Coins className="w-4 h-4 text-yellow-400" />
                <span>Adjust User Coins</span>
              </h4>
              <button onClick={() => setAdjustCoinUser(null)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <p className="text-xs text-neutral-300">
              Directly inject or deduct coins from <strong>{adjustCoinUser.name}</strong> (Current: {adjustCoinUser.coinBalance.toLocaleString()} 🪙).
            </p>

            <div className="space-y-1.5 text-xs">
              <label className="text-neutral-400 font-bold">Amount to Inject (Coins):</label>
              <input
                type="number"
                value={adjustCoinAmount}
                onChange={(e) => setAdjustCoinAmount(e.target.value)}
                className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3 py-2 text-white font-mono font-bold focus:outline-none focus:border-yellow-400"
              />
            </div>

            <div className="flex items-center gap-2 pt-2 text-xs">
              <button
                onClick={() => setAdjustCoinUser(null)}
                className="flex-1 py-2 rounded-xl bg-[#11192e] text-neutral-400 hover:text-white font-bold border border-[#1d2a4d]"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmCoinAdjustment}
                className="flex-1 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-black shadow"
              >
                Confirm Grant
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#0c142c] border border-cyan-500/60 rounded-2xl px-4 py-3 shadow-2xl text-xs font-semibold text-white flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-2">
          <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
};
