import React, { useState } from 'react';
import { 
  Shield, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Eye, 
  CheckCircle2, 
  AlertTriangle, 
  Activity
} from 'lucide-react';
import { AdminAccount, UserAccount } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';
import { UserBanUnbanPowerHub } from './UserBanUnbanPowerHub';

interface AdminsSectionProps {
  admins: AdminAccount[];
  users?: UserAccount[];
  onUpdateUsers?: (users: UserAccount[]) => void;
  onOpenDetail: (adm: AdminAccount) => void;
  onOpenCreate: () => void;
  onUpdateStatus: (id: string, newStatus: string) => void;
  onRemove: (id: string) => void;
}

export const AdminsSection: React.FC<AdminsSectionProps> = ({
  admins = [],
  users = [],
  onUpdateUsers,
  onOpenDetail,
  onOpenCreate,
  onUpdateStatus,
  onRemove
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filtered = (admins || []).filter((adm) => {
    const matchesStatus = statusFilter === 'ALL' || adm.status === statusFilter;
    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (adm.name || '').toLowerCase().includes(q) ||
      (adm.username || '').toLowerCase().includes(q) ||
      (adm.id || '').toLowerCase().includes(q) ||
      (adm.contact || '').toLowerCase().includes(q);

    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-500/40">
              <Shield className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">System Admins Governance</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 border border-blue-500/30">
              Rank #5
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Operational staff managing live room moderation, reports review, and daily user enforcement.
          </p>
        </div>

        <button
          onClick={() => {
            onOpenCreate();
            playSoundFX('click');
          }}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold shadow-lg shadow-blue-900/30 transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Create Admin Account</span>
        </button>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search Admins by ID, name, contact..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto">
          {['ALL', 'Active', 'Inactive', 'Suspended'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-xl font-bold transition-all ${
                statusFilter === st
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Table List */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-3.5">Admin ID & Name</th>
                <th className="p-3.5">Contact</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5">Assigned Permissions</th>
                <th className="p-3.5">Last Login & Activity</th>
                <th className="p-3.5 text-right">Owner Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filtered.map((adm) => (
                <tr key={adm.id} className="hover:bg-neutral-850/50 transition-colors">
                  
                  {/* Admin Info */}
                  <td className="p-3.5">
                    <div className="flex items-center gap-3">
                      <img
                        src={adm.avatar}
                        alt={adm.name}
                        className="w-9 h-9 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                      />
                      <div>
                        <span className="font-bold text-white block">{adm.name}</span>
                        <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
                          <span className="font-mono text-blue-400 font-bold">{adm.id}</span>
                          <span>•</span>
                          <span>@{adm.username}</span>
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* Contact */}
                  <td className="p-3.5">
                    <span className="text-neutral-300 font-mono">{adm.contact}</span>
                  </td>

                  {/* Status */}
                  <td className="p-3.5">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                      adm.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                      adm.status === 'Suspended' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                      'bg-neutral-800 text-neutral-400 border-neutral-700'
                    }`}>
                      {adm.status}
                    </span>
                  </td>

                  {/* Permissions */}
                  <td className="p-3.5">
                    <div className="flex items-center gap-1 flex-wrap max-w-xs">
                      {(adm.permissions || []).map((p) => (
                        <span key={p} className="text-[9px] px-1.5 py-0.2 rounded bg-blue-500/10 text-blue-300 border border-blue-500/20 font-mono">
                          {p}
                        </span>
                      ))}
                    </div>
                  </td>

                  {/* Last Login & Activity */}
                  <td className="p-3.5">
                    <div className="space-y-0.5 text-[11px]">
                      <span className="text-neutral-300 block">{adm.lastLogin}</span>
                      <span className="text-emerald-400 font-bold">{adm.activityCount} actions logged</span>
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => {
                          onOpenDetail(adm);
                          playSoundFX('click');
                        }}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white"
                        title="View Full Admin Profile"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          const nextStatus = adm.status === 'Active' ? 'Suspended' : 'Active';
                          onUpdateStatus(adm.id, nextStatus);
                          playSoundFX('click');
                        }}
                        className={`p-1.5 rounded-lg ${
                          adm.status === 'Active' ? 'bg-amber-600/20 text-amber-300 hover:bg-amber-600/30' : 'bg-emerald-600 text-white'
                        }`}
                        title={adm.status === 'Active' ? 'Suspend Admin' : 'Activate Admin'}
                      >
                        {adm.status === 'Active' ? <AlertTriangle className="w-3.5 h-3.5" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => {
                          onRemove(adm.id);
                          playSoundFX('click');
                        }}
                        className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300"
                        title="Remove Admin"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Instant User ID Ban & Unban Power Hub for System Admin */}
      <UserBanUnbanPowerHub
        users={users}
        onUpdateUsers={onUpdateUsers}
        operatorRole="System Admin"
        operatorName="Admin Desk"
      />

    </div>
  );
};
