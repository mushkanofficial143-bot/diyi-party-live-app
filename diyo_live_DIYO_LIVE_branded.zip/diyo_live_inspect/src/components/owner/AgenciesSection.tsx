import React, { useState } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Eye, 
  CheckCircle2, 
  AlertTriangle, 
  Tv, 
  Percent, 
  Gift, 
  Award
} from 'lucide-react';
import { AgencyAccount } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface AgenciesSectionProps {
  agencies: AgencyAccount[];
  onOpenDetail: (agency: AgencyAccount) => void;
  onOpenCreate: () => void;
  onUpdateStatus: (id: string, newStatus: string) => void;
  onRemove: (id: string) => void;
}

export const AgenciesSection: React.FC<AgenciesSectionProps> = ({
  agencies,
  onOpenDetail,
  onOpenCreate,
  onUpdateStatus,
  onRemove
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filtered = agencies.filter((ag) => {
    const matchesStatus = statusFilter === 'ALL' || ag.status === statusFilter;
    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (ag.name || '').toLowerCase().includes(q) ||
      (ag.code || '').toLowerCase().includes(q) ||
      (ag.id || '').toLowerCase().includes(q) ||
      (ag.ownerOrManager || '').toLowerCase().includes(q) ||
      (ag.contactEmail || '').toLowerCase().includes(q);

    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              <Building2 className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Partner Agency Guilds</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
              Rank #3
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Signed talent agencies recruiting broadcasters and receiving diamond revenue splits.
          </p>
        </div>

        <button
          onClick={() => {
            onOpenCreate();
            playSoundFX('click');
          }}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-lg shadow-cyan-900/30 transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Register New Agency</span>
        </button>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search Agencies by ID, name, code..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto">
          {['ALL', 'Active', 'Suspended', 'Deactivated'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-xl font-bold transition-all ${
                statusFilter === st
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Table List */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-3.5">Agency Name & Code</th>
                <th className="p-3.5">Assigned Manager</th>
                <th className="p-3.5">Signed Hosts</th>
                <th className="p-3.5">Commission & Gifts</th>
                <th className="p-3.5">Performance & Earnings</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Owner Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filtered.map((ag) => (
                <tr key={ag.id} className="hover:bg-neutral-850/50 transition-colors">
                  
                  {/* Agency Name & Code */}
                  <td className="p-3.5">
                    <div className="flex items-center gap-3">
                      <img
                        src={ag.logo}
                        alt={ag.name}
                        className="w-9 h-9 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                      />
                      <div>
                        <span className="font-bold text-white block">{ag.name}</span>
                        <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
                          <span className="font-mono text-cyan-400 font-bold">{ag.id}</span>
                          <span>•</span>
                          <span className="text-neutral-300 font-mono font-semibold">{ag.code}</span>
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* Manager */}
                  <td className="p-3.5">
                    <span className="text-white font-medium">{ag.ownerOrManager}</span>
                    <span className="text-[10px] text-neutral-400 block font-mono">{ag.contactEmail}</span>
                  </td>

                  {/* Signed Hosts */}
                  <td className="p-3.5">
                    <div className="space-y-0.5">
                      <span className="font-bold text-white flex items-center gap-1">
                        <Tv className="w-3.5 h-3.5 text-rose-400" />
                        <span>{ag.numberOfHosts} Total Hosts</span>
                      </span>
                      <span className="text-[11px] text-emerald-400 font-semibold">
                        {ag.activeHosts} Currently Live
                      </span>
                    </div>
                  </td>

                  {/* Commission & Gifts */}
                  <td className="p-3.5">
                    <div className="space-y-0.5">
                      <span className="font-mono text-emerald-400 font-bold block">
                        {ag.commissionRate}% Commission
                      </span>
                      <span className="text-[11px] text-neutral-400">
                        {(ag?.totalGiftsReceived ?? 0).toLocaleString()} gifts
                      </span>
                    </div>
                  </td>

                  {/* Performance & Earnings */}
                  <td className="p-3.5">
                    <div className="space-y-0.5">
                      <span className="font-mono text-rose-400 font-bold block">
                        {(ag?.totalEarningsDiamonds ?? 0).toLocaleString()} 💎
                      </span>
                      <div className="flex items-center gap-1 text-emerald-400 text-[11px] font-bold">
                        <Award className="w-3 h-3 text-emerald-400" />
                        <span>{ag.hostPerformanceScore}% Score</span>
                      </div>
                    </div>
                  </td>

                  {/* Status */}
                  <td className="p-3.5">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                      ag.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                      ag.status === 'Suspended' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                      'bg-neutral-800 text-neutral-400 border-neutral-700'
                    }`}>
                      {ag.status}
                    </span>
                  </td>

                  {/* Actions */}
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => {
                          onOpenDetail(ag);
                          playSoundFX('click');
                        }}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white"
                        title="View Agency Profile & Hosts"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          const nextStatus = ag.status === 'Active' ? 'Suspended' : 'Active';
                          onUpdateStatus(ag.id, nextStatus);
                          playSoundFX('click');
                        }}
                        className={`p-1.5 rounded-lg ${
                          ag.status === 'Active' ? 'bg-amber-600/20 text-amber-300 hover:bg-amber-600/30' : 'bg-emerald-600 text-white'
                        }`}
                        title={ag.status === 'Active' ? 'Suspend Agency' : 'Activate Agency'}
                      >
                        {ag.status === 'Active' ? <AlertTriangle className="w-3.5 h-3.5" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => {
                          onRemove(ag.id);
                          playSoundFX('click');
                        }}
                        className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300"
                        title="Remove Agency"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
