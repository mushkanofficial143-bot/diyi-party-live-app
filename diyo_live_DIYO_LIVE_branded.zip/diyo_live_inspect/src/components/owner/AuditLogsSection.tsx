import React, { useState } from 'react';
import { 
  Activity, 
  Search, 
  ShieldAlert, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  Filter, 
  Lock,
  Globe
} from 'lucide-react';
import { AuditLogEntry } from '../../types/ownerTypes';
import { ROLE_BADGE_COLORS } from '../../utils/rbacGuard';

interface AuditLogsSectionProps {
  logs: AuditLogEntry[];
}

export const AuditLogsSection: React.FC<AuditLogsSectionProps> = ({ logs }) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filtered = logs.filter((l) => {
    const matchesStatus = statusFilter === 'ALL' || l.status === statusFilter;
    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (l.actorName || '').toLowerCase().includes(q) ||
      (l.action || '').toLowerCase().includes(q) ||
      (l.targetId || '').toLowerCase().includes(q) ||
      (l.details || '').toLowerCase().includes(q) ||
      (l.ipAddress || '').toLowerCase().includes(q);

    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              <Activity className="w-4 h-4 text-cyan-400" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">System Audit Logs & Security Forensics</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
              Immutable Trail
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Cryptographically sealed audit log recording every privileged administrative action, permission modification, and blocked RBAC escalation attempt.
          </p>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search logs by actor, action, target ID, IP..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          {['ALL', 'SUCCESS', 'DENIED', 'FLAGGED'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-xl font-bold transition-all ${
                statusFilter === st
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-3.5">Timestamp</th>
                <th className="p-3.5">Actor & Role</th>
                <th className="p-3.5">Action Executed</th>
                <th className="p-3.5">Target Entity</th>
                <th className="p-3.5">Forensic Details</th>
                <th className="p-3.5">IP Address</th>
                <th className="p-3.5 text-right">RBAC Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-mono">
              {filtered.map((log) => (
                <tr key={log.id} className="hover:bg-neutral-850/50 transition-colors">
                  
                  {/* Timestamp */}
                  <td className="p-3.5 text-neutral-400 text-[11px] whitespace-nowrap">
                    {log.timestamp}
                  </td>

                  {/* Actor */}
                  <td className="p-3.5 font-sans">
                    <div className="space-y-0.5">
                      <span className="font-bold text-white block">{log.actorName}</span>
                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full border ${ROLE_BADGE_COLORS[log.actorRole]}`}>
                        {log.actorRole.replace('_', ' ')}
                      </span>
                    </div>
                  </td>

                  {/* Action */}
                  <td className="p-3.5 text-amber-400 font-bold font-mono">
                    {log.action}
                  </td>

                  {/* Target */}
                  <td className="p-3.5 text-neutral-300">
                    <span className="font-bold text-white block">{log.targetId}</span>
                    <span className="text-[10px] text-neutral-500 capitalize">{log.targetRole?.replace('_', ' ')}</span>
                  </td>

                  {/* Details */}
                  <td className="p-3.5 font-sans text-neutral-300 text-[11px] max-w-xs">
                    {log.details}
                  </td>

                  {/* IP */}
                  <td className="p-3.5 text-neutral-400 text-[11px]">
                    {log.ipAddress}
                  </td>

                  {/* Result Status */}
                  <td className="p-3.5 text-right">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      log.status === 'SUCCESS' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                      log.status === 'DENIED' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                      'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    }`}>
                      {log.status}
                    </span>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
