import React, { useState } from 'react';
import { Image, Plus, Trash2, Eye, CheckCircle2, Sparkles, Upload, Edit, Radio } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface BannerItem {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  badge?: string;
  active: boolean;
  createdAt: string;
}

interface BannersSectionProps {
  banners: BannerItem[];
  onUpdateBanners: (banners: BannerItem[]) => void;
  onAddAuditLog?: (log: any) => void;
}

export const BannersSection: React.FC<BannersSectionProps> = ({
  banners,
  onUpdateBanners,
  onAddAuditLog
}) => {
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [badge, setBadge] = useState('FEATURED');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    playSoundFX('notification');
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        if (uploadEvent.target?.result) {
          setImageUrl(uploadEvent.target.result as string);
          showToast('📁 Image loaded successfully from Mobile Gallery / PC File!');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const presetImages = [
    { label: 'Festival Neon', url: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=800&auto=format&fit=crop&q=80' },
    { label: 'VIP Lounge', url: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80' },
    { label: 'Crown Party', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=800&auto=format&fit=crop&q=80' },
    { label: 'Music Stage', url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80' }
  ];

  const handleCreateBanner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !imageUrl) {
      showToast('⚠️ Please enter banner title and image URL.');
      return;
    }

    const newBanner: BannerItem = {
      id: `BNR-${Math.floor(1000 + Math.random() * 9000)}`,
      title,
      subtitle: subtitle || 'DIYO LIVE Official Event',
      imageUrl,
      badge: badge || 'NEW',
      active: true,
      createdAt: new Date().toISOString().split('T')[0]
    };

    onUpdateBanners([newBanner, ...banners]);
    showToast(`✨ Successfully uploaded & published banner "${title}" on everyone's home page!`);
    setTitle('');
    setSubtitle('');
    setImageUrl('');
  };

  const handleToggleActive = (id: string) => {
    const updated = banners.map(b => b.id === id ? { ...b, active: !b.active } : b);
    onUpdateBanners(updated);
    showToast('🔄 Banner status updated successfully!');
  };

  const handleDeleteBanner = (id: string) => {
    const updated = banners.filter(b => b.id !== id);
    onUpdateBanners(updated);
    showToast('🗑️ Banner removed successfully from home page!');
  };

  return (
    <div className="space-y-6 animate-in fade-in pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-5 py-3 rounded-2xl shadow-2xl border border-cyan-300/50 flex items-center gap-3 animate-in fade-in slide-in-from-top duration-300">
          <Sparkles className="w-5 h-5 text-amber-300 animate-spin" />
          <span className="font-bold text-sm">{toastMessage}</span>
        </div>
      )}

      {/* Header Info Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-[#0c142c] via-[#111c3c] to-[#0c142c] border border-cyan-500/30 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center font-bold">
              <Image className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-['Outfit'] font-black text-xl text-white">App-Wide Home Banners & Sliders</h2>
              <p className="text-xs text-neutral-400">Upload, remove, and manage promotional banners displayed instantly on all users' home screens.</p>
            </div>
          </div>
        </div>
        <div className="px-4 py-2 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-bold">
          Active Banners: {banners.filter(b => b.active).length} / {banners.length}
        </div>
      </div>

      {/* Upload / Create Banner Form */}
      <form onSubmit={handleCreateBanner} className="p-6 rounded-3xl bg-[#0c142c] border border-[#1d2a4d] shadow-xl space-y-4">
        <h3 className="font-['Outfit'] font-bold text-base text-white flex items-center gap-2">
          <Upload className="w-4 h-4 text-amber-400" />
          <span>Upload & Broadcast New Home Banner</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">Banner Title</label>
            <input
              type="text"
              required
              placeholder="e.g. ⭐ DIYO LIVE Grand Opening Festival"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">Subtitle / Description</label>
            <input
              type="text"
              placeholder="e.g. Complete daily missions & earn 50M rewards"
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-neutral-300">Banner Image URL or Device File</label>
              <label className="text-[11px] text-cyan-400 font-bold hover:underline cursor-pointer flex items-center gap-1">
                <span>📁 Choose from Gallery / PC</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
            <input
              type="text"
              required
              placeholder="Paste URL or upload from Mobile/PC..."
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3.5 py-2.5 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">Badge Label</label>
            <select
              value={badge}
              onChange={(e) => setBadge(e.target.value)}
              className="w-full bg-[#11192e] border border-[#1d2a4d] rounded-xl px-3.5 py-2.5 text-white font-bold text-xs focus:outline-none focus:border-cyan-400"
            >
              <option value="FEATURED">⭐ FEATURED</option>
              <option value="HOT">🔥 HOT EVENT</option>
              <option value="VIP">👑 VIP EXCLUSIVE</option>
              <option value="NEW">✨ NEW LAUNCH</option>
            </select>
          </div>
        </div>

        {/* Preset Quick Images */}
        <div>
          <label className="block text-[11px] font-bold text-neutral-400 mb-1.5">Quick Preset Backgrounds:</label>
          <div className="flex items-center gap-2 flex-wrap">
            {presetImages.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setImageUrl(p.url)}
                className="px-3 py-1 rounded-xl bg-[#11192e] border border-[#1d2a4d] text-cyan-300 text-[11px] font-bold hover:bg-cyan-500/20 transition-all cursor-pointer"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-neutral-950 font-black text-xs shadow-lg shadow-cyan-950/50 hover:brightness-110 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Upload & Publish to All Home Pages</span>
          </button>
        </div>
      </form>

      {/* Banners List & Management */}
      <div className="space-y-4">
        <h3 className="font-['Outfit'] font-bold text-base text-white">Active Home Banners Roster ({banners.length})</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {banners.map((banner) => (
            <div key={banner.id} className="relative rounded-3xl bg-[#0c142c] border border-[#1d2a4d] overflow-hidden shadow-xl flex flex-col justify-between">
              {/* Banner Image Preview Header */}
              <div className="relative h-36 w-full overflow-hidden">
                <img
                  src={banner.imageUrl}
                  alt={banner.title}
                  className="w-full h-full object-cover brightness-90 group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0c142c] via-transparent to-black/40" />
                
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/80 backdrop-blur-md text-neutral-950 font-black text-[10px] font-mono shadow">
                    {banner.badge || 'FEATURED'}
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${banner.active ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-neutral-800 text-neutral-400'}`}>
                    {banner.active ? '🟢 Live on Home' : '⏸️ Hidden'}
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3">
                  <h4 className="font-black text-white text-sm font-['Outfit'] drop-shadow">{banner.title}</h4>
                  <p className="text-[11px] text-neutral-300 drop-shadow line-clamp-1">{banner.subtitle}</p>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="p-3.5 bg-[#080d1d] border-t border-[#16203a] flex items-center justify-between text-xs">
                <span className="text-[10px] text-neutral-400 font-mono">ID: {banner.id} • Created: {banner.createdAt}</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggleActive(banner.id)}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                      banner.active
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30'
                    }`}
                  >
                    {banner.active ? 'Hide from Home' : 'Show on Home'}
                  </button>

                  <button
                    onClick={() => handleDeleteBanner(banner.id)}
                    className="p-1.5 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30 transition-all cursor-pointer"
                    title="Remove Banner"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
