import React, { useState } from 'react';
import { 
  Coins, 
  Send, 
  RotateCcw, 
  Sparkles, 
  History, 
  FileText, 
  Users, 
  TrendingUp, 
  ShieldCheck, 
  Search, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  DollarSign
} from 'lucide-react';
import { CoinSellerAccount, CoinSellerTransaction, WalletTransaction } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface CoinManagementHubProps {
  coinSellers: CoinSellerAccount[];
  ownerTestCoinBalance: number;
  sellerToUserTxs: CoinSellerTransaction[];
  walletTransactions: WalletTransaction[];
  onTransferToSeller: (sellerId: string, amount: number, notes?: string) => Promise<boolean>;
  onReclaimFromSeller: (sellerId: string, amount: number, notes?: string) => Promise<boolean>;
  onCreateSeller: (data: any) => Promise<boolean>;
  onUpdateSellerStatus: (sellerId: string, status: any) => Promise<boolean>;
  onAutoGenerateCoins: (data: any) => Promise<boolean>;
  onReverseTransaction: (txId: string, reason: string) => Promise<boolean>;
}

export const CoinManagementHub: React.FC<CoinManagementHubProps> = ({
  coinSellers,
  ownerTestCoinBalance,
  sellerToUserTxs,
  walletTransactions,
  onTransferToSeller,
  onReclaimFromSeller,
  onCreateSeller,
  onUpdateSellerStatus,
  onAutoGenerateCoins,
  onReverseTransaction
}) => {
  const [coinSubTab, setCoinSubTab] = useState<'central' | 'generate' | 'give' | 'sellers' | 'transactions' | 'reclaim' | 'reports'>('central');
  
  // Give Coins form state
  const [targetSellerId, setTargetSellerId] = useState('');
  const [giveAmount, setGiveAmount] = useState('10000000');
  const [giveNotes, setGiveNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Auto Generate form state
  const [genAmount, setGenAmount] = useState('50000000');
  const [genType, setGenType] = useState('Event Reward');
  const [genReceiverType, setGenReceiverType] = useState('Specific User');
  const [genReceiverId, setGenReceiverId] = useState('USR-3456789');
  const [genFrequency, setGenFrequency] = useState('Once');
  const [genReason, setGenReason] = useState('Special seasonal promotional event reward injection');

  // Reclaim / Reverse state
  const [reverseTxId, setReverseTxId] = useState('');
  const [reverseReason, setReverseReason] = useState('');
  const [lookupTx, setLookupTx] = useState<any | null>(null);

  // Search filter for sellers & transactions
  const [sellerSearch, setSellerSearch] = useState('');
  const [txSearch, setTxSearch] = useState('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Calculations for Central Coin Supply
  const totalSellerHoldings = (coinSellers || []).reduce((acc, s) => acc + (s.balanceCoins || 0), 0);
  const totalAvailable = ownerTestCoinBalance;
  const totalDistributed = (sellerToUserTxs || []).reduce((acc, t) => acc + (t.amount || 0), 0);
  const totalReclaimed = 25000000; // Tracked reclaimed pool
  const totalReserved = 50000000;
  const grandTotalSupply = totalAvailable + totalSellerHoldings + totalDistributed + totalReserved;

  const handleGiveCoins = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetSellerId) {
      showToast('⚠️ Please enter or select a valid Seller ID');
      return;
    }
    const amt = Number(giveAmount);
    if (amt <= 0) {
      showToast('⚠️ Please enter a valid coin amount');
      return;
    }
    setIsSubmitting(true);
    try {
      const success = await onTransferToSeller(targetSellerId, amt, giveNotes || 'Central Supply Transfer to Seller');
      if (success) {
        playSoundFX('success');
        showToast(`✅ Successfully transferred ${amt.toLocaleString()} coins to seller ${targetSellerId}`);
        setGiveNotes('');
      } else {
        playSoundFX('alert');
        showToast('❌ Transfer failed. Check central balance or seller ID.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAutoGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(genAmount);
    if (amt <= 0) {
      showToast('⚠️ Enter valid generation amount');
      return;
    }
    setIsSubmitting(true);
    try {
      const success = await onAutoGenerateCoins({
        amount: amt,
        type: genType,
        receiverType: genReceiverType,
        receiverId: genReceiverId,
        frequency: genFrequency,
        reason: genReason
      });
      if (success) {
        playSoundFX('success');
        showToast(`✅ Successfully generated ${amt.toLocaleString()} coins (${genType}) for ${genReceiverId}`);
      } else {
        playSoundFX('alert');
        showToast('❌ Auto coin generation failed.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLookupTx = () => {
    if (!reverseTxId) return;
    const found = walletTransactions.find(t => t.id.toLowerCase() === reverseTxId.toLowerCase()) ||
                  sellerToUserTxs.find(t => t.id.toLowerCase() === reverseTxId.toLowerCase());
    if (found) {
      setLookupTx(found);
      showToast('✅ Transaction located successfully');
    } else {
      setLookupTx(null);
      showToast('❌ Transaction ID not found in database');
    }
  };

  const handleExecuteReverse = async () => {
    if (!lookupTx || !reverseReason) {
      showToast('⚠️ Please verify transaction and provide a reversal reason');
      return;
    }
    setIsSubmitting(true);
    try {
      const success = await onReverseTransaction(lookupTx.id, reverseReason);
      if (success) {
        playSoundFX('success');
        showToast(`✅ Transaction ${lookupTx.id} successfully reversed / reclaimed.`);
        setLookupTx(null);
        setReverseTxId('');
        setReverseReason('');
      } else {
        playSoundFX('alert');
        showToast('❌ Reversal failed. May already be reversed.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="bg-gradient-to-r from-purple-900/90 to-pink-900/90 border border-pink-500/50 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center justify-between animate-in fade-in z-50">
          <span className="font-bold text-sm">{toastMessage}</span>
        </div>
      )}

      {/* Submenu Navigation Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-purple-500/20">
        {[
          { id: 'central', label: 'Central Coin Supply', icon: Coins },
          { id: 'give', label: 'Give Coins to Seller', icon: Send },
          { id: 'sellers', label: 'All Coin Sellers', icon: Users },
          { id: 'generate', label: 'Auto Coin Generate', icon: Sparkles },
          { id: 'transactions', label: 'Transaction History', icon: History },
          { id: 'reclaim', label: 'Reclaim / Reverse', icon: RotateCcw },
          { id: 'reports', label: 'Coin Reports', icon: FileText }
        ].map((sub) => {
          const Icon = sub.icon;
          const isActive = coinSubTab === sub.id;
          return (
            <button
              key={sub.id}
              onClick={() => {
                playSoundFX('click');
                setCoinSubTab(sub.id as any);
              }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all whitespace-nowrap shadow-md ${
                isActive
                  ? 'bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 text-white shadow-purple-500/30'
                  : 'bg-[#131626] text-neutral-400 hover:text-white border border-white/5 hover:border-purple-500/30'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{sub.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. CENTRAL COIN SUPPLY SUBVIEW */}
      {coinSubTab === 'central' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-400" />
                <span>Central Coin Supply & Treasury</span>
              </h2>
              <p className="text-xs text-neutral-400">Automated secure treasury metrics and allocation ledger.</p>
            </div>
            <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-lg text-amber-300 font-mono text-xs font-bold">
              Status: SECURE & SYNCED
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl p-5 shadow-xl">
              <p className="text-xs text-neutral-400 font-medium uppercase tracking-wider">Total Coin Supply</p>
              <h3 className="text-2xl font-black text-white mt-1 font-mono">
                🪙 {grandTotalSupply.toLocaleString()}
              </h3>
              <p className="text-[11px] text-emerald-400 mt-2">Verified Treasury Ledger</p>
            </div>

            <div className="bg-[#131626]/90 border border-emerald-500/30 rounded-2xl p-5 shadow-xl">
              <p className="text-xs text-neutral-400 font-medium uppercase tracking-wider">Available Balance</p>
              <h3 className="text-2xl font-black text-emerald-300 mt-1 font-mono">
                🪙 {totalAvailable.toLocaleString()}
              </h3>
              <p className="text-[11px] text-neutral-400 mt-2">Ready for seller allocation</p>
            </div>

            <div className="bg-[#131626]/90 border border-blue-500/30 rounded-2xl p-5 shadow-xl">
              <p className="text-xs text-neutral-400 font-medium uppercase tracking-wider">Allocated to Sellers</p>
              <h3 className="text-2xl font-black text-blue-300 mt-1 font-mono">
                🪙 {totalSellerHoldings.toLocaleString()}
              </h3>
              <p className="text-[11px] text-neutral-400 mt-2">Active seller holdings</p>
            </div>

            <div className="bg-[#131626]/90 border border-pink-500/30 rounded-2xl p-5 shadow-xl">
              <p className="text-xs text-neutral-400 font-medium uppercase tracking-wider">Sold / Distributed</p>
              <h3 className="text-2xl font-black text-pink-300 mt-1 font-mono">
                🪙 {totalDistributed.toLocaleString()}
              </h3>
              <p className="text-[11px] text-neutral-400 mt-2">Delivered to users/hosts</p>
            </div>

            <div className="bg-[#131626]/90 border border-amber-500/30 rounded-2xl p-5 shadow-xl">
              <p className="text-xs text-neutral-400 font-medium uppercase tracking-wider">Reclaimed / Returned</p>
              <h3 className="text-2xl font-black text-amber-300 mt-1 font-mono">
                🪙 {totalReclaimed.toLocaleString()}
              </h3>
              <p className="text-[11px] text-neutral-400 mt-2">Reversed back to central</p>
            </div>

            <div className="bg-[#131626]/90 border border-indigo-500/30 rounded-2xl p-5 shadow-xl">
              <p className="text-xs text-neutral-400 font-medium uppercase tracking-wider">Reserved / Pending</p>
              <h3 className="text-2xl font-black text-indigo-300 mt-1 font-mono">
                🪙 {totalReserved.toLocaleString()}
              </h3>
              <p className="text-[11px] text-neutral-400 mt-2">Locked reserve escrow</p>
            </div>
          </div>
        </div>
      )}

      {/* 2. GIVE COINS TO SELLER SUBVIEW */}
      {coinSubTab === 'give' && (
        <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl p-6 shadow-2xl max-w-2xl mx-auto">
          <h2 className="text-base font-black text-white flex items-center gap-2 mb-4">
            <Send className="w-5 h-5 text-pink-400" />
            <span>Give Coins to Coin Seller</span>
          </h2>

          <form onSubmit={handleGiveCoins} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">Target Seller ID or Username</label>
              <select
                value={targetSellerId}
                onChange={(e) => setTargetSellerId(e.target.value)}
                className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-pink-500"
              >
                <option value="">-- Select Verified Coin Seller --</option>
                {(coinSellers || []).map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.id}) - Balance: {s.balanceCoins.toLocaleString()}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">Coin Amount</label>
              <input
                type="number"
                value={giveAmount}
                onChange={(e) => setGiveAmount(e.target.value)}
                className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm font-mono focus:outline-none focus:border-pink-500"
                placeholder="Enter coin amount..."
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-2">Quick Amount Selectors</label>
              <div className="grid grid-cols-5 gap-2">
                {[
                  { label: '10M', val: '10000000' },
                  { label: '50M', val: '50000000' },
                  { label: '100M', val: '100000000' },
                  { label: '500M', val: '500000000' },
                  { label: '1B', val: '1000000000' }
                ].map(q => (
                  <button
                    key={q.val}
                    type="button"
                    onClick={() => {
                      playSoundFX('click');
                      setGiveAmount(q.val);
                    }}
                    className={`py-2 rounded-xl text-xs font-bold transition-all ${
                      giveAmount === q.val
                        ? 'bg-pink-600 text-white shadow-lg shadow-pink-500/30'
                        : 'bg-[#0a0d18] text-neutral-300 hover:text-white border border-white/10'
                    }`}
                  >
                    {q.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">Transfer Notes / Reason</label>
              <input
                type="text"
                value={giveNotes}
                onChange={(e) => setGiveNotes(e.target.value)}
                className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-pink-500"
                placeholder="e.g., Weekly authorized dealer stock allocation"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-gradient-to-r from-purple-600 via-pink-600 to-amber-600 text-white font-black rounded-xl shadow-xl hover:opacity-95 transition-all text-sm tracking-wider"
            >
              {isSubmitting ? 'Processing Secure Transfer...' : '🚀 GIVE COINS (SECURE TRANSFER)'}
            </button>
          </form>
        </div>
      )}

      {/* 3. ALL COIN SELLERS SUBVIEW */}
      {coinSubTab === 'sellers' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-black text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-400" />
              <span>All Coin Sellers Management</span>
            </h2>
            <div className="relative w-64">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                value={sellerSearch}
                onChange={(e) => setSellerSearch(e.target.value)}
                placeholder="Search Seller ID / Name..."
                className="w-full bg-[#131626] border border-purple-500/30 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
              />
            </div>
          </div>

          <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-purple-950/40 text-[11px] font-bold text-neutral-300 uppercase border-b border-purple-500/20 font-mono">
                    <th className="py-3 px-4">#</th>
                    <th className="py-3 px-4">Seller ID</th>
                    <th className="py-3 px-4">Name</th>
                    <th className="py-3 px-4">Total Received</th>
                    <th className="py-3 px-4">Total Sold</th>
                    <th className="py-3 px-4">Current Balance</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-xs text-neutral-200">
                  {(coinSellers || [])
                    .filter(s => !sellerSearch || s.name.toLowerCase().includes(sellerSearch.toLowerCase()) || s.id.toLowerCase().includes(sellerSearch.toLowerCase()))
                    .map((seller, idx) => (
                      <tr key={seller.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3 px-4 font-mono text-neutral-400">{idx + 1}</td>
                        <td className="py-3 px-4 font-mono text-pink-400 font-bold">{seller.id}</td>
                        <td className="py-3 px-4 font-bold text-white flex items-center gap-2">
                          <img src={seller.avatar} alt="" className="w-7 h-7 rounded-full object-cover border border-purple-500/40" />
                          <span>{seller.name}</span>
                        </td>
                        <td className="py-3 px-4 font-mono text-blue-300">🪙 {(seller.totalReceivedCoins || 150000000).toLocaleString()}</td>
                        <td className="py-3 px-4 font-mono text-emerald-300">🪙 {(seller.totalSoldCoins || 120000000).toLocaleString()}</td>
                        <td className="py-3 px-4 font-mono text-amber-300 font-bold">🪙 {(seller.balanceCoins || 0).toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            seller.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          }`}>
                            {seller.status || 'Active'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          <button
                            onClick={() => {
                              playSoundFX('click');
                              onUpdateSellerStatus(seller.id, seller.status === 'Active' ? 'Suspended' : 'Active');
                            }}
                            className="px-2.5 py-1 bg-purple-600/30 hover:bg-purple-600 text-purple-200 hover:text-white rounded-lg text-[11px] font-bold transition-all border border-purple-500/40"
                          >
                            {seller.status === 'Active' ? 'Suspend' : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. AUTO COIN GENERATE SUBVIEW */}
      {coinSubTab === 'generate' && (
        <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl p-6 shadow-2xl max-w-2xl mx-auto">
          <h2 className="text-base font-black text-white flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>Auto Coin Generate & Reward System</span>
          </h2>

          <form onSubmit={handleAutoGenerate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">Generate Amount</label>
              <input
                type="number"
                value={genAmount}
                onChange={(e) => setGenAmount(e.target.value)}
                className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm font-mono focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">Reward Type</label>
                <select
                  value={genType}
                  onChange={(e) => setGenType(e.target.value)}
                  className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-amber-500"
                >
                  <option value="Test / Reward">Test / Reward</option>
                  <option value="Event Reward">Event Reward</option>
                  <option value="Promotional Reward">Promotional Reward</option>
                  <option value="Admin Approved Reward">Admin Approved Reward</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">Receiver Scope</label>
                <select
                  value={genReceiverType}
                  onChange={(e) => setGenReceiverType(e.target.value)}
                  className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-amber-500"
                >
                  <option value="Specific User">Specific User</option>
                  <option value="Specific Host">Specific Host</option>
                  <option value="Specific Seller">Specific Seller</option>
                  <option value="Selected Users">Selected Users</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">Receiver ID</label>
              <input
                type="text"
                value={genReceiverId}
                onChange={(e) => setGenReceiverId(e.target.value)}
                className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm font-mono focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">Frequency</label>
              <select
                value={genFrequency}
                onChange={(e) => setGenFrequency(e.target.value)}
                className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-amber-500"
              >
                <option value="Once">Once</option>
                <option value="Daily">Daily</option>
                <option value="Weekly">Weekly</option>
                <option value="Monthly">Monthly</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">Admin Audit Reason</label>
              <input
                type="text"
                value={genReason}
                onChange={(e) => setGenReason(e.target.value)}
                className="w-full bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-gradient-to-r from-amber-500 via-pink-600 to-purple-600 text-white font-black rounded-xl shadow-xl hover:opacity-95 transition-all text-sm tracking-wider"
            >
              {isSubmitting ? 'Generating Secured Coins...' : '✨ GENERATE & INJECT COINS (AUDITED)'}
            </button>
          </form>
        </div>
      )}

      {/* 5. TRANSACTION HISTORY SUBVIEW */}
      {coinSubTab === 'transactions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-black text-white flex items-center gap-2">
              <History className="w-5 h-5 text-purple-400" />
              <span>Complete Transaction History Ledger</span>
            </h2>
            <div className="relative w-64">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                value={txSearch}
                onChange={(e) => setTxSearch(e.target.value)}
                placeholder="Search Transaction ID / User..."
                className="w-full bg-[#131626] border border-purple-500/30 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
              />
            </div>
          </div>

          <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-purple-950/40 text-[11px] font-bold text-neutral-300 uppercase border-b border-purple-500/20 font-mono">
                    <th className="py-3 px-4">Tx ID</th>
                    <th className="py-3 px-4">User / Seller</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Amount Coins</th>
                    <th className="py-3 px-4">Timestamp</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-xs text-neutral-200">
                  {(walletTransactions || [])
                    .filter(t => !txSearch || t.id.toLowerCase().includes(txSearch.toLowerCase()) || t.userId.toLowerCase().includes(txSearch.toLowerCase()))
                    .slice(0, 30)
                    .map((tx) => (
                      <tr key={tx.id} className="hover:bg-white/5 transition-colors font-mono">
                        <td className="py-3 px-4 text-pink-400 font-bold">{tx.id}</td>
                        <td className="py-3 px-4 text-white font-sans">{tx.userName || tx.userId}</td>
                        <td className="py-3 px-4 text-blue-300">{tx.type}</td>
                        <td className="py-3 px-4 text-amber-300 font-bold">
                          {tx.amountCoins >= 0 ? `+${tx.amountCoins.toLocaleString()}` : tx.amountCoins.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-neutral-400 text-[11px]">{tx.timestamp}</td>
                        <td className="py-3 px-4">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-sans">
                            {tx.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 6. RECLAIM / REVERSE SUBVIEW */}
      {coinSubTab === 'reclaim' && (
        <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl p-6 shadow-2xl max-w-xl mx-auto space-y-5">
          <h2 className="text-base font-black text-white flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-rose-400" />
            <span>Reclaim / Reverse Transaction</span>
          </h2>
          <p className="text-xs text-neutral-400">Enter a secure transaction ID to inspect and execute verified escrow reversal.</p>

          <div className="flex gap-2">
            <input
              type="text"
              value={reverseTxId}
              onChange={(e) => setReverseTxId(e.target.value)}
              placeholder="Enter Transaction ID (e.g. TX-1757...)"
              className="flex-1 bg-[#0a0d18] border border-purple-500/30 rounded-xl px-4 py-2.5 text-white text-xs font-mono focus:outline-none focus:border-rose-500"
            />
            <button
              onClick={handleLookupTx}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs transition-all shadow-lg"
            >
              Verify Tx
            </button>
          </div>

          {lookupTx && (
            <div className="bg-[#0a0d18] border border-emerald-500/40 rounded-xl p-4 space-y-3 font-mono text-xs">
              <div className="flex justify-between text-emerald-400 font-bold">
                <span>Transaction Verified Eligible</span>
                <span>ID: {lookupTx.id}</span>
              </div>
              <div className="text-neutral-300 space-y-1">
                <div>User ID: {lookupTx.userId}</div>
                <div>Amount: 🪙 {(lookupTx.amountCoins || lookupTx.amount || 0).toLocaleString()}</div>
                <div>Type: {lookupTx.type || lookupTx.source}</div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-400 mb-1 font-sans">Reversal Reason / Audit Note</label>
                <input
                  type="text"
                  value={reverseReason}
                  onChange={(e) => setReverseReason(e.target.value)}
                  placeholder="Required audit reason for reversal..."
                  className="w-full bg-[#131626] border border-rose-500/40 rounded-lg px-3 py-2 text-white text-xs font-sans focus:outline-none"
                />
              </div>

              <button
                onClick={handleExecuteReverse}
                disabled={isSubmitting || !reverseReason}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-black rounded-lg shadow-xl transition-all font-sans text-xs"
              >
                {isSubmitting ? 'Processing Reversal...' : '⚠️ EXECUTE SECURE REVERSE / RECLAIM'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* 7. COIN REPORTS SUBVIEW */}
      {coinSubTab === 'reports' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-black text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-400" />
              <span>Comprehensive Coin Reports & Analytics</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl p-5 shadow-xl space-y-3">
              <h3 className="text-sm font-bold text-white border-b border-white/10 pb-2">Daily Coin Flow Summary</h3>
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Total Injected Today:</span>
                <span className="text-emerald-400 font-bold">+50,000,000</span>
              </div>
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Total Spent in Games:</span>
                <span className="text-pink-400 font-bold">-18,400,000</span>
              </div>
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Total Gifted Today:</span>
                <span className="text-blue-300 font-bold">12,500,000</span>
              </div>
            </div>

            <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl p-5 shadow-xl space-y-3">
              <h3 className="text-sm font-bold text-white border-b border-white/10 pb-2">Treasury Escrow Integrity</h3>
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">System Balance Check:</span>
                <span className="text-emerald-300 font-bold">PASSED (100% SECURE)</span>
              </div>
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Atomic Lock Latency:</span>
                <span className="text-neutral-200">12ms</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
