import React, { useState } from 'react';
import {
  Users,
  Plus,
  Search,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Send,
  RotateCcw,
  Sliders,
  History,
  Trash2,
  Coins,
  ShieldCheck,
  Phone,
  Mail,
  MoreVertical,
  ExternalLink,
  Lock,
  Building
} from 'lucide-react';
import { CoinSellerAccount, CoinSellerTransaction } from '../../types/ownerTypes';

interface CoinSellersSectionProps {
  coinSellers: CoinSellerAccount[];
  ownerTestCoinBalance: number;
  sellerToUserTxs: CoinSellerTransaction[];
  onCreateSeller: (data: {
    name: string;
    username: string;
    phone?: string;
    email?: string;
    initialCoins?: number;
    dailyLimit?: number;
    singleLimit?: number;
    notes?: string;
  }) => Promise<boolean>;
  onUpdateStatus: (sellerId: string, status: 'Active' | 'Inactive' | 'Suspended' | 'Deactivated') => Promise<boolean>;
  onUpdateLimits: (sellerId: string, dailyLimit: number, singleLimit: number) => Promise<boolean>;
  onTransferToSeller: (sellerId: string, amount: number, notes?: string) => Promise<boolean>;
  onReclaimFromSeller: (sellerId: string, amount: number, notes?: string) => Promise<boolean>;
  onRemoveSeller?: (sellerId: string) => Promise<boolean>;
}

export const CoinSellersSection: React.FC<CoinSellersSectionProps> = ({
  coinSellers,
  ownerTestCoinBalance,
  sellerToUserTxs,
  onCreateSeller,
  onUpdateStatus,
  onUpdateLimits,
  onTransferToSeller,
  onReclaimFromSeller,
  onRemoveSeller
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Suspended' | 'Inactive'>('All');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedSellerForCoins, setSelectedSellerForCoins] = useState<CoinSellerAccount | null>(null);
  const [coinActionType, setCoinActionType] = useState<'GIVE' | 'RECLAIM'>('GIVE');
  const [coinAmount, setCoinAmount] = useState('5000000');
  const [coinNotes, setCoinNotes] = useState('');
  const [selectedSellerForLimits, setSelectedSellerForLimits] = useState<CoinSellerAccount | null>(null);
  const [newDailyLimit, setNewDailyLimit] = useState(50000000);
  const [newSingleLimit, setNewSingleLimit] = useState(10000000);
  const [viewHistorySeller, setViewHistorySeller] = useState<CoinSellerAccount | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New Seller Form State
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    phone: '',
    email: '',
    initialCoins: '10000000',
    dailyLimit: '50000000',
    singleLimit: '10000000',
    notes: ''
  });

  const filteredSellers = (coinSellers || []).filter(seller => {
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (seller.name || '').toLowerCase().includes(q) ||
      (seller.username || '').toLowerCase().includes(q) ||
      (seller.id || '').toLowerCase().includes(q);
    const matchesStatus = statusFilter === 'All' || seller.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.username) return;
    setIsSubmitting(true);
    try {
      const success = await onCreateSeller({
        name: formData.name,
        username: formData.username.replace('@', ''),
        phone: formData.phone,
        email: formData.email,
        initialCoins: Number(formData.initialCoins) || 0,
        dailyLimit: Number(formData.dailyLimit) || 50000000,
        singleLimit: Number(formData.singleLimit) || 10000000,
        notes: formData.notes
      });
      if (success) {
        setShowCreateModal(false);
        setFormData({
          name: '',
          username: '',
          phone: '',
          email: '',
          initialCoins: '10000000',
          dailyLimit: '50000000',
          singleLimit: '10000000',
          notes: ''
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCoinTransferSubmit = async () => {
    if (!selectedSellerForCoins) return;
    const amount = Number(coinAmount);
    if (!amount || amount <= 0) return;

    setIsSubmitting(true);
    try {
      if (coinActionType === 'GIVE') {
        await onTransferToSeller(selectedSellerForCoins.id, amount, coinNotes);
      } else {
        await onReclaimFromSeller(selectedSellerForCoins.id, amount, coinNotes);
      }
      setSelectedSellerForCoins(null);
      setCoinNotes('');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLimitsSubmit = async () => {
    if (!selectedSellerForLimits) return;
    setIsSubmitting(true);
    try {
      await onUpdateLimits(selectedSellerForLimits.id, Number(newDailyLimit), Number(newSingleLimit));
      setSelectedSellerForLimits(null);
    } finally {
      setIsSubmitting(false);
    }
  };

  const historyForSelectedSeller = viewHistorySeller
    ? sellerToUserTxs.filter(tx => tx.sellerId === viewHistorySeller.id)
    : [];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Quick Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black text-white uppercase tracking-wider">
              Coin Sellers Management
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-300 text-[10px] font-black uppercase tracking-wider border border-yellow-500/30">
              Role: COIN SELLER
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Manage authorized test coin distribution partners, enforce daily transfer caps, and monitor user disbursements.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 hover:to-amber-500 text-neutral-950 font-black text-xs shadow-lg shadow-yellow-500/20 flex items-center gap-2 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Create Coin Seller</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search seller by name, @username, or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-8 pr-3 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-yellow-500"
          />
        </div>

        <div className="flex items-center gap-2">
          {(['All', 'Active', 'Suspended', 'Inactive'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                statusFilter === tab
                  ? 'bg-yellow-500 text-neutral-950 shadow-md shadow-yellow-500/20'
                  : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Coin Sellers Table */}
      <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900 shadow-xl">
        <table className="w-full text-left text-xs text-neutral-300">
          <thead className="bg-neutral-950 text-neutral-400 font-bold uppercase tracking-wider border-b border-neutral-800">
            <tr>
              <th className="py-3 px-4">Seller ID</th>
              <th className="py-3 px-4">Seller Profile</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4">Test Balance</th>
              <th className="py-3 px-4">Total Distributed</th>
              <th className="py-3 px-4">Daily Cap</th>
              <th className="py-3 px-4">Last Activity</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800 font-medium">
            {filteredSellers.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-neutral-500">
                  No Coin Sellers found. Click "Create Coin Seller" to register one.
                </td>
              </tr>
            ) : (
              filteredSellers.map(seller => (
                <tr key={seller.id} className="hover:bg-neutral-800/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-yellow-400">{seller.id}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={seller.avatar}
                        alt={seller.name}
                        className="w-8 h-8 rounded-full object-cover border border-neutral-700"
                      />
                      <div>
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <span>{seller.name}</span>
                          {seller.status === 'Active' && (
                            <CheckCircle className="w-3.5 h-3.5 text-yellow-400" />
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-400 font-mono">@{seller.username}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      seller.status === 'Active'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : seller.status === 'Suspended'
                        ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                        : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                    }`}>
                      {seller.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-bold text-yellow-400 font-mono">
                    {((seller?.testCoinBalance) ?? 0).toLocaleString()}
                  </td>
                  <td className="py-3 px-4 font-mono text-emerald-400 font-bold">
                    {((seller?.totalDistributed) ?? 0).toLocaleString()}
                  </td>
                  <td className="py-3 px-4 font-mono text-neutral-400 text-[11px]">
                    {((seller?.dailyLimit) ?? 0).toLocaleString()} / day
                  </td>
                  <td className="py-3 px-4 text-neutral-400 text-[11px]">
                    {seller.lastActivity}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => {
                          setSelectedSellerForCoins(seller);
                          setCoinActionType('GIVE');
                          setCoinAmount('5000000');
                        }}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-yellow-400 hover:text-yellow-300 transition-all"
                        title="Give / Transfer Test Coins to Seller"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setSelectedSellerForCoins(seller);
                          setCoinActionType('RECLAIM');
                          setCoinAmount('1000000');
                        }}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-cyan-400 hover:text-cyan-300 transition-all"
                        title="Reclaim unused Test Coins from Seller"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setSelectedSellerForLimits(seller);
                          setNewDailyLimit(seller.dailyLimit ?? 50000000);
                          setNewSingleLimit(seller.singleTransferLimit ?? (seller as any).singleLimit ?? 10000000);
                        }}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-all"
                        title="Configure Transfer Limits"
                      >
                        <Sliders className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setViewHistorySeller(seller)}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-purple-400 hover:text-purple-300 transition-all"
                        title="View Disbursement History"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>
                      <select
                        value={seller.status}
                        onChange={(e) => onUpdateStatus(seller.id, e.target.value as any)}
                        className="bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-300 rounded-lg px-2 py-1 focus:outline-none focus:border-yellow-500"
                      >
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Suspended">Suspended</option>
                        <option value="Deactivated">Deactivated</option>
                      </select>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* CREATE COIN SELLER MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Register Authorized Coin Seller
                  </h3>
                  <p className="text-[11px] text-neutral-400">Creates an authorized agent for test coin liquidity distribution.</p>
                </div>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-neutral-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 font-bold mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Kabir Singhania"
                    value={formData.name ?? ''}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-yellow-500"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 font-bold mb-1">Username *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. kabir_coins"
                    value={formData.username ?? ''}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-yellow-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 font-bold mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="+91 99881 12233"
                    value={formData.phone ?? ''}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-yellow-500"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 font-bold mb-1">Email</label>
                  <input
                    type="email"
                    placeholder="kabir.coins@srlive.io"
                    value={formData.email ?? ''}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-yellow-500"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between text-[11px] font-bold text-yellow-400">
                  <span>Initial Test Coin Grant</span>
                  <span>Owner Balance: {(ownerTestCoinBalance ?? 0).toLocaleString()}</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] text-neutral-400 mb-1">Initial Coins</label>
                    <input
                      type="number"
                      value={formData.initialCoins ?? '10000000'}
                      onChange={(e) => setFormData({ ...formData, initialCoins: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2 py-1.5 text-yellow-300 font-bold focus:outline-none focus:border-yellow-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-neutral-400 mb-1">Daily Cap</label>
                    <input
                      type="number"
                      value={formData.dailyLimit ?? '50000000'}
                      onChange={(e) => setFormData({ ...formData, dailyLimit: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2 py-1.5 text-neutral-200 focus:outline-none focus:border-yellow-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-neutral-400 mb-1">Single Tx Cap</label>
                    <input
                      type="number"
                      value={formData.singleLimit ?? '10000000'}
                      onChange={(e) => setFormData({ ...formData, singleLimit: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2 py-1.5 text-neutral-200 focus:outline-none focus:border-yellow-500"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-neutral-400 font-bold mb-1">Internal Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Primary Delhi SEA Distribution partner"
                  value={formData.notes ?? ''}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-yellow-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 font-bold hover:bg-neutral-700 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-yellow-500 hover:bg-yellow-400 text-neutral-950 font-black transition-all disabled:opacity-50"
                >
                  {isSubmitting ? 'Creating...' : 'Confirm Registration'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* GIVE / RECLAIM COINS MODAL */}
      {selectedSellerForCoins && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <div className={`p-2 rounded-xl border ${
                  coinActionType === 'GIVE'
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                    : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                }`}>
                  {coinActionType === 'GIVE' ? <Send className="w-5 h-5" /> : <RotateCcw className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    {coinActionType === 'GIVE' ? 'Distribute Test Coins' : 'Reclaim Test Coins'}
                  </h3>
                  <p className="text-[11px] text-neutral-400">Target: {selectedSellerForCoins.name} ({selectedSellerForCoins.id})</p>
                </div>
              </div>
              <button onClick={() => setSelectedSellerForCoins(null)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex gap-2">
                <button
                  onClick={() => setCoinActionType('GIVE')}
                  className={`flex-1 py-2 rounded-xl font-bold transition-all ${
                    coinActionType === 'GIVE' ? 'bg-amber-500 text-neutral-950 font-black' : 'bg-neutral-950 text-neutral-400'
                  }`}
                >
                  Give Coins
                </button>
                <button
                  onClick={() => setCoinActionType('RECLAIM')}
                  className={`flex-1 py-2 rounded-xl font-bold transition-all ${
                    coinActionType === 'RECLAIM' ? 'bg-cyan-500 text-neutral-950 font-black' : 'bg-neutral-950 text-neutral-400'
                  }`}
                >
                  Reclaim Coins
                </button>
              </div>

              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Current Seller Balance:</span>
                  <span className="font-bold text-yellow-400">{((selectedSellerForCoins?.testCoinBalance) ?? 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Owner Treasury Balance:</span>
                  <span className="font-bold text-amber-400">{(ownerTestCoinBalance ?? 0).toLocaleString()}</span>
                </div>
              </div>

              <div>
                <label className="block text-neutral-400 font-bold mb-1">Amount (TEST COINS) *</label>
                <input
                  type="number"
                  value={coinAmount}
                  onChange={(e) => setCoinAmount(e.target.value)}
                  step="100000"
                  min="1000"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-yellow-500"
                />
              </div>

              <div>
                <label className="block text-neutral-400 font-bold mb-1">Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Monthly QA Test Liquidity Grant"
                  value={coinNotes}
                  onChange={(e) => setCoinNotes(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-yellow-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  onClick={() => setSelectedSellerForCoins(null)}
                  className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 font-bold hover:bg-neutral-700"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCoinTransferSubmit}
                  disabled={isSubmitting}
                  className={`px-5 py-2 rounded-xl font-black text-neutral-950 transition-all ${
                    coinActionType === 'GIVE' ? 'bg-amber-500 hover:bg-amber-400' : 'bg-cyan-500 hover:bg-cyan-400'
                  }`}
                >
                  {isSubmitting ? 'Processing...' : 'Confirm Transaction'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CONFIGURE LIMITS MODAL */}
      {selectedSellerForLimits && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Configure Seller Caps
                  </h3>
                  <p className="text-[11px] text-neutral-400">{selectedSellerForLimits.name}</p>
                </div>
              </div>
              <button onClick={() => setSelectedSellerForLimits(null)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-neutral-400 font-bold mb-1">Daily Transfer Limit (TEST COINS)</label>
                <input
                  type="number"
                  value={newDailyLimit}
                  onChange={(e) => setNewDailyLimit(Number(e.target.value))}
                  step="1000000"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-yellow-500"
                />
              </div>

              <div>
                <label className="block text-neutral-400 font-bold mb-1">Single Transaction Cap (TEST COINS)</label>
                <input
                  type="number"
                  value={newSingleLimit}
                  onChange={(e) => setNewSingleLimit(Number(e.target.value))}
                  step="500000"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-yellow-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  onClick={() => setSelectedSellerForLimits(null)}
                  className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 font-bold hover:bg-neutral-700"
                >
                  Cancel
                </button>
                <button
                  onClick={handleLimitsSubmit}
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-purple-500 hover:bg-purple-400 text-neutral-950 font-black transition-all"
                >
                  {isSubmitting ? 'Saving...' : 'Save Limits'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DISBURSEMENT HISTORY MODAL */}
      {viewHistorySeller && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-2xl p-6 shadow-2xl space-y-4 animate-in zoom-in-95 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    {viewHistorySeller.name} — User Transfers
                  </h3>
                  <p className="text-[11px] text-neutral-400">Total Distributed: {((viewHistorySeller?.totalDistributed) ?? 0).toLocaleString()} TEST COINS</p>
                </div>
              </div>
              <button onClick={() => setViewHistorySeller(null)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <div className="overflow-y-auto flex-1 rounded-xl border border-neutral-800 text-xs">
              <table className="w-full text-left text-neutral-300">
                <thead className="bg-neutral-950 text-neutral-400 font-bold uppercase tracking-wider sticky top-0">
                  <tr>
                    <th className="py-2.5 px-3">Tx ID</th>
                    <th className="py-2.5 px-3">Recipient User</th>
                    <th className="py-2.5 px-3">Amount</th>
                    <th className="py-2.5 px-3">Time</th>
                    <th className="py-2.5 px-3">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800 font-mono">
                  {historyForSelectedSeller.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-neutral-500">
                        No user distribution transactions on record for this seller.
                      </td>
                    </tr>
                  ) : (
                    historyForSelectedSeller.map(tx => (
                      <tr key={tx.id} className="hover:bg-neutral-800/40">
                        <td className="py-2.5 px-3 text-yellow-400 font-bold">{tx.id}</td>
                        <td className="py-2.5 px-3 font-sans font-medium text-white">
                          {tx.userName} <span className="text-[10px] text-neutral-500">({tx.userId})</span>
                        </td>
                        <td className="py-2.5 px-3 text-emerald-400 font-bold">
                          +{((tx?.amount) ?? 0).toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-neutral-500 text-[10px] font-sans">{tx.timestamp}</td>
                        <td className="py-2.5 px-3 text-neutral-400 text-[11px] font-sans truncate max-w-xs">{tx.notes || '—'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="pt-3 border-t border-neutral-800 flex justify-end">
              <button
                onClick={() => setViewHistorySeller(null)}
                className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 font-bold hover:bg-neutral-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
