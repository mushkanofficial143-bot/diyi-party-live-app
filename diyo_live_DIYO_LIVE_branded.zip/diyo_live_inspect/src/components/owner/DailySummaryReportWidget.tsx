import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Calendar, 
  ShieldAlert, 
  Activity, 
  CheckCircle, 
  AlertTriangle, 
  Filter, 
  Search,
  RefreshCw,
  Clock,
  User,
  Shield,
  Layers
} from 'lucide-react';
import { AuditLogEntry, ModerationReport } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface DailySummaryReportWidgetProps {
  auditLogs: AuditLogEntry[];
  reports: ModerationReport[];
  onResolveReport?: (reportId: string) => void;
}

export interface SummaryRowItem {
  id: string;
  sourceType: 'AUDIT_LOG' | 'USER_REPORT';
  timestamp: string;
  actorOrReporter: string;
  actorRole: string;
  target: string;
  categoryOrAction: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'INFO';
  status: 'FLAGGED' | 'RESOLVED' | 'SUCCESS' | 'DENIED' | 'PENDING';
  details: string;
}

export const DailySummaryReportWidget: React.FC<DailySummaryReportWidgetProps> = ({
  auditLogs = [],
  reports = [],
  onResolveReport
}) => {
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [sourceFilter, setSourceFilter] = useState<'ALL' | 'AUDIT' | 'REPORTS'>('ALL');
  const [severityFilter, setSeverityFilter] = useState<'ALL' | 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'INFO'>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  // Map and combine audit logs & moderation reports into a unified daily summary dataset
  const unifiedRows: SummaryRowItem[] = [
    ...(auditLogs || []).map((log) => {
      let severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'INFO' = 'INFO';
      const actionStr = (log?.action || '').toUpperCase();
      const statusStr = (log?.status || '').toUpperCase();

      if (statusStr === 'FLAGGED' || statusStr === 'DENIED') severity = 'CRITICAL';
      else if (actionStr.includes('BAN') || actionStr.includes('SUSPEND') || actionStr.includes('RECLAIM')) severity = 'HIGH';
      else if (actionStr.includes('ASSIGN') || actionStr.includes('UPDATE')) severity = 'MEDIUM';

      return {
        id: log?.id || `LOG-${Date.now()}`,
        sourceType: 'AUDIT_LOG' as const,
        timestamp: log?.timestamp || new Date().toISOString(),
        actorOrReporter: log?.actorName || log?.actorId || 'System',
        actorRole: log?.actorRole || 'SYSTEM',
        target: log?.targetId ? `${log?.targetType || 'TARGET'}: ${log.targetId}` : 'System Platform',
        categoryOrAction: log?.action || 'AUDIT_ACTION',
        severity,
        status: (log?.status as any) || 'SUCCESS',
        details: log?.details || 'Operational action logged server-side'
      };
    }),
    ...(reports || []).map((rpt) => {
      let severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'INFO' = 'MEDIUM';
      const reasonStr = (rpt?.reason || '');

      if (reasonStr.includes('Harassment') || reasonStr.includes('Hate') || reasonStr.includes('Nudity') || reasonStr.includes('Fraud')) severity = 'CRITICAL';
      else if (reasonStr.includes('Spam') || reasonStr.includes('Copyright')) severity = 'HIGH';

      return {
        id: rpt?.id || `RPT-${Date.now()}`,
        sourceType: 'USER_REPORT' as const,
        timestamp: rpt?.timestamp || new Date().toISOString(),
        actorOrReporter: rpt?.reporterName || 'Anonymous Reporter',
        actorRole: 'USER (Reporter)',
        target: `${rpt?.targetType || 'USER'}: ${rpt?.targetName || 'Broadcaster'} (${rpt?.targetId || 'N/A'})`,
        categoryOrAction: `REPORT: ${rpt?.reason || 'Flagged Content'}`,
        severity,
        status: (rpt?.status === 'Resolved' ? 'RESOLVED' : rpt?.status === 'Dismissed' ? 'DENIED' : 'FLAGGED') as any,
        details: rpt?.details || rpt?.reason || 'User report submitted'
      };
    })
  ];

  // Filter unified summary
  const filteredRows = (unifiedRows || []).filter((row) => {
    const matchesSource = 
      sourceFilter === 'ALL' ||
      (sourceFilter === 'AUDIT' && row.sourceType === 'AUDIT_LOG') ||
      (sourceFilter === 'REPORTS' && row.sourceType === 'USER_REPORT');

    const matchesSeverity = severityFilter === 'ALL' || row.severity === severityFilter;

    const q = (searchTerm || '').toLowerCase();
    const matchesSearch =
      !q ||
      (row.id || '').toLowerCase().includes(q) ||
      (row.actorOrReporter || '').toLowerCase().includes(q) ||
      (row.target || '').toLowerCase().includes(q) ||
      (row.categoryOrAction || '').toLowerCase().includes(q) ||
      (row.details || '').toLowerCase().includes(q);

    return matchesSource && matchesSeverity && matchesSearch;
  });

  // Calculate high-level summary KPIs
  const totalAuditEvents = (auditLogs || []).length;
  const flaggedReportsCount = (reports || []).filter(r => r && (r.status === 'Pending' || r.status === 'Investigating')).length;
  const resolvedReportsCount = (reports || []).filter(r => r && r.status === 'Resolved').length;
  const criticalAlertsCount = (unifiedRows || []).filter(r => r.severity === 'CRITICAL').length;

  const handleExportCSV = () => {
    setIsExporting(true);
    playSoundFX('click');
    
    const headers = ['ID', 'Type', 'Timestamp', 'Actor/Reporter', 'Role', 'Target', 'Action/Category', 'Severity', 'Status', 'Details'];
    const csvRows = filteredRows.map(r => [
      r.id,
      r.sourceType,
      `"${r.timestamp}"`,
      `"${r.actorOrReporter}"`,
      `"${r.actorRole}"`,
      `"${r.target}"`,
      `"${r.categoryOrAction}"`,
      r.severity,
      r.status,
      `"${r.details.replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...csvRows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SR_LIVE_Daily_Summary_${selectedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => setIsExporting(false), 800);
  };

  return (
    <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 space-y-5 shadow-2xl backdrop-blur-md">
      
      {/* Header & Date/Export Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white uppercase tracking-wider font-['Outfit']">
                Daily Operations & Security Summary Report
              </h3>
              <p className="text-xs text-neutral-400">
                Consolidated audit logs, security events, and flagged moderation reports.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-2 bg-neutral-950 px-3 py-1.5 rounded-xl border border-neutral-800 text-xs">
            <Calendar className="w-4 h-4 text-amber-400" />
            <input 
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent text-white font-mono text-xs focus:outline-none cursor-pointer"
            />
          </div>

          <button
            onClick={handleExportCSV}
            disabled={isExporting}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Exporting...' : 'Export CSV'}</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-neutral-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase text-neutral-400 block">Total Audit Events</span>
            <span className="text-lg font-black text-white font-mono">{totalAuditEvents}</span>
          </div>
          <Activity className="w-5 h-5 text-blue-400 opacity-80" />
        </div>

        <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-rose-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase text-rose-300 block">Flagged Reports</span>
            <span className="text-lg font-black text-rose-400 font-mono">{flaggedReportsCount}</span>
          </div>
          <ShieldAlert className="w-5 h-5 text-rose-400 opacity-80" />
        </div>

        <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-emerald-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase text-emerald-300 block">Resolved Cases</span>
            <span className="text-lg font-black text-emerald-400 font-mono">{resolvedReportsCount}</span>
          </div>
          <CheckCircle className="w-5 h-5 text-emerald-400 opacity-80" />
        </div>

        <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-amber-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase text-amber-300 block">Security Alerts</span>
            <span className="text-lg font-black text-amber-400 font-mono">{criticalAlertsCount}</span>
          </div>
          <AlertTriangle className="w-5 h-5 text-amber-400 opacity-80" />
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search report items by Actor, Target ID, Action, or Reason..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 text-xs"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Source Tabs */}
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800">
            {(['ALL', 'AUDIT', 'REPORTS'] as const).map((src) => (
              <button
                key={src}
                onClick={() => {
                  setSourceFilter(src);
                  playSoundFX('click');
                }}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                  sourceFilter === src
                    ? 'bg-amber-500 text-neutral-950 shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {src === 'ALL' ? 'All Sources' : src === 'AUDIT' ? 'Audit Logs' : 'User Reports'}
              </button>
            ))}
          </div>

          {/* Severity Filter */}
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800">
            {(['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'INFO'] as const).map((sev) => (
              <button
                key={sev}
                onClick={() => {
                  setSeverityFilter(sev);
                  playSoundFX('click');
                }}
                className={`px-2 py-1 rounded-lg font-bold text-[10px] transition-all cursor-pointer ${
                  severityFilter === sev
                    ? sev === 'CRITICAL' ? 'bg-rose-600 text-white' :
                      sev === 'HIGH' ? 'bg-amber-600 text-white' :
                      sev === 'MEDIUM' ? 'bg-blue-600 text-white' :
                      'bg-neutral-700 text-white'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Summary Report Table Widget */}
      <div className="overflow-x-auto rounded-xl border border-neutral-800 bg-neutral-950/80">
        <table className="w-full text-left text-xs text-neutral-300">
          <thead className="bg-neutral-900/90 text-neutral-400 uppercase text-[10px] font-bold tracking-wider border-b border-neutral-800">
            <tr>
              <th className="py-3 px-3.5">Log ID / Type</th>
              <th className="py-3 px-3.5">Time</th>
              <th className="py-3 px-3.5">Actor / Reporter</th>
              <th className="py-3 px-3.5">Target Entity</th>
              <th className="py-3 px-3.5">Action / Reason</th>
              <th className="py-3 px-3.5">Severity</th>
              <th className="py-3 px-3.5">Status</th>
              <th className="py-3 px-3.5 text-right">Details & Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800/70 font-sans">
            {filteredRows.length > 0 ? (
              filteredRows.map((row) => {
                const isReport = row.sourceType === 'USER_REPORT';

                return (
                  <tr key={row.id} className="hover:bg-neutral-900/50 transition-colors">
                    {/* ID & Type Badge */}
                    <td className="py-3 px-3.5">
                      <div className="flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          isReport 
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' 
                            : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                        }`}>
                          {isReport ? 'REPORT' : 'AUDIT'}
                        </span>
                        <span className="font-mono text-neutral-400 font-bold text-[11px]">{row.id}</span>
                      </div>
                    </td>

                    {/* Timestamp */}
                    <td className="py-3 px-3.5 font-mono text-neutral-400 text-[11px] whitespace-nowrap">
                      {row.timestamp}
                    </td>

                    {/* Actor / Reporter */}
                    <td className="py-3 px-3.5">
                      <div>
                        <span className="font-semibold text-white block">{row.actorOrReporter}</span>
                        <span className="text-[10px] text-neutral-400 font-mono">{row.actorRole}</span>
                      </div>
                    </td>

                    {/* Target Entity */}
                    <td className="py-3 px-3.5 font-mono text-[11px] text-neutral-300">
                      {row.target}
                    </td>

                    {/* Action / Category */}
                    <td className="py-3 px-3.5">
                      <span className="font-medium text-amber-300/90 text-xs">
                        {row.categoryOrAction}
                      </span>
                    </td>

                    {/* Severity */}
                    <td className="py-3 px-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        row.severity === 'CRITICAL' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' :
                        row.severity === 'HIGH' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                        row.severity === 'MEDIUM' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' :
                        'bg-neutral-800 text-neutral-400'
                      }`}>
                        {row.severity}
                      </span>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                        row.status === 'SUCCESS' || row.status === 'RESOLVED' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                        row.status === 'FLAGGED' || row.status === 'PENDING' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 animate-pulse' :
                        'bg-neutral-800 text-neutral-400'
                      }`}>
                        {row.status}
                      </span>
                    </td>

                    {/* Details & Action */}
                    <td className="py-3 px-3.5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="text-[11px] text-neutral-400 truncate max-w-xs block text-left" title={row.details}>
                          {row.details}
                        </span>
                        {isReport && row.status === 'FLAGGED' && onResolveReport && (
                          <button
                            onClick={() => {
                              onResolveReport(row.id);
                              playSoundFX('success');
                            }}
                            className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] transition-all cursor-pointer whitespace-nowrap"
                          >
                            Resolve
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={8} className="py-8 text-center text-neutral-500">
                  No summary items matched the selected filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Summary Footer */}
      <div className="flex items-center justify-between text-xs text-neutral-400 pt-2 border-t border-neutral-800">
        <span>Showing <strong className="text-white">{filteredRows.length}</strong> of <strong className="text-white">{unifiedRows.length}</strong> daily operational items</span>
        <span className="text-[11px] font-mono text-neutral-500">DIYO LIVE Enterprise Audit Engine • Auto-Refreshed</span>
      </div>
    </div>
  );
};
