import React, { useState } from 'react';
import { Sparkles, Plus, Search, Crown, CheckCircle2, Sliders, Trash2, Layers } from 'lucide-react';
import { AvatarFrameItem } from '../../types/ownerTypes';
import { ProfileFrameStudio } from '../frames/ProfileFrameStudio';

interface FramesSectionProps {
  frames: AvatarFrameItem[];
}

export const FramesSection: React.FC<FramesSectionProps> = ({ frames = [] }) => {
  const [tab, setTab] = useState<'official_system' | 'vip_catalog'>('official_system');
  const [frameList, setFrameList] = useState<AvatarFrameItem[]>(frames || []);
  const [search, setSearch] = useState('');

  const q = (search || '').toLowerCase();
  const filtered = (frameList || []).filter(f =>
    !q ||
    (f.name || '').toLowerCase().includes(q) ||
    (f.rarity || '').toLowerCase().includes(q)
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Toggle Switcher */}
      <div className="flex items-center justify-between p-2 rounded-2xl bg-neutral-900 border border-neutral-800">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setTab('official_system')}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all ${
              tab === 'official_system'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-black shadow-lg shadow-amber-500/20'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Crown className="w-4 h-4" />
            <span>Official DIYO LIVE 6-Role System</span>
          </button>

          <button
            onClick={() => setTab('vip_catalog')}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all ${
              tab === 'vip_catalog'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-black shadow-lg shadow-amber-500/20'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>VIP Store Catalog ({filtered.length})</span>
          </button>
        </div>

        <span className="text-xs text-amber-400/90 font-bold hidden sm:inline-block pr-2">
          Official DIYO LIVE Brand Asset Engine
        </span>
      </div>

      {/* Tab 1: Official DIYO LIVE 6-Role Profile Frame System Studio */}
      {tab === 'official_system' && (
        <ProfileFrameStudio />
      )}

      {/* Tab 2: VIP Catalog */}
      {tab === 'vip_catalog' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <span>Avatar Frames Catalog & VIP Rewards</span>
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Manage dynamic animated avatar frames, VIP tier exclusivity requirements, and test coin unlock pricing.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
            {filtered.map(frame => (
              <div key={frame.id} className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 flex flex-col justify-between hover:border-amber-500/40 transition-all">
                <div className="flex items-center justify-between">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                    frame.rarity === 'Royalty' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                    frame.rarity === 'Legendary' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                    'bg-purple-500/20 text-purple-300 border-purple-500/30'
                  }`}>
                    {frame.rarity}
                  </span>
                  <span className="text-[10px] text-neutral-500 font-mono">{frame.id}</span>
                </div>

                <div className="flex flex-col items-center py-2">
                  <div className="w-20 h-20 rounded-full p-1 border-2 border-amber-400 relative flex items-center justify-center">
                    <img
                      src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"
                      alt="Avatar Frame"
                      className="w-full h-full rounded-full object-cover"
                    />
                  </div>
                  <h4 className="font-bold text-white text-xs mt-2 text-center">{frame.name}</h4>
                  <span className="text-[11px] font-mono text-amber-400 font-bold">
                    {((frame?.coinPrice) ?? 0).toLocaleString()} Coins
                  </span>
                </div>

                <div className="pt-2 border-t border-neutral-800 flex justify-between items-center text-[11px] text-neutral-400">
                  <span>Required: <b>VIP {frame.vipLevelRequired}</b></span>
                  <span>{((frame?.activeUsersCount) ?? 0).toLocaleString()} Users</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

