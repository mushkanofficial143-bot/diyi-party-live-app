import React, { useState } from 'react';
import { Dices, Trophy, Flame, Play, ShieldAlert, CheckCircle, RefreshCw } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface GameManagementSectionProps {
  onAddAuditLog: (log: any) => void;
}

export const GameManagementSection: React.FC<GameManagementSectionProps> = ({ onAddAuditLog }) => {
  const [games, setGames] = useState([
    { id: 'gm-1', name: 'Trophy Fruit Party (3x3)', category: 'Arcade / Multiplier', status: 'Active', totalBets: 15480000, totalPayouts: 14200000, RTP: '91.7%' },
    { id: 'gm-2', name: 'Lucky Crash Rocket', category: 'Crash / Multiplier', status: 'Active', totalBets: 48900000, totalPayouts: 45100000, RTP: '92.2%' },
    { id: 'gm-3', name: 'Golden Lucky Wheel 777', category: 'Spin / Wheel', status: 'Active', totalBets: 22100000, totalPayouts: 20400000, RTP: '92.3%' }
  ]);

  const toggleGameStatus = (id: string) => {
    playSoundFX('click');
    setGames(prev => prev.map(g => {
      if (g.id === id) {
        const nextStatus = g.status === 'Active' ? 'Disabled' : 'Active';
        return { ...g, status: nextStatus };
      }
      return g;
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-white flex items-center gap-2">
            <Dices className="w-5 h-5 text-emerald-400" />
            <span>Game Management & Monitoring Dashboard</span>
          </h2>
          <p className="text-xs text-neutral-400">Monitor arcade game RTP, bets, payouts, and toggle live availability.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#131626]/90 border border-emerald-500/30 rounded-2xl p-5 shadow-xl">
          <p className="text-xs text-neutral-400 uppercase font-bold">Total Platform Bets</p>
          <h3 className="text-2xl font-black text-emerald-300 font-mono mt-1">🪙 86,480,000</h3>
          <p className="text-[11px] text-neutral-400 mt-2">All-time active wagers</p>
        </div>
        <div className="bg-[#131626]/90 border border-blue-500/30 rounded-2xl p-5 shadow-xl">
          <p className="text-xs text-neutral-400 uppercase font-bold">Total Game Payouts</p>
          <h3 className="text-2xl font-black text-blue-300 font-mono mt-1">🪙 79,700,000</h3>
          <p className="text-[11px] text-neutral-400 mt-2">Secured win payouts</p>
        </div>
        <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl p-5 shadow-xl">
          <p className="text-xs text-neutral-400 uppercase font-bold">Average House RTP</p>
          <h3 className="text-2xl font-black text-pink-300 font-mono mt-1">92.1%</h3>
          <p className="text-[11px] text-neutral-400 mt-2">Provably fair calibrated</p>
        </div>
      </div>

      <div className="bg-[#131626]/90 border border-purple-500/30 rounded-2xl overflow-hidden shadow-2xl">
        <div className="p-4 border-b border-purple-500/20 font-bold text-sm text-white">Active Arcade Game Catalogs</div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-purple-950/40 text-[11px] font-bold text-neutral-300 uppercase border-b border-purple-500/20 font-mono">
                <th className="py-3 px-4">Game Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Total Bets</th>
                <th className="py-3 px-4">Total Payouts</th>
                <th className="py-3 px-4">RTP</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs text-neutral-200">
              {games.map(g => (
                <tr key={g.id} className="hover:bg-white/5 transition-colors">
                  <td className="py-3 px-4 font-bold text-white flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-amber-400" />
                    <span>{g.name}</span>
                  </td>
                  <td className="py-3 px-4 text-neutral-300">{g.category}</td>
                  <td className="py-3 px-4 font-mono text-amber-300">🪙 {g.totalBets.toLocaleString()}</td>
                  <td className="py-3 px-4 font-mono text-emerald-300">🪙 {g.totalPayouts.toLocaleString()}</td>
                  <td className="py-3 px-4 font-mono text-pink-300">{g.RTP}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      g.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    }`}>
                      {g.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => toggleGameStatus(g.id)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                        g.status === 'Active' ? 'bg-rose-600/20 text-rose-300 border border-rose-500/40' : 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {g.status === 'Active' ? 'Disable Game' : 'Enable Game'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
