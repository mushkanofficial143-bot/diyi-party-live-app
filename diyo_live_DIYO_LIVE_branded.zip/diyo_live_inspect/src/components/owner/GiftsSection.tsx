import React, { useState } from 'react';
import { 
  Gift, 
  Plus, 
  Search, 
  Sparkles, 
  Flame, 
  Edit, 
  Trash2, 
  Coins, 
  Gem, 
  ToggleLeft, 
  ToggleRight,
  Zap,
  Crown,
  X,
  CheckCircle,
  Save
} from 'lucide-react';
import { GiftItem, GiftCategory } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface GiftsSectionProps {
  gifts: GiftItem[];
  onOpenCreate?: () => void;
  onToggleActive?: (giftId: string) => void;
  onDeleteGift?: (giftId: string) => void;
  onUpdateGiftsCatalog?: (newGifts: GiftItem[]) => void;
}

export const GiftsSection: React.FC<GiftsSectionProps> = ({
  gifts,
  onOpenCreate,
  onToggleActive,
  onDeleteGift,
  onUpdateGiftsCatalog
}) => {
  const [filterType, setFilterType] = useState<GiftCategory>('ALL');
  const [search, setSearch] = useState('');
  const [editingGift, setEditingGift] = useState<GiftItem | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(false);
  const [saveSuccessToast, setSaveSuccessToast] = useState<string | null>(null);

  // Form State for Create / Edit
  const [formData, setFormData] = useState<Partial<GiftItem>>({
    name: '',
    icon: '🎁',
    coinPrice: 1000,
    diamondValue: 700,
    category: 'POPULAR',
    animationType: 'pop',
    isLucky: false,
    luckyMultiplierMax: 100,
    isLuckyBox: false,
    isRedPacket: false,
    isActive: true
  });

  const categories: GiftCategory[] = ['ALL', 'FLAGS', 'POPULAR', 'VIP', 'SPECIAL', 'LUCKY', 'RED PACKET'];

  const filtered = gifts.filter((g) => {
    const matchesType =
      filterType === 'ALL' ||
      (g.category && g.category.toUpperCase() === filterType.toUpperCase());

    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (g.name || '').toLowerCase().includes(q) ||
      (g.category || '').toLowerCase().includes(q) ||
      (g.id || '').toLowerCase().includes(q);

    return matchesType && matchesSearch;
  });

  const handleOpenEdit = (gift: GiftItem) => {
    setEditingGift(gift);
    setFormData({ ...gift });
    setIsCreatingNew(false);
  };

  const handleOpenCreateModal = () => {
    setEditingGift(null);
    setFormData({
      id: `GFT-${Date.now().toString().slice(-4)}`,
      name: '',
      icon: '🎁',
      coinPrice: 1000,
      diamondValue: 700,
      category: 'POPULAR',
      animationType: 'pop',
      isLucky: false,
      luckyMultiplierMax: 100,
      isLuckyBox: false,
      isRedPacket: false,
      isActive: true,
      totalSentCount: 0
    });
    setIsCreatingNew(true);
  };

  const handleSaveGiftForm = async () => {
    if (!formData.name) {
      alert('Please enter a gift name');
      return;
    }

    const payload: GiftItem = {
      id: formData.id || `GFT-${Date.now().toString().slice(-4)}`,
      name: formData.name,
      icon: formData.icon || '🎁',
      coinPrice: Number(formData.coinPrice) || 1000,
      diamondValue: Number(formData.diamondValue) || Math.floor((Number(formData.coinPrice) || 1000) * 0.7),
      category: (formData.category as GiftCategory) || 'POPULAR',
      animationType: formData.animationType || 'pop',
      isLucky: !!formData.isLucky,
      luckyMultiplierMax: formData.luckyMultiplierMax ? Number(formData.luckyMultiplierMax) : undefined,
      isLuckyBox: !!formData.isLuckyBox,
      isRedPacket: !!formData.isRedPacket,
      isActive: formData.isActive !== false,
      totalSentCount: formData.totalSentCount || 0
    };

    try {
      const res = await fetch('/api/gifts/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success && data.catalog) {
        if (onUpdateGiftsCatalog) onUpdateGiftsCatalog(data.catalog);
      }
    } catch (err) {
      // Local fallback
    }

    setSaveSuccessToast(`Saved gift: ${payload.name}`);
    setTimeout(() => setSaveSuccessToast(null), 3000);
    setIsCreatingNew(false);
    setEditingGift(null);
  };

  const handleDeleteGiftItem = async (giftId: string) => {
    if (!confirm('Are you sure you want to remove this gift from the catalog?')) return;
    try {
      const res = await fetch('/api/gifts/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ giftId })
      });
      const data = await res.json();
      if (data.success && data.catalog) {
        if (onUpdateGiftsCatalog) onUpdateGiftsCatalog(data.catalog);
      } else if (onDeleteGift) {
        onDeleteGift(giftId);
      }
    } catch (err) {
      if (onDeleteGift) onDeleteGift(giftId);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/40">
              <Gift className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Gifts Catalog & Lucky Boxes</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/30">
              ALL, POPULAR, VIP, SPECIAL, LUCKY, RED PACKET
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Configure broadcast gifting animations, coin costs, diamond yields, lucky multipliers, and room red packets.
          </p>
        </div>

        <button
          id="add-new-gift-catalog-btn"
          onClick={() => {
            handleOpenCreateModal();
            playSoundFX('click');
          }}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-bold shadow-lg shadow-purple-900/30 transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add New Gift</span>
        </button>
      </div>

      {saveSuccessToast && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/60 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-scale-up">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{saveSuccessToast}</span>
        </div>
      )}

      {/* Filter Toolbar (6 Categories) */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search gifts by name, category..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none w-full sm:w-auto pb-1 sm:pb-0">
          {categories.map((t) => (
            <button
              key={t}
              id={`owner-gift-cat-btn-${t.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1 rounded-xl font-bold whitespace-nowrap transition-all ${
                filterType === t
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Gifts */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {filtered.map((gift) => (
          <div 
            key={gift.id}
            className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between relative group ${
              gift.isLucky || gift.isLuckyBox
                ? 'bg-gradient-to-b from-amber-950/30 via-neutral-900 to-neutral-900 border-amber-500/40 hover:border-amber-400'
                : gift.isRedPacket
                ? 'bg-gradient-to-b from-rose-950/30 via-neutral-900 to-neutral-900 border-rose-500/40 hover:border-rose-400'
                : 'bg-neutral-900/80 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            {/* Top Tag */}
            <div className="flex items-center justify-between">
              {gift.isLuckyBox ? (
                <span className="px-1.5 py-0.5 rounded-full bg-amber-500/20 text-[9px] font-black text-amber-300 uppercase flex items-center gap-1 border border-amber-500/40">
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>10X–100X</span>
                </span>
              ) : gift.isLucky ? (
                <span className="px-1.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-pink-500 text-[9px] font-black text-black uppercase flex items-center gap-1 shadow-sm">
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>Up to {gift.luckyMultiplierMax}x</span>
                </span>
              ) : gift.isRedPacket ? (
                <span className="px-1.5 py-0.5 rounded-full bg-rose-500/20 text-[9px] font-black text-rose-300 uppercase border border-rose-500/40">
                  RED PACKET
                </span>
              ) : (
                <span className="text-[9px] text-neutral-400 uppercase font-mono">{gift.category}</span>
              )}

              <button
                onClick={() => {
                  if (onToggleActive) onToggleActive(gift.id);
                  playSoundFX('click');
                }}
                className={`text-[10px] font-bold ${gift.isActive ? 'text-emerald-400' : 'text-neutral-500'}`}
              >
                {gift.isActive ? 'Active' : 'Disabled'}
              </button>
            </div>

            {/* Gift Icon Display */}
            <div className="py-4 flex flex-col items-center justify-center">
              <span className="text-4xl group-hover:scale-125 transition-transform duration-300 filter drop-shadow-md">
                {gift.icon}
              </span>
              <h4 className="text-xs font-bold text-white mt-2 text-center truncate w-full">{gift.name}</h4>
              <span className="text-[10px] text-neutral-500 font-mono">[{gift.animationType}]</span>
            </div>

            {/* Price & Diamond Value */}
            <div className="space-y-1.5 pt-2 border-t border-neutral-800/80 text-[11px]">
              <div className="flex justify-between items-center text-neutral-300">
                <span className="text-neutral-400">Cost:</span>
                <span className="font-bold text-amber-400 font-mono">{(gift?.coinPrice ?? 0).toLocaleString()} 🪙</span>
              </div>
              <div className="flex justify-between items-center text-neutral-300">
                <span className="text-neutral-400">Yield:</span>
                <span className="font-bold text-rose-400 font-mono">{(gift?.diamondValue ?? 0).toLocaleString()} 💎</span>
              </div>

              <div className="pt-2 flex items-center justify-between text-[10px] text-neutral-400">
                <button
                  onClick={() => handleOpenEdit(gift)}
                  className="text-neutral-400 hover:text-amber-300 flex items-center gap-1 font-bold"
                >
                  <Edit className="w-3 h-3" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => {
                    handleDeleteGiftItem(gift.id);
                    playSoundFX('click');
                  }}
                  className="text-neutral-500 hover:text-rose-400 p-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Create Gift Modal */}
      {(isCreatingNew || editingGift) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md bg-neutral-900 border border-purple-500/40 rounded-3xl p-6 shadow-2xl space-y-4 text-neutral-100">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Gift className="w-4 h-4 text-purple-400" />
                <span>{isCreatingNew ? 'Create New Gift' : `Edit Gift: ${formData.name}`}</span>
              </h3>
              <button
                onClick={() => {
                  setIsCreatingNew(false);
                  setEditingGift(null);
                }}
                className="p-1 rounded-lg text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block text-neutral-400 mb-1">Gift Name</label>
                  <input
                    type="text"
                    value={formData.name || ''}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Royal Dragon Palace"
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Icon / Emoji</label>
                  <input
                    type="text"
                    value={formData.icon || ''}
                    onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                    placeholder="🐉"
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white text-center text-lg focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1">Category</label>
                  <select
                    value={formData.category || 'POPULAR'}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as GiftCategory })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                  >
                    {['FLAGS', 'POPULAR', 'VIP', 'SPECIAL', 'LUCKY', 'RED PACKET'].map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Animation Type</label>
                  <select
                    value={formData.animationType || 'pop'}
                    onChange={(e) => setFormData({ ...formData, animationType: e.target.value as any })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                  >
                    {['pop', 'fullscreen', 'rain', 'dragon', 'confetti', 'fireworks', 'sparkle'].map((a) => (
                      <option key={a} value={a}>{a}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1">Coin Price (Cost)</label>
                  <input
                    type="number"
                    value={formData.coinPrice || 0}
                    onChange={(e) => {
                      const p = Number(e.target.value);
                      setFormData({ ...formData, coinPrice: p, diamondValue: Math.floor(p * 0.7) });
                    }}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Diamond Yield (To Host)</label>
                  <input
                    type="number"
                    value={formData.diamondValue || 0}
                    onChange={(e) => setFormData({ ...formData, diamondValue: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* Flags */}
              <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isLucky || false}
                    onChange={(e) => setFormData({ ...formData, isLucky: e.target.checked })}
                    className="accent-purple-500 rounded"
                  />
                  <span>Is Lucky Gift (Has potential multiplier payout)</span>
                </label>
                {formData.isLucky && (
                  <div className="pl-6">
                    <label className="block text-[11px] text-neutral-400 mb-0.5">Max Multiplier (e.g. 500x)</label>
                    <input
                      type="number"
                      value={formData.luckyMultiplierMax || 500}
                      onChange={(e) => setFormData({ ...formData, luckyMultiplierMax: Number(e.target.value) })}
                      className="w-32 bg-neutral-900 border border-neutral-800 rounded-lg px-2 py-1 text-xs text-white"
                    />
                  </div>
                )}
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isLuckyBox || false}
                    onChange={(e) => setFormData({ ...formData, isLuckyBox: e.target.checked })}
                    className="accent-amber-500 rounded"
                  />
                  <span>Is SR Lucky Box (Opens 10X–100X multiplier flow)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isRedPacket || false}
                    onChange={(e) => setFormData({ ...formData, isRedPacket: e.target.checked })}
                    className="accent-rose-500 rounded"
                  />
                  <span>Is Virtual Red Packet (Opens room coin drop flow)</span>
                </label>
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-neutral-800">
              <button
                onClick={() => {
                  setIsCreatingNew(false);
                  setEditingGift(null);
                }}
                className="flex-1 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl text-xs font-bold transition-colors"
              >
                Cancel
              </button>
              <button
                id="submit-gift-form-btn"
                onClick={handleSaveGiftForm}
                className="flex-1 py-2.5 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg flex items-center justify-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save to Catalog</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
