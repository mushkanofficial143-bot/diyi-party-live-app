import React, { useState } from 'react';
import { 
  Crown, 
  ShieldCheck, 
  Shield, 
  UserCheck, 
  Building2, 
  Tv, 
  Users, 
  Coins,
  ArrowDown, 
  Info, 
  X, 
  ChevronRight,
  CheckCircle2,
  Lock
} from 'lucide-react';
import { UserRole } from '../../types/ownerTypes';
import { ROLE_HIERARCHY_RANK, ROLE_LABELS, ROLE_BADGE_COLORS } from '../../utils/rbacGuard';

interface HierarchyTreeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRoleFilter?: (role: UserRole) => void;
  superAdminsCount?: number;
  adminsCount?: number;
  managersCount?: number;
  agenciesCount?: number;
  hostsCount?: number;
  usersCount?: number;
}

export const HierarchyTreeModal: React.FC<HierarchyTreeModalProps> = ({
  isOpen,
  onClose,
  onSelectRoleFilter,
  superAdminsCount,
  adminsCount,
  managersCount,
  agenciesCount,
  hostsCount,
  usersCount
}) => {
  const [selectedNode, setSelectedNode] = useState<UserRole>('OWNER');

  if (!isOpen) return null;

  const hierarchyNodes: {
    role: UserRole;
    rank: number;
    title: string;
    description: string;
    authorityLevel: string;
    canManage: string[];
    cannotManage: string[];
    icon: any;
    color: string;
  }[] = [
    {
      role: 'OWNER',
      rank: 6,
      title: 'DIYO LIVE — Owner',
      description: 'The supreme administrator and root of DIYO LIVE. Unrestricted authority over all roles, system configs, wallets, and treasury.',
      authorityLevel: 'Absolute Full Access (100%)',
      canManage: ['Manager', 'Admin', 'Coin Seller', 'Agency', 'User', 'All Modules'],
      cannotManage: ['None (Root Authority)'],
      icon: Crown,
      color: 'from-amber-500 to-yellow-600'
    },
    {
      role: 'MANAGER',
      rank: 5,
      title: 'Manager',
      description: 'Talent & Agency managers. Oversees assigned partner agencies and host rosters.',
      authorityLevel: 'Talent & Agency Governance (Rank 5)',
      canManage: ['Assigned Agencies', 'Assigned Users'],
      cannotManage: ['Owner', 'Global Treasury'],
      icon: UserCheck,
      color: 'from-emerald-500 to-teal-600'
    },
    {
      role: 'ADMIN',
      rank: 4,
      title: 'Admin',
      description: 'Daily live operations & moderation. Investigates reports and executes user bans.',
      authorityLevel: 'Operations & Moderation (Rank 4)',
      canManage: ['Live Moderation', 'Reports', 'User Bans'],
      cannotManage: ['Manager', 'Owner'],
      icon: Shield,
      color: 'from-blue-500 to-cyan-600'
    },
    {
      role: 'COIN_SELLER',
      rank: 3,
      title: 'Coin Sellers',
      description: 'Authorized coin distributors. Manages coin balances, selling, and seller transaction history.',
      authorityLevel: 'Coin Distribution Scope (Rank 3)',
      canManage: ['Coin Balance', 'Coin Distribution', 'Assigned Users'],
      cannotManage: ['Admin', 'Owner'],
      icon: Coins,
      color: 'from-yellow-500 to-amber-600'
    },
    {
      role: 'AGENCY',
      rank: 2,
      title: 'Agency',
      description: 'Talent agency guilds. Recruits signed hosts and manages commission splits.',
      authorityLevel: 'Agency Scope Only (Rank 2)',
      canManage: ['Signed Users', 'Agency Payouts'],
      cannotManage: ['Coin Seller', 'Admin', 'Owner'],
      icon: Building2,
      color: 'from-cyan-500 to-blue-600'
    },
    {
      role: 'USER',
      rank: 1,
      title: 'User',
      description: 'Stream hosts, creators, and registered users. Broadcasts party live rooms, sends gifts, and joins parties.',
      authorityLevel: 'Standard User & Broadcaster (Rank 1)',
      canManage: ['Own Stream & Room', 'Personal Wallet'],
      cannotManage: ['Management Panels', 'Staff Roles'],
      icon: Users,
      color: 'from-neutral-700 to-neutral-800'
    }
  ];

  const activeNode = hierarchyNodes.find((n) => n.role === selectedNode) || hierarchyNodes[0];
  const ActiveIcon = activeNode.icon;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-950 border border-neutral-800 rounded-3xl p-6 max-w-4xl w-full shadow-2xl space-y-5 animate-in zoom-in-95 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center p-0.5 shadow-lg shadow-amber-500/20">
              <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
                <Crown className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-['Outfit'] flex items-center gap-2">
                DIYO LIVE ROLE HIERARCHY ARCHITECTURE
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  7-TIER RBAC
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                OWNER has ultimate authority. Lower tiers are restricted from accessing higher management scopes.
              </p>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body: Left Visual Tree + Right Role Inspector */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 flex-1 min-h-0 overflow-y-auto">
          
          {/* Left Column: Visual Hierarchy Flow (5 cols) */}
          <div className="md:col-span-5 space-y-2 pr-1">
            <div className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2">
              Chain of Authority Flow:
            </div>

            <div className="space-y-1.5">
              {hierarchyNodes.map((node, idx) => {
                const NodeIcon = node.icon;
                const isSelected = selectedNode === node.role;
                return (
                  <div key={node.role} className="flex flex-col items-center">
                    <button
                      onClick={() => setSelectedNode(node.role)}
                      className={`w-full p-2.5 rounded-2xl border text-left transition-all flex items-center justify-between group ${
                        isSelected
                          ? 'bg-neutral-900 border-amber-500 ring-2 ring-amber-500/30 shadow-lg shadow-amber-500/10'
                          : 'bg-neutral-950 hover:bg-neutral-900/80 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${node.color} flex items-center justify-center text-white shadow-sm flex-shrink-0`}>
                          <NodeIcon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                              {ROLE_LABELS[node.role]}
                            </span>
                          </div>
                          <span className="text-[10px] font-mono text-neutral-400">
                            Rank #{node.rank} • {node.authorityLevel.split(' ')[0]}
                          </span>
                        </div>
                      </div>

                      <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'text-amber-400 rotate-90' : 'text-neutral-600'}`} />
                    </button>

                    {idx < hierarchyNodes.length - 1 && (
                      <div className="my-0.5 flex flex-col items-center text-neutral-600">
                        <ArrowDown className="w-3.5 h-3.5 animate-bounce" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Node Details & Permissions Inspector (7 cols) */}
          <div className="md:col-span-7 bg-neutral-900/60 border border-neutral-800 rounded-2xl p-4.5 space-y-4 flex flex-col justify-between">
            <div className="space-y-3.5">
              
              {/* Header card of selected role */}
              <div className="flex items-center gap-3 pb-3 border-b border-neutral-800">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${activeNode.color} flex items-center justify-center text-white shadow-lg`}>
                  <ActiveIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">{activeNode.title}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${ROLE_BADGE_COLORS[activeNode.role]}`}>
                      Hierarchy Level: Rank {activeNode.rank} of 7
                    </span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="text-xs text-neutral-300 leading-relaxed bg-neutral-950/70 p-3 rounded-xl border border-neutral-800">
                {activeNode.description}
              </div>

              {/* Authority & Permission Scopes */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Authorized Management Capabilities:</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {activeNode.canManage.map((item) => (
                    <span key={item} className="text-[11px] px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-medium">
                      ✓ {item}
                    </span>
                  ))}
                </div>
              </div>

              {/* Restricted Scopes */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-rose-400" />
                  <span>Strictly Restricted Scopes (Security Boundary):</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {activeNode.cannotManage.map((item) => (
                    <span key={item} className="text-[11px] px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-300 border border-rose-500/20 font-medium">
                      ✕ {item}
                    </span>
                  ))}
                </div>
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-neutral-800 flex items-center justify-between gap-3">
              <span className="text-[11px] text-neutral-400 font-mono">
                RBAC Security Policy: STRICT_ENFORCED
              </span>

              {onSelectRoleFilter && (
                <button
                  onClick={() => {
                    onSelectRoleFilter(activeNode.role);
                    onClose();
                  }}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white text-xs font-bold shadow-lg shadow-amber-500/20 transition-all flex items-center gap-1.5"
                >
                  <span>Manage {ROLE_LABELS[activeNode.role].split(' ')[0]}s</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
