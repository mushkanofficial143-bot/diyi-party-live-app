import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Sparkles, 
  Tv, 
  Check, 
  ShieldCheck, 
  Coins, 
  Flame, 
  Crown, 
  Layers, 
  CheckCircle2, 
  XCircle, 
  RefreshCw,
  Gift,
  ArrowRight,
  TrendingUp,
  User,
  Zap
} from 'lucide-react';
import { HOST_TYPE_DEFINITIONS, MOCK_AVATAR_FRAMES } from '../../data/mockOwnerData';
import { HostTypeDefinition, HostTagType, HostAccount } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface HostEarningsLedgerEntry {
  id: string;
  hostId: string;
  hostName: string;
  hostTag: string;
  senderId: string;
  senderName: string;
  giftId: string;
  giftName: string;
  giftCostCoins: number;
  hostEarnedCoins: number;
  commissionRate: number;
  timestamp: string;
}

interface HostTypesSectionProps {
  hosts?: HostAccount[];
  onAssignHostType?: (hostId: string, hostTag: HostTagType) => void;
  onAssignAvatarFrame?: (hostId: string, frameUrl: string) => void;
}

export const HostTypesSection: React.FC<HostTypesSectionProps> = ({
  hosts = [],
  onAssignHostType,
  onAssignAvatarFrame
}) => {
  const [hostTypes, setHostTypes] = useState<HostTypeDefinition[]>(HOST_TYPE_DEFINITIONS);
  const [selectedTag, setSelectedTag] = useState<HostTagType>('CELEBRATE');
  const [ledger, setLedger] = useState<HostEarningsLedgerEntry[]>([]);
  const [loadingLedger, setLoadingLedger] = useState(false);
  const [activeTab, setActiveTab] = useState<'TYPES' | 'FRAMES' | 'LEDGER' | 'ASSIGN'>('TYPES');

  // Quick Host Assignment State
  const [assignHostId, setAssignHostId] = useState(hosts[0]?.id || 'HST-001');
  const [assignTag, setAssignTag] = useState<HostTagType>('CELEBRATE');
  const [assignFrameUrl, setAssignFrameUrl] = useState(MOCK_AVATAR_FRAMES[0]?.previewUrl || '');
  const [assignSuccess, setAssignSuccess] = useState(false);

  // Fetch host earnings ledger from backend
  const fetchLedger = async () => {
    setLoadingLedger(true);
    try {
      const res = await fetch('/api/host-earnings/ledger');
      if (res.ok) {
        const data = await res.json();
        setLedger(data.ledger || []);
      }
    } catch (err) {
      console.warn('Could not fetch host earnings ledger:', err);
    } finally {
      setLoadingLedger(false);
    }
  };

  useEffect(() => {
    fetchLedger();
  }, []);

  const handleToggleTypeStatus = (tag: HostTagType) => {
    setHostTypes(prev => prev.map(t => {
      if (t.tag === tag) {
        const nextStatus = t.status === 'Active' ? 'Disabled' : 'Active';
        playSoundFX('click');
        return { ...t, status: nextStatus };
      }
      return t;
    }));
  };

  const handleQuickAssign = async () => {
    try {
      const res = await fetch('/api/hosts/assign-type', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hostId: assignHostId,
          hostTag: assignTag,
          avatarFrameUrl: assignFrameUrl,
          operatorRole: 'SUPER_ADMIN'
        })
      });

      if (res.ok) {
        if (onAssignHostType) onAssignHostType(assignHostId, assignTag);
        if (onAssignAvatarFrame) onAssignAvatarFrame(assignHostId, assignFrameUrl);
        setAssignSuccess(true);
        playSoundFX('reward');
        setTimeout(() => setAssignSuccess(false), 3000);
      } else {
        alert('Failed to assign Host Tag.');
      }
    } catch (err) {
      console.error('Assign error:', err);
      // Fallback local
      if (onAssignHostType) onAssignHostType(assignHostId, assignTag);
      if (onAssignAvatarFrame) onAssignAvatarFrame(assignHostId, assignFrameUrl);
      setAssignSuccess(true);
      setTimeout(() => setAssignSuccess(false), 3000);
    }
  };

  const currentType = hostTypes.find(t => t.tag === selectedTag) || hostTypes[0];

  return (
    <div className="space-y-6">
      
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Award className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-black text-white tracking-wide font-['Outfit']">
              HOST TYPES, BADGES & FRAMES GOVERNANCE
            </h2>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold">
              OFFICIAL CREATOR MATRIX
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Owner authorization console for Celebrate, Talent, Singer, and Normal Host types, animated avatars, and gift splits.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded-2xl border border-neutral-800 self-start md:self-auto">
          <button
            onClick={() => { setActiveTab('TYPES'); playSoundFX('click'); }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'TYPES' ? 'bg-neutral-800 text-white shadow-md' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Host Types (4)
          </button>
          <button
            onClick={() => { setActiveTab('FRAMES'); playSoundFX('click'); }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'FRAMES' ? 'bg-neutral-800 text-white shadow-md' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Avatar Frames
          </button>
          <button
            onClick={() => { setActiveTab('ASSIGN'); playSoundFX('click'); }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'ASSIGN' ? 'bg-rose-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Assign Host
          </button>
          <button
            onClick={() => { setActiveTab('LEDGER'); fetchLedger(); playSoundFX('click'); }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
              activeTab === 'LEDGER' ? 'bg-neutral-800 text-white shadow-md' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <span>Earnings Ledger</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </button>
        </div>
      </div>

      {/* VIEW: 4 HOST TYPES */}
      {activeTab === 'TYPES' && (
        <div className="space-y-6">
          
          {/* 4 Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {hostTypes.map((ht) => {
              const isSelected = selectedTag === ht.tag;
              return (
                <div
                  key={ht.id}
                  onClick={() => {
                    setSelectedTag(ht.tag);
                    playSoundFX('click');
                  }}
                  className={`cursor-pointer rounded-2xl border p-4 transition-all relative overflow-hidden ${
                    isSelected ? 'ring-2 ring-rose-500 scale-[1.02]' : 'hover:border-neutral-700'
                  } ${ht.badgeBg} ${ht.badgeBorder}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="text-3xl p-2 rounded-2xl bg-black/40 border border-white/10">
                      {ht.badgeIcon}
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase border ${
                      ht.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-red-500/20 text-red-300 border-red-500/40'
                    }`}>
                      {ht.status}
                    </span>
                  </div>

                  <div className="mt-3 space-y-1">
                    <span className="text-[10px] font-bold text-neutral-400 uppercase font-mono">{ht.id}</span>
                    <h3 className="text-sm font-black text-white">{ht.name}</h3>
                    <p className="text-[11px] text-neutral-300 line-clamp-2">{ht.description}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs font-mono">
                    <span className="text-neutral-400">Commission</span>
                    <span className="font-bold text-amber-400">{ht.defaultCommissionRate}%</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Host Type Detailed Inspector */}
          <div className="bg-neutral-900/90 border border-neutral-800 rounded-3xl p-6 shadow-2xl backdrop-blur-md">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
              <div className="flex items-center gap-3">
                <span className="text-4xl">{currentType.badgeIcon}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black text-white">{currentType.name}</h3>
                    <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border ${currentType.badgeBg} ${currentType.badgeBorder} ${currentType.badgeText}`}>
                      {currentType.tagLabel}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 mt-0.5">{currentType.description}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleToggleTypeStatus(currentType.tag)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all border ${
                    currentType.status === 'Active'
                      ? 'bg-red-500/20 text-red-300 border-red-500/40 hover:bg-red-500/30'
                      : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                  }`}
                >
                  {currentType.status === 'Active' ? <XCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                  <span>{currentType.status === 'Active' ? 'Disable This Type' : 'Enable This Type'}</span>
                </button>
              </div>
            </div>

            {/* Visual Specs & Perks Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
              
              {/* Frame & Badge Preview */}
              <div className="bg-neutral-950/80 border border-neutral-800 rounded-2xl p-4 flex flex-col items-center justify-center text-center space-y-3">
                <span className="text-[10px] font-bold text-neutral-400 uppercase">Live Avatar & Frame Preview</span>
                
                <div className="relative">
                  <div className={`w-24 h-24 rounded-full p-1 border-4 ${currentType.roomBorderColor} ${currentType.roomBorderGlow} shadow-2xl flex items-center justify-center relative overflow-hidden`}>
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150"
                      alt="Host Preview"
                      className="w-full h-full rounded-full object-cover"
                    />
                  </div>
                  <span className="absolute -bottom-2 -right-1 text-2xl">{currentType.badgeIcon}</span>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-white">{currentType.frameName}</h4>
                  <span className="text-[10px] text-amber-400 font-mono">Special FX Aura Active</span>
                </div>
              </div>

              {/* Room & Entry Attributes */}
              <div className="bg-neutral-950/80 border border-neutral-800 rounded-2xl p-4 space-y-3 text-xs">
                <span className="text-[10px] font-bold text-neutral-400 uppercase block pb-2 border-b border-neutral-800">
                  Visual & Audio Specs
                </span>

                <div className="flex justify-between items-center py-1">
                  <span className="text-neutral-400">Entry Animation Effect</span>
                  <span className="font-bold text-amber-300">{currentType.entryEffect}</span>
                </div>

                <div className="flex justify-between items-center py-1">
                  <span className="text-neutral-400">Live Room Border</span>
                  <span className="font-bold text-white font-mono">{currentType.roomBorderColor}</span>
                </div>

                <div className="flex justify-between items-center py-1">
                  <span className="text-neutral-400">Default Gift Split</span>
                  <span className="font-bold text-emerald-400 font-mono">{currentType.defaultCommissionRate}% to Host</span>
                </div>

                <div className="flex justify-between items-center py-1">
                  <span className="text-neutral-400">Assignment Permission</span>
                  <span className="font-bold text-rose-400">Owner & Super Admin Only</span>
                </div>
              </div>

              {/* Assigned Broadcasters Count */}
              <div className="bg-neutral-950/80 border border-neutral-800 rounded-2xl p-4 space-y-3 text-xs">
                <span className="text-[10px] font-bold text-neutral-400 uppercase block pb-2 border-b border-neutral-800">
                  Roster Distribution
                </span>

                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Currently Assigned</span>
                  <span className="text-lg font-black text-white font-mono">
                    {hosts.filter(h => (h.hostTag || 'CELEBRATE') === currentType.tag).length} Hosts
                  </span>
                </div>

                <p className="text-[11px] text-neutral-500">
                  Assigned hosts receive this badge on their stream cards, live rooms, search listings, and owner dashboards.
                </p>

                <button
                  onClick={() => {
                    setAssignTag(currentType.tag);
                    setActiveTab('ASSIGN');
                    playSoundFX('click');
                  }}
                  className="w-full py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
                >
                  <span>Assign Hosts to {currentType.tag}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* VIEW: AVATAR FRAMES */}
      {activeTab === 'FRAMES' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {MOCK_AVATAR_FRAMES.map(frame => (
              <div 
                key={frame.id}
                className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 flex flex-col items-center text-center hover:border-neutral-700 transition-all space-y-2"
              >
                <div className="relative w-20 h-20 flex items-center justify-center">
                  <img
                    src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"
                    alt="Sample"
                    className="w-14 h-14 rounded-full object-cover"
                  />
                  <img
                    src={frame.previewUrl}
                    alt={frame.name}
                    className="absolute inset-0 w-full h-full object-contain pointer-events-none"
                  />
                </div>

                <div>
                  <h4 className="text-xs font-bold text-white truncate max-w-[120px]">{frame.name}</h4>
                  <span className="text-[9px] font-bold text-amber-400 uppercase">{frame.rarity}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW: QUICK ASSIGN HOST */}
      {activeTab === 'ASSIGN' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-3xl p-6 max-w-2xl mx-auto space-y-5 shadow-2xl">
          <div>
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-rose-500" />
              <span>Direct Host Tag & Frame Assignment</span>
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Only authorized Owner/Super Admins can grant or modify Host Classifications.
            </p>
          </div>

          {assignSuccess && (
            <div className="p-3.5 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Host Classification & Avatar Frame successfully assigned and synchronized!</span>
            </div>
          )}

          {/* Form */}
          <div className="space-y-4 text-xs">
            <div>
              <label className="text-[11px] font-bold text-neutral-300 uppercase block mb-1">Select Host</label>
              <select
                value={assignHostId}
                onChange={(e) => setAssignHostId(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2.5 text-white font-medium focus:border-rose-500 focus:outline-none"
              >
                {hosts.map(h => (
                  <option key={h.id} value={h.id}>
                    {h.name} (@{h.username}) • {h.id} • Current: {h.hostTag || 'CELEBRATE'}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-neutral-300 uppercase block mb-1">Select Host Tag</label>
              <div className="grid grid-cols-2 gap-2">
                {hostTypes.map(ht => (
                  <button
                    key={ht.id}
                    type="button"
                    onClick={() => setAssignTag(ht.tag)}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      assignTag === ht.tag
                        ? `${ht.badgeBg} ${ht.badgeBorder} ring-2 ring-rose-500`
                        : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{ht.badgeIcon}</span>
                      <div>
                        <span className="text-xs font-bold text-white block">{ht.name}</span>
                        <span className="text-[10px] text-neutral-400">{ht.defaultCommissionRate}% Commission</span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-neutral-300 uppercase block mb-1">Avatar Frame Selection</label>
              <select
                value={assignFrameUrl}
                onChange={(e) => setAssignFrameUrl(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2.5 text-white font-medium focus:border-rose-500 focus:outline-none"
              >
                {MOCK_AVATAR_FRAMES.map(f => (
                  <option key={f.id} value={f.previewUrl}>
                    {f.name} ({f.rarity})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleQuickAssign}
              className="w-full py-3 bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 hover:opacity-95 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-xl shadow-rose-600/30 transition-all"
            >
              Commit Host Assignment
            </button>
          </div>
        </div>
      )}

      {/* VIEW: EARNINGS LEDGER */}
      {activeTab === 'LEDGER' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Live Virtual Host Earnings Ledger</h3>
              <p className="text-xs text-neutral-400">Real-time test coin distributions generated from viewer gifts and lucky boxes.</p>
            </div>
            <button
              onClick={fetchLedger}
              disabled={loadingLedger}
              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold rounded-xl flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingLedger ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>

          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
                  <tr>
                    <th className="p-3">Transaction ID</th>
                    <th className="p-3">Host & Tag</th>
                    <th className="p-3">Sender</th>
                    <th className="p-3">Gift Item</th>
                    <th className="p-3">Gift Cost</th>
                    <th className="p-3">Host Earned</th>
                    <th className="p-3">Split %</th>
                    <th className="p-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60 font-mono text-[11px]">
                  {ledger.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-neutral-500 font-sans">
                        No transactions recorded yet in this session. Send test gifts in any live room to generate earnings entries.
                      </td>
                    </tr>
                  ) : (
                    ledger.map(tx => (
                      <tr key={tx.id} className="hover:bg-neutral-800/40">
                        <td className="p-3 text-rose-400 font-bold">{tx.id}</td>
                        <td className="p-3 text-white font-sans font-bold">
                          {tx.hostName} ({tx.hostTag})
                        </td>
                        <td className="p-3 text-neutral-300 font-sans">{tx.senderName}</td>
                        <td className="p-3 text-amber-300 font-sans">🎁 {tx.giftName}</td>
                        <td className="p-3 text-neutral-400">{tx.giftCostCoins.toLocaleString()}</td>
                        <td className="p-3 text-emerald-400 font-bold">+{tx.hostEarnedCoins.toLocaleString()} 🪙</td>
                        <td className="p-3 text-cyan-400">{tx.commissionRate}%</td>
                        <td className="p-3 text-neutral-500 text-[10px]">{tx.timestamp}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
