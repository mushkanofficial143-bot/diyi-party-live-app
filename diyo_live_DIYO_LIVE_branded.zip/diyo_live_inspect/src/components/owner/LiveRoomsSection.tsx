import React, { useState } from 'react';
import { 
  Radio, 
  Search, 
  Eye, 
  AlertTriangle, 
  StopCircle, 
  Sparkles, 
  Users, 
  Gem, 
  ShieldAlert,
  Volume2
} from 'lucide-react';
import { LiveRoomAccount } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface LiveRoomsSectionProps {
  liveRooms: LiveRoomAccount[];
  onTerminateRoom: (roomId: string) => void;
  onWarnHost: (hostId: string) => void;
  onJoinRoom?: (roomId: string) => void;
}

export const LiveRoomsSection: React.FC<LiveRoomsSectionProps> = ({
  liveRooms,
  onTerminateRoom,
  onWarnHost,
  onJoinRoom
}) => {
  const [search, setSearch] = useState('');

  const q = (search || '').toLowerCase();
  const filtered = (liveRooms || []).filter((rm) => 
    !q ||
    (rm.roomTitle || '').toLowerCase().includes(q) ||
    (rm.hostName || '').toLowerCase().includes(q) ||
    (rm.id || '').toLowerCase().includes(q) ||
    (rm.category || '').toLowerCase().includes(q)
  );

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40">
              <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Active Live Broadcast Rooms</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/30">
              {liveRooms.length} Broadcasters On-Air
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Real-time live room monitoring, stream bitrate health, diamond accumulation, and instant killswitch.
          </p>
        </div>
      </div>

      {/* Search Toolbar */}
      <div className="flex items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search Live Rooms by title, host, category..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500"
          />
        </div>
      </div>

      {/* Grid of Live Rooms */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((room) => (
          <div 
            key={room.id}
            className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl hover:border-rose-500/40 transition-all flex flex-col"
          >
            {/* Thumbnail Header */}
            <div className="relative h-44 bg-neutral-950 overflow-hidden group">
              <img
                src={room.thumbnail}
                alt={room.roomTitle}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/30 to-transparent" />

              {/* Status Badges */}
              <div className="absolute top-3 left-3 flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-rose-600/90 backdrop-blur-md text-white text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                  LIVE
                </span>
                <span className="px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-white text-[10px] font-mono">
                  {room.resolution}
                </span>
              </div>

              <div className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-md text-white text-[10px] font-bold flex items-center gap-1">
                <Users className="w-3 h-3 text-rose-400" />
                <span>{(room?.viewerCount ?? 0).toLocaleString()}</span>
              </div>

              {/* Host & Title overlay */}
              <div className="absolute bottom-3 left-3 right-3 space-y-1">
                <div className="flex items-center gap-2">
                  <img
                    src={room.thumbnail}
                    alt={room.hostName}
                    className="w-6 h-6 rounded-full object-cover border border-white/50"
                  />
                  <span className="text-xs font-bold text-white shadow-sm">{room.hostName}</span>
                </div>
                <h4 className="text-xs font-semibold text-neutral-200 truncate">{room.roomTitle}</h4>
              </div>
            </div>

            {/* Room Metrics Body */}
            <div className="p-4 space-y-3 flex-1 flex flex-col justify-between text-xs">
              <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800 text-center font-mono">
                <div>
                  <span className="text-[10px] text-neutral-400 block">Diamonds</span>
                  <span className="font-bold text-rose-400">{(room?.diamondsCollected ?? 0).toLocaleString()} 💎</span>
                </div>
                <div>
                  <span className="text-[10px] text-neutral-400 block">Bitrate</span>
                  <span className="font-bold text-cyan-400">{room.bitrate}</span>
                </div>
                <div>
                  <span className="text-[10px] text-neutral-400 block">Duration</span>
                  <span className="font-bold text-amber-400">{room.durationMinutes}m</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-neutral-800">
                <button
                  onClick={() => {
                    onWarnHost(room.hostId);
                    playSoundFX('notification');
                  }}
                  className="flex-1 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Send Warning</span>
                </button>

                <button
                  onClick={() => {
                    onTerminateRoom(room.id);
                    playSoundFX('click');
                  }}
                  className="flex-1 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <StopCircle className="w-3.5 h-3.5" />
                  <span>Kill Stream</span>
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
