import React, { useState, useEffect } from 'react';
import { 
  Gift, 
  Sparkles, 
  CheckCircle, 
  ToggleLeft, 
  ToggleRight, 
  ShieldCheck, 
  Sliders, 
  History, 
  Save, 
  RefreshCw,
  Zap,
  Lock,
  Unlock
} from 'lucide-react';
import { LuckyBoxConfig, LuckyBoxMultiplier, LuckyBoxItem } from '../../types/ownerTypes';
import { DEFAULT_LUCKY_BOX_CONFIG, INITIAL_LUCKY_BOX_HISTORY } from '../../data/platformFeaturesData';

interface LuckyBoxOwnerSectionProps {
  initialConfig?: LuckyBoxConfig;
  onSaveConfig?: (config: LuckyBoxConfig) => void;
}

export const LuckyBoxOwnerSection: React.FC<LuckyBoxOwnerSectionProps> = ({
  initialConfig = DEFAULT_LUCKY_BOX_CONFIG,
  onSaveConfig
}) => {
  const [config, setConfig] = useState<LuckyBoxConfig>(initialConfig);
  const [history, setHistory] = useState<LuckyBoxItem[]>(INITIAL_LUCKY_BOX_HISTORY);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  useEffect(() => {
    // Fetch live settings from server
    fetch('/api/lucky-box/settings')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.config) {
          setConfig(data.config);
        }
      })
      .catch(() => {});
  }, []);

  const handleToggleMaster = () => {
    setConfig(prev => ({ ...prev, enabled: !prev.enabled }));
  };

  const handleToggleMultiplier = (multiplier: LuckyBoxMultiplier) => {
    setConfig(prev => ({
      ...prev,
      multipliers: {
        ...prev.multipliers,
        [multiplier]: !prev.multipliers[multiplier]
      }
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      const res = await fetch('/api/lucky-box/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      const data = await res.json();
      if (data.success) {
        setSaveSuccess(true);
        if (onSaveConfig) onSaveConfig(config);
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      setSaveSuccess(true);
      if (onSaveConfig) onSaveConfig(config);
      setTimeout(() => setSaveSuccess(false), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  const multiplierList: LuckyBoxMultiplier[] = ['10X', '20X', '30X', '50X', '100X'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
              <Gift className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-white font-['Outfit']">SR Lucky Box Management</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
              TEST COINS ONLY
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Configure broadcast Lucky Box mystery mechanics, multiplier toggles (10X, 20X, 30X, 50X, 100X), and RTP payout parameters.
          </p>
        </div>

        <button
          id="save-lucky-box-owner-config-btn"
          disabled={isSaving}
          onClick={handleSave}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          {isSaving ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Save className="w-4 h-4" />
          )}
          <span>Save Settings</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/60 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-scale-up">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>Lucky Box settings successfully updated across all live and party rooms!</span>
        </div>
      )}

      {/* Global Notice */}
      <div className="p-3.5 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center justify-between text-xs text-amber-300">
        <span className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          Strict Test Mode: All Lucky Box sends and opens operate exclusively on virtual TEST COINS.
        </span>
        <span className="font-mono text-neutral-400 text-[11px]">AUTHORITATIVE_RNG</span>
      </div>

      {/* Master Toggle & Core Parameters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Master Switch */}
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">Master Switch</span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
              config.enabled ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-red-950 text-red-300 border border-red-800'
            }`}>
              {config.enabled ? 'ENABLED' : 'DISABLED'}
            </span>
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Enable Lucky Box System</h4>
            <p className="text-xs text-neutral-400 mt-0.5">Toggle overall availability in Gift → Lucky tab</p>
          </div>
          <button
            id="toggle-master-lucky-box-btn"
            onClick={handleToggleMaster}
            className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              config.enabled
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                : 'bg-neutral-800 text-neutral-400 border border-neutral-700 hover:bg-neutral-700'
            }`}
          >
            {config.enabled ? <ToggleRight className="w-5 h-5 text-emerald-400" /> : <ToggleLeft className="w-5 h-5 text-neutral-500" />}
            <span>{config.enabled ? 'Feature is Active (Click to Disable)' : 'Feature is Disabled (Click to Enable)'}</span>
          </button>
        </div>

        {/* Base Cost Tier */}
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">Base Cost Settings</span>
          <div>
            <label className="text-xs text-neutral-400">Default Base Investment (TEST COINS)</label>
            <input
              type="number"
              value={config.baseCostCoins}
              onChange={(e) => setConfig({ ...config, baseCostCoins: Math.max(100, Number(e.target.value)) })}
              className="mt-1.5 w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:border-amber-500 focus:outline-none"
            />
          </div>
          <p className="text-[11px] text-neutral-500">
            Total cost = Base Cost × Multiplier. E.g., 1,000 × 50X = 50,000 TEST COINS.
          </p>
        </div>

        {/* Return to Player (RTP) Rate */}
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">Virtual Payout Rate</span>
          <div>
            <div className="flex justify-between text-xs text-neutral-400 mb-1">
              <span>Target RTP:</span>
              <strong className="text-amber-300">{config.rtpRate}%</strong>
            </div>
            <input
              type="range"
              min="80"
              max="99"
              step="0.5"
              value={config.rtpRate}
              onChange={(e) => setConfig({ ...config, rtpRate: Number(e.target.value) })}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>
          <p className="text-[11px] text-neutral-500">
            Virtual expected return to room receivers when mystery boxes are opened.
          </p>
        </div>
      </div>

      {/* Multipliers ON / OFF Configuration */}
      <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            Multiplier Options (10X, 20X, 30X, 50X, 100X)
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Individual switch for each multiplier tier. Disabled multipliers will appear locked to senders.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
          {multiplierList.map((multiplier) => {
            const isEnabled = config.multipliers[multiplier] ?? true;
            return (
              <div
                key={multiplier}
                className={`p-4 rounded-xl border transition-all flex flex-col justify-between space-y-3 ${
                  isEnabled
                    ? 'bg-neutral-950 border-amber-500/40 shadow-sm'
                    : 'bg-neutral-950/40 border-neutral-800 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-lg font-black text-white font-mono">{multiplier}</span>
                  {isEnabled ? (
                    <Unlock className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Lock className="w-4 h-4 text-neutral-500" />
                  )}
                </div>

                <div className="text-[11px] text-neutral-400">
                  Status: <strong className={isEnabled ? 'text-emerald-400' : 'text-neutral-500'}>
                    {isEnabled ? 'ACTIVE' : 'OFF'}
                  </strong>
                </div>

                <button
                  id={`toggle-owner-multiplier-${multiplier}`}
                  onClick={() => handleToggleMultiplier(multiplier)}
                  className={`w-full py-2 rounded-lg text-xs font-bold transition-all ${
                    isEnabled
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                      : 'bg-neutral-800 text-neutral-400 border border-neutral-700 hover:bg-neutral-700'
                  }`}
                >
                  {isEnabled ? 'Turn OFF' : 'Turn ON'}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Live History Logs */}
      <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Recent Lucky Box Operations
            </h3>
          </div>
          <span className="text-[11px] text-neutral-400">Authoritative Ledger</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-neutral-800 text-[10px] text-neutral-400 uppercase tracking-wider">
                <th className="pb-2 font-medium">Box ID</th>
                <th className="pb-2 font-medium">Sender ➔ Receiver</th>
                <th className="pb-2 font-medium">Multiplier</th>
                <th className="pb-2 font-medium text-right">Cost (TC)</th>
                <th className="pb-2 font-medium text-right">Reward Won</th>
                <th className="pb-2 font-medium text-center">Status</th>
                <th className="pb-2 font-medium text-right">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {(history || []).map((box) => (
                <tr key={box.id} className="hover:bg-neutral-800/40">
                  <td className="py-2.5 font-mono text-[11px] text-amber-300">{box.id}</td>
                  <td className="py-2.5 text-neutral-200">
                    {box.senderName} ➔ <strong className="text-white">{box.receiverName}</strong>
                  </td>
                  <td className="py-2.5 font-mono font-bold text-amber-400">{box.multiplier}</td>
                  <td className="py-2.5 text-right font-mono text-neutral-300">{((box?.costCoins) ?? 0).toLocaleString()}</td>
                  <td className="py-2.5 text-right font-mono font-bold text-emerald-400">
                    {box.wonRewardCoins ? `+${((box?.wonRewardCoins) ?? 0).toLocaleString()} TC` : '—'}
                  </td>
                  <td className="py-2.5 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      box.opened
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {box.opened ? 'OPENED' : 'UNOPENED'}
                    </span>
                  </td>
                  <td className="py-2.5 text-right text-neutral-400 text-[11px]">{box.createdAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
