import React, { useState } from 'react';
import { 
  UserCheck, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Eye, 
  CheckCircle2, 
  AlertTriangle, 
  Building2, 
  Tv, 
  Star,
  Layers
} from 'lucide-react';
import { ManagerAccount } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface ManagersSectionProps {
  managers: ManagerAccount[];
  onOpenDetail: (mgr: ManagerAccount) => void;
  onOpenCreate: () => void;
  onUpdateStatus: (id: string, newStatus: string) => void;
  onRemove: (id: string) => void;
}

export const ManagersSection: React.FC<ManagersSectionProps> = ({
  managers,
  onOpenDetail,
  onOpenCreate,
  onUpdateStatus,
  onRemove
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filtered = managers.filter((mgr) => {
    const matchesStatus = statusFilter === 'ALL' || mgr.status === statusFilter;
    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (mgr.name || '').toLowerCase().includes(q) ||
      (mgr.username || '').toLowerCase().includes(q) ||
      (mgr.id || '').toLowerCase().includes(q) ||
      (mgr.contact || '').toLowerCase().includes(q) ||
      (mgr.assignedAgencyNames || []).some((n) => (n || '').toLowerCase().includes(q));

    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              <UserCheck className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Talent Managers Management</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
              Rank #4
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Supervisors managing partner agency guilds and signed stream host talent rosters.
          </p>
        </div>

        <button
          onClick={() => {
            onOpenCreate();
            playSoundFX('click');
          }}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-lg shadow-emerald-900/30 transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Create Talent Manager</span>
        </button>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search Managers by ID, name, agency..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto">
          {['ALL', 'Active', 'Inactive', 'Suspended'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-xl font-bold transition-all ${
                statusFilter === st
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Table List */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-3.5">Manager ID & Name</th>
                <th className="p-3.5">Assigned Agencies</th>
                <th className="p-3.5">Hosts Roster</th>
                <th className="p-3.5">Earnings & Rating</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Owner Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filtered.map((mgr) => (
                <tr key={mgr.id} className="hover:bg-neutral-850/50 transition-colors">
                  
                  {/* Manager Info */}
                  <td className="p-3.5">
                    <div className="flex items-center gap-3">
                      <img
                        src={mgr.avatar}
                        alt={mgr.name}
                        className="w-9 h-9 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                      />
                      <div>
                        <span className="font-bold text-white block">{mgr.name}</span>
                        <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
                          <span className="font-mono text-emerald-400 font-bold">{mgr.id}</span>
                          <span>•</span>
                          <span>@{mgr.username}</span>
                        </div>
                        <span className="text-[10px] text-neutral-500 font-mono">{mgr.contact}</span>
                      </div>
                    </div>
                  </td>

                  {/* Assigned Agencies */}
                  <td className="p-3.5">
                    <div className="space-y-1">
                      {(mgr.assignedAgencyNames || []).map((an) => (
                        <span key={an} className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-[10px] mr-1">
                          <Building2 className="w-3 h-3" />
                          <span>{an}</span>
                        </span>
                      ))}
                    </div>
                  </td>

                  {/* Hosts Roster */}
                  <td className="p-3.5">
                    <div className="space-y-0.5">
                      <span className="font-bold text-white flex items-center gap-1">
                        <Tv className="w-3.5 h-3.5 text-rose-400" />
                        <span>{mgr.hostCount} Managed Hosts</span>
                      </span>
                      <span className="text-[10px] text-neutral-400 font-mono">
                        {mgr.assignedHosts.join(', ')}
                      </span>
                    </div>
                  </td>

                  {/* Earnings & Rating */}
                  <td className="p-3.5">
                    <div className="space-y-0.5">
                      <span className="font-mono text-amber-400 font-bold block">
                        {(mgr?.totalEarningsDiamonds ?? 0).toLocaleString()} 💎
                      </span>
                      <div className="flex items-center gap-1 text-emerald-400 font-bold text-[11px]">
                        <Star className="w-3 h-3 fill-emerald-400" />
                        <span>{mgr.performanceRating} / 5.0 Rating</span>
                      </div>
                    </div>
                  </td>

                  {/* Status */}
                  <td className="p-3.5">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                      mgr.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                      mgr.status === 'Suspended' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                      'bg-neutral-800 text-neutral-400 border-neutral-700'
                    }`}>
                      {mgr.status}
                    </span>
                  </td>

                  {/* Actions */}
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => {
                          onOpenDetail(mgr);
                          playSoundFX('click');
                        }}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white"
                        title="View Full Manager Profile"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          const nextStatus = mgr.status === 'Active' ? 'Suspended' : 'Active';
                          onUpdateStatus(mgr.id, nextStatus);
                          playSoundFX('click');
                        }}
                        className={`p-1.5 rounded-lg ${
                          mgr.status === 'Active' ? 'bg-amber-600/20 text-amber-300 hover:bg-amber-600/30' : 'bg-emerald-600 text-white'
                        }`}
                        title={mgr.status === 'Active' ? 'Suspend Manager' : 'Activate Manager'}
                      >
                        {mgr.status === 'Active' ? <AlertTriangle className="w-3.5 h-3.5" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => {
                          onRemove(mgr.id);
                          playSoundFX('click');
                        }}
                        className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300"
                        title="Remove Manager"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
