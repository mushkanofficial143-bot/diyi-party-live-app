import React, { useState } from 'react';
import { 
  Bell, 
  Send, 
  Search, 
  Sparkles, 
  Users, 
  Tv, 
  Building2, 
  Crown, 
  Radio,
  Plus
} from 'lucide-react';
import { NotificationItem } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface NotificationsSectionProps {
  notifications: NotificationItem[];
  onOpenCreate: () => void;
}

export const NotificationsSection: React.FC<NotificationsSectionProps> = ({
  notifications,
  onOpenCreate
}) => {
  const [search, setSearch] = useState('');

  const q = (search || '').toLowerCase();
  const filtered = (notifications || []).filter((n) =>
    !q ||
    (n.title || '').toLowerCase().includes(q) ||
    (n.message || '').toLowerCase().includes(q) ||
    (n.targetAudience || '').toLowerCase().includes(q)
  );

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
              <Bell className="w-4 h-4 text-amber-400" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">System Notifications & Broadcast Dispatcher</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
              Push Messaging
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Send real-time system alerts, event banners, and target-specific announcements to users, hosts, or agencies.
          </p>
        </div>

        <button
          onClick={() => {
            onOpenCreate();
            playSoundFX('click');
          }}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white text-xs font-bold shadow-lg shadow-amber-900/30 transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Send className="w-3.5 h-3.5" />
          <span>New Broadcast Alert</span>
        </button>
      </div>

      {/* Grid of Broadcasts */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((nt) => (
          <div
            key={nt.id}
            className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 shadow-xl hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                  Audience: {nt.targetAudience}
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">{nt.timestamp}</span>
              </div>

              <h4 className="text-sm font-bold text-white">{nt.title}</h4>
              <p className="text-xs text-neutral-300 leading-relaxed">{nt.message}</p>
            </div>

            <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-[11px] text-neutral-400">
              <span>Sent by: <strong className="text-neutral-200">{nt.sentBy}</strong></span>
              <span className="font-mono text-emerald-400 font-bold">{(nt?.readCount ?? 0).toLocaleString()} Delivered</span>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
