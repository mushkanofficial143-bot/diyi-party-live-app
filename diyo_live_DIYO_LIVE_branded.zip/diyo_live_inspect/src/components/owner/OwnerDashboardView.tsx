import React from 'react';
import { 
  Crown, 
  ShieldCheck, 
  Shield, 
  UserCheck, 
  Building2, 
  Tv, 
  Users, 
  Radio, 
  Coins, 
  Gem, 
  Gift, 
  Receipt, 
  TrendingUp, 
  AlertTriangle, 
  Layers, 
  Zap, 
  ArrowUpRight, 
  Sparkles,
  DollarSign,
  Activity,
  CheckCircle2
} from 'lucide-react';
import { OwnerDashboardStats, UserRole } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface OwnerDashboardViewProps {
  stats: OwnerDashboardStats;
  onNavigateSection: (sectionId: string) => void;
  onOpenHierarchyTree: () => void;
  onOpenActionModal: (type: any) => void;
}

export const OwnerDashboardView: React.FC<OwnerDashboardViewProps> = ({
  stats,
  onNavigateSection,
  onOpenHierarchyTree,
  onOpenActionModal
}) => {
  return (
    <div className="space-y-6">
      
      {/* Top Banner: Owner Master Control & Quick Trigger Actions */}
      <div className="relative overflow-hidden bg-gradient-to-r from-neutral-900 via-neutral-900 to-neutral-950 border border-amber-500/30 rounded-3xl p-6 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
                <Crown className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                DIYO LIVE ENTERPRISE GOVERNANCE
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                SYSTEM STATUS: 100% OPERATIONAL
              </span>
            </div>
            
            <h1 className="text-2xl font-black text-white font-['Outfit'] tracking-tight">
              Master Owner Control Hub
            </h1>
            <p className="text-xs text-neutral-300 max-w-2xl leading-relaxed">
              Full hierarchy management, RBAC enforcement, real-time 4K live room moderation, diamond economy, and multi-tier staff governance.
            </p>
          </div>

          {/* Quick Trigger Buttons */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => {
                onOpenHierarchyTree();
                playSoundFX('click');
              }}
              className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-100 hover:text-white border border-neutral-700 text-xs font-bold transition-all flex items-center gap-2 shadow-sm"
            >
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Explore Hierarchy Tree</span>
            </button>

            <button
              onClick={() => {
                onOpenActionModal('CREATE_SUPER_ADMIN');
                playSoundFX('click');
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-purple-900/30"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>+ Super Admin</span>
            </button>

            <button
              onClick={() => {
                onOpenActionModal('CREATE_AGENCY');
                playSoundFX('click');
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-rose-900/30"
            >
              <Building2 className="w-4 h-4" />
              <span>+ Agency Guild</span>
            </button>
          </div>
        </div>
      </div>

      {/* Role Population Metrics (Cards Grid 1: Roles) */}
      <div>
        <div className="flex items-center justify-between pb-3">
          <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5">
            <Users className="w-4 h-4 text-rose-500" />
            <span>Enterprise Role Hierarchy Census</span>
          </h3>
          <span className="text-[11px] text-neutral-500 font-mono">7 TIER ACTIVE ACCOUNTS</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          
          {/* Card 1: Super Admins */}
          <div 
            onClick={() => onNavigateSection('super_admins')}
            className="p-3.5 bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-purple-500/50 rounded-2xl cursor-pointer transition-all group"
          >
            <div className="flex items-center justify-between">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-purple-400" />
            </div>
            <p className="text-xl font-black text-white font-mono mt-2">{stats.superAdminsCount}</p>
            <p className="text-[10px] text-purple-300 font-semibold mt-0.5">Super Admins</p>
          </div>

          {/* Card 2: Admins */}
          <div 
            onClick={() => onNavigateSection('admins')}
            className="p-3.5 bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-blue-500/50 rounded-2xl cursor-pointer transition-all group"
          >
            <div className="flex items-center justify-between">
              <Shield className="w-4 h-4 text-blue-400" />
              <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-blue-400" />
            </div>
            <p className="text-xl font-black text-white font-mono mt-2">{stats.adminsCount}</p>
            <p className="text-[10px] text-blue-300 font-semibold mt-0.5">Admins</p>
          </div>

          {/* Card 3: Managers */}
          <div 
            onClick={() => onNavigateSection('managers')}
            className="p-3.5 bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-emerald-500/50 rounded-2xl cursor-pointer transition-all group"
          >
            <div className="flex items-center justify-between">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-emerald-400" />
            </div>
            <p className="text-xl font-black text-white font-mono mt-2">{stats.managersCount}</p>
            <p className="text-[10px] text-emerald-300 font-semibold mt-0.5">Managers</p>
          </div>

          {/* Card 4: Agencies */}
          <div 
            onClick={() => onNavigateSection('agencies')}
            className="p-3.5 bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-cyan-500/50 rounded-2xl cursor-pointer transition-all group"
          >
            <div className="flex items-center justify-between">
              <Building2 className="w-4 h-4 text-cyan-400" />
              <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-cyan-400" />
            </div>
            <p className="text-xl font-black text-white font-mono mt-2">{stats.agenciesCount}</p>
            <p className="text-[10px] text-cyan-300 font-semibold mt-0.5">Agencies</p>
          </div>

          {/* Card 5: Total Hosts */}
          <div 
            onClick={() => onNavigateSection('hosts')}
            className="p-3.5 bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-rose-500/50 rounded-2xl cursor-pointer transition-all group"
          >
            <div className="flex items-center justify-between">
              <Tv className="w-4 h-4 text-rose-400" />
              <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-rose-400" />
            </div>
            <p className="text-xl font-black text-white font-mono mt-2">{stats.hostsCount}</p>
            <p className="text-[10px] text-rose-300 font-semibold mt-0.5">Total Hosts</p>
          </div>

          {/* Card 6: Online Hosts */}
          <div 
            onClick={() => onNavigateSection('hosts')}
            className="p-3.5 bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-emerald-500/50 rounded-2xl cursor-pointer transition-all group relative overflow-hidden"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <Tv className="w-4 h-4 text-emerald-400" />
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-emerald-400" />
            </div>
            <p className="text-xl font-black text-emerald-400 font-mono mt-2">{stats.onlineHostsCount}</p>
            <p className="text-[10px] text-emerald-300 font-semibold mt-0.5">Online Hosts</p>
          </div>

          {/* Card 7: Users */}
          <div 
            onClick={() => onNavigateSection('users')}
            className="p-3.5 bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-amber-500/50 rounded-2xl cursor-pointer transition-all group"
          >
            <div className="flex items-center justify-between">
              <Users className="w-4 h-4 text-amber-400" />
              <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-amber-400" />
            </div>
            <p className="text-xl font-black text-white font-mono mt-2">{stats.usersCount}</p>
            <p className="text-[10px] text-amber-300 font-semibold mt-0.5">Registered Users</p>
          </div>

          {/* Card 8: Live Rooms */}
          <div 
            onClick={() => onNavigateSection('live_rooms')}
            className="p-3.5 bg-neutral-900/80 hover:bg-neutral-850 border border-neutral-800 hover:border-rose-500/50 rounded-2xl cursor-pointer transition-all group"
          >
            <div className="flex items-center justify-between">
              <Radio className="w-4 h-4 text-rose-500" />
              <ArrowUpRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-rose-500" />
            </div>
            <p className="text-xl font-black text-rose-400 font-mono mt-2">{stats.liveRoomsCount}</p>
            <p className="text-[10px] text-rose-300 font-semibold mt-0.5">Live Rooms</p>
          </div>

        </div>
      </div>

      {/* Financial & Economy Metrics (Cards Grid 2: Economy) */}
      <div>
        <div className="flex items-center justify-between pb-3">
          <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5">
            <Coins className="w-4 h-4 text-amber-500" />
            <span>Virtual Economy & Financial Liquidity</span>
          </h3>
          <span className="text-[11px] text-neutral-500 font-mono">REAL-TIME TREASURY METRICS</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Total Coins */}
          <div 
            onClick={() => onNavigateSection('wallet')}
            className="p-4 bg-gradient-to-br from-neutral-900 to-neutral-950 border border-yellow-500/30 rounded-2xl cursor-pointer hover:border-yellow-500/60 transition-all shadow-lg"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-yellow-400 uppercase tracking-wider">Total Coins Circulation</span>
              <Coins className="w-5 h-5 text-yellow-400" />
            </div>
            <p className="text-2xl font-black text-white font-mono mt-2">{(stats?.totalCoinsCirculation ?? 0).toLocaleString()} 🪙</p>
            <p className="text-[11px] text-neutral-400 mt-1">Total user wallet balances</p>
          </div>

          {/* Total Diamonds */}
          <div 
            onClick={() => onNavigateSection('wallet')}
            className="p-4 bg-gradient-to-br from-neutral-900 to-neutral-950 border border-rose-500/30 rounded-2xl cursor-pointer hover:border-rose-500/60 transition-all shadow-lg"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">Total Diamonds Minted</span>
              <Gem className="w-5 h-5 text-rose-400" />
            </div>
            <p className="text-2xl font-black text-white font-mono mt-2">{(stats?.totalDiamondsMinted ?? 0).toLocaleString()} 💎</p>
            <p className="text-[11px] text-neutral-400 mt-1">Host & Agency earned pool</p>
          </div>

          {/* Total Gifts */}
          <div 
            onClick={() => onNavigateSection('gifts')}
            className="p-4 bg-gradient-to-br from-neutral-900 to-neutral-950 border border-purple-500/30 rounded-2xl cursor-pointer hover:border-purple-500/60 transition-all shadow-lg"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">Total Virtual Gifts Sent</span>
              <Gift className="w-5 h-5 text-purple-400" />
            </div>
            <p className="text-2xl font-black text-white font-mono mt-2">{(stats?.totalGiftsSent ?? 0).toLocaleString()} 🎁</p>
            <p className="text-[11px] text-neutral-400 mt-1">Across 8 categories & Lucky Boxes</p>
          </div>

          {/* Total Test Transactions */}
          <div 
            onClick={() => onNavigateSection('wallet')}
            className="p-4 bg-gradient-to-br from-neutral-900 to-neutral-950 border border-cyan-500/30 rounded-2xl cursor-pointer hover:border-cyan-500/60 transition-all shadow-lg"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Total Test Transactions</span>
              <Receipt className="w-5 h-5 text-cyan-400" />
            </div>
            <p className="text-2xl font-black text-white font-mono mt-2">{stats?.totalTestTransactions ?? 0} Txns</p>
            <p className="text-[11px] text-neutral-400 mt-1">Sandbox liquidity & QA logs</p>
          </div>

        </div>
      </div>

      {/* Revenue Summary & Platform Health Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Revenue Performance Card */}
        <div className="p-5 bg-neutral-900/80 border border-neutral-800 rounded-3xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Platform Gross Revenue</span>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
              +28.4% this month
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-emerald-400 font-mono">
              ${(stats?.totalRevenueUSD ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span className="text-xs text-neutral-400">USD</span>
          </div>

          <div className="space-y-2 pt-2 border-t border-neutral-800 text-xs">
            <div className="flex justify-between text-neutral-300">
              <span className="text-neutral-400">Platform Commission (15%):</span>
              <span className="font-bold font-mono">${((stats?.totalRevenueUSD ?? 0) * 0.15).toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-neutral-300">
              <span className="text-neutral-400">Pending Host/Agency Payouts:</span>
              <span className="font-bold text-amber-400 font-mono">${(stats?.pendingWithdrawalsUSD ?? 0).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Security & Moderation Health */}
        <div className="p-5 bg-neutral-900/80 border border-neutral-800 rounded-3xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <span>Security & RBAC Enforcement</span>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
              Active Guard
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
              <span className="text-neutral-300">Normal User Panel Block</span>
              <span className="text-emerald-400 font-bold">100% BLOCKED</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
              <span className="text-neutral-300">Host → Agency Escalation Prevention</span>
              <span className="text-emerald-400 font-bold">ENFORCED</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
              <span className="text-neutral-300">Owner Account Tamper Protection</span>
              <span className="text-amber-400 font-bold">IMMUTABLE</span>
            </div>
          </div>
        </div>

        {/* Quick Management Shortcuts */}
        <div className="p-5 bg-neutral-900/80 border border-neutral-800 rounded-3xl space-y-3">
          <span className="text-xs font-bold text-white uppercase tracking-wider block">
            Owner Rapid Governance
          </span>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => onNavigateSection('hosts')}
              className="p-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-left transition-all group"
            >
              <Tv className="w-4 h-4 text-rose-400 mb-1 group-hover:scale-110 transition-transform" />
              <p className="font-bold text-white">Review Hosts</p>
              <p className="text-[10px] text-neutral-400">Approvals & bans</p>
            </button>

            <button
              onClick={() => onNavigateSection('withdrawals')}
              className="p-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-left transition-all group"
            >
              <DollarSign className="w-4 h-4 text-emerald-400 mb-1 group-hover:scale-110 transition-transform" />
              <p className="font-bold text-white">Withdrawals</p>
              <p className="text-[10px] text-neutral-400">Process payouts</p>
            </button>

            <button
              onClick={() => onNavigateSection('reports')}
              className="p-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-left transition-all group"
            >
              <AlertTriangle className="w-4 h-4 text-amber-400 mb-1 group-hover:scale-110 transition-transform" />
              <p className="font-bold text-white">Reports Queue</p>
              <p className="text-[10px] text-neutral-400">Stream moderation</p>
            </button>

            <button
              onClick={() => onNavigateSection('audit_logs')}
              className="p-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-left transition-all group"
            >
              <Activity className="w-4 h-4 text-cyan-400 mb-1 group-hover:scale-110 transition-transform" />
              <p className="font-bold text-white">Audit Logs</p>
              <p className="text-[10px] text-neutral-400">Action trail</p>
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
