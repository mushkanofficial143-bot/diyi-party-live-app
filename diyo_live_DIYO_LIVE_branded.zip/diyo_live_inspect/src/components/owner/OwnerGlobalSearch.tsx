import React, { useState, useMemo } from 'react';
import { 
  Search, 
  X, 
  Crown, 
  ShieldCheck, 
  Shield, 
  UserCheck, 
  Building2, 
  Tv, 
  Users, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { 
  UserRole, 
  SuperAdminAccount, 
  AdminAccount, 
  ManagerAccount, 
  AgencyAccount, 
  HostAccount, 
  UserAccount,
  HostTagType
} from '../../types/ownerTypes';
import { ROLE_LABELS, ROLE_BADGE_COLORS } from '../../utils/rbacGuard';
import { playSoundFX } from '../../utils/audioSynth';
import { HostTagBadge } from '../HostTagBadge';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';

interface OwnerGlobalSearchResult {
  id: string;
  name: string;
  username: string;
  role: UserRole;
  status: string;
  extraInfo: string;
  avatar: string;
  rawItem: any;
  hostTag?: HostTagType | string;
  avatarFrameUrl?: string;
  avatarFrameId?: string;
}

interface OwnerGlobalSearchProps {
  admins: AdminAccount[];
  managers: ManagerAccount[];
  agencies: AgencyAccount[];
  users: UserAccount[];
  onSelectEntity: (role: UserRole, item: any) => void;
}

export const OwnerGlobalSearch: React.FC<OwnerGlobalSearchProps> = ({
  admins,
  managers,
  agencies,
  users,
  onSelectEntity
}) => {
  const [query, setQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');

  const allEntities: OwnerGlobalSearchResult[] = useMemo(() => {
    const list: OwnerGlobalSearchResult[] = [];

    admins.forEach((adm) => {
      list.push({
        id: adm.id,
        name: adm.name,
        username: adm.username,
        role: 'ADMIN',
        status: adm.status,
        extraInfo: adm.contact,
        avatar: adm.avatar,
        rawItem: adm
      });
    });

    managers.forEach((mgr) => {
      list.push({
        id: mgr.id,
        name: mgr.name,
        username: mgr.username,
        role: 'MANAGER',
        status: mgr.status,
        extraInfo: `${mgr.assignedAgencies.length} agencies`,
        avatar: mgr.avatar,
        rawItem: mgr
      });
    });

    agencies.forEach((ag) => {
      list.push({
        id: ag.id,
        name: ag.name,
        username: ag.code,
        role: 'AGENCY',
        status: ag.status,
        extraInfo: `${ag.numberOfHosts} users (${ag.activeHosts} live) • ${ag.commissionRate}% comm`,
        avatar: ag.logo,
        rawItem: ag
      });
    });

    users.forEach((usr) => {
      list.push({
        id: usr.id,
        name: usr.name,
        username: usr.username,
        role: 'USER',
        status: usr.status,
        extraInfo: `VIP Level ${usr.vipLevel} • ${(usr.coinBalance ?? 0).toLocaleString()} 🪙`,
        avatar: usr.avatar,
        rawItem: usr
      });
    });

    return list;
  }, [admins, managers, agencies, users]);

  const filteredResults = useMemo(() => {
    if (!query || !query.trim()) return [];

    const q = query.toLowerCase().trim();
    return allEntities.filter((item) => {
      const matchesRole = roleFilter === 'ALL' || item.role === roleFilter;
      const matchesSearch =
        (item.id || '').toLowerCase().includes(q) ||
        (item.name || '').toLowerCase().includes(q) ||
        (item.username || '').toLowerCase().includes(q) ||
        (item.extraInfo || '').toLowerCase().includes(q);

      return matchesRole && matchesSearch;
    });
  }, [allEntities, query, roleFilter]);

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case 'ADMIN': return Shield;
      case 'MANAGER': return UserCheck;
      case 'AGENCY': return Building2;
      case 'USER': return Users;
      default: return Crown;
    }
  };

  return (
    <div className="relative w-full">
      {/* Search Input Bar */}
      <div className="relative flex items-center bg-neutral-900 border border-neutral-700/80 rounded-2xl px-3 py-2 shadow-inner focus-within:border-amber-500 focus-within:ring-2 focus-within:ring-amber-500/20 transition-all">
        <Search className="w-4 h-4 text-neutral-400 mr-2 flex-shrink-0" />
        
        <input
          type="text"
          placeholder="Global Search: User ID, Host ID, Agency ID, Manager ID, Admin ID, Super Admin ID, Username, Name..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full bg-transparent text-xs text-white placeholder-neutral-500 focus:outline-none"
        />

        {query && (
          <button 
            onClick={() => setQuery('')}
            className="text-xs text-neutral-400 hover:text-white px-1.5 py-0.5 rounded-lg bg-neutral-800"
          >
            ✕
          </button>
        )}
      </div>

      {/* Dropdown Results Overlay when query is active */}
      {query.trim().length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 z-40 bg-neutral-950/95 backdrop-blur-xl border border-neutral-800 rounded-2xl shadow-2xl p-3 max-h-96 overflow-y-auto space-y-2 animate-in fade-in slide-in-from-top-2">
          
          {/* Header & Quick Role Filters */}
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800 text-[11px]">
            <span className="font-bold text-neutral-400">
              Found <span className="text-amber-400">{filteredResults.length}</span> matching enterprise accounts
            </span>

            <div className="flex items-center gap-1 overflow-x-auto">
              {['ALL', 'SUPER_ADMIN', 'ADMIN', 'MANAGER', 'AGENCY', 'HOST', 'USER'].map((r) => (
                <button
                  key={r}
                  onClick={() => setRoleFilter(r)}
                  className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                    roleFilter === r
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'text-neutral-400 hover:text-white bg-neutral-900'
                  }`}
                >
                  {r.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Results List */}
          {filteredResults.length > 0 ? (
            <div className="divide-y divide-neutral-900">
              {filteredResults.map((item) => {
                const IconComponent = getRoleIcon(item.role);
                return (
                  <div
                    key={`${item.role}-${item.id}`}
                    onClick={() => {
                      onSelectEntity(item.role, item.rawItem);
                      playSoundFX('click');
                      setQuery('');
                    }}
                    className="p-2.5 hover:bg-neutral-900/90 rounded-xl transition-all cursor-pointer flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {item.role === 'HOST' ? (
                        <div className="flex-shrink-0">
                          <HostAvatarWithFrame
                            avatarUrl={item.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                            frameUrl={item.avatarFrameUrl}
                            frameId={item.avatarFrameId}
                            hostTag={item.hostTag || 'CELEBRATE'}
                            size="sm"
                          />
                        </div>
                      ) : (
                        <img
                          src={item.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                          alt={item.name}
                          className="w-9 h-9 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                        />
                      )}

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors truncate">
                            {item.name}
                          </span>
                          {item.role === 'HOST' && (
                            <HostTagBadge tag={item.hostTag || 'CELEBRATE'} size="xs" />
                          )}
                          <span className="text-[10px] font-mono text-neutral-400">
                            @{item.username}
                          </span>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${ROLE_BADGE_COLORS[item.role]}`}>
                            {item.role.replace('_', ' ')}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-[10px] text-neutral-400 mt-0.5">
                          <span className="font-mono text-amber-400 font-bold">{item.id}</span>
                          <span>•</span>
                          <span className="truncate">{item.extraInfo}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        (item.status || '').toLowerCase().includes('active') ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                        (item.status || '').toLowerCase().includes('banned') ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                        'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}>
                        {item.status}
                      </span>
                      <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-amber-400 group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-neutral-500">
              No matching accounts found for query "{query}".
            </div>
          )}

        </div>
      )}
    </div>
  );
};
