import React, { useState, useEffect } from 'react';
import {
  Coins,
  Send,
  RotateCcw,
  ArrowUpRight,
  ArrowDownLeft,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  Search,
  CheckCircle2,
  Lock,
  Building2,
  Users,
  Wallet,
  Sparkles,
  SlidersHorizontal,
  Save,
  Check,
  Info,
  UserCheck
} from 'lucide-react';
import { CoinSellerAccount, OwnerToSellerTransaction, PlatformWalletSettings } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface OwnerTestWalletSectionProps {
  ownerTestCoinBalance: number;
  coinSellers: CoinSellerAccount[];
  ownerToSellerTxs: OwnerToSellerTransaction[];
  onTransferToSeller: (sellerId: string, amount: number, notes?: string) => Promise<boolean>;
  onReclaimFromSeller: (sellerId: string, amount: number, notes?: string) => Promise<boolean>;
  walletSettings?: PlatformWalletSettings;
  onUpdateWalletSettings?: (settings: PlatformWalletSettings) => Promise<boolean> | void;
  platformUsers?: Array<{
    id: string;
    name: string;
    username?: string;
    avatar?: string;
    coinBalance?: number;
    diamondBalance?: number;
    status?: string;
  }>;
  onUserTransfer?: (senderId: string, receiverId: string, amount: number, notes?: string) => Promise<any>;
  onRefreshData?: () => void;
}

export const OwnerTestWalletSection: React.FC<OwnerTestWalletSectionProps> = ({
  ownerTestCoinBalance,
  coinSellers,
  ownerToSellerTxs,
  onTransferToSeller,
  onReclaimFromSeller,
  walletSettings = {
    userTransferEnabled: true,
    virtualExchangeEnabled: true,
    minTransferAmount: 100,
    maxTransferAmount: 10000000,
    coinToDiamondRate: 1.0,
    testModeNotice: "TEST MODE — Cash withdrawal is disabled."
  },
  onUpdateWalletSettings,
  platformUsers = [
    { id: 'USR-882941', name: 'Aarav Mehta', username: 'aarav_vip', coinBalance: 245000, diamondBalance: 18500, status: 'Active' },
    { id: 'USR-8001', name: 'Rohan Joshi', username: 'rohan_star', coinBalance: 120000, diamondBalance: 8500, status: 'Active' },
    { id: 'USR-8002', name: 'Meera Patel', username: 'meera_queen', coinBalance: 85000, diamondBalance: 12000, status: 'Active' },
    { id: 'USR-8003', name: 'Zoya Khan', username: 'zoya_live', coinBalance: 450000, diamondBalance: 35000, status: 'Active' },
    { id: 'USR-8004', name: 'David Miller', username: 'david_gamer', coinBalance: 15000, diamondBalance: 1200, status: 'Active' }
  ],
  onUserTransfer,
  onRefreshData
}) => {
  // Coin Seller state
  const [selectedSellerId, setSelectedSellerId] = useState<string>('');
  const [transferAmount, setTransferAmount] = useState<string>('5000000');
  const [transferNotes, setTransferNotes] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [searchTx, setSearchTx] = useState<string>('');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Settings Form State
  const [settingsForm, setSettingsForm] = useState<PlatformWalletSettings>({
    userTransferEnabled: walletSettings?.userTransferEnabled ?? true,
    virtualExchangeEnabled: walletSettings?.virtualExchangeEnabled ?? true,
    minTransferAmount: walletSettings?.minTransferAmount ?? 100,
    maxTransferAmount: walletSettings?.maxTransferAmount ?? 10000000,
    coinToDiamondRate: walletSettings?.coinToDiamondRate ?? 1.0,
    testModeNotice: walletSettings?.testModeNotice ?? "TEST MODE — Cash withdrawal is disabled."
  });
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsSavedToast, setSettingsSavedToast] = useState(false);

  // Simulator State
  const [simSenderId, setSimSenderId] = useState<string>('USR-8001');
  const [simReceiverId, setSimReceiverId] = useState<string>('USR-882941');
  const [simAmount, setSimAmount] = useState<string>('15000');
  const [simNotes, setSimNotes] = useState<string>('Owner QA simulator transfer');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  useEffect(() => {
    if (coinSellers.length > 0 && !selectedSellerId) {
      const activeSeller = coinSellers.find(s => s.status === 'Active') || coinSellers[0];
      setSelectedSellerId(activeSeller.id);
    }
  }, [coinSellers.length, selectedSellerId]);

  useEffect(() => {
    if (walletSettings) {
      setSettingsForm({
        userTransferEnabled: walletSettings.userTransferEnabled ?? true,
        virtualExchangeEnabled: walletSettings.virtualExchangeEnabled ?? true,
        minTransferAmount: walletSettings.minTransferAmount ?? 100,
        maxTransferAmount: walletSettings.maxTransferAmount ?? 10000000,
        coinToDiamondRate: walletSettings.coinToDiamondRate ?? 1.0,
        testModeNotice: walletSettings.testModeNotice ?? "TEST MODE — Cash withdrawal is disabled."
      });
    }
  }, [
    walletSettings?.userTransferEnabled,
    walletSettings?.virtualExchangeEnabled,
    walletSettings?.minTransferAmount,
    walletSettings?.maxTransferAmount,
    walletSettings?.coinToDiamondRate,
    walletSettings?.testModeNotice
  ]);

  const activeSellers = coinSellers.filter(s => s.status === 'Active');
  const selectedSeller = coinSellers.find(s => s.id === selectedSellerId);

  const totalDistributedToSellers = ownerToSellerTxs
    .filter(tx => tx.type === 'OWNER_TO_SELLER')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const totalReclaimed = ownerToSellerTxs
    .filter(tx => tx.type === 'RECLAIM_FROM_SELLER')
    .reduce((sum, tx) => sum + tx.amount, 0);

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    try {
      if (onUpdateWalletSettings) {
        await onUpdateWalletSettings(settingsForm);
      } else {
        await fetch('/api/wallet/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(settingsForm)
        });
      }
      playSoundFX('notification');
      setSettingsSavedToast(true);
      setTimeout(() => setSettingsSavedToast(false), 3500);
    } catch (err: any) {
      alert("Failed to save wallet settings: " + (err.message || 'Error'));
    } finally {
      setIsSavingSettings(false);
    }
  };

  // Run Simulator Transfer
  const handleRunSimulatorTransfer = async () => {
    if (simSenderId === simReceiverId) {
      alert("Sender and Receiver cannot be identical.");
      return;
    }
    const amt = Number(simAmount);
    if (!amt || amt <= 0) {
      alert("Please enter a valid amount.");
      return;
    }

    setIsSimulating(true);
    try {
      if (onUserTransfer) {
        const res = await onUserTransfer(simSenderId, simReceiverId, amt, simNotes);
        if (res && !res.success) {
          alert(`Transfer failed: ${res.error || 'Server error'}`);
          setIsSimulating(false);
          return;
        }
      } else {
        const res = await fetch('/api/wallet/transfer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            senderId: simSenderId,
            receiverId: simReceiverId,
            amount: amt,
            notes: simNotes
          })
        });
        const data = await res.json();
        if (!data.success) {
          alert(`Transfer failed: ${data.error}`);
          setIsSimulating(false);
          return;
        }
      }
      playSoundFX('win');
      setFeedbackMsg({
        type: 'success',
        text: `✅ Simulator: Successfully sent ${(amt ?? 0).toLocaleString()} TEST COINS from ${simSenderId} to ${simReceiverId}!`
      });
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      alert("Simulator error: " + err.message);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleExecuteTransfer = async () => {
    const amount = Number(transferAmount);
    if (!selectedSellerId) {
      setFeedbackMsg({ type: 'error', text: 'Please select an authorized Coin Seller.' });
      return;
    }
    if (!amount || amount <= 0) {
      setFeedbackMsg({ type: 'error', text: 'Enter a valid positive number of TEST COINS.' });
      return;
    }
    if (amount > ownerTestCoinBalance) {
      setFeedbackMsg({ type: 'error', text: 'Insufficient Owner Test Coin balance.' });
      return;
    }

    setIsProcessing(true);
    setFeedbackMsg(null);
    try {
      const success = await onTransferToSeller(selectedSellerId, amount, transferNotes);
      if (success) {
        setFeedbackMsg({
          type: 'success',
          text: `✅ Successfully distributed ${(amount ?? 0).toLocaleString()} TEST COINS to ${selectedSeller?.name}.`
        });
        setTransferNotes('');
      } else {
        setFeedbackMsg({ type: 'error', text: 'Server rejected the test coin distribution.' });
      }
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err.message || 'Transaction failed.' });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExecuteReclaim = async () => {
    const amount = Number(transferAmount);
    if (!selectedSellerId) {
      setFeedbackMsg({ type: 'error', text: 'Please select a Coin Seller.' });
      return;
    }
    if (!amount || amount <= 0) {
      setFeedbackMsg({ type: 'error', text: 'Enter a valid positive number of TEST COINS.' });
      return;
    }
    if (!selectedSeller || selectedSeller.testCoinBalance < amount) {
      setFeedbackMsg({
        type: 'error',
        text: `Seller only has ${(selectedSeller?.testCoinBalance ?? 0).toLocaleString()} TEST COINS available to reclaim.`
      });
      return;
    }

    setIsProcessing(true);
    setFeedbackMsg(null);
    try {
      const success = await onReclaimFromSeller(selectedSellerId, amount, transferNotes);
      if (success) {
        setFeedbackMsg({
          type: 'success',
          text: `✅ Successfully reclaimed ${(amount ?? 0).toLocaleString()} TEST COINS from ${selectedSeller.name}.`
        });
        setTransferNotes('');
      } else {
        setFeedbackMsg({ type: 'error', text: 'Server rejected the test coin reclaim.' });
      }
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err.message || 'Reclaim failed.' });
    } finally {
      setIsProcessing(false);
    }
  };

  const q = (searchTx || '').toLowerCase();
  const filteredTransactions = (ownerToSellerTxs || []).filter(tx =>
    (tx.id || '').toLowerCase().includes(q) ||
    (tx.sellerName || '').toLowerCase().includes(q) ||
    (tx.notes || '').toLowerCase().includes(q)
  );

  return (
    <div id="owner-test-wallet-section" className="space-y-6">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-amber-950/40 via-neutral-900 to-neutral-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
                <Wallet className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                DIYO LIVE TEST WALLET & TRANSFER CONTROLS
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                100% VIRTUAL SANDBOX
              </span>
            </div>
            <h1 className="text-2xl font-black text-white font-['Outfit'] tracking-tight">
              Test Treasury, User Transfers & Virtual Exchange
            </h1>
            <p className="text-xs text-neutral-400 max-w-2xl">
              Owner-level configuration for user-to-user transfers, virtual diamond exchange rates, limits, and server-side atomic validations.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-amber-500/30 font-mono text-right">
            <span className="text-[10px] text-neutral-400 uppercase font-bold block">Owner Test Treasury</span>
            <span className="text-2xl font-black text-amber-400">
              {(ownerTestCoinBalance ?? 0).toLocaleString()} 🪙
            </span>
            <span className="text-[10px] text-neutral-500 block">Virtual Sandbox Pool</span>
          </div>
        </div>

        {/* Withdrawal Status Banner */}
        <div className={`mt-4 flex items-center gap-2.5 px-4 py-2.5 rounded-xl border text-xs ${
          settingsForm.withdrawalsEnabled 
            ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300' 
            : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
        }`}>
          {settingsForm.withdrawalsEnabled ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          ) : (
            <Lock className="w-4 h-4 text-amber-400 flex-shrink-0" />
          )}
          <span className="font-bold">
            {settingsForm.withdrawalsEnabled 
              ? 'LIVE MODE — Creator & Host Diamond Cash Withdrawals are FULLY ENABLED & Active! Payout requests can now be submitted and processed.'
              : 'TEST MODE — Cash withdrawal is disabled. Real money deposits, bank transfers, UPI payouts, and crypto redemptions are strictly disabled.'}
          </span>
        </div>
      </div>

      {/* Global Feedback Message */}
      {feedbackMsg && (
        <div className={`p-4 rounded-2xl border flex items-center justify-between text-xs font-bold animate-in fade-in ${
          feedbackMsg.type === 'success'
            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-lg shadow-emerald-950/40'
            : 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-lg shadow-rose-950/40'
        }`}>
          <div className="flex items-center gap-2">
            {feedbackMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
            <span>{feedbackMsg.text}</span>
          </div>
          <button onClick={() => setFeedbackMsg(null)} className="text-neutral-400 hover:text-white">✕</button>
        </div>
      )}

      {/* SECTION 1: OWNER CONFIGURATION — USER TRANSFER & EXCHANGE CONTROLS */}
      <div className="p-6 rounded-3xl bg-neutral-900/90 border border-neutral-800 space-y-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              Coin Transfer & Virtual Exchange Settings (Owner Controls)
            </h2>
          </div>
          {settingsSavedToast && (
            <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
              <CheckCircle2 className="w-3.5 h-3.5" /> Settings Saved!
            </span>
          )}
        </div>

        <form onSubmit={handleSaveSettings} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            
            {/* Withdrawals Enabled Toggle Card */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-neutral-200">Creator & Host Withdrawals</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  settingsForm.withdrawalsEnabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                }`}>
                  {settingsForm.withdrawalsEnabled ? 'ACTIVE (ENABLED)' : 'DISABLED'}
                </span>
              </div>
              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={Boolean(settingsForm.withdrawalsEnabled)}
                  onChange={(e) => setSettingsForm({ ...settingsForm, withdrawalsEnabled: e.target.checked })}
                  className="rounded border-neutral-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4"
                />
                <span className="text-neutral-300 font-bold text-emerald-400">Enable real/test diamond cash withdrawals</span>
              </label>
            </div>

            {/* User Transfer Toggle */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-neutral-200">User → User Transfer</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  settingsForm.userTransferEnabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                }`}>
                  {settingsForm.userTransferEnabled ? 'ENABLED' : 'DISABLED'}
                </span>
              </div>
              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={Boolean(settingsForm.userTransferEnabled)}
                  onChange={(e) => setSettingsForm({ ...settingsForm, userTransferEnabled: e.target.checked })}
                  className="rounded border-neutral-700 text-amber-500 focus:ring-amber-500 w-4 h-4"
                />
                <span className="text-neutral-300">Allow users to send coins to other users</span>
              </label>
            </div>

            {/* Virtual Exchange Toggle */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-neutral-200">Virtual Diamond Exchange</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  settingsForm.virtualExchangeEnabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                }`}>
                  {settingsForm.virtualExchangeEnabled ? 'ENABLED' : 'DISABLED'}
                </span>
              </div>
              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={Boolean(settingsForm.virtualExchangeEnabled)}
                  onChange={(e) => setSettingsForm({ ...settingsForm, virtualExchangeEnabled: e.target.checked })}
                  className="rounded border-neutral-700 text-rose-500 focus:ring-rose-500 w-4 h-4"
                />
                <span className="text-neutral-300">Allow users to exchange TEST COINS for Diamonds</span>
              </label>
            </div>

            {/* Coin to Diamond Exchange Rate */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1.5">
              <label className="font-bold text-neutral-200 block">Coin → Diamond Rate (1.0 = 1:1)</label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                max="10"
                value={settingsForm.coinToDiamondRate ?? 1.0}
                onChange={(e) => setSettingsForm({ ...settingsForm, coinToDiamondRate: Number(e.target.value) })}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white font-mono font-bold"
              />
              <span className="text-[10px] text-neutral-500">100 Coins = {Math.round(100 * (settingsForm.coinToDiamondRate ?? 1.0))} Diamonds</span>
            </div>

            {/* Minimum Transfer Amount */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1.5">
              <label className="font-bold text-neutral-200 block">Minimum Transfer Amount (Coins)</label>
              <input
                type="number"
                step="10"
                min="1"
                value={settingsForm.minTransferAmount ?? 100}
                onChange={(e) => setSettingsForm({ ...settingsForm, minTransferAmount: Number(e.target.value) })}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white font-mono font-bold"
              />
              <span className="text-[10px] text-neutral-500">Default: 100 TEST COINS</span>
            </div>

            {/* Maximum Transfer Amount */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1.5">
              <label className="font-bold text-neutral-200 block">Maximum Transfer Limit (Coins)</label>
              <input
                type="number"
                step="10000"
                min="100"
                value={settingsForm.maxTransferAmount ?? 10000000}
                onChange={(e) => setSettingsForm({ ...settingsForm, maxTransferAmount: Number(e.target.value) })}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white font-mono font-bold"
              />
              <span className="text-[10px] text-neutral-500">Default: 10,000,000 TEST COINS</span>
            </div>

            {/* Save Button */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center">
              <button
                type="submit"
                disabled={isSavingSettings}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-neutral-950 font-black text-xs shadow-lg shadow-amber-950/40 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{isSavingSettings ? 'Saving Settings...' : 'Save Wallet Rules'}</span>
              </button>
            </div>

          </div>
        </form>
      </div>

      {/* SECTION 2: LIVE USER WALLET DIRECTORY & TRANSFER SIMULATOR */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* User Directory */}
        <div className="lg:col-span-2 p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 space-y-3">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Platform Users & Test Balances
              </h3>
            </div>
            <span className="text-[10px] font-mono text-neutral-400">{platformUsers.length} Active Accounts</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-300">
              <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-950 border-b border-neutral-800">
                <tr>
                  <th className="py-2.5 px-3">User</th>
                  <th className="py-2.5 px-3">User ID</th>
                  <th className="py-2.5 px-3">TEST COINS 🪙</th>
                  <th className="py-2.5 px-3">Virtual Diamonds 💎</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60 font-mono">
                {platformUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-neutral-800/40">
                    <td className="py-2.5 px-3 font-sans font-bold text-white flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center text-[10px] text-amber-300">
                        {u.name.charAt(0)}
                      </div>
                      <span>{u.name}</span>
                    </td>
                    <td className="py-2.5 px-3 text-neutral-400">{u.id}</td>
                    <td className="py-2.5 px-3 font-bold text-amber-400">
                      {(u.coinBalance ?? 0).toLocaleString()} 🪙
                    </td>
                    <td className="py-2.5 px-3 font-bold text-rose-400">
                      {(u.diamondBalance ?? 0).toLocaleString()} 💎
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {u.status || 'Active'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Transfer Simulator */}
        <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 space-y-3">
          <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
            <Send className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Transfer Simulator
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-neutral-400 block mb-1 font-semibold">Sender User</label>
              <select
                value={simSenderId ?? ''}
                onChange={(e) => setSimSenderId(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white font-mono"
              >
                {platformUsers.map(u => (
                  <option key={u.id} value={u.id}>{u.name} ({u.id}) — {(u.coinBalance ?? 0).toLocaleString()} 🪙</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-neutral-400 block mb-1 font-semibold">Recipient User</label>
              <select
                value={simReceiverId ?? ''}
                onChange={(e) => setSimReceiverId(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white font-mono"
              >
                {platformUsers.map(u => (
                  <option key={u.id} value={u.id}>{u.name} ({u.id}) — {(u.coinBalance ?? 0).toLocaleString()} 🪙</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-neutral-400 block mb-1 font-semibold">Amount (TEST COINS)</label>
              <input
                type="number"
                value={simAmount ?? ''}
                onChange={(e) => setSimAmount(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-amber-400 font-mono font-bold"
              />
            </div>

            <div>
              <label className="text-neutral-400 block mb-1 font-semibold">Transfer Note</label>
              <input
                type="text"
                value={simNotes ?? ''}
                onChange={(e) => setSimNotes(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white"
              />
            </div>

            <button
              onClick={handleRunSimulatorTransfer}
              disabled={isSimulating}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-amber-950/40 cursor-pointer"
            >
              {isSimulating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              <span>Execute Simulator Transfer</span>
            </button>
          </div>
        </div>

      </div>

      {/* SECTION 3: OWNER ⇄ COIN SELLER ALLOCATION */}
      <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Owner ⇄ Authorized Coin Seller Test Distributions
            </h3>
          </div>
          <span className="text-xs text-neutral-400 font-mono">
            {activeSellers.length} Authorized Sellers
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label className="text-[11px] font-bold text-neutral-400 mb-1 block">Select Coin Seller</label>
            <select
              value={selectedSellerId ?? ''}
              onChange={(e) => setSelectedSellerId(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
            >
              {coinSellers.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.id}) — {(s?.testCoinBalance ?? 0).toLocaleString()} coins [{s.status}]
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-neutral-400 mb-1 block">Amount (TEST COINS)</label>
            <input
              type="number"
              value={transferAmount ?? ''}
              onChange={(e) => setTransferAmount(e.target.value)}
              min="1000"
              step="100000"
              placeholder="e.g. 5000000"
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-amber-400 font-bold focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-neutral-400 mb-1 block">Notes / Reason</label>
            <input
              type="text"
              value={transferNotes ?? ''}
              onChange={(e) => setTransferNotes(e.target.value)}
              placeholder="e.g. Weekly QA test liquidity"
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-end gap-2">
            <button
              onClick={handleExecuteTransfer}
              disabled={isProcessing}
              className="flex-1 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs py-2 rounded-xl transition-all shadow-md shadow-amber-500/20 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Give Coins</span>
            </button>
            <button
              onClick={handleExecuteReclaim}
              disabled={isProcessing}
              className="px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold transition-all disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer"
              title="Take back test coins to Owner Treasury"
            >
              <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
              <span>Reclaim</span>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 4: TRANSACTION HISTORY & AUDIT LEDGER */}
      <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Owner ⇄ Coin Seller Transfer History
            </h3>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search TX ID, seller, notes..."
              value={searchTx ?? ''}
              onChange={(e) => setSearchTx(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto rounded-xl border border-neutral-800">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-neutral-950 text-neutral-400 font-bold uppercase tracking-wider border-b border-neutral-800">
              <tr>
                <th className="py-3 px-4">Tx ID</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Seller</th>
                <th className="py-3 px-4">Amount</th>
                <th className="py-3 px-4">Owner Balance</th>
                <th className="py-3 px-4">Seller Balance</th>
                <th className="py-3 px-4">Time</th>
                <th className="py-3 px-4">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-mono">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-neutral-500">
                    No transactions found matching query.
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-neutral-800/40 transition-colors">
                    <td className="py-3 px-4 font-bold text-amber-400">{tx.id}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        tx.type === 'OWNER_TO_SELLER'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      }`}>
                        {tx.type === 'OWNER_TO_SELLER' ? 'DISTRIBUTION' : 'RECLAIM'}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-sans font-medium text-white">{tx.sellerName}</td>
                    <td className="py-3 px-4 font-bold text-amber-400">
                      {tx.type === 'OWNER_TO_SELLER' ? '+' : '-'}{(tx.amount ?? 0).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-neutral-400">
                      {(tx?.newOwnerBalance ?? 0).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-neutral-300">
                      {(tx?.newSellerBalance ?? 0).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-neutral-500 font-sans text-[11px]">{tx.timestamp}</td>
                    <td className="py-3 px-4 text-neutral-400 font-sans text-[11px] truncate max-w-xs">{tx.notes || '—'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
