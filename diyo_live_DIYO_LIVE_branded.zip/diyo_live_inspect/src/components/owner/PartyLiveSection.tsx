import React, { useState } from 'react';
import {
  Crown,
  Users,
  Mic,
  MicOff,
  Video,
  VideoOff,
  ShieldAlert,
  Play,
  RotateCcw,
  Sparkles,
  Lock,
  Unlock,
  Eye,
  Radio
} from 'lucide-react';
import { PartyLiveRoomSession, PartySeat } from '../../types/ownerTypes';

interface PartyLiveSectionProps {
  partyRoom: PartyLiveRoomSession;
  onOpenPartyLiveModal?: () => void;
}

export const PartyLiveSection: React.FC<PartyLiveSectionProps> = ({
  partyRoom,
  onOpenPartyLiveModal
}) => {
  const [roomState, setRoomState] = useState<PartyLiveRoomSession>(partyRoom);

  const occupiedSeatsCount = roomState.seats.filter(s => Boolean(s.userId)).length;
  const crownSeat = roomState.seats.find(s => s.hasSirCrown);

  const handleToggleSeatMute = (seatNum: number) => {
    setRoomState(prev => {
      const newSeats = [...prev.seats];
      const s = newSeats[seatNum - 1];
      if (s) {
        s.isMuted = !s.isMuted;
        s.isMicOn = !s.isMuted;
      }
      return { ...prev, seats: newSeats };
    });
  };

  const handleKickSeat = (seatNum: number) => {
    setRoomState(prev => {
      const newSeats = [...prev.seats];
      newSeats[seatNum - 1] = {
        seatNumber: seatNum,
        isOwner: false,
        hasSirCrown: false,
        isMuted: false,
        isCameraOn: false,
        isMicOn: false,
        isLocked: false
      };
      return { ...prev, seats: newSeats };
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black text-white uppercase tracking-wider">
              Party Live (20 Seats) Control & Moderation
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-black uppercase tracking-wider border border-purple-500/30">
              👑 SIR CROWN AUTHORITATIVE
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Monitor and govern 20-seat interactive audio/video party rooms, supervise Sir Crown allocation, and moderate seats.
          </p>
        </div>

        {onOpenPartyLiveModal && (
          <button
            onClick={onOpenPartyLiveModal}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs shadow-lg shadow-purple-600/20 flex items-center gap-2 active:scale-95 transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Launch Live Party Studio</span>
          </button>
        )}
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800">
          <div className="text-xs text-neutral-400 font-bold mb-1">Total Room Seats</div>
          <div className="text-3xl font-black text-white">20 SEATS</div>
          <div className="text-[11px] text-emerald-400 font-medium mt-1">
            {occupiedSeatsCount} Occupied / {20 - occupiedSeatsCount} Available
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800">
          <div className="text-xs text-neutral-400 font-bold mb-1">👑 Sir Crown Holder</div>
          <div className="text-xl font-black text-amber-400 truncate">
            {roomState.crownHolderName}
          </div>
          <div className="text-[11px] text-neutral-400 font-mono mt-1">
            Seat #1 (Room Owner Exclusive)
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800">
          <div className="text-xs text-neutral-400 font-bold mb-1">Active Spectators</div>
          <div className="text-3xl font-black text-purple-400">
            {((roomState?.viewerCount) ?? 0).toLocaleString()}
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            Room ID: {roomState.id}
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800">
          <div className="text-xs text-neutral-400 font-bold mb-1">Total Gifts Exchanged</div>
          <div className="text-3xl font-black text-amber-400 font-mono">
            {((roomState?.totalGiftsReceivedCoins) ?? 0).toLocaleString()}
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            Virtual Test Coins Sent
          </div>
        </div>
      </div>

      {/* 20-Seat Moderation Matrix */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Radio className="w-4 h-4 text-purple-400" />
            <span>20-Seat Stage Moderation Matrix</span>
          </h3>
          <span className="text-xs text-neutral-400">Owner Superuser Moderation Enabled</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
          {(roomState?.seats || []).map((seat) => {
            const isOccupied = Boolean(seat.userId);
            return (
              <div
                key={seat.seatNumber}
                className={`p-3 rounded-xl border flex flex-col justify-between space-y-2 ${
                  seat.hasSirCrown
                    ? 'bg-amber-950/40 border-amber-500 shadow-md ring-1 ring-amber-400/40'
                    : isOccupied
                    ? 'bg-neutral-950 border-neutral-800'
                    : 'bg-neutral-950/40 border-neutral-800/60 border-dashed'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-neutral-400">
                    Seat #{seat.seatNumber}
                  </span>
                  {seat.hasSirCrown && (
                    <span className="flex items-center gap-1 text-[9px] font-black bg-amber-500 text-neutral-950 px-1.5 py-0.2 rounded-full">
                      <Crown className="w-2.5 h-2.5 fill-current" />
                      <span>SIR CROWN</span>
                    </span>
                  )}
                </div>

                {isOccupied ? (
                  <div className="flex items-center gap-2">
                    <img src={seat.avatar} alt={seat.userName} className="w-8 h-8 rounded-full object-cover" />
                    <div className="truncate">
                      <div className="font-bold text-white text-xs truncate">{seat.userName}</div>
                      <div className="text-[10px] text-neutral-400 font-mono">{seat.userId}</div>
                    </div>
                  </div>
                ) : (
                  <div className="py-2 text-center text-xs text-neutral-600 font-medium">
                    Empty Seat
                  </div>
                )}

                {isOccupied && (
                  <div className="flex items-center justify-between pt-2 border-t border-neutral-800/80">
                    <button
                      onClick={() => handleToggleSeatMute(seat.seatNumber)}
                      className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                        seat.isMuted
                          ? 'bg-rose-500/20 text-rose-300'
                          : 'bg-neutral-800 text-neutral-300 hover:text-white'
                      }`}
                      title={seat.isMuted ? 'Unmute' : 'Mute'}
                    >
                      {seat.isMuted ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
                    </button>

                    {!seat.hasSirCrown && (
                      <button
                        onClick={() => handleKickSeat(seat.seatNumber)}
                        className="px-2 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-[10px] font-bold transition-all"
                      >
                        Kick
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
