import React, { useState } from 'react';
import { Flame, Swords, Clock, Trophy, Users, Play, StopCircle, RefreshCw } from 'lucide-react';
import { PkBattleItem } from '../../types/ownerTypes';

interface PkBattlesSectionProps {
  pkBattles: PkBattleItem[];
}

export const PkBattlesSection: React.FC<PkBattlesSectionProps> = ({ pkBattles = [] }) => {
  const [battles, setBattles] = useState<PkBattleItem[]>(pkBattles || []);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-white uppercase tracking-wider flex items-center gap-2">
            <Swords className="w-5 h-5 text-rose-400" />
            <span>PK Battles Supervision & Live Match Control</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Monitor real-time host vs host PK battles, gift score counters, timers, and reward calculations.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {(battles || []).map(pk => (
          <div key={pk.id} className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between">
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider ${
                pk.status === 'Live' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse' : 'bg-neutral-800 text-neutral-400'
              }`}>
                {pk.status === 'Live' ? '🔴 LIVE MATCH' : '🏁 MATCH ENDED'}
              </span>
              <span className="text-xs font-mono text-neutral-400 font-bold">
                {pk.remainingSeconds > 0 ? `⏳ ${pk.remainingSeconds}s remaining` : 'Finished'}
              </span>
            </div>

            {/* Versus Stage */}
            <div className="grid grid-cols-3 items-center gap-3 py-2">
              <div className="flex flex-col items-center text-center">
                <img src={pk.host1Avatar} alt={pk.host1Name} className="w-14 h-14 rounded-full object-cover ring-2 ring-rose-500" />
                <div className="font-bold text-white text-xs mt-1.5">{pk.host1Name}</div>
                <div className="text-sm font-black text-rose-400 font-mono mt-0.5">{((pk?.host1Score) ?? 0).toLocaleString()} pts</div>
              </div>

              <div className="flex flex-col items-center justify-center">
                <div className="w-9 h-9 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 font-black text-xs">
                  VS
                </div>
                <div className="text-[10px] text-neutral-500 font-mono mt-1">ID: {pk.id}</div>
              </div>

              <div className="flex flex-col items-center text-center">
                <img src={pk.host2Avatar} alt={pk.host2Name} className="w-14 h-14 rounded-full object-cover ring-2 ring-blue-500" />
                <div className="font-bold text-white text-xs mt-1.5">{pk.host2Name}</div>
                <div className="text-sm font-black text-blue-400 font-mono mt-0.5">{((pk?.host2Score) ?? 0).toLocaleString()} pts</div>
              </div>
            </div>

            {/* Score Bar */}
            <div className="w-full bg-neutral-950 h-3 rounded-full overflow-hidden flex border border-neutral-800">
              <div
                className="bg-gradient-to-r from-rose-600 to-pink-500 h-full transition-all"
                style={{ width: `${(pk.host1Score / (pk.host1Score + pk.host2Score || 1)) * 100}%` }}
              />
              <div
                className="bg-gradient-to-r from-cyan-500 to-blue-600 h-full transition-all"
                style={{ width: `${(pk.host2Score / (pk.host1Score + pk.host2Score || 1)) * 100}%` }}
              />
            </div>

            <div className="flex justify-between items-center text-[11px] text-neutral-400 pt-2 border-t border-neutral-800">
              <span>MVP Gifter: <b className="text-amber-400">{pk.mvpGifterName || 'None'}</b></span>
              <span>Started {pk.startedAt}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
