import React, { useState, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  CheckCircle, 
  ToggleLeft, 
  ToggleRight, 
  ShieldCheck, 
  History, 
  Save, 
  RefreshCw,
  Users,
  Coins
} from 'lucide-react';
import { RedPacketSettings, RedPacketItem } from '../../types/ownerTypes';
import { DEFAULT_RED_PACKET_SETTINGS, INITIAL_RED_PACKETS } from '../../data/platformFeaturesData';

interface RedPacketOwnerSectionProps {
  initialConfig?: RedPacketSettings;
  onSaveConfig?: (config: RedPacketSettings) => void;
}

export const RedPacketOwnerSection: React.FC<RedPacketOwnerSectionProps> = ({
  initialConfig = DEFAULT_RED_PACKET_SETTINGS,
  onSaveConfig
}) => {
  const [config, setConfig] = useState<RedPacketSettings>(initialConfig);
  const [packets, setPackets] = useState<RedPacketItem[]>(INITIAL_RED_PACKETS);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  useEffect(() => {
    fetch('/api/red-packet/settings')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.settings) {
          setConfig(data.settings);
        }
      })
      .catch(() => {});
  }, []);

  const handleToggleMaster = () => {
    setConfig(prev => ({ ...prev, enabled: !prev.enabled }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      const res = await fetch('/api/red-packet/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      const data = await res.json();
      if (data.success) {
        setSaveSuccess(true);
        if (onSaveConfig) onSaveConfig(config);
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      setSaveSuccess(true);
      if (onSaveConfig) onSaveConfig(config);
      setTimeout(() => setSaveSuccess(false), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-rose-600/20 text-rose-300 border border-rose-600/40">
              🧧
            </div>
            <h2 className="text-lg font-bold text-white font-['Outfit']">Virtual Red Packet Configuration</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
              TEST COINS ONLY
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Configure live broadcast Red Packet limits, max receivers, expiration duration, and monitor room distributions.
          </p>
        </div>

        <button
          id="save-red-packet-owner-config-btn"
          disabled={isSaving}
          onClick={handleSave}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-500 hover:from-rose-500 hover:to-red-400 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-rose-600/20 transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          {isSaving ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Save className="w-4 h-4" />
          )}
          <span>Save Configuration</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/60 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-scale-up">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>Red Packet configuration successfully updated!</span>
        </div>
      )}

      {/* Global Notice */}
      <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-center justify-between text-xs text-rose-300">
        <span className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-rose-400" />
          Strict Test Mode: All Red Packet distributions use virtual TEST COINS only. No real money value.
        </span>
        <span className="font-mono text-neutral-400 text-[11px]">ROOM_DISTRIBUTOR</span>
      </div>

      {/* Master Toggle & Limits */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Master Switch */}
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">Master Switch</span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
              config.enabled ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-red-950 text-red-300 border border-red-800'
            }`}>
              {config.enabled ? 'ENABLED' : 'DISABLED'}
            </span>
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Enable Red Packets</h4>
            <p className="text-xs text-neutral-400 mt-0.5">Toggle availability in all live and party rooms</p>
          </div>
          <button
            id="toggle-master-red-packet-btn"
            onClick={handleToggleMaster}
            className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              config.enabled
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                : 'bg-neutral-800 text-neutral-400 border border-neutral-700 hover:bg-neutral-700'
            }`}
          >
            {config.enabled ? <ToggleRight className="w-5 h-5 text-emerald-400" /> : <ToggleLeft className="w-5 h-5 text-neutral-500" />}
            <span>{config.enabled ? 'Active' : 'Disabled'}</span>
          </button>
        </div>

        {/* Min Amount */}
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">Min Amount</span>
          <div>
            <label className="text-xs text-neutral-400">Minimum Pool (TEST COINS)</label>
            <input
              type="number"
              value={config.minAmountCoins}
              onChange={(e) => setConfig({ ...config, minAmountCoins: Math.max(1000, Number(e.target.value)) })}
              className="mt-1.5 w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:border-rose-500 focus:outline-none"
            />
          </div>
          <p className="text-[11px] text-neutral-500">Minimum coins a sender can distribute.</p>
        </div>

        {/* Max Amount */}
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">Max Amount</span>
          <div>
            <label className="text-xs text-neutral-400">Maximum Pool (TEST COINS)</label>
            <input
              type="number"
              value={config.maxAmountCoins}
              onChange={(e) => setConfig({ ...config, maxAmountCoins: Math.max(10000, Number(e.target.value)) })}
              className="mt-1.5 w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:border-rose-500 focus:outline-none"
            />
          </div>
          <p className="text-[11px] text-neutral-500">Maximum cap per single Red Packet.</p>
        </div>

        {/* Max Receivers */}
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">Max Receivers</span>
          <div>
            <label className="text-xs text-neutral-400">Max Claimers per Packet</label>
            <input
              type="number"
              value={config.maxPackets}
              onChange={(e) => setConfig({ ...config, maxPackets: Math.max(1, Number(e.target.value)) })}
              className="mt-1.5 w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:border-rose-500 focus:outline-none"
            />
          </div>
          <p className="text-[11px] text-neutral-500">Up to 20 concurrent recipients.</p>
        </div>
      </div>

      {/* Active Packets & Claim Logs */}
      <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-rose-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Live Room Red Packet Records
            </h3>
          </div>
          <span className="text-[11px] text-neutral-400">Active & Settled Packets</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-neutral-800 text-[10px] text-neutral-400 uppercase tracking-wider">
                <th className="pb-2 font-medium">Packet ID</th>
                <th className="pb-2 font-medium">Sender</th>
                <th className="pb-2 font-medium">Total Pool</th>
                <th className="pb-2 font-medium text-center">Claimed / Total</th>
                <th className="pb-2 font-medium">Message</th>
                <th className="pb-2 font-medium text-center">Status</th>
                <th className="pb-2 font-medium text-right">Expires</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {packets.map((pkt) => (
                <tr key={pkt.id} className="hover:bg-neutral-800/40">
                  <td className="py-2.5 font-mono text-[11px] text-rose-300">{pkt.id}</td>
                  <td className="py-2.5 font-semibold text-white">{pkt.senderName}</td>
                  <td className="py-2.5 font-mono font-bold text-rose-400">{((pkt?.totalCoins) ?? 0).toLocaleString()} TC</td>
                  <td className="py-2.5 text-center font-mono">
                    {pkt.claims.length} / {pkt.totalPackets}
                  </td>
                  <td className="py-2.5 text-neutral-300 italic max-w-xs truncate">{pkt.message}</td>
                  <td className="py-2.5 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      pkt.status === 'COMPLETED'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-rose-950 text-rose-300 border border-rose-800'
                    }`}>
                      {pkt.status}
                    </span>
                  </td>
                  <td className="py-2.5 text-right text-neutral-400 text-[11px]">{pkt.expiresAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
