import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Search, 
  CheckCircle2, 
  XCircle, 
  ShieldAlert, 
  UserX, 
  Tv, 
  Clock,
  Eye,
  Check,
  X,
  FileText,
  MessageSquare
} from 'lucide-react';
import { ModerationReport } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface ReportsSectionProps {
  reports: ModerationReport[];
  onResolveReport: (id: string, action: string) => void;
  onDismissReport: (id: string) => void;
  onUpdateReportStatus?: (id: string, newStatus: string, internalNote: string) => void;
}

export const ReportsSection: React.FC<ReportsSectionProps> = ({
  reports,
  onResolveReport,
  onDismissReport,
  onUpdateReportStatus
}) => {
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [search, setSearch] = useState('');
  const [activeReportForDetail, setActiveReportForDetail] = useState<ModerationReport | null>(null);
  const [noteInput, setNoteInput] = useState('');
  const [selectedStatusUpdate, setSelectedStatusUpdate] = useState<string>('Investigating');

  const filtered = reports.filter((r) => {
    const matchesStatus = statusFilter === 'ALL' || r.status === statusFilter;
    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (r.targetName || '').toLowerCase().includes(q) ||
      (r.reporterName || '').toLowerCase().includes(q) ||
      (r.reason || '').toLowerCase().includes(q) ||
      (r.id || '').toLowerCase().includes(q);

    return matchesStatus && matchesSearch;
  });

  const handleSaveInvestigation = (reportId: string) => {
    if (onUpdateReportStatus) {
      onUpdateReportStatus(reportId, selectedStatusUpdate, noteInput);
    }
    playSoundFX('superchat');
    setActiveReportForDetail(null);
    setNoteInput('');
  };

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Complaint & Moderation Investigation Hub</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/30">
              Official Power
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Track investigations, add internal notes, update status, and take action on incoming complaints in real-time.
          </p>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search reports by target, reporter, reason..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          {['ALL', 'Pending', 'Investigating', 'Resolved', 'Dismissed'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-xl font-bold transition-all ${
                statusFilter === st
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Table of Reports */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-3.5">Report ID & Target</th>
                <th className="p-3.5">Reported By</th>
                <th className="p-3.5">Reason & Description</th>
                <th className="p-3.5">Status & Notes</th>
                <th className="p-3.5 text-right">Official Action & Investigation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filtered.map((rpt) => (
                <tr key={rpt.id} className="hover:bg-neutral-850/50 transition-colors">
                  
                  {/* Target */}
                  <td className="p-3.5">
                    <div>
                      <span className="font-bold text-white block">{rpt.targetName || 'Unknown Target'}</span>
                      <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
                        <span className="font-mono text-rose-400 font-bold">{rpt.id}</span>
                        <span>•</span>
                        <span className="capitalize">{(rpt.targetType || 'User').toLowerCase()}</span>
                      </div>
                    </div>
                  </td>

                  {/* Reporter */}
                  <td className="p-3.5">
                    <span className="text-neutral-200 font-medium block">{rpt.reporterName || 'Anonymous'}</span>
                    <span className="text-[10px] text-neutral-500 font-mono">{rpt.reporterId}</span>
                  </td>

                  {/* Reason */}
                  <td className="p-3.5">
                    <div className="space-y-0.5 max-w-sm">
                      <span className="font-bold text-amber-300 block">{rpt.reason}</span>
                      <p className="text-[11px] text-neutral-400 line-clamp-2">{rpt.description}</p>
                    </div>
                  </td>

                  {/* Status */}
                  <td className="p-3.5">
                    <div className="space-y-1">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        rpt.status === 'Resolved' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                        rpt.status === 'Pending' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                        rpt.status === 'Investigating' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                        'bg-neutral-800 text-neutral-400 border-neutral-700'
                      }`}>
                        {rpt.status}
                      </span>
                      {rpt.internalNote && (
                        <div className="text-[10px] text-indigo-300 bg-indigo-950/40 px-2 py-1 rounded border border-indigo-900/50 flex items-center gap-1">
                          <FileText className="w-3 h-3 shrink-0" />
                          <span className="truncate max-w-[180px]">Note: {rpt.internalNote}</span>
                        </div>
                      )}
                      <span className="block text-[10px] text-neutral-500 font-mono">{rpt.timestamp}</span>
                    </div>
                  </td>

                  {/* Actions & Investigation Trigger */}
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => {
                          setActiveReportForDetail(rpt);
                          setSelectedStatusUpdate(rpt.status);
                          setNoteInput(rpt.internalNote || '');
                          playSoundFX('click');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] transition-all flex items-center gap-1"
                      >
                        <MessageSquare className="w-3 h-3" />
                        Investigate / Update
                      </button>
                      <button
                        onClick={() => {
                          onResolveReport(rpt.id, 'Resolved & Closed');
                          playSoundFX('notification');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-all"
                      >
                        Resolve
                      </button>
                      <button
                        onClick={() => {
                          onDismissReport(rpt.id);
                          playSoundFX('click');
                        }}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
                        title="Dismiss Report"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Investigation Modal / Drawer */}
      {activeReportForDetail && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 w-full max-w-lg rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div>
                <h3 className="text-sm font-bold text-white">Complaint Investigation Panel</h3>
                <p className="text-xs text-neutral-400 font-mono">Report #{activeReportForDetail.id}</p>
              </div>
              <button
                onClick={() => setActiveReportForDetail(null)}
                className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Target Name:</span>
                  <span className="text-white font-bold">{activeReportForDetail.targetName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Reported By:</span>
                  <span className="text-neutral-200">{activeReportForDetail.reporterName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Reason:</span>
                  <span className="text-amber-400 font-bold">{activeReportForDetail.reason}</span>
                </div>
                <div>
                  <span className="text-neutral-400 block mb-1">Description:</span>
                  <p className="text-neutral-300 bg-neutral-900 p-2 rounded-lg">{activeReportForDetail.description}</p>
                </div>
              </div>

              {/* Status Update Dropdown */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300 block uppercase tracking-wider">
                  Status Update Dropdown
                </label>
                <select
                  value={selectedStatusUpdate}
                  onChange={(e) => setSelectedStatusUpdate(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-indigo-500"
                >
                  <option value="Pending">Pending Review</option>
                  <option value="Investigating">Investigating (Official Assigned)</option>
                  <option value="Resolved">Resolved & Action Taken</option>
                  <option value="Dismissed">Dismissed (False Report)</option>
                </select>
              </div>

              {/* Internal Note Field */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300 block uppercase tracking-wider">
                  Internal Note (Official Audit Trail)
                </label>
                <textarea
                  rows={3}
                  placeholder="Enter notes regarding evidence, chat logs, user warnings, or investigation steps..."
                  value={noteInput}
                  onChange={(e) => setNoteInput(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-white text-xs placeholder-neutral-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* History trail if any */}
              {activeReportForDetail.history && activeReportForDetail.history.length > 0 && (
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-neutral-400 block">Investigation History Log:</span>
                  <div className="space-y-1 max-h-24 overflow-y-auto">
                    {activeReportForDetail.history.map((h, i) => (
                      <div key={i} className="text-[10px] bg-neutral-950 p-2 rounded border border-neutral-800 flex justify-between text-neutral-300">
                        <span>{h.action}: {h.note}</span>
                        <span className="text-neutral-500 font-mono">{h.timestamp}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
              <button
                onClick={() => setActiveReportForDetail(null)}
                className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSaveInvestigation(activeReportForDetail.id)}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-950"
              >
                Save Investigation & Status
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

