import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Check, 
  ShieldCheck, 
  Shield, 
  UserCheck, 
  Building2, 
  Tv, 
  Gift, 
  Bell,
  DollarSign
} from 'lucide-react';
import { UserRole } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface RoleActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  actionType: 'CREATE_SUPER_ADMIN' | 'CREATE_ADMIN' | 'CREATE_MANAGER' | 'CREATE_AGENCY' | 'CREATE_HOST' | 'CREATE_GIFT' | 'SEND_NOTIFICATION' | 'ADJUST_COINS';
  onSuccess: (formData: any) => void;
  agencies?: any[];
  managers?: any[];
}

export const RoleActionModal: React.FC<RoleActionModalProps> = ({
  isOpen,
  onClose,
  actionType,
  onSuccess,
  agencies = [],
  managers = []
}) => {
  const [formData, setFormData] = useState<any>({
    name: '',
    username: '',
    email: '',
    phone: '',
    contact: '',
    assignedArea: 'Global Operations',
    assignedPermissions: ['LIVE_ROOM_MOD', 'REPORT_REVIEW'],
    agencyId: agencies[0]?.id || '',
    managerId: managers[0]?.id || '',
    streamCategory: 'music',
    commissionRate: 15,
    coinPrice: 500,
    diamondValue: 350,
    isLucky: false,
    luckyMultiplierMax: 100,
    animationType: 'pop',
    title: '',
    message: '',
    targetAudience: 'All',
    amountCoins: 10000,
    targetUserId: 'USR-8001'
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSuccess(formData);
    playSoundFX('notification');
    onClose();
  };

  const getTitle = () => {
    switch (actionType) {
      case 'CREATE_SUPER_ADMIN': return 'Create Super Admin Account';
      case 'CREATE_ADMIN': return 'Create System Admin Account';
      case 'CREATE_MANAGER': return 'Create Talent Manager Account';
      case 'CREATE_AGENCY': return 'Register Partner Agency Guild';
      case 'CREATE_HOST': return 'Onboard Stream Host';
      case 'CREATE_GIFT': return 'Create Virtual Gift / Lucky Gift';
      case 'SEND_NOTIFICATION': return 'Broadcast Push Notification';
      case 'ADJUST_COINS': return 'Manual Treasury Coin Adjustment';
      default: return 'Action';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-950 border border-neutral-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in zoom-in-95 max-h-[90vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-md">
              <Plus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-['Outfit']">{getTitle()}</h3>
              <p className="text-[11px] text-neutral-400">DIYO LIVE Owner Panel Governance Action</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-3.5 flex-1 min-h-0 overflow-y-auto pr-1 text-xs">
          
          {(actionType === 'CREATE_SUPER_ADMIN' || actionType === 'CREATE_ADMIN' || actionType === 'CREATE_MANAGER' || actionType === 'CREATE_AGENCY' || actionType === 'CREATE_HOST') && (
            <>
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Full Legal / Display Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Vikramaditya Rao"
                  value={formData.name ?? ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Username (Handle)</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. vikram_sec"
                  value={formData.username ?? ''}
                  onChange={(e) => setFormData({ ...formData, username: (e.target.value || '').toLowerCase().replace(/\s+/g, '_') })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="official@srlive.io"
                    value={formData.email ?? ''}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Phone Contact</label>
                  <input
                    type="text"
                    placeholder="+91 98765 43210"
                    value={formData.phone || formData.contact || ''}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value, contact: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </>
          )}

          {actionType === 'CREATE_SUPER_ADMIN' && (
            <div>
              <label className="block font-semibold text-neutral-300 mb-1">Assigned Operational Area</label>
              <input
                type="text"
                value={formData.assignedArea ?? ''}
                onChange={(e) => setFormData({ ...formData, assignedArea: e.target.value })}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          )}

          {actionType === 'CREATE_AGENCY' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Commission Split (%)</label>
                <input
                  type="number"
                  min="5"
                  max="40"
                  value={formData.commissionRate ?? 15}
                  onChange={(e) => setFormData({ ...formData, commissionRate: Number(e.target.value) })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Assigned Manager</label>
                <select
                  value={formData.managerId ?? ''}
                  onChange={(e) => setFormData({ ...formData, managerId: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                >
                  {managers.map((m) => (
                    <option key={m.id} value={m.id}>{m.name} ({m.id})</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {actionType === 'CREATE_HOST' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Stream Category</label>
                <select
                  value={formData.streamCategory ?? 'music'}
                  onChange={(e) => setFormData({ ...formData, streamCategory: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 capitalize"
                >
                  {['music', 'gaming', 'sports', 'news', 'tech', 'radio'].map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Assigned Agency</label>
                <select
                  value={formData.agencyId ?? ''}
                  onChange={(e) => setFormData({ ...formData, agencyId: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="">Independent (No Agency)</option>
                  {agencies.map((a) => (
                    <option key={a.id} value={a.id}>{a.name}</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {actionType === 'CREATE_GIFT' && (
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Gift Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Imperial Pegasus 4K"
                  value={formData.name ?? ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Coin Price</label>
                  <input
                    type="number"
                    value={formData.coinPrice ?? 500}
                    onChange={(e) => setFormData({ ...formData, coinPrice: Number(e.target.value) })}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Diamond Value</label>
                  <input
                    type="number"
                    value={formData.diamondValue ?? 350}
                    onChange={(e) => setFormData({ ...formData, diamondValue: Number(e.target.value) })}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 bg-neutral-900 rounded-xl border border-neutral-800">
                <input
                  type="checkbox"
                  id="lucky-gift-check"
                  checked={Boolean(formData.isLucky)}
                  onChange={(e) => setFormData({ ...formData, isLucky: e.target.checked })}
                  className="rounded border-neutral-700 text-amber-500 focus:ring-0"
                />
                <label htmlFor="lucky-gift-check" className="font-semibold text-white cursor-pointer">
                  Enable Lucky Multiplier (Chance to drop up to 500x bonus)
                </label>
              </div>
            </div>
          )}

          {actionType === 'SEND_NOTIFICATION' && (
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Announcement Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Scheduled Network Maintenance"
                  value={formData.title ?? ''}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Broadcast Message Body</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Enter message details for viewers or broadcasters..."
                  value={formData.message ?? ''}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Target Role Audience</label>
                <select
                  value={formData.targetAudience ?? 'All'}
                  onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="All">All Users & Hosts (Global Broadcast)</option>
                  <option value="Hosts">Stream Hosts Only</option>
                  <option value="Agencies">Agencies Only</option>
                  <option value="VIPs">VIP 1–8 High Rollers</option>
                  <option value="Managers">Managers</option>
                </select>
              </div>
            </div>
          )}

          {actionType === 'ADJUST_COINS' && (
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Target User ID</label>
                <input
                  type="text"
                  required
                  value={formData.targetUserId ?? ''}
                  onChange={(e) => setFormData({ ...formData, targetUserId: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Adjustment Amount (Coins)</label>
                <input
                  type="number"
                  required
                  value={formData.amountCoins ?? 10000}
                  onChange={(e) => setFormData({ ...formData, amountCoins: Number(e.target.value) })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                />
                <p className="text-[10px] text-neutral-400 mt-1">Use positive numbers to credit, negative to debit.</p>
              </div>
            </div>
          )}

          {/* Submit Action */}
          <div className="pt-3 border-t border-neutral-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white text-xs font-bold shadow-lg shadow-amber-500/20 transition-all flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Confirm & Execute</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
