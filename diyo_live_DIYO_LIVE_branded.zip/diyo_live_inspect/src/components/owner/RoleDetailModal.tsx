import React, { useState } from 'react';
import { 
  X, 
  Crown, 
  ShieldCheck, 
  Shield, 
  UserCheck, 
  Building2, 
  Tv, 
  Users, 
  Sparkles, 
  Calendar, 
  Clock, 
  Gift, 
  DollarSign, 
  Activity, 
  Lock, 
  Unlock, 
  Ban, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  FileText,
  Mail,
  Phone,
  Layers,
  Edit,
  RotateCcw,
  Check,
  Award,
  Palette,
  Flame,
  Radio,
  Music,
  Smile,
  Wallet
} from 'lucide-react';
import { 
  UserRole, 
  HostAccount, 
  SuperAdminAccount, 
  AdminAccount, 
  ManagerAccount, 
  AgencyAccount, 
  UserAccount,
  HostTagType,
  HostTypeDefinition
} from '../../types/ownerTypes';
import { ROLE_LABELS, ROLE_BADGE_COLORS } from '../../utils/rbacGuard';
import { playSoundFX } from '../../utils/audioSynth';
import { MOCK_AVATAR_FRAMES, HOST_TYPE_DEFINITIONS } from '../../data/mockOwnerData';

interface RoleDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  role: UserRole;
  data: any; // HostAccount | SuperAdminAccount | AdminAccount | ManagerAccount | AgencyAccount | UserAccount
  onUpdateStatus?: (id: string, newStatus: string) => void;
  onAssignAgencyManager?: (hostId: string, agencyId: string, managerId: string) => void;
  onAssignHostType?: (hostId: string, hostTag: HostTagType) => void;
  onAssignAvatarFrame?: (hostId: string, frameId: string, frameUrl?: string) => void;
  onResetAccess?: (id: string) => void;
  allAgencies?: AgencyAccount[];
  allManagers?: ManagerAccount[];
}

export const RoleDetailModal: React.FC<RoleDetailModalProps> = ({
  isOpen,
  onClose,
  role,
  data,
  onUpdateStatus,
  onAssignAgencyManager,
  onAssignHostType,
  onAssignAvatarFrame,
  onResetAccess,
  allAgencies = [],
  allManagers = []
}) => {
  const [activeTab, setActiveTab] = useState<string>('profile');
  const [selectedAgencyId, setSelectedAgencyId] = useState<string>(data?.agencyId || '');
  const [selectedManagerId, setSelectedManagerId] = useState<string>(data?.managerId || '');
  const [selectedHostTag, setSelectedHostTag] = useState<HostTagType>(data?.hostTag || 'NORMAL');
  const [selectedFrameId, setSelectedFrameId] = useState<string>(data?.avatarFrameId || 'FRM-HT-04');
  const [isSavedAssignment, setIsSavedAssignment] = useState(false);
  const [isSavedTag, setIsSavedTag] = useState(false);

  if (!isOpen || !data) return null;

  const handleSaveAgencyAssignment = () => {
    if (onAssignAgencyManager && data.id) {
      onAssignAgencyManager(data.id, selectedAgencyId, selectedManagerId);
      setIsSavedAssignment(true);
      playSoundFX('click');
      setTimeout(() => setIsSavedAssignment(false), 2000);
    }
  };

  const handleSaveHostTagAndFrame = () => {
    if (data.id) {
      if (onAssignHostType) {
        onAssignHostType(data.id, selectedHostTag);
      }
      if (onAssignAvatarFrame) {
        const frameObj = MOCK_AVATAR_FRAMES.find(f => f.id === selectedFrameId);
        onAssignAvatarFrame(data.id, selectedFrameId, frameObj?.previewUrl);
      }
      setIsSavedTag(true);
      playSoundFX('reward');
      setTimeout(() => setIsSavedTag(false), 2000);
    }
  };

  const renderHostDetails = (host: HostAccount) => {
    const currentHostType = HOST_TYPE_DEFINITIONS.find(t => t.tag === (host.hostTag || 'NORMAL')) || HOST_TYPE_DEFINITIONS[3];
    const hostLvl = host.hostLevel || Math.min(10, 1 + Math.floor((host.xp || 0) / 15000));
    const hostXp = host.xp || 0;
    const nextLvlXp = hostLvl * 15000;
    const progressPercent = Math.min(100, Math.round((hostXp % 15000) / 150));

    return (
    <div className="space-y-4">
      {/* Sub Tabs */}
      <div className="flex items-center gap-1.5 border-b border-neutral-800 pb-2 overflow-x-auto scrollbar-none">
        {[
          { id: 'profile', label: 'Profile' },
          { id: 'host_type', label: '🏷️ Host Tag & Frame' },
          { id: 'hierarchy', label: 'Agency & Manager' },
          { id: 'wallet', label: '💰 Host Earnings Wallet' },
          { id: 'live_history', label: 'Live History' },
          { id: 'gift_history', label: 'Gift History' },
          { id: 'actions', label: 'Moderation & Status' }
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === t.id
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white bg-neutral-900'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Profile Tab */}
      {activeTab === 'profile' && (
        <div className="space-y-4 text-xs">
          {/* Host Tag & Level Banner */}
          <div className={`p-4 rounded-2xl border ${currentHostType.badgeBorder} ${currentHostType.badgeBg} flex items-center justify-between gap-4 flex-wrap`}>
            <div className="flex items-center gap-3">
              <div className="relative">
                <img 
                  src={host.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'} 
                  alt={host.name} 
                  className={`w-14 h-14 rounded-2xl object-cover border-2 ${currentHostType.frameBorderClass}`}
                />
                <span className="absolute -bottom-1 -right-1 text-base">{currentHostType.badgeIcon}</span>
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider bg-black/40 border ${currentHostType.badgeBorder} ${currentHostType.badgeText}`}>
                    {currentHostType.tagLabel}
                  </span>
                  <span className="px-2 py-0.5 bg-rose-600/30 text-rose-300 font-bold border border-rose-500/40 rounded-full text-[11px]">
                    ⭐ Level {hostLvl}
                  </span>
                </div>
                <p className="text-[11px] text-neutral-300 mt-1 font-medium">{currentHostType.description}</p>
              </div>
            </div>
            
            <div className="text-right bg-black/30 px-3.5 py-2 rounded-xl border border-white/5">
              <span className="text-[10px] text-neutral-400 block font-semibold uppercase">Broadcaster Level XP</span>
              <span className="text-amber-300 font-mono font-bold text-sm">{hostXp.toLocaleString()} / {nextLvlXp.toLocaleString()} XP</span>
              <div className="w-32 bg-neutral-800 rounded-full h-1.5 mt-1 overflow-hidden">
                <div className="bg-gradient-to-r from-amber-500 to-rose-500 h-full rounded-full" style={{ width: `${progressPercent}%` }}></div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
              <span className="text-[10px] uppercase font-bold text-neutral-400">Broadcaster Metadata</span>
              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-400">Host ID:</span>
                <span className="font-mono font-bold text-white">{host.id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-400">Username:</span>
                <span className="text-rose-400 font-semibold">@{host.username}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-400">Category:</span>
                <span className="capitalize text-white font-medium">{host.streamCategory}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-neutral-400">Verification:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  host.verificationStatus === 'Verified' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                }`}>
                  {host.verificationStatus}
                </span>
              </div>
            </div>

            <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
              <span className="text-[10px] uppercase font-bold text-neutral-400">Broadcasting Metrics</span>
              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-400">Followers:</span>
                <span className="font-bold text-white">{(host.followers ?? 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-400">Total Live Hours:</span>
                <span className="font-mono text-emerald-400 font-bold">{host.totalLiveHours ?? 0} hrs</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-400">Gifts Received:</span>
                <span className="text-amber-400 font-bold">{(host.giftsReceived ?? 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-neutral-400">Last Live:</span>
                <span className="text-neutral-300">{host.lastLive}</span>
              </div>
            </div>
          </div>

          {host.bio && (
            <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800">
              <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">Broadcaster Bio</span>
              <p className="text-neutral-200 leading-relaxed">{host.bio}</p>
            </div>
          )}
        </div>
      )}

      {/* Host Tag & Avatar Frame Assignment Tab */}
      {activeTab === 'host_type' && (
        <div className="space-y-4 text-xs">
          <div className="p-4 bg-neutral-900/80 border border-neutral-800 rounded-2xl space-y-3">
            <h4 className="font-bold text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Host Type & Tag Classification (Owner / Admin Exclusive)</span>
            </h4>
            <p className="text-neutral-400">
              Select one of the 4 verified Host Types to assign exclusive tag badges, live room frames, and entry effects.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {HOST_TYPE_DEFINITIONS.map((def) => {
                const isSelected = selectedHostTag === def.tag;
                return (
                  <div
                    key={def.id}
                    onClick={() => {
                      setSelectedHostTag(def.tag);
                      if (def.frameId) setSelectedFrameId(def.frameId);
                      playSoundFX('click');
                    }}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                      isSelected 
                        ? `${def.badgeBg} ${def.badgeBorder} ring-2 ring-rose-500` 
                        : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-base">{def.badgeIcon}</span>
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border ${def.badgeBorder} ${def.badgeText}`}>
                        {def.tagLabel}
                      </span>
                    </div>
                    <h5 className="font-bold text-white text-xs">{def.name}</h5>
                    <p className="text-[11px] text-neutral-400 mt-1 line-clamp-2">{def.description}</p>
                    <div className="mt-2 pt-2 border-t border-neutral-800/60 text-[10px] text-neutral-400 flex items-center justify-between">
                      <span>Default Frame: {def.frameName.split(' ')[0]}</span>
                      <span className="text-amber-300 font-mono font-bold">{def.commissionRateDefault}% split</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Avatar Frame Selector */}
          <div className="p-4 bg-neutral-900/80 border border-neutral-800 rounded-2xl space-y-3">
            <h4 className="font-bold text-white flex items-center gap-2">
              <Palette className="w-4 h-4 text-cyan-400" />
              <span>Select Host Avatar Frame (MOCK_AVATAR_FRAMES)</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {MOCK_AVATAR_FRAMES.map((frm) => {
                const isSelected = selectedFrameId === frm.id;
                return (
                  <div
                    key={frm.id}
                    onClick={() => {
                      setSelectedFrameId(frm.id);
                      playSoundFX('click');
                    }}
                    className={`p-2.5 rounded-2xl border text-center cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-rose-500/20 border-rose-500 ring-2 ring-rose-500/60'
                        : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div className="relative mx-auto w-12 h-12 mb-1.5">
                      <img
                        src={host.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                        alt="Avatar"
                        className="w-12 h-12 rounded-xl object-cover"
                      />
                      <div className="absolute -inset-1 border-2 border-dashed border-amber-400 rounded-2xl pointer-events-none opacity-60"></div>
                    </div>
                    <span className="text-[11px] font-bold text-white block truncate">{frm.name}</span>
                    <span className="text-[9px] text-amber-400 font-semibold">{frm.rarity}</span>
                  </div>
                );
              })}
            </div>

            <button
              onClick={handleSaveHostTagAndFrame}
              className="mt-3 px-4 py-2.5 bg-gradient-to-r from-amber-500 via-rose-600 to-pink-600 hover:opacity-90 text-white font-bold rounded-xl shadow-lg transition-all flex items-center gap-2"
            >
              {isSavedTag ? <Check className="w-4 h-4" /> : <Award className="w-4 h-4" />}
              <span>{isSavedTag ? 'Host Type & Frame Assigned!' : 'Save Host Type & Frame'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Hierarchy Tab */}
      {activeTab === 'hierarchy' && (
        <div className="space-y-4 text-xs">
          <div className="p-4 bg-neutral-900/80 border border-neutral-800 rounded-2xl space-y-3">
            <h4 className="font-bold text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-rose-400" />
              <span>Assigned Agency & Manager Governance</span>
            </h4>
            <p className="text-neutral-400">
              Owner can reassign this host to another partner agency guild or direct talent manager.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-neutral-300 font-semibold block mb-1">Assign Agency</label>
                <select
                  value={selectedAgencyId}
                  onChange={(e) => setSelectedAgencyId(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-white text-xs focus:border-rose-500 focus:outline-none"
                >
                  <option value="">-- No Agency (Independent) --</option>
                  {(allAgencies || []).map((ag) => (
                    <option key={ag.id} value={ag.id}>
                      {ag.name} ({ag.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-neutral-300 font-semibold block mb-1">Assign Talent Manager</label>
                <select
                  value={selectedManagerId}
                  onChange={(e) => setSelectedManagerId(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-white text-xs focus:border-rose-500 focus:outline-none"
                >
                  <option value="">-- No Manager --</option>
                  {(allManagers || []).map((mgr) => (
                    <option key={mgr.id} value={mgr.id}>
                      {mgr.name} ({mgr.id})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button
              onClick={handleSaveAgencyAssignment}
              className="mt-2 px-4 py-2 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5"
            >
              {isSavedAssignment ? <Check className="w-3.5 h-3.5" /> : <Layers className="w-3.5 h-3.5" />}
              <span>{isSavedAssignment ? 'Assignment Saved!' : 'Save Hierarchy Assignment'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Host Earnings Wallet Tab */}
      {activeTab === 'wallet' && (
        <div className="space-y-4 text-xs">
          <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Wallet className="w-5 h-5 text-amber-400 flex-shrink-0" />
              <div>
                <span className="font-bold text-amber-300">Host Earnings Wallet (Virtual TEST COINS)</span>
                <p className="text-[11px] text-amber-200/80">TEST MODE Active — Virtual earnings ledger with zero cash payout or real-money processing.</p>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40 text-[10px]">
              TEST MODE
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 bg-neutral-900/90 border border-neutral-800 rounded-2xl">
              <span className="text-[10px] text-neutral-400 uppercase font-bold">Total Virtual Earned</span>
              <p className="text-lg font-black text-amber-400 font-mono mt-1">{(host.earningsWallet?.totalEarnedCoins || host.diamonds || 0).toLocaleString()} TC</p>
            </div>
            <div className="p-3.5 bg-neutral-900/90 border border-neutral-800 rounded-2xl">
              <span className="text-[10px] text-neutral-400 uppercase font-bold">Gift Split Share</span>
              <p className="text-lg font-black text-emerald-400 font-mono mt-1">{host.earningsWallet?.commissionRate || 70}%</p>
            </div>
            <div className="p-3.5 bg-neutral-900/90 border border-neutral-800 rounded-2xl">
              <span className="text-[10px] text-neutral-400 uppercase font-bold">Lucky Box / Packets Earned</span>
              <p className="text-lg font-black text-rose-400 font-mono mt-1">{((host.earningsWallet?.luckyGiftEarnings || 0) + (host.earningsWallet?.redPacketEarnings || 0)).toLocaleString()} TC</p>
            </div>
          </div>

          {/* Earnings History Ledger */}
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">Host Earnings Transaction Ledger</span>
            {(host.earningsWallet?.history && host.earningsWallet.history.length > 0) ? (
              <div className="space-y-2">
                {host.earningsWallet.history.map((tx) => (
                  <div key={tx.id} className="p-3 bg-neutral-900/80 border border-neutral-800 rounded-xl flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <span className="text-lg">{tx.giftIcon || '🎁'}</span>
                      <div>
                        <h5 className="font-bold text-white">{tx.giftName} ({tx.multiplier || 1}x)</h5>
                        <p className="text-[11px] text-neutral-400">From <span className="text-rose-400 font-semibold">{tx.senderName}</span> • {tx.timestamp}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-emerald-400 font-bold font-mono">+{tx.hostEarningAmount.toLocaleString()} TC</span>
                      <p className="text-[10px] text-neutral-500">Price: {tx.giftPrice.toLocaleString()} TC</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-neutral-500 bg-neutral-900/40 rounded-xl border border-neutral-800">
                No gift earnings records yet. Send a gift to this host in a live room to test.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Live History Tab */}
      {activeTab === 'live_history' && (
        <div className="space-y-2 text-xs">
          <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">Recent 4K Live Broadcast Records</span>
          {(host.liveHistory && host.liveHistory.length > 0) ? (
            <div className="space-y-2">
              {host.liveHistory.map((lh) => (
                <div key={lh.id} className="p-3 bg-neutral-900/80 border border-neutral-800 rounded-xl flex items-center justify-between gap-3">
                  <div>
                    <h5 className="font-bold text-white">{lh.title}</h5>
                    <div className="flex items-center gap-2 text-neutral-400 text-[11px] mt-0.5">
                      <span>{lh.date}</span>
                      <span>•</span>
                      <span>Duration: {lh.durationMinutes} min</span>
                      <span>•</span>
                      <span>Category: {lh.category}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-amber-400 font-bold font-mono">+{(lh.diamondsEarned ?? 0).toLocaleString()} 💎</span>
                    <p className="text-[10px] text-neutral-400">Peak: {(lh.peakViewers ?? 0).toLocaleString()} viewers</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 text-center text-neutral-500 bg-neutral-900/40 rounded-xl border border-neutral-800">
              No historical broadcast archive recorded.
            </div>
          )}
        </div>
      )}

      {/* Gift History Tab */}
      {activeTab === 'gift_history' && (
        <div className="space-y-2 text-xs">
          <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">Incoming Virtual Gifts Stream</span>
          {(host.giftHistory && host.giftHistory.length > 0) ? (
            <div className="space-y-2">
              {host.giftHistory.map((gh) => (
                <div key={gh.id} className="p-3 bg-neutral-900/80 border border-neutral-800 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-lg">🎁</span>
                    <div>
                      <h5 className="font-bold text-white">{gh.giftName}</h5>
                      <p className="text-[11px] text-neutral-400">From <span className="text-rose-400 font-semibold">{gh.senderName}</span> • {gh.time}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-emerald-400 font-bold font-mono">+{(gh.diamondsReceived ?? 0).toLocaleString()} 💎</span>
                    <p className="text-[10px] text-neutral-500">{gh.coinsValue} coins</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 text-center text-neutral-500 bg-neutral-900/40 rounded-xl border border-neutral-800">
              No gifts recorded yet in this cycle.
            </div>
          )}
        </div>
      )}

      {/* Moderation & Actions Tab */}
      {activeTab === 'actions' && (
        <div className="space-y-3 text-xs">
          <div className="p-4 bg-neutral-900/90 border border-neutral-800 rounded-2xl space-y-3">
            <span className="font-bold text-white block">Owner Host Controls & State Enforcement</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={() => onUpdateStatus && onUpdateStatus(host.id, 'Active')}
                className="py-2 px-3 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 rounded-xl font-bold transition-all text-center"
              >
                ✓ Set Active / Approve
              </button>
              <button
                onClick={() => onUpdateStatus && onUpdateStatus(host.id, 'Suspended')}
                className="py-2 px-3 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 rounded-xl font-bold transition-all text-center"
              >
                ⚠ Suspend Host
              </button>
              <button
                onClick={() => onUpdateStatus && onUpdateStatus(host.id, 'Banned')}
                className="py-2 px-3 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 rounded-xl font-bold transition-all text-center"
              >
                ⛔ Permanent Ban
              </button>
              <button
                onClick={() => onUpdateStatus && onUpdateStatus(host.id, 'Pending')}
                className="py-2 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl font-bold transition-all text-center"
              >
                ⟳ Reset to Pending
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
  };


  const renderSuperAdminDetails = (sa: SuperAdminAccount) => (
    <div className="space-y-4 text-xs">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Account Credentials</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">ID:</span>
            <span className="font-mono font-bold text-white">{sa.id}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Username:</span>
            <span className="text-purple-400 font-semibold">@{sa.username}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Email:</span>
            <span className="text-white">{sa.email}</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Phone:</span>
            <span className="text-white">{sa.phone}</span>
          </div>
        </div>

        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Governance & Scope</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Assigned Area:</span>
            <span className="text-white font-medium">{sa.assignedArea}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Created:</span>
            <span className="text-neutral-300">{sa.createdDate}</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Last Login:</span>
            <span className="text-neutral-300">{sa.lastLogin}</span>
          </div>
        </div>
      </div>

      {/* Permissions */}
      <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
        <span className="text-[10px] uppercase font-bold text-neutral-400 block">Assigned Elevated Permissions</span>
        <div className="flex flex-wrap gap-1.5">
          {(sa.assignedPermissions || []).map((p) => (
            <span key={p} className="px-2.5 py-1 rounded-lg bg-purple-500/10 text-purple-300 border border-purple-500/20 font-mono text-[11px]">
              ✓ {p}
            </span>
          ))}
        </div>
      </div>

      {/* Owner Actions */}
      <div className="p-3.5 bg-neutral-900/80 border border-neutral-800 rounded-2xl flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <button
            onClick={() => onResetAccess && onResetAccess(sa.id)}
            className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-xl font-bold flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset 2FA / Password</span>
          </button>
          <button
            onClick={() => onUpdateStatus && onUpdateStatus(sa.id, sa.status === 'Active' ? 'Suspended' : 'Active')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              sa.status === 'Active' ? 'bg-amber-600/20 text-amber-300 border border-amber-500/40' : 'bg-emerald-600 text-white'
            }`}
          >
            {sa.status === 'Active' ? 'Suspend Super Admin' : 'Activate Account'}
          </button>
        </div>
      </div>
    </div>
  );

  const renderAdminDetails = (adm: AdminAccount) => (
    <div className="space-y-4 text-xs">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Admin Info</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">ID:</span>
            <span className="font-mono font-bold text-white">{adm.id}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Username:</span>
            <span className="text-blue-400 font-semibold">@{adm.username}</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Contact:</span>
            <span className="text-white truncate max-w-[180px]">{adm.contact}</span>
          </div>
        </div>

        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Activity Metrics</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Actions Logged:</span>
            <span className="font-bold text-emerald-400">{adm.activityCount} actions</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Created:</span>
            <span className="text-neutral-300">{adm.createdDate}</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Last Login:</span>
            <span className="text-neutral-300">{adm.lastLogin}</span>
          </div>
        </div>
      </div>

      <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
        <span className="text-[10px] uppercase font-bold text-neutral-400 block">Assigned Operational Permissions</span>
        <div className="flex flex-wrap gap-1.5">
          {(adm.permissions || []).map((p) => (
            <span key={p} className="px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-300 border border-blue-500/20 font-mono text-[11px]">
              ✓ {p}
            </span>
          ))}
        </div>
      </div>
    </div>
  );

  const renderManagerDetails = (mgr: ManagerAccount) => (
    <div className="space-y-4 text-xs">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Manager Details</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">ID:</span>
            <span className="font-mono font-bold text-white">{mgr.id}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Username:</span>
            <span className="text-emerald-400 font-semibold">@{mgr.username}</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Contact:</span>
            <span className="text-white truncate max-w-[180px]">{mgr.contact}</span>
          </div>
        </div>

        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Roster & Performance</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Managed Hosts:</span>
            <span className="font-bold text-white">{mgr.hostCount} hosts</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Talent Diamonds:</span>
            <span className="font-mono text-amber-400 font-bold">{(mgr.totalEarningsDiamonds ?? 0).toLocaleString()} 💎</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Performance Rating:</span>
            <span className="font-bold text-emerald-400">⭐ {mgr.performanceRating} / 5.0</span>
          </div>
        </div>
      </div>

      <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
        <span className="text-[10px] uppercase font-bold text-neutral-400 block">Assigned Agency Guilds</span>
        <div className="flex flex-wrap gap-1.5">
          {(mgr.assignedAgencyNames || []).map((name, i) => (
            <span key={name} className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-medium">
              🏢 {name} ({(mgr.assignedAgencies && mgr.assignedAgencies[i]) || 'AG'})
            </span>
          ))}
        </div>
      </div>
    </div>
  );

  const renderAgencyDetails = (ag: AgencyAccount) => (
    <div className="space-y-4 text-xs">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Agency Organization</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Agency ID:</span>
            <span className="font-mono font-bold text-white">{ag.id}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Agency Code:</span>
            <span className="text-cyan-400 font-bold">{ag.code}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Lead / Manager:</span>
            <span className="text-white">{ag.ownerOrManager}</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Commission Rate:</span>
            <span className="text-emerald-400 font-bold font-mono">{ag.commissionRate}%</span>
          </div>
        </div>

        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Broadcasting Performance</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Total Signed Hosts:</span>
            <span className="font-bold text-white">{ag.numberOfHosts} hosts ({ag.activeHosts} live)</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Performance Score:</span>
            <span className="font-bold text-emerald-400">{ag.hostPerformanceScore}%</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Total Diamonds:</span>
            <span className="text-rose-400 font-mono font-bold">{(ag.totalEarningsDiamonds ?? 0).toLocaleString()} 💎</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderUserDetails = (usr: UserAccount) => (
    <div className="space-y-4 text-xs">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">User Identity</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">ID:</span>
            <span className="font-mono font-bold text-white">{usr.id}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Username:</span>
            <span className="text-amber-400 font-semibold">@{usr.username}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Email:</span>
            <span className="text-white">{usr.email}</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">VIP Tier:</span>
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
              VIP Level {usr.vipLevel}
            </span>
          </div>
        </div>

        <div className="bg-neutral-900/80 p-3.5 rounded-2xl border border-neutral-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-neutral-400">Wallet & Activity</span>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Coin Balance:</span>
            <span className="font-mono text-yellow-400 font-bold">{(usr.coinBalance ?? 0).toLocaleString()} 🪙</span>
          </div>
          <div className="flex justify-between py-1 border-b border-neutral-800/60">
            <span className="text-neutral-400">Total Spent:</span>
            <span className="font-mono text-white">{(usr.totalSpentCoins ?? 0).toLocaleString()} coins</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-neutral-400">Last Active:</span>
            <span className="text-neutral-300">{usr.lastActive}</span>
          </div>
        </div>
      </div>

      <div className="p-3.5 bg-neutral-900/80 border border-neutral-800 rounded-2xl flex items-center justify-between gap-3 flex-wrap">
        <span className="font-bold text-white">Owner User Sanctions</span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onUpdateStatus && onUpdateStatus(usr.id, 'Muted')}
            className="px-3 py-1.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 rounded-xl font-bold"
          >
            Mute Chat (24h)
          </button>
          <button
            onClick={() => onUpdateStatus && onUpdateStatus(usr.id, usr.status === 'Banned' ? 'Active' : 'Banned')}
            className={`px-3 py-1.5 rounded-xl font-bold ${
              usr.status === 'Banned' ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
            }`}
          >
            {usr.status === 'Banned' ? 'Unban User' : 'Ban User Account'}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-950 border border-neutral-800 rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-4 animate-in zoom-in-95 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800 flex-shrink-0">
          <div className="flex items-center gap-3">
            <img
              src={data.avatar || data.logo || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
              alt={data.name}
              className="w-12 h-12 rounded-2xl object-cover border border-neutral-700"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-bold text-white">{data.name}</h3>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${ROLE_BADGE_COLORS[role]}`}>
                  {ROLE_LABELS[role].split(' ')[0]}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  data.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300' :
                  data.status === 'Suspended' ? 'bg-amber-500/20 text-amber-300' :
                  data.status === 'Banned' ? 'bg-rose-500/20 text-rose-300' :
                  'bg-neutral-800 text-neutral-300'
                }`}>
                  {data.status}
                </span>
              </div>
              <p className="text-xs text-neutral-400 font-mono mt-0.5">
                ID: {data.id} • Registered in DIYO LIVE Enterprise Matrix
              </p>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dynamic Detail Body by Role */}
        <div className="flex-1 min-h-0 overflow-y-auto pr-1">
          {role === 'HOST' && renderHostDetails(data)}
          {role === 'SUPER_ADMIN' && renderSuperAdminDetails(data)}
          {role === 'ADMIN' && renderAdminDetails(data)}
          {role === 'MANAGER' && renderManagerDetails(data)}
          {role === 'AGENCY' && renderAgencyDetails(data)}
          {role === 'USER' && renderUserDetails(data)}
        </div>

      </div>
    </div>
  );
};
