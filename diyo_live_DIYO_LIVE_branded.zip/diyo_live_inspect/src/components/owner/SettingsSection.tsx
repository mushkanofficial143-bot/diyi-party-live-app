import React, { useState } from 'react';
import { 
  Settings, 
  ShieldAlert, 
  Coins, 
  Gem, 
  DollarSign, 
  Lock, 
  Globe, 
  Save,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { PlatformSettings } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface SettingsSectionProps {
  settings: PlatformSettings;
  onUpdateSettings: (newSettings: PlatformSettings) => void;
}

export const SettingsSection: React.FC<SettingsSectionProps> = ({
  settings,
  onUpdateSettings
}) => {
  const [form, setForm] = useState<PlatformSettings>({
    platformCommissionRate: settings?.platformCommissionRate ?? 15,
    diamondToUSDRate: settings?.diamondToUSDRate ?? 10000,
    coinPriceUSD: settings?.coinPriceUSD ?? 100,
    diamondRedemptionRateUSD: settings?.diamondRedemptionRateUSD ?? 200,
    minWithdrawalDiamonds: settings?.minWithdrawalDiamonds ?? 50000,
    hostDefaultCommissionRate: settings?.hostDefaultCommissionRate ?? 70,
    agencyDefaultCommissionRate: settings?.agencyDefaultCommissionRate ?? 15,
    defaultAgencyCommissionRate: settings?.defaultAgencyCommissionRate ?? settings?.agencyDefaultCommissionRate ?? 15,
    maintenanceMode: settings?.maintenanceMode ?? false,
    antiFraudAIEnabled: settings?.antiFraudAIEnabled ?? true,
    antiFraudEnabled: settings?.antiFraudEnabled ?? settings?.antiFraudAIEnabled ?? true,
    autoApproveHosts: settings?.autoApproveHosts ?? false,
    allowMultiCamStreaming: settings?.allowMultiCamStreaming ?? true,
    maxTestTransactionAmount: settings?.maxTestTransactionAmount ?? 100000
  });
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(form);
    playSoundFX('notification');
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-neutral-800 text-neutral-300 border border-neutral-700">
              <Settings className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Global Platform Architecture & Economy Rules</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 border border-neutral-700">
              System Core
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Configure exchange ratios, payout commissions, broadcast safety thresholds, and platform-wide maintenance locks.
          </p>
        </div>
      </div>

      {/* Form Settings */}
      <form onSubmit={handleSave} className="space-y-5 text-xs max-w-3xl">
        
        {/* Economy Grid */}
        <div className="p-5 bg-neutral-900/80 border border-neutral-800 rounded-2xl space-y-4 shadow-xl">
          <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <Coins className="w-4 h-4" />
            <span>Virtual Currency & Exchange Ratios</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-neutral-300 mb-1">Coin Price (Coins per 1.00 USD)</label>
              <input
                type="number"
                value={form.coinPriceUSD ?? 100}
                onChange={(e) => setForm({ ...form, coinPriceUSD: Number(e.target.value) })}
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-white font-mono"
              />
              <span className="text-[10px] text-neutral-500">Default: 100 coins = $1.00 USD</span>
            </div>

            <div>
              <label className="block font-semibold text-neutral-300 mb-1">Diamond Redemption Rate (Diamonds per 1.00 USD)</label>
              <input
                type="number"
                value={form.diamondRedemptionRateUSD ?? 200}
                onChange={(e) => setForm({ ...form, diamondRedemptionRateUSD: Number(e.target.value) })}
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-white font-mono"
              />
              <span className="text-[10px] text-neutral-500">Default: 200 diamonds = $1.00 USD</span>
            </div>

            <div>
              <label className="block font-semibold text-neutral-300 mb-1">Platform Revenue Cut (%)</label>
              <input
                type="number"
                value={form.platformCommissionRate ?? 15}
                onChange={(e) => setForm({ ...form, platformCommissionRate: Number(e.target.value) })}
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-300 mb-1">Default Agency Commission (%)</label>
              <input
                type="number"
                value={form.defaultAgencyCommissionRate ?? 15}
                onChange={(e) => setForm({ ...form, defaultAgencyCommissionRate: Number(e.target.value) })}
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>
          </div>
        </div>

        {/* Global Platform Tax & Service Surcharge Matrix */}
        <div className="p-5 bg-neutral-900/80 border border-amber-500/30 rounded-2xl space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>Platform Tax & Surcharge Policy Matrix</span>
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
              Tax Engine Active
            </span>
          </div>

          <p className="text-[11px] text-neutral-400">
            Configure real-time government TDS, cashout deduction tax, P2P & coin merchant trading fees, and VIP exemption privileges.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
              <label className="block font-semibold text-neutral-200 mb-1">Withdrawal / TDS Tax (%)</label>
              <input
                type="number"
                step="0.5"
                value={form.platformWithdrawalTaxRate ?? 5.0}
                onChange={(e) => setForm({ ...form, platformWithdrawalTaxRate: Number(e.target.value) })}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs"
              />
              <span className="text-[10px] text-neutral-400 mt-1 block">Deducted on eSewa / Bank / USD cashouts</span>
            </div>

            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
              <label className="block font-semibold text-neutral-200 mb-1">Coins Trading / Transfer Tax (%)</label>
              <input
                type="number"
                step="0.5"
                value={form.coinTransferTaxRate ?? 2.0}
                onChange={(e) => setForm({ ...form, coinTransferTaxRate: Number(e.target.value) })}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs"
              />
              <span className="text-[10px] text-neutral-400 mt-1 block">Merchant & User P2P transfer tax</span>
            </div>

            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
              <label className="block font-semibold text-neutral-200 mb-1">Live Gifting Platform Cut (%)</label>
              <input
                type="number"
                step="0.5"
                value={form.platformGiftingTaxRate ?? 15.0}
                onChange={(e) => setForm({ ...form, platformGiftingTaxRate: Number(e.target.value) })}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs"
              />
              <span className="text-[10px] text-neutral-400 mt-1 block">Live room & PK battle revenue cut</span>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-neutral-950 rounded-xl border border-neutral-800">
            <input
              type="checkbox"
              id="vip-tax-rebate"
              checked={form.vipTaxRebateEnabled ?? true}
              onChange={(e) => setForm({ ...form, vipTaxRebateEnabled: e.target.checked })}
              className="rounded border-neutral-700 text-amber-500"
            />
            <label htmlFor="vip-tax-rebate" className="font-semibold text-neutral-200 text-xs cursor-pointer">
              Enable VIP Nobility Tax Rebates (High VIP tiers receive up to 50% discount on withdrawal tax & 0% trading fee)
            </label>
          </div>
        </div>

        {/* Safety & Fraud Protection */}
        <div className="p-5 bg-neutral-900/80 border border-neutral-800 rounded-2xl space-y-4 shadow-xl">
          <h3 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4" />
            <span>Safety, Fraud Guard & Withdrawal Limits</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-neutral-300 mb-1">Minimum Diamonds for Withdrawal</label>
              <input
                type="number"
                value={form.minWithdrawalDiamonds ?? 50000}
                onChange={(e) => setForm({ ...form, minWithdrawalDiamonds: Number(e.target.value) })}
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>

            <div className="flex items-center gap-3 p-3 bg-neutral-950 rounded-xl border border-neutral-800">
              <input
                type="checkbox"
                id="anti-fraud-check"
                checked={Boolean(form.antiFraudEnabled)}
                onChange={(e) => setForm({ ...form, antiFraudEnabled: e.target.checked })}
                className="rounded border-neutral-700 text-rose-500"
              />
              <label htmlFor="anti-fraud-check" className="font-semibold text-white cursor-pointer">
                Enable AI Anti-Fraud & Chargeback Auto-Freeze
              </label>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-neutral-950 rounded-xl border border-neutral-800">
            <input
              type="checkbox"
              id="maintenance-mode-check"
              checked={Boolean(form.maintenanceMode)}
              onChange={(e) => setForm({ ...form, maintenanceMode: e.target.checked })}
              className="rounded border-neutral-700 text-amber-500"
            />
            <label htmlFor="maintenance-mode-check" className="font-semibold text-white cursor-pointer">
              Emergency Maintenance Mode (Locks all non-Owner logins)
            </label>
          </div>
        </div>

        {/* Save button */}
        <div className="flex items-center gap-3">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-bold text-xs shadow-lg shadow-amber-900/30 transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Save Global Platform Settings</span>
          </button>

          {saved && (
            <span className="text-emerald-400 font-bold flex items-center gap-1.5 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4" />
              <span>Settings applied successfully!</span>
            </span>
          )}
        </div>

      </form>

    </div>
  );
};
