/**
 * DIYO LIVE - Staff & Role Hiring Hub Component
 * Allows Owner/Super Admin to instantly hire Coin Sellers, BD Executives, Admins, Managers, Agency Owners, and Hosts.
 */

import React, { useState } from 'react';
import {
  UserPlus,
  Coins,
  ShieldCheck,
  Building2,
  Users,
  Briefcase,
  Phone,
  Mail,
  CheckCircle,
  Sparkles,
  Award,
  DollarSign
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface StaffHiringHubSectionProps {
  onHireCoinSeller: (data: any) => Promise<boolean>;
  onHireAdmin: (data: any) => Promise<boolean>;
  onHireManager: (data: any) => Promise<boolean>;
  onHireAgency: (data: any) => Promise<boolean>;
  onHireBD: (data: any) => Promise<boolean>;
}

export const StaffHiringHubSection: React.FC<StaffHiringHubSectionProps> = ({
  onHireCoinSeller,
  onHireAdmin,
  onHireManager,
  onHireAgency,
  onHireBD
}) => {
  const [activeCategory, setActiveCategory] = useState<'COIN_SELLER' | 'BD' | 'ADMIN' | 'MANAGER' | 'AGENCY'>('COIN_SELLER');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Form states
  const [coinSellerForm, setCoinSellerForm] = useState({
    name: '',
    username: '',
    phone: '',
    email: '',
    initialCoins: '10000000',
    dailyLimit: '50000000',
    singleLimit: '10000000',
    commissionRate: '5'
  });

  const [bdForm, setBdForm] = useState({
    name: '',
    username: '',
    contact: '',
    email: '',
    assignedArea: 'South Asia (India/Nepal)',
    baseSalary: '500',
    commissionPct: '10'
  });

  const [adminForm, setAdminForm] = useState({
    name: '',
    username: '',
    contact: '',
    roleTier: 'SUPER_ADMIN',
    assignedArea: 'Global Platform'
  });

  const [managerForm, setManagerForm] = useState({
    name: '',
    username: '',
    contact: '',
    assignedAgencyCode: 'AG-01'
  });

  const [agencyForm, setAgencyForm] = useState({
    name: '',
    code: 'AG-' + Math.floor(100 + Math.random() * 900),
    ownerName: '',
    contactEmail: '',
    commissionRate: '15'
  });

  const handleHireSubmit = async (type: string) => {
    setIsSubmitting(true);
    setSuccessMessage(null);
    playSoundFX('coin');

    try {
      let success = false;
      if (type === 'COIN_SELLER') {
        success = await onHireCoinSeller({
          name: coinSellerForm.name || 'New Coin Seller',
          username: coinSellerForm.username || `seller_${Date.now()}`,
          phone: coinSellerForm.phone,
          email: coinSellerForm.email,
          initialCoins: Number(coinSellerForm.initialCoins) || 10000000,
          dailyLimit: Number(coinSellerForm.dailyLimit) || 50000000,
          singleLimit: Number(coinSellerForm.singleLimit) || 10000000
        });
        if (success) setSuccessMessage('✅ Coin Seller hired and assigned successfully!');
      } else if (type === 'BD') {
        success = await onHireBD({
          name: bdForm.name || 'BD Executive',
          username: bdForm.username || `bd_${Date.now()}`,
          contact: bdForm.contact,
          email: bdForm.email,
          assignedArea: bdForm.assignedArea,
          commissionPct: Number(bdForm.commissionPct)
        });
        if (success) setSuccessMessage('✅ BD (Business Development Executive) hired successfully!');
      } else if (type === 'ADMIN') {
        success = await onHireAdmin({
          name: adminForm.name || 'System Admin',
          username: adminForm.username || `admin_${Date.now()}`,
          contact: adminForm.contact,
          permissions: ['global_moderation', 'user_ban', 'finance_audit'],
          assignedArea: adminForm.assignedArea
        });
        if (success) setSuccessMessage('✅ Admin / Super Admin hired with full permissions!');
      } else if (type === 'MANAGER') {
        success = await onHireManager({
          name: managerForm.name || 'Agency Manager',
          username: managerForm.username || `mgr_${Date.now()}`,
          contact: managerForm.contact,
          assignedAgencies: [managerForm.assignedAgencyCode]
        });
        if (success) setSuccessMessage('✅ Manager hired and assigned to agency!');
      } else if (type === 'AGENCY') {
        success = await onHireAgency({
          name: agencyForm.name || 'Elite Talent Agency',
          code: agencyForm.code,
          ownerOrManager: agencyForm.ownerName || 'Agency Guild Master',
          contactEmail: agencyForm.contactEmail,
          commissionRate: Number(agencyForm.commissionRate) || 15
        });
        if (success) setSuccessMessage('✅ New Agency Guild created and hired successfully!');
      }
    } catch (e: any) {
      setSuccessMessage(`❌ Error: ${e.message || 'Hiring failed'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-500/20 via-purple-600/20 to-rose-500/20 border border-amber-500/30 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500 text-neutral-950 flex items-center justify-center font-black shadow-lg">
            <UserPlus className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">Staff & Role Hiring Command Hub</h2>
            <p className="text-xs text-neutral-300">Instantly hire Coin Sellers, BD Executives, Admins, Managers, and Agencies</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-bold">
            👑 Owner Privilege
          </span>
        </div>
      </div>

      {successMessage && (
        <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-sm font-bold flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-emerald-400" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Category Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {[
          { id: 'COIN_SELLER', label: 'Coin Seller Hiring', icon: Coins, color: 'from-amber-500 to-yellow-600' },
          { id: 'BD', label: 'BD Executive', icon: Briefcase, color: 'from-blue-600 to-cyan-600' },
          { id: 'ADMIN', label: 'Admin / Super Admin', icon: ShieldCheck, color: 'from-purple-600 to-indigo-600' },
          { id: 'MANAGER', label: 'Agency Manager', icon: Users, color: 'from-emerald-600 to-teal-600' },
          { id: 'AGENCY', label: 'Talent Agency', icon: Building2, color: 'from-rose-600 to-pink-600' }
        ].map(cat => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id as any);
                setSuccessMessage(null);
                playSoundFX('click');
              }}
              className={`p-3.5 rounded-2xl border flex flex-col items-center gap-2 text-center transition-all cursor-pointer ${
                isActive
                  ? 'bg-neutral-900 border-amber-400 shadow-lg shadow-amber-500/20 scale-[1.02]'
                  : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-white'
              }`}
            >
              <div className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${cat.color} flex items-center justify-center text-white shadow`}>
                <Icon className="w-4 h-4" />
              </div>
              <span className="text-xs font-black text-white">{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Hiring Form Workspace */}
      <div className="p-6 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-2xl">
        {/* 1. COIN SELLER HIRING */}
        {activeCategory === 'COIN_SELLER' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-800">
              <Coins className="w-5 h-5 text-amber-400" />
              <h3 className="text-sm font-black text-white">Hire New Official Coin Seller</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Seller Full Name</label>
                <input
                  type="text"
                  value={coinSellerForm.name}
                  onChange={e => setCoinSellerForm({ ...coinSellerForm, name: e.target.value })}
                  placeholder="e.g. Rahul Coin Hub"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Username / ID Code</label>
                <input
                  type="text"
                  value={coinSellerForm.username}
                  onChange={e => setCoinSellerForm({ ...coinSellerForm, username: e.target.value })}
                  placeholder="e.g. rahul_coins"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">WhatsApp / Phone</label>
                <input
                  type="text"
                  value={coinSellerForm.phone}
                  onChange={e => setCoinSellerForm({ ...coinSellerForm, phone: e.target.value })}
                  placeholder="+91 9876543210"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Email Address</label>
                <input
                  type="email"
                  value={coinSellerForm.email}
                  onChange={e => setCoinSellerForm({ ...coinSellerForm, email: e.target.value })}
                  placeholder="seller@srlive.io"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Initial Starting Coins</label>
                <input
                  type="number"
                  value={coinSellerForm.initialCoins}
                  onChange={e => setCoinSellerForm({ ...coinSellerForm, initialCoins: e.target.value })}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Daily Transfer Limit</label>
                <input
                  type="number"
                  value={coinSellerForm.dailyLimit}
                  onChange={e => setCoinSellerForm({ ...coinSellerForm, dailyLimit: e.target.value })}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>
            </div>
            <button
              onClick={() => handleHireSubmit('COIN_SELLER')}
              disabled={isSubmitting}
              className="mt-4 w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30 hover:opacity-95 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Coins className="w-4 h-4" />
              <span>{isSubmitting ? 'Hiring Coin Seller...' : 'Hire & Authorize Coin Seller'}</span>
            </button>
          </div>
        )}

        {/* 2. BD (BUSINESS DEVELOPMENT) HIRING */}
        {activeCategory === 'BD' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-800">
              <Briefcase className="w-5 h-5 text-cyan-400" />
              <h3 className="text-sm font-black text-white">Hire Business Development (BD) Executive</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">BD Full Name</label>
                <input
                  type="text"
                  value={bdForm.name}
                  onChange={e => setBdForm({ ...bdForm, name: e.target.value })}
                  placeholder="e.g. Aman Sharma (BD Lead)"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Username</label>
                <input
                  type="text"
                  value={bdForm.username}
                  onChange={e => setBdForm({ ...bdForm, username: e.target.value })}
                  placeholder="e.g. aman_bd"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Contact / WhatsApp</label>
                <input
                  type="text"
                  value={bdForm.contact}
                  onChange={e => setBdForm({ ...bdForm, contact: e.target.value })}
                  placeholder="+91 9123456789"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Assigned Region / Area</label>
                <input
                  type="text"
                  value={bdForm.assignedArea}
                  onChange={e => setBdForm({ ...bdForm, assignedArea: e.target.value })}
                  placeholder="North India & Nepal Guilds"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Commission Share (%)</label>
                <input
                  type="number"
                  value={bdForm.commissionPct}
                  onChange={e => setBdForm({ ...bdForm, commissionPct: e.target.value })}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>
            </div>
            <button
              onClick={() => handleHireSubmit('BD')}
              disabled={isSubmitting}
              className="mt-4 w-full py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/30 hover:opacity-95 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Briefcase className="w-4 h-4" />
              <span>{isSubmitting ? 'Hiring BD...' : 'Hire & Assign BD Executive'}</span>
            </button>
          </div>
        )}

        {/* 3. ADMIN / SUPER ADMIN HIRING */}
        {activeCategory === 'ADMIN' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-800">
              <ShieldCheck className="w-5 h-5 text-purple-400" />
              <h3 className="text-sm font-black text-white">Hire System Admin / Super Admin</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Admin Full Name</label>
                <input
                  type="text"
                  value={adminForm.name}
                  onChange={e => setAdminForm({ ...adminForm, name: e.target.value })}
                  placeholder="e.g. Vikram Security Chief"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Username</label>
                <input
                  type="text"
                  value={adminForm.username}
                  onChange={e => setAdminForm({ ...adminForm, username: e.target.value })}
                  placeholder="e.g. vikram_admin"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Contact Number</label>
                <input
                  type="text"
                  value={adminForm.contact}
                  onChange={e => setAdminForm({ ...adminForm, contact: e.target.value })}
                  placeholder="+91 9988776655"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Role Tier</label>
                <select
                  value={adminForm.roleTier}
                  onChange={e => setAdminForm({ ...adminForm, roleTier: e.target.value })}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400"
                >
                  <option value="SUPER_ADMIN">👑 Super Admin (Full Global Override)</option>
                  <option value="ADMIN">🛡️ Standard Admin (Moderation & Finance)</option>
                </select>
              </div>
            </div>
            <button
              onClick={() => handleHireSubmit('ADMIN')}
              disabled={isSubmitting}
              className="mt-4 w-full py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-purple-500/30 hover:opacity-95 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{isSubmitting ? 'Hiring Admin...' : 'Hire & Authorize Admin'}</span>
            </button>
          </div>
        )}

        {/* 4. MANAGER HIRING */}
        {activeCategory === 'MANAGER' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-800">
              <Users className="w-5 h-5 text-emerald-400" />
              <h3 className="text-sm font-black text-white">Hire Agency Manager</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Manager Full Name</label>
                <input
                  type="text"
                  value={managerForm.name}
                  onChange={e => setManagerForm({ ...managerForm, name: e.target.value })}
                  placeholder="e.g. Priya Agency Manager"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Username</label>
                <input
                  type="text"
                  value={managerForm.username}
                  onChange={e => setManagerForm({ ...managerForm, username: e.target.value })}
                  placeholder="e.g. priya_mgr"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Contact</label>
                <input
                  type="text"
                  value={managerForm.contact}
                  onChange={e => setManagerForm({ ...managerForm, contact: e.target.value })}
                  placeholder="+91 9876501234"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Assign Agency Code</label>
                <input
                  type="text"
                  value={managerForm.assignedAgencyCode}
                  onChange={e => setManagerForm({ ...managerForm, assignedAgencyCode: e.target.value })}
                  placeholder="AG-01"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400 uppercase font-mono"
                />
              </div>
            </div>
            <button
              onClick={() => handleHireSubmit('MANAGER')}
              disabled={isSubmitting}
              className="mt-4 w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-500/30 hover:opacity-95 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Users className="w-4 h-4" />
              <span>{isSubmitting ? 'Hiring Manager...' : 'Hire & Assign Manager'}</span>
            </button>
          </div>
        )}

        {/* 5. AGENCY HIRING */}
        {activeCategory === 'AGENCY' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-800">
              <Building2 className="w-5 h-5 text-rose-400" />
              <h3 className="text-sm font-black text-white">Hire / Create Talent Agency Guild</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Agency Guild Name</label>
                <input
                  type="text"
                  value={agencyForm.name}
                  onChange={e => setAgencyForm({ ...agencyForm, name: e.target.value })}
                  placeholder="e.g. Royal Star Talent Agency"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-rose-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Agency Code (Unique)</label>
                <input
                  type="text"
                  value={agencyForm.code}
                  onChange={e => setAgencyForm({ ...agencyForm, code: e.target.value })}
                  placeholder="AG-105"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-rose-400 uppercase font-mono"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Owner / Guild Master Name</label>
                <input
                  type="text"
                  value={agencyForm.ownerName}
                  onChange={e => setAgencyForm({ ...agencyForm, ownerName: e.target.value })}
                  placeholder="e.g. Karan Singhania"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-rose-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Contact Email</label>
                <input
                  type="email"
                  value={agencyForm.contactEmail}
                  onChange={e => setAgencyForm({ ...agencyForm, contactEmail: e.target.value })}
                  placeholder="agency@srlive.io"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-rose-400"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-400 block mb-1">Commission Rate (%)</label>
                <input
                  type="number"
                  value={agencyForm.commissionRate}
                  onChange={e => setAgencyForm({ ...agencyForm, commissionRate: e.target.value })}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-rose-400 font-mono"
                />
              </div>
            </div>
            <button
              onClick={() => handleHireSubmit('AGENCY')}
              disabled={isSubmitting}
              className="mt-4 w-full py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-pink-600 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-rose-600/30 hover:opacity-95 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Building2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Creating Agency...' : 'Hire & Establish Talent Agency'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
