import React, { useState } from 'react';
import { ShieldCheck, Search, ArrowUpRight, ArrowDownLeft, Coins, Filter, Download } from 'lucide-react';
import { WalletTransaction, CasinoTestTransaction, CoinSellerTransaction, OwnerToSellerTransaction } from '../../types/ownerTypes';

interface TransactionsSectionProps {
  walletTransactions: WalletTransaction[];
  casinoTransactions: CasinoTestTransaction[];
  coinSellerTransactions: CoinSellerTransaction[];
  ownerToSellerTransactions: OwnerToSellerTransaction[];
}

export const TransactionsSection: React.FC<TransactionsSectionProps> = ({
  walletTransactions = [],
  casinoTransactions = [],
  coinSellerTransactions = [],
  ownerToSellerTransactions = []
}) => {
  const [tab, setTab] = useState<'ALL' | 'OWNER_SELLER' | 'SELLER_USER' | 'CASINO' | 'WALLET'>('ALL');
  const [search, setSearch] = useState('');

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span>Master Transactions & Audit Ledger</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Complete transaction registry across Owner Treasury, Coin Sellers, User disbursements, and Casino test simulations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {(['ALL', 'OWNER_SELLER', 'SELLER_USER', 'CASINO', 'WALLET'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                tab === t
                  ? 'bg-amber-500 text-neutral-950 font-black shadow-md shadow-amber-500/20'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              {t.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900">
        <table className="w-full text-left text-xs text-neutral-300">
          <thead className="bg-neutral-950 text-neutral-400 font-bold uppercase tracking-wider border-b border-neutral-800">
            <tr>
              <th className="py-3 px-4">Transaction ID</th>
              <th className="py-3 px-4">Module / Type</th>
              <th className="py-3 px-4">Sender ➔ Recipient</th>
              <th className="py-3 px-4">Amount</th>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4">Notes</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800 font-mono">
            {/* Owner to Seller */}
            {(tab === 'ALL' || tab === 'OWNER_SELLER') &&
              (ownerToSellerTransactions || []).map(tx => (
                <tr key={tx.id} className="hover:bg-neutral-800/40">
                  <td className="py-3 px-4 font-bold text-amber-400">{tx.id}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-bold">
                      {tx.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-sans font-medium text-white">Owner ➔ {tx.sellerName}</td>
                  <td className="py-3 px-4 text-amber-400 font-bold">{(tx.amount ?? 0).toLocaleString()} Coins</td>
                  <td className="py-3 px-4 text-neutral-500 text-[11px] font-sans">{tx.timestamp}</td>
                  <td className="py-3 px-4 text-neutral-400 text-[11px] font-sans truncate max-w-xs">{tx.notes}</td>
                </tr>
              ))}

            {/* Seller to User */}
            {(tab === 'ALL' || tab === 'SELLER_USER') &&
              (coinSellerTransactions || []).map(tx => (
                <tr key={tx.id} className="hover:bg-neutral-800/40">
                  <td className="py-3 px-4 font-bold text-yellow-400">{tx.id}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-full text-[10px] bg-yellow-500/20 text-yellow-300 font-bold">
                      SELLER_TO_USER
                    </span>
                  </td>
                  <td className="py-3 px-4 font-sans font-medium text-white">{tx.sellerName} ➔ {tx.userName}</td>
                  <td className="py-3 px-4 text-yellow-400 font-bold">{(tx.amount ?? 0).toLocaleString()} Coins</td>
                  <td className="py-3 px-4 text-neutral-500 text-[11px] font-sans">{tx.timestamp}</td>
                  <td className="py-3 px-4 text-neutral-400 text-[11px] font-sans truncate max-w-xs">{tx.notes}</td>
                </tr>
              ))}

            {/* Casino Games */}
            {(tab === 'ALL' || tab === 'CASINO') &&
              (casinoTransactions || []).map(tx => (
                <tr key={tx.id} className="hover:bg-neutral-800/40">
                  <td className="py-3 px-4 font-bold text-cyan-400">{tx.id}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      tx.outcome === 'WIN' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                    }`}>
                      CASINO: {tx.gameName} ({tx.outcome})
                    </span>
                  </td>
                  <td className="py-3 px-4 font-sans font-medium text-white">{tx.userName} (Bet: {(tx.bet ?? 0).toLocaleString()})</td>
                  <td className="py-3 px-4 text-cyan-400 font-bold">{tx.reward ? `+${(tx.reward ?? 0).toLocaleString()}` : `-${(tx.bet ?? 0).toLocaleString()}`} Coins</td>
                  <td className="py-3 px-4 text-neutral-500 text-[11px] font-sans">{tx.timestamp}</td>
                  <td className="py-3 px-4 text-neutral-400 text-[11px] font-sans truncate max-w-xs">{tx.result}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
