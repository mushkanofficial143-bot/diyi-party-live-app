import React, { useState } from 'react';
import {
  Ban,
  ShieldCheck,
  ShieldAlert,
  Search,
  CheckCircle2,
  AlertTriangle,
  UserX,
  UserCheck,
  Clock,
  History,
  Sparkles,
  RefreshCw,
  Lock,
  Unlock
} from 'lucide-react';
import { UserAccount } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface UserBanUnbanPowerHubProps {
  users: UserAccount[];
  onUpdateUsers?: (users: UserAccount[]) => void;
  operatorRole?: string;
  operatorName?: string;
  onAuditLog?: (log: any) => void;
}

const BAN_REASONS = [
  'Terms of Service Violation',
  'Payment / Coin Topup Fraud',
  'Abusive Behavior & Harassment in Live Stream',
  'Fake / Spam Bot Account',
  'Unauthorized Administrative Impersonation',
  'Copyright / Re-broadcast Infringement',
  'Custom Reason'
];

const BAN_DURATIONS = [
  { label: 'Permanent (Lifetime Ban)', value: 'Permanent' },
  { label: '24 Hours (Warning Suspension)', value: '24 Hours' },
  { label: '7 Days (Temporary Freeze)', value: '7 Days' },
  { label: '30 Days (Extended Suspension)', value: '30 Days' }
];

export const UserBanUnbanPowerHub: React.FC<UserBanUnbanPowerHubProps> = ({
  users = [],
  onUpdateUsers,
  operatorRole = 'Super Admin / Admin',
  operatorName = 'Master Authority',
  onAuditLog
}) => {
  const [targetQuery, setTargetQuery] = useState('');
  const [selectedReason, setSelectedReason] = useState(BAN_REASONS[0]);
  const [customReasonText, setCustomReasonText] = useState('');
  const [selectedDuration, setSelectedDuration] = useState('Permanent');
  const [isProcessing, setIsProcessing] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [actionHistory, setActionHistory] = useState<Array<{
    id: string;
    userId: string;
    userName: string;
    action: 'BAN' | 'UNBAN';
    reason?: string;
    timestamp: string;
  }>>([]);

  // Find candidate user
  const cleanQuery = targetQuery.trim().toLowerCase();
  const matchedUser = users.find((u) => {
    if (!cleanQuery) return false;
    const padded = cleanQuery.padStart(7, '0');
    return (
      u.id.toLowerCase() === cleanQuery ||
      u.id === padded ||
      u.username.toLowerCase() === cleanQuery ||
      (u.name && u.name.toLowerCase() === cleanQuery)
    );
  });

  const bannedUsers = users.filter((u) => u.status === 'Banned' || u.status === 'Suspended');

  const isSuperAdmin = operatorRole?.toUpperCase().includes('SUPER_ADMIN');

  const executeBan = async (userToBan: UserAccount) => {
    try {
      setIsProcessing(true);
      playSoundFX('alert');

      const reasonToUse = selectedReason === 'Custom Reason' ? (customReasonText.trim() || 'Admin Discretionary Enforcement') : selectedReason;

      // Update backend
      try {
        await fetch('/api/admin/users/ban', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: userToBan.id,
            reason: reasonToUse,
            duration: selectedDuration,
            operator: `${operatorRole} (${operatorName})`
          })
        });
      } catch (err) {
        console.warn('Backend ban API notification error:', err);
      }

      // Optimistically update local users state
      if (onUpdateUsers) {
        const updated = users.map((u) =>
          u.id === userToBan.id ? { ...u, status: 'Banned' as const } : u
        );
        onUpdateUsers(updated);
      }

      const historyEntry = {
        id: `ACT-${Date.now()}`,
        userId: userToBan.id,
        userName: userToBan.name,
        action: 'BAN' as const,
        reason: `${reasonToUse} (${selectedDuration})`,
        timestamp: new Date().toLocaleTimeString()
      };
      setActionHistory((prev) => [historyEntry, ...prev.slice(0, 9)]);

      setFeedbackMessage({
        type: 'success',
        text: `⛔ User #${userToBan.id} (${userToBan.name}) is now BANNED. Duration: ${selectedDuration}. Reason: ${reasonToUse}`
      });
      setTimeout(() => setFeedbackMessage(null), 6000);
    } catch (e) {
      setFeedbackMessage({ type: 'error', text: 'Failed to ban user.' });
    } finally {
      setIsProcessing(false);
    }
  };

  const executeUnban = async (userToUnban: UserAccount) => {
    if (isSuperAdmin) {
      playSoundFX('alert');
      setFeedbackMessage({
        type: 'error',
        text: 'SECURITY_DENIED: Super Admin role is strictly prohibited from unbanning users. Authorization rejected.'
      });
      return;
    }

    try {
      setIsProcessing(true);
      playSoundFX('win');

      // Update backend
      try {
        const res = await fetch('/api/admin/users/unban', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: userToUnban.id,
            operator: `${operatorRole} (${operatorName})`,
            role: operatorRole
          })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Server rejected unban');
        }
      } catch (err: any) {
        console.warn('Backend unban API error:', err);
        if (err.message?.includes('SECURITY_DENIED') || err.message?.includes('rejected')) {
          setFeedbackMessage({ type: 'error', text: err.message });
          return;
        }
      }

      // Optimistically update local users state
      if (onUpdateUsers) {
        const updated = users.map((u) =>
          u.id === userToUnban.id ? { ...u, status: 'Active' as const } : u
        );
        onUpdateUsers(updated);
      }

      const historyEntry = {
        id: `ACT-${Date.now()}`,
        userId: userToUnban.id,
        userName: userToUnban.name,
        action: 'UNBAN' as const,
        reason: 'Restored to Active state by Admin power',
        timestamp: new Date().toLocaleTimeString()
      };
      setActionHistory((prev) => [historyEntry, ...prev.slice(0, 9)]);

      setFeedbackMessage({
        type: 'success',
        text: `✅ User #${userToUnban.id} (${userToUnban.name}) has been UNBANNED and restored to Active status!`
      });
      setTimeout(() => setFeedbackMessage(null), 6000);
    } catch (e) {
      setFeedbackMessage({ type: 'error', text: 'Failed to unban user.' });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="bg-neutral-900/90 border border-rose-500/30 rounded-2xl p-5 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Glow Effect */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-inner">
            <Ban className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white font-['Outfit']">
                Instant User ID Ban & Unban Power Hub
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" /> High-Authority Power
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              Target any 7-digit User ID or username to enforce immediate bans or restore suspended accounts with one click.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-neutral-950/80 border border-neutral-800 text-xs">
            <span className="text-neutral-400">Total Banned Users: </span>
            <strong className="text-rose-400 font-mono font-bold">{bannedUsers.length}</strong>
          </div>
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMessage && (
        <div
          className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in ${
            feedbackMessage.type === 'success'
              ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300'
              : 'bg-rose-500/20 border border-rose-500/40 text-rose-300'
          }`}
        >
          {feedbackMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
          )}
          <span>{feedbackMessage.text}</span>
        </div>
      )}

      {/* Two Column Layout: Action Center & Live Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left Column: ID Search & Enforcement Config (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Target ID Lookup */}
          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1.5 uppercase tracking-wider">
              Enter 7-Digit User ID or Username
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="e.g. 0000001 or aarav_prime"
                value={targetQuery}
                onChange={(e) => setTargetQuery(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 font-mono"
              />
              {targetQuery && (
                <button
                  onClick={() => setTargetQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-neutral-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Quick Select from Registered Users */}
          <div className="space-y-1">
            <span className="text-[11px] text-neutral-400 block font-medium">Quick Select Registered User:</span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {users.slice(0, 6).map((u) => (
                <button
                  key={u.id}
                  onClick={() => {
                    setTargetQuery(u.id);
                    playSoundFX('click');
                  }}
                  className={`text-xs px-2.5 py-1 rounded-lg border transition-all flex items-center gap-1.5 ${
                    targetQuery === u.id
                      ? 'bg-rose-600 text-white border-rose-500 font-bold'
                      : u.status === 'Banned'
                      ? 'bg-rose-950/40 text-rose-300 border-rose-800/60 hover:border-rose-500'
                      : 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <span className="font-mono font-bold text-[11px]">{u.id}</span>
                  <span className="text-neutral-400">•</span>
                  <span>{u.name}</span>
                  {u.status === 'Banned' && (
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 inline-block" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Ban Reasons & Durations Config */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                Violation Reason
              </label>
              <select
                value={selectedReason}
                onChange={(e) => setSelectedReason(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
              >
                {BAN_REASONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                Ban Duration
              </label>
              <select
                value={selectedDuration}
                onChange={(e) => setSelectedDuration(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
              >
                {BAN_DURATIONS.map((d) => (
                  <option key={d.value} value={d.value}>
                    {d.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {selectedReason === 'Custom Reason' && (
            <div>
              <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                Custom Violation Details
              </label>
              <input
                type="text"
                placeholder="Describe exact violation reason for audit records..."
                value={customReasonText}
                onChange={(e) => setCustomReasonText(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500"
              />
            </div>
          )}

        </div>

        {/* Right Column: Matched User Live Preview Card & Instant Action Buttons (5 Cols) */}
        <div className="lg:col-span-5 bg-neutral-950/90 border border-neutral-800 rounded-xl p-4 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-neutral-850">
              <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
                Target User Dossier
              </span>
              {matchedUser && (
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                    matchedUser.status === 'Active'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  }`}
                >
                  Status: {matchedUser.status}
                </span>
              )}
            </div>

            {matchedUser ? (
              <div className="mt-3 space-y-3">
                <div className="flex items-center gap-3">
                  <img
                    src={matchedUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                    alt={matchedUser.name}
                    className="w-12 h-12 rounded-xl object-cover border border-neutral-700"
                  />
                  <div>
                    <h4 className="font-bold text-white text-sm">{matchedUser.name}</h4>
                    <div className="flex items-center gap-1.5 text-xs text-neutral-400">
                      <span className="font-mono text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                        ID: {matchedUser.id}
                      </span>
                      <span>•</span>
                      <span>@{matchedUser.username}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs bg-neutral-900/80 p-2.5 rounded-xl border border-neutral-800">
                  <div>
                    <span className="text-[10px] text-neutral-500 block">VIP Level</span>
                    <span className="font-bold text-amber-300">Level {matchedUser.vipLevel || 0}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-500 block">Coin Balance</span>
                    <span className="font-bold text-yellow-400 font-mono">
                      {(matchedUser.coinBalance ?? 0).toLocaleString()} 🪙
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-500 block">Diamonds</span>
                    <span className="font-bold text-cyan-300 font-mono">
                      {(matchedUser.diamondBalance ?? 0).toLocaleString()} 💎
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-500 block">Role</span>
                    <span className="font-bold text-neutral-300">{matchedUser.role || 'USER'}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-neutral-500 text-xs space-y-1">
                <Search className="w-6 h-6 mx-auto text-neutral-600 mb-2" />
                <p>Type a 7-digit ID or username on the left to preview dossier.</p>
              </div>
            )}
          </div>

          {/* Action Trigger Buttons */}
          <div className="space-y-2 pt-2">
            {matchedUser ? (
              matchedUser.status === 'Banned' ? (
                isSuperAdmin ? (
                  <div className="w-full py-2.5 px-4 rounded-xl bg-neutral-900 border border-rose-500/30 text-rose-400 font-bold text-xs flex items-center justify-center gap-2">
                    <Lock className="w-4 h-4 text-rose-400" />
                    <span>Super Admin: Unban Restricted (Manager/Official Only)</span>
                  </div>
                ) : (
                  <button
                    disabled={isProcessing}
                    onClick={() => executeUnban(matchedUser)}
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/40 transition-all flex items-center justify-center gap-2"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>Unban & Restore Account Now</span>
                  </button>
                )
              ) : (
                <button
                  disabled={isProcessing}
                  onClick={() => executeBan(matchedUser)}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-red-700 hover:from-rose-500 hover:to-red-600 text-white font-bold text-xs shadow-lg shadow-rose-950/40 transition-all flex items-center justify-center gap-2"
                >
                  <Ban className="w-4 h-4" />
                  <span>Apply Immediate Ban ({selectedDuration})</span>
                </button>
              )
            ) : (
              <button
                disabled
                className="w-full py-2.5 px-4 rounded-xl bg-neutral-900 text-neutral-600 font-bold text-xs cursor-not-allowed flex items-center justify-center gap-2 border border-neutral-800"
              >
                <Ban className="w-4 h-4" />
                <span>Select User to Apply Power</span>
              </button>
            )}
          </div>

        </div>

      </div>

      {/* Currently Banned Accounts Live List */}
      <div className="space-y-3 pt-2 border-t border-neutral-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UserX className="w-4 h-4 text-rose-400" />
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Currently Banned Accounts Registry ({bannedUsers.length})
            </h4>
          </div>
        </div>

        {bannedUsers.length === 0 ? (
          <div className="p-4 rounded-xl bg-neutral-950/60 border border-neutral-800 text-center text-xs text-neutral-400 flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>No users are currently banned. The platform is running smoothly.</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {bannedUsers.map((bu) => (
              <div
                key={bu.id}
                className="p-3 rounded-xl bg-neutral-950/90 border border-rose-500/30 flex items-center justify-between gap-3 shadow-md hover:border-rose-500/60 transition-colors"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <img
                    src={bu.avatar}
                    alt={bu.name}
                    className="w-9 h-9 rounded-xl object-cover border border-rose-500/40 flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <span className="font-bold text-white text-xs truncate block">{bu.name}</span>
                    <div className="flex items-center gap-1.5 text-[11px] text-neutral-400 font-mono">
                      <span className="text-rose-400 font-bold">ID: {bu.id}</span>
                      <span>•</span>
                      <span>@{bu.username}</span>
                    </div>
                  </div>
                </div>

                {isSuperAdmin ? (
                  <span className="px-2.5 py-1 rounded-lg bg-neutral-900 text-neutral-500 border border-neutral-800 text-[10px] font-bold flex items-center gap-1">
                    <Lock className="w-3 h-3 text-rose-400" />
                    <span>Restricted</span>
                  </span>
                ) : (
                  <button
                    onClick={() => executeUnban(bu)}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 font-bold text-[11px] transition-all flex items-center gap-1 flex-shrink-0"
                    title="Unban Account"
                  >
                    <Unlock className="w-3 h-3" />
                    <span>Unban</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Action History Telemetry */}
      {actionHistory.length > 0 && (
        <div className="space-y-2 pt-2 border-t border-neutral-800 text-xs">
          <div className="flex items-center gap-1.5 text-neutral-400 font-bold text-[11px] uppercase tracking-wider">
            <History className="w-3.5 h-3.5" />
            <span>Session Enforcement History</span>
          </div>
          <div className="space-y-1.5">
            {actionHistory.map((item) => (
              <div
                key={item.id}
                className="px-3 py-1.5 rounded-lg bg-neutral-950/70 border border-neutral-800/80 flex items-center justify-between text-[11px]"
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`font-bold px-1.5 py-0.2 rounded text-[9px] ${
                      item.action === 'BAN'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}
                  >
                    {item.action}
                  </span>
                  <span className="text-white font-medium">
                    #{item.userId} ({item.userName})
                  </span>
                  {item.reason && <span className="text-neutral-400">• {item.reason}</span>}
                </div>
                <span className="text-neutral-500 font-mono text-[10px]">{item.timestamp}</span>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
