import React, { useState, useEffect } from 'react';
import { 
  Crown, Sparkles, Coins, ShieldCheck, Percent, Edit, Check, Flame, 
  Users, DollarSign, Plus, ToggleLeft, ToggleRight, Trash2, Search,
  RefreshCw, UserPlus, UserX, Clock, Calendar, ArrowUpRight, Zap,
  CheckCircle2, AlertCircle, FileText
} from 'lucide-react';
import { VipLevelConfig, UserVipRecord, VipTransaction, VipSystemStats } from '../../types/vipTypes.js';
import { VipBadge } from '../badges/VipBadge.js';
import { playSoundFX } from '../../utils/audioSynth.js';

interface VipSectionProps {
  vipConfigs?: any[];
  onUpdateVipConfig?: (level: number, updated: any) => void;
}

export const VipSection: React.FC<VipSectionProps> = () => {
  const [activeTab, setActiveTab] = useState<'tiers' | 'members' | 'transactions' | 'analytics'>('tiers');
  const [levels, setLevels] = useState<VipLevelConfig[]>([]);
  const [members, setMembers] = useState<UserVipRecord[]>([]);
  const [transactions, setTransactions] = useState<VipTransaction[]>([]);
  const [stats, setStats] = useState<VipSystemStats | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Edit Tier Modal State
  const [editingTier, setEditingTier] = useState<VipLevelConfig | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<VipLevelConfig>>({});

  // Grant VIP Modal State
  const [showGrantModal, setShowGrantModal] = useState<boolean>(false);
  const [grantUserId, setGrantUserId] = useState<string>('');
  const [grantUserName, setGrantUserName] = useState<string>('');
  const [grantLevel, setGrantLevel] = useState<number>(1);
  const [grantDays, setGrantDays] = useState<number>(30);
  const [grantNotes, setGrantNotes] = useState<string>('');

  // Search & Filters
  const [memberSearch, setMemberSearch] = useState<string>('');
  const [txSearch, setTxSearch] = useState<string>('');

  useEffect(() => {
    fetchAllVipAdminData();
  }, []);

  const fetchAllVipAdminData = async () => {
    setLoading(true);
    try {
      // 1. Levels
      const lvlRes = await fetch('/api/vip/levels');
      const lvlData = await lvlRes.json();
      if (lvlData.success) setLevels(lvlData.levels);

      // 2. Members
      const memRes = await fetch('/api/vip/members');
      const memData = await memRes.json();
      if (memData.success) setMembers(memData.members);

      // 3. Transactions
      const txRes = await fetch('/api/vip/transactions');
      const txData = await txRes.json();
      if (txData.success) setTransactions(txData.transactions);

      // 4. Stats
      const statRes = await fetch('/api/vip/stats');
      const statData = await statRes.json();
      if (statData.success) setStats(statData.stats);
    } catch (err: any) {
      console.error('Error fetching VIP admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const showAlert = (type: 'success' | 'error', message: string) => {
    setAlert({ type, message });
    setTimeout(() => setAlert(null), 4000);
  };

  // Toggle Level Active
  const handleToggleLevel = async (level: number) => {
    try {
      const res = await fetch('/api/vip/levels/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ level })
      });
      const data = await res.json();
      if (data.success) {
        playSoundFX('click');
        showAlert('success', data.message);
        fetchAllVipAdminData();
      }
    } catch (err: any) {
      showAlert('error', err.message);
    }
  };

  // Save Tier Edits
  const handleSaveTier = async () => {
    if (!editingTier) return;
    try {
      const res = await fetch('/api/vip/levels/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          level: editingTier.level,
          updated: editFormData
        })
      });
      const data = await res.json();
      if (data.success) {
        playSoundFX('notification');
        showAlert('success', data.message);
        setEditingTier(null);
        fetchAllVipAdminData();
      } else {
        showAlert('error', data.error);
      }
    } catch (err: any) {
      showAlert('error', err.message);
    }
  };

  // Admin Grant VIP
  const handleAdminGrant = async () => {
    if (!grantUserId.trim()) {
      showAlert('error', 'User ID is required.');
      return;
    }

    try {
      const res = await fetch('/api/vip/admin/assign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: grantUserId.trim(),
          userName: grantUserName.trim() || `User ${grantUserId}`,
          targetLevel: Number(grantLevel),
          durationDays: Number(grantDays),
          adminId: 'OWNER-001',
          adminName: 'Super Admin',
          notes: grantNotes.trim()
        })
      });
      const data = await res.json();
      if (data.success) {
        playSoundFX('win');
        showAlert('success', data.message);
        setShowGrantModal(false);
        setGrantUserId('');
        setGrantUserName('');
        setGrantNotes('');
        fetchAllVipAdminData();
      } else {
        showAlert('error', data.error);
      }
    } catch (err: any) {
      showAlert('error', err.message);
    }
  };

  // Admin Revoke VIP
  const handleRevokeVip = async (userId: string) => {
    if (!window.confirm(`Are you sure you want to revoke VIP membership for user ${userId}?`)) return;

    try {
      const res = await fetch('/api/vip/admin/revoke', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          adminId: 'OWNER-001',
          adminName: 'Super Admin',
          reason: 'Revoked by Super Admin'
        })
      });
      const data = await res.json();
      if (data.success) {
        playSoundFX('notification');
        showAlert('success', data.message);
        fetchAllVipAdminData();
      }
    } catch (err: any) {
      showAlert('error', err.message);
    }
  };

  const filteredMembers = members.filter(m => 
    m.userName.toLowerCase().includes(memberSearch.toLowerCase()) || 
    m.userId.toLowerCase().includes(memberSearch.toLowerCase())
  );

  const filteredTransactions = transactions.filter(t => 
    t.userName.toLowerCase().includes(txSearch.toLowerCase()) || 
    t.userId.toLowerCase().includes(txSearch.toLowerCase()) ||
    t.id.toLowerCase().includes(txSearch.toLowerCase())
  );

  return (
    <div className="space-y-5">
      
      {/* Alert Banner */}
      {alert && (
        <div className={`p-4 rounded-2xl border text-xs font-bold flex items-center justify-between animate-in fade-in ${
          alert.type === 'success' 
            ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300' 
            : 'bg-rose-500/20 border-rose-500/40 text-rose-300'
        }`}>
          <div className="flex items-center gap-2">
            {alert.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
            <span>{alert.message}</span>
          </div>
          <button onClick={() => setAlert(null)} className="text-neutral-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Top Header & Metrics Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 rounded-3xl bg-neutral-900/90 border border-amber-500/30">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 text-black shadow-lg shadow-amber-950/60 font-black">
              <Crown className="w-6 h-6 fill-black" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">VIP NOBILITY MANAGEMENT SUITE</h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold uppercase">
                  VIP 1–10 Live System
                </span>
              </div>
              <p className="text-xs text-neutral-400">Configure pricing, benefits, entrance animations, and manage active VIP subscribers.</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowGrantModal(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-black font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-amber-950/40"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Grant VIP</span>
          </button>
          <button
            onClick={fetchAllVipAdminData}
            disabled={loading}
            className="px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-bold flex items-center gap-1.5 border border-neutral-700 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Admin Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2 overflow-x-auto scrollbar-none">
        {[
          { id: 'tiers', label: 'VIP Tiers (1–10)', icon: Crown, count: levels.length },
          { id: 'members', label: 'Subscribers & Members', icon: Users, count: members.length },
          { id: 'transactions', label: 'Purchase Ledger', icon: FileText, count: transactions.length },
          { id: 'analytics', label: 'Revenue Analytics', icon: DollarSign }
        ].map(tab => {
          const Icon = tab.icon;
          const isSelected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                playSoundFX('click');
              }}
              className={`px-4 py-2.5 rounded-2xl border text-xs font-bold transition-all flex items-center gap-2 ${
                isSelected
                  ? 'bg-amber-500 text-black border-amber-400 font-black shadow-lg shadow-amber-950/40'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              {typeof tab.count === 'number' && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${isSelected ? 'bg-black text-amber-400 font-bold' : 'bg-neutral-800 text-neutral-400'}`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: VIP TIERS CONFIGURATION (1 to 10)                                 */}
      {/* ========================================================================= */}
      {activeTab === 'tiers' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {levels.map(tier => (
              <div 
                key={tier.level}
                className={`p-4 rounded-3xl bg-neutral-900/90 border transition-all flex flex-col justify-between space-y-3 relative overflow-hidden ${
                  tier.isActive ? 'border-amber-500/30 hover:border-amber-500/60' : 'border-neutral-800 opacity-60'
                }`}
              >
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{tier.badgeIcon}</span>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-black text-white text-sm">{tier.title}</h3>
                        <VipBadge level={tier.level} size="xs" />
                      </div>
                      <span className="text-[11px] text-neutral-400">{tier.subtitle}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleToggleLevel(tier.level)}
                      title={tier.isActive ? 'Deactivate Tier' : 'Activate Tier'}
                      className={`p-1.5 rounded-xl border text-xs transition-all ${
                        tier.isActive ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400' : 'bg-neutral-800 border-neutral-700 text-neutral-500'
                      }`}
                    >
                      {tier.isActive ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => {
                        setEditingTier(tier);
                        setEditFormData({ ...tier });
                        playSoundFX('click');
                      }}
                      className="p-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-amber-300 border border-neutral-700 transition-all"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Pricing Badges */}
                <div className="p-3 bg-neutral-950/80 rounded-2xl border border-neutral-800/80 space-y-2 text-xs font-mono">
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="bg-neutral-900 p-2 rounded-xl border border-neutral-800">
                      <span className="text-neutral-500 block text-[9px]">7 DAYS</span>
                      <span className="font-bold text-yellow-400">{tier.pricing['7d'].toLocaleString()} TC</span>
                    </div>
                    <div className="bg-neutral-900 p-2 rounded-xl border border-neutral-800">
                      <span className="text-neutral-500 block text-[9px]">30 DAYS</span>
                      <span className="font-bold text-yellow-400">{tier.pricing['30d'].toLocaleString()} TC</span>
                    </div>
                    <div className="bg-neutral-900 p-2 rounded-xl border border-neutral-800">
                      <span className="text-neutral-500 block text-[9px]">90 DAYS</span>
                      <span className="font-bold text-yellow-400">{tier.pricing['90d'].toLocaleString()} TC</span>
                    </div>
                    <div className="bg-neutral-900 p-2 rounded-xl border border-neutral-800">
                      <span className="text-neutral-500 block text-[9px]">1 YEAR</span>
                      <span className="font-bold text-yellow-400">{tier.pricing['365d'].toLocaleString()} TC</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[11px] font-sans">
                    <span className="text-neutral-400">Entrance:</span>
                    <span className="text-amber-300 font-bold truncate max-w-[150px]">{tier.entranceEffect.name}</span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] font-sans">
                    <span className="text-neutral-400">Discounts:</span>
                    <span className="text-emerald-400 font-bold">{tier.storeDiscountPercent}% Store / {tier.withdrawalTaxDiscountPercent}% Tax Rebate</span>
                  </div>
                </div>

                {/* Privileges count */}
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span>{tier.privileges.length} Exclusive Perks</span>
                  <span className="text-amber-400 font-bold">{tier.totalActiveMembers} Active Users</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: SUBSCRIBERS & MEMBERS MANAGEMENT                                   */}
      {/* ========================================================================= */}
      {activeTab === 'members' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="relative max-w-sm w-full">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search member name or ID..."
                value={memberSearch}
                onChange={e => setMemberSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500/50"
              />
            </div>
            <span className="text-xs text-neutral-400 font-mono">Total: {filteredMembers.length} Members</span>
          </div>

          <div className="bg-neutral-900/90 border border-neutral-800 rounded-3xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-950 text-neutral-400 font-bold border-b border-neutral-800 uppercase text-[10px]">
                <tr>
                  <th className="p-3.5">User</th>
                  <th className="p-3.5">VIP Tier</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Plan</th>
                  <th className="p-3.5">Remaining</th>
                  <th className="p-3.5">Expiry Date</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {filteredMembers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-neutral-500">
                      No VIP members found matching your search.
                    </td>
                  </tr>
                ) : (
                  filteredMembers.map(m => (
                    <tr key={m.userId} className="hover:bg-neutral-800/40 transition-colors">
                      <td className="p-3.5 flex items-center gap-2.5">
                        <img src={m.userAvatar} alt="avatar" className="w-8 h-8 rounded-full border border-neutral-700 object-cover" />
                        <div>
                          <span className="font-bold text-white block">{m.userName}</span>
                          <span className="text-[10px] text-neutral-500 font-mono">{m.userId}</span>
                        </div>
                      </td>
                      <td className="p-3.5">
                        <VipBadge level={m.vipLevel} size="xs" />
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          m.status === 'ACTIVE' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-neutral-800 text-neutral-400'
                        }`}>
                          {m.status}
                        </span>
                      </td>
                      <td className="p-3.5 capitalize font-mono text-neutral-300">
                        {m.planDuration}
                      </td>
                      <td className="p-3.5 font-mono text-amber-300 font-bold">
                        {m.remainingDays} days
                      </td>
                      <td className="p-3.5 text-neutral-400 font-mono text-[11px]">
                        {new Date(m.expiresAt).toLocaleDateString()}
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => handleRevokeVip(m.userId)}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[11px] font-bold transition-all"
                        >
                          Revoke
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: TRANSACTION AUDIT LEDGER                                           */}
      {/* ========================================================================= */}
      {activeTab === 'transactions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="relative max-w-sm w-full">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search tx id, user or tier..."
                value={txSearch}
                onChange={e => setTxSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500/50"
              />
            </div>
            <span className="text-xs text-neutral-400 font-mono">{filteredTransactions.length} Transactions</span>
          </div>

          <div className="bg-neutral-900/90 border border-neutral-800 rounded-3xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-950 text-neutral-400 font-bold border-b border-neutral-800 uppercase text-[10px]">
                <tr>
                  <th className="p-3.5">TX ID</th>
                  <th className="p-3.5">User</th>
                  <th className="p-3.5">Action</th>
                  <th className="p-3.5">Tier</th>
                  <th className="p-3.5">Amount (TC)</th>
                  <th className="p-3.5">Date & Time</th>
                  <th className="p-3.5">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60 font-mono">
                {filteredTransactions.map(tx => (
                  <tr key={tx.id} className="hover:bg-neutral-800/40 transition-colors">
                    <td className="p-3.5 text-neutral-500 text-[11px]">{tx.id}</td>
                    <td className="p-3.5 font-sans font-bold text-white">{tx.userName}</td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[10px]">
                        {tx.type}
                      </span>
                    </td>
                    <td className="p-3.5 text-yellow-300 font-bold">VIP {tx.level} ({tx.levelTitle})</td>
                    <td className="p-3.5 text-yellow-400 font-black">
                      {tx.costCoins > 0 ? `-${tx.costCoins.toLocaleString()}` : '0 (Admin)'}
                    </td>
                    <td className="p-3.5 text-neutral-400 text-[11px]">{new Date(tx.timestamp).toLocaleString()}</td>
                    <td className="p-3.5 font-sans text-neutral-400 text-[11px] max-w-xs truncate">{tx.notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: REVENUE & VIP ANALYTICS                                            */}
      {/* ========================================================================= */}
      {activeTab === 'analytics' && stats && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-3xl bg-neutral-900/90 border border-amber-500/30">
              <span className="text-neutral-400 text-xs font-bold uppercase">Total VIP Revenue</span>
              <div className="flex items-baseline gap-1 mt-1 font-mono">
                <span className="text-2xl font-black text-yellow-400">{stats.totalVipRevenueCoins.toLocaleString()}</span>
                <span className="text-xs font-bold text-amber-500">TC</span>
              </div>
            </div>
            <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800">
              <span className="text-neutral-400 text-xs font-bold uppercase">Active VIP Subscribers</span>
              <div className="flex items-baseline gap-1 mt-1 font-mono">
                <span className="text-2xl font-black text-emerald-400">{stats.totalActiveVipMembers}</span>
                <span className="text-xs text-neutral-500">Users</span>
              </div>
            </div>
            <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800">
              <span className="text-neutral-400 text-xs font-bold uppercase">Avg. Plan Duration</span>
              <div className="flex items-baseline gap-1 mt-1 font-mono">
                <span className="text-2xl font-black text-sky-400">30</span>
                <span className="text-xs text-neutral-500">Days</span>
              </div>
            </div>
          </div>

          {/* Tier Subscriber Distribution */}
          <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 space-y-3">
            <h3 className="text-sm font-black text-white">VIP Level Membership Breakdown</h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {levels.map(tier => {
                const count = stats.vipMembersByLevel[tier.level] || 0;
                return (
                  <div key={tier.level} className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>{tier.badgeIcon}</span>
                      <span className="text-xs font-bold text-white">VIP {tier.level}</span>
                    </div>
                    <span className="font-mono font-black text-amber-400 text-sm">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: EDIT VIP TIER CONFIGURATION                                        */}
      {/* ========================================================================= */}
      {editingTier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="bg-neutral-900 border border-amber-500/40 rounded-3xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Edit className="w-4 h-4 text-amber-400" />
                Configure VIP Level {editingTier.level}
              </h3>
              <button onClick={() => setEditingTier(null)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-3 text-xs max-h-[60vh] overflow-y-auto pr-1">
              <div>
                <label className="text-neutral-400 block mb-1">Tier Title:</label>
                <input
                  type="text"
                  value={editFormData.title || ''}
                  onChange={e => setEditFormData({ ...editFormData, title: e.target.value })}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div>
                  <label className="text-neutral-400 block mb-1">7-Day Price (TC):</label>
                  <input
                    type="number"
                    value={editFormData.pricing?.['7d'] || 0}
                    onChange={e => setEditFormData({
                      ...editFormData,
                      pricing: { ...editFormData.pricing!, '7d': Number(e.target.value) }
                    })}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2 text-yellow-400"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">30-Day Price (TC):</label>
                  <input
                    type="number"
                    value={editFormData.pricing?.['30d'] || 0}
                    onChange={e => setEditFormData({
                      ...editFormData,
                      pricing: { ...editFormData.pricing!, '30d': Number(e.target.value) }
                    })}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2 text-yellow-400"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">90-Day Price (TC):</label>
                  <input
                    type="number"
                    value={editFormData.pricing?.['90d'] || 0}
                    onChange={e => setEditFormData({
                      ...editFormData,
                      pricing: { ...editFormData.pricing!, '90d': Number(e.target.value) }
                    })}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2 text-yellow-400"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">365-Day Price (TC):</label>
                  <input
                    type="number"
                    value={editFormData.pricing?.['365d'] || 0}
                    onChange={e => setEditFormData({
                      ...editFormData,
                      pricing: { ...editFormData.pricing!, '365d': Number(e.target.value) }
                    })}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2 text-yellow-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-neutral-400 block mb-1">Store Discount (%):</label>
                  <input
                    type="number"
                    value={editFormData.storeDiscountPercent || 0}
                    onChange={e => setEditFormData({ ...editFormData, storeDiscountPercent: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2 text-emerald-400 font-mono"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Tax Rebate (%):</label>
                  <input
                    type="number"
                    value={editFormData.withdrawalTaxDiscountPercent || 0}
                    onChange={e => setEditFormData({ ...editFormData, withdrawalTaxDiscountPercent: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2 text-amber-400 font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-neutral-800 flex justify-end gap-2">
              <button
                onClick={() => setEditingTier(null)}
                className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveTier}
                className="px-5 py-2 rounded-xl bg-amber-500 text-black font-black text-xs uppercase"
              >
                Save Tier Config
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: ADMIN GRANT VIP TO USER                                            */}
      {/* ========================================================================= */}
      {showGrantModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="bg-neutral-900 border border-amber-500/40 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-amber-400" />
                Grant VIP Membership
              </h3>
              <button onClick={() => setShowGrantModal(false)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-neutral-400 block mb-1">User ID:</label>
                <input
                  type="text"
                  placeholder="e.g. USR-882941"
                  value={grantUserId}
                  onChange={e => setGrantUserId(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-neutral-400 block mb-1">User Name (Optional):</label>
                <input
                  type="text"
                  placeholder="e.g. Aarav Mehta"
                  value={grantUserName}
                  onChange={e => setGrantUserName(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-neutral-400 block mb-1">VIP Level (1–10):</label>
                  <select
                    value={grantLevel}
                    onChange={e => setGrantLevel(Number(e.target.value))}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2.5 text-yellow-300 font-bold"
                  >
                    {levels.map(l => (
                      <option key={l.level} value={l.level}>
                        VIP {l.level} - {l.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-neutral-400 block mb-1">Duration (Days):</label>
                  <input
                    type="number"
                    value={grantDays}
                    onChange={e => setGrantDays(Number(e.target.value))}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-neutral-400 block mb-1">Admin Reason / Note:</label>
                <input
                  type="text"
                  placeholder="e.g. Special Contributor Grant"
                  value={grantNotes}
                  onChange={e => setGrantNotes(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-2.5 text-white"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-neutral-800 flex justify-end gap-2">
              <button
                onClick={() => setShowGrantModal(false)}
                className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleAdminGrant}
                className="px-5 py-2 rounded-xl bg-amber-500 text-black font-black text-xs uppercase"
              >
                Grant VIP Membership
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
