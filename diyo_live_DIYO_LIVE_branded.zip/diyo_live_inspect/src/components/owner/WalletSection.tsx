import React, { useState } from 'react';
import { 
  Coins, 
  Gem, 
  Receipt, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Search, 
  Filter, 
  CreditCard, 
  RefreshCw,
  Zap,
  CheckCircle2,
  DollarSign
} from 'lucide-react';
import { WalletTransaction } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface WalletSectionProps {
  transactions: WalletTransaction[];
  onOpenAdjustCoins: () => void;
  onGenerateTestTransaction: () => void;
}

export const WalletSection: React.FC<WalletSectionProps> = ({
  transactions,
  onOpenAdjustCoins,
  onGenerateTestTransaction
}) => {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('ALL');

  const filtered = transactions.filter((tx) => {
    const matchesType = filterType === 'ALL' || tx.type === filterType;
    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (tx.id || '').toLowerCase().includes(q) ||
      (tx.senderName || '').toLowerCase().includes(q) ||
      (tx.recipientName || '').toLowerCase().includes(q) ||
      (tx.txHash || '').toLowerCase().includes(q);

    return matchesType && matchesSearch;
  });

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
              <Coins className="w-4 h-4 text-amber-400" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Treasury & Wallet Transactions</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
              Financial Ledger
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Monitor currency circulation, coin purchases, lucky gift payouts, test transactions, and manual adjustments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              onGenerateTestTransaction();
              playSoundFX('notification');
            }}
            className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-cyan-300 border border-cyan-500/30 text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm"
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>Generate Test Txn</span>
          </button>

          <button
            onClick={() => {
              onOpenAdjustCoins();
              playSoundFX('click');
            }}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white text-xs font-bold shadow-lg shadow-amber-900/30 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Adjust Balance</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search Txn ID, hash, sender, recipient..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto">
          {['ALL', 'COIN_PURCHASE', 'GIFT_SENT', 'LUCKY_WIN', 'WITHDRAWAL', 'COMMISSION_PAYOUT', 'TEST_TRANSACTION', 'MANUAL_ADJUSTMENT'].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1 rounded-xl font-bold transition-all whitespace-nowrap ${
                filterType === type
                  ? 'bg-amber-500 text-black shadow-sm'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {type.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-3.5">Transaction ID & Hash</th>
                <th className="p-3.5">Type & Channel</th>
                <th className="p-3.5">Sender → Recipient</th>
                <th className="p-3.5">Coins Flow</th>
                <th className="p-3.5">Diamonds Flow</th>
                <th className="p-3.5">Status & Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-mono">
              {filtered.map((tx) => (
                <tr key={tx.id} className="hover:bg-neutral-850/50 transition-colors">
                  
                  {/* Txn ID */}
                  <td className="p-3.5">
                    <div>
                      <span className="font-bold text-white block">{tx.id}</span>
                      <span className="text-[10px] text-neutral-500 truncate max-w-[140px] block">
                        {tx.txHash}
                      </span>
                    </div>
                  </td>

                  {/* Type */}
                  <td className="p-3.5 font-sans">
                    <span className="text-neutral-200 font-bold block text-[11px]">
                      {tx.type.replace('_', ' ')}
                    </span>
                    <span className="text-[10px] text-neutral-400 font-mono">{tx.paymentChannel}</span>
                  </td>

                  {/* Sender / Recipient */}
                  <td className="p-3.5 font-sans">
                    <div className="space-y-0.5">
                      <span className="text-white font-medium block">From: {tx.senderName}</span>
                      <span className="text-neutral-400 text-[11px] block">To: {tx.recipientName}</span>
                    </div>
                  </td>

                  {/* Coins */}
                  <td className="p-3.5">
                    {(tx.amountCoins ?? 0) > 0 ? (
                      <span className="text-amber-400 font-bold">
                        {(tx.amountCoins ?? 0).toLocaleString()} 🪙
                      </span>
                    ) : (
                      <span className="text-neutral-600">—</span>
                    )}
                  </td>

                  {/* Diamonds */}
                  <td className="p-3.5">
                    {(tx.amountDiamonds ?? 0) > 0 ? (
                      <span className="text-rose-400 font-bold">
                        {(tx.amountDiamonds ?? 0).toLocaleString()} 💎
                      </span>
                    ) : (
                      <span className="text-neutral-600">—</span>
                    )}
                  </td>

                  {/* Status & Time */}
                  <td className="p-3.5 font-sans">
                    <div className="space-y-0.5">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {tx.status}
                      </span>
                      <span className="text-[10px] text-neutral-500 block font-mono">
                        {tx.timestamp}
                      </span>
                    </div>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
