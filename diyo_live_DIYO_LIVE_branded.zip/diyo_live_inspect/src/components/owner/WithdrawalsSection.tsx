import React, { useState } from 'react';
import { 
  DollarSign, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ExternalLink, 
  Gem, 
  Building2, 
  Tv,
  Check,
  X
} from 'lucide-react';
import { WithdrawalRequest } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface WithdrawalsSectionProps {
  withdrawals: WithdrawalRequest[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

export const WithdrawalsSection: React.FC<WithdrawalsSectionProps> = ({
  withdrawals,
  onApprove,
  onReject
}) => {
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [search, setSearch] = useState('');

  const filtered = withdrawals.filter((w) => {
    const q = (search || '').toLowerCase();
    const matchesStatus = statusFilter === 'ALL' || w.status === statusFilter;
    const matchesSearch =
      (w.applicantName || '').toLowerCase().includes(q) ||
      (w.id || '').toLowerCase().includes(q) ||
      (w.payoutAddress || '').toLowerCase().includes(q);

    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-4">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              <DollarSign className="w-4 h-4 text-emerald-400" />
            </div>
            <h2 className="text-base font-bold text-white font-['Outfit']">Host & Agency Diamond Withdrawals</h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
              Payouts Queue
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            Process creator diamond payouts, verify bank & USDT addresses, approve settlements, or flag suspicious requests.
          </p>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by ID, applicant, address..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          {['ALL', 'Pending', 'Approved', 'Rejected'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-xl font-bold transition-all ${
                statusFilter === st
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Table of Withdrawals */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
              <tr>
                <th className="p-3.5">Request ID & Applicant</th>
                <th className="p-3.5">Diamonds Exchanged</th>
                <th className="p-3.5">Net Payout (USD)</th>
                <th className="p-3.5">Payout Method & Address</th>
                <th className="p-3.5">Status & Time</th>
                <th className="p-3.5 text-right">Settlement Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filtered.map((w) => (
                <tr key={w.id} className="hover:bg-neutral-850/50 transition-colors">
                  
                  {/* ID & Applicant */}
                  <td className="p-3.5">
                    <div>
                      <span className="font-bold text-white block">{w.applicantName}</span>
                      <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
                        <span className="font-mono text-emerald-400 font-bold">{w.id}</span>
                        <span>•</span>
                        <span className="capitalize">{(w.applicantRole || '').toLowerCase()}</span>
                      </div>
                    </div>
                  </td>

                  {/* Diamonds */}
                  <td className="p-3.5 font-mono">
                    <span className="font-bold text-rose-400">
                      {(w?.diamondsAmount ?? 0).toLocaleString()} 💎
                    </span>
                  </td>

                  {/* USD Amount */}
                  <td className="p-3.5 font-mono">
                    <span className="font-bold text-emerald-400 text-sm">
                      ${(w?.payoutAmountUSD ?? 0).toFixed(2)} USD
                    </span>
                  </td>

                  {/* Method & Address */}
                  <td className="p-3.5">
                    <div className="space-y-0.5">
                      <span className="text-white font-medium block">{w.payoutMethod}</span>
                      <span className="text-[10px] font-mono text-neutral-400 truncate max-w-[150px] block">
                        {w.payoutAddress}
                      </span>
                    </div>
                  </td>

                  {/* Status */}
                  <td className="p-3.5">
                    <div className="space-y-1">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        w.status === 'Approved' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                        w.status === 'Pending' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                        'bg-rose-500/20 text-rose-300 border-rose-500/30'
                      }`}>
                        {w.status}
                      </span>
                      <span className="block text-[10px] text-neutral-500 font-mono">
                        {w.requestDate}
                      </span>
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="p-3.5 text-right">
                    {w.status === 'Pending' ? (
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            onApprove(w.id);
                            playSoundFX('notification');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 transition-all"
                        >
                          <Check className="w-3 h-3" />
                          <span>Approve & Pay</span>
                        </button>
                        <button
                          onClick={() => {
                            onReject(w.id);
                            playSoundFX('click');
                          }}
                          className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300"
                          title="Reject Request"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-neutral-500 font-mono">Processed</span>
                    )}
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
