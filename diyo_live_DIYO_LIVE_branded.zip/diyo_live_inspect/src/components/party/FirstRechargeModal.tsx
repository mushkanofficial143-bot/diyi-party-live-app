import React, { useState } from 'react';
import { X, Sparkles, Gift, CheckCircle2, ChevronRight, Zap, Trophy, ShieldCheck } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface FirstRechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimReward: (coins: number, diamonds: number) => void;
  userCoins: number;
}

export const FirstRechargeModal: React.FC<FirstRechargeModalProps> = ({
  isOpen,
  onClose,
  onClaimReward,
  userCoins
}) => {
  const [isClaimed, setIsClaimed] = useState(false);

  if (!isOpen) return null;

  const handleClaim = () => {
    playSoundFX('win');
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
    setIsClaimed(true);
    onClaimReward(50000, 1000);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div
      id="first-recharge-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        id="first-recharge-modal-container"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm bg-gradient-to-b from-[#11311b] via-[#0d2214] to-[#07130a] border-2 border-[#57e32c] rounded-3xl p-5 shadow-[0_0_30px_rgba(87,227,44,0.35)] flex flex-col items-center text-center relative select-none text-white animate-in zoom-in-95 duration-200"
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/50 hover:bg-black/80 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* 3D Green Gift Box with Yellow Ribbon Representation */}
        <div className="relative my-2">
          <div className="w-24 h-24 rounded-2xl bg-gradient-to-tr from-emerald-600 via-green-500 to-lime-400 p-1 border-2 border-yellow-300 shadow-xl shadow-green-950/80 flex items-center justify-center">
            <span className="text-5xl animate-bounce">🎁</span>
          </div>
          <span className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full bg-yellow-400 text-neutral-950 text-[10px] font-black tracking-wider uppercase shadow-md">
            +300% BONUS
          </span>
        </div>

        {/* Title */}
        <h2 className="text-xl font-black tracking-tight text-white mt-1">
          First Recharge Reward
        </h2>
        <p className="text-xs text-lime-300 font-medium mt-1">
          Exclusive New Player Welcome Gift Package!
        </p>

        {/* Reward Tiers */}
        <div className="w-full bg-black/50 border border-lime-500/30 rounded-2xl p-3 my-3.5 space-y-2 text-left">
          <div className="flex items-center justify-between text-xs font-bold text-neutral-200">
            <span className="flex items-center gap-1.5">
              <span className="text-amber-400">🪙</span>
              <span>Extra Test Coins</span>
            </span>
            <span className="text-amber-300 font-mono">+50,000 TC</span>
          </div>

          <div className="flex items-center justify-between text-xs font-bold text-neutral-200 border-t border-white/10 pt-2">
            <span className="flex items-center gap-1.5">
              <span>💎</span>
              <span>Withdrawable Diamonds</span>
            </span>
            <span className="text-cyan-300 font-mono">+1,000 💎</span>
          </div>

          <div className="flex items-center justify-between text-xs font-bold text-neutral-200 border-t border-white/10 pt-2">
            <span className="flex items-center gap-1.5">
              <span>👑</span>
              <span>VIP 1-Day Trial Frame</span>
            </span>
            <span className="text-lime-400 font-mono">UNLOCKED</span>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleClaim}
          disabled={isClaimed}
          className="w-full py-3 rounded-full bg-gradient-to-r from-lime-400 via-green-400 to-emerald-400 hover:from-lime-300 hover:to-emerald-300 text-neutral-950 font-black text-sm tracking-wider uppercase shadow-lg shadow-green-500/40 active:scale-95 transition-all flex items-center justify-center gap-2"
        >
          {isClaimed ? (
            <>
              <CheckCircle2 className="w-4 h-4" />
              <span>REWARD CLAIMED!</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>CLAIM REWARD NOW</span>
            </>
          )}
        </button>

        <p className="text-[10px] text-neutral-400 mt-2 flex items-center gap-1">
          <ShieldCheck className="w-3 h-3 text-lime-400" />
          <span>Available once per account ID</span>
        </p>
      </div>
    </div>
  );
};
