import React, { useState, useEffect, useRef } from 'react';
import { 
  Music, 
  Play, 
  Pause, 
  SkipForward, 
  Volume2, 
  Upload, 
  X, 
  Search, 
  Sparkles, 
  Disc, 
  Radio,
  Flame,
  Mic2
} from 'lucide-react';
import { musicEngine, MusicEngineState } from '../../utils/musicEngine';
import { MusicTrack, DJ_SOUND_EFFECTS } from '../../utils/musicTracks';
import { playSoundFX } from '../../utils/audioSynth';

interface PartyDjMusicModalProps {
  isOpen: boolean;
  onClose: () => void;
  roomTitle?: string;
  onBroadcastSong?: (songName: string) => void;
}

export const PartyDjMusicModal: React.FC<PartyDjMusicModalProps> = ({
  isOpen,
  onClose,
  roomTitle = 'Party Room',
  onBroadcastSong
}) => {
  const [engineState, setEngineState] = useState<MusicEngineState>(musicEngine.getState());
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const unsub = musicEngine.subscribe((s) => setEngineState(s));
    return () => unsub();
  }, []);

  if (!isOpen) return null;

  const current = engineState.currentTrack;

  const handlePlayTrack = (track: MusicTrack) => {
    musicEngine.playTrack(track);
    playSoundFX('click');
    if (onBroadcastSong) {
      onBroadcastSong(track.title);
    }
  };

  const handleTogglePlay = () => {
    musicEngine.togglePlay();
    playSoundFX('click');
  };

  const handleNext = () => {
    musicEngine.nextTrack();
    playSoundFX('click');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      const file = files[0];
      musicEngine.addCustomTrack(file);
      playSoundFX('success');
      if (onBroadcastSong) {
        onBroadcastSong(file.name);
      }
    }
  };

  const filteredTracks = (engineState.playlist || []).filter((track) => {
    const matchesCat = selectedCategory === 'All' || track.category === selectedCategory;
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (track.title || '').toLowerCase().includes(q) ||
      (track.artist || '').toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center shadow-lg">
              <Music className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Party DJ Music Station 🎵</h3>
              <p className="text-[11px] text-neutral-400">Play any song live for {roomTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Active Player Strip */}
        <div className="p-3.5 bg-neutral-950 border-b border-neutral-800/80 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className={`w-10 h-10 rounded-xl overflow-hidden relative flex-shrink-0 ${engineState.isPlaying ? 'ring-2 ring-rose-500' : ''}`}>
              <img
                src={current?.coverUrl || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300'}
                alt={current?.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate">{current?.title || 'No Song Playing'}</p>
              <p className="text-[10px] text-neutral-400 truncate">{current?.artist || 'Select a track below'}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={handleTogglePlay}
              className={`p-2 rounded-xl text-white transition-all active:scale-95 shadow-md ${
                engineState.isPlaying ? 'bg-rose-600' : 'bg-white text-neutral-950 hover:bg-neutral-200'
              }`}
            >
              {engineState.isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>
            <button
              onClick={handleNext}
              className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white transition-all active:scale-95"
            >
              <SkipForward className="w-4 h-4 fill-current" />
            </button>
          </div>
        </div>

        {/* DJ Sound FX Fast Bar */}
        <div className="px-4 py-2 bg-neutral-900 border-b border-neutral-800/60 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider whitespace-nowrap flex items-center gap-1">
            <Mic2 className="w-3 h-3" /> FX:
          </span>
          {DJ_SOUND_EFFECTS.map((fx) => (
            <button
              key={fx.id}
              onClick={() => playSoundFX(fx.sound as any)}
              className="px-2.5 py-1 rounded-lg bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-[11px] font-bold text-neutral-300 hover:text-white whitespace-nowrap transition-all active:scale-95"
            >
              {fx.icon} {fx.name.split(' ')[1]}
            </button>
          ))}
        </div>

        {/* Search & Custom Upload */}
        <div className="p-3 border-b border-neutral-800/60 space-y-2 bg-neutral-900/50">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400" />
              <input
                type="text"
                placeholder="Search Bollywood, Punjabi, LoFi, EDM..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs placeholder:text-neutral-500 focus:outline-none focus:border-rose-500"
              />
            </div>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all active:scale-95 shadow-md shadow-rose-600/30"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Add Song</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>

          {/* Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
            {['All', 'Bollywood', 'Punjabi', 'LoFi', 'EDM', 'Sufi'].map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  playSoundFX('click');
                }}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-rose-600 text-white'
                    : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Scrollable Song List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2 max-h-72">
          {filteredTracks.map((track) => {
            const isThisTrackPlaying = engineState.isPlaying && current?.id === track.id;

            return (
              <div
                key={track.id}
                onClick={() => handlePlayTrack(track)}
                className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  current?.id === track.id
                    ? 'bg-rose-950/40 border-rose-500/60 ring-1 ring-rose-500/30'
                    : 'bg-neutral-950 hover:bg-neutral-850 border-neutral-800/80'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-9 h-9 rounded-lg overflow-hidden flex-shrink-0 relative bg-neutral-800">
                    <img src={track.coverUrl} alt={track.title} className="w-full h-full object-cover" />
                    {isThisTrackPlaying && (
                      <div className="absolute inset-0 bg-rose-600/60 flex items-center justify-center">
                        <Disc className="w-4 h-4 text-white animate-spin" />
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">{track.title}</p>
                    <p className="text-[10px] text-neutral-400 truncate">{track.artist} • {track.category}</p>
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePlayTrack(track);
                  }}
                  className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                    isThisTrackPlaying
                      ? 'bg-rose-600 text-white'
                      : 'bg-neutral-800 hover:bg-rose-600 text-neutral-300 hover:text-white'
                  }`}
                >
                  {isThisTrackPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current ml-0.5" />}
                </button>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between text-xs">
          <span className="text-neutral-400 font-mono text-[11px]">
            {filteredTracks.length} Songs in Jukebox
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-800 text-neutral-300 font-bold hover:bg-neutral-700"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
