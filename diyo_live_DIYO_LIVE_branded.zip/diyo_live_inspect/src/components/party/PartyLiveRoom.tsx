import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Mic,
  MicOff,
  Smile,
  Gift,
  Share2,
  AlertTriangle,
  Power,
  ChevronRight,
  Flame,
  Trophy,
  Shield,
  Sparkles,
  Crown,
  Heart,
  Send,
  MessageSquare,
  Volume2,
  VolumeX,
  Music,
  Users
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';
import { UserAccount, GiftItem } from '../../types/ownerTypes';
import { UserProfileCardModal, UserProfileCardData } from '../profile/UserProfileCardModal';
import { BottomGiftSheet } from '../gifts/BottomGiftSheet';
import { PartyDjMusicModal } from './PartyDjMusicModal';
import { PartyRtcService } from '../../services/partyRtcService';
import { audioDebug, AudioDebugLogEntry } from '../../services/audioDebugService';
import { RankLeaderboardModal } from '../profile/RankLeaderboardModal';

export interface PartySeat {
  seatNumber: number;
  userId?: string;
  userName?: string;
  avatar?: string;
  isOwner?: boolean;
  isMuted?: boolean;
  isSpeaking?: boolean;
  isCameraOn?: boolean;
  isMicOn?: boolean;
  isLocked?: boolean;
  vipLevel?: number;
  userLevel?: number;
  countryFlag?: string;
  diamondsEarned?: number;
  joinedAt?: string;
}

export interface PartyLiveRoomProps {
  currentUser?: UserAccount;
  onClose?: () => void;
  onSendGift?: (gift: GiftItem, recipientUserId: string) => Promise<boolean>;
  onUpdateUserBalance?: (newCoins: number, newDiamonds: number) => void;
}

export const PartyLiveRoom: React.FC<PartyLiveRoomProps> = ({
  currentUser = {
    id: '0000001',
    name: 'SR Angel',
    username: 'sr_angel',
    email: 'sr.angel@srlive.io',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    role: 'SUPER_ADMIN',
    hostTag: 'CELEBRATE',
    vipLevel: 5,
    svipLevel: 2,
    coinBalance: 0,
    diamondBalance: 0,
    boltBalance: 0,
    userLevel: 42,
    followersCount: 12800,
    followingCount: 856,
    countryCode: 'NP',
    countryFlag: '🇳🇵',
    countryName: 'Nepal',
    bio: 'Live • Laugh • Share ❤️',
    totalRechargedUSD: 0,
    totalSpentCoins: 0,
    status: 'ACTIVE',
    deviceType: 'Mobile App',
    registrationDate: '2025-01-10',
    lastLogin: 'Just now'
  },
  onClose,
  onSendGift,
  onUpdateUserBalance
}) => {
  // 10 Seats matching exact requirements: No.1 to No.5 in row 1, No.6 to No.10 in row 2
  const [seats, setSeats] = useState<PartySeat[]>(() => {
    return Array.from({ length: 10 }, (_, i) => {
      const seatNum = i + 1;
      if (seatNum === 1) {
        return {
          seatNumber: 1,
          userId: currentUser.id,
          userName: currentUser.name,
          avatar: currentUser.avatar,
          isOwner: true,
          isMuted: false,
          isSpeaking: true,
          isCameraOn: true,
          isMicOn: true,
          isLocked: false,
          vipLevel: currentUser.vipLevel || 5,
          userLevel: currentUser.userLevel || 42,
          countryFlag: currentUser.countryFlag || '🇳🇵',
          diamondsEarned: 1200
        };
      }
      return {
        seatNumber: seatNum,
        userId: undefined,
        userName: undefined,
        avatar: undefined,
        isOwner: false,
        isMuted: false,
        isSpeaking: false,
        isCameraOn: false,
        isMicOn: false,
        isLocked: false,
        vipLevel: undefined,
        userLevel: undefined,
        countryFlag: undefined,
        diamondsEarned: 0
      };
    });
  });

  const [userCoins, setUserCoins] = useState(currentUser.coinBalance || 0);
  const [userDiamonds, setUserDiamonds] = useState(currentUser.diamondBalance || 0);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isSpeakerMuted, setIsSpeakerMuted] = useState(false);

  // RTC & Audio state
  const [rtcStatus, setRtcStatus] = useState<string>('INITIALIZING');
  const [micPermissionGranted, setMicPermissionGranted] = useState<boolean>(false);
  const localAudioStreamRef = useRef<MediaStream | null>(null);

  // Modals state
  const [showGiftModal, setShowGiftModal] = useState(false);
  const [showDjMusicModal, setShowDjMusicModal] = useState(false);
  const [showAudioDebugModal, setShowAudioDebugModal] = useState(false);
  const [isRankModalOpen, setIsRankModalOpen] = useState(false);
  const [isDailyPrizeModalOpen, setIsDailyPrizeModalOpen] = useState(false);

  const [audioLogs, setAudioLogs] = useState<AudioDebugLogEntry[]>([]);
  const [selectedProfileUser, setSelectedProfileUser] = useState<UserProfileCardData | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // Subscribe to audio debug logs
  useEffect(() => {
    const unsubscribe = audioDebug.subscribe((logs) => {
      setAudioLogs(logs);
    });
    return () => unsubscribe();
  }, []);

  // Chat stream
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ id: string; user: string; text: string; type?: string }>>([
    { id: '1', user: currentUser.name, text: 'entered the royal party lounge 🎉', type: 'entrance' },
    { id: '2', user: 'Ritu Bharti', text: 'entered the room', type: 'entrance' }
  ]);

  // Initialize RTC Channel & Microphone on mount using PartyRtcService
  useEffect(() => {
    console.log('[RTC_INITIALIZED] DIYO LIVE Party Room Channel: sr_party_room_12345');
    setRtcStatus('RTC_JOIN_STARTED');

    const rtcService = PartyRtcService.getInstance();
    rtcService.joinRoom('sr_party_room_12345', currentUser.id, currentUser.name)
      .then((res) => {
        if (res.success) {
          setMicPermissionGranted(true);
          setRtcStatus('RTC_JOIN_SUCCESS');
          console.log('[AUDIO] participant joined: ' + currentUser.name);
        } else {
          setMicPermissionGranted(false);
          setRtcStatus('MIC_PERMISSION_DENIED');
        }
      })
      .catch((err) => {
        console.warn('[MIC_PERMISSION_DENIED]', err);
        setMicPermissionGranted(false);
        setRtcStatus('MIC_PERMISSION_DENIED');
      });

    return () => {
      rtcService.leaveRoom();
      console.log('[RTC_LEAVE] Party Room exited');
    };
  }, [currentUser.id, currentUser.name]);

  // Sync state when currentUser updates
  useEffect(() => {
    setUserCoins(currentUser.coinBalance || 0);
    setUserDiamonds(currentUser.diamondBalance || 0);
  }, [currentUser.coinBalance, currentUser.diamondBalance]);

  const handleSeatClick = async (seat: PartySeat) => {
    playSoundFX('click');
    if (seat.userId) {
      if (seat.userId === currentUser.id && !seat.isOwner) {
        // Option to leave seat
        if (confirm(`Do you want to step down from Seat #${seat.seatNumber}?`)) {
          setSeats((prev) => {
            const next = [...prev];
            next[seat.seatNumber - 1] = {
              seatNumber: seat.seatNumber,
              userId: undefined,
              userName: undefined,
              avatar: undefined,
              isOwner: false,
              isMuted: false,
              isSpeaking: false,
              isCameraOn: false,
              isMicOn: false,
              isLocked: false
            };
            return next;
          });
          playSoundFX('click');
        }
        return;
      }

      setSelectedProfileUser({
        id: seat.userId,
        name: seat.userName || 'SR User',
        avatar: seat.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        gender: 'male',
        countryFlag: seat.countryFlag || '🇳🇵',
        countryCode: 'NP',
        level: seat.userLevel || 24,
        vipLevel: seat.vipLevel || 5,
        roleTag: seat.isOwner ? 'Host' : 'VIP Member',
        followingCount: 31,
        followersCount: 839,
        bio: 'Welcome to DIYO LIVE Royal Lounge! 🌟',
        isFollowing: false,
        seatNumber: seat.seatNumber
      });
      setIsProfileModalOpen(true);
    } else {
      // Sit on empty seat -> Request mic and publish audio
      if (!micPermissionGranted) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          localAudioStreamRef.current = stream;
          setMicPermissionGranted(true);
          console.log('[MIC_PERMISSION_GRANTED] Seat audio enabled');
        } catch (e) {
          alert('⚠️ Microphone permission is required to speak on party seats.');
          return;
        }
      }

      console.log(`[AUDIO_PUBLISH_STARTED] User ${currentUser.id} occupied Seat #${seat.seatNumber}`);
      setSeats((prev) => {
        const next = [...prev];
        const idx = seat.seatNumber - 1;
        next[idx] = {
          seatNumber: seat.seatNumber,
          userId: currentUser.id,
          userName: currentUser.name,
          avatar: currentUser.avatar,
          isOwner: false,
          isMuted: false,
          isSpeaking: true,
          isCameraOn: true,
          isMicOn: true,
          isLocked: false,
          vipLevel: currentUser.vipLevel || 0,
          userLevel: currentUser.userLevel || 1,
          countryFlag: currentUser.countryFlag || '🇳🇵',
          diamondsEarned: 0
        };
        return next;
      });
      playSoundFX('win');
      confetti({ particleCount: 30, spread: 45 });
    }
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setChatMessages((prev) => [
      ...prev,
      { id: Math.random().toString(), user: currentUser.name, text: chatInput.trim(), type: 'chat' }
    ]);
    setChatInput('');
    playSoundFX('click');
  };

  return (
    <div
      id="party-live-room-container"
      className="relative w-full min-h-[92vh] bg-[#0d0915] text-white flex flex-col justify-between overflow-x-hidden font-sans select-none pb-20 sm:pb-6 rounded-2xl border border-purple-900/30 shadow-2xl"
      style={{
        backgroundImage: 'radial-gradient(circle at 50% 15%, #2a1548 0%, #120a22 55%, #06030c 100%)'
      }}
    >
      {/* ========================================================================= */}
      {/* 1. TOP ROOM HEADER & SCREENSHOT UI (Rankings & Daily Prize)                */}
      {/* ========================================================================= */}
      <div className="relative z-20 px-3.5 pt-3 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          
          {/* Left: Host Avatar, Name, 7-Digit DIYO LIVE ID */}
          <div className="flex items-center gap-2.5">
            <div className="relative cursor-pointer" onClick={() => handleSeatClick(seats[0])}>
              <div className="w-10 h-10 rounded-full ring-2 ring-amber-400 p-0.5 bg-gradient-to-tr from-pink-500 via-purple-600 to-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]">
                <img
                  src={currentUser.avatar}
                  alt="Room Host"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 text-neutral-950 flex items-center justify-center text-[9px] font-black border border-neutral-900 shadow">
                👑
              </div>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="text-xs sm:text-sm font-black text-white tracking-tight drop-shadow-md truncate max-w-[100px]">
                  {currentUser.name}
                </span>
                {currentUser.countryFlag && (
                  <span className="text-xs">{currentUser.countryFlag}</span>
                )}
              </div>
              <div className="flex items-center gap-1">
                <span className="text-[10px] text-amber-300 font-mono font-bold">
                  ID: {currentUser.id}
                </span>
                <span className="text-[8px] px-1 rounded bg-purple-900/60 text-purple-200 border border-purple-500/40 font-black">
                  LV.{currentUser.userLevel || 1}
                </span>
              </div>
            </div>

            {/* Online Viewers Count */}
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-600/30 border border-purple-400/40 text-purple-200 text-[10px] font-bold">
              <Users className="w-3 h-3 text-purple-300" />
              <span>128</span>
            </div>
          </div>

          {/* Right Action Icons: DJ Music, Audio Debug, Share, Exit */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                playSoundFX('magic');
                setShowDjMusicModal(true);
              }}
              className="w-8 h-8 rounded-full bg-purple-950/80 border border-purple-500/30 flex items-center justify-center text-purple-300 hover:text-white active:scale-95 transition-all shadow"
              title="Party DJ Music"
            >
              <Music className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                playSoundFX('click');
                setShowAudioDebugModal(true);
              }}
              className="w-8 h-8 rounded-full bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-300 hover:text-white active:scale-95 transition-all shadow"
              title="Audio Debug Pipeline"
            >
              <Mic className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                playSoundFX('click');
                navigator.clipboard?.writeText(window.location.href);
              }}
              className="w-8 h-8 rounded-full bg-black/40 border border-white/15 flex items-center justify-center text-neutral-300 hover:text-white active:scale-95 transition-all shadow"
              title="Share Room"
            >
              <Share2 className="w-4 h-4" />
            </button>

            {onClose && (
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-rose-950/60 border border-rose-500/40 flex items-center justify-center text-rose-300 hover:text-rose-100 active:scale-95 transition-all shadow"
                title="Exit Party Room"
              >
                <Power className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Sub-Header matching exact user screenshot: Rankings button (Left) & Daily Prize (Right) */}
        <div className="flex items-center justify-between px-1">
          <button
            onClick={() => {
              playSoundFX('superchat');
              setIsRankModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/50 text-amber-300 text-xs font-black shadow-md hover:bg-amber-500/30 active:scale-95 transition-all"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Rankings</span>
          </button>

          <button
            onClick={() => {
              playSoundFX('coin');
              setIsDailyPrizeModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-rose-500/20 to-purple-500/20 border border-rose-400/50 text-rose-300 text-xs font-black shadow-md hover:bg-rose-500/30 active:scale-95 transition-all"
          >
            <span className="text-sm">🎁</span>
            <span>Daily Prize</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. 10 MIC SEATS 3D GRID (Row 1: No.1 to No.5 | Row 2: No.6 to No.10)       */}
      {/* ========================================================================= */}
      <div className="relative z-10 my-auto px-3 py-2 space-y-3 max-w-lg mx-auto w-full">
        
        {/* Row 1: No.1 to No.5 */}
        <div className="grid grid-cols-5 gap-2">
          {seats.slice(0, 5).map((seat) => {
            const isOccupied = Boolean(seat.userId);
            const isHost = seat.isOwner || seat.seatNumber === 1;
            return (
              <div
                key={seat.seatNumber}
                onClick={() => handleSeatClick(seat)}
                className="flex flex-col items-center group cursor-pointer active:scale-95 transition-all"
              >
                {/* 3D Circular Platform with Depth & Neon/Gold Rings */}
                <div
                  className={`relative w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                    isHost
                      ? 'bg-gradient-to-tr from-amber-500/20 via-purple-900/40 to-yellow-400/20 border-2 border-amber-400 shadow-[0_0_14px_rgba(245,158,11,0.5)]'
                      : isOccupied
                      ? 'bg-[#181a28]/90 border-2 border-purple-400 shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                      : 'bg-[#121422]/70 border border-white/15 hover:border-amber-400/60 shadow-md'
                  } ${seat.isSpeaking ? 'ring-4 ring-emerald-400 ring-offset-2 ring-offset-[#0d0915] animate-pulse' : ''}`}
                >
                  {isOccupied && seat.avatar ? (
                    <div className="relative w-full h-full rounded-full overflow-hidden p-0.5">
                      <img
                        src={seat.avatar}
                        alt={seat.userName}
                        className="w-full h-full rounded-full object-cover"
                      />
                      {seat.countryFlag && (
                        <span className="absolute top-0 right-0 text-[9px] bg-black/60 rounded-full px-0.5">
                          {seat.countryFlag}
                        </span>
                      )}
                    </div>
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-gradient-to-b from-white/10 to-transparent border border-white/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Mic className="w-3.5 h-3.5 text-purple-300 group-hover:text-amber-300" />
                    </div>
                  )}

                  {isHost && (
                    <div className="absolute -top-1.5 -left-1 text-[10px] bg-amber-400 text-neutral-950 font-black rounded-full px-1 shadow border border-amber-200">
                      👑
                    </div>
                  )}

                  {isOccupied && (
                    <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border border-white flex items-center justify-center text-[7px] text-white">
                      <Mic className="w-2 h-2 fill-current" />
                    </div>
                  )}
                </div>

                {/* Seat Name / Number Label */}
                <div className="mt-0.5 flex flex-col items-center max-w-[62px]">
                  <span className="text-[10px] font-bold text-neutral-200 group-hover:text-amber-300 truncate w-full text-center">
                    {isOccupied ? seat.userName : `NO.${seat.seatNumber}`}
                  </span>
                  {isOccupied && seat.vipLevel && seat.vipLevel > 0 ? (
                    <span className="text-[7px] font-black px-1 rounded bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950">
                      VIP {seat.vipLevel}
                    </span>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>

        {/* Row 2: No.6 to No.10 */}
        <div className="grid grid-cols-5 gap-2">
          {seats.slice(5, 10).map((seat) => {
            const isOccupied = Boolean(seat.userId);
            return (
              <div
                key={seat.seatNumber}
                onClick={() => handleSeatClick(seat)}
                className="flex flex-col items-center group cursor-pointer active:scale-95 transition-all"
              >
                <div
                  className={`relative w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                    isOccupied
                      ? 'bg-[#181a28]/90 border-2 border-purple-400 shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                      : 'bg-[#121422]/70 border border-white/15 hover:border-amber-400/60 shadow-md'
                  } ${seat.isSpeaking ? 'ring-4 ring-emerald-400 ring-offset-2 ring-offset-[#0d0915] animate-pulse' : ''}`}
                >
                  {isOccupied && seat.avatar ? (
                    <div className="relative w-full h-full rounded-full overflow-hidden p-0.5">
                      <img
                        src={seat.avatar}
                        alt={seat.userName}
                        className="w-full h-full rounded-full object-cover"
                      />
                      {seat.countryFlag && (
                        <span className="absolute top-0 right-0 text-[9px] bg-black/60 rounded-full px-0.5">
                          {seat.countryFlag}
                        </span>
                      )}
                    </div>
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-gradient-to-b from-white/10 to-transparent border border-white/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Mic className="w-3.5 h-3.5 text-purple-300 group-hover:text-amber-300" />
                    </div>
                  )}

                  {isOccupied && (
                    <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border border-white flex items-center justify-center text-[7px] text-white">
                      <Mic className="w-2 h-2 fill-current" />
                    </div>
                  )}
                </div>

                <div className="mt-0.5 flex flex-col items-center max-w-[62px]">
                  <span className="text-[10px] font-bold text-neutral-200 group-hover:text-amber-300 truncate w-full text-center">
                    {isOccupied ? seat.userName : `NO.${seat.seatNumber}`}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 3. COMMUNITY GUIDELINES NOTICE BOX (Exact Match to User Screenshot)         */}
      {/* ========================================================================= */}
      <div className="px-3.5 py-1">
        <div className="bg-[#151226]/80 backdrop-blur-md border border-white/10 rounded-2xl p-2.5 text-[10px] text-neutral-300 leading-relaxed shadow-inner">
          <span className="font-bold text-amber-300">Community Guidelines:</span> Please maintain respect. Explicit content, harassment, or inappropriate behavior toward minors is strictly prohibited and will result in an immediate ban. Help us keep this space safe.
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. CHAT STREAM & QUICK AUDIO CONTROLS                                     */}
      {/* ========================================================================= */}
      <div className="relative z-10 px-4 flex items-end justify-between gap-3 mb-1">
        
        {/* Left: Chat stream */}
        <div className="flex-1 space-y-1.5 max-w-[280px]">
          {chatMessages.slice(-3).map((msg) => (
            <div
              key={msg.id}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-xs text-neutral-200 shadow"
            >
              <span className="font-bold text-amber-300">{msg.user}:</span>
              <span className="text-neutral-300 font-normal">{msg.text}</span>
            </div>
          ))}
        </div>

        {/* Right: Floating Mic & Speaker Toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const nextMuted = PartyRtcService.getInstance().toggleMute();
              setIsMicMuted(nextMuted);
              playSoundFX('click');
            }}
            className={`w-9 h-9 rounded-full border flex items-center justify-center shadow-lg active:scale-95 transition-all ${
              isMicMuted
                ? 'bg-rose-950/80 border-rose-500/50 text-rose-300'
                : 'bg-gradient-to-tr from-cyan-500 to-teal-400 border-cyan-300 text-neutral-950 shadow-cyan-500/30'
            }`}
            title={isMicMuted ? 'Unmute Mic' : 'Mute Mic'}
          >
            {isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <button
            onClick={() => {
              setIsSpeakerMuted(!isSpeakerMuted);
              playSoundFX('click');
            }}
            className={`w-9 h-9 rounded-full border flex items-center justify-center shadow-lg active:scale-95 transition-all ${
              isSpeakerMuted
                ? 'bg-neutral-800 border-neutral-600 text-neutral-400'
                : 'bg-[#1b1c28] border-white/20 text-white shadow-purple-900/30'
            }`}
            title={isSpeakerMuted ? 'Turn Sound On' : 'Mute Room Audio'}
          >
            {isSpeakerMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 5. BOTTOM TOOLBAR: Chat Input + Emoji + Gift Button                        */}
      {/* ========================================================================= */}
      <div className="relative z-20 px-3 pt-2.5 pb-2 border-t border-white/10 flex items-center justify-between gap-2 bg-[#090611]/90 backdrop-blur-md">
        
        {/* Chat Input */}
        <form onSubmit={handleSendChat} className="flex-1 flex items-center gap-1.5 bg-black/60 border border-neutral-700/80 rounded-full px-3.5 py-1.5 focus-within:border-amber-400">
          <MessageSquare className="w-3.5 h-3.5 text-neutral-400" />
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Say something nice..."
            className="flex-1 bg-transparent text-xs text-white placeholder-neutral-500 focus:outline-none"
          />
          <button type="submit" className="text-neutral-400 hover:text-amber-400">
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>

        {/* Emoji Button */}
        <button
          onClick={() => {
            setChatMessages((prev) => [
              ...prev,
              { id: Math.random().toString(), user: currentUser.name, text: '🔥❤️🎉', type: 'chat' }
            ]);
            playSoundFX('vote');
          }}
          className="w-9 h-9 rounded-full bg-black/60 border border-neutral-700 flex items-center justify-center text-amber-400 hover:text-white active:scale-95 transition-all shrink-0"
          title="Send Reaction"
        >
          <Smile className="w-4 h-4" />
        </button>

        {/* Gift Button -> Opens Bottom Gift Sheet */}
        <button
          id="party-room-gift-sheet-btn"
          onClick={() => {
            playSoundFX('coin');
            setShowGiftModal(true);
          }}
          className="h-9 px-4 rounded-full bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 text-white flex items-center gap-1.5 font-black text-xs uppercase tracking-wider shadow-lg shadow-pink-600/40 active:scale-95 shrink-0 border border-pink-400/40"
          title="Send Gifts"
        >
          <Gift className="w-4 h-4 text-amber-300 animate-bounce" />
          <span>Send Gift</span>
        </button>

      </div>

      {/* ========================================================================= */}
      {/* 6. MODALS & SHEETS                                                        */}
      {/* ========================================================================= */}

      {/* Global Leaderboard Rankings Modal */}
      <RankLeaderboardModal
        isOpen={isRankModalOpen}
        onClose={() => setIsRankModalOpen(false)}
      />

      {/* Daily Prize Modal */}
      {isDailyPrizeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-sm bg-gradient-to-b from-[#1a1130] to-[#0d0915] border border-amber-500/50 rounded-3xl p-6 text-center shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-3xl mx-auto mb-3 animate-bounce">
              🎁
            </div>
            <h3 className="text-lg font-black text-amber-300">Daily Party Prize Chest</h3>
            <p className="text-xs text-neutral-300 mt-1 mb-5">
              Claim your daily free coins & bonus diamonds for participating in party rooms!
            </p>
            <div className="p-3 rounded-2xl bg-black/40 border border-white/10 mb-5 flex items-center justify-around">
              <div>
                <span className="text-[10px] text-neutral-400 block">Free Reward</span>
                <span className="text-sm font-black text-amber-400">5,000 Coins 🪙</span>
              </div>
              <div className="h-8 w-px bg-white/10" />
              <div>
                <span className="text-[10px] text-neutral-400 block">Bonus</span>
                <span className="text-sm font-black text-cyan-400">100 Diamonds 💎</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  playSoundFX('win');
                  confetti({ particleCount: 50, spread: 60 });
                  alert('🎉 Successfully claimed Daily Party Prize!');
                  setIsDailyPrizeModalOpen(false);
                }}
                className="flex-1 py-2.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 font-black text-xs uppercase shadow-lg shadow-amber-500/30"
              >
                Claim Now
              </button>
              <button
                onClick={() => setIsDailyPrizeModalOpen(false)}
                className="px-4 py-2.5 rounded-full bg-white/10 text-neutral-300 font-bold text-xs hover:bg-white/20"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomGiftSheet
        isOpen={showGiftModal}
        onClose={() => setShowGiftModal(false)}
        initialCoins={userCoins}
        initialDiamonds={userDiamonds}
        senderId={currentUser.id}
        senderName={currentUser.name}
        roomType="PARTY_LIVE"
        onSendSuccess={({ gift, multiplier, newBalance, newDiamonds, diamondsEarned }) => {
          setUserCoins(newBalance);
          const updatedDiamonds = newDiamonds !== undefined ? newDiamonds : (userDiamonds + (diamondsEarned || 0));
          setUserDiamonds(updatedDiamonds);
          if (onUpdateUserBalance) onUpdateUserBalance(newBalance, updatedDiamonds);

          setChatMessages((prev) => [
            ...prev,
            {
              id: Math.random().toString(),
              user: currentUser.name,
              text: `🎁 Sent ${multiplier}x ${gift.name}!`,
              type: 'gift'
            }
          ]);
        }}
      />

      <UserProfileCardModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        user={selectedProfileUser}
        onSendGift={() => setShowGiftModal(true)}
        onSendMessage={(u) => setChatInput(`@${u.name} `)}
      />

      <PartyDjMusicModal
        isOpen={showDjMusicModal}
        onClose={() => setShowDjMusicModal(false)}
        roomTitle="SR Royal Party Live"
        onBroadcastSong={(songTitle) => {
          setChatMessages((prev) => [
            ...prev,
            {
              id: Math.random().toString(),
              user: currentUser.name,
              text: `🎵 Playing track: "${songTitle}"`,
              type: 'system'
            }
          ]);
        }}
      />

      {showAudioDebugModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-lg bg-neutral-900 border border-emerald-500/40 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center justify-center">
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">Audio Pipeline & RTC Diagnostics</h3>
                  <p className="text-[10px] text-neutral-400">Real-time voice communication health check</p>
                </div>
              </div>
              <button 
                onClick={() => setShowAudioDebugModal(false)}
                className="p-1.5 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 text-xs">
              <div className="space-y-2">
                <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-bold">Real-Time Audio States</span>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <span>RTC Connected</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">ACTIVE</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <span>Mic Permission</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black ${micPermissionGranted ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'}`}>
                      {micPermissionGranted ? 'GRANTED' : 'PENDING'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <span>Mic Capturing</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black ${!isMicMuted && micPermissionGranted ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'}`}>
                      {!isMicMuted && micPermissionGranted ? 'ACTIVE' : 'MUTED'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <span>Speaker Playback</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black ${!isSpeakerMuted ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'}`}>
                      {!isSpeakerMuted ? 'PLAYING' : 'MUTED'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-bold">Structured Audio Event Logs</span>
                  <button
                    onClick={() => audioDebug.clearLogs()}
                    className="text-[10px] text-rose-400 hover:underline cursor-pointer"
                  >
                    Clear Logs
                  </button>
                </div>
                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 font-mono text-[10px] space-y-1.5 max-h-48 overflow-y-auto">
                  {audioLogs.map(log => (
                    <div key={log.id} className="flex items-start gap-2 border-b border-neutral-900 pb-1">
                      <span className="text-neutral-500 shrink-0">{log.timestamp.substring(11, 19)}</span>
                      <span className={`px-1 rounded shrink-0 font-bold ${
                        log.category === 'ERROR' ? 'bg-rose-500/20 text-rose-300' :
                        log.category === 'PERMISSION' ? 'bg-blue-500/20 text-blue-300' :
                        log.category === 'PUBLISH' ? 'bg-emerald-500/20 text-emerald-300' :
                        log.category === 'SUBSCRIBE' ? 'bg-purple-500/20 text-purple-300' :
                        'bg-neutral-800 text-neutral-300'
                      }`}>
                        {log.category}
                      </span>
                      <span className="text-neutral-300 break-all">{log.message}</span>
                    </div>
                  ))}
                  {audioLogs.length === 0 && (
                    <div className="text-neutral-500 text-center py-4">No audio logs recorded yet.</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
