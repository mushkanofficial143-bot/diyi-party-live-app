import React from 'react';
import { PartyLiveRoom } from './PartyLiveRoom';
import { UserAccount, GiftItem, PartyLiveRoomSession } from '../../types/ownerTypes';
import { Radio, Zap } from 'lucide-react';

interface PartyLiveScreenProps {
  currentUser?: UserAccount;
  partyLiveRoom?: PartyLiveRoomSession;
  onClose?: () => void;
  onOpenVideoLive?: () => void;
  onStartPartyLive?: () => void;
  onUpdateUserBalance?: (newCoins: number, newDiamonds: number) => void;
  onSendGift?: (gift: GiftItem, recipientUserId: string) => Promise<boolean>;
}

export const PartyLiveScreen: React.FC<PartyLiveScreenProps> = ({
  currentUser,
  partyLiveRoom,
  onClose,
  onOpenVideoLive,
  onStartPartyLive,
  onUpdateUserBalance,
  onSendGift
}) => {
  return (
    <div className="w-full max-w-lg mx-auto pb-4 animate-in fade-in overflow-y-auto overscroll-y-contain [-webkit-overflow-scrolling:touch]">
      <PartyLiveRoom
        currentUser={currentUser}
        partyRoom={partyLiveRoom}
        onClose={onClose}
        onSendGift={onSendGift}
        onUpdateUserBalance={onUpdateUserBalance}
      />
    </div>
  );
};
