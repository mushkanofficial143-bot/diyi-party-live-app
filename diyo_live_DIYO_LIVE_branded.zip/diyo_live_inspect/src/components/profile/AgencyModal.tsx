import React, { useState } from 'react';
import { 
  X, 
  Users, 
  Sparkles, 
  Check, 
  Building2, 
  ShieldCheck, 
  DollarSign, 
  Award, 
  ChevronRight,
  UserCheck,
  TrendingUp,
  Coins,
  Search,
  AlertCircle,
  Clock,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';
import { AgencyAccount, AgencyJoinRequest } from '../../types/ownerTypes';
import { createAuditLog } from '../../utils/rbacGuard';

interface AgencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: any;
  agencies: AgencyAccount[];
  agencyJoinRequests: AgencyJoinRequest[];
  onUpdateAgencyRequests: (reqs: AgencyJoinRequest[]) => void;
  onUpdateUserAgencyMembership: (membership: any) => void;
  onAddAuditLog: (log: any) => void;
  onAddNotification: (notif: any) => void;
}

export const AgencyModal: React.FC<AgencyModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  agencies = [],
  agencyJoinRequests = [],
  onUpdateAgencyRequests,
  onUpdateUserAgencyMembership,
  onAddAuditLog,
  onAddNotification
}) => {
  const [activeTab, setActiveTab] = useState<'VERIFY_JOIN' | 'CREATE' | 'HOST_LIST'>('VERIFY_JOIN');
  const [searchAgencyId, setSearchAgencyId] = useState('');
  const [verifiedAgency, setVerifiedAgency] = useState<AgencyAccount | null>(null);
  const [searchNotFound, setSearchNotFound] = useState(false);
  const [agencyName, setAgencyName] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    playSoundFX('notification');
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleSearchAgency = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchAgencyId.trim()) return;
    playSoundFX('click');

    const q = searchAgencyId.trim().toUpperCase();
    const found = agencies.find(a => a.id.toUpperCase() === q || a.code.toUpperCase() === q || a.name.toUpperCase().includes(q));

    if (found) {
      setVerifiedAgency(found);
      setSearchNotFound(false);
      showToast(`✨ Agency verified successfully: ${found.name}`);
    } else {
      setVerifiedAgency(null);
      setSearchNotFound(true);
      showToast('❌ Agency Not Found. Please check the Agency ID or Power ID.');
    }
  };

  const existingRequestForUser = agencyJoinRequests.find(
    r => r.hostId === currentUser.id && verifiedAgency && r.agencyId === verifiedAgency.id && r.status === 'PENDING'
  );

  const userMembership = currentUser.agencyMembership || { status: 'NONE' };

  const handleSendJoinRequest = () => {
    if (!verifiedAgency) return;

    if (verifiedAgency.status !== 'Active') {
      showToast('❌ Cannot join: This agency is Suspended, Banned, or Deactivated.');
      return;
    }

    if (userMembership.status === 'VERIFIED_JOINED') {
      showToast('⚠️ You are already joined in an approved agency. Leave your current agency first to join a new one.');
      return;
    }

    if (existingRequestForUser) {
      showToast('⚠️ You already have a pending join request for this agency.');
      return;
    }

    playSoundFX('superchat');
    confetti({ particleCount: 40, spread: 60 });

    const newReq: AgencyJoinRequest = {
      id: `AJR-${Math.floor(1000 + Math.random() * 9000)}`,
      hostId: currentUser.id || 'HST-5001',
      hostName: currentUser.name || currentUser.username || 'Host Broadcaster',
      hostAvatar: currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      hostLevel: currentUser.vipLevel || 10,
      hostVipLevel: currentUser.vipLevel || 2,
      agencyId: verifiedAgency.id,
      agencyName: verifiedAgency.name,
      ownerId: verifiedAgency.managerId || 'MGR-301',
      status: 'PENDING',
      requestDate: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC'
    };

    onUpdateAgencyRequests([newReq, ...agencyJoinRequests]);

    onUpdateUserAgencyMembership({
      agencyId: verifiedAgency.id,
      agencyName: verifiedAgency.name,
      status: 'PENDING',
      requestId: newReq.id,
      requestDate: newReq.requestDate
    });

    // Audit Log
    onAddAuditLog(createAuditLog(
      currentUser.id || 'HST-5001',
      currentUser.name || 'Host',
      'HOST',
      'CREATE_AGENCY_JOIN_REQUEST',
      newReq.id,
      'AGENCY',
      'SUCCESS',
      `Host created joining request for agency ${verifiedAgency.name} (${verifiedAgency.id})`
    ));

    // Notification to Agency Owner / Manager
    onAddNotification({
      id: `NTF-${Math.floor(1000 + Math.random() * 9000)}`,
      title: '📥 New Host Joining Request',
      message: `Host ${currentUser.name} (ID: ${currentUser.id}) has requested to join your agency ${verifiedAgency.name}. Review in Owner Panel.`,
      targetAudience: verifiedAgency.managerId || 'OWN-001',
      timestamp: 'Just now',
      readCount: 0,
      sentBy: 'Agency System'
    });

    showToast('🚀 Joining request sent to Agency Owner! Status: PENDING.');
  };

  const handleCreateAgency = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agencyName.trim()) return;
    playSoundFX('superchat');
    confetti({ particleCount: 60, spread: 80 });
    showToast(`Congratulations! Agency "${agencyName.trim()}" created successfully. Your Agency ID is AG-9901.`);
    setAgencyName('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-950 border border-teal-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-500/40 flex items-center justify-center shadow-md">
              <Building2 className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white">Agency Verification & Talent Guild</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-teal-500/20 text-teal-300 border border-teal-500/40">
                  OFFICIAL GUILD
                </span>
              </div>
              <p className="text-xs text-neutral-400">Verify agency credentials, send secure join requests, and unlock earnings</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-teal-500/20 border border-teal-500/50 text-teal-200 text-xs font-bold text-center animate-in zoom-in-95">
            {toastMsg}
          </div>
        )}

        {/* Tab switcher */}
        <div className="p-4 border-b border-neutral-800 flex items-center gap-2">
          {[
            { key: 'VERIFY_JOIN', label: 'Agency Verification & Join' },
            { key: 'CREATE', label: 'Create New Agency' },
            { key: 'HOST_LIST', label: 'Top Guild Ranking' }
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => {
                setActiveTab(tab.key as any);
                playSoundFX('click');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                activeTab === tab.key
                  ? 'bg-teal-500 text-neutral-950 border-teal-400 shadow-md font-black'
                  : 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:bg-neutral-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Body content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {activeTab === 'VERIFY_JOIN' && (
            <div className="space-y-4">
              
              {/* Current Status Box */}
              <div className="p-4 rounded-2xl bg-neutral-950/90 border border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-wider">Your Agency Status</span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase ${
                      userMembership.status === 'VERIFIED_JOINED' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                      userMembership.status === 'PENDING' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                      'bg-neutral-800 text-neutral-400'
                    }`}>
                      {userMembership.status === 'VERIFIED_JOINED' ? 'Verified / Joined' :
                       userMembership.status === 'PENDING' ? 'Request Pending Approval' : 'Not Joined (Independent)'}
                    </span>
                    {userMembership.agencyName && (
                      <span className="text-xs font-bold text-white">({userMembership.agencyName})</span>
                    )}
                  </div>
                </div>
                {userMembership.status === 'VERIFIED_JOINED' && (
                  <button
                    onClick={() => {
                      onUpdateUserAgencyMembership({ status: 'NONE' });
                      showToast('🔓 You have left your agency. You can now join a new one.');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold border border-rose-500/30 cursor-pointer"
                  >
                    Leave Agency
                  </button>
                )}
              </div>

              {/* Search Form */}
              <form onSubmit={handleSearchAgency} className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800 space-y-3">
                <h4 className="text-xs font-bold text-white flex items-center gap-2">
                  <Search className="w-4 h-4 text-teal-400" />
                  <span>Search Agency by Agency ID or Power ID</span>
                </h4>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    required
                    placeholder="e.g., AG-01 or AG-101"
                    value={searchAgencyId}
                    onChange={(e) => setSearchAgencyId(e.target.value)}
                    className="flex-1 px-3.5 py-2.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-teal-400 font-mono"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-neutral-950 font-black text-xs uppercase shadow-md cursor-pointer transition-all"
                  >
                    Verify Agency
                  </button>
                </div>
              </form>

              {/* Not Found State */}
              {searchNotFound && (
                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <div>
                    <span className="font-bold block">Agency Not Found</span>
                    <span className="text-[11px] text-neutral-400">Please check the Agency ID or Power ID and try searching again.</span>
                  </div>
                </div>
              )}

              {/* Verified Agency Details Card */}
              {verifiedAgency && (
                <div className="p-4 rounded-2xl bg-gradient-to-b from-neutral-900 to-neutral-950 border border-teal-500/40 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                    <div className="flex items-center gap-3">
                      <img
                        src={verifiedAgency.logo}
                        alt={verifiedAgency.name}
                        className="w-12 h-12 rounded-2xl object-cover border border-teal-500/40"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <h4 className="font-bold text-white text-sm">{verifiedAgency.name}</h4>
                        <div className="flex items-center gap-2 text-[11px] text-neutral-400">
                          <span className="font-mono text-teal-400 font-bold">{verifiedAgency.id}</span>
                          <span>•</span>
                          <span className="font-mono text-neutral-300">Code: {verifiedAgency.code}</span>
                        </div>
                      </div>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase ${
                      verifiedAgency.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                      'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    }`}>
                      {verifiedAgency.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800">
                      <span className="text-[10px] text-neutral-400 block">Agency Owner / Manager</span>
                      <span className="font-bold text-white">{verifiedAgency.ownerOrManager}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800">
                      <span className="text-[10px] text-neutral-400 block">Commission & Hosts</span>
                      <span className="font-bold text-teal-300">{verifiedAgency.commissionRate}% • {verifiedAgency.numberOfHosts} Hosts</span>
                    </div>
                  </div>

                  {/* Joining Actions */}
                  <div className="pt-2">
                    {verifiedAgency.status !== 'Active' ? (
                      <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs text-center font-bold">
                        ⚠️ This agency is currently Suspended or Banned. Joining is not permitted.
                      </div>
                    ) : userMembership.status === 'VERIFIED_JOINED' ? (
                      <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400 text-xs text-center font-medium">
                        🔒 You are already joined in an approved agency.
                      </div>
                    ) : existingRequestForUser ? (
                      <div className="p-3 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs text-center font-bold flex items-center justify-center gap-2">
                        <Clock className="w-4 h-4 animate-spin" />
                        <span>Joining request pending approval by Agency Owner.</span>
                      </div>
                    ) : (
                      <button
                        onClick={handleSendJoinRequest}
                        className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-teal-950/50 cursor-pointer transition-all flex items-center justify-center gap-2"
                      >
                        <UserCheck className="w-4 h-4" />
                        <span>JOIN AGENCY (Send Request)</span>
                      </button>
                    )}
                  </div>
                </div>
              )}

            </div>
          )}

          {activeTab === 'CREATE' && (
            <form onSubmit={handleCreateAgency} className="space-y-4">
              <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800 space-y-3">
                <h4 className="text-xs font-bold text-white">Agency Guild Name</h4>
                <input
                  type="text"
                  required
                  placeholder="e.g., Galaxy Stars Guild"
                  value={agencyName}
                  onChange={(e) => setAgencyName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-teal-400"
                />
                <div className="grid grid-cols-2 gap-2 text-xs pt-2">
                  <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-center">
                    <span className="text-[10px] text-neutral-400 block">Agent Commission</span>
                    <span className="text-base font-black text-teal-400">Up to 25%</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-center">
                    <span className="text-[10px] text-neutral-400 block">Requirement</span>
                    <span className="text-base font-black text-amber-300">Level 20+</span>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-950/50 cursor-pointer"
              >
                Create Agency Guild
              </button>
            </form>
          )}

          {activeTab === 'HOST_LIST' && (
            <div className="space-y-2.5">
              {agencies.map((g, idx) => (
                <div key={g.id} className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-neutral-800 text-white font-mono font-black text-xs flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <div>
                      <p className="text-xs font-bold text-white flex items-center gap-1">
                        <span>{g.name}</span>
                        <span className="text-[10px] text-teal-400 font-mono">({g.id})</span>
                      </p>
                      <p className="text-[10px] text-neutral-400">{g.numberOfHosts} Active Hosts • {g.ownerOrManager}</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-black text-teal-300">{(g.totalEarningsDiamonds || 0).toLocaleString()} 💎</span>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
