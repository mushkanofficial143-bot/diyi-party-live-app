import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  Crown, 
  ShieldCheck, 
  Check, 
  Lock, 
  Eye, 
  Zap, 
  RotateCcw,
  Layers,
  Award,
  Palette,
  Flame,
  Star,
  Heart,
  Sliders,
  CheckCircle2
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';
import { SRLiveRoleType } from '../frames/SRLiveRoleFrame';
import { MASTER_FRAME_CATALOG } from '../../data/mockFramesData';

export interface FrameOption {
  id: string;
  name: string;
  category: 'ALL' | 'ROLE' | 'VIP' | 'HOST' | 'SPECIAL' | 'CUSTOM';
  rarity: 'Royalty' | 'Legendary' | 'Epic' | 'Rare' | 'Common';
  coinPrice: number;
  vipLevelRequired: number;
  isAnimated: boolean;
  roleType?: SRLiveRoleType;
  hostTag?: string;
  previewUrl?: string;
  description: string;
  badgeLabel?: string;
  customRingStyle?: string;
  glowColor?: string;
}

export const ALL_AVATAR_FRAMES: FrameOption[] = [
  // 1. Official 6-Role Luxury Frames
  {
    id: 'FRM-ROLE-SUPER_ADMIN',
    name: '👑 Super Admin Sovereign Frame',
    category: 'ROLE',
    rarity: 'Royalty',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    roleType: 'SUPER_ADMIN',
    description: '3D Gold-Red Imperial filigree with divine Phoenix wings and DIYO Super Admin crest.',
    badgeLabel: 'SUPER ADMIN'
  },
  {
    id: 'FRM-ROLE-ADMIN',
    name: '🛡️ Admin Cyber Diamond Frame',
    category: 'ROLE',
    rarity: 'Legendary',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    roleType: 'ADMIN',
    description: 'Ultra-luxurious Cyan/Gold cyber shields with Official DIYO Admin nameplate.',
    badgeLabel: 'ADMIN'
  },
  {
    id: 'FRM-ROLE-AGENCY',
    name: '🏢 Agency Emerald Crest Frame',
    category: 'ROLE',
    rarity: 'Legendary',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    roleType: 'AGENCY',
    description: 'Emerald-Gold laurel wreath and corporate crown for verified Talent Agencies.',
    badgeLabel: 'AGENCY'
  },
  {
    id: 'FRM-ROLE-MANAGER',
    name: '💼 Manager Sapphire Halo Frame',
    category: 'ROLE',
    rarity: 'Epic',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    roleType: 'MANAGER',
    description: 'Deep Blue sapphire halo with golden stars for DIYO Room & Guild Managers.',
    badgeLabel: 'MANAGER'
  },
  {
    id: 'FRM-ROLE-COIN_SELLER',
    name: '🪙 Official Coin Seller Frame',
    category: 'ROLE',
    rarity: 'Epic',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    roleType: 'COIN_SELLER',
    description: 'Spinning gold coin aura and diamond merchant ring for verified recharge agents.',
    badgeLabel: 'COIN SELLER'
  },
  {
    id: 'FRM-ROLE-MY_ADD',
    name: '📢 My Add Broadcaster Frame',
    category: 'ROLE',
    rarity: 'Rare',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    roleType: 'MY_ADD',
    description: 'Pulsing neon-amber announcement frame with radar wings for promotional hosts.',
    badgeLabel: 'MY ADD'
  },

  // 2. VIP Nobility Frames (VIP 1 to VIP 10)
  {
    id: 'FRM-VIP-08',
    name: '👑 VIP 8 Sovereign Emperor Crown',
    category: 'VIP',
    rarity: 'Royalty',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    description: 'Triple-tier gold crown with ruby gems and spinning golden starlight halo.',
    badgeLabel: 'VIP 8'
  },
  {
    id: 'FRM-VIP-07',
    name: '💎 VIP 7 Diamond Archduke Frame',
    category: 'VIP',
    rarity: 'Royalty',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    description: 'Sparkling diamond aura with violet laser crown.',
    badgeLabel: 'VIP 7'
  },
  {
    id: 'FRM-VIP-05',
    name: '⭐ VIP 5 Gold Baron Halo',
    category: 'VIP',
    rarity: 'Epic',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    description: 'Spinning golden star crown with luxury amber border.',
    badgeLabel: 'VIP 5'
  },
  {
    id: 'FRM-VIP-01',
    name: '🌟 VIP 1 Starlight Starter Frame',
    category: 'VIP',
    rarity: 'Common',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: false,
    description: 'Polished gold-trimmed starlight ring with subtle shimmer.',
    badgeLabel: 'VIP 1'
  },

  // 3. Special Cyber, Neon, Dragon & Custom Frames
  {
    id: 'FRM-CYBER-NEON',
    name: '⚡ Neon Cyberpunk Matrix',
    category: 'SPECIAL',
    rarity: 'Legendary',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    description: 'Vibrant multi-color pink/cyan/yellow glowing laser ring with pulse waves.',
    badgeLabel: 'CYBER',
    glowColor: 'rgba(6, 182, 212, 0.9)'
  },
  {
    id: 'FRM-FIRE-DRAGON',
    name: '🔥 Inferno Dragon Emperor',
    category: 'SPECIAL',
    rarity: 'Royalty',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    description: 'Blazing dragon wings and swirling golden fire embers orbiting the frame.',
    badgeLabel: 'DRAGON',
    glowColor: 'rgba(249, 115, 22, 0.9)'
  },
  {
    id: 'FRM-GALAXY-NEBULA',
    name: '🌌 Cosmic Galaxy Orbit',
    category: 'SPECIAL',
    rarity: 'Legendary',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    description: 'Deep violet space portal with floating celestial stars and lunar aura.',
    badgeLabel: 'GALAXY',
    glowColor: 'rgba(168, 85, 247, 0.9)'
  },
  {
    id: 'FRM-LOVE-HEART',
    name: '💖 Radiant Angel Wings',
    category: 'SPECIAL',
    rarity: 'Epic',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    description: 'Shimmering pink neon heart with holy feathered wings and glowing halo.',
    badgeLabel: 'ANGEL',
    glowColor: 'rgba(236, 72, 153, 0.9)'
  },
  {
    id: 'FRM-SR-EXCLUSIVE',
    name: '✨ DIYO Golden Prestige',
    category: 'SPECIAL',
    rarity: 'Royalty',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    description: 'Official DIYO flagship border with multi-neon aura and gold top crown.',
    badgeLabel: 'DIYO LIVE',
    glowColor: 'rgba(234, 179, 8, 0.9)'
  },

  // 4. Host Badges & Categories
  {
    id: 'FRM-HT-01',
    name: '🎉 Celebrate Host Frame',
    category: 'HOST',
    rarity: 'Royalty',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    hostTag: 'CELEBRATE',
    description: 'Golden party aura with top crown and celebration confetti sparks.',
    badgeLabel: 'CELEBRATE'
  },
  {
    id: 'FRM-HT-02',
    name: '⭐ Talent Host Cyber Frame',
    category: 'HOST',
    rarity: 'Legendary',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    hostTag: 'TALENT',
    description: 'Neon purple laser aura with pulsing talent stars.',
    badgeLabel: 'TALENT'
  },
  {
    id: 'FRM-HT-03',
    name: '🎤 Singer Melody Frame',
    category: 'HOST',
    rarity: 'Epic',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    hostTag: 'SINGER',
    description: 'Cyan soundwave rings with floating musical notes and mic emblem.',
    badgeLabel: 'SINGER'
  },
  {
    id: 'FRM-HT-04',
    name: '🌟 Normal Verified Frame',
    category: 'HOST',
    rarity: 'Rare',
    coinPrice: 0,
    vipLevelRequired: 1,
    isAnimated: true,
    hostTag: 'NORMAL',
    description: 'Emerald verified broadcaster shield and clean glowing border.',
    badgeLabel: 'NORMAL'
  }
];

interface AvatarFrameSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAvatar: string;
  currentFrameId?: string;
  currentRole?: string;
  currentHostTag?: string;
  vipLevel?: number;
  userCoins?: number;
  onEquipFrame: (frameId: string, frameUrl?: string, roleType?: SRLiveRoleType, hostTag?: string) => void;
  onUnequipFrame: () => void;
}

export const AvatarFrameSelectorModal: React.FC<AvatarFrameSelectorModalProps> = ({
  isOpen,
  onClose,
  currentAvatar,
  currentFrameId = '',
  currentRole = 'SUPER_ADMIN',
  currentHostTag = 'CELEBRATE',
  vipLevel = 8,
  userCoins = 772000,
  onEquipFrame,
  onUnequipFrame
}) => {
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'ROLE' | 'VIP' | 'HOST' | 'SPECIAL' | 'CUSTOM'>('ALL');
  
  // Custom Frame Builder State
  const [customRingColor, setCustomRingColor] = useState('neon-pink-cyan');
  const [customCrown, setCustomCrown] = useState('👑');
  const [customBadgeText, setCustomBadgeText] = useState('TROPHY PARTY');
  const [customAnimation, setCustomAnimation] = useState(true);

  const [selectedFrame, setSelectedFrame] = useState<FrameOption>(() => {
    if (currentFrameId) {
      const found = ALL_AVATAR_FRAMES.find(f => f.id === currentFrameId);
      if (found) return found;
    }
    const roleKey = (currentRole || '').toUpperCase().replace('OWNER', 'SUPER_ADMIN');
    const roleMatch = ALL_AVATAR_FRAMES.find(f => f.roleType && f.roleType.toUpperCase() === roleKey);
    if (roleMatch) return roleMatch;

    return ALL_AVATAR_FRAMES[0];
  });

  const [equippedFrameId, setEquippedFrameId] = useState<string>(currentFrameId || '');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredFrames = ALL_AVATAR_FRAMES.filter(frame => {
    if (activeCategory === 'ALL') return true;
    return frame.category === activeCategory;
  });

  const isCurrentEquipped = (frame: FrameOption) => {
    if (equippedFrameId) {
      return equippedFrameId === frame.id;
    }
    const roleKey = (currentRole || '').toUpperCase().replace('OWNER', 'SUPER_ADMIN');
    if (frame.roleType && frame.roleType.toUpperCase() === roleKey) {
      return true;
    }
    if (frame.hostTag && currentHostTag && frame.hostTag.toUpperCase() === currentHostTag.toUpperCase()) {
      return true;
    }
    return false;
  };

  const handleApplyFrame = (frame: FrameOption) => {
    playSoundFX('superchat');
    setEquippedFrameId(frame.id);
    onEquipFrame(
      frame.id, 
      frame.previewUrl, 
      frame.roleType, 
      frame.hostTag
    );
    setSuccessToast(`Equipped "${frame.name}"!`);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  const handleApplyCustomFrame = () => {
    playSoundFX('superchat');
    const customId = `FRM-CUSTOM-${Date.now()}`;
    setEquippedFrameId(customId);
    onEquipFrame(customId, undefined, undefined, 'CELEBRATE');
    setSuccessToast(`Custom Frame (${customBadgeText}) Created & Equipped!`);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  const handleRemove = () => {
    playSoundFX('click');
    setEquippedFrameId('');
    onUnequipFrame();
    setSuccessToast('Avatar frame removed. Using default profile look.');
    setTimeout(() => setSuccessToast(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-xl animate-in fade-in select-none">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-[#0e1628] via-[#090f1d] to-[#060a15] border border-cyan-500/40 rounded-3xl p-4 sm:p-6 shadow-2xl text-neutral-100 flex flex-col max-h-[92vh] overflow-hidden space-y-4">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-400 via-pink-500 to-amber-400 p-0.5 shadow-lg shadow-cyan-950/40">
              <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center">
                <Crown className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <h2 className="font-['Outfit'] font-black text-lg text-white flex items-center gap-2">
                <span>Avatar Frame Wardrobe & Costumes</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                  FREE TO EQUIP
                </span>
              </h2>
              <p className="text-xs text-neutral-400">Choose and equip any frame of your choice with 1-click</p>
            </div>
          </div>
          <button
            id="btn-close-frame-selector"
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-full bg-neutral-800/80 hover:bg-neutral-700 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Preview Box */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-neutral-900/90 via-[#11192e] to-neutral-900/90 border border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative p-2 rounded-2xl bg-[#070b19] border border-cyan-500/40 shadow-2xl flex items-center justify-center">
              <HostAvatarWithFrame
                avatarUrl={currentAvatar}
                frameId={selectedFrame.id}
                role={selectedFrame.roleType}
                hostTag={selectedFrame.hostTag}
                size="xl"
                isLive={true}
                vipLevel={vipLevel}
              />
            </div>
            <div className="space-y-1 text-left">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {selectedFrame.badgeLabel || selectedFrame.category}
                </span>
                <span className="text-xs font-bold text-cyan-400">
                  {selectedFrame.rarity}
                </span>
                {selectedFrame.isAnimated && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30 font-bold">
                    ✨ Glowing FX
                  </span>
                )}
              </div>
              <h3 className="text-sm font-black text-white">{selectedFrame.name}</h3>
              <p className="text-[11px] text-neutral-400 max-w-sm">{selectedFrame.description}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isCurrentEquipped(selectedFrame) ? (
              <span className="px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-1.5 shadow">
                <Check className="w-4 h-4" />
                <span>Equipped</span>
              </span>
            ) : (
              <button
                id="btn-apply-selected-frame"
                onClick={() => handleApplyFrame(selectedFrame)}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-amber-950/60 transition-all cursor-pointer hover:scale-105 active:scale-95"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Wear This Frame</span>
              </button>
            )}

            {equippedFrameId && (
              <button
                onClick={handleRemove}
                className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-bold transition-all border border-neutral-700 cursor-pointer"
                title="Remove Frame / Default Look"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Success Toast Notification */}
        {successToast && (
          <div className="p-2.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{successToast}</span>
          </div>
        )}

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'ALL', label: 'All Frames', count: ALL_AVATAR_FRAMES.length },
            { id: 'SPECIAL', label: '⚡ Neon & Cyber', count: 5 },
            { id: 'ROLE', label: '👑 Role & Admin', count: 6 },
            { id: 'VIP', label: '💎 VIP Royalty', count: 4 },
            { id: 'HOST', label: '🎤 Host Badges', count: 4 },
            { id: 'CUSTOM', label: '🎨 Custom Builder', count: 'NEW' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                playSoundFX('click');
                setActiveCategory(tab.id as any);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeCategory === tab.id
                  ? 'bg-gradient-to-r from-cyan-400 via-pink-500 to-amber-400 text-neutral-950 shadow-md shadow-cyan-950/40 font-black'
                  : 'bg-neutral-900/90 hover:bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                activeCategory === tab.id ? 'bg-black/30 text-white font-bold' : 'bg-neutral-800 text-neutral-400'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Custom Builder View or Frame Grid */}
        {activeCategory === 'CUSTOM' ? (
          <div className="flex-1 overflow-y-auto pr-1 space-y-4 p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-sm flex items-center gap-1.5">
                <Palette className="w-4 h-4 text-cyan-400" />
                <span>Create Your Own Personalized Frame (Apna Marzi Ka Frame)</span>
              </h3>
            </div>

            {/* Color Theme Selector */}
            <div className="space-y-1.5">
              <span className="text-neutral-400 font-bold block">1. Choose Glow Ring Style:</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'neon-pink-cyan', label: '💖 Neon Pink & Cyan', style: 'border-pink-500 shadow-pink-500/50' },
                  { id: 'royal-gold', label: '👑 Imperial Royal Gold', style: 'border-amber-400 shadow-amber-400/50' },
                  { id: 'fire-ember', label: '🔥 Blazing Fire Ember', style: 'border-orange-500 shadow-orange-500/50' },
                  { id: 'cosmic-purple', label: '🌌 Cosmic Purple Galaxy', style: 'border-purple-500 shadow-purple-500/50' },
                  { id: 'emerald-matrix', label: '💎 Emerald Cyber Matrix', style: 'border-emerald-400 shadow-emerald-400/50' },
                  { id: 'rainbow-flash', label: '🌈 Rainbow Multi-Glow', style: 'border-cyan-400 shadow-cyan-400/50' },
                ].map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      playSoundFX('click');
                      setCustomRingColor(c.id);
                    }}
                    className={`p-2 rounded-xl border text-[11px] font-bold text-left transition-all cursor-pointer flex items-center justify-between ${
                      customRingColor === c.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-white shadow'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span>{c.label}</span>
                    {customRingColor === c.id && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Top Crown Emblem */}
            <div className="space-y-1.5">
              <span className="text-neutral-400 font-bold block">2. Select Top Crest / Crown Emblem:</span>
              <div className="flex items-center gap-2">
                {['👑', '💎', '🔥', '⭐', '⚡', '🌸', '🛡️', '💖'].map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      playSoundFX('click');
                      setCustomCrown(emoji);
                    }}
                    className={`w-10 h-10 rounded-xl text-xl flex items-center justify-center border transition-all cursor-pointer ${
                      customCrown === emoji
                        ? 'bg-amber-500/20 border-amber-400 shadow-md scale-110'
                        : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Bottom Plaque Text */}
            <div className="space-y-1.5">
              <span className="text-neutral-400 font-bold block">3. Bottom Nameplate Badge:</span>
              <div className="flex items-center gap-2">
                {['TROPHY PARTY', 'VIP 8', 'ROYAL', 'KING', 'QUEEN', 'SUPER HOST', 'ADMIN'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => {
                      playSoundFX('click');
                      setCustomBadgeText(tag);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-mono text-[11px] font-bold border transition-all cursor-pointer ${
                      customBadgeText === tag
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 border-amber-400 font-black'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Apply Custom Frame Button */}
            <div className="pt-2">
              <button
                onClick={handleApplyCustomFrame}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-400 via-pink-500 to-amber-400 hover:opacity-90 text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-cyan-950/40 cursor-pointer active:scale-98 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Equip This Custom Frame to Profile Now</span>
              </button>
            </div>

          </div>
        ) : (
          <div className="flex-1 overflow-y-auto pr-1">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {filteredFrames.map((frame) => {
                const isSelected = selectedFrame.id === frame.id;
                const isEquipped = isCurrentEquipped(frame);

                return (
                  <div
                    key={frame.id}
                    onClick={() => {
                      playSoundFX('click');
                      setSelectedFrame(frame);
                    }}
                    className={`relative p-3 rounded-2xl border transition-all cursor-pointer flex flex-col items-center justify-between text-center space-y-2 group ${
                      isSelected
                        ? 'bg-cyan-500/10 border-cyan-400 shadow-lg shadow-cyan-950/50 ring-2 ring-cyan-500/40'
                        : isEquipped
                        ? 'bg-emerald-500/10 border-emerald-500/60'
                        : 'bg-neutral-900/80 hover:bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    {/* Equipped Ribbon */}
                    {isEquipped && (
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-emerald-500 text-neutral-950 text-[9px] font-black uppercase tracking-wider z-20 shadow">
                        EQUIPPED
                      </span>
                    )}

                    {/* Frame Category Pill */}
                    <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded-md bg-black/70 text-cyan-300 text-[9px] font-mono font-bold z-20">
                      {frame.badgeLabel || frame.rarity}
                    </span>

                    {/* Visual Frame Avatar Display */}
                    <div className="pt-4 pb-2 flex items-center justify-center">
                      <HostAvatarWithFrame
                        avatarUrl={currentAvatar}
                        frameId={frame.id}
                        role={frame.roleType}
                        hostTag={frame.hostTag}
                        size="lg"
                        isLive={false}
                        vipLevel={vipLevel}
                      />
                    </div>

                    {/* Name & Quick Details */}
                    <div className="space-y-0.5 w-full">
                      <h4 className="text-xs font-black text-white truncate px-1">{frame.name}</h4>
                      <p className="text-[10px] text-neutral-400 truncate">{frame.rarity} • {frame.isAnimated ? '✨ Animated' : 'Static'}</p>
                    </div>

                    {/* Button inside card */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleApplyFrame(frame);
                      }}
                      className={`w-full py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                        isEquipped
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : isSelected
                          ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-neutral-950 font-black shadow-md'
                          : 'bg-neutral-800 group-hover:bg-neutral-700 text-neutral-300 group-hover:text-white'
                      }`}
                    >
                      {isEquipped ? (
                        <>
                          <Check className="w-3 h-3" />
                          <span>Equipped</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3 h-3 text-amber-400" />
                          <span>Equip Frame</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-neutral-800 text-xs text-neutral-400">
          <span>Frames automatically sync across Live Stream, Audio Party & Profile.</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};

