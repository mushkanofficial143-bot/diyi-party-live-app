import React from 'react';
import { X, Briefcase, Package, Sparkles, Gem, Gift, ShieldAlert } from 'lucide-react';

interface BagModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BagModal: React.FC<BagModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const bagItems = [
    { id: 'b1', name: 'Lucky Treasure Chest', count: 3, icon: '🎁', desc: 'Can be sent in live rooms with 500x multiplier potential' },
    { id: 'b2', name: 'VIP 7-Day Trial Pass', count: 1, icon: '👑', desc: 'Grants temporary VIP level 5 sovereign perks' },
    { id: 'b3', name: 'EXP 2X Booster Card', count: 5, icon: '⚡', desc: 'Doubles all user level experience earned for 1 hour' },
    { id: 'b4', name: 'Golden Room Entrance Bugatti', count: 1, icon: '🏎️', desc: 'Equipped luxury entrance vehicle (28 days left)' },
    { id: 'b5', name: 'Voice Room Fireworks', count: 12, icon: '🎆', desc: 'Fullscreen celebration burst for audio lounges' },
    { id: 'b6', name: 'Superstar Chat Glow', count: 2, icon: '✨', desc: 'Highlights text messages in crowded live chats' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-emerald-500/30 rounded-3xl w-full max-w-xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl shadow-emerald-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-emerald-900/30">
              <Briefcase className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                MY BAG & INVENTORY
              </h2>
              <p className="text-xs text-neutral-400">Stored Gifts, Booster Cards & Special Assets</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {bagItems.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-start gap-3 relative overflow-hidden group hover:border-emerald-500/40 transition-all"
              >
                <div className="w-12 h-12 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center text-2xl flex-shrink-0 shadow-inner">
                  {item.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white">{item.name}</h4>
                    <span className="text-[11px] font-black text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                      x{item.count}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3.5 rounded-2xl bg-neutral-900/50 border border-neutral-800 text-center text-xs text-neutral-400">
            💡 Items won from Lucky Gifts, Mission Rewards, and VIP Tier Upgrades are stored automatically here.
          </div>
        </div>

      </div>
    </div>
  );
};
