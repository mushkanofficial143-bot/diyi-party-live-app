import React, { useState } from 'react';
import { X, Headphones, Send, MessageSquare, Mail, Globe, CheckCircle2, ShieldCheck } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  const [topic, setTopic] = useState('Account / VIP');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    setSent(true);
    playSoundFX('click');
    setTimeout(() => {
      setSent(false);
      setMessage('');
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-emerald-500/30 rounded-3xl w-full max-w-lg max-h-[85vh] overflow-hidden flex flex-col shadow-2xl shadow-emerald-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg">
              <Headphones className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                CONTACT US & 24/7 SUPPORT
              </h2>
              <p className="text-xs text-neutral-400">DIYO LIVE Official Help Desk & VIP Concierge</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          
          {sent ? (
            <div className="py-12 text-center space-y-3 animate-in fade-in">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-base font-black text-white">Ticket Submitted Successfully!</h3>
              <p className="text-xs text-neutral-400 max-w-xs mx-auto">Our 24/7 live team will respond directly to your Message inbox shortly.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300">Inquiry Category</label>
                <select
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-semibold focus:outline-none focus:border-emerald-500"
                >
                  <option value="Account / VIP">Account / VIP & Nobility</option>
                  <option value="Host Verification">Host Application & Agency</option>
                  <option value="Wallet / Recharge">Wallet & Test Coins Inquiry</option>
                  <option value="Game & Lucky Gifts">Game & Lucky Gifts Rule</option>
                  <option value="Security / Report">Bug Report & Security</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300">Message Details</label>
                <textarea
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe your question or feedback in detail..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs placeholder:text-neutral-600 focus:outline-none focus:border-emerald-500 resize-none"
                  required
                />
              </div>

              <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-1.5 text-[11px] text-neutral-400">
                <div className="flex items-center justify-between">
                  <span>Official Email: <strong className="text-emerald-300">srliveindia@gmail.com</strong></span>
                  <a href="mailto:srliveindia@gmail.com" className="text-xs text-emerald-400 font-bold hover:underline">Send Email</a>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-neutral-800">
                  <span>WhatsApp Support: <strong className="text-emerald-300">+91 9714475750</strong></span>
                  <a href="https://wa.me/919714475750" target="_blank" rel="noreferrer" className="text-xs text-emerald-400 font-bold hover:underline">Chat on WhatsApp</a>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50"
              >
                <Send className="w-4 h-4" />
                <span>Submit Ticket</span>
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
