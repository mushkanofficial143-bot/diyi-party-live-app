import React from 'react';
import { X, Heart, Sparkles, Flame, Shield, Award } from 'lucide-react';

interface CpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CpModal: React.FC<CpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-rose-500/30 rounded-3xl w-full max-w-xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl shadow-rose-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-400 flex items-center justify-center text-white shadow-lg">
              <Heart className="w-5 h-5 text-white fill-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                CP SWEETHEART SPACE
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 uppercase font-mono">
                  Couple System
                </span>
              </h2>
              <p className="text-xs text-neutral-400">CP Level, Intimacy Value & Exclusive Rings</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          
          {/* CP Status Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-rose-950/50 via-neutral-900 to-amber-950/40 border border-rose-500/40 text-center space-y-4">
            <div className="flex items-center justify-center gap-4">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"
                  alt="You"
                  className="w-16 h-16 rounded-full object-cover border-2 border-rose-500 shadow-md"
                />
                <span className="absolute -bottom-1 -right-1 text-xs">👑</span>
              </div>

              <div className="flex flex-col items-center">
                <div className="w-10 h-10 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center">
                  <Heart className="w-5 h-5 text-rose-500 fill-rose-500 animate-pulse" />
                </div>
                <span className="text-[10px] text-rose-400 font-mono font-bold mt-1">CP Level 5</span>
              </div>

              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                  alt="DJ Anya"
                  className="w-16 h-16 rounded-full object-cover border-2 border-rose-500 shadow-md"
                />
                <span className="absolute -bottom-1 -right-1 text-xs">💖</span>
              </div>
            </div>

            <div>
              <h3 className="text-base font-black text-white">Aarav & DJ Anya</h3>
              <p className="text-xs text-rose-300 font-mono mt-0.5">Intimacy: 145,000 / 200,000 Points</p>
              <div className="w-48 h-1.5 bg-neutral-800 rounded-full mx-auto mt-2 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-rose-500 to-amber-400 w-[72%]" />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider block">CP Privileges</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-3 rounded-xl bg-neutral-900/80 border border-neutral-800 text-neutral-300 flex items-center gap-2">
                <span>💍 Exclusive Diamond Ring Badge</span>
              </div>
              <div className="p-3 rounded-xl bg-neutral-900/80 border border-neutral-800 text-neutral-300 flex items-center gap-2">
                <span>✨ Joint Entrance Animation Banner</span>
              </div>
              <div className="p-3 rounded-xl bg-neutral-900/80 border border-neutral-800 text-neutral-300 flex items-center gap-2">
                <span>💬 Couple Chat Bubble & Aura</span>
              </div>
              <div className="p-3 rounded-xl bg-neutral-900/80 border border-neutral-800 text-neutral-300 flex items-center gap-2">
                <span>🏆 CP Top Lover Weekly Leaderboard</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
