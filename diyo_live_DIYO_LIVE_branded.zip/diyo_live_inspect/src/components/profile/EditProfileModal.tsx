import React, { useState, useRef } from 'react';
import { X, Camera, Save, User, FileText, CheckCircle2, Image as ImageIcon, Upload, Loader2, Calendar, Globe, Phone, Mail } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: {
    name: string;
    username: string;
    avatar: string;
    bio?: string;
    gender?: 'Male' | 'Female' | 'Other';
    dob?: string;
    countryName?: string;
    countryFlag?: string;
    phone?: string;
    email?: string;
    profileTag?: string;
  };
  onSaveProfile?: (updated: {
    name: string;
    username: string;
    avatar: string;
    bio?: string;
    gender?: 'Male' | 'Female' | 'Other';
    dob?: string;
    countryName?: string;
    countryFlag?: string;
    phone?: string;
    profileTag?: string;
  }) => void;
  onSave?: (updated: {
    name: string;
    username: string;
    avatar: string;
    bio?: string;
    gender?: 'Male' | 'Female' | 'Other';
    dob?: string;
    countryName?: string;
    countryFlag?: string;
    phone?: string;
    profileTag?: string;
  }) => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSaveProfile,
  onSave
}) => {
  const [name, setName] = useState(currentUser.name || '');
  const [username, setUsername] = useState(currentUser.username || '');
  const [avatar, setAvatar] = useState(currentUser.avatar || '');
  const [bio, setBio] = useState(currentUser.bio || 'Live • Laugh • Share ❤️');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>(currentUser.gender || 'Male');
  const [dob, setDob] = useState(currentUser.dob || '2004-05-12');
  const [countryName, setCountryName] = useState(currentUser.countryName || 'India');
  const [countryFlag, setCountryFlag] = useState(currentUser.countryFlag || '🇮🇳');
  const [phone, setPhone] = useState(currentUser.phone || '+91 9876543210');
  const [email] = useState(currentUser.email || 'user@trophyparty.live');
  const [profileTag, setProfileTag] = useState(currentUser.profileTag || 'TROPHY VIP');

  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const countryOptions = [
    { name: 'India', flag: '🇮🇳', code: 'IN' },
    { name: 'United States', flag: '🇺🇸', code: 'US' },
    { name: 'United Arab Emirates', flag: '🇦🇪', code: 'AE' },
    { name: 'United Kingdom', flag: '🇬🇧', code: 'GB' },
    { name: 'Malaysia', flag: '🇲🇾', code: 'MY' },
    { name: 'Canada', flag: '🇨🇦', code: 'CA' },
    { name: 'Australia', flag: '🇦🇺', code: 'AU' },
    { name: 'Saudi Arabia', flag: '🇸🇦', code: 'SA' },
    { name: 'Bangladesh', flag: '🇧🇩', code: 'BD' },
    { name: 'Pakistan', flag: '🇵🇰', code: 'PK' },
  ];

  const sampleAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80'
  ];

  const handleGalleryFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file (JPG, PNG, WEBP)');
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const result = uploadEvent.target?.result as string;
      if (result) {
        setAvatar(result);
        playSoundFX('win');
      }
      setIsUploading(false);
    };
    reader.onerror = () => {
      setIsUploading(false);
      alert('Failed to read image file');
    };
    reader.readAsDataURL(file);
  };

  const handleTriggerFileInput = () => {
    playSoundFX('click');
    fileInputRef.current?.click();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    playSoundFX('click');

    const selectedC = countryOptions.find(c => c.name === countryName) || { flag: countryFlag, code: 'IN' };

    setTimeout(() => {
      const updatedData = {
        name,
        username,
        avatar,
        bio,
        gender,
        dob,
        countryName,
        countryFlag: selectedC.flag,
        phone,
        profileTag
      };

      if (onSave) onSave(updatedData);
      if (onSaveProfile) onSaveProfile(updatedData);

      setIsSaving(false);
      setSaved(true);
      playSoundFX('win');

      setTimeout(() => {
        setSaved(false);
        onClose();
      }, 900);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-[#0e1635] via-[#091026] to-[#060a19] border border-cyan-500/40 rounded-3xl w-full max-w-lg max-h-[92vh] overflow-hidden flex flex-col shadow-2xl shadow-cyan-950/60">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-cyan-900/40 flex items-center justify-between bg-[#0a1430]/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/30">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-white font-['Outfit'] tracking-wide">EDIT TROPHY PROFILE</h2>
              <p className="text-xs text-cyan-200/70">Update photo, nickname, bio & details</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          
          {saved && (
            <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in shadow-lg">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Profile updated and successfully saved to DIYO LIVE!</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Gallery Upload Section */}
            <div className="p-4 rounded-2xl bg-[#070e24]/80 border border-cyan-500/30 text-center space-y-3 shadow-inner">
              <div className="relative inline-block">
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full p-1 bg-gradient-to-tr from-cyan-400 via-blue-500 to-amber-400 shadow-[0_0_20px_rgba(6,182,212,0.6)] mx-auto">
                  <img
                    src={avatar}
                    alt="Avatar Preview"
                    className="w-full h-full rounded-full object-cover border-2 border-[#071330]"
                  />
                </div>
                
                {/* Hidden File Input for Device Gallery */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleGalleryFileSelect}
                  accept="image/*"
                  className="hidden"
                />
                
                {/* Camera Overlay */}
                <button
                  type="button"
                  onClick={handleTriggerFileInput}
                  className="absolute bottom-0 right-0 p-2 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-neutral-950 shadow-lg border-2 border-white cursor-pointer transition-transform active:scale-95"
                  title="Choose image from device gallery"
                >
                  <Camera className="w-4 h-4 stroke-[2.5]" />
                </button>
              </div>

              <div>
                <button
                  type="button"
                  onClick={handleTriggerFileInput}
                  disabled={isUploading}
                  className="px-4 py-2 rounded-full bg-gradient-to-r from-cyan-500 via-teal-400 to-blue-500 text-neutral-950 text-xs font-black flex items-center justify-center gap-2 mx-auto shadow-md shadow-cyan-950/60 hover:brightness-110 active:scale-95 transition-all cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isUploading ? 'Loading Photo...' : '📁 Gallery se Photo Lagayein'}</span>
                </button>
                <p className="text-[10px] text-cyan-200/60 mt-1 font-medium">Select photo from your phone gallery or computer</p>
              </div>
              
              {/* Preset Sample Avatars */}
              <div className="pt-2 border-t border-cyan-900/30">
                <span className="text-[10px] text-neutral-400 block mb-1.5 font-bold uppercase tracking-wider">Or choose preset avatar</span>
                <div className="flex items-center justify-center gap-2 flex-wrap">
                  {sampleAvatars.map((sAv, i) => (
                    <img
                      key={i}
                      src={sAv}
                      alt="Preset"
                      onClick={() => {
                        setAvatar(sAv);
                        playSoundFX('click');
                      }}
                      className={`w-9 h-9 rounded-full object-cover cursor-pointer border transition-all ${
                        avatar === sAv ? 'border-cyan-400 scale-110 ring-2 ring-cyan-400/50 shadow-md shadow-cyan-500/40' : 'border-neutral-700 hover:border-white opacity-80 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Name / Nickname */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-neutral-300">Display Nickname</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#091026] border border-cyan-900/50 text-white text-xs font-bold focus:outline-none focus:border-cyan-400"
                required
              />
            </div>

            {/* Username Handle */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-neutral-300">Username Handle</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#091026] border border-cyan-900/50 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                required
              />
            </div>

            {/* Bio / Signature */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-neutral-300">Personal Signature / Bio</label>
              <textarea
                rows={2}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#091026] border border-cyan-900/50 text-white text-xs focus:outline-none focus:border-cyan-400 resize-none"
              />
            </div>

            {/* Gender & DOB Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as 'Male' | 'Female' | 'Other')}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#091026] border border-cyan-900/50 text-white text-xs font-bold focus:outline-none focus:border-cyan-400"
                >
                  <option value="Male">Male ♂</option>
                  <option value="Female">Female ♀</option>
                  <option value="Other">Other ⚧</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-cyan-400" />
                  <span>Date of Birth</span>
                </label>
                <input
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#091026] border border-cyan-900/50 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            {/* Country Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-neutral-300 flex items-center gap-1">
                <Globe className="w-3 h-3 text-emerald-400" />
                <span>Country / Region</span>
              </label>
              <select
                value={countryName}
                onChange={(e) => setCountryName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#091026] border border-cyan-900/50 text-white text-xs font-bold focus:outline-none focus:border-cyan-400"
              >
                {countryOptions.map((c) => (
                  <option key={c.name} value={c.name}>
                    {c.flag} {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Mobile Number & Email */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-amber-400" />
                  <span>Mobile Number</span>
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#091026] border border-cyan-900/50 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300 flex items-center gap-1">
                  <Mail className="w-3 h-3 text-purple-400" />
                  <span>Email (Secure)</span>
                </label>
                <input
                  type="email"
                  value={email}
                  disabled
                  className="w-full px-3 py-2 rounded-xl bg-[#091026]/50 border border-cyan-900/30 text-neutral-400 text-xs font-mono cursor-not-allowed"
                  title="Secured Account Email (Read-only)"
                />
              </div>
            </div>

            {/* Save Button */}
            <button
              type="submit"
              disabled={isSaving}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/60 cursor-pointer active:scale-98 disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Saving Profile...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Save Changes & Update Profile</span>
                </>
              )}
            </button>
          </form>

        </div>

      </div>
    </div>
  );
};
