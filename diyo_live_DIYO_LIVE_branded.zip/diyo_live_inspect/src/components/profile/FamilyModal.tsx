import React, { useState } from 'react';
import { X, Users, Crown, Sparkles, Shield, Trophy, CheckCircle2, Award } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface FamilyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FamilyModal: React.FC<FamilyModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'myFamily' | 'rankings'>('myFamily');

  if (!isOpen) return null;

  const familyMembers = [
    { name: 'Aarav Mehta (You)', role: 'Patriarch / Leader', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80', contribution: '420,000 EXP' },
    { name: 'DJ Anya', role: 'Elder / Host Star', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', contribution: '350,000 EXP' },
    { name: 'Ananya Gupta', role: 'Elite Guard', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', contribution: '180,000 EXP' },
    { name: 'Rishi Kapoor', role: 'Member', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80', contribution: '95,000 EXP' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-emerald-500/30 rounded-3xl w-full max-w-xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl shadow-emerald-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-amber-500 flex items-center justify-center text-white shadow-lg">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                SR FAMILY GUILD
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase font-mono">
                  Level 8 Guild
                </span>
              </h2>
              <p className="text-xs text-neutral-400">Starlight Dynasty • Family Ranking #1</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Family Banner Card */}
        <div className="p-5 bg-gradient-to-r from-emerald-950/40 via-neutral-900 to-amber-950/30 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center text-2xl shadow-md">
              👑
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Starlight Dynasty</h3>
              <p className="text-[11px] text-neutral-400">Members: 48/50 • Guild EXP: 1,450,000</p>
            </div>
          </div>
          <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
            Top #1 Family
          </span>
        </div>

        {/* Member List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider block">Family Roster</span>
          <div className="space-y-2">
            {familyMembers.map((m, idx) => (
              <div key={idx} className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <img src={m.avatar} alt={m.name} className="w-9 h-9 rounded-xl object-cover border border-neutral-700" />
                  <div>
                    <p className="font-bold text-white">{m.name}</p>
                    <p className="text-[10px] text-emerald-400">{m.role}</p>
                  </div>
                </div>
                <span className="font-mono text-[11px] text-yellow-400 font-bold">{m.contribution}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
