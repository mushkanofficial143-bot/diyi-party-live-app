import React from 'react';
import { X, Heart, Users, Sparkles, Star, Award } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface FanClubModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName?: string;
}

export const FanClubModal: React.FC<FanClubModalProps> = ({
  isOpen,
  onClose,
  userName = 'SR RITU'
}) => {
  if (!isOpen) return null;

  const clubMembers = [
    { name: '💖 Priya_Star', badge: 'Lv.12 RituFan', intimacy: 124000, rank: 1, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' },
    { name: '🔥 Tiger_SR', badge: 'Lv.9 RituFan', intimacy: 78500, rank: 2, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
    { name: '🌟 Sunny_G', badge: 'Lv.6 RituFan', intimacy: 45000, rank: 3, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in select-none">
      <div className="bg-white text-neutral-900 border border-neutral-200 rounded-3xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between bg-gradient-to-r from-pink-50 via-rose-50 to-amber-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-pink-500 text-white flex items-center justify-center shadow-md">
              <Heart className="w-5 h-5 fill-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-neutral-900">{userName}'s Fan Club</h2>
              <p className="text-[11px] text-pink-600 font-bold">1,262 Active Club Members</p>
            </div>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Club Perks Banner */}
        <div className="p-4 bg-gradient-to-r from-pink-500 to-rose-500 text-white m-3.5 rounded-2xl shadow-md space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black uppercase tracking-wider">Fan Club Badge Privileges</span>
            <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold">Exclusive</span>
          </div>
          <p className="text-xs text-pink-100 leading-snug">
            Equip custom club chat badges, send club-exclusive gifts, and get highlighted entry effects!
          </p>
        </div>

        {/* Members Leaderboard */}
        <div className="p-4 overflow-y-auto space-y-2.5 flex-1">
          <h3 className="text-xs font-black text-neutral-500 uppercase tracking-wider">Top Intimacy Contributors</h3>
          {clubMembers.map(m => (
            <div key={m.name} className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className={`w-5 text-center font-black text-sm ${m.rank === 1 ? 'text-amber-500' : m.rank === 2 ? 'text-slate-400' : 'text-amber-700'}`}>
                  {m.rank}
                </span>
                <img src={m.avatar} alt={m.name} className="w-10 h-10 rounded-full object-cover ring-2 ring-pink-300" />
                <div>
                  <span className="text-xs font-bold text-neutral-900">{m.name}</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-pink-100 text-pink-800">{m.badge}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-mono font-bold text-pink-600">💖 {m.intimacy.toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
