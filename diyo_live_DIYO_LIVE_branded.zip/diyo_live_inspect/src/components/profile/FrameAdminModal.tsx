import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  Edit3, 
  Save, 
  TrendingUp, 
  Gift, 
  ShoppingBag, 
  Layers, 
  Check, 
  AlertCircle,
  Sparkles,
  Sliders,
  DollarSign,
  Crown
} from 'lucide-react';
import { FrameItem, FrameCategory, FrameDurationType, FrameAnalyticsSummary } from '../../types/frameTypes';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';
import { playSoundFX } from '../../utils/audioSynth';

interface FrameAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  frames: FrameItem[];
  onSaveFrame: (frame: FrameItem) => void;
  onDeleteFrame: (frameId: string) => void;
  onToggleFrameStatus: (frameId: string) => void;
  currentUserRole?: string;
}

const CATEGORIES: FrameCategory[] = [
  'FREE',
  'NEW',
  'HOT',
  'PREMIUM',
  'VIP',
  'LOVE',
  'ROYAL',
  'FIRE',
  'FLOWER',
  'COUNTRY',
  'HOST',
  'EVENT',
  'LIMITED',
  'ACHIEVEMENT'
];

export const FrameAdminModal: React.FC<FrameAdminModalProps> = ({
  isOpen,
  onClose,
  frames,
  onSaveFrame,
  onDeleteFrame,
  onToggleFrameStatus,
  currentUserRole = 'SUPER_ADMIN'
}) => {
  const [activeTab, setActiveTab] = useState<'catalog' | 'create_edit' | 'analytics'>('catalog');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [editingFrame, setEditingFrame] = useState<FrameItem | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<FrameItem>>({
    id: `FRM-CUSTOM-${Date.now().toString().slice(-4)}`,
    name: '',
    category: 'HOT',
    rarity: 'Legendary',
    coinPrice: 50000,
    duration: '30D',
    durationDays: 30,
    vipLevelRequired: 1,
    isTransferable: true,
    isPurchaseAllowed: true,
    status: 'Active',
    iconEmoji: '👑',
    description: '',
    glowColor: 'rgba(234, 179, 8, 0.8)',
    borderStyle: 'border-amber-400',
    gradientStyle: 'from-amber-400 to-yellow-500',
    animationType: 'sparkle',
    topPlaqueText: 'TROPHY PARTY',
    bottomNameplateText: 'VIP'
  });

  if (!isOpen) return null;

  // Filter frames
  const filteredFrames = frames.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase()) || f.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'ALL' || f.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  // Calculate Analytics
  const analytics: FrameAnalyticsSummary = {
    totalFrames: frames.length,
    activeFrames: frames.filter(f => f.status === 'Active').length,
    totalPurchasesCount: frames.reduce((acc, f) => acc + (f.totalPurchases || 0), 0),
    totalGiftsCount: frames.reduce((acc, f) => acc + (f.totalGifts || 0), 0),
    totalCoinsGenerated: frames.reduce((acc, f) => acc + (f.totalCoinsGenerated || 0), 0),
    activeFrameUsers: frames.reduce((acc, f) => acc + (f.activeUsersCount || 0), 0),
    mostPopularFrame: '👑 VIP 8 Imperial Sovereign Crown',
    mostGiftedFrame: '🇮🇳 India Tiranga Chakra Frame'
  };

  const handleStartCreate = () => {
    setEditingFrame(null);
    setFormData({
      id: `FRM-CUSTOM-${Date.now().toString().slice(-4)}`,
      name: '',
      category: 'HOT',
      rarity: 'Legendary',
      coinPrice: 50000,
      duration: '30D',
      durationDays: 30,
      vipLevelRequired: 1,
      isTransferable: true,
      isPurchaseAllowed: true,
      status: 'Active',
      iconEmoji: '👑',
      description: '',
      glowColor: 'rgba(234, 179, 8, 0.8)',
      borderStyle: 'border-amber-400',
      gradientStyle: 'from-amber-400 to-yellow-500',
      animationType: 'sparkle',
      topPlaqueText: 'TROPHY PARTY',
      bottomNameplateText: 'VIP'
    });
    setActiveTab('create_edit');
  };

  const handleStartEdit = (frame: FrameItem) => {
    setEditingFrame(frame);
    setFormData({ ...frame });
    setActiveTab('create_edit');
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.id) return;

    const frameToSave: FrameItem = {
      id: formData.id,
      name: formData.name,
      category: (formData.category as FrameCategory) || 'HOT',
      rarity: formData.rarity || 'Legendary',
      coinPrice: Number(formData.coinPrice) || 0,
      duration: (formData.duration as FrameDurationType) || '30D',
      durationDays: Number(formData.durationDays) || 30,
      vipLevelRequired: Number(formData.vipLevelRequired) || undefined,
      hostTypeRequired: formData.hostTypeRequired,
      countryRequired: formData.countryRequired,
      countryFlag: formData.countryFlag,
      isTransferable: Boolean(formData.isTransferable),
      isPurchaseAllowed: Boolean(formData.isPurchaseAllowed),
      status: formData.status || 'Active',
      iconEmoji: formData.iconEmoji || '👑',
      description: formData.description || 'DIYO Official Dynamic Frame',
      glowColor: formData.glowColor || 'rgba(234, 179, 8, 0.8)',
      borderStyle: formData.borderStyle || 'border-amber-400',
      gradientStyle: formData.gradientStyle || 'from-amber-400 to-yellow-500',
      animationType: formData.animationType || 'sparkle',
      topPlaqueText: formData.topPlaqueText,
      bottomNameplateText: formData.bottomNameplateText,
      totalPurchases: editingFrame?.totalPurchases || 0,
      totalGifts: editingFrame?.totalGifts || 0,
      totalCoinsGenerated: editingFrame?.totalCoinsGenerated || 0,
      activeUsersCount: editingFrame?.activeUsersCount || 0
    };

    playSoundFX('win');
    onSaveFrame(frameToSave);
    setActiveTab('catalog');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl rounded-3xl bg-gradient-to-b from-[#18212e] via-[#111722] to-[#0c1017] border border-amber-500/40 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white uppercase tracking-wider">
                  DIYO LIVE Frame Admin Center
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase">
                  {currentUserRole}
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Create, edit, price, enable/disable frames, configure durations & analyze revenue.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-neutral-800 bg-neutral-900/50">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('catalog')}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'catalog'
                  ? 'bg-amber-500 text-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Catalog ({frames.length})</span>
            </button>

            <button
              onClick={handleStartCreate}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'create_edit'
                  ? 'bg-amber-500 text-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>{editingFrame ? 'Edit Frame' : 'Create Frame'}</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'analytics'
                  ? 'bg-amber-500 text-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Analytics</span>
            </button>
          </div>

          {activeTab === 'catalog' && (
            <button
              onClick={handleStartCreate}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Frame</span>
            </button>
          )}
        </div>

        {/* Tab 1: Catalog Management */}
        {activeTab === 'catalog' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            
            {/* Filters */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <input
                type="text"
                placeholder="Search frame name or ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full sm:w-64 px-3.5 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
              />

              <div className="flex items-center gap-1 overflow-x-auto w-full pb-1 sm:pb-0">
                <button
                  onClick={() => setSelectedCategory('ALL')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap ${
                    selectedCategory === 'ALL' ? 'bg-amber-400 text-black' : 'bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  All ({frames.length})
                </button>
                {CATEGORIES.slice(0, 8).map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap ${
                      selectedCategory === cat ? 'bg-amber-400 text-black' : 'bg-neutral-900 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Frames Table / Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredFrames.map(frame => (
                <div
                  key={frame.id}
                  className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between ${
                    frame.status === 'Active'
                      ? 'bg-neutral-900/90 border-neutral-800 hover:border-amber-500/40'
                      : 'bg-neutral-950/60 border-red-900/30 opacity-70'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <HostAvatarWithFrame
                        avatarUrl="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"
                        frameId={frame.id}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <h4 className="text-xs font-black text-white truncate max-w-[130px]">{frame.name}</h4>
                        <span className="text-[10px] text-neutral-500 font-mono">{frame.id}</span>
                      </div>
                    </div>

                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase border ${
                      frame.status === 'Active'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}>
                      {frame.status}
                    </span>
                  </div>

                  <div className="mt-3 pt-2 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-neutral-400">Price / Duration</span>
                      <span className="font-mono text-amber-300 font-bold">
                        {frame.isFree ? 'FREE' : `🪙 ${frame.coinPrice.toLocaleString()}`} ({frame.duration})
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleStartEdit(frame)}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white"
                        title="Edit Frame"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          playSoundFX('click');
                          onToggleFrameStatus(frame.id);
                        }}
                        className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                          frame.status === 'Active'
                            ? 'bg-red-500/20 text-red-300 hover:bg-red-500/30'
                            : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                        }`}
                      >
                        {frame.status === 'Active' ? 'Disable' : 'Enable'}
                      </button>

                      <button
                        onClick={() => {
                          if (confirm(`Are you sure you want to delete ${frame.name}?`)) {
                            playSoundFX('alert');
                            onDeleteFrame(frame.id);
                          }
                        }}
                        className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-400"
                        title="Delete Frame"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* Tab 2: Create / Edit Frame Form */}
        {activeTab === 'create_edit' && (
          <form onSubmit={handleSaveForm} className="flex-1 overflow-y-auto p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>{editingFrame ? `Editing: ${editingFrame.name}` : 'Create New Dynamic Frame'}</span>
              </h4>

              <button
                type="button"
                onClick={() => setActiveTab('catalog')}
                className="text-xs text-neutral-400 hover:text-white"
              >
                Back to catalog
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Frame Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">Frame Name *</label>
                <input
                  type="text"
                  required
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. 👑 Sovereign Dragon Imperial Frame"
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Frame ID */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">Frame ID *</label>
                <input
                  type="text"
                  required
                  disabled={Boolean(editingFrame)}
                  value={formData.id || ''}
                  onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-neutral-300 font-mono focus:outline-none focus:border-amber-400 disabled:opacity-60"
                />
              </div>

              {/* Category */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">Category *</label>
                <select
                  value={formData.category || 'HOT'}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value as FrameCategory })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* Rarity */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">Rarity Tier</label>
                <select
                  value={formData.rarity || 'Legendary'}
                  onChange={(e) => setFormData({ ...formData, rarity: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="Royalty">👑 Royalty</option>
                  <option value="Legendary">🔥 Legendary</option>
                  <option value="Epic">💎 Epic</option>
                  <option value="Rare">✨ Rare</option>
                  <option value="Common">🌟 Common</option>
                </select>
              </div>

              {/* Coin Price */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">Coin Price (0 for Free)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.coinPrice ?? 50000}
                  onChange={(e) => setFormData({ ...formData, coinPrice: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-amber-300 font-mono font-bold focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Default Duration */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">Default Duration</label>
                <select
                  value={formData.duration || '30D'}
                  onChange={(e) => setFormData({ ...formData, duration: e.target.value as FrameDurationType })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="1D">1 Day</option>
                  <option value="3D">3 Days</option>
                  <option value="7D">7 Days</option>
                  <option value="30D">30 Days</option>
                  <option value="90D">90 Days</option>
                  <option value="PERMANENT">Permanent (Never Expires)</option>
                </select>
              </div>

              {/* VIP Requirement */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">VIP Level Requirement (0-8)</label>
                <input
                  type="number"
                  min="0"
                  max="8"
                  value={formData.vipLevelRequired ?? 0}
                  onChange={(e) => setFormData({ ...formData, vipLevelRequired: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Icon Emoji */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">Icon Emoji</label>
                <input
                  type="text"
                  value={formData.iconEmoji || '👑'}
                  onChange={(e) => setFormData({ ...formData, iconEmoji: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Country Requirement (if Country Category) */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300">Country Flag & Name (Optional)</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Flag 🇳🇵"
                    value={formData.countryFlag || ''}
                    onChange={(e) => setFormData({ ...formData, countryFlag: e.target.value })}
                    className="w-20 px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white"
                  />
                  <input
                    type="text"
                    placeholder="Country Name"
                    value={formData.countryRequired || ''}
                    onChange={(e) => setFormData({ ...formData, countryRequired: e.target.value })}
                    className="flex-1 px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white"
                  />
                </div>
              </div>

              {/* Toggles: Transferable & Purchase Allowed */}
              <div className="flex items-center gap-4 pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-300 font-bold">
                  <input
                    type="checkbox"
                    checked={formData.isTransferable ?? true}
                    onChange={(e) => setFormData({ ...formData, isTransferable: e.target.checked })}
                    className="w-4 h-4 rounded text-amber-500 focus:ring-0"
                  />
                  <span>Transferable (Giftable)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-300 font-bold">
                  <input
                    type="checkbox"
                    checked={formData.isPurchaseAllowed ?? true}
                    onChange={(e) => setFormData({ ...formData, isPurchaseAllowed: e.target.checked })}
                    className="w-4 h-4 rounded text-amber-500 focus:ring-0"
                  />
                  <span>Purchase Allowed</span>
                </label>
              </div>

            </div>

            {/* Description */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-neutral-300">Description</label>
              <textarea
                rows={2}
                value={formData.description || ''}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Details and lore about this frame..."
                className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Submit Bar */}
            <div className="pt-3 border-t border-neutral-800 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setActiveTab('catalog')}
                className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs uppercase"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/30"
              >
                <Save className="w-4 h-4" />
                <span>Save Frame to Catalog</span>
              </button>
            </div>

          </form>
        )}

        {/* Tab 3: Analytics */}
        {activeTab === 'analytics' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {/* Top 4 KPI Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                <span className="text-[10px] text-neutral-400 uppercase font-bold">Total Frames</span>
                <p className="text-2xl font-black text-white">{analytics.totalFrames}</p>
                <span className="text-[10px] text-emerald-400 font-bold">● {analytics.activeFrames} Active</span>
              </div>

              <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                <span className="text-[10px] text-neutral-400 uppercase font-bold">Total Purchases</span>
                <p className="text-2xl font-black text-amber-300 font-mono">
                  {analytics.totalPurchasesCount.toLocaleString()}
                </p>
                <span className="text-[10px] text-neutral-400">In-app unlocks</span>
              </div>

              <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                <span className="text-[10px] text-neutral-400 uppercase font-bold">Frame Gifts</span>
                <p className="text-2xl font-black text-pink-300 font-mono">
                  {analytics.totalGiftsCount.toLocaleString()}
                </p>
                <span className="text-[10px] text-pink-400">Peer-to-peer gifts</span>
              </div>

              <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                <span className="text-[10px] text-neutral-400 uppercase font-bold">Coins Revenue</span>
                <p className="text-xl sm:text-2xl font-black text-emerald-400 font-mono">
                  🪙 {(analytics.totalCoinsGenerated / 1000000).toFixed(1)}M
                </p>
                <span className="text-[10px] text-neutral-400">Total volume</span>
              </div>
            </div>

            {/* Popular and Gifted Highlight Boxes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 to-neutral-900 border border-amber-500/30 flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center text-xl">
                  👑
                </div>
                <div>
                  <span className="text-[10px] text-amber-400 uppercase font-black tracking-wider">Most Popular Frame</span>
                  <h4 className="text-sm font-black text-white">{analytics.mostPopularFrame}</h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5">Highest active user equipped count</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-gradient-to-r from-pink-950/40 to-neutral-900 border border-pink-500/30 flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-pink-500/20 text-pink-300 flex items-center justify-center text-xl">
                  🎁
                </div>
                <div>
                  <span className="text-[10px] text-pink-400 uppercase font-black tracking-wider">Most Gifted Frame</span>
                  <h4 className="text-sm font-black text-white">{analytics.mostGiftedFrame}</h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5">Top gifted between community friends</p>
                </div>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
