import React, { useState, useMemo } from 'react';
import { 
  X, 
  Sparkles, 
  Crown, 
  Flame, 
  Heart, 
  Flower2, 
  Globe, 
  Mic2, 
  Calendar, 
  Clock, 
  Award, 
  ShieldCheck, 
  Gift, 
  ShoppingBag, 
  Check, 
  Search, 
  RefreshCw, 
  Trash2,
  Sliders,
  Layers,
  Coins,
  ChevronRight,
  TrendingUp,
  Info
} from 'lucide-react';
import { 
  FrameItem, 
  FrameCategory, 
  UserOwnedFrame, 
  FrameDurationType,
  FrameGiftTransaction
} from '../../types/frameTypes';
import { MASTER_FRAME_CATALOG, INITIAL_USER_OWNED_FRAMES, DURATION_OPTIONS } from '../../data/mockFramesData';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';
import { FramePreviewModal } from './FramePreviewModal';
import { FrameGiftModal } from './FrameGiftModal';
import { FrameAdminModal } from './FrameAdminModal';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface FrameCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: {
    id: string;
    name: string;
    avatar: string;
    coinBalance: number;
    vipLevel?: number;
    role?: string;
    hostTag?: string | null;
    avatarFrameId?: string | null;
  };
  onUpdateEquippedFrame: (frameId: string | null) => void;
  onDeductCoins: (amount: number) => void;
  onOpenRecharge: () => void;
}

interface CategoryNavTab {
  id: FrameCategory | 'ALL' | 'MY_COLLECTION';
  label: string;
  icon: string;
  badge?: string;
}

const CATEGORY_TABS: CategoryNavTab[] = [
  { id: 'ALL', label: 'All Frames', icon: '✨' },
  { id: 'MY_COLLECTION', label: 'My Frames', icon: '🎒', badge: 'Collection' },
  { id: 'FREE', label: 'Free Frames', icon: '🌟' },
  { id: 'NEW', label: 'New Frames', icon: '⚡', badge: 'NEW' },
  { id: 'HOT', label: 'Hot Frames', icon: '🔥', badge: 'HOT' },
  { id: 'PREMIUM', label: 'Premium', icon: '💎' },
  { id: 'VIP', label: 'VIP Frames', icon: '👑' },
  { id: 'LOVE', label: 'Love Frames', icon: '💖' },
  { id: 'ROYAL', label: 'Royal Frames', icon: '🔱' },
  { id: 'FIRE', label: 'Fire Frames', icon: '🔥' },
  { id: 'FLOWER', label: 'Flower Frames', icon: '🌸' },
  { id: 'COUNTRY', label: 'Country Frames', icon: '🌍' },
  { id: 'HOST', label: 'Host Frames', icon: '🎤' },
  { id: 'EVENT', label: 'Event Frames', icon: '🎆' },
  { id: 'LIMITED', label: 'Limited Frames', icon: '⏳', badge: 'LTD' },
  { id: 'ACHIEVEMENT', label: 'Achievements', icon: '🏆' }
];

export const FrameCenterModal: React.FC<FrameCenterModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateEquippedFrame,
  onDeductCoins,
  onOpenRecharge
}) => {
  // Master catalog & User owned frames state
  const [catalog, setCatalog] = useState<FrameItem[]>(MASTER_FRAME_CATALOG);
  const [ownedFrames, setOwnedFrames] = useState<UserOwnedFrame[]>(INITIAL_USER_OWNED_FRAMES);
  
  // Navigation & Search
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modals
  const [previewFrame, setPreviewFrame] = useState<FrameItem | null>(null);
  const [giftFrame, setGiftFrame] = useState<FrameItem | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Filter Catalog
  const filteredCatalog = useMemo(() => {
    return catalog.filter(frame => {
      const matchesSearch = frame.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        frame.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        frame.description.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;
      if (selectedCategory === 'ALL') return true;
      return frame.category === selectedCategory;
    });
  }, [catalog, searchQuery, selectedCategory]);

  const isAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN' || currentUser.role === 'OWNER';

  // Check which frame is equipped
  const currentlyEquippedFrameId = currentUser.avatarFrameId || 'FRM-ROLE-ADMIN';

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  // Equip a frame
  const handleEquipFrame = (frame: FrameItem | null) => {
    playSoundFX('click');
    const newFrameId = frame ? frame.id : null;
    
    // Update local equipped state
    setOwnedFrames(prev => prev.map(of => ({
      ...of,
      isEquipped: of.frameId === newFrameId
    })));

    onUpdateEquippedFrame(newFrameId);
    showToast(frame ? `Equipped ${frame.name}!` : 'Removed active frame');
  };

  // Buy a frame
  const handleBuyFrame = (frame: FrameItem, duration: FrameDurationType, cost: number) => {
    if (cost > 0) {
      onDeductCoins(cost);
    }

    const durationDays = duration === '1D' ? 1 : duration === '3D' ? 3 : duration === '7D' ? 7 : duration === '30D' ? 30 : duration === '90D' ? 90 : -1;
    const expiresAt = durationDays === -1 
      ? null 
      : new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString();

    const newOwned: UserOwnedFrame = {
      id: `OWN-${Date.now()}`,
      frameId: frame.id,
      frame: frame,
      acquiredAt: new Date().toISOString(),
      expiresAt: expiresAt,
      durationDays: durationDays,
      isEquipped: true,
      isTransferable: frame.isTransferable,
      obtainedFrom: 'PURCHASE'
    };

    setOwnedFrames(prev => [
      ...prev.map(f => ({ ...f, isEquipped: false })),
      newOwned
    ]);

    // Update catalog stats
    setCatalog(prev => prev.map(f => f.id === frame.id ? {
      ...f,
      totalPurchases: (f.totalPurchases || 0) + 1,
      totalCoinsGenerated: (f.totalCoinsGenerated || 0) + cost,
      activeUsersCount: (f.activeUsersCount || 0) + 1
    } : f));

    onUpdateEquippedFrame(frame.id);
    showToast(`Successfully purchased and equipped ${frame.name}!`);
  };

  // Claim free achievement frame
  const handleClaimAchievement = (frame: FrameItem) => {
    playSoundFX('win');
    confetti({ particleCount: 50, spread: 60 });

    const newOwned: UserOwnedFrame = {
      id: `OWN-ACH-${Date.now()}`,
      frameId: frame.id,
      frame: frame,
      acquiredAt: new Date().toISOString(),
      expiresAt: null,
      durationDays: -1,
      isEquipped: true,
      isTransferable: false,
      obtainedFrom: 'ACHIEVEMENT'
    };

    setOwnedFrames(prev => [
      ...prev.map(f => ({ ...f, isEquipped: false })),
      newOwned
    ]);

    onUpdateEquippedFrame(frame.id);
    showToast(`🏆 Achievement unlocked! ${frame.name} equipped!`);
  };

  // Send Gift Transaction
  const handleSendFrameGift = (tx: FrameGiftTransaction) => {
    onDeductCoins(tx.coinAmount);

    // Update frame stats
    setCatalog(prev => prev.map(f => f.id === tx.frameId ? {
      ...f,
      totalGifts: (f.totalGifts || 0) + 1,
      totalCoinsGenerated: (f.totalCoinsGenerated || 0) + tx.coinAmount
    } : f));

    showToast(`🎁 Gifted ${tx.frameName} to ${tx.receiverName}!`);
  };

  // Admin handlers
  const handleSaveAdminFrame = (frame: FrameItem) => {
    setCatalog(prev => {
      const idx = prev.findIndex(f => f.id === frame.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = frame;
        return next;
      }
      return [frame, ...prev];
    });
    showToast(`Saved ${frame.name} to Frame Center!`);
  };

  const handleDeleteAdminFrame = (frameId: string) => {
    setCatalog(prev => prev.filter(f => f.id !== frameId));
    showToast('Frame deleted from catalog');
  };

  const handleToggleAdminFrameStatus = (frameId: string) => {
    setCatalog(prev => prev.map(f => f.id === frameId ? {
      ...f,
      status: f.status === 'Active' ? 'Inactive' : 'Active'
    } : f));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl h-[92vh] max-h-[850px] rounded-3xl bg-gradient-to-b from-[#161d28] via-[#101620] to-[#0a0d13] border border-neutral-700/80 shadow-2xl overflow-hidden flex flex-col">
        
        {/* ========================================================================= */}
        {/* 1. TOP HEADER BAR                                                        */}
        {/* ========================================================================= */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-neutral-800/80 bg-neutral-900/90 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center shadow-lg shadow-amber-500/20 text-black font-black text-lg">
              👑
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
                  DIYO LIVE Frame Center
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[10px] font-black uppercase">
                  STORE & COLLECTION
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 hidden sm:block">
                Exclusive live party avatars, animated neon glows, VIP halos & country flags
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Coins Balance Pill */}
            <button
              onClick={onOpenRecharge}
              className="px-3 py-1.5 rounded-full bg-neutral-800/90 border border-amber-500/30 hover:border-amber-400 flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-mono text-xs font-black text-amber-300">
                {currentUser.coinBalance.toLocaleString()}
              </span>
              <span className="text-[10px] text-neutral-400 font-bold hidden sm:inline">+ Recharge</span>
            </button>

            {/* Admin Management Button */}
            {isAdmin && (
              <button
                onClick={() => setIsAdminOpen(true)}
                className="px-3 py-1.5 rounded-full bg-amber-500/20 border border-amber-400/50 hover:bg-amber-500/30 text-amber-300 text-xs font-black uppercase flex items-center gap-1 transition-all"
                title="Frame Management & Analytics"
              >
                <Sliders className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Admin Center</span>
              </button>
            )}

            {/* Close Button */}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 2. CATEGORY TABS & SEARCH BAR                                            */}
        {/* ========================================================================= */}
        <div className="px-4 sm:px-6 py-2.5 border-b border-neutral-800 bg-neutral-950/60 flex-shrink-0 space-y-2">
          
          {/* Horizontal Scrollable Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {CATEGORY_TABS.map((tab) => {
              const isSelected = selectedCategory === tab.id;

              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    playSoundFX('click');
                    setSelectedCategory(tab.id);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 flex-shrink-0 ${
                    isSelected
                      ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black shadow-md shadow-amber-500/20 font-black'
                      : 'bg-neutral-900/80 border border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-black ${
                      isSelected ? 'bg-black/30 text-black' : 'bg-rose-500/20 text-rose-300'
                    }`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Search */}
          {selectedCategory !== 'MY_COLLECTION' && (
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search frames by name, category, VIP level, or style..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-4 py-1.5 rounded-xl bg-neutral-900/90 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
              />
            </div>
          )}
        </div>

        {/* ========================================================================= */}
        {/* 3. MAIN BODY CONTENT                                                     */}
        {/* ========================================================================= */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          
          {/* ========================================================================= */}
          {/* TAB: MY FRAMES / INVENTORY COLLECTION                                    */}
          {/* ========================================================================= */}
          {selectedCategory === 'MY_COLLECTION' ? (
            <div className="space-y-6">
              
              {/* Currently Active Equipped Frame Banner */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-neutral-900 to-purple-950/40 border border-amber-500/40 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <HostAvatarWithFrame
                    avatarUrl={currentUser.avatar}
                    frameId={currentlyEquippedFrameId}
                    size="xl"
                    isLive={true}
                  />
                  <div>
                    <span className="text-[10px] uppercase font-black tracking-wider text-amber-400">
                      Currently Equipped Active Frame
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-white">
                      {ownedFrames.find(f => f.frameId === currentlyEquippedFrameId)?.frame.name || 'Default Role Frame'}
                    </h3>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Visible in Profile, Party Live (all 8 seats), Live Audio, Chat & Rankings
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleEquipFrame(null)}
                  className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs uppercase transition-all"
                >
                  Unequip Frame
                </button>
              </div>

              {/* Owned Inventory Grid */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>My Owned Frame Collection ({ownedFrames.length})</span>
                  </h4>
                  <span className="text-[11px] text-neutral-400">
                    Tap Use to equip instantly
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {ownedFrames.map((item) => {
                    const isEquipped = item.frameId === currentlyEquippedFrameId;
                    const isExpired = item.expiresAt && new Date(item.expiresAt).getTime() < Date.now();

                    // Calculate remaining days
                    let remainingText = 'Permanent';
                    if (item.expiresAt) {
                      const diffMs = new Date(item.expiresAt).getTime() - Date.now();
                      const days = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
                      remainingText = days > 0 ? `${days} Days Left` : 'Expired';
                    }

                    return (
                      <div
                        key={item.id}
                        className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between ${
                          isEquipped
                            ? 'bg-amber-500/10 border-amber-400 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400/40'
                            : isExpired
                            ? 'bg-neutral-950/60 border-neutral-800/80 opacity-60'
                            : 'bg-neutral-900/90 border-neutral-800 hover:border-neutral-700'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <HostAvatarWithFrame
                            avatarUrl={currentUser.avatar}
                            frameId={item.frameId}
                            size="md"
                          />
                          <div className="min-w-0 flex-1">
                            <h5 className="text-xs font-black text-white truncate">
                              {item.frame.name}
                            </h5>
                            <div className="flex items-center gap-1.5 mt-1">
                              <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                                isExpired ? 'bg-rose-500/20 text-rose-300' : 'bg-cyan-500/20 text-cyan-300'
                              }`}>
                                {remainingText}
                              </span>
                              <span className="text-[10px] text-neutral-400">
                                {item.obtainedFrom}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="mt-3 pt-2.5 border-t border-neutral-800/80 flex items-center gap-2">
                          <button
                            onClick={() => setPreviewFrame(item.frame)}
                            className="flex-1 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs"
                          >
                            Preview
                          </button>

                          {isEquipped ? (
                            <div className="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-black flex items-center gap-1">
                              <Check className="w-3.5 h-3.5" />
                              <span>In Use</span>
                            </div>
                          ) : isExpired ? (
                            <button
                              onClick={() => setPreviewFrame(item.frame)}
                              className="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-400/50 text-amber-300 text-xs font-bold flex items-center gap-1"
                            >
                              <RefreshCw className="w-3 h-3" />
                              <span>Renew</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => handleEquipFrame(item.frame)}
                              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs uppercase shadow"
                            >
                              Use
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          ) : (
            /* ========================================================================= */
            /* TAB: FRAME CATALOG BROWSER                                               */
            /* ========================================================================= */
            <div className="space-y-4">
              
              {/* Category Info Header */}
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>Showing {filteredCatalog.length} available frames</span>
                <span className="text-amber-400 font-bold">● Tap any frame for Live Preview & Duration Pricing</span>
              </div>

              {/* Grid of Frame Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {filteredCatalog.map((frame) => {
                  const isEquipped = currentlyEquippedFrameId === frame.id;
                  const isOwned = ownedFrames.some(of => of.frameId === frame.id);

                  return (
                    <div
                      key={frame.id}
                      className={`p-4 rounded-2xl border transition-all flex flex-col justify-between relative group ${
                        isEquipped
                          ? 'bg-amber-500/10 border-amber-400/80 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400/40'
                          : 'bg-neutral-900/80 border-neutral-800 hover:border-amber-500/40 hover:bg-neutral-900'
                      }`}
                    >
                      {/* Top Badges */}
                      <div className="flex items-center justify-between gap-1 mb-2">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase border ${
                          frame.rarity === 'Royalty' ? 'bg-amber-500/20 text-amber-300 border-amber-400/40' :
                          frame.rarity === 'Legendary' ? 'bg-rose-500/20 text-rose-300 border-rose-400/40' :
                          frame.rarity === 'Epic' ? 'bg-purple-500/20 text-purple-300 border-purple-400/40' :
                          'bg-cyan-500/20 text-cyan-300 border-cyan-400/40'
                        }`}>
                          {frame.rarity}
                        </span>

                        {frame.isLimited && (
                          <span className="px-2 py-0.5 rounded-full bg-red-600/30 border border-red-500/50 text-red-300 text-[9px] font-black flex items-center gap-1">
                            <Clock className="w-2.5 h-2.5 text-red-400" />
                            <span>{frame.limitedDaysRemaining || 3}D Left</span>
                          </span>
                        )}

                        {frame.vipLevelRequired && (
                          <span className="px-2 py-0.5 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-300 text-[9px] font-black flex items-center gap-1">
                            <Crown className="w-2.5 h-2.5 text-amber-400" />
                            <span>VIP {frame.vipLevelRequired}</span>
                          </span>
                        )}

                        {frame.isFree && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[9px] font-black">
                            FREE
                          </span>
                        )}
                      </div>

                      {/* Center Stage Avatar + Frame */}
                      <div className="flex flex-col items-center justify-center py-2 cursor-pointer" onClick={() => setPreviewFrame(frame)}>
                        <HostAvatarWithFrame
                          avatarUrl={currentUser.avatar}
                          frameId={frame.id}
                          frameUrl={frame.previewUrl}
                          size="lg"
                          isLive={false}
                        />
                        <h4 className="mt-2 text-xs font-black text-white text-center truncate max-w-[200px]">
                          {frame.name}
                        </h4>
                        <p className="text-[10px] text-neutral-400 text-center line-clamp-1 mt-0.5">
                          {frame.description}
                        </p>
                      </div>

                      {/* Price & Primary Action Bar */}
                      <div className="mt-3 pt-2.5 border-t border-neutral-800/80 flex items-center justify-between gap-2">
                        <div className="flex flex-col">
                          <span className="text-[9px] text-neutral-500 font-bold uppercase">Price</span>
                          <span className="text-xs font-mono font-black text-amber-300">
                            {frame.isFree || frame.coinPrice === 0 ? 'FREE' : `🪙 ${frame.coinPrice.toLocaleString()}`}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => {
                              playSoundFX('click');
                              setPreviewFrame(frame);
                            }}
                            className="px-2.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white font-bold text-xs transition-colors"
                          >
                            Preview
                          </button>

                          {isEquipped ? (
                            <span className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-black flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              <span>In Use</span>
                            </span>
                          ) : isOwned || frame.isFree ? (
                            <button
                              onClick={() => handleEquipFrame(frame)}
                              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-neutral-950 font-black text-xs uppercase tracking-wider shadow"
                            >
                              Use
                            </button>
                          ) : (
                            <button
                              onClick={() => setPreviewFrame(frame)}
                              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs uppercase tracking-wider shadow"
                            >
                              Buy
                            </button>
                          )}

                          {frame.isTransferable && (
                            <button
                              onClick={() => setGiftFrame(frame)}
                              className="p-1.5 rounded-xl bg-pink-500/20 hover:bg-pink-500/30 text-pink-300"
                              title="Gift Frame"
                            >
                              <Gift className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>

            </div>
          )}

        </div>

        {/* ========================================================================= */}
        {/* 4. SUCCESS NOTIFICATION TOAST                                            */}
        {/* ========================================================================= */}
        {successToast && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs shadow-2xl flex items-center gap-2 animate-in slide-in-from-bottom-2">
            <Check className="w-4 h-4" />
            <span>{successToast}</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 5. CHILD MODALS                                                          */}
        {/* ========================================================================= */}
        <FramePreviewModal
          isOpen={Boolean(previewFrame)}
          onClose={() => setPreviewFrame(null)}
          frame={previewFrame}
          currentAvatar={currentUser.avatar}
          userCoins={currentUser.coinBalance}
          userVipLevel={currentUser.vipLevel || 1}
          isOwned={Boolean(previewFrame && ownedFrames.some(of => of.frameId === previewFrame.id))}
          isEquipped={Boolean(previewFrame && currentlyEquippedFrameId === previewFrame.id)}
          onEquip={handleEquipFrame}
          onBuy={handleBuyFrame}
          onOpenGiftModal={(f) => {
            setPreviewFrame(null);
            setGiftFrame(f);
          }}
          onOpenRecharge={onOpenRecharge}
          onClaimAchievement={handleClaimAchievement}
        />

        <FrameGiftModal
          isOpen={Boolean(giftFrame)}
          onClose={() => setGiftFrame(null)}
          frame={giftFrame}
          currentUser={currentUser}
          onSendFrameGift={handleSendFrameGift}
          onOpenRecharge={onOpenRecharge}
        />

        <FrameAdminModal
          isOpen={isAdminOpen}
          onClose={() => setIsAdminOpen(false)}
          frames={catalog}
          onSaveFrame={handleSaveAdminFrame}
          onDeleteFrame={handleDeleteAdminFrame}
          onToggleFrameStatus={handleToggleAdminFrameStatus}
          currentUserRole={currentUser.role}
        />

      </div>
    </div>
  );
};
