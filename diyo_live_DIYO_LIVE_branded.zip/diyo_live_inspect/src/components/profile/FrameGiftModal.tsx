import React, { useState } from 'react';
import { 
  X, 
  Gift, 
  Search, 
  Sparkles, 
  Clock, 
  Coins, 
  Check, 
  User, 
  Users, 
  Heart,
  Crown,
  Send
} from 'lucide-react';
import { FrameItem, FrameDurationType, FrameGiftTransaction } from '../../types/frameTypes';
import { DURATION_OPTIONS } from '../../data/mockFramesData';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface RecipientUser {
  id: string;
  name: string;
  avatar: string;
  vipLevel?: number;
  countryFlag?: string;
  role?: string;
}

const DEFAULT_RECIPIENTS: RecipientUser[] = [
  { id: 'USR-889912', name: 'Rohan Sharma', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', vipLevel: 6, countryFlag: '🇮🇳' },
  { id: 'USR-884102', name: 'DJ Anya (Host)', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', vipLevel: 7, countryFlag: '🇳🇵', role: 'Singer Host' },
  { id: 'USR-881290', name: 'Kavita Roy', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', vipLevel: 5, countryFlag: '🇮🇳' },
  { id: 'USR-885544', name: 'DesDes Hi (Top Host)', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150', vipLevel: 8, countryFlag: '🇻🇳' },
  { id: 'USR-887766', name: 'Rahul Varma', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', vipLevel: 4, countryFlag: '🇵🇰' }
];

interface FrameGiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  frame: FrameItem | null;
  currentUser: {
    id: string;
    name: string;
    avatar: string;
    coinBalance: number;
  };
  onSendFrameGift: (transaction: FrameGiftTransaction) => void;
  onOpenRecharge: () => void;
}

export const FrameGiftModal: React.FC<FrameGiftModalProps> = ({
  isOpen,
  onClose,
  frame,
  currentUser,
  onSendFrameGift,
  onOpenRecharge
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRecipient, setSelectedRecipient] = useState<RecipientUser>(DEFAULT_RECIPIENTS[0]);
  const [selectedDuration, setSelectedDuration] = useState<FrameDurationType>('30D');
  const [giftNote, setGiftNote] = useState('Enjoy this royal frame from me! 🎉');
  const [isSending, setIsSending] = useState(false);

  if (!isOpen || !frame) return null;

  const durationOpt = DURATION_OPTIONS.find(d => d.type === selectedDuration) || DURATION_OPTIONS[3];
  const calculatedCost = Math.round(frame.coinPrice * durationOpt.priceMultiplier);
  const canAfford = currentUser.coinBalance >= calculatedCost;

  const filteredRecipients = DEFAULT_RECIPIENTS.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSend = () => {
    if (!canAfford) {
      playSoundFX('alert');
      onOpenRecharge();
      return;
    }

    setIsSending(true);
    playSoundFX('superchat');
    confetti({ particleCount: 60, spread: 70 });

    const tx: FrameGiftTransaction = {
      transactionId: `TX-GIFT-${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      receiverId: selectedRecipient.id,
      receiverName: selectedRecipient.name,
      receiverAvatar: selectedRecipient.avatar,
      frameId: frame.id,
      frameName: frame.name,
      coinAmount: calculatedCost,
      duration: selectedDuration,
      timestamp: new Date().toISOString(),
      status: 'SUCCESS',
      note: giftNote
    };

    setTimeout(() => {
      onSendFrameGift(tx);
      setIsSending(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-gradient-to-b from-[#1c2331] via-[#141b26] to-[#0c1017] border border-purple-500/40 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-800 bg-neutral-900/80">
          <div className="flex items-center gap-2">
            <Gift className="w-5 h-5 text-pink-400" />
            <h3 className="text-base font-black text-white uppercase tracking-wider">
              Gift Frame to Friend
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          
          {/* Selected Frame Mini Spotlight */}
          <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <HostAvatarWithFrame
                avatarUrl={selectedRecipient.avatar}
                frameId={frame.id}
                size="md"
              />
              <div>
                <h4 className="text-sm font-black text-white">{frame.name}</h4>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs font-mono text-amber-300 font-bold">
                    🪙 {calculatedCost.toLocaleString()} Coins
                  </span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-bold">
                    {durationOpt.label}
                  </span>
                </div>
              </div>
            </div>

            <span className="text-xs text-neutral-400 font-mono">
              Transferable ✅
            </span>
          </div>

          {/* Recipient Selection */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-pink-400" />
                <span>Select Recipient</span>
              </span>
              <span className="text-[11px] text-neutral-400 font-normal">
                {selectedRecipient ? `Selected: ${selectedRecipient.name}` : 'Choose a user'}
              </span>
            </label>

            {/* Quick Search */}
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search user by name or ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500"
              />
            </div>

            {/* Recipient Horizontal/Grid Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-1">
              {filteredRecipients.map((user) => {
                const isSelected = selectedRecipient.id === user.id;

                return (
                  <button
                    key={user.id}
                    onClick={() => {
                      playSoundFX('click');
                      setSelectedRecipient(user);
                    }}
                    className={`p-2 rounded-xl border text-left flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-pink-500/20 border-pink-400 text-white shadow-md ring-1 ring-pink-400/40'
                        : 'bg-neutral-900/60 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="w-8 h-8 rounded-full object-cover border border-neutral-700"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="text-xs font-bold truncate text-white">{user.name}</span>
                          {user.countryFlag && <span className="text-xs">{user.countryFlag}</span>}
                        </div>
                        <span className="text-[10px] text-neutral-400 font-mono">{user.id}</span>
                      </div>
                    </div>

                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-pink-500 text-white flex items-center justify-center text-xs">
                        ✓
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Duration Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>Gift Duration</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {DURATION_OPTIONS.map((opt) => {
                const cost = Math.round(frame.coinPrice * opt.priceMultiplier);
                const isSel = selectedDuration === opt.type;

                return (
                  <button
                    key={opt.type}
                    onClick={() => {
                      playSoundFX('click');
                      setSelectedDuration(opt.type);
                    }}
                    className={`p-2 rounded-xl border text-center transition-all flex flex-col items-center justify-center ${
                      isSel
                        ? 'bg-purple-500/20 border-purple-400 text-white shadow-md ring-1 ring-purple-400/40'
                        : 'bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs font-bold">{opt.label}</span>
                    <span className="text-[10px] font-mono text-amber-300 font-bold mt-0.5">
                      🪙 {cost.toLocaleString()}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Greeting Note */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Gift Message</span>
            </label>
            <input
              type="text"
              value={giftNote}
              onChange={(e) => setGiftNote(e.target.value)}
              maxLength={60}
              placeholder="Add a nice note with this frame gift..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:outline-none focus:border-pink-500"
            />
          </div>

          {/* Balance Check */}
          <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-neutral-400 uppercase font-bold">Total Gift Cost</span>
              <p className="text-base font-black text-amber-400 font-mono">
                🪙 {calculatedCost.toLocaleString()} Coins
              </p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-neutral-400 uppercase font-bold">Your Balance</span>
              <p className={`text-sm font-mono font-bold ${canAfford ? 'text-cyan-300' : 'text-rose-400'}`}>
                🪙 {currentUser.coinBalance.toLocaleString()}
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Actions */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex items-center gap-3">
          <button
            onClick={onClose}
            className="px-4 py-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs uppercase"
          >
            Cancel
          </button>

          {canAfford ? (
            <button
              onClick={handleSend}
              disabled={isSending}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-pink-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{isSending ? 'Sending Gift...' : `Send Frame Gift (${calculatedCost.toLocaleString()} Coins)`}</span>
            </button>
          ) : (
            <button
              onClick={onOpenRecharge}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-rose-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <Coins className="w-4 h-4" />
              <span>Insufficient Coins • Recharge Now</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
