import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  Crown, 
  ShieldCheck, 
  Check, 
  Lock, 
  Gift, 
  ShoppingBag, 
  Zap, 
  Clock, 
  Coins, 
  AlertCircle,
  Award,
  Globe
} from 'lucide-react';
import { FrameItem, FrameDurationType } from '../../types/frameTypes';
import { DURATION_OPTIONS } from '../../data/mockFramesData';
import { HostAvatarWithFrame } from '../HostAvatarWithFrame';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface FramePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  frame: FrameItem | null;
  currentAvatar: string;
  userCoins: number;
  userVipLevel?: number;
  isOwned: boolean;
  isEquipped: boolean;
  onEquip: (frame: FrameItem) => void;
  onBuy: (frame: FrameItem, duration: FrameDurationType, cost: number) => void;
  onOpenGiftModal: (frame: FrameItem) => void;
  onOpenRecharge: () => void;
  onClaimAchievement?: (frame: FrameItem) => void;
}

export const FramePreviewModal: React.FC<FramePreviewModalProps> = ({
  isOpen,
  onClose,
  frame,
  currentAvatar,
  userCoins,
  userVipLevel = 1,
  isOwned,
  isEquipped,
  onEquip,
  onBuy,
  onOpenGiftModal,
  onOpenRecharge,
  onClaimAchievement
}) => {
  const [selectedDuration, setSelectedDuration] = useState<FrameDurationType>('30D');
  const [isConfirmingBuy, setIsConfirmingBuy] = useState(false);

  if (!isOpen || !frame) return null;

  // Calculate dynamic price based on duration
  const currentDurationOpt = DURATION_OPTIONS.find(d => d.type === selectedDuration) || DURATION_OPTIONS[3];
  const calculatedCost = frame.isFree || frame.coinPrice === 0 
    ? 0 
    : Math.round(frame.coinPrice * currentDurationOpt.priceMultiplier);

  const canAfford = userCoins >= calculatedCost;
  const isVipEligible = !frame.vipLevelRequired || (userVipLevel >= frame.vipLevelRequired);

  const handleBuy = () => {
    if (!canAfford) {
      playSoundFX('alert');
      onOpenRecharge();
      return;
    }
    playSoundFX('win');
    confetti({ particleCount: 50, spread: 60 });
    onBuy(frame, selectedDuration, calculatedCost);
    setIsConfirmingBuy(false);
  };

  const handleEquip = () => {
    playSoundFX('win');
    onEquip(frame);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-[#18212e] via-[#121924] to-[#0c1017] border border-neutral-700/80 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-800/80 bg-neutral-900/60">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-black text-white uppercase tracking-wider">
              Frame Live Preview
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          
          {/* Live Avatar Preview Center Stage */}
          <div className="flex flex-col items-center justify-center py-6 px-4 rounded-2xl bg-gradient-to-b from-neutral-900/80 to-black/60 border border-neutral-800 relative overflow-hidden">
            {/* Background Glow */}
            <div 
              className="absolute w-40 h-40 rounded-full blur-3xl opacity-30 pointer-events-none"
              style={{ backgroundColor: frame.glowColor }}
            />

            {/* Frame + Avatar in XXL size */}
            <div className="relative z-10 my-2">
              <HostAvatarWithFrame
                avatarUrl={currentAvatar}
                frameId={frame.id}
                frameUrl={frame.previewUrl}
                size="2xl"
                isLive={true}
              />
            </div>

            {/* Badges and tags */}
            <div className="mt-4 flex items-center gap-2 flex-wrap justify-center">
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider border shadow-sm ${
                frame.rarity === 'Royalty' ? 'bg-amber-500/20 text-amber-300 border-amber-400/40' :
                frame.rarity === 'Legendary' ? 'bg-rose-500/20 text-rose-300 border-rose-400/40' :
                frame.rarity === 'Epic' ? 'bg-purple-500/20 text-purple-300 border-purple-400/40' :
                'bg-cyan-500/20 text-cyan-300 border-cyan-400/40'
              }`}>
                {frame.rarity}
              </span>

              {frame.isLimited && (
                <span className="px-2.5 py-0.5 rounded-full bg-red-600/30 border border-red-500/60 text-red-300 text-xs font-black uppercase flex items-center gap-1">
                  <Clock className="w-3 h-3 text-red-400" />
                  <span>Limited ({frame.limitedDaysRemaining || 3}D Left)</span>
                </span>
              )}

              {frame.vipLevelRequired && (
                <span className="px-2.5 py-0.5 rounded-full bg-purple-600/30 border border-purple-500/60 text-purple-300 text-xs font-black flex items-center gap-1">
                  <Crown className="w-3 h-3 text-amber-400" />
                  <span>VIP {frame.vipLevelRequired}+ Required</span>
                </span>
              )}

              {frame.countryFlag && (
                <span className="px-2.5 py-0.5 rounded-full bg-blue-600/30 border border-blue-500/60 text-blue-200 text-xs font-black flex items-center gap-1">
                  <span>{frame.countryFlag}</span>
                  <span>{frame.countryRequired}</span>
                </span>
              )}
            </div>

            {/* Title & Description */}
            <h4 className="mt-3 text-lg font-black text-white text-center">
              {frame.name}
            </h4>
            <p className="mt-1 text-xs text-neutral-300 text-center max-w-sm leading-relaxed">
              {frame.description}
            </p>
          </div>

          {/* Duration Selector (Only if purchasable and not permanent-only or achievement) */}
          {!frame.isFree && !frame.isAchievement && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Select Duration</span>
              </label>

              <div className="grid grid-cols-3 gap-2">
                {DURATION_OPTIONS.map((opt) => {
                  const costForOpt = Math.round(frame.coinPrice * opt.priceMultiplier);
                  const isSelected = selectedDuration === opt.type;

                  return (
                    <button
                      key={opt.type}
                      onClick={() => {
                        playSoundFX('click');
                        setSelectedDuration(opt.type);
                      }}
                      className={`p-2 rounded-xl border text-center transition-all flex flex-col items-center justify-center ${
                        isSelected
                          ? 'bg-amber-500/20 border-amber-400 text-white shadow-lg ring-1 ring-amber-400/50'
                          : 'bg-neutral-900/70 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                      }`}
                    >
                      <span className="text-xs font-bold">{opt.label}</span>
                      <span className="text-[10px] font-mono text-amber-300 font-bold mt-0.5">
                        🪙 {costForOpt.toLocaleString()}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Price & Balance Info Box */}
          <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
                Price for {selectedDuration}
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-lg font-black text-amber-400 font-mono">
                  {frame.isFree || frame.coinPrice === 0 ? 'FREE' : `🪙 ${calculatedCost.toLocaleString()}`}
                </span>
                {frame.isFree && (
                  <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-black">
                    UNLOCKED
                  </span>
                )}
              </div>
            </div>

            <div className="flex flex-col items-end">
              <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
                Your Coins
              </span>
              <span className={`text-sm font-mono font-bold mt-0.5 ${canAfford ? 'text-cyan-300' : 'text-rose-400'}`}>
                🪙 {userCoins.toLocaleString()}
              </span>
            </div>
          </div>

          {/* VIP Restriction Warning if Not Eligible */}
          {!isVipEligible && (
            <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-500/40 flex items-start gap-2.5 text-xs text-purple-200">
              <Lock className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-white">VIP Level {frame.vipLevelRequired} Required</p>
                <p className="text-[11px] text-purple-300">
                  Your current VIP level is VIP {userVipLevel}. Upgrade your VIP status by gifting or recharging to unlock this royal frame.
                </p>
              </div>
            </div>
          )}

          {/* Achievement Frame Unlock Details */}
          {frame.isAchievement && (
            <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-amber-200 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>{frame.achievementTitle || 'Achievement Requirement'}</span>
                </span>
                <span className="font-mono text-amber-300 font-bold">
                  {frame.achievementProgress || 0} / {frame.achievementTarget || 1}
                </span>
              </div>
              <p className="text-[11px] text-neutral-300">
                {frame.achievementDesc}
              </p>
            </div>
          )}

        </div>

        {/* Bottom Actions Bar */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex items-center gap-2.5">
          {/* If already owned & currently equipped */}
          {isEquipped ? (
            <div className="flex-1 py-3 rounded-xl bg-emerald-600/20 border border-emerald-500/50 text-emerald-300 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2">
              <Check className="w-4 h-4" />
              <span>Currently Equipped</span>
            </div>
          ) : isOwned || frame.isFree ? (
            <button
              onClick={handleEquip}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Use / Equip Frame</span>
            </button>
          ) : frame.isAchievement && frame.isUnlocked ? (
            <button
              onClick={() => {
                if (onClaimAchievement) onClaimAchievement(frame);
              }}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <Award className="w-4 h-4" />
              <span>Claim & Unlock Free</span>
            </button>
          ) : !isVipEligible ? (
            <button
              disabled
              className="flex-1 py-3 rounded-xl bg-neutral-800 border border-neutral-700 text-neutral-500 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-not-allowed"
            >
              <Lock className="w-4 h-4" />
              <span>VIP {frame.vipLevelRequired} Required</span>
            </button>
          ) : canAfford ? (
            <button
              onClick={() => setIsConfirmingBuy(true)}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-black font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Buy ({calculatedCost.toLocaleString()} Coins)</span>
            </button>
          ) : (
            <button
              onClick={onOpenRecharge}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-rose-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <Coins className="w-4 h-4" />
              <span>Recharge Coins to Buy</span>
            </button>
          )}

          {/* Gift Button (if transferable) */}
          {frame.isTransferable && (
            <button
              onClick={() => {
                onClose();
                onOpenGiftModal(frame);
              }}
              className="px-4 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-purple-600/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              title="Gift this frame to another user"
            >
              <Gift className="w-4 h-4" />
              <span className="hidden sm:inline">Gift Frame</span>
            </button>
          )}
        </div>

        {/* Confirmation Modal Overlay */}
        {isConfirmingBuy && (
          <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center space-y-4 animate-in fade-in">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-2xl text-amber-300">
              🪙
            </div>
            <h4 className="text-lg font-black text-white">
              Confirm Frame Purchase
            </h4>
            <p className="text-xs text-neutral-300 max-w-xs">
              Are you sure you want to purchase <strong>{frame.name}</strong> for <strong>{selectedDuration}</strong>?
            </p>
            <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 w-full max-w-xs font-mono text-sm">
              <div className="flex justify-between text-neutral-400 text-xs">
                <span>Cost:</span>
                <span className="text-amber-400 font-bold">🪙 {calculatedCost.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-neutral-400 text-xs mt-1">
                <span>Remaining:</span>
                <span className="text-cyan-300 font-bold">🪙 {(userCoins - calculatedCost).toLocaleString()}</span>
              </div>
            </div>
            <div className="flex items-center gap-3 w-full max-w-xs pt-2">
              <button
                onClick={() => setIsConfirmingBuy(false)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleBuy}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30"
              >
                Confirm Buy
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
