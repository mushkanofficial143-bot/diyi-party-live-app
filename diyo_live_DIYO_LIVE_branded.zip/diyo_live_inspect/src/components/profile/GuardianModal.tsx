import React, { useState } from 'react';
import { X, Shield, ShieldCheck, Heart, Crown, Sparkles, UserCheck } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface GuardianModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName?: string;
}

export const GuardianModal: React.FC<GuardianModalProps> = ({
  isOpen,
  onClose,
  userName = 'SR RITU'
}) => {
  const [activeTab, setActiveTab] = useState<'my_guardians' | 'guarding'>('my_guardians');

  if (!isOpen) return null;

  const guardians = [
    {
      id: 'g-1',
      name: '👑 Vikram Raja',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100',
      tier: 'Diamond Guardian',
      daysLeft: 28,
      intimacy: 89400,
      badge: '💎 VIP 8'
    },
    {
      id: 'g-2',
      name: '🔥 Star Knight',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100',
      tier: 'Gold Guardian',
      daysLeft: 14,
      intimacy: 42300,
      badge: '⭐ VIP 5'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in select-none">
      <div className="bg-white text-neutral-900 border border-neutral-200 rounded-3xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between bg-gradient-to-r from-cyan-50 to-teal-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-cyan-500 text-white flex items-center justify-center shadow-md">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-neutral-900">Guardian Center</h2>
              <p className="text-[11px] text-neutral-500 font-medium">Protect & support your favorite host</p>
            </div>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Toggle */}
        <div className="flex border-b border-neutral-100 p-2 gap-2 bg-neutral-50">
          <button
            onClick={() => {
              setActiveTab('my_guardians');
              playSoundFX('click');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'my_guardians'
                ? 'bg-cyan-500 text-white shadow-sm'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            My Guardians ({guardians.length})
          </button>
          <button
            onClick={() => {
              setActiveTab('guarding');
              playSoundFX('click');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'guarding'
                ? 'bg-cyan-500 text-white shadow-sm'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            I am Guarding (0)
          </button>
        </div>

        {/* List */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {activeTab === 'my_guardians' ? (
            guardians.map(g => (
              <div key={g.id} className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img src={g.avatar} alt={g.name} className="w-12 h-12 rounded-full object-cover ring-2 ring-cyan-400" />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-neutral-900">{g.name}</span>
                      <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-cyan-100 text-cyan-800">{g.badge}</span>
                    </div>
                    <p className="text-[11px] text-cyan-600 font-bold mt-0.5">{g.tier} • {g.daysLeft} days left</p>
                    <p className="text-[10px] text-neutral-400">Intimacy: {g.intimacy.toLocaleString()} pts</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-2.5 py-1 rounded-full bg-cyan-50 text-cyan-700 text-[10px] font-bold border border-cyan-200">
                    Active 🛡️
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 text-neutral-400 space-y-2">
              <Shield className="w-10 h-10 mx-auto text-neutral-300" />
              <p className="text-xs font-medium">You are not currently guarding any hosts.</p>
              <p className="text-[11px] text-neutral-400">Visit any Live Room and click Guard to protect them!</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
