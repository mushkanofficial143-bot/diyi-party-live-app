import React from 'react';
import { X, Award, Shield, Sparkles, Star, ChevronRight, Zap } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface HonorLevelModalProps {
  isOpen: boolean;
  onClose: () => void;
  userLevel?: number;
  charmLevel?: number;
}

export const HonorLevelModal: React.FC<HonorLevelModalProps> = ({
  isOpen,
  onClose,
  userLevel = 9,
  charmLevel = 38
}) => {
  if (!isOpen) return null;

  const levels = [
    { lvl: 9, title: 'Baron Supporter', badge: 'Lv.9', perk: 'Exclusive chat glow, custom entry animation', exp: '48,200 / 50,000 EXP' },
    { lvl: 10, title: 'Viscount Supporter', badge: 'Lv.10', perk: 'Sound FX on stream entry, 1.2x Lucky multiplier boost', exp: 'Locked' },
    { lvl: 15, title: 'Count Supporter', badge: 'Lv.15', perk: 'Personalized avatar frame, VIP seat reservation', exp: 'Locked' },
    { lvl: 20, title: 'Duke Supporter', badge: 'Lv.20', perk: 'Global stream broadcast banner on entering live room', exp: 'Locked' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in select-none">
      <div className="bg-white text-neutral-900 border border-neutral-200 rounded-3xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between bg-gradient-to-r from-purple-50 to-indigo-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-purple-600 text-white flex items-center justify-center shadow-md">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-neutral-900">Honor Level Privileges</h2>
              <p className="text-[11px] text-purple-600 font-bold">Level up by sending gifts & active streaming</p>
            </div>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Level Status Card */}
        <div className="p-4 m-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-violet-700 text-white shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-black text-sm">
                V{userLevel}
              </div>
              <div>
                <h3 className="text-sm font-black">Level {userLevel} Honor</h3>
                <span className="text-[10px] text-purple-200">Charm Star: ★ {charmLevel}</span>
              </div>
            </div>
            <span className="text-xs bg-white/20 px-2.5 py-1 rounded-full font-bold">Baron</span>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-[11px] text-purple-200">
              <span>EXP Progress</span>
              <span>96.4%</span>
            </div>
            <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden">
              <div className="w-[96.4%] h-full bg-gradient-to-r from-amber-300 to-yellow-400 rounded-full" />
            </div>
          </div>
        </div>

        {/* Level Perks List */}
        <div className="p-4 overflow-y-auto space-y-2.5 flex-1">
          <h3 className="text-xs font-black text-neutral-500 uppercase tracking-wider">Level Roadmap</h3>
          {levels.map(l => (
            <div key={l.lvl} className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-black">
                    {l.badge}
                  </span>
                  <span className="text-xs font-bold text-neutral-900">{l.title}</span>
                </div>
                <span className="text-[10px] text-neutral-400 font-mono">{l.exp}</span>
              </div>
              <p className="text-[11px] text-neutral-600 pl-1">{l.perk}</p>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
