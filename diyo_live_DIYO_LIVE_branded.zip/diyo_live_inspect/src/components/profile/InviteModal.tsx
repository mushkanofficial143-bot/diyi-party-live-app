import React, { useState } from 'react';
import { X, Share2, Copy, CheckCircle2, Gift, Sparkles, Users } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface InviteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InviteModal: React.FC<InviteModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const inviteCode = 'SRLIVE8829';

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(inviteCode);
    setCopied(true);
    playSoundFX('click');
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-amber-500/30 rounded-3xl w-full max-w-lg max-h-[85vh] overflow-hidden flex flex-col shadow-2xl shadow-amber-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-neutral-950 shadow-lg">
              <Share2 className="w-5 h-5 text-neutral-950 font-bold" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                INVITE FRIENDS & EARN
              </h2>
              <p className="text-xs text-neutral-400">Share Referral Code & Get +10,000 Free Test Coins</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          
          <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/50 via-neutral-900 to-emerald-950/40 border border-amber-500/30 text-center space-y-2">
            <span className="text-2xl">🎁</span>
            <h3 className="text-sm font-black text-white">Your Unique Referral Code</h3>
            
            <div className="flex items-center justify-center gap-2 max-w-xs mx-auto mt-2">
              <span className="px-4 py-2.5 rounded-xl bg-neutral-950 border border-amber-500/40 font-mono text-lg font-black text-amber-300 tracking-wider">
                {inviteCode}
              </span>
              <button
                onClick={handleCopy}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs uppercase flex items-center gap-1.5 transition-all shadow-md"
              >
                {copied ? <CheckCircle2 className="w-4 h-4 text-neutral-950" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mt-1">Both you and your friend receive 10,000 Test Coins upon first stream entry.</p>
          </div>

          <div className="space-y-2 text-xs text-neutral-300">
            <span className="font-bold text-neutral-400 uppercase tracking-wider block">How it Works</span>
            <div className="p-3.5 rounded-xl bg-neutral-900/80 border border-neutral-800 space-y-1.5">
              <p>1. Copy your code and send it to friends on WhatsApp, Telegram, or Discord.</p>
              <p>2. Friend registers and enters your referral code.</p>
              <p>3. Instant bonus coins credited directly to your DIYO LIVE Wallet!</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
