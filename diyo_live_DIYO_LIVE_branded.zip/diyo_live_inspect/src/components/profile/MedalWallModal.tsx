import React from 'react';
import { X, Award, Medal, Crown, Star, Sparkles, CheckCircle2 } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface MedalWallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MedalWallModal: React.FC<MedalWallModalProps> = ({
  isOpen,
  onClose
}) => {
  if (!isOpen) return null;

  const medals = [
    { id: 'm1', name: 'DIYO Founder', icon: '👑', desc: 'Active member since platform launch', unlocked: true, rarity: 'Mythic' },
    { id: 'm2', name: 'Lucky Multiplier 1000x', icon: '🎰', desc: 'Hit a 1000x jackpot in Lucky Gift', unlocked: true, rarity: 'Legendary' },
    { id: 'm3', name: 'Top 100 Gifter', icon: '💎', desc: 'Sent over 1,000,000 Test Coins', unlocked: true, rarity: 'Epic' },
    { id: 'm4', name: 'PK Gladiator', icon: '⚔️', desc: 'Won 50+ consecutive PK battles', unlocked: false, rarity: 'Rare' },
    { id: 'm5', name: 'Super Host Star', icon: '🌟', desc: 'Streamed for 100+ live broadcast hours', unlocked: true, rarity: 'Epic' },
    { id: 'm6', name: 'Millionaire Club', icon: '💰', desc: 'Hold over 500,000 Test Coins in vault', unlocked: false, rarity: 'Legendary' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in select-none">
      <div className="bg-white text-neutral-900 border border-neutral-200 rounded-3xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between bg-gradient-to-r from-amber-50 to-orange-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md">
              <Medal className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-neutral-900">Medal Wall</h2>
              <p className="text-[11px] text-amber-600 font-bold">Showcase your achievements & prestige</p>
            </div>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Medals Grid */}
        <div className="p-4 overflow-y-auto grid grid-cols-2 gap-3 flex-1">
          {medals.map(m => (
            <div
              key={m.id}
              className={`p-3.5 rounded-2xl border flex flex-col items-center text-center gap-2 transition-all ${
                m.unlocked
                  ? 'bg-gradient-to-b from-amber-50/60 to-white border-amber-300 shadow-sm'
                  : 'bg-neutral-50 border-neutral-200 opacity-50 grayscale'
              }`}
            >
              <div className="w-12 h-12 rounded-2xl bg-white border border-amber-200 shadow-sm flex items-center justify-center text-2xl">
                {m.icon}
              </div>
              <div>
                <h4 className="text-xs font-black text-neutral-900">{m.name}</h4>
                <p className="text-[10px] text-neutral-500 mt-0.5 leading-tight">{m.desc}</p>
              </div>
              <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${
                m.unlocked ? 'bg-amber-100 text-amber-800' : 'bg-neutral-200 text-neutral-600'
              }`}>
                {m.unlocked ? 'Unlocked ✓' : 'Locked'}
              </span>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
