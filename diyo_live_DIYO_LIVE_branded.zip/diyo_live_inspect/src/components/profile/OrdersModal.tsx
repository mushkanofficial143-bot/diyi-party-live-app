import React, { useState } from 'react';
import { 
  X, 
  FolderArchive, 
  Coins, 
  Gem, 
  ShoppingBag, 
  CheckCircle2, 
  Clock, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Filter,
  FileText
} from 'lucide-react';
import { WalletTransaction } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

interface OrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: WalletTransaction[];
}

export const OrdersModal: React.FC<OrdersModalProps> = ({
  isOpen,
  onClose,
  transactions
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'TOPUP' | 'GIFT' | 'EXCHANGE' | 'STORE'>('ALL');

  if (!isOpen) return null;

  // Sample order records if transactions is empty
  const sampleOrders = [
    { id: 'ORD-892144', type: 'TOPUP', title: 'Coin Top-up (50,000 Coins)', amount: '+50,000 🪙', price: '$49.99', date: '2026-08-22 11:24', status: 'COMPLETED' },
    { id: 'ORD-892143', type: 'STORE', title: 'Golden Sovereign Avatar Frame', amount: '-12,000 🪙', price: 'Coins', date: '2026-08-21 18:40', status: 'COMPLETED' },
    { id: 'ORD-892142', type: 'EXCHANGE', title: 'Diamonds to Coins Exchange', amount: '+20,000 🪙', price: '10,000 💎', date: '2026-08-20 14:15', status: 'COMPLETED' },
    { id: 'ORD-892141', type: 'GIFT', title: 'Super Rocket Gift to Host', amount: '-5,000 🪙', price: 'Coins', date: '2026-08-19 22:05', status: 'COMPLETED' },
    { id: 'ORD-892140', type: 'TOPUP', title: 'Coin Top-up (100,000 Coins)', amount: '+100,000 🪙', price: '$99.99', date: '2026-08-18 09:30', status: 'COMPLETED' }
  ];

  const displayOrders = sampleOrders.filter(o => filterType === 'ALL' || o.type === filterType);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-950 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-rose-400 shadow-md">
              <FolderArchive className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-base font-black text-white">Orders & Transaction Logs</h2>
              <p className="text-xs text-neutral-400">View your complete billing, top-ups and store records</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="p-4 border-b border-neutral-800 flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {[
            { key: 'ALL', label: 'All Orders' },
            { key: 'TOPUP', label: 'Top-ups' },
            { key: 'STORE', label: 'Store Items' },
            { key: 'EXCHANGE', label: 'Exchanges' },
            { key: 'GIFT', label: 'Gifts' }
          ].map(f => (
            <button
              key={f.key}
              onClick={() => {
                setFilterType(f.key as any);
                playSoundFX('click');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                filterType === f.key
                  ? 'bg-rose-600 text-white border-rose-500 shadow-md'
                  : 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:bg-neutral-800'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Orders List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {displayOrders.map((order) => (
            <div 
              key={order.id}
              className="p-3.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 hover:border-neutral-700 transition-all flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                  order.amount.startsWith('+') ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                }`}>
                  {order.amount.startsWith('+') ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                </div>

                <div>
                  <h4 className="text-xs font-bold text-white leading-tight">{order.title}</h4>
                  <div className="flex items-center gap-2 mt-1 text-[10px] text-neutral-400 font-mono">
                    <span>{order.id}</span>
                    <span>•</span>
                    <span>{order.date}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <p className={`text-xs font-black font-mono ${order.amount.startsWith('+') ? 'text-emerald-400' : 'text-amber-300'}`}>
                  {order.amount}
                </p>
                <span className="text-[10px] text-neutral-500 font-mono block mt-0.5">
                  {order.price}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
