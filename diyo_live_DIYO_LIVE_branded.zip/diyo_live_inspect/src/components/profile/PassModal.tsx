import React, { useState } from 'react';
import { 
  X, 
  Crown, 
  Sparkles, 
  Check, 
  Lock, 
  Gift, 
  Zap, 
  Moon, 
  Coins, 
  Gem, 
  Star,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface PassModalProps {
  isOpen: boolean;
  onClose: () => void;
  userPassLevel?: number;
  userPassXp?: number;
  isVipPassUnlocked?: boolean;
  onUnlockVipPass?: () => void;
  onClaimReward?: (tier: number, isVip: boolean) => void;
}

interface PassRewardTier {
  level: number;
  requiredXp: number;
  freeReward: { title: string; icon: string; count: string; type: 'COIN' | 'GIFT' | 'FRAME' };
  vipReward: { title: string; icon: string; count: string; type: 'COIN' | 'DIAMOND' | 'MOUNT' | 'FRAME' };
}

const PASS_TIERS: PassRewardTier[] = [
  { level: 1, requiredXp: 100, freeReward: { title: 'Welcome Coins', icon: '🪙', count: '1,000 Coins', type: 'COIN' }, vipReward: { title: 'Neon Moonlight Frame', icon: '✨', count: '7 Days', type: 'FRAME' } },
  { level: 2, requiredXp: 250, freeReward: { title: 'Lucky Rose', icon: '🌹', count: 'x10 Gifts', type: 'GIFT' }, vipReward: { title: 'Royal Diamonds', icon: '💎', count: '500 Diamonds', type: 'DIAMOND' } },
  { level: 3, requiredXp: 500, freeReward: { title: 'Silver Speaker', icon: '📢', count: 'x5 Loudspeakers', type: 'GIFT' }, vipReward: { title: 'Cyber Dragon Entrance', icon: '🐉', count: '15 Days Mount', type: 'MOUNT' } },
  { level: 4, requiredXp: 800, freeReward: { title: 'Level XP Card', icon: '⚡', count: '+5,000 XP', type: 'COIN' }, vipReward: { title: 'Imperial Coins', icon: '🪙', count: '25,000 Coins', type: 'COIN' } },
  { level: 5, requiredXp: 1200, freeReward: { title: 'Golden Heart', icon: '💛', count: 'x20 Gifts', type: 'GIFT' }, vipReward: { title: 'Golden Sovereign Crown', icon: '👑', count: 'Permanent Avatar Frame', type: 'FRAME' } },
  { level: 6, requiredXp: 1800, freeReward: { title: 'Bonus Coins', icon: '🪙', count: '5,000 Coins', type: 'COIN' }, vipReward: { title: 'Mega Diamond Vault', icon: '💎', count: '2,500 Diamonds', type: 'DIAMOND' } }
];

export const PassModal: React.FC<PassModalProps> = ({
  isOpen,
  onClose,
  userPassLevel = 3,
  userPassXp = 650,
  isVipPassUnlocked = false,
  onUnlockVipPass,
  onClaimReward
}) => {
  const [activeTab, setActiveTab] = useState<'REWARDS' | 'QUESTS'>('REWARDS');
  const [claimedFree, setClaimedFree] = useState<number[]>([1, 2]);
  const [claimedVip, setClaimedVip] = useState<number[]>([]);
  const [isVipUnlocked, setIsVipUnlocked] = useState(isVipPassUnlocked);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleClaim = (tier: number, isVip: boolean) => {
    if (isVip && !isVipUnlocked) {
      playSoundFX('notification');
      setToastMsg('Unlock Royal Pass to claim elite VIP rewards!');
      setTimeout(() => setToastMsg(null), 2500);
      return;
    }

    if (isVip) {
      if (claimedVip.includes(tier)) return;
      setClaimedVip(prev => [...prev, tier]);
    } else {
      if (claimedFree.includes(tier)) return;
      setClaimedFree(prev => [...prev, tier]);
    }

    playSoundFX('reward');
    confetti({ particleCount: 40, spread: 60 });
    setToastMsg(`Claimed Level ${tier} ${isVip ? 'VIP' : 'Free'} Reward!`);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleUnlockVip = () => {
    setIsVipUnlocked(true);
    if (onUnlockVipPass) onUnlockVipPass();
    playSoundFX('superchat');
    confetti({ particleCount: 70, spread: 90 });
    setToastMsg('Royal Monthly Pass Unlocked! Elite track active.');
    setTimeout(() => setToastMsg(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-[#1c122c] via-neutral-900 to-neutral-950 border border-purple-500/40 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header with Monthly Pass Artwork */}
        <div className="relative p-5 bg-gradient-to-r from-purple-900 via-indigo-900 to-purple-950 border-b border-purple-500/30 overflow-hidden">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-purple-500/20 rounded-full blur-3xl" />
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button 
              onClick={onClose}
              className="p-1.5 rounded-xl bg-black/40 hover:bg-black/60 text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-amber-300 shadow-xl shadow-purple-950/60 border border-purple-400/40">
              <Moon className="w-7 h-7 fill-amber-400 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">SR Royal Season Pass</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-500/30 text-purple-300 border border-purple-400/40">
                  SEASON 12
                </span>
              </div>
              <p className="text-xs text-purple-200/80">Level {userPassLevel} • {userPassXp} Pass XP • Ends in 18 Days</p>
            </div>
          </div>

          {/* Unlock VIP Banner if not unlocked */}
          {!isVipUnlocked && (
            <div className="mt-4 p-3 rounded-2xl bg-neutral-950/70 border border-amber-500/40 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-amber-400 fill-amber-400" />
                <div>
                  <h4 className="text-xs font-black text-white">Unlock Royal VIP Track</h4>
                  <p className="text-[10px] text-amber-200/80">Get permanent avatar frame, 50,000 coins & diamond vault</p>
                </div>
              </div>
              <button
                onClick={handleUnlockVip}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-950/50 cursor-pointer"
              >
                Unlock • 4,999 🪙
              </button>
            </div>
          )}
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-purple-500/20 border border-purple-500/50 text-purple-200 text-xs font-bold text-center animate-in zoom-in-95">
            {toastMsg}
          </div>
        )}

        {/* Tiers List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <div className="grid grid-cols-12 gap-2 text-[11px] font-black text-neutral-400 uppercase tracking-wider px-2 pb-1">
            <span className="col-span-2">Level</span>
            <span className="col-span-5">Free Track</span>
            <span className="col-span-5 text-amber-300">Royal VIP Track 👑</span>
          </div>

          {PASS_TIERS.map((tier) => {
            const isUnlocked = userPassLevel >= tier.level;
            const isFreeClaimed = claimedFree.includes(tier.level);
            const isVipClaimed = claimedVip.includes(tier.level);

            return (
              <div 
                key={tier.level}
                className={`grid grid-cols-12 gap-2 p-3 rounded-2xl border items-center transition-all ${
                  isUnlocked 
                    ? 'bg-neutral-950/80 border-purple-500/30' 
                    : 'bg-neutral-950/40 border-neutral-900 opacity-70'
                }`}
              >
                {/* Level Column */}
                <div className="col-span-2 flex flex-col items-center justify-center">
                  <span className={`w-8 h-8 rounded-xl flex items-center justify-center font-mono font-black text-xs ${
                    isUnlocked ? 'bg-purple-600 text-white shadow-md' : 'bg-neutral-800 text-neutral-500'
                  }`}>
                    {tier.level}
                  </span>
                  <span className="text-[9px] text-neutral-500 font-mono mt-0.5">{tier.requiredXp} XP</span>
                </div>

                {/* Free Reward */}
                <div className="col-span-5 p-2 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base">{tier.freeReward.icon}</span>
                    <div className="truncate">
                      <p className="text-[11px] font-bold text-white truncate">{tier.freeReward.title}</p>
                      <p className="text-[9px] text-neutral-400 truncate">{tier.freeReward.count}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleClaim(tier.level, false)}
                    disabled={!isUnlocked || isFreeClaimed}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                      isFreeClaimed
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : isUnlocked
                        ? 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow'
                        : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                    }`}
                  >
                    {isFreeClaimed ? 'Claimed' : isUnlocked ? 'Claim' : 'Locked'}
                  </button>
                </div>

                {/* VIP Reward */}
                <div className="col-span-5 p-2 rounded-xl bg-amber-950/20 border border-amber-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base">{tier.vipReward.icon}</span>
                    <div className="truncate">
                      <p className="text-[11px] font-bold text-amber-200 truncate">{tier.vipReward.title}</p>
                      <p className="text-[9px] text-amber-300/80 truncate">{tier.vipReward.count}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleClaim(tier.level, true)}
                    disabled={!isUnlocked || isVipClaimed}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                      isVipClaimed
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : !isVipUnlocked
                        ? 'bg-neutral-800 text-amber-400 border border-amber-500/40 flex items-center gap-0.5'
                        : isUnlocked
                        ? 'bg-amber-500 hover:bg-amber-400 text-neutral-950 shadow'
                        : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                    }`}
                  >
                    {isVipClaimed ? 'Claimed' : !isVipUnlocked ? <><Lock className="w-2.5 h-2.5" /> VIP</> : isUnlocked ? 'Claim' : 'Locked'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
