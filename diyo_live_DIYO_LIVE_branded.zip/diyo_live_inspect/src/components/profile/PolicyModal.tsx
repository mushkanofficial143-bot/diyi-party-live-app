import React, { useState } from 'react';
import { X, FileText, Award, DollarSign, Users, Sparkles, TrendingUp, ShieldCheck } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface PolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PolicyModal: React.FC<PolicyModalProps> = ({ isOpen, onClose }) => {
  const [activeSection, setActiveSection] = useState<number>(1);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-amber-500/30 rounded-3xl w-full max-w-4xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl shadow-amber-950/40 relative">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-600 flex items-center justify-center text-neutral-950 font-black shadow-lg">
              <Award className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-black text-white font-['Outfit'] tracking-wide">DIYO LIVE OFFICIAL POLICY</h2>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold">Effective: 2026</span>
              </div>
              <p className="text-xs text-neutral-400">Official Host & Agency Commission Policy • Settlement: Daily • Withdrawal: Weekly</p>
            </div>
          </div>
          <button
            onClick={() => { playSoundFX('click'); onClose(); }}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 px-6 py-3 bg-neutral-950 border-b border-neutral-800 text-xs">
          <div className="p-2 rounded-xl bg-neutral-900/80 border border-white/5">
            <span className="text-neutral-400 text-[10px] block font-medium">Host Gift Share</span>
            <span className="font-bold text-amber-400">70% of Points</span>
          </div>
          <div className="p-2 rounded-xl bg-neutral-900/80 border border-white/5">
            <span className="text-neutral-400 text-[10px] block font-medium">Official Rate</span>
            <span className="font-bold text-emerald-400">$1 = 50,000 Coins</span>
          </div>
          <div className="p-2 rounded-xl bg-neutral-900/80 border border-white/5">
            <span className="text-neutral-400 text-[10px] block font-medium">Host Exchange</span>
            <span className="font-bold text-cyan-400">70,000 Pts = $1 USD</span>
          </div>
          <div className="p-2 rounded-xl bg-neutral-900/80 border border-white/5">
            <span className="text-neutral-400 text-[10px] block font-medium">Agent Commission</span>
            <span className="font-bold text-purple-400">Up to 21%</span>
          </div>
        </div>

        {/* Section Navigation Tabs */}
        <div className="flex overflow-x-auto border-b border-neutral-800 bg-neutral-950/60 px-4 py-2 gap-1.5 scrollbar-none">
          {[
            { id: 1, label: '01. Host Salary' },
            { id: 2, label: '02. Agent Commission' },
            { id: 3, label: '03. Agency Opening' },
            { id: 4, label: '04. New Host Reward' },
            { id: 5, label: '05. Host Invitation' },
            { id: 6, label: '06. Broadcaster Weekly' },
            { id: 7, label: '07. Reseller Policy' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => { playSoundFX('click'); setActiveSection(tab.id); }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeSection === tab.id
                  ? 'bg-amber-500 text-neutral-950 font-black shadow-md'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-neutral-300 text-xs">
          
          {/* SECTION 1 */}
          {activeSection === 1 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-1.5">
                <h3 className="text-sm font-black text-amber-400 flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-amber-400" /> 01. BASIC HOST SALARY POLICY
                </h3>
                <p className="text-neutral-300">
                  Voice room and video hosts receive 70% of points from gifts. Hosts can exchange points directly to salary (70,000 Points = $1 USD). Daily calculation with weekly cash-outs.
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900/60">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-neutral-800 bg-neutral-900 text-neutral-400 font-mono text-[11px]">
                      <th className="p-3">LEVEL</th>
                      <th className="p-3">TARGET POINTS</th>
                      <th className="p-3 text-right">BASE SALARY ($ USD)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/60">
                    {[
                      { level: 'Level 1', pts: '70,000', salary: '$1' },
                      { level: 'Level 2', pts: '700,000', salary: '$10' },
                      { level: 'Level 3', pts: '1,400,000', salary: '$20' },
                      { level: 'Level 4', pts: '3,500,000', salary: '$50' },
                      { level: 'Level 5', pts: '7,000,000', salary: '$100' },
                      { level: 'Level 6', pts: '35,000,000', salary: '$500' },
                      { level: 'Level 7', pts: '70,000,000', salary: '$1,000' },
                    ].map((row, idx) => (
                      <tr key={idx} className="hover:bg-neutral-800/40 transition-colors">
                        <td className="p-3 font-bold text-white">{row.level}</td>
                        <td className="p-3 font-mono text-cyan-400">{row.pts}</td>
                        <td className="p-3 text-right font-black text-amber-400">{row.salary}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SECTION 2 */}
          {activeSection === 2 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-purple-950/20 border border-purple-500/30 space-y-1.5">
                <h3 className="text-sm font-black text-purple-400 flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-400" /> 02. AGENT COMMISSION & GRADE PERFORMANCE BONUS
                </h3>
                <p className="text-neutral-300">
                  Agency commission is calculated based on total gifts received by all agency hosts and paid every Monday. If agency weekly points are below 3.5M, commission is calculated at 17%. Grade rewards are paid bi-monthly (every 15 days).
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900/60">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-neutral-800 bg-neutral-900 text-neutral-400 font-mono text-[11px]">
                      <th className="p-3">WEEKLY AGENCY POINTS</th>
                      <th className="p-3">COMMISSION RATE</th>
                      <th className="p-3">15-DAY GRADE</th>
                      <th className="p-3">GRADE TARGET POINTS</th>
                      <th className="p-3 text-right">BI-MONTHLY GRADE BONUS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/60">
                    {[
                      { pts: 'Below 3,500,000', rate: '17%', grade: '—', target: '—', bonus: '—' },
                      { pts: '3,500,000', rate: '18%', grade: 'Grade A', target: '35,000,000', bonus: '$20 (1,400,000 Pts)' },
                      { pts: '10,500,000', rate: '19%', grade: 'Grade AA', target: '105,000,000', bonus: '$60 (4,200,000 Pts)' },
                      { pts: '17,500,000', rate: '20%', grade: 'Grade AAA', target: '175,000,000', bonus: '$100 (7,000,000 Pts)' },
                      { pts: '35,000,000', rate: '21%', grade: 'Grade AAAA', target: '350,000,000', bonus: '$200 (14,000,000 Pts)' },
                    ].map((row, idx) => (
                      <tr key={idx} className="hover:bg-neutral-800/40 transition-colors">
                        <td className="p-3 font-mono text-cyan-400">{row.pts}</td>
                        <td className="p-3 font-bold text-white">{row.rate}</td>
                        <td className="p-3 text-emerald-400 font-bold">{row.grade}</td>
                        <td className="p-3 font-mono text-neutral-300">{row.target}</td>
                        <td className="p-3 text-right font-black text-amber-400">{row.bonus}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SECTION 3 */}
          {activeSection === 3 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-1.5">
                <h3 className="text-sm font-black text-emerald-400 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" /> 03. AGENCY OPENING CEREMONY REWARDS
                </h3>
                <p className="text-neutral-300">
                  Must be held within 1 week from agency registration date. Agency must fulfill diamond points and anchor counts simultaneously.
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900/60">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-neutral-800 bg-neutral-900 text-neutral-400 font-mono text-[11px]">
                      <th className="p-3">AGENCY LEVEL</th>
                      <th className="p-3">VIP REQ.</th>
                      <th className="p-3">TARGET POINTS</th>
                      <th className="p-3">PART A BONUS COINS</th>
                      <th className="p-3">PART B MONTHLY BONUS ($)</th>
                      <th className="p-3">ACTIVE ANCHORS</th>
                      <th className="p-3 text-right">TOTAL VALUE</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/60">
                    {[
                      { level: 'A-Agency', vip: 'VIP7', target: '70,000,000', partA: '12,500,000', partB: '$100 (7.0M Pts)', anchors: '20', total: '22.5M Pts' },
                      { level: 'B-Agency', vip: 'VIP6', target: '35,000,000', partA: '7,500,000', partB: '$64 (4.5M Pts)', anchors: '15', total: '12.0M Pts' },
                      { level: 'C-Agency', vip: 'VIP5', target: '17,500,000', partA: '5,000,000', partB: '$28 (2.0M Pts)', anchors: '10', total: '7.0M Pts' },
                      { level: 'D-Agency', vip: 'VIP4', target: '7,000,000', partA: '2,500,000', partB: '$10 (0.75M Pts)', anchors: '5', total: '3.25M Pts' },
                    ].map((row, idx) => (
                      <tr key={idx} className="hover:bg-neutral-800/40 transition-colors">
                        <td className="p-3 font-bold text-white">{row.level}</td>
                        <td className="p-3 text-amber-400 font-bold">{row.vip}</td>
                        <td className="p-3 font-mono text-cyan-400">{row.target}</td>
                        <td className="p-3 font-mono text-neutral-300">{row.partA}</td>
                        <td className="p-3 font-mono text-neutral-300">{row.partB}</td>
                        <td className="p-3 font-bold text-white">{row.anchors}</td>
                        <td className="p-3 text-right font-black text-emerald-400">{row.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SECTION 4 & 5 */}
          {activeSection === 4 && (
            <div className="space-y-6 animate-in fade-in">
              <div className="space-y-3">
                <h3 className="text-sm font-black text-cyan-400">04. FIRST WEEK NEW HOST REWARD</h3>
                <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900/60">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-neutral-800 bg-neutral-900 text-neutral-400 font-mono text-[11px]">
                        <th className="p-3">STREAMING HOURS</th>
                        <th className="p-3">TARGET / DAY</th>
                        <th className="p-3 text-right">DAILY REWARD</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-800/60">
                      <tr className="hover:bg-neutral-800/40">
                        <td className="p-3 font-bold text-white">Day 1 to Day 7</td>
                        <td className="p-3 font-mono text-cyan-400">1 Hr + 70k Pts ($1)</td>
                        <td className="p-3 text-right font-black text-amber-400">$2 / Day ($14 Max Bonus Total)</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <h3 className="text-sm font-black text-indigo-400">05. HOST INVITATION REWARDS</h3>
                <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900/60">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-neutral-800 bg-neutral-900 text-neutral-400 font-mono text-[11px]">
                        <th className="p-3">HOST HOURS</th>
                        <th className="p-3">RECEIVED GIFTS</th>
                        <th className="p-3 text-right">INVITER REWARD</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-800/60">
                      {[
                        { hours: '1 Hour', gifts: '1,400,000 Pts', reward: '70,000 Pts ($1)' },
                        { hours: '5 Hours', gifts: '3,500,000 Pts', reward: '210,000 Pts ($3)' },
                        { hours: '10 Hours', gifts: '7,000,000 Pts', reward: '350,000 Pts ($5)' },
                      ].map((row, idx) => (
                        <tr key={idx} className="hover:bg-neutral-800/40">
                          <td className="p-3 font-bold text-white">{row.hours}</td>
                          <td className="p-3 font-mono text-cyan-400">{row.gifts}</td>
                          <td className="p-3 text-right font-black text-emerald-400">{row.reward}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 6 */}
          {activeSection === 6 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/30 space-y-1.5">
                <h3 className="text-sm font-black text-indigo-400 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-indigo-400" /> 06. HIGH-QUALITY BROADCASTER WEEKLY REWARDS
                </h3>
                <p className="text-neutral-300">
                  Resets every Monday at 00:01 Saudi Time. Broadcasters must meet both streaming duration and point requirements.
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900/60 max-h-[50vh]">
                <table className="w-full text-left border-collapse">
                  <thead className="sticky top-0 bg-neutral-900">
                    <tr className="border-b border-neutral-800 text-neutral-400 font-mono text-[11px]">
                      <th className="p-3">LEVEL</th>
                      <th className="p-3">WEEKLY POINTS TARGET</th>
                      <th className="p-3">HOURS</th>
                      <th className="p-3">LEVEL REWARD</th>
                      <th className="p-3">HOURLY POINT REWARD</th>
                      <th className="p-3 text-right">TOTAL EXTRA REWARD</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/60">
                    {[
                      { level: 'Level 1', weekly: '700,000', hours: '3 Hrs', reward: '40,000', hourly: '13,333', total: '40,000 Pts' },
                      { level: 'Level 2', weekly: '1,750,000', hours: '3 Hrs', reward: '50,000', hourly: '16,667', total: '90,000 Pts' },
                      { level: 'Level 3', weekly: '4,200,000', hours: '3 Hrs', reward: '130,000', hourly: '43,333', total: '220,000 Pts' },
                      { level: 'Level 4', weekly: '7,000,000', hours: '3 Hrs', reward: '180,000', hourly: '60,000', total: '400,000 Pts' },
                      { level: 'Level 5', weekly: '14,000,000', hours: '3 Hrs', reward: '300,000', hourly: '100,000', total: '700,000 Pts' },
                      { level: 'Level 6', weekly: '21,000,000', hours: '3 Hrs', reward: '400,000', hourly: '133,333', total: '1,100,000 Pts' },
                      { level: 'Level 7', weekly: '28,000,000', hours: '3 Hrs', reward: '420,000', hourly: '140,000', total: '1,520,000 Pts' },
                      { level: 'Level 8', weekly: '35,000,000', hours: '3 Hrs', reward: '480,000', hourly: '160,000', total: '2,000,000 Pts' },
                      { level: 'Level 9', weekly: '49,000,000', hours: '3 Hrs', reward: '700,000', hourly: '175,000', total: '2,700,000 Pts' },
                      { level: 'Level 10', weekly: '70,000,000', hours: '4 Hrs', reward: '1,100,000', hourly: '275,000', total: '3,800,000 Pts' },
                      { level: 'Level 11', weekly: '140,000,000', hours: '4 Hrs', reward: '3,200,000', hourly: '800,000', total: '7,000,000 Pts' },
                      { level: 'Level 12', weekly: '210,000,000', hours: '4 Hrs', reward: '4,000,000', hourly: '1,000,000', total: '11,000,000 Pts' },
                    ].map((row, idx) => (
                      <tr key={idx} className="hover:bg-neutral-800/45 transition-colors">
                        <td className="p-3 font-bold text-white">{row.level}</td>
                        <td className="p-3 font-mono text-cyan-400">{row.weekly}</td>
                        <td className="p-3 text-neutral-300">{row.hours}</td>
                        <td className="p-3 font-mono text-neutral-300">{row.reward}</td>
                        <td className="p-3 font-mono text-neutral-400">{row.hourly}</td>
                        <td className="p-3 text-right font-black text-amber-400">{row.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SECTION 7 */}
          {activeSection === 7 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-1.5">
                <h3 className="text-sm font-black text-cyan-400 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400" /> 07. RESELLER SUPER BENEFITS & RECHARGE POLICY
                </h3>
                <p className="text-neutral-300">
                  Authorized coin resellers receive bonus coin percentages and enhanced effective exchange rates.
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900/60">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-neutral-800 bg-neutral-900 text-neutral-400 font-mono text-[11px]">
                      <th className="p-3">RECHARGE AMOUNT ($ USD)</th>
                      <th className="p-3">BASE COINS</th>
                      <th className="p-3">BONUS %</th>
                      <th className="p-3">EXTRA BONUS COINS</th>
                      <th className="p-3">TOTAL COINS ISSUED</th>
                      <th className="p-3 text-right">EFFECTIVE EXCHANGE RATE</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/60">
                    {[
                      { amount: '$1,000', base: '50,000,000', bonus: '20%', extra: '10,000,000', total: '60,000,000', rate: '$1 = 60,000 Coins' },
                      { amount: '$3,000', base: '150,000,000', bonus: '25%', extra: '37,500,000', total: '187,500,000', rate: '$1 = 62,500 Coins' },
                      { amount: '$10,000', base: '500,000,000', bonus: '30%', extra: '150,000,000', total: '650,000,000', rate: '$1 = 65,000 Coins' },
                      { amount: '$30,000', base: '1,500,000,000', bonus: '35%', extra: '525,000,000', total: '2,025,000,000', rate: '$1 = 67,500 Coins' },
                      { amount: '$50,000', base: '2,500,000,000', bonus: '40%', extra: '1,000,000,000', total: '3,500,000,000', rate: '$1 = 70,000 Coins' },
                    ].map((row, idx) => (
                      <tr key={idx} className="hover:bg-neutral-800/40 transition-colors">
                        <td className="p-3 font-bold text-white">{row.amount}</td>
                        <td className="p-3 font-mono text-neutral-300">{row.base}</td>
                        <td className="p-3 text-amber-400 font-bold">{row.bonus}</td>
                        <td className="p-3 font-mono text-cyan-400">{row.extra}</td>
                        <td className="p-3 font-mono text-emerald-400 font-bold">{row.total}</td>
                        <td className="p-3 text-right font-black text-purple-400">{row.rate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-neutral-800 bg-neutral-900/90 flex items-center justify-between">
          <span className="text-[11px] text-neutral-400 font-mono">DIYO LIVE Official Policy Document • Confidential & Official</span>
          <button
            onClick={() => { playSoundFX('click'); onClose(); }}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-neutral-950 font-black text-xs transition-all shadow-md"
          >
            I Understand & Agree
          </button>
        </div>

      </div>
    </div>
  );
};
