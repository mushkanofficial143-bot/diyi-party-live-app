import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, 
  Upload, 
  ZoomIn, 
  ZoomOut, 
  RotateCw, 
  Check, 
  X, 
  Image as ImageIcon, 
  Sparkles, 
  RefreshCw,
  Video,
  VideoOff,
  Disc
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface ProfilePhotoCropperModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAvatar: string;
  onSaveAvatar: (newAvatarUrl: string) => void;
}

const PRESET_HD_AVATARS = [
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80'
];

export const ProfilePhotoCropperModal: React.FC<ProfilePhotoCropperModalProps> = ({
  isOpen,
  onClose,
  currentAvatar,
  onSaveAvatar
}) => {
  const [selectedImage, setSelectedImage] = useState<string>(currentAvatar);
  const [zoom, setZoom] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!isOpen && isCameraActive) {
      stopCamera();
    }
  }, [isOpen]);

  const startCamera = async () => {
    try {
      setCameraError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 640 } }
      });
      streamRef.current = stream;
      setIsCameraActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      playSoundFX('click');
    } catch (err: any) {
      console.error('Camera access failed', err);
      setCameraError('Camera access denied or unavailable on this device.');
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 480;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        setSelectedImage(dataUrl);
        setZoom(1);
        setRotation(0);
        stopCamera();
        playSoundFX('win');
      }
    }
  };

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setSelectedImage(reader.result);
          setZoom(1);
          setRotation(0);
          if (isCameraActive) stopCamera();
          playSoundFX('click');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    playSoundFX('success');
    if (isCameraActive) stopCamera();
    onSaveAvatar(selectedImage);
    onClose();
  };

  const handleClose = () => {
    if (isCameraActive) stopCamera();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-xl animate-in fade-in">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl text-neutral-100 overflow-hidden space-y-5">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-md shadow-emerald-950/40">
              <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center">
                <Camera className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <h2 className="font-['Outfit'] font-black text-base text-white flex items-center gap-2">
                <span>Profile Photo & Avatar Studio</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  HD 4K
                </span>
              </h2>
              <p className="text-xs text-neutral-400">Take selfie, upload photo, or pick from VIP presets</p>
            </div>
          </div>
          <button
            id="btn-close-cropper"
            onClick={handleClose}
            className="p-2 text-neutral-400 hover:text-white rounded-full bg-neutral-800 hover:bg-neutral-700 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Cropping Preview or Live Camera Stage */}
        <div className="flex flex-col items-center justify-center space-y-4 py-1">
          
          {isCameraActive ? (
            <div className="relative w-52 h-52 rounded-full overflow-hidden border-4 border-amber-400 shadow-2xl bg-black flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20">
                <button
                  id="btn-take-selfie-snapshot"
                  onClick={capturePhoto}
                  className="px-4 py-1.5 rounded-full bg-amber-400 hover:bg-amber-300 text-black font-black text-xs uppercase flex items-center gap-1.5 shadow-lg shadow-amber-950 cursor-pointer animate-pulse"
                >
                  <Disc className="w-4 h-4" />
                  <span>Snap Photo</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-emerald-500/80 shadow-2xl shadow-emerald-950/60 bg-neutral-950 flex items-center justify-center">
              <img
                src={selectedImage}
                alt="Avatar Preview"
                className="w-full h-full object-cover transition-transform duration-200"
                style={{
                  transform: `scale(${zoom}) rotate(${rotation}deg)`
                }}
              />
              <div className="absolute inset-0 border border-dashed border-white/25 pointer-events-none rounded-full" />
            </div>
          )}

          {cameraError && (
            <p className="text-xs text-rose-400 font-medium bg-rose-950/40 border border-rose-500/30 px-3 py-1.5 rounded-xl">
              {cameraError}
            </p>
          )}

          {/* Adjust Controls */}
          {!isCameraActive && (
            <div className="w-full max-w-xs flex items-center justify-between gap-3 bg-neutral-950/80 border border-neutral-800 rounded-2xl px-4 py-2">
              <button
                onClick={() => setZoom(prev => Math.max(0.8, prev - 0.1))}
                className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <input
                type="range"
                min="0.8"
                max="2.5"
                step="0.05"
                value={zoom}
                onChange={(e) => setZoom(parseFloat(e.target.value))}
                className="flex-1 accent-emerald-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
              />
              <button
                onClick={() => setZoom(prev => Math.min(2.5, prev + 0.1))}
                className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setRotation(prev => (prev + 90) % 360)}
                className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 ml-1 cursor-pointer"
                title="Rotate 90°"
              >
                <RotateCw className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Action Buttons: Upload File or Camera */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload}
          />
          <button
            id="btn-upload-local-photo"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-2xl bg-neutral-800/90 hover:bg-neutral-700 text-neutral-200 hover:text-white text-xs font-bold transition-all border border-neutral-700 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span>Upload Photo</span>
          </button>

          <button
            id="btn-camera-toggle"
            onClick={() => {
              if (isCameraActive) {
                stopCamera();
              } else {
                startCamera();
              }
            }}
            className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-2xl text-xs font-bold transition-all border cursor-pointer ${
              isCameraActive
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                : 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-500/40'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{isCameraActive ? 'Cancel Cam' : 'Take Selfie'}</span>
          </button>

          <button
            onClick={() => {
              setSelectedImage(PRESET_HD_AVATARS[0]);
              setZoom(1);
              setRotation(0);
              if (isCameraActive) stopCamera();
              playSoundFX('click');
            }}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-2xl bg-neutral-800/90 hover:bg-neutral-700 text-neutral-200 hover:text-white text-xs font-bold transition-all border border-neutral-700 cursor-pointer col-span-2 sm:col-span-1"
          >
            <RefreshCw className="w-3.5 h-3.5 text-neutral-400" />
            <span>Reset</span>
          </button>
        </div>

        {/* HD Avatar Gallery Presets */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Choose from HD VIP Avatar Presets:</span>
          </label>
          <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
            {PRESET_HD_AVATARS.map((avatarUrl, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setSelectedImage(avatarUrl);
                  setZoom(1);
                  setRotation(0);
                  if (isCameraActive) stopCamera();
                  playSoundFX('click');
                }}
                className={`relative aspect-square rounded-2xl overflow-hidden border-2 transition-all p-0.5 cursor-pointer ${
                  selectedImage === avatarUrl && !isCameraActive
                    ? 'border-emerald-400 ring-2 ring-emerald-400/40 scale-105 shadow-md shadow-emerald-950/60'
                    : 'border-neutral-800 hover:border-neutral-600 opacity-80 hover:opacity-100'
                }`}
              >
                <img src={avatarUrl} alt={`Preset ${idx + 1}`} className="w-full h-full object-cover rounded-[12px]" />
              </button>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-800">
          <button
            onClick={handleClose}
            className="px-5 py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            id="btn-save-crop-avatar"
            onClick={handleSave}
            className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-neutral-950 text-xs font-black tracking-wider uppercase shadow-lg shadow-emerald-950/60 flex items-center gap-2 transition-all cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>Save & Apply Photo</span>
          </button>
        </div>

      </div>
    </div>
  );
};
