import React, { useState } from 'react';
import { 
  Folder, 
  Tv, 
  Users, 
  UserCheck, 
  ShieldCheck, 
  ChevronRight, 
  Coins, 
  Gem, 
  Shield, 
  ShoppingBag, 
  Award, 
  Star, 
  Moon, 
  Trophy,
  Sparkles,
  Settings,
  Crown
} from 'lucide-react';
import { UserAccount, VipTierConfig, WalletTransaction, UserRole, PlatformWalletSettings } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

// Sub-modals
import { EditProfileModal } from './EditProfileModal';
import { WalletModal } from './WalletModal';
import { StoreModal } from './StoreModal';
import { HostCenterModal } from './HostCenterModal';
import { LevelModal } from './LevelModal';
import { SettingsModal } from './SettingsModal';
import { InviteModal } from './InviteModal';
import { RewardModal } from './RewardModal';
import { VipUpgradeModal } from './VipUpgradeModal';
import { GuardianModal } from './GuardianModal';
import { FanClubModal } from './FanClubModal';
import { OrdersModal } from './OrdersModal';
import { AgencyModal } from './AgencyModal';
import { SellerModal } from './SellerModal';
import { VerificationModal } from './VerificationModal';
import { SpecialIdModal } from './SpecialIdModal';
import { BadgeTagsShowcase } from '../badges/BadgeTagsShowcase';
import { SRLiveProfileHeader } from './SRLiveProfileHeader';

interface ProfileScreenProps {
  currentUser: UserAccount;
  vipConfigs: VipTierConfig[];
  transactions: WalletTransaction[];
  currentRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  onOpenOwnerPanel: () => void;
  onGoLiveClick: () => void;
  onUpdateUserBalance: (newCoins: number, newDiamonds: number) => void;
  onUpdateUserProfile: (updated: { name: string; username: string; avatar: string; bio?: string; countryCode?: string; countryFlag?: string; countryName?: string }) => void;
  onUpgradeVip: (level: number) => void;
  onEquipAvatarFrame?: (frameId: string, frameUrl?: string, roleType?: any, hostTag?: string) => void;
  onTransferCoins?: (recipientId: string, amount: number, notes?: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  onExchangeCoins?: (amount: number) => Promise<{ success: boolean; error?: string; message?: string }>;
  walletSettings?: PlatformWalletSettings;
  platformUsers?: any[];
  agencies?: any[];
  agencyJoinRequests?: any[];
  onUpdateAgencyRequests?: (reqs: any[]) => void;
  onUpdateUserAgencyMembership?: (membership: any) => void;
  onAddAuditLog?: (log: any) => void;
  onAddNotification?: (notif: any) => void;
  onNavigateTab?: (tab: string) => void;
  onLogout?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  currentUser,
  vipConfigs,
  transactions,
  currentRole,
  onChangeRole,
  onOpenOwnerPanel,
  onGoLiveClick,
  onUpdateUserBalance,
  onUpdateUserProfile,
  onUpgradeVip,
  onTransferCoins,
  onExchangeCoins,
  walletSettings,
  platformUsers,
  agencies = [],
  agencyJoinRequests = [],
  onUpdateAgencyRequests = () => {},
  onUpdateUserAgencyMembership = () => {},
  onAddAuditLog = () => {},
  onAddNotification = () => {},
  onNavigateTab,
  onLogout
}) => {
  // Modal states
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [walletDefaultTab, setWalletDefaultTab] = useState<'RECHARGE' | 'EXCHANGE' | 'WITHDRAW'>('RECHARGE');
  const [isStoreOpen, setIsStoreOpen] = useState(false);
  const [isLevelOpen, setIsLevelOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isVipModalOpen, setIsVipModalOpen] = useState(false);
  const [isHostCenterOpen, setIsHostCenterOpen] = useState(false);
  const [isGuardianOpen, setIsGuardianOpen] = useState(false);
  const [isFanClubOpen, setIsFanClubOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isAgencyOpen, setIsAgencyOpen] = useState(false);
  const [isSellerOpen, setIsSellerOpen] = useState(false);
  const [isVerificationOpen, setIsVerificationOpen] = useState(false);
  const [isSpecialIdOpen, setIsSpecialIdOpen] = useState(false);
  const [isBadgeModalOpen, setIsBadgeModalOpen] = useState(false);

  const activeUserId = currentUser.id.replace('USR-', '') || '148830743';

  const handleOpenWalletTopUp = () => {
    playSoundFX('click');
    setWalletDefaultTab('RECHARGE');
    setIsWalletOpen(true);
  };

  const handleOpenPointsExchange = () => {
    playSoundFX('click');
    setWalletDefaultTab('EXCHANGE');
    setIsWalletOpen(true);
  };

  return (
    <div className="w-full max-w-md md:max-w-lg mx-auto flex flex-col pb-56 pt-1 text-white select-none animate-in fade-in bg-[#10131d] min-h-screen">
      
      <div className="relative z-10 space-y-3.5 pb-48 pt-2">
      
      {/* 1. TOP PROFILE HEADER (Screenshot match) */}
      <div className="px-3 sm:px-4">
        <SRLiveProfileHeader
          username={currentUser.name || 'DIYO LIVE STREAM'}
          userId={activeUserId}
          countryFlag={currentUser.countryFlag || '🇳🇵'}
          countryCode={currentUser.countryCode || 'NP'}
          countryName={currentUser.countryName || 'Nepal'}
          avatarUrl={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600'}
          followersCount={currentUser.followersCount || 8}
          followingCount={currentUser.followingCount || 8}
          vipLevel={currentUser.vipLevel || 3}
          userLevel={currentUser.userLevel || 42}
          gender={currentUser.gender || 'Male'}
          age={22}
          role={currentUser.role}
          onEditProfile={() => setIsEditProfileOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenVipModal={() => setIsVipModalOpen(true)}
          onOpenLevelModal={() => setIsLevelOpen(true)}
          onOpenFollowers={() => setIsFanClubOpen(true)}
          onOpenFollowing={() => setIsGuardianOpen(true)}
          onUpdateAvatar={(newAvatarUrl) => {
            onUpdateUserProfile({
              name: currentUser.name,
              username: currentUser.username,
              avatar: newAvatarUrl,
              bio: currentUser.bio,
              gender: currentUser.gender,
              dob: currentUser.dob,
              countryCode: currentUser.countryCode,
              countryFlag: currentUser.countryFlag,
              countryName: currentUser.countryName
            });
          }}
        />
      </div>

      {/* 2. TWO BALANCE CARDS (Coin & Diamonds) */}
      <div className="px-3 sm:px-4">
        <div className="grid grid-cols-2 gap-3">
          
          {/* Coin Card */}
          <div 
            onClick={handleOpenWalletTopUp}
            className="p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 shadow-md cursor-pointer transition-all flex items-center justify-between group"
          >
            <div className="space-y-0.5">
              <span className="text-xs text-neutral-400 font-medium">Coin</span>
              <div className="text-lg font-black font-['Outfit'] text-white">
                {currentUser.coinBalance?.toLocaleString() || '70'}
              </div>
            </div>
            <button 
              onClick={(e) => { e.stopPropagation(); handleOpenWalletTopUp(); }}
              className="px-3 py-1 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 text-xs font-black shadow flex items-center gap-1 group-hover:scale-105 transition-transform"
            >
              <span>Top up</span>
              <ChevronRight className="w-3 h-3 stroke-[3]" />
            </button>
          </div>

          {/* Diamonds Card */}
          <div 
            onClick={handleOpenPointsExchange}
            className="p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 shadow-md cursor-pointer transition-all flex items-center justify-between group"
          >
            <div className="space-y-0.5">
              <span className="text-xs text-neutral-400 font-medium">Diamonds</span>
              <div className="text-lg font-black font-['Outfit'] text-amber-300">
                {currentUser.diamondBalance?.toLocaleString() || '145447.7'}
              </div>
            </div>
            <button 
              onClick={(e) => { e.stopPropagation(); handleOpenPointsExchange(); }}
              className="px-3 py-1 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 text-xs font-black shadow flex items-center gap-1 group-hover:scale-105 transition-transform"
            >
              <span>View</span>
              <ChevronRight className="w-3 h-3 stroke-[3]" />
            </button>
          </div>

        </div>
      </div>

      {/* 3. FEATURE GRID (Level, Costume, Special ID, Badge, Store, Pass, Task) */}
      <div className="px-3 sm:px-4">
        <div className="p-4 rounded-2xl bg-[#181d2c] border border-white/5 shadow-md">
          <div className="grid grid-cols-4 gap-y-4 gap-x-2 text-center">
            
            {/* Level */}
            <div onClick={() => { playSoundFX('click'); setIsLevelOpen(true); }} className="flex flex-col items-center gap-1.5 cursor-pointer group">
              <div className="w-12 h-12 rounded-2xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-110 shadow transition-transform">
                <Shield className="w-6 h-6 text-blue-400" />
              </div>
              <span className="text-xs text-neutral-300 font-medium">Level</span>
            </div>

            {/* Costume */}
            <div onClick={() => { playSoundFX('click'); setIsStoreOpen(true); }} className="flex flex-col items-center gap-1.5 cursor-pointer group">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-110 shadow transition-transform">
                <ShoppingBag className="w-6 h-6 text-purple-400" />
              </div>
              <span className="text-xs text-neutral-300 font-medium">Costume</span>
            </div>

            {/* Special ID */}
            <div onClick={() => { playSoundFX('click'); setIsSpecialIdOpen(true); }} className="flex flex-col items-center gap-1.5 cursor-pointer group">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 shadow transition-transform">
                <Award className="w-6 h-6 text-emerald-400" />
              </div>
              <span className="text-xs text-neutral-300 font-medium">Special ID</span>
            </div>

            {/* Badge */}
            <div onClick={() => { playSoundFX('click'); setIsBadgeModalOpen(true); }} className="flex flex-col items-center gap-1.5 cursor-pointer group">
              <div className="w-12 h-12 rounded-2xl bg-pink-500/15 border border-pink-500/30 flex items-center justify-center text-pink-400 group-hover:scale-110 shadow transition-transform">
                <Star className="w-6 h-6 text-pink-400" />
              </div>
              <span className="text-xs text-neutral-300 font-medium">Badge</span>
            </div>

            {/* Store */}
            <div onClick={() => { playSoundFX('click'); setIsStoreOpen(true); }} className="flex flex-col items-center gap-1.5 cursor-pointer group">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-110 shadow transition-transform">
                <ShoppingBag className="w-6 h-6 text-indigo-400" />
              </div>
              <span className="text-xs text-neutral-300 font-medium">Store</span>
            </div>

            {/* Pass */}
            <div onClick={() => { playSoundFX('click'); setIsVipModalOpen(true); }} className="flex flex-col items-center gap-1.5 cursor-pointer group">
              <div className="w-12 h-12 rounded-2xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center text-violet-400 group-hover:scale-110 shadow transition-transform">
                <Moon className="w-6 h-6 text-violet-400" />
              </div>
              <span className="text-xs text-neutral-300 font-medium">Pass</span>
            </div>

            {/* Task */}
            <div onClick={() => { playSoundFX('click'); setIsHostCenterOpen(true); }} className="flex flex-col items-center gap-1.5 cursor-pointer group">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 shadow transition-transform">
                <Trophy className="w-6 h-6 text-emerald-400" />
              </div>
              <span className="text-xs text-neutral-300 font-medium">Task</span>
            </div>

          </div>
        </div>
      </div>

      {/* 4. SYSTEM LIST MENU ITEMS (Orders, Live Center, Agency, Seller, Verification) */}
      <div className="px-3 sm:px-4 space-y-2">
        
        {/* Orders */}
        <div 
          onClick={() => { playSoundFX('click'); setIsOrdersOpen(true); }}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 cursor-pointer transition-all shadow-sm group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <Folder className="w-4 h-4" />
            </div>
            <span className="text-sm font-semibold text-white">Orders</span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
        </div>

        {/* Live Center */}
        <div 
          onClick={() => { playSoundFX('click'); setIsHostCenterOpen(true); }}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 cursor-pointer transition-all shadow-sm group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
              <Tv className="w-4 h-4" />
            </div>
            <span className="text-sm font-semibold text-white">Live Center</span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
        </div>

        {/* Agency */}
        <div 
          onClick={() => { playSoundFX('click'); setIsAgencyOpen(true); }}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 cursor-pointer transition-all shadow-sm group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <span className="text-sm font-semibold text-white">Agency</span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
        </div>

        {/* Seller */}
        <div 
          onClick={() => { playSoundFX('click'); setIsSellerOpen(true); }}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 cursor-pointer transition-all shadow-sm group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <UserCheck className="w-4 h-4" />
            </div>
            <span className="text-sm font-semibold text-white">Seller</span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
        </div>

        {/* Verification */}
        <div 
          onClick={() => { playSoundFX('click'); setIsVerificationOpen(true); }}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 cursor-pointer transition-all shadow-sm group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <span className="text-sm font-semibold text-white">Verification</span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
        </div>

        {/* Settings */}
        <div 
          onClick={() => { playSoundFX('click'); setIsSettingsOpen(true); }}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 cursor-pointer transition-all shadow-sm group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
              <Settings className="w-4 h-4" />
            </div>
            <span className="text-sm font-semibold text-white">Settings</span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
        </div>

        {/* Owner Panel */}
        <div 
          onClick={() => { playSoundFX('click'); onOpenOwnerPanel(); }}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#181d2c] border border-white/5 hover:border-white/15 cursor-pointer transition-all shadow-sm group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Crown className="w-4 h-4" />
            </div>
            <span className="text-sm font-semibold text-white">Owner Panel</span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
        </div>

      </div>

      </div>

      {/* Modals */}
      {isWalletOpen && (
        <WalletModal
          isOpen={isWalletOpen}
          onClose={() => setIsWalletOpen(false)}
          currentUser={currentUser}
          transactions={transactions}
          onUpdateUserBalance={onUpdateUserBalance}
          defaultTab={walletDefaultTab}
        />
      )}

      {isStoreOpen && (
        <StoreModal
          isOpen={isStoreOpen}
          onClose={() => setIsStoreOpen(false)}
          currentUser={currentUser}
          onUpdateUserBalance={onUpdateUserBalance}
        />
      )}

      {isLevelOpen && (
        <LevelModal
          isOpen={isLevelOpen}
          onClose={() => setIsLevelOpen(false)}
          currentUser={currentUser}
        />
      )}

      {isOrdersOpen && (
        <OrdersModal
          isOpen={isOrdersOpen}
          onClose={() => setIsOrdersOpen(false)}
          transactions={transactions}
        />
      )}

      {isAgencyOpen && (
        <AgencyModal
          isOpen={isAgencyOpen}
          onClose={() => setIsAgencyOpen(false)}
          currentUser={currentUser}
          agencies={agencies}
          agencyJoinRequests={agencyJoinRequests}
          onUpdateAgencyRequests={onUpdateAgencyRequests}
          onUpdateUserAgencyMembership={onUpdateUserAgencyMembership}
          onAddAuditLog={onAddAuditLog}
          onAddNotification={onAddNotification}
        />
      )}

      {isSellerOpen && (
        <SellerModal
          isOpen={isSellerOpen}
          onClose={() => setIsSellerOpen(false)}
          currentUser={currentUser}
        />
      )}

      {isVerificationOpen && (
        <VerificationModal
          isOpen={isVerificationOpen}
          onClose={() => setIsVerificationOpen(false)}
          currentUser={currentUser}
        />
      )}

      {isHostCenterOpen && (
        <HostCenterModal
          isOpen={isHostCenterOpen}
          onClose={() => setIsHostCenterOpen(false)}
          currentUser={currentUser}
          onGoLiveClick={() => {
            setIsHostCenterOpen(false);
            onGoLiveClick();
          }}
        />
      )}

      {isEditProfileOpen && (
        <EditProfileModal
          isOpen={isEditProfileOpen}
          onClose={() => setIsEditProfileOpen(false)}
          currentUser={currentUser}
          onSave={onUpdateUserProfile}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          currentRole={currentRole}
          onChangeRole={onChangeRole}
          onOpenOwnerPanel={onOpenOwnerPanel}
          onLogout={onLogout}
        />
      )}

      {isVipModalOpen && (
        <VipUpgradeModal
          isOpen={isVipModalOpen}
          onClose={() => setIsVipModalOpen(false)}
          currentVipLevel={currentUser.vipLevel || 3}
          vipConfigs={vipConfigs}
          userCoinsSpent={currentUser.totalSpentCoins || 0}
          userCoins={currentUser.coinBalance || 0}
          userId={currentUser.id}
          userName={currentUser.name}
          userAvatar={currentUser.avatar}
          onUpgradeVip={onUpgradeVip}
          onUpgrade={onUpgradeVip}
        />
      )}

      {isSpecialIdOpen && (
        <SpecialIdModal
          isOpen={isSpecialIdOpen}
          onClose={() => setIsSpecialIdOpen(false)}
          currentUser={currentUser}
          onUpdateUserBalance={onUpdateUserBalance}
        />
      )}

      {isBadgeModalOpen && (
        <BadgeTagsShowcase
          isOpen={isBadgeModalOpen}
          onClose={() => setIsBadgeModalOpen(false)}
        />
      )}

      {isGuardianOpen && (
        <GuardianModal
          isOpen={isGuardianOpen}
          onClose={() => setIsGuardianOpen(false)}
        />
      )}

      {isFanClubOpen && (
        <FanClubModal
          isOpen={isFanClubOpen}
          onClose={() => setIsFanClubOpen(false)}
        />
      )}

    </div>
  );
};
