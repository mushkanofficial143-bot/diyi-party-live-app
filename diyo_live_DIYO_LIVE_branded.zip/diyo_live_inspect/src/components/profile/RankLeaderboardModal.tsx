import React, { useState } from 'react';
import { X, Trophy, Crown, Flame, Sparkles, Star } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface RankLeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RankLeaderboardModal: React.FC<RankLeaderboardModalProps> = ({
  isOpen,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'monthly'>('daily');

  if (!isOpen) return null;

  const topRankers = [
    { rank: 1, name: '🍒 SR RITU', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120', score: '1,480,200', tag: '💎 VIP 9', crown: '👑 Gold' },
    { rank: 2, name: 'Vikram Rajput', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120', score: '985,000', tag: '⭐ VIP 8', crown: '🥈 Silver' },
    { rank: 3, name: 'Pooja Verma', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120', score: '742,000', tag: '🌟 VIP 6', crown: '🥉 Bronze' },
    { rank: 4, name: 'Kabir Khan', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120', score: '520,000', tag: 'VIP 5', crown: '#4' },
    { rank: 5, name: 'Ananya Roy', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120', score: '410,000', tag: 'VIP 4', crown: '#5' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in select-none">
      <div className="bg-white text-neutral-900 border border-neutral-200 rounded-3xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-neutral-950 text-amber-400 flex items-center justify-center shadow-md">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-neutral-950">Global Leaderboard</h2>
              <p className="text-[11px] font-bold text-neutral-800">Top Hosts & Gifters Ranking</p>
            </div>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-neutral-950/20 hover:bg-neutral-950/30 text-neutral-950 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Toggle */}
        <div className="flex border-b border-neutral-100 p-2 gap-2 bg-neutral-50">
          {(['daily', 'weekly', 'monthly'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                playSoundFX('click');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-black uppercase transition-all ${
                activeTab === tab
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 shadow-sm'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Podium Top 3 */}
        <div className="p-4 bg-gradient-to-b from-amber-50 to-white flex items-end justify-center gap-3 border-b border-neutral-100">
          {/* Rank 2 */}
          <div className="flex flex-col items-center">
            <div className="relative">
              <img src={topRankers[1].avatar} alt="" className="w-14 h-14 rounded-full object-cover ring-2 ring-slate-300 shadow-md" />
              <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-sm">🥈</span>
            </div>
            <span className="text-[11px] font-bold text-neutral-900 mt-1 truncate max-w-[80px]">{topRankers[1].name}</span>
            <span className="text-[10px] font-mono font-bold text-slate-600">985k</span>
          </div>

          {/* Rank 1 */}
          <div className="flex flex-col items-center -translate-y-2">
            <div className="relative">
              <img src={topRankers[0].avatar} alt="" className="w-18 h-18 rounded-full object-cover ring-4 ring-amber-400 shadow-xl" />
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-xl animate-bounce">👑</span>
            </div>
            <span className="text-xs font-black text-neutral-900 mt-1 truncate max-w-[100px]">{topRankers[0].name}</span>
            <span className="text-xs font-mono font-black text-amber-600">1.48M 💎</span>
          </div>

          {/* Rank 3 */}
          <div className="flex flex-col items-center">
            <div className="relative">
              <img src={topRankers[2].avatar} alt="" className="w-14 h-14 rounded-full object-cover ring-2 ring-amber-700 shadow-md" />
              <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-sm">🥉</span>
            </div>
            <span className="text-[11px] font-bold text-neutral-900 mt-1 truncate max-w-[80px]">{topRankers[2].name}</span>
            <span className="text-[10px] font-mono font-bold text-amber-800">742k</span>
          </div>
        </div>

        {/* Ranking List */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1">
          {topRankers.slice(3).map((r, i) => (
            <div key={r.name} className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="w-6 text-center font-bold text-neutral-400 text-sm">#{i + 4}</span>
                <img src={r.avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
                <div>
                  <span className="text-xs font-bold text-neutral-900">{r.name}</span>
                  <span className="ml-1.5 text-[9px] font-black px-1.5 py-0.2 rounded-full bg-neutral-200 text-neutral-700">{r.tag}</span>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-neutral-700">{r.score}</span>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
