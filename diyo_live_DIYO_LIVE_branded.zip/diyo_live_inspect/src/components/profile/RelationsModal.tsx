import React, { useState } from 'react';
import { X, Users, UserCheck, Shield, Sparkles, Heart } from 'lucide-react';

interface RelationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RelationsModal: React.FC<RelationsModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'following' | 'friends' | 'fans'>('following');

  if (!isOpen) return null;

  const contacts = [
    { name: 'DJ Anya', role: 'Live Host', vipLevel: 7, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', isOnline: true },
    { name: 'Kavita Roy', role: 'Gaming Pro', vipLevel: 6, avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80', isOnline: true },
    { name: 'Devansh Kapoor', role: 'Sports Host', vipLevel: 5, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', isOnline: false },
    { name: 'Ananya Gupta', role: 'VIP Member', vipLevel: 6, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', isOnline: true }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-emerald-500/30 rounded-3xl w-full max-w-xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl shadow-emerald-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                FRIENDS & RELATIONS
              </h2>
              <p className="text-xs text-neutral-400">Following, Close Friends & Fans Circle</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center border-b border-neutral-800 px-6 bg-neutral-900/40">
          <button
            onClick={() => setActiveTab('following')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'following' ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            Following (128)
          </button>
          <button
            onClick={() => setActiveTab('friends')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'friends' ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            Close Friends (42)
          </button>
          <button
            onClick={() => setActiveTab('fans')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'fans' ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            Followers (34.2K)
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          {contacts.map((c, i) => (
            <div key={i} className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img src={c.avatar} alt={c.name} className="w-10 h-10 rounded-full object-cover border border-neutral-700" />
                  {c.isOnline && (
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-neutral-950" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-white">{c.name}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
                      VIP {c.vipLevel}
                    </span>
                  </div>
                  <p className="text-[10px] text-neutral-400">{c.role} • {c.isOnline ? '🟢 Online' : 'Offline'}</p>
                </div>
              </div>

              <button className="px-3 py-1 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[11px] font-bold">
                Profile
              </button>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
