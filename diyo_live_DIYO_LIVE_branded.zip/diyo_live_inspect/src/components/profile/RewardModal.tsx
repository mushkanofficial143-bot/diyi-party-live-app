import React, { useState } from 'react';
import { X, Gift, Sparkles, CheckCircle2, Calendar, Award, Flame, Zap } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface RewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimReward: (coins: number) => void;
}

export const RewardModal: React.FC<RewardModalProps> = ({
  isOpen,
  onClose,
  onClaimReward
}) => {
  const [checkedDays, setCheckedDays] = useState<number[]>([1, 2, 3]);
  const [hasClaimedToday, setHasClaimedToday] = useState<boolean>(false);
  const [claimToast, setClaimToast] = useState<string | null>(null);

  if (!isOpen) return null;

  const weekDays = [
    { day: 1, coins: 500, label: 'Day 1' },
    { day: 2, coins: 1000, label: 'Day 2' },
    { day: 3, coins: 1500, label: 'Day 3' },
    { day: 4, coins: 3000, label: 'Day 4 (Today)', isToday: true },
    { day: 5, coins: 5000, label: 'Day 5' },
    { day: 6, coins: 8000, label: 'Day 6' },
    { day: 7, coins: 20000, label: 'Day 7 (Mystery Box)', isSuper: true },
  ];

  const tasks = [
    { id: 't1', title: 'Watch 3 Live Streams for 5 mins', reward: 2000, progress: '3/3', completed: true },
    { id: 't2', title: 'Send 1 Lucky Gift in a Live Room', reward: 5000, progress: '1/1', completed: true },
    { id: 't3', title: 'Play 5 rounds in Test Games Catalog', reward: 3500, progress: '5/5', completed: true },
    { id: 't4', title: 'Post a Moment update to Community', reward: 1500, progress: '0/1', completed: false }
  ];

  const handleClaimDay4 = () => {
    if (hasClaimedToday) return;
    setHasClaimedToday(true);
    setCheckedDays((prev) => [...prev, 4]);
    onClaimReward(3000);
    playSoundFX('win');
    setClaimToast('🎉 Daily check-in claimed! +3,000 Test Coins added to your wallet.');
    setTimeout(() => setClaimToast(null), 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-amber-500/30 rounded-3xl w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl shadow-amber-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-neutral-950 shadow-lg shadow-amber-900/30">
              <Gift className="w-5 h-5 text-neutral-950 font-bold" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                DAILY REWARDS & MISSIONS
              </h2>
              <p className="text-xs text-neutral-400">7-Day Streak Bonus & Task Rewards</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          
          {claimToast && (
            <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>{claimToast}</span>
            </div>
          )}

          {/* 7-Day Check-in Strip */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-400" /> 7-Day Attendance Streak
              </span>
              <span className="text-[11px] text-amber-400 font-bold font-mono">Streak: 4 Days 🔥</span>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {weekDays.map((wd) => {
                const isClaimed = checkedDays.includes(wd.day);
                return (
                  <div
                    key={wd.day}
                    onClick={() => {
                      if (wd.day === 4 && !isClaimed) handleClaimDay4();
                    }}
                    className={`p-2.5 rounded-2xl border text-center flex flex-col items-center justify-between space-y-1 transition-all ${
                      isClaimed
                        ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                        : wd.isToday
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 animate-pulse cursor-pointer shadow-lg shadow-amber-950/40'
                        : 'bg-neutral-900/80 border-neutral-800 text-neutral-400'
                    }`}
                  >
                    <span className="text-[9px] font-bold uppercase">{wd.label}</span>
                    <span className="text-base my-0.5">{isClaimed ? '✅' : wd.isSuper ? '🎁' : '🪙'}</span>
                    <span className="text-[10px] font-mono font-bold">{wd.coins >= 1000 ? `${wd.coins / 1000}k` : wd.coins}</span>
                  </div>
                );
              })}
            </div>

            <button
              onClick={handleClaimDay4}
              disabled={hasClaimedToday}
              className={`w-full py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                hasClaimedToday
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-neutral-950 shadow-lg shadow-amber-950/40'
              }`}
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>{hasClaimedToday ? 'Today\'s Reward Claimed' : 'Claim Day 4 Reward (+3,000 Coins)'}</span>
            </button>
          </div>

          {/* Daily Missions */}
          <div className="space-y-3 pt-2 border-t border-neutral-800">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-emerald-400" /> Daily Active Missions
              </span>
            </div>

            <div className="space-y-2">
              {tasks.map((t) => (
                <div key={t.id} className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <p className="font-bold text-white">{t.title}</p>
                    <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                      <span>Reward: <strong className="text-yellow-400 font-mono">+{t.reward} 🪙</strong></span>
                      <span>• Progress: {t.progress}</span>
                    </div>
                  </div>

                  {t.completed ? (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                      Completed
                    </span>
                  ) : (
                    <button className="px-3 py-1 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[10px] font-bold">
                      Go
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
