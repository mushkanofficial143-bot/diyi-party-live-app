import React, { useState, useRef } from 'react';
import { 
  Edit3, 
  Settings, 
  Copy, 
  Crown, 
  Sparkles, 
  CheckCircle2,
  ChevronRight
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface SRLiveProfileHeaderProps {
  username?: string;
  userId?: string;
  countryFlag?: string;
  countryCode?: string;
  countryName?: string;
  bio?: string;
  avatarUrl?: string;
  followersCount?: string | number;
  followingCount?: string | number;
  diamondsCount?: string | number;
  coinsCount?: string | number;
  vipLevel?: number;
  userLevel?: number;
  age?: number;
  gender?: string;
  roleTitle?: string;
  role?: string;
  profileTag?: string;
  onEditProfile?: () => void;
  onOpenSettings?: () => void;
  onOpenVipModal?: () => void;
  onOpenLevelModal?: () => void;
  onOpenFollowers?: () => void;
  onOpenFollowing?: () => void;
  onOpenWallet?: (tab?: 'RECHARGE' | 'EXCHANGE') => void;
  onUpdateAvatar?: (newUrl: string) => void;
}

export const SRLiveProfileHeader: React.FC<SRLiveProfileHeaderProps> = ({
  username = "DIYO LIVE STREAM",
  userId = "148830743",
  countryFlag = "🇳🇵",
  countryCode = "NP",
  countryName = "Nepal",
  avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600",
  followersCount = 8,
  followingCount = 8,
  vipLevel = 3,
  userLevel = 42,
  age = 22,
  gender = "Male",
  role = "OWNER",
  onEditProfile,
  onOpenSettings,
  onOpenVipModal,
  onOpenLevelModal,
  onOpenFollowers,
  onOpenFollowing,
  onUpdateAvatar
}) => {
  const [copiedId, setCopiedId] = useState(false);
  const [uploadToast, setUploadToast] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCopyId = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(userId);
    playSoundFX('click');
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const triggerGalleryPicker = (e: React.MouseEvent) => {
    e.stopPropagation();
    playSoundFX('click');
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleDirectPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const res = reader.result as string;
        if (onUpdateAvatar) {
          onUpdateAvatar(res);
        }
        playSoundFX('win');
        setUploadToast(true);
        setTimeout(() => setUploadToast(false), 3000);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div 
      id="sr-live-profile-header-container"
      className="relative w-full overflow-hidden text-white select-none px-3 py-3 flex flex-col items-center text-center"
    >
      {/* Hidden file input for avatar */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleDirectPhotoUpload}
        accept="image/*"
        className="hidden"
      />

      {/* Top Right Action Icons: Edit & Settings */}
      <div className="absolute top-2 right-3 flex items-center gap-2 z-20">
        <button
          onClick={() => {
            playSoundFX('click');
            if (onEditProfile) onEditProfile();
          }}
          className="w-9 h-9 rounded-full bg-[#1b2030] hover:bg-[#252b42] border border-white/10 text-white flex items-center justify-center shadow transition-all cursor-pointer"
          title="Edit Profile"
        >
          <Edit3 className="w-4 h-4 text-neutral-300" />
        </button>
        <button
          onClick={() => {
            playSoundFX('click');
            if (onOpenSettings) onOpenSettings();
          }}
          className="w-9 h-9 rounded-full bg-[#1b2030] hover:bg-[#252b42] border border-white/10 text-white flex items-center justify-center shadow transition-all cursor-pointer"
          title="Settings"
        >
          <Settings className="w-4 h-4 text-neutral-300" />
        </button>
      </div>

      {/* Centered Avatar with Ornate Frame Badge ("NEW" + Crown + Aura) */}
      <div className="relative mb-3 mt-1">
        <div 
          onClick={triggerGalleryPicker}
          className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full p-1 bg-gradient-to-tr from-cyan-400 via-purple-500 via-pink-500 to-amber-400 shadow-[0_0_25px_rgba(168,85,247,0.4)] cursor-pointer group mx-auto"
        >
          {/* Top "NEW" Crown Badge over Avatar */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 text-white text-[9px] font-black uppercase tracking-widest shadow-lg border border-pink-300 flex items-center gap-1">
            <Crown className="w-2.5 h-2.5 text-yellow-300 fill-yellow-300 animate-bounce" />
            <span>NEW</span>
          </div>

          <div className="w-full h-full rounded-full overflow-hidden bg-neutral-900 border-2 border-neutral-950 flex items-center justify-center">
            <img
              src={avatarUrl}
              alt={username}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            />
          </div>
        </div>
      </div>

      {/* Centered User Details */}
      <div className="w-full flex flex-col items-center space-y-2 mb-4">
        
        {/* Name & Country Flag & Gender */}
        <div className="flex items-center justify-center gap-2">
          <h1 className="text-xl sm:text-2xl font-black font-['Outfit'] text-white tracking-tight">
            {username}
          </h1>
          <span className="text-base">{countryFlag}</span>
          <span className="px-1.5 py-0.5 rounded-md bg-blue-500/20 text-blue-400 border border-blue-500/40 text-[10px] font-black flex items-center gap-0.5">
            <span>♂</span>
            <span>{age}</span>
          </span>
        </div>

        {/* ID with Copy Button & Chevron */}
        <div 
          onClick={handleCopyId}
          className="inline-flex items-center justify-center gap-3 bg-[#1b2030] hover:bg-[#22283d] px-3.5 py-1.5 rounded-xl border border-white/5 cursor-pointer transition-all shadow"
        >
          <span className="text-xs text-neutral-300 font-medium">ID {userId}</span>
          <Copy className="w-3.5 h-3.5 text-neutral-400" />
          {copiedId && <span className="text-[10px] text-emerald-400 font-bold">Copied!</span>}
          <ChevronRight className="w-4 h-4 text-neutral-500" />
        </div>

        {/* Badges Row (VIP, Level, Owner) */}
        <div className="flex items-center justify-center gap-1.5 pt-1 flex-wrap">
          <div 
            onClick={() => {
              playSoundFX('win');
              if (onOpenVipModal) onOpenVipModal();
            }}
            className="px-2.5 py-0.5 rounded-md bg-gradient-to-r from-blue-600 to-indigo-700 text-white text-[10px] font-black tracking-wide shadow flex items-center gap-1 cursor-pointer"
          >
            <span className="text-cyan-300">💎</span>
            <span>VIP {vipLevel}</span>
          </div>

          <div 
            onClick={() => {
              playSoundFX('win');
              if (onOpenLevelModal) onOpenLevelModal();
            }}
            className="px-2.5 py-0.5 rounded-md bg-gradient-to-r from-emerald-600 to-teal-700 text-white text-[10px] font-black tracking-wide shadow flex items-center gap-1 cursor-pointer"
          >
            <span className="text-emerald-300">⭐</span>
            <span>Level {userLevel}</span>
          </div>

          <div className="px-2.5 py-0.5 rounded-md bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-neutral-950 text-[10px] font-black tracking-wide shadow flex items-center gap-1">
            <Crown className="w-3 h-3 text-neutral-950 fill-neutral-950" />
            <span>Owner</span>
          </div>
        </div>

      </div>

      {/* Follow & Followers Count Row (Centered) */}
      <div className="flex items-center justify-center gap-8 pb-3 border-b border-white/10 text-xs w-full max-w-xs mx-auto">
        <div 
          onClick={() => {
            playSoundFX('click');
            if (onOpenFollowing) onOpenFollowing();
          }}
          className="flex items-center gap-1.5 cursor-pointer hover:opacity-80 transition-opacity"
        >
          <span className="font-black text-white text-sm">{followingCount}</span>
          <span className="text-neutral-400 font-medium">Follow</span>
        </div>

        <div className="w-px h-3.5 bg-white/15" />

        <div 
          onClick={() => {
            playSoundFX('click');
            if (onOpenFollowers) onOpenFollowers();
          }}
          className="flex items-center gap-1.5 cursor-pointer hover:opacity-80 transition-opacity"
        >
          <span className="font-black text-white text-sm">{followersCount}</span>
          <span className="text-neutral-400 font-medium">Followers</span>
        </div>
      </div>

      {uploadToast && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 px-3 py-1.5 rounded-full bg-emerald-500 text-neutral-950 text-[11px] font-black shadow-xl flex items-center gap-1 animate-in fade-in">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Profile photo updated successfully!</span>
        </div>
      )}
    </div>
  );
};
