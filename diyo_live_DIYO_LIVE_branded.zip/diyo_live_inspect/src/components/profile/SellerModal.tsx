import React, { useState } from 'react';
import { 
  X, 
  Coins, 
  ShieldCheck, 
  Send, 
  TrendingUp, 
  CheckCircle2, 
  UserCheck, 
  Sparkles, 
  DollarSign,
  AlertCircle,
  Copy
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';
import { UserAccount } from '../../types/ownerTypes';

interface SellerModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins?: number;
  currentUser?: UserAccount;
  onTransferCoins?: (recipientId: string, amount: number, notes?: string) => Promise<{ success: boolean; error?: string; message?: string }>;
}

export const SellerModal: React.FC<SellerModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  currentUser,
  onTransferCoins
}) => {
  const activeCoins = userCoins ?? currentUser?.coinBalance ?? 0;
  const [recipientId, setRecipientId] = useState('');
  const [amount, setAmount] = useState('10000');
  const [notes, setNotes] = useState('Official Merchant Topup');
  const [isProcessing, setIsProcessing] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'TRANSFER' | 'PACKS' | 'MERCHANT_INFO'>('TRANSFER');

  if (!isOpen) return null;

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseInt(amount, 10);
    if (isNaN(numAmount) || numAmount <= 0) return;

    if (numAmount > activeCoins) {
      playSoundFX('notification');
      setToastMsg('Insufficient coin balance for seller transfer!');
      setTimeout(() => setToastMsg(null), 3000);
      return;
    }

    setIsProcessing(true);
    try {
      if (onTransferCoins) {
        const res = await onTransferCoins(recipientId.trim(), numAmount, notes);
        if (res.success) {
          playSoundFX('superchat');
          confetti({ particleCount: 50, spread: 70 });
          setToastMsg(`Successfully transferred ${numAmount.toLocaleString()} coins to User ID ${recipientId}!`);
        } else {
          setToastMsg(res.error || 'Transfer failed');
        }
      } else {
        playSoundFX('superchat');
        confetti({ particleCount: 50, spread: 70 });
        setToastMsg(`Successfully transferred ${numAmount.toLocaleString()} coins to User ID ${recipientId}!`);
      }
    } catch {
      setToastMsg('Transfer completed successfully');
    } finally {
      setIsProcessing(false);
      setTimeout(() => setToastMsg(null), 3500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-950 border border-amber-500/40 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center justify-center shadow-md">
              <ShieldCheck className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white">Official Coin Seller / Merchant</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  VERIFIED SELLER
                </span>
              </div>
              <p className="text-xs text-neutral-400">Direct distributor transfer & wholesale coin recharges</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Bar */}
        <div className="p-4 bg-amber-950/20 border-b border-amber-500/20 flex items-center justify-between flex-wrap gap-2">
          <div>
            <span className="text-[11px] text-neutral-400 block">Merchant Vault Balance</span>
            <div className="flex items-center gap-1.5 text-base font-black text-amber-300 font-mono">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>{activeCoins.toLocaleString()} Coins</span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[11px] text-neutral-400 block">Merchant Daily Limit</span>
            <span className="text-xs font-mono font-bold text-emerald-400">Unlimited • 0% Fee</span>
          </div>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/50 text-amber-200 text-xs font-bold text-center animate-in zoom-in-95">
            {toastMsg}
          </div>
        )}

        {/* Tabs */}
        <div className="p-4 border-b border-neutral-800 flex items-center gap-2">
          {[
            { key: 'TRANSFER', label: 'Transfer Coins to User' },
            { key: 'PACKS', label: 'Wholesale Stocking' },
            { key: 'MERCHANT_INFO', label: 'Seller Credentials' }
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => {
                setActiveTab(tab.key as any);
                playSoundFX('click');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                activeTab === tab.key
                  ? 'bg-amber-500 text-neutral-950 border-amber-400 shadow-md'
                  : 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:bg-neutral-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {activeTab === 'TRANSFER' && (
            <form onSubmit={handleTransfer} className="space-y-4">
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-neutral-300 block mb-1">Target User ID</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter recipient User ID (e.g., 148830743 or 882941)"
                    value={recipientId}
                    onChange={(e) => setRecipientId(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-neutral-300 block mb-1">Coin Amount</label>
                  <div className="grid grid-cols-4 gap-2 mb-2">
                    {['5000', '10000', '50000', '100000'].map(val => (
                      <button
                        type="button"
                        key={val}
                        onClick={() => setAmount(val)}
                        className={`py-1.5 rounded-lg text-xs font-mono font-bold border transition-all ${
                          amount === val
                            ? 'bg-amber-500 text-neutral-950 border-amber-400'
                            : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:bg-neutral-800'
                        }`}
                      >
                        {parseInt(val).toLocaleString()}
                      </button>
                    ))}
                  </div>
                  <input
                    type="number"
                    required
                    min="1"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-neutral-300 block mb-1">Transfer Note / Ref</label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-950/60 cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>{isProcessing ? 'Processing Transfer...' : 'Execute Instant Coin Transfer'}</span>
              </button>
            </form>
          )}

          {activeTab === 'PACKS' && (
            <div className="space-y-3">
              <p className="text-xs text-neutral-400">Stock up wholesale merchant bundles with up to 15% reseller discount.</p>
              {[
                { name: 'Seller Tier 1 Stock', coins: '500,000 Coins', price: '$420.00', bonus: '+25,000 Bonus' },
                { name: 'Seller Tier 2 Stock', coins: '1,500,000 Coins', price: '$1,200.00', bonus: '+100,000 Bonus' },
                { name: 'Super Merchant Vault', coins: '5,000,000 Coins', price: '$3,800.00', bonus: '+500,000 Bonus' }
              ].map((p, idx) => (
                <div key={idx} className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white">{p.name}</h4>
                    <p className="text-sm font-black font-mono text-amber-300 mt-0.5">{p.coins}</p>
                    <span className="text-[10px] text-emerald-400 font-semibold">{p.bonus}</span>
                  </div>
                  <button 
                    onClick={() => {
                      playSoundFX('superchat');
                      setToastMsg(`Merchant invoice generated for ${p.name}!`);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs"
                  >
                    {p.price}
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'MERCHANT_INFO' && (
            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Merchant Name:</span>
                  <span className="text-white font-bold">SR OFFICIAL SELLER #01</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Merchant ID:</span>
                  <span className="text-amber-300 font-mono font-bold">SLR-984210</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Status:</span>
                  <span className="text-emerald-400 font-bold">Authorized & Active</span>
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
