import React, { useState } from 'react';
import { X, Settings, ShieldCheck, Moon, Volume2, Globe, Key, LogOut, AlertTriangle, FileText, ChevronRight } from 'lucide-react';
import { UserRole } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';
import { PolicyModal } from './PolicyModal';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  onOpenOwnerPanel: () => void;
  onLogout?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  onChangeRole,
  onOpenOwnerPanel,
  onLogout
}) => {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [streamQuality, setStreamQuality] = useState('4K Ultra HD (AV1)');
  const [language, setLanguage] = useState('English (Global)');
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [isPolicyOpen, setIsPolicyOpen] = useState(false);

  if (!isOpen) return null;

  const roles: UserRole[] = ['USER', 'AGENCY', 'COIN_SELLER', 'MANAGER', 'ADMIN', 'OWNER'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-emerald-500/30 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col shadow-2xl shadow-emerald-950/40 relative">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-neutral-800 to-neutral-700 flex items-center justify-center text-white shadow-lg">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-white font-['Outfit']">APP SETTINGS</h2>
              <p className="text-xs text-neutral-400">Preferences, Role Switcher & System Control</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          
          {/* Owner Panel Access Highlight */}
          {(currentRole === 'OWNER' || currentRole === 'SUPER_ADMIN' || currentRole === 'ADMIN') && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950 via-neutral-900 to-amber-950/50 border border-emerald-500/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" /> Master Security Dashboard
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                  {currentRole}
                </span>
              </div>
              <p className="text-[11px] text-neutral-300">
                Direct access to manage all 18 platform modules: Super Admins, Agencies, Treasury, Withdrawals, Games & Gifts.
              </p>
              <button
                onClick={() => {
                  onClose();
                  onOpenOwnerPanel();
                }}
                className="w-full mt-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-amber-500 hover:from-emerald-500 hover:to-amber-400 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-md"
              >
                <Key className="w-3.5 h-3.5" />
                <span>Launch Master Owner Panel</span>
              </button>
            </div>
          )}

          {/* Role switcher */}
          <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-2">
            <span className="font-bold text-neutral-300 uppercase tracking-wider block">Sandbox Role Switcher</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {roles.map((r) => (
                <button
                  key={r}
                  onClick={() => {
                    onChangeRole(r);
                    playSoundFX('click');
                  }}
                  className={`px-2.5 py-1.5 rounded-xl text-[10px] font-bold border transition-all ${
                    currentRole === r
                      ? 'bg-emerald-500 border-emerald-400 text-neutral-950 font-black shadow-md'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* Preferences */}
          <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-3">
            <span className="font-bold text-neutral-300 uppercase tracking-wider block">Playback & General</span>

            <div className="flex items-center justify-between">
              <span className="text-neutral-300 flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-emerald-400" /> Web Audio Sound FX
              </span>
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`w-10 h-6 rounded-full p-1 transition-all ${soundEnabled ? 'bg-emerald-500' : 'bg-neutral-800'}`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform ${soundEnabled ? 'translate-x-4' : ''}`} />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-neutral-300 flex items-center gap-2">
                <Globe className="w-4 h-4 text-amber-400" /> Stream Preferred Ingest
              </span>
              <span className="text-[11px] font-mono text-emerald-400">{streamQuality}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-neutral-300 flex items-center gap-2">
                <Moon className="w-4 h-4 text-rose-400" /> Interface Theme
              </span>
              <span className="text-[11px] font-mono text-neutral-400">DIYO Midnight Luxury</span>
            </div>
          </div>

          {/* Platform Policy & Guidelines Link */}
          <div 
            onClick={() => { playSoundFX('click'); setIsPolicyOpen(true); }}
            className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 hover:border-emerald-500/40 flex items-center justify-between cursor-pointer transition-all group shadow-sm"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-white block">Platform Policy & Guidelines</span>
                <span className="text-[10px] text-neutral-400">Community rules, streaming conduct & agency terms</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-emerald-400 transition-colors" />
          </div>

          {/* Logout Section */}
          <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/20 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-rose-300 uppercase tracking-wider block">Account Session</span>
                <span className="text-[10px] text-neutral-400">Sign out of this device and return to login</span>
              </div>
              <button
                onClick={() => setShowLogoutConfirm(true)}
                className="px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-bold border border-rose-500/40 flex items-center gap-1.5 transition-all"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            </div>
          </div>

          {/* App info */}
          <div className="text-center text-[11px] text-neutral-500 space-y-0.5 pt-2">
            <p className="font-bold text-neutral-400 font-['Outfit']">DIYO LIVE</p>
            <p>Version 4.2.0 • Ultra Low-Latency Ingest Engine</p>
            <p>© 2026 DIYO LIVE. All rights reserved.</p>
          </div>

        </div>

        {/* Confirmation Modal */}
        {showLogoutConfirm && (
          <div className="absolute inset-0 bg-black/90 backdrop-blur-md rounded-3xl flex flex-col items-center justify-center p-6 text-center z-30 animate-in fade-in">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-3 shadow-lg">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-black text-white font-['Outfit'] mb-1">Confirm Log Out</h3>
            <p className="text-xs text-neutral-400 max-w-xs mb-6">
              Are you sure you want to log out of DIYO LIVE? You will need to sign in again to access live rooms, games, and wallet.
            </p>

            <div className="flex items-center gap-3 w-full max-w-xs">
              <button
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLogoutConfirm(false);
                  onClose();
                  if (onLogout) onLogout();
                }}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-rose-900/40"
              >
                Log Out
              </button>
            </div>
          </div>
        )}

      </div>

      <PolicyModal isOpen={isPolicyOpen} onClose={() => setIsPolicyOpen(false)} />
    </div>
  );
};
