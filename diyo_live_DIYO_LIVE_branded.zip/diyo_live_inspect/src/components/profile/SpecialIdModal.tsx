import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  Check, 
  Search, 
  Crown, 
  Zap, 
  Gem, 
  Coins, 
  ShieldCheck, 
  Copy, 
  Award,
  Flame,
  Star
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface SpecialIdModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentId?: string;
  currentUserId?: string;
  userCoins?: number;
  onEquipId?: (newId: string) => void;
  onPurchaseSpecialId?: (newId: string) => void;
}

interface SpecialIdItem {
  id: string;
  displayId: string;
  category: 'ROYAL_TRIPLE' | 'LUCKY_8' | 'MIRROR' | 'SHORT_VIP' | 'LOVE';
  priceCoins: number;
  badge: string;
  glowColor: string;
  isPopular?: boolean;
}

const SPECIAL_IDS_CATALOG: SpecialIdItem[] = [
  { id: '888888', displayId: '888888', category: 'LUCKY_8', priceCoins: 50000, badge: 'PROSPERITY GOD', glowColor: 'from-amber-400 to-yellow-500', isPopular: true },
  { id: '777777', displayId: '777777', category: 'ROYAL_TRIPLE', priceCoins: 45000, badge: 'JACKPOT 7', glowColor: 'from-emerald-400 to-teal-500', isPopular: true },
  { id: '999999', displayId: '999999', category: 'ROYAL_TRIPLE', priceCoins: 60000, badge: 'SUPREME EMPEROR', glowColor: 'from-purple-400 to-indigo-500' },
  { id: '123456', displayId: '123456', category: 'MIRROR', priceCoins: 35000, badge: 'STRAIGHT FLUSH', glowColor: 'from-sky-400 to-blue-500' },
  { id: '5201314', displayId: '5201314', category: 'LOVE', priceCoins: 40000, badge: 'ETERNAL LOVE', glowColor: 'from-pink-400 to-rose-500', isPopular: true },
  { id: '666666', displayId: '666666', category: 'ROYAL_TRIPLE', priceCoins: 38000, badge: 'LUCKY SMOOTH', glowColor: 'from-amber-300 to-orange-500' },
  { id: '111111', displayId: '111111', category: 'SHORT_VIP', priceCoins: 42000, badge: 'NUMBER ONE', glowColor: 'from-yellow-400 to-amber-600' },
  { id: '100001', displayId: '100001', category: 'MIRROR', priceCoins: 25000, badge: 'BINARY NOBLE', glowColor: 'from-cyan-400 to-teal-600' },
  { id: '999000', displayId: '999000', category: 'SHORT_VIP', priceCoins: 28000, badge: 'VIP MILLIONAIRE', glowColor: 'from-emerald-400 to-green-600' }
];

export const SpecialIdModal: React.FC<SpecialIdModalProps> = ({
  isOpen,
  onClose,
  currentId,
  currentUserId,
  userCoins = 0,
  onEquipId,
  onPurchaseSpecialId
}) => {
  const initialId = currentId || currentUserId || '3456789';
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'LUCKY_8' | 'ROYAL_TRIPLE' | 'LOVE' | 'MIRROR'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [customSearchId, setCustomSearchId] = useState('');
  const [purchasedIds, setPurchasedIds] = useState<string[]>([initialId]);
  const [activeSpecialId, setActiveSpecialId] = useState<string>(initialId);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredCatalog = SPECIAL_IDS_CATALOG.filter(item => {
    const matchesCat = selectedCategory === 'ALL' || item.category === selectedCategory;
    const matchesSearch = item.displayId.includes(searchQuery) || item.badge.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleBuyOrEquip = (item: SpecialIdItem) => {
    if (activeSpecialId === item.id) {
      playSoundFX('click');
      return;
    }

    if (purchasedIds.includes(item.id)) {
      setActiveSpecialId(item.id);
      if (onEquipId) onEquipId(item.id);
      if (onPurchaseSpecialId) onPurchaseSpecialId(item.id);
      playSoundFX('superchat');
      setToastMsg(`Equipped Special ID ${item.displayId}!`);
      setTimeout(() => setToastMsg(null), 2500);
      return;
    }

    if (userCoins < item.priceCoins) {
      playSoundFX('notification');
      setToastMsg(`Insufficient coins! Need ${item.priceCoins.toLocaleString()} coins.`);
      setTimeout(() => setToastMsg(null), 2500);
      return;
    }

    setPurchasedIds(prev => [...prev, item.id]);
    setActiveSpecialId(item.id);
    if (onEquipId) onEquipId(item.id);
    if (onPurchaseSpecialId) onPurchaseSpecialId(item.id);
    playSoundFX('superchat');
    confetti({ particleCount: 50, spread: 70 });
    setToastMsg(`Successfully purchased and equipped Special ID ${item.displayId}!`);
    setTimeout(() => setToastMsg(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-950 border border-emerald-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-400 to-green-600 flex items-center justify-center text-neutral-950 shadow-lg shadow-emerald-950/50">
              <ShieldCheck className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white">Special ID Market</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  VIP EXCLUSIVE
                </span>
              </div>
              <p className="text-xs text-neutral-400">Own rare, vanity 6-digit lucky stream IDs</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current ID Banner */}
        <div className="p-4 bg-emerald-950/20 border-b border-emerald-500/20 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs text-neutral-400">Current ID:</span>
            <span className="px-3 py-1 rounded-xl bg-neutral-900 text-emerald-300 font-mono font-black text-sm border border-emerald-500/40 shadow-inner">
              ID {activeSpecialId}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-amber-300 bg-amber-500/10 px-3 py-1 rounded-xl border border-amber-500/30 font-bold">
            <Coins className="w-3.5 h-3.5" />
            <span>Balance: {userCoins.toLocaleString()} Coins</span>
          </div>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/50 text-emerald-200 text-xs font-bold text-center animate-in zoom-in-95">
            {toastMsg}
          </div>
        )}

        {/* Category Pills & Search */}
        <div className="p-4 space-y-3">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {[
              { key: 'ALL', label: 'All IDs' },
              { key: 'LUCKY_8', label: '👑 Lucky 8s' },
              { key: 'ROYAL_TRIPLE', label: '💎 Royal Triples' },
              { key: 'LOVE', label: '💖 Love 520' },
              { key: 'MIRROR', label: '⚡ Straight/Mirror' }
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => {
                  setSelectedCategory(tab.key as any);
                  playSoundFX('click');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                  selectedCategory === tab.key
                    ? 'bg-emerald-500 text-neutral-950 border-emerald-400 shadow-md'
                    : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:bg-neutral-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search lucky digits (e.g., 888, 777, love)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>
        </div>

        {/* Special IDs Grid */}
        <div className="flex-1 overflow-y-auto p-4 pt-0 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filteredCatalog.map((item) => {
            const isEquipped = activeSpecialId === item.id;
            const isOwned = purchasedIds.includes(item.id);

            return (
              <div 
                key={item.id}
                className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between ${
                  isEquipped
                    ? 'bg-emerald-950/30 border-emerald-500 ring-1 ring-emerald-500 shadow-lg shadow-emerald-950/40'
                    : 'bg-neutral-950/70 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-neutral-900 text-amber-300 border border-amber-500/30">
                      {item.badge}
                    </span>
                    <h3 className="text-xl font-black font-mono tracking-wider text-white mt-1">
                      {item.displayId}
                    </h3>
                  </div>

                  {item.isPopular && (
                    <span className="flex items-center gap-0.5 text-[9px] font-black text-rose-400 bg-rose-500/20 px-1.5 py-0.5 rounded border border-rose-500/30">
                      <Flame className="w-2.5 h-2.5" /> HOT
                    </span>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-xs font-black text-amber-300 font-mono">
                    <Coins className="w-3.5 h-3.5 text-amber-400" />
                    <span>{item.priceCoins.toLocaleString()}</span>
                  </div>

                  <button
                    onClick={() => handleBuyOrEquip(item)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1 ${
                      isEquipped
                        ? 'bg-emerald-500 text-neutral-950'
                        : isOwned
                        ? 'bg-amber-500 hover:bg-amber-400 text-neutral-950'
                        : 'bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700'
                    }`}
                  >
                    {isEquipped ? (
                      <>
                        <Check className="w-3.5 h-3.5" /> Equipped
                      </>
                    ) : isOwned ? (
                      'Equip'
                    ) : (
                      'Purchase'
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
