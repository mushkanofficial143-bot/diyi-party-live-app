import React, { useState } from 'react';
import { X, ShoppingBag, Sparkles, Crown, Car, Shield, Check, Zap } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface StoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  onPurchaseItem: (item: { name: string; price: number; type: string }) => void;
}

export const StoreModal: React.FC<StoreModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  onPurchaseItem
}) => {
  const [activeCategory, setActiveCategory] = useState<'frames' | 'mounts' | 'bubbles' | 'badges'>('frames');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  if (!isOpen) return null;

  const storeItems = {
    frames: [
      { id: 'f1', name: 'Emerald Dragon Halo', price: 5000, icon: '🐲', duration: '30 Days', desc: 'Animated glowing emerald aura around your avatar' },
      { id: 'f2', name: 'Golden Sovereign Crown', price: 12000, icon: '👑', duration: '30 Days', desc: 'Regal golden frame with dynamic particle glitter' },
      { id: 'f3', name: 'Cyberpunk Neon Ring', price: 3500, icon: '⚡', duration: '15 Days', desc: 'Pulsing ultra-violet laser outline' },
      { id: 'f4', name: 'Galaxy Stellar Ring', price: 20000, icon: '🌌', duration: 'Permanent', desc: 'Cosmic nebula with rotating orbiting planets' }
    ],
    mounts: [
      { id: 'm1', name: 'Bugatti Chiron Ultra', price: 50000, icon: '🏎️', duration: '30 Days', desc: 'Fly-in sports car animation with engine rev when entering live rooms' },
      { id: 'm2', name: 'Cyberpunk Hovercraft', price: 35000, icon: '🛸', duration: '30 Days', desc: 'Futuristic anti-gravity vehicle entry banner' },
      { id: 'm3', name: 'Royal Pegasus Steed', price: 80000, icon: '🦄', duration: 'Permanent', desc: 'Legendary winged unicorn with rainbow dust trail' }
    ],
    bubbles: [
      { id: 'b1', name: 'Gold VIP Chat Bubble', price: 2000, icon: '💬', duration: '30 Days', desc: 'Highlighted golden border chat bubble for all messages' },
      { id: 'b2', name: 'Emerald Laser Bubble', price: 2000, icon: '💚', duration: '30 Days', desc: 'Deep neon green chat box with custom font color' },
      { id: 'b3', name: 'Diamond Crystal Box', price: 8000, icon: '💎', duration: '60 Days', desc: 'Frosted 3D glassmorphic VIP chat appearance' }
    ],
    badges: [
      { id: 'bd1', name: 'Top Supporter Medal', price: 15000, icon: '🎖️', duration: '30 Days', desc: 'Stands out in live viewer lists and chat rankings' },
      { id: 'bd2', name: 'DIYO LIVE Founding Pioneer', price: 30000, icon: '🛡️', duration: 'Permanent', desc: 'Exclusive legacy badge for platform test supporters' }
    ]
  };

  const handleBuy = (item: { name: string; price: number; icon: string }) => {
    if (userCoins < item.price) {
      alert('Insufficient virtual test coins! Please recharge free test coins in your Wallet.');
      return;
    }
    onPurchaseItem({ name: item.name, price: item.price, type: activeCategory });
    playSoundFX('win');
    setSuccessToast(`✨ Purchased "${item.name}"! Equipped to your profile inventory.`);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border border-amber-500/30 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl shadow-amber-950/40">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center text-neutral-950 shadow-lg shadow-amber-900/30">
              <ShoppingBag className="w-5 h-5 text-neutral-950 font-bold" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                VIP STORE & NOBILITY
              </h2>
              <p className="text-xs text-neutral-400">Avatar Frames, Fly-in Mounts & Luxury Effects</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Balance Bar & Category Filters */}
        <div className="px-6 py-3 bg-neutral-900/90 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 bg-neutral-950 px-3 py-1.5 rounded-full border border-yellow-500/30">
            <span className="text-xs text-neutral-400 font-medium">Balance:</span>
            <span className="text-xs font-black text-yellow-400 font-mono">{(userCoins ?? 0).toLocaleString()} 🪙</span>
          </div>

          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800">
            <button
              onClick={() => setActiveCategory('frames')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                activeCategory === 'frames' ? 'bg-amber-500 text-neutral-950 font-black' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Frames
            </button>
            <button
              onClick={() => setActiveCategory('mounts')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                activeCategory === 'mounts' ? 'bg-amber-500 text-neutral-950 font-black' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Mounts
            </button>
            <button
              onClick={() => setActiveCategory('bubbles')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                activeCategory === 'bubbles' ? 'bg-amber-500 text-neutral-950 font-black' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Bubbles
            </button>
            <button
              onClick={() => setActiveCategory('badges')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                activeCategory === 'badges' ? 'bg-amber-500 text-neutral-950 font-black' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Badges
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          
          {successToast && (
            <div className="p-3 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{successToast}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {(storeItems[activeCategory] || []).map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-3"
              >
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-neutral-950 border border-neutral-700 flex items-center justify-center text-2xl flex-shrink-0 shadow-inner">
                    {item.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-white">{item.name}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 font-mono">
                        {item.duration}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-1 line-clamp-2">{item.desc}</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-neutral-800 flex items-center justify-between">
                  <span className="font-mono text-sm font-black text-yellow-400">
                    {(item.price ?? 0).toLocaleString()} 🪙
                  </span>
                  <button
                    onClick={() => handleBuy(item)}
                    className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-950/40"
                  >
                    Equip
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>
    </div>
  );
};
