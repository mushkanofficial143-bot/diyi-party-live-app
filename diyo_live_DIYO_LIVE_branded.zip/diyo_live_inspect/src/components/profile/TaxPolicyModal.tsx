import React from 'react';
import { X, ShieldCheck, DollarSign, Percent, Crown, Coins, Gem, Gift, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

interface TaxPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentVipLevel?: number;
  onOpenVipModal?: () => void;
}

export const TaxPolicyModal: React.FC<TaxPolicyModalProps> = ({
  isOpen,
  onClose,
  currentVipLevel = 9,
  onOpenVipModal
}) => {
  if (!isOpen) return null;

  const vipDiscountCashout = currentVipLevel >= 8 ? 50 : currentVipLevel >= 5 ? 25 : 0;
  const vipTransferTax = currentVipLevel >= 4 ? 0 : 2.0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-neutral-950 border border-amber-500/40 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col shadow-2xl shadow-amber-950/50">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-amber-950/50 via-neutral-900 to-neutral-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-neutral-950 shadow-md">
              <DollarSign className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                PLATFORM TAX & FEE POLICY
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono font-bold">
                  Active
                </span>
              </h2>
              <p className="text-xs text-neutral-400">Standard Platform Surcharges & VIP Tax Rebates</p>
            </div>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          
          {/* Current VIP Benefit Status */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-neutral-900 to-amber-950/30 border border-amber-500/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xl">
                👑
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white text-sm">VIP {currentVipLevel} Privilege Active</span>
                </div>
                <p className="text-[11px] text-amber-300">
                  {vipDiscountCashout > 0 ? `${vipDiscountCashout}% Cashout Tax Rebate Applied!` : 'Standard Tax Tier'}
                </p>
              </div>
            </div>
            {onOpenVipModal && (
              <button
                onClick={() => {
                  onClose();
                  onOpenVipModal();
                }}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1 cursor-pointer transition-all"
              >
                <span>Upgrade VIP</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* 3 Main Tax Slabs */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
              Real-Time Tax & Surcharge Schedule
            </h3>

            {/* 1. Cashout / TDS Tax */}
            <div className="p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Gem className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-white text-sm">Diamond Withdrawal / TDS Tax</span>
                </div>
                <span className="font-mono font-black text-amber-400 text-sm">
                  {currentVipLevel >= 8 ? '2.5% (VIP 50% OFF)' : '5.0% Standard'}
                </span>
              </div>
              <p className="text-neutral-400 text-[11px] leading-relaxed">
                Applies to all eSewa, Bank Transfer, ePay, and USD payouts. High-tier VIP users receive an automatic 50% rebate.
              </p>
            </div>

            {/* 2. Coin Seller & P2P Trading Tax */}
            <div className="p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Coins className="w-4 h-4 text-yellow-400" />
                  <span className="font-bold text-white text-sm">Coins Trading & Transfer Tax</span>
                </div>
                <span className="font-mono font-black text-emerald-400 text-sm">
                  {vipTransferTax === 0 ? '0.0% (VIP Free)' : '2.0% Standard'}
                </span>
              </div>
              <p className="text-neutral-400 text-[11px] leading-relaxed">
                Platform fee for merchant coin distribution and peer-to-peer coin transfers. VIP 4+ enjoy 0% transfer tax.
              </p>
            </div>

            {/* 3. Live Stream Gifting Split */}
            <div className="p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Gift className="w-4 h-4 text-rose-400" />
                  <span className="font-bold text-white text-sm">Live Gift Revenue Split</span>
                </div>
                <span className="font-mono font-black text-white text-sm">
                  85% Host / 15% Platform
                </span>
              </div>
              <p className="text-neutral-400 text-[11px] leading-relaxed">
                Hosts receive 85% directly in withdrawable diamonds. 15% covers streaming infrastructure and platform maintenance.
              </p>
            </div>
          </div>

          {/* VIP Tax Exemption Table */}
          <div className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2">
            <span className="font-bold text-neutral-300 block">VIP Nobility Tax Exemption Slabs</span>
            <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono">
              <div className="p-2 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-neutral-400 block">VIP 1–3</span>
                <span className="text-white font-bold block mt-0.5">5% Tax</span>
                <span className="text-neutral-500">2% Transfer</span>
              </div>
              <div className="p-2 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-amber-400 font-bold block">VIP 4–7</span>
                <span className="text-emerald-400 font-bold block mt-0.5">3.75% Tax</span>
                <span className="text-emerald-300">0% Transfer</span>
              </div>
              <div className="p-2 rounded-xl bg-neutral-950 border border-amber-500/40">
                <span className="text-yellow-300 font-bold block">VIP 8–10</span>
                <span className="text-yellow-400 font-bold block mt-0.5">2.5% Tax</span>
                <span className="text-emerald-300">0% Transfer</span>
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-neutral-800 bg-neutral-900/90 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-neutral-400 text-[11px]">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Encrypted & Compliant Financial Engine</span>
          </div>
          <button
            onClick={() => {
              playSoundFX('click');
              onClose();
            }}
            className="px-4 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs cursor-pointer transition-all"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
