import React, { useState } from 'react';
import { 
  Shield, 
  Crown, 
  Star, 
  Sparkles, 
  Copy, 
  Check, 
  MessageSquare, 
  UserPlus, 
  Gift, 
  X, 
  Flame, 
  Award,
  Heart,
  Flag,
  MoreHorizontal
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';

export interface UserProfileCardData {
  id: string;
  name: string;
  avatar: string;
  gender?: 'male' | 'female';
  countryFlag?: string;
  countryCode?: string;
  level?: number;
  vipLevel?: number;
  roleTag?: string; // 'Agent', 'Host', 'Mod', 'Owner', 'TopFan'
  guildName?: string; // 'nily Te...', 'SR Royals'
  seniorityBadge?: string; // 'Senior', 'Veteran', 'Elite'
  isCoinSeller?: boolean;
  coinSellerTitle?: string; // 'TESFA COIN SELLER BD'
  customFrameUrl?: string;
  followingCount?: number;
  followersCount?: number;
  bio?: string;
  isFollowing?: boolean;
  diamondsEarned?: number;
  seatNumber?: number;
}

interface UserProfileCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfileCardData | null;
  onSendGift?: (user: UserProfileCardData) => void;
  onSendMessage?: (user: UserProfileCardData) => void;
  onToggleFollow?: (user: UserProfileCardData) => void;
}

export const UserProfileCardModal: React.FC<UserProfileCardModalProps> = ({
  isOpen,
  onClose,
  user,
  onSendGift,
  onSendMessage,
  onToggleFollow
}) => {
  const [copied, setCopied] = useState(false);
  const [isFollowing, setIsFollowing] = useState(user?.isFollowing || false);

  if (!isOpen || !user) return null;

  const handleCopyId = () => {
    navigator.clipboard.writeText(user.id.replace(/^USR-|^HST-/, ''));
    setCopied(true);
    playSoundFX('click');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFollowClick = () => {
    setIsFollowing(!isFollowing);
    playSoundFX('win');
    if (onToggleFollow) onToggleFollow(user);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in">
      <div 
        className="relative w-full max-w-md bg-gradient-to-b from-[#1c1829] via-[#120f1d] to-[#0a0812] border-t sm:border border-amber-500/30 rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-2xl shadow-purple-950/80 text-white animate-in slide-in-from-bottom-6"
      >
        {/* Top Floating Controls: Report & More & Close */}
        <div className="flex items-center justify-between pb-1">
          <button 
            onClick={() => playSoundFX('click')}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-neutral-900/90 border border-neutral-700/80 text-[11px] font-bold text-neutral-300 hover:text-white"
          >
            <Flag className="w-3 h-3 text-neutral-400" />
            <span>Report</span>
          </button>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => playSoundFX('click')}
              className="p-1.5 rounded-full bg-neutral-900/90 border border-neutral-700/80 text-neutral-300 hover:text-white"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>
            <button 
              onClick={onClose}
              className="p-1.5 rounded-full bg-neutral-900/90 border border-neutral-700/80 text-neutral-300 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Center: Grand Imperial Crest Frame & User Avatar */}
        <div className="flex flex-col items-center -mt-2 relative">
          {/* Ornate Gold Crown Crest Badge */}
          <div className="relative flex flex-col items-center">
            {/* Top decorative Crown */}
            <div className="flex items-center gap-1 -mb-2 z-10">
              <span className="text-amber-400 font-black text-xs drop-shadow-[0_0_8px_rgba(251,191,36,0.9)]">$$$</span>
              <Crown className="w-6 h-6 text-yellow-300 fill-amber-400 drop-shadow-[0_0_12px_rgba(234,179,8,0.9)] animate-pulse" />
              <span className="text-amber-400 font-black text-xs drop-shadow-[0_0_8px_rgba(251,191,36,0.9)]">$$$</span>
            </div>

            {/* Glowing Ornate Gold Crest Border */}
            <div className="relative p-1.5 rounded-3xl bg-gradient-to-b from-yellow-300 via-amber-600 to-yellow-700 border-2 border-yellow-200 shadow-[0_0_25px_rgba(245,158,11,0.6)]">
              <div className="relative p-1 rounded-2xl bg-neutral-950">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover ring-2 ring-yellow-400/80"
                />
                {/* Active Online Indicator */}
                <span className="absolute bottom-2 right-2 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-neutral-950 shadow-[0_0_8px_rgba(16,185,129,0.9)]" />
              </div>
            </div>

            {/* Imperial Title Ribbon Banner */}
            <div className="mt-1 px-4 py-0.5 rounded-full bg-gradient-to-r from-amber-600 via-yellow-400 to-amber-600 border border-yellow-200 shadow-lg text-center">
              <div className="text-[11px] font-black text-neutral-950 uppercase tracking-widest drop-shadow-[0_1px_1px_rgba(255,255,255,0.7)]">
                {user.coinSellerTitle || (user.roleTag ? `${user.roleTag.toUpperCase()} VIP` : 'TESFA COIN SELLER BD')}
              </div>
              <div className="text-[9px] font-bold text-neutral-900 font-mono -mt-0.5">
                ID {user.id.replace(/^USR-|^HST-/, '')}
              </div>
            </div>
          </div>

          {/* User Name + Flag + Gender */}
          <div className="flex items-center gap-2 mt-3">
            <h3 className="text-lg font-black text-white tracking-wide drop-shadow-md">
              {user.name}
            </h3>
            <span className="text-base" title="Country Flag">
              {user.countryFlag || '🇪🇹'}
            </span>
            <span className="text-sm font-bold text-sky-400 font-mono">
              {user.gender === 'female' ? '♀️' : '♂️'}
            </span>
          </div>

          {/* Authentic Badges / Tags Row */}
          <div className="flex items-center justify-center gap-1.5 flex-wrap mt-2.5 max-w-full">
            {/* 1. Level Badge with Wings */}
            <div className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-gradient-to-r from-purple-700 to-fuchsia-600 border border-purple-300/80 text-[10px] font-black text-white shadow-md shadow-purple-900/50">
              <span className="text-purple-200">💜</span>
              <span>{user.level || 24}</span>
            </div>

            {/* 2. Country Tag */}
            <div className="inline-flex items-center px-2 py-0.5 rounded-full bg-gradient-to-r from-emerald-800 via-red-700 to-emerald-800 border border-amber-400/80 text-[10px] font-black text-amber-200 shadow-sm">
              <span>{user.countryCode || 'BD'}</span>
            </div>

            {/* 3. Role / Agent Shield Badge */}
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-700 via-red-800 to-amber-900 border border-yellow-400/90 text-[10px] font-black text-amber-100 shadow-md">
              <Shield className="w-3 h-3 text-amber-300 fill-amber-400" />
              <span>{user.roleTag || 'Agent'}</span>
            </div>

            {/* 4. Guild / Family Tag */}
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-indigo-900 via-purple-800 to-pink-900 border border-fuchsia-400/70 text-[10px] font-black text-purple-200 shadow-md">
              <Crown className="w-2.5 h-2.5 text-yellow-300" />
              <span>{user.guildName || 'nily Te...'}</span>
            </div>

            {/* 5. Seniority Badge */}
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-purple-900 to-violet-800 border border-purple-400/70 text-[10px] font-black text-purple-200 shadow-md">
              <Star className="w-2.5 h-2.5 text-yellow-300 fill-yellow-300" />
              <span>{user.seniorityBadge || 'Senior'}</span>
            </div>

            {/* 6. Diamond Rank Shield */}
            <div className="inline-flex items-center px-1.5 py-0.5 rounded-md bg-gradient-to-r from-cyan-600 to-blue-700 border border-cyan-300 text-[10px] font-black text-white shadow-sm">
              <span>💎</span>
            </div>

            {/* Mention @ Button */}
            <button 
              onClick={() => playSoundFX('click')}
              className="w-6 h-6 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center text-xs font-bold text-neutral-300 hover:text-white"
              title="Mention in chat"
            >
              @
            </button>
          </div>

          {/* Copyable ID */}
          <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-400 font-mono">
            <span>ID {user.id.replace(/^USR-|^HST-/, '')}</span>
            <button 
              onClick={handleCopyId}
              className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-amber-400 transition-colors"
              title="Copy ID"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            {copied && <span className="text-[10px] text-emerald-400 font-sans font-bold">Copied!</span>}
          </div>

          {/* Following & Followers Stats */}
          <div className="grid grid-cols-2 divide-x divide-neutral-800 w-full max-w-xs mt-3 pt-3 border-t border-neutral-800/80 text-center">
            <div>
              <div className="text-base font-black text-white font-mono">
                {user.followingCount || 31}
              </div>
              <div className="text-[11px] text-neutral-400 font-bold">Follow</div>
            </div>
            <div>
              <div className="text-base font-black text-white font-mono">
                {user.followersCount || 839}
              </div>
              <div className="text-[11px] text-neutral-400 font-bold">Followers</div>
            </div>
          </div>

          {/* Bio Quote */}
          <div className="text-xs text-neutral-300 italic mt-3 text-center px-4">
            "{user.bio || 'Can you be my friend?'}"
          </div>

          {/* Bottom Action Ribbon: Chat, Follow (+), and Gift Hands Box */}
          <div className="flex items-center justify-center gap-3 w-full max-w-xs mt-5">
            {/* Chat button */}
            <button
              onClick={() => {
                playSoundFX('click');
                if (onSendMessage) onSendMessage(user);
                onClose();
              }}
              className="w-12 h-12 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/80 flex items-center justify-center text-neutral-300 hover:text-white transition-transform active:scale-95 shadow-lg"
              title="Send Direct Message"
            >
              <MessageSquare className="w-5 h-5" />
            </button>

            {/* Follow (+) Button */}
            <button
              onClick={handleFollowClick}
              className={`w-12 h-12 rounded-full flex items-center justify-center font-black transition-transform active:scale-95 shadow-lg ${
                isFollowing
                  ? 'bg-emerald-600 text-white border border-emerald-400'
                  : 'bg-gradient-to-r from-teal-400 to-cyan-500 text-neutral-950 border border-cyan-300 hover:brightness-110'
              }`}
              title={isFollowing ? 'Following' : 'Add Friend / Follow'}
            >
              {isFollowing ? <Check className="w-6 h-6 stroke-[3]" /> : <UserPlus className="w-6 h-6 stroke-[2.5]" />}
            </button>

            {/* Gift Box with Hands Glowing Button */}
            <button
              onClick={() => {
                playSoundFX('superchat');
                if (onSendGift) onSendGift(user);
                onClose();
              }}
              className="flex-1 h-12 rounded-full bg-gradient-to-r from-cyan-400 via-teal-300 to-cyan-400 hover:from-cyan-300 hover:to-teal-200 text-neutral-950 font-black text-xs flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(45,212,191,0.5)] border border-cyan-200 transition-transform active:scale-95 group relative overflow-hidden"
              title="Send Gifts & Lucky Boxes"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none" />
              <span className="text-lg">🎁</span>
              <span className="font-extrabold tracking-wider uppercase text-neutral-900">Send Gift</span>
              <span className="text-base">✨</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
