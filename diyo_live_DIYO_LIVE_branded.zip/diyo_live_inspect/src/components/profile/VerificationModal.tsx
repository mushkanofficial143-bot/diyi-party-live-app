import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  Camera, 
  FileText, 
  UserCheck, 
  Sparkles, 
  AlertCircle, 
  Upload,
  Lock
} from 'lucide-react';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  isVerified?: boolean;
}

export const VerificationModal: React.FC<VerificationModalProps> = ({
  isOpen,
  onClose,
  isVerified = false
}) => {
  const [realName, setRealName] = useState('DIYO Host');
  const [idNumber, setIdNumber] = useState('NP-89421094');
  const [documentType, setDocumentType] = useState('PASSPORT');
  const [hasUploadedId, setHasUploadedId] = useState(true);
  const [hasCompletedFaceCheck, setHasCompletedFaceCheck] = useState(true);
  const [verificationStatus, setVerificationStatus] = useState<'VERIFIED' | 'PENDING' | 'UNVERIFIED'>(isVerified ? 'VERIFIED' : 'VERIFIED');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmitKyc = (e: React.FormEvent) => {
    e.preventDefault();
    setVerificationStatus('VERIFIED');
    playSoundFX('superchat');
    confetti({ particleCount: 50, spread: 70 });
    setToastMsg('KYC Verification Approved! Verified Broadcaster badge active.');
    setTimeout(() => setToastMsg(null), 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-950 border border-sky-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-sky-500/20 text-sky-300 border border-sky-500/40 flex items-center justify-center shadow-md">
              <ShieldCheck className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white">Identity & Host Verification</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-sky-500/20 text-sky-300 border border-sky-500/40">
                  OFFICIAL KYC
                </span>
              </div>
              <p className="text-xs text-neutral-400">Get the blue verified checkmark & unlock diamond withdrawals</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Verification Status Banner */}
        <div className="p-4 bg-sky-950/20 border-b border-sky-500/20 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <div>
              <h4 className="text-xs font-black text-white">Official Verified Broadcaster</h4>
              <p className="text-[10px] text-sky-200/80">Real identity confirmed • Withdrawals enabled</p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-mono font-bold">
            STATUS: VERIFIED ✓
          </span>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-sky-500/20 border border-sky-500/50 text-sky-200 text-xs font-bold text-center animate-in zoom-in-95">
            {toastMsg}
          </div>
        )}

        {/* Form Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Verified Details</h4>
            
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1.5 border-b border-neutral-900">
                <span className="text-neutral-400">Legal Full Name:</span>
                <span className="text-white font-mono font-semibold">{realName}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-neutral-900">
                <span className="text-neutral-400">Document Type:</span>
                <span className="text-white font-semibold">National ID / Passport</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-neutral-900">
                <span className="text-neutral-400">Document ID:</span>
                <span className="text-sky-300 font-mono font-semibold">{idNumber}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-neutral-400">Live Face Recognition:</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Passed 100%
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-center space-y-1">
              <span className="text-[10px] text-neutral-400 block">Withdrawal Limit</span>
              <span className="text-sm font-black text-emerald-400">$10,000 / Day</span>
            </div>
            <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-center space-y-1">
              <span className="text-[10px] text-neutral-400 block">Host Protection</span>
              <span className="text-sm font-black text-sky-400">VIP Priority</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
