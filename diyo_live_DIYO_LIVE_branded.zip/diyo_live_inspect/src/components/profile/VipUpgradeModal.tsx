import React from 'react';
import { VipNobilityCenter } from '../vip/VipNobilityCenter.js';
import { VipTierConfig } from '../../types/ownerTypes.js';

interface VipUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentVipLevel: number;
  vipConfigs?: VipTierConfig[];
  userCoinsSpent?: number;
  userCoins?: number;
  userId?: string;
  userName?: string;
  userAvatar?: string;
  onUpgradeVip?: (targetLevel: number) => void;
  onUpgrade?: (targetLevel: number) => void;
}

export const VipUpgradeModal: React.FC<VipUpgradeModalProps> = ({
  isOpen,
  onClose,
  currentVipLevel = 1,
  userCoins = 5200422000,
  userId = 'USR-882941',
  userName = 'Aarav Mehta',
  userAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  onUpgradeVip,
  onUpgrade
}) => {
  if (!isOpen) return null;

  return (
    <VipNobilityCenter
      isOpen={isOpen}
      onClose={onClose}
      userId={userId}
      userName={userName}
      userAvatar={userAvatar}
      userCoins={userCoins}
      currentVipLevel={currentVipLevel}
      onVipUpdated={(newLevel, newBalance) => {
        if (typeof onUpgradeVip === 'function') {
          onUpgradeVip(newLevel);
        } else if (typeof onUpgrade === 'function') {
          onUpgrade(newLevel);
        }
      }}
    />
  );
};

