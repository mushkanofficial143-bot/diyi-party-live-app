import React, { useState, useEffect } from 'react';
import { 
  X, 
  Coins, 
  Gem, 
  ArrowUpRight, 
  ArrowDownLeft, 
  History, 
  ShieldCheck, 
  Plus, 
  Zap, 
  AlertCircle,
  CheckCircle2,
  Send,
  RefreshCw,
  User,
  Search,
  Lock,
  Sparkles,
  Info,
  SlidersHorizontal,
  ArrowRight,
  Banknote,
  Building2,
  CreditCard,
  Smartphone,
  DollarSign,
  Clock,
  Receipt,
  ExternalLink,
  Shield,
  QrCode,
  Check,
  ChevronRight
} from 'lucide-react';
import { WalletTransaction, PlatformWalletSettings } from '../../types/ownerTypes';
import { playSoundFX } from '../../utils/audioSynth';

export type PayoutMethod = 'ESEWA' | 'BANK' | 'EPAY' | 'USD';

export interface WithdrawalItem {
  id: string;
  userId: string;
  userName: string;
  method: PayoutMethod;
  methodLabel: string;
  diamondAmount: number;
  fiatAmountUSD: number;
  fiatAmountLocal: number;
  currency: 'USD' | 'NPR' | 'INR';
  exchangeRate: number;
  accountDetails: any;
  processingFeeUSD: number;
  netPayoutUSD: number;
  netPayoutLocal: number;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'REJECTED' | 'CANCELLED';
  txHash?: string;
  referenceCode: string;
  submittedAt: string;
  processedAt?: string;
  notes?: string;
}

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: {
    id: string;
    name: string;
    username?: string;
    avatar?: string;
    coinBalance: number;
    diamondBalance: number;
    vipLevel?: number;
    role?: string;
    agencyId?: string;
    hostTag?: string;
  };
  coinBalance: number;
  diamondBalance: number;
  onRechargeCoins: (amount: number) => void;
  onTransferCoins?: (recipientId: string, amount: number, notes?: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  onExchangeCoins?: (amount: number) => Promise<{ success: boolean; error?: string; message?: string }>;
  onWithdrawDiamonds?: (method: PayoutMethod, diamonds: number, accountDetails: any) => Promise<{ success: boolean; error?: string; message?: string; withdrawal?: any }>;
  transactions: WalletTransaction[];
  walletSettings?: PlatformWalletSettings;
  platformUsers?: Array<{
    id: string;
    name: string;
    username?: string;
    avatar?: string;
    coinBalance?: number;
    diamondBalance?: number;
  }>;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  isOpen,
  onClose,
  currentUser = {
    id: 'USR-882941',
    name: 'Aarav Mehta',
    username: 'aarav_vip',
    coinBalance: 245000,
    diamondBalance: 18500,
    vipLevel: 9
  } as any,
  coinBalance,
  diamondBalance,
  onRechargeCoins,
  onTransferCoins,
  onExchangeCoins,
  onWithdrawDiamonds,
  transactions = [],
  walletSettings = {
    userTransferEnabled: true,
    virtualExchangeEnabled: true,
    minTransferAmount: 100,
    maxTransferAmount: 10000000,
    coinToDiamondRate: 1.0,
    testModeNotice: "Cash withdrawals available for eSewa, Direct Bank, ePay, and USD (USDT/PayPal)."
  },
  platformUsers = [
    { id: 'USR-8001', name: 'Rohan Joshi', username: 'rohan_star', coinBalance: 120000, diamondBalance: 8500 },
    { id: 'USR-8002', name: 'Meera Patel', username: 'meera_queen', coinBalance: 85000, diamondBalance: 12000 },
    { id: 'USR-8003', name: 'Zoya Khan', username: 'zoya_live', coinBalance: 450000, diamondBalance: 35000 },
    { id: 'USR-8004', name: 'David Miller', username: 'david_gamer', coinBalance: 15000, diamondBalance: 1200 }
  ]
}) => {
  const isHostWithoutAgency = (currentUser.role === 'HOST' || (currentUser as any).hostTag) && (!currentUser.agencyId || currentUser.agencyId.trim() === '');
  const [activeTab, setActiveTab] = useState<'withdraw' | 'transfer' | 'exchange' | 'history' | 'recharge'>(isHostWithoutAgency ? 'transfer' : 'withdraw');
  
  // Real Money Withdrawal State
  const [withdrawMethod, setWithdrawMethod] = useState<PayoutMethod>('ESEWA');
  const [withdrawDiamonds, setWithdrawDiamonds] = useState<number | string>(10000);
  const [esewaId, setEsewaId] = useState<string>('9841029384');
  const [accountHolderName, setAccountHolderName] = useState<string>(currentUser.name || 'Aarav Mehta');
  const [bankName, setBankName] = useState<string>('Nabil Bank Limited');
  const [bankAccountNumber, setBankAccountNumber] = useState<string>('00100175029182');
  const [bankBranchCode, setBankBranchCode] = useState<string>('NARBNPKA / Kathmandu Main Branch');
  const [epayId, setEpayId] = useState<string>('epay_aarav_99');
  const [payoutTypeUSD, setPayoutTypeUSD] = useState<'USDT_TRC20' | 'USDT_ERC20' | 'PAYPAL' | 'WIRE'>('USDT_TRC20');
  const [usdtAddress, setUsdtAddress] = useState<string>('TXn871KaB92MopQrZ21KLa90vVnmQ19p02');
  const [paypalEmail, setPaypalEmail] = useState<string>('aarav.mehta@srlive.io');
  
  const [withdrawLoading, setWithdrawLoading] = useState<boolean>(false);
  const [withdrawError, setWithdrawError] = useState<string | null>(null);
  const [withdrawReceipt, setWithdrawReceipt] = useState<WithdrawalItem | null>(null);
  const [withdrawalsList, setWithdrawalsList] = useState<WithdrawalItem[]>([]);
  const [cancelLoadingId, setCancelLoadingId] = useState<string | null>(null);

  // Transfer Form State
  const [targetUserId, setTargetUserId] = useState<string>('USR-8001');
  const [transferAmount, setTransferAmount] = useState<number | string>(5000);
  const [transferNotes, setTransferNotes] = useState<string>('');
  const [transferLoading, setTransferLoading] = useState<boolean>(false);
  const [transferError, setTransferError] = useState<string | null>(null);

  // Exchange Form State
  const [exchangeAmount, setExchangeAmount] = useState<number | string>(10000);
  const [exchangeLoading, setExchangeLoading] = useState<boolean>(false);
  const [exchangeError, setExchangeError] = useState<string | null>(null);

  // Recharging
  const [selectedPack, setSelectedPack] = useState<number>(50000);
  
  // Feedback
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [historyFilter, setHistoryFilter] = useState<'ALL' | 'WITHDRAW' | 'RECEIVED' | 'SENT' | 'EXCHANGE' | 'RECHARGE'>('ALL');

  // Load existing withdrawals
  const loadWithdrawals = async () => {
    try {
      const res = await fetch(`/api/wallet/withdrawals?userId=${currentUser.id}`);
      const data = await res.json();
      if (data.success && data.withdrawals) {
        setWithdrawalsList(data.withdrawals);
      }
    } catch (e) {
      // Fallback
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadWithdrawals();
    }
  }, [isOpen, currentUser.id]);

  if (!isOpen) return null;

  const currentCoins = coinBalance ?? currentUser.coinBalance ?? 0;
  const currentDiamonds = diamondBalance ?? currentUser.diamondBalance ?? 0;
  const rate = walletSettings?.coinToDiamondRate ?? 1.0;
  const minTransfer = walletSettings?.minTransferAmount ?? 100;
  const maxTransfer = walletSettings?.maxTransferAmount ?? 10000000;
  const isTransferEnabled = walletSettings?.userTransferEnabled ?? true;
  const isExchangeEnabled = walletSettings?.virtualExchangeEnabled ?? true;

  // Candidate recipients (excluding current user)
  const candidateRecipients = (platformUsers || []).filter(u => u && u.id !== currentUser?.id);
  const selectedRecipientObj = (platformUsers || []).find(
    u => u && (u.id === targetUserId || (u.username && u.username === targetUserId.replace('@', '')))
  );

  const rechargePacks = [
    { coins: 10000, bonus: 0, tag: 'Starter' },
    { coins: 50000, bonus: 2500, tag: 'Popular', isHot: true },
    { coins: 100000, bonus: 8000, tag: 'Best Value' },
    { coins: 500000, bonus: 50000, tag: 'VIP Mega', isVip: true },
    { coins: 1000000, bonus: 150000, tag: 'Whale Pack', isVip: true },
  ];

  // WITHDRAWAL CALCULATION
  const numWithdrawDiamonds = Math.max(0, Number(withdrawDiamonds) || 0);
  const diamondRate = 10000; // 10,000 Diamonds = $1.00 USD (100,000 = $10)
  const grossUSD = Number((numWithdrawDiamonds / diamondRate).toFixed(2));
  
  const nprRate = 135.0; // 1 USD = 135 NPR
  const inrRate = 88.0;  // 1 USD = 88 INR

  let feePercent = 0.0;
  let targetCurrency: 'NPR' | 'USD' | 'INR' = 'USD';
  let currencyRate = 1.0;

  if (withdrawMethod === 'ESEWA') {
    feePercent = 0.0;
    targetCurrency = 'NPR';
    currencyRate = nprRate;
  } else if (withdrawMethod === 'BANK') {
    feePercent = 1.5;
    targetCurrency = 'NPR';
    currencyRate = nprRate;
  } else if (withdrawMethod === 'EPAY') {
    feePercent = 1.0;
    targetCurrency = 'USD';
    currencyRate = 1.0;
  } else if (withdrawMethod === 'USD') {
    feePercent = 0.0;
    targetCurrency = 'USD';
    currencyRate = 1.0;
  }

  // TDS / Platform Tax (5% base, VIP 8+ gets 50% discount = 2.5%, VIP 5-7 gets 25% discount = 3.75%)
  const userVip = currentUser?.vipLevel || 9;
  const taxDiscountPercent = userVip >= 8 ? 50 : userVip >= 5 ? 25 : 0;
  const standardTaxRate = 5.0; // 5%
  const effectiveTaxRate = standardTaxRate * (1 - taxDiscountPercent / 100);
  
  const taxUSD = Number(((grossUSD * effectiveTaxRate) / 100).toFixed(2));
  const feeUSD = Number(((grossUSD * feePercent) / 100).toFixed(2));
  const totalDeductionsUSD = Number((taxUSD + feeUSD).toFixed(2));
  const netUSD = Math.max(0, Number((grossUSD - totalDeductionsUSD).toFixed(2)));
  const netLocal = Number((netUSD * currencyRate).toFixed(2));

  // EXECUTE REAL MONEY WITHDRAWAL
  const handleExecuteWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError(null);

    if (numWithdrawDiamonds < 5000) {
      setWithdrawError("Minimum withdrawal amount is 5,000 Diamonds ($5.00 USD).");
      playSoundFX('alert');
      return;
    }

    if (currentDiamonds < numWithdrawDiamonds) {
      setWithdrawError(`Insufficient Diamond balance! Available: ${(currentDiamonds ?? 0).toLocaleString()} 💎, requested: ${(numWithdrawDiamonds ?? 0).toLocaleString()} 💎.`);
      playSoundFX('alert');
      return;
    }

    // Build Account details
    let accountDetails: any = {
      accountHolderName: accountHolderName.trim()
    };

    if (withdrawMethod === 'ESEWA') {
      if (!esewaId.trim() || esewaId.trim().length < 8) {
        setWithdrawError("Please enter a valid eSewa ID / Mobile number (e.g. 9841029384).");
        playSoundFX('alert');
        return;
      }
      accountDetails.esewaId = esewaId.trim();
    } else if (withdrawMethod === 'BANK') {
      if (!bankName.trim()) {
        setWithdrawError("Please enter your Bank Name.");
        playSoundFX('alert');
        return;
      }
      if (!bankAccountNumber.trim() || bankAccountNumber.trim().length < 6) {
        setWithdrawError("Please enter a valid Bank Account Number.");
        playSoundFX('alert');
        return;
      }
      accountDetails.bankName = bankName.trim();
      accountDetails.accountNumber = bankAccountNumber.trim();
      accountDetails.ifscOrSwiftCode = bankBranchCode.trim();
    } else if (withdrawMethod === 'EPAY') {
      if (!epayId.trim()) {
        setWithdrawError("Please enter your ePay ID or registered phone/email.");
        playSoundFX('alert');
        return;
      }
      accountDetails.epayId = epayId.trim();
    } else if (withdrawMethod === 'USD') {
      accountDetails.payoutTypeUSD = payoutTypeUSD;
      if (payoutTypeUSD === 'PAYPAL') {
        if (!paypalEmail.trim() || !paypalEmail.includes('@')) {
          setWithdrawError("Please enter a valid PayPal email address.");
          playSoundFX('alert');
          return;
        }
        accountDetails.paypalEmail = paypalEmail.trim();
      } else {
        if (!usdtAddress.trim() || usdtAddress.trim().length < 20) {
          setWithdrawError("Please enter a valid USDT Wallet Address (TRC20 / ERC20).");
          playSoundFX('alert');
          return;
        }
        accountDetails.usdtAddress = usdtAddress.trim();
      }
    }

    setWithdrawLoading(true);
    try {
      const res = await fetch('/api/wallet/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          diamonds: numWithdrawDiamonds,
          method: withdrawMethod,
          accountDetails,
          notes: `Real money withdrawal via ${withdrawMethod}`
        })
      });

      const data = await res.json();
      if (!data.success) {
        setWithdrawError(data.error || "Withdrawal failed. Please check your account details.");
        playSoundFX('alert');
        setWithdrawLoading(false);
        return;
      }

      playSoundFX('win');
      setWithdrawReceipt(data.withdrawal);
      setWithdrawalsList(prev => [data.withdrawal, ...prev]);
      setSuccessToast(`🎉 Withdrawal of ${(numWithdrawDiamonds ?? 0).toLocaleString()} Diamonds ($${netUSD.toFixed(2)} USD / ${(netLocal ?? 0).toLocaleString()} ${targetCurrency}) submitted!`);
      
      // Update parent if handler provided
      if (onWithdrawDiamonds) {
        await onWithdrawDiamonds(withdrawMethod, numWithdrawDiamonds, accountDetails);
      }

      // Auto clear error
      setWithdrawError(null);
    } catch (err: any) {
      setWithdrawError(err.message || "Failed to submit withdrawal request.");
      playSoundFX('alert');
    } finally {
      setWithdrawLoading(false);
    }
  };

  // CANCEL WITHDRAWAL & REFUND DIAMONDS
  const handleCancelWithdrawal = async (wdId: string) => {
    setCancelLoadingId(wdId);
    try {
      const res = await fetch('/api/wallet/withdrawal/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ withdrawalId: wdId, userId: currentUser.id })
      });
      const data = await res.json();
      if (data.success) {
        playSoundFX('win');
        setWithdrawalsList(prev => prev.map(w => w.id === wdId ? { ...w, status: 'CANCELLED', notes: 'Cancelled by user. Diamonds refunded.' } : w));
        setSuccessToast(`✅ Withdrawal cancelled. Diamonds refunded to your balance!`);
        setTimeout(() => setSuccessToast(null), 4000);
      } else {
        setWithdrawError(data.error || "Failed to cancel withdrawal.");
        playSoundFX('alert');
      }
    } catch (err: any) {
      setWithdrawError(err.message || "Network error while cancelling.");
    } finally {
      setCancelLoadingId(null);
    }
  };

  // Execute User-to-User Transfer
  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setTransferError(null);

    if (!isTransferEnabled) {
      setTransferError("User-to-User coin transfer is currently disabled by the Platform Owner.");
      playSoundFX('alert');
      return;
    }

    const numAmount = Number(transferAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setTransferError("Please enter a valid amount of coins to transfer.");
      playSoundFX('alert');
      return;
    }

    if (numAmount < minTransfer) {
      setTransferError(`Minimum transfer amount is ${(minTransfer ?? 0).toLocaleString()} LIVE COINS.`);
      playSoundFX('alert');
      return;
    }

    if (numAmount > maxTransfer) {
      setTransferError(`Maximum transfer limit is ${(maxTransfer ?? 0).toLocaleString()} LIVE COINS per transaction.`);
      playSoundFX('alert');
      return;
    }

    if (currentCoins < numAmount) {
      setTransferError(`Insufficient LIVE COINS! Available balance: ${(currentCoins ?? 0).toLocaleString()} 🪙.`);
      playSoundFX('alert');
      return;
    }

    if (!targetUserId.trim()) {
      setTransferError("Please enter or select a valid recipient User ID.");
      playSoundFX('alert');
      return;
    }

    setTransferLoading(true);
    try {
      if (onTransferCoins) {
        const result = await onTransferCoins(targetUserId, numAmount, transferNotes);
        if (result && !result.success) {
          setTransferError(result.error || "Transfer failed.");
          playSoundFX('alert');
          setTransferLoading(false);
          return;
        }
      }
      playSoundFX('win');
      setSuccessToast(`🎉 Successfully sent ${(numAmount ?? 0).toLocaleString()} LIVE COINS to ${selectedRecipientObj?.name || targetUserId}!`);
      setTransferNotes('');
      setTimeout(() => setSuccessToast(null), 4500);
    } catch (err: any) {
      setTransferError(err.message || "Failed to process server-side transfer.");
      playSoundFX('alert');
    } finally {
      setTransferLoading(false);
    }
  };

  // Execute Virtual Exchange
  const handleExecuteExchange = async (e: React.FormEvent) => {
    e.preventDefault();
    setExchangeError(null);

    if (!isExchangeEnabled) {
      setExchangeError("Virtual Exchange is currently disabled by the Platform Owner.");
      playSoundFX('alert');
      return;
    }

    const numAmount = Number(exchangeAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setExchangeError("Please enter a valid coin amount to exchange.");
      playSoundFX('alert');
      return;
    }

    if (currentCoins < numAmount) {
      setExchangeError(`Insufficient LIVE COINS! Available balance: ${(currentCoins ?? 0).toLocaleString()} 🪙.`);
      playSoundFX('alert');
      return;
    }

    const expectedDiamonds = Math.floor(numAmount * rate);
    if (expectedDiamonds <= 0) {
      setExchangeError("Exchange amount is too small. Please exchange more coins.");
      playSoundFX('alert');
      return;
    }

    setExchangeLoading(true);
    try {
      if (onExchangeCoins) {
        const result = await onExchangeCoins(numAmount);
        if (result && !result.success) {
          setExchangeError(result.error || "Exchange failed.");
          playSoundFX('alert');
          setExchangeLoading(false);
          return;
        }
      }
      playSoundFX('win');
      setSuccessToast(`✨ Exchanged ${(numAmount ?? 0).toLocaleString()} LIVE COINS into ${(expectedDiamonds ?? 0).toLocaleString()} Virtual Diamonds!`);
      setTimeout(() => setSuccessToast(null), 4500);
    } catch (err: any) {
      setExchangeError(err.message || "Failed to execute virtual exchange.");
      playSoundFX('alert');
    } finally {
      setExchangeLoading(false);
    }
  };

  // Execute Recharge
  const handleExecuteRecharge = (amount: number) => {
    onRechargeCoins(amount);
    playSoundFX('win');
    setSuccessToast(`🎉 Added +${(amount ?? 0).toLocaleString()} Free LIVE COINS!`);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  // Filtered transactions
  const filteredTxs = (transactions || []).filter(tx => {
    if (!tx) return false;
    if (historyFilter === 'ALL') return true;
    if (historyFilter === 'WITHDRAW') return tx.type === 'Payout' || (tx.type && tx.type.includes('WITHDRAW'));
    if (historyFilter === 'RECEIVED') return tx.type === 'USER_TRANSFER_RECEIVED' || ((tx.amountCoins ?? 0) > 0 && tx.type && tx.type.includes('TRANSFER'));
    if (historyFilter === 'SENT') return tx.type === 'USER_TRANSFER_SENT' || ((tx.amountCoins ?? 0) < 0 && tx.type && tx.type.includes('TRANSFER'));
    if (historyFilter === 'EXCHANGE') return tx.type === 'VIRTUAL_EXCHANGE' || tx.type === 'Diamond_Convert';
    if (historyFilter === 'RECHARGE') return tx.type === 'FAUCET_RECHARGE' || tx.type === 'Deposit';
    return true;
  });

  const receivedTxs = (transactions || []).filter(tx => 
    tx && (tx.type === 'USER_TRANSFER_RECEIVED' || (tx.receiverId === currentUser?.id && (tx.amountCoins ?? 0) > 0))
  );

  return (
    <div id="sr-live-test-wallet-modal" className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="bg-neutral-950 border border-emerald-500/30 rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl shadow-emerald-950/40">
        
        {/* Header Bar */}
        <div className="px-5 sm:px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 via-amber-500 to-yellow-400 flex items-center justify-center text-neutral-950 shadow-lg shadow-amber-950/40">
              <Banknote className="w-5 h-5 text-neutral-950 font-black" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white tracking-tight">DIYO LIVE FINANCIAL WALLET</h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase font-mono font-bold">
                  Real Payouts Active
                </span>
              </div>
              <p className="text-xs text-neutral-400">eSewa • Bank Transfer • ePay • USD (USDT / PayPal)</p>
            </div>
          </div>
          <button
            id="close-wallet-modal-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Balances Display Banner (Single Unified Financial Wallet) */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950/50 via-neutral-900 to-teal-950/50 border-b border-neutral-800">
          <div className="p-4 sm:p-5 rounded-2xl bg-neutral-900/95 border border-emerald-500/50 shadow-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                <Gem className="w-4 h-4 text-emerald-400" /> TROPHY PARTY FINANCIAL WALLET
              </span>
              <span className="text-[10px] text-emerald-300 font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                ≈ ${(currentDiamonds / 1000).toFixed(2)} USD
              </span>
            </div>
            <div className="flex items-baseline justify-between pt-1">
              <div>
                <p className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight flex items-baseline gap-1.5">
                  {(currentDiamonds ?? 0).toLocaleString()} <span className="text-emerald-400 text-lg">💎 Withdrawable Diamonds</span>
                </p>
                <p className="text-xs text-neutral-400 mt-0.5">
                  ≈ Rs. {((currentDiamonds / 1000) * 135).toLocaleString()} NPR (eSewa / Bank / ePay / USDT)
                </p>
              </div>
              <div className="text-right hidden sm:block">
                <p className="text-xs text-amber-400 font-bold">{(currentCoins ?? 0).toLocaleString()} 🪙 Coins</p>
                <p className="text-[10px] text-neutral-500">In-App Balance</p>
              </div>
            </div>
          </div>

          {/* Quick Notice Banner */}
          <div className="mt-3 flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span className="font-semibold leading-tight">
              Real-money withdrawal enabled! Payouts to <strong>eSewa</strong>, <strong>Bank Transfer</strong>, <strong>ePay</strong>, and <strong>USD (USDT / PayPal)</strong> process with instant settlement.
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-neutral-800 px-3 sm:px-6 bg-neutral-900/60 overflow-x-auto">
          
          {!isHostWithoutAgency ? (
            <button
              id="tab-withdraw-money"
              onClick={() => { setActiveTab('withdraw'); playSoundFX('click'); }}
              className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'withdraw'
                  ? 'border-emerald-500 text-emerald-400 bg-emerald-500/10'
                  : 'border-transparent text-neutral-400 hover:text-white'
              }`}
            >
              <Banknote className="w-3.5 h-3.5" />
              <span>Withdraw (eSewa / Bank / ePay / USD)</span>
            </button>
          ) : (
            <div
              onClick={() => {
                playSoundFX('alert');
                alert('🔒 Withdrawal Section Locked: You must join an approved talent agency before you can withdraw earnings.');
              }}
              className="py-3 px-3 sm:px-4 text-xs font-bold border-b-2 border-transparent text-neutral-500 whitespace-nowrap flex items-center gap-1.5 cursor-pointer opacity-70 hover:text-amber-400"
              title="Join an agency to unlock withdrawals"
            >
              <span>🔒 Withdraw (Agency Required)</span>
            </div>
          )}

          <button
            id="tab-send-coins"
            onClick={() => { setActiveTab('transfer'); playSoundFX('click'); }}
            className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'transfer'
                ? 'border-amber-500 text-amber-400 bg-amber-500/5'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send Coins (User → User)</span>
          </button>
          
          <button
            id="tab-virtual-exchange"
            onClick={() => { setActiveTab('exchange'); playSoundFX('click'); }}
            className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'exchange'
                ? 'border-rose-500 text-rose-400 bg-rose-500/5'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Exchange (🪙 → 💎)</span>
          </button>

          <button
            id="tab-wallet-history"
            onClick={() => { setActiveTab('history'); playSoundFX('click'); }}
            className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'history'
                ? 'border-cyan-500 text-cyan-400 bg-cyan-500/5'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Withdrawals & Ledger</span>
            {withdrawalsList.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-mono font-bold">
                {withdrawalsList.length}
              </span>
            )}
          </button>

          <button
            id="tab-instant-recharge"
            onClick={() => { setActiveTab('recharge'); playSoundFX('click'); }}
            className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'recharge'
                ? 'border-yellow-500 text-yellow-400 bg-yellow-500/5'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Coin Top-Up</span>
          </button>
        </div>

        {/* Tab Body Container */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4 max-h-[55vh]">
          
          {/* Success Toast */}
          {successToast && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in shadow-lg shadow-emerald-950/50">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{successToast}</span>
            </div>
          )}

          {/* TAB 1: REAL MONEY WITHDRAWAL */}
          {activeTab === 'withdraw' && isHostWithoutAgency && (
            <div className="bg-[#1b1424] border-2 border-amber-500/50 rounded-3xl p-8 text-center space-y-4 my-6 shadow-2xl">
              <div className="w-14 h-14 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300 mx-auto text-2xl">
                🔒
              </div>
              <h3 className="text-lg font-black text-amber-300 font-['Outfit']">Withdrawal Section Locked</h3>
              <p className="text-xs text-neutral-300 max-w-md mx-auto leading-relaxed">
                You are registered as a Host on DIYO LIVE, but you have <strong>not joined an agency</strong> yet. As per platform policy, cash withdrawals are strictly hidden until you join an approved talent agency.
              </p>
              <div className="pt-2">
                <span className="inline-block px-4 py-2 rounded-xl bg-amber-500/15 text-amber-300 text-xs font-bold border border-amber-500/30">
                  Please join an agency to unlock your withdrawal section.
                </span>
              </div>
            </div>
          )}

          {activeTab === 'withdraw' && !isHostWithoutAgency && (
            <form onSubmit={handleExecuteWithdrawal} className="space-y-4">
              
              {/* Self-Gift Conversion Info Banner */}
              <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-teal-950/50 to-emerald-950/70 border border-emerald-500/30 flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center shrink-0 text-sm">
                  💎
                </div>
                <div className="space-y-0.5 text-[11px] leading-tight">
                  <p className="font-bold text-emerald-300">
                    Self-Gifting to Withdrawal Wallet is Active!
                  </p>
                  <p className="text-neutral-300 text-[10px]">
                    Whenever you send a gift to <strong>Self</strong> in any Live Stream or 20-Seat Party Lounge, 100% of the coins are credited directly to your Withdrawable Diamonds (1 TC = 1 💎).
                  </p>
                </div>
              </div>

              {/* Method Selector Strip */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-emerald-400" /> Select Withdrawal Method
                  </label>
                  <span className="text-[10px] text-neutral-400 font-mono">10,000 Diamonds = $1.00 USD (100k = $10)</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  
                  {/* 1. eSewa */}
                  <div
                    id="select-method-esewa"
                    onClick={() => { setWithdrawMethod('ESEWA'); playSoundFX('click'); }}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col items-center text-center relative ${
                      withdrawMethod === 'ESEWA'
                        ? 'bg-gradient-to-b from-emerald-950/80 to-neutral-900 border-emerald-400 shadow-lg shadow-emerald-950/60 scale-[1.02]'
                        : 'bg-neutral-900/70 hover:bg-neutral-800/80 border-neutral-800 text-neutral-300'
                    }`}
                  >
                    <span className="absolute top-1.5 right-1.5 text-[8px] font-black uppercase px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      0% Fee
                    </span>
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-sm mb-1.5">
                      📱
                    </div>
                    <h4 className="text-xs font-black text-white">eSewa</h4>
                    <p className="text-[10px] font-mono text-emerald-400 font-bold mt-0.5">NPR (Instant)</p>
                  </div>

                  {/* 2. Direct Bank Transfer */}
                  <div
                    id="select-method-bank"
                    onClick={() => { setWithdrawMethod('BANK'); playSoundFX('click'); }}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col items-center text-center relative ${
                      withdrawMethod === 'BANK'
                        ? 'bg-gradient-to-b from-blue-950/80 to-neutral-900 border-blue-400 shadow-lg shadow-blue-950/60 scale-[1.02]'
                        : 'bg-neutral-900/70 hover:bg-neutral-800/80 border-neutral-800 text-neutral-300'
                    }`}
                  >
                    <span className="absolute top-1.5 right-1.5 text-[8px] font-black uppercase px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                      Bank
                    </span>
                    <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-black text-sm mb-1.5">
                      🏦
                    </div>
                    <h4 className="text-xs font-black text-white">Bank Transfer</h4>
                    <p className="text-[10px] font-mono text-blue-400 font-bold mt-0.5">NPR / Domestic</p>
                  </div>

                  {/* 3. ePay */}
                  <div
                    id="select-method-epay"
                    onClick={() => { setWithdrawMethod('EPAY'); playSoundFX('click'); }}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col items-center text-center relative ${
                      withdrawMethod === 'EPAY'
                        ? 'bg-gradient-to-b from-purple-950/80 to-neutral-900 border-purple-400 shadow-lg shadow-purple-950/60 scale-[1.02]'
                        : 'bg-neutral-900/70 hover:bg-neutral-800/80 border-neutral-800 text-neutral-300'
                    }`}
                  >
                    <span className="absolute top-1.5 right-1.5 text-[8px] font-black uppercase px-1.5 py-0.2 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      Global
                    </span>
                    <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-black text-sm mb-1.5">
                      💳
                    </div>
                    <h4 className="text-xs font-black text-white">ePay</h4>
                    <p className="text-[10px] font-mono text-purple-400 font-bold mt-0.5">Fast Wallet</p>
                  </div>

                  {/* 4. USD Payout */}
                  <div
                    id="select-method-usd"
                    onClick={() => { setWithdrawMethod('USD'); playSoundFX('click'); }}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col items-center text-center relative ${
                      withdrawMethod === 'USD'
                        ? 'bg-gradient-to-b from-amber-950/80 to-neutral-900 border-amber-400 shadow-lg shadow-amber-950/60 scale-[1.02]'
                        : 'bg-neutral-900/70 hover:bg-neutral-800/80 border-neutral-800 text-neutral-300'
                    }`}
                  >
                    <span className="absolute top-1.5 right-1.5 text-[8px] font-black uppercase px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      USDT / PP
                    </span>
                    <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-sm mb-1.5">
                      💵
                    </div>
                    <h4 className="text-xs font-black text-white">USD Payout</h4>
                    <p className="text-[10px] font-mono text-amber-400 font-bold mt-0.5">USDT TRC20</p>
                  </div>

                </div>
              </div>

              {/* Amount Selection & Presets */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-300">
                    Diamonds to Withdraw
                  </label>
                  <span className="text-[11px] font-mono text-emerald-400 font-bold">
                    Available: {(currentDiamonds ?? 0).toLocaleString()} 💎
                  </span>
                </div>

                {/* Preset Chips */}
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {[
                    { diamonds: 5000, label: '$5 USD' },
                    { diamonds: 10000, label: '$10 USD' },
                    { diamonds: 25000, label: '$25 USD' },
                    { diamonds: 50000, label: '$50 USD' },
                    { diamonds: 100000, label: '$100 USD' },
                    { diamonds: currentDiamonds, label: 'MAX' }
                  ].map((p, idx) => {
                    const isSelected = Number(withdrawDiamonds) === p.diamonds && p.diamonds > 0;
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setWithdrawDiamonds(p.diamonds);
                          playSoundFX('click');
                        }}
                        className={`py-1.5 px-2 rounded-xl text-xs font-mono font-bold border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-500 text-neutral-950 border-emerald-400 shadow-md'
                            : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-700'
                        }`}
                      >
                        {p.label}
                      </button>
                    );
                  })}
                </div>

                {/* Custom Amount Input */}
                <div className="relative mt-2">
                  <input
                    id="input-withdraw-diamonds"
                    type="number"
                    min={5000}
                    step={1000}
                    placeholder="Enter Diamonds amount (min 5,000)"
                    value={withdrawDiamonds ?? ''}
                    onChange={(e) => setWithdrawDiamonds(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3.5 py-3 text-sm text-white font-mono placeholder-neutral-500"
                  />
                  <div className="absolute right-3.5 top-3 flex items-center gap-1.5 text-xs text-neutral-400 font-mono">
                    <Gem className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Diamonds</span>
                  </div>
                </div>
              </div>

              {/* Dynamic Method Form Fields */}
              <div className="p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                  <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    {withdrawMethod === 'ESEWA' && '📱 eSewa Wallet Details'}
                    {withdrawMethod === 'BANK' && '🏦 Direct Bank Details'}
                    {withdrawMethod === 'EPAY' && '💳 ePay Wallet Details'}
                    {withdrawMethod === 'USD' && '💵 USD / Crypto Details'}
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold">
                    {withdrawMethod === 'ESEWA' ? 'Instant Settlement' : 'Verified Channel'}
                  </span>
                </div>

                {/* Account Holder Name (Universal) */}
                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                    Account Holder Full Name (as registered)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Aarav Mehta"
                    value={accountHolderName}
                    onChange={(e) => setAccountHolderName(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                {/* Method Specific Fields */}
                {withdrawMethod === 'ESEWA' && (
                  <div>
                    <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                      eSewa ID / Registered Mobile Number (Nepal)
                    </label>
                    <input
                      id="input-esewa-id"
                      type="text"
                      placeholder="e.g. 9841029384 or 98XXXXXXXX"
                      value={esewaId}
                      onChange={(e) => setEsewaId(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                    <p className="text-[10px] text-neutral-500 mt-1">
                      Funds will be dispatched directly to your eSewa mobile balance in NPR.
                    </p>
                  </div>
                )}

                {withdrawMethod === 'BANK' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                        Bank Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Nabil Bank, NIC Asia, Global IME"
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-700 focus:border-blue-500 rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                        Bank Account Number
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. 00100175029182"
                        value={bankAccountNumber}
                        onChange={(e) => setBankAccountNumber(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-700 focus:border-blue-500 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                        Branch Name / SWIFT / IFSC Code
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. NARBNPKA / Kathmandu Main Branch"
                        value={bankBranchCode}
                        onChange={(e) => setBankBranchCode(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-700 focus:border-blue-500 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>
                  </div>
                )}

                {withdrawMethod === 'EPAY' && (
                  <div>
                    <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                      ePay Wallet ID / Registered Phone / Email
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. epay_aarav_99 or user@epay.com"
                      value={epayId}
                      onChange={(e) => setEpayId(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 focus:border-purple-500 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                )}

                {withdrawMethod === 'USD' && (
                  <div className="space-y-2.5">
                    <div className="flex items-center gap-2">
                      {[
                        { key: 'USDT_TRC20', label: 'USDT (TRC-20)' },
                        { key: 'USDT_ERC20', label: 'USDT (ERC-20)' },
                        { key: 'PAYPAL', label: 'PayPal' }
                      ].map((item) => (
                        <button
                          key={item.key}
                          type="button"
                          onClick={() => setPayoutTypeUSD(item.key as any)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            payoutTypeUSD === item.key
                              ? 'bg-amber-500 text-neutral-950 border-amber-400 font-black'
                              : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>

                    {payoutTypeUSD === 'PAYPAL' ? (
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                          PayPal Registered Email
                        </label>
                        <input
                          type="email"
                          placeholder="e.g. aarav.mehta@srlive.io"
                          value={paypalEmail}
                          onChange={(e) => setPaypalEmail(e.target.value)}
                          className="w-full bg-neutral-950 border border-neutral-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        />
                      </div>
                    ) : (
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                          USDT Wallet Address ({payoutTypeUSD.replace('_', ' ')})
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. TXn871KaB92MopQrZ21KLa90vVnmQ19p02"
                          value={usdtAddress}
                          onChange={(e) => setUsdtAddress(e.target.value)}
                          className="w-full bg-neutral-950 border border-neutral-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        />
                        <p className="text-[10px] text-neutral-500 mt-1">
                          Ensure TRC-20 address is correct. 0% gas fee on TRC-20 network.
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Conversion Breakdown Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-neutral-900 to-neutral-950 border border-emerald-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span>Gross Diamond Value:</span>
                  <span className="font-mono font-bold text-white">${grossUSD.toFixed(2)} USD</span>
                </div>
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <div className="flex items-center gap-1.5">
                    <span>Govt TDS & Platform Tax ({effectiveTaxRate}%):</span>
                    {taxDiscountPercent > 0 && (
                      <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                        VIP {userVip} {taxDiscountPercent}% Rebate
                      </span>
                    )}
                  </div>
                  <span className="font-mono text-amber-400 font-bold">-${taxUSD.toFixed(2)} USD</span>
                </div>
                {feePercent > 0 && (
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Payment Gateway Fee ({feePercent}%):</span>
                    <span className="font-mono text-emerald-400 font-bold">-${feeUSD.toFixed(2)} USD</span>
                  </div>
                )}
                <div className="pt-2 border-t border-neutral-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white uppercase tracking-wider block">
                      Net Payout to Receive:
                    </span>
                    <span className="text-[10px] text-neutral-400">
                      {withdrawMethod === 'ESEWA' || withdrawMethod === 'BANK' ? 'Converted at 1 USD = 135 NPR' : 'Direct USD Settlement'}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-black text-emerald-400 font-mono">
                      ${netUSD.toFixed(2)} USD
                    </p>
                    {targetCurrency === 'NPR' && (
                      <p className="text-xs font-bold text-white font-mono">
                        ≈ Rs. {(netLocal ?? 0).toLocaleString()} NPR
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Error Message */}
              {withdrawError && (
                <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{withdrawError}</span>
                </div>
              )}

              {/* Submit Button */}
              <button
                id="btn-confirm-withdrawal"
                type="submit"
                disabled={withdrawLoading || currentDiamonds < 5000}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-400 hover:from-emerald-400 hover:to-teal-400 disabled:opacity-50 text-neutral-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-emerald-950/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {withdrawLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-neutral-950" />
                    <span>Processing Payout Request...</span>
                  </>
                ) : (
                  <>
                    <Banknote className="w-4 h-4 text-neutral-950" />
                    <span>Withdraw ${(netUSD).toFixed(2)} USD via {withdrawMethod} Now</span>
                  </>
                )}
              </button>

              {/* Live Withdrawal Status Item (if exists) */}
              {withdrawReceipt && (
                <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-2 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                      <Receipt className="w-4 h-4" /> Withdrawal Reference Code: {withdrawReceipt.referenceCode}
                    </span>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">
                      {withdrawReceipt.status}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-300">
                    {withdrawReceipt.notes}
                  </p>
                  <div className="text-[10px] font-mono text-neutral-400 flex items-center justify-between pt-1 border-t border-emerald-900/50">
                    <span>ID: {withdrawReceipt.id}</span>
                    <span>{withdrawReceipt.submittedAt}</span>
                  </div>
                </div>
              )}

            </form>
          )}

          {/* TAB 2: USER → USER COIN TRANSFER */}
          {activeTab === 'transfer' && (
            <form onSubmit={handleExecuteTransfer} className="space-y-4">
              
              {/* Transfer Header Card */}
              <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Send className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      User → User LIVE COIN Transfer
                    </span>
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                    isTransferEnabled 
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' 
                      : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                  }`}>
                    {isTransferEnabled ? 'Transfers Enabled' : 'Transfers Disabled by Owner'}
                  </span>
                </div>
                <p className="text-xs text-neutral-400">
                  Send virtual LIVE COINS instantly to any registered user ID. Balance deductions and recipient credits occur atomically server-side.
                </p>
              </div>

              {/* Recipient Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-neutral-300">
                  Select Recipient or Enter User ID
                </label>
                
                {/* Quick select chips */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {candidateRecipients.map((user) => {
                    const isSelected = targetUserId === user.id;
                    return (
                      <button
                        key={user.id}
                        type="button"
                        onClick={() => {
                          setTargetUserId(user.id);
                          playSoundFX('click');
                        }}
                        className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-500 text-white shadow-md shadow-amber-950/40'
                            : 'bg-neutral-900/60 hover:bg-neutral-800/80 border-neutral-800 text-neutral-300'
                        }`}
                      >
                        <div className="w-7 h-7 rounded-full bg-amber-500/30 flex items-center justify-center font-bold text-[10px] text-amber-300 flex-shrink-0">
                          {user.name.charAt(0)}
                        </div>
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold truncate">{user.name}</p>
                          <p className="text-[10px] font-mono text-neutral-400 truncate">{user.id}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Custom User ID input */}
                <div className="relative mt-2">
                  <input
                    id="transfer-target-user-id"
                    type="text"
                    placeholder="Enter Recipient User ID (e.g. USR-8002, 8002, or username)"
                    value={targetUserId ?? ''}
                    onChange={(e) => setTargetUserId(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-amber-500 rounded-xl px-3 py-2.5 text-xs text-white placeholder-neutral-500 font-mono"
                  />
                  {selectedRecipientObj && (
                    <span className="absolute right-3 top-2.5 text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Verified: {selectedRecipientObj.name}
                    </span>
                  )}
                </div>
              </div>

              {/* Transfer Amount */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-300">
                    Amount to Send (LIVE COINS)
                  </label>
                  <span className="text-[10px] font-mono text-neutral-400">
                    Available: {(currentCoins ?? 0).toLocaleString()} 🪙
                  </span>
                </div>

                {/* Quick amount presets */}
                <div className="grid grid-cols-4 gap-2">
                  {[1000, 5000, 10000, 50000].map((amt) => {
                    const isSelected = Number(transferAmount) === amt;
                    return (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => {
                          setTransferAmount(amt);
                          playSoundFX('click');
                        }}
                        className={`py-1.5 px-2 rounded-xl text-xs font-mono font-bold border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500 text-neutral-950 border-amber-400 shadow-md'
                            : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-700'
                        }`}
                      >
                        {(amt ?? 0).toLocaleString()} 🪙
                      </button>
                    );
                  })}
                </div>

                <div className="relative mt-2">
                  <input
                    id="transfer-coin-amount"
                    type="number"
                    min={minTransfer}
                    max={maxTransfer}
                    placeholder={`Min ${(minTransfer ?? 0).toLocaleString()} - Max ${(maxTransfer ?? 0).toLocaleString()}`}
                    value={transferAmount ?? ''}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-amber-500 rounded-xl px-3 py-2.5 text-xs text-white font-mono placeholder-neutral-500"
                  />
                  <div className="absolute right-3 top-2.5 text-xs text-neutral-400 font-mono">
                    🪙 COINS
                  </div>
                </div>
              </div>

              {/* Optional Transfer Notes */}
              <div className="space-y-1">
                <label className="block text-[11px] font-bold text-neutral-400">
                  Transfer Note (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Gift for Live Room DJ, PK Battle Support, etc."
                  value={transferNotes}
                  onChange={(e) => setTransferNotes(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500"
                />
              </div>

              {/* Error Box */}
              {transferError && (
                <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{transferError}</span>
                </div>
              )}

              {/* Action Button */}
              <button
                id="execute-transfer-btn"
                type="submit"
                disabled={transferLoading || !isTransferEnabled}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-400 hover:from-amber-400 hover:to-yellow-300 disabled:opacity-50 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-950/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {transferLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-neutral-950" />
                    <span>Processing Transfer...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 fill-neutral-950" />
                    <span>Send {Number(transferAmount || 0).toLocaleString()} Coins Now</span>
                  </>
                )}
              </button>

            </form>
          )}

          {/* TAB 3: VIRTUAL EXCHANGE (🪙 → 💎) */}
          {activeTab === 'exchange' && (
            <form onSubmit={handleExecuteExchange} className="space-y-4">
              
              {/* Header Box */}
              <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-rose-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      Coins ➔ Diamonds Exchange
                    </span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-300 border border-rose-500/30">
                    Rate 1 : {rate}
                  </span>
                </div>
                <p className="text-xs text-neutral-400">
                  Convert your LIVE COINS into Virtual Diamonds. Diamonds can then be withdrawn via eSewa, Bank Transfer, ePay, or USD!
                </p>
              </div>

              {/* Conversion Calculator */}
              <div className="p-4 rounded-2xl bg-neutral-900/90 border border-rose-500/30 space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-300 flex items-center justify-between">
                    <span>Amount of Coins to Convert:</span>
                    <span className="text-[10px] font-mono text-neutral-400">
                      Balance: {(currentCoins ?? 0).toLocaleString()} 🪙
                    </span>
                  </label>
                  
                  <div className="relative">
                    <input
                      id="exchange-coins-input"
                      type="number"
                      min={100}
                      value={exchangeAmount ?? ''}
                      onChange={(e) => setExchangeAmount(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 focus:border-rose-500 rounded-xl px-3 py-2.5 text-xs text-white font-mono"
                    />
                    <div className="absolute right-3 top-2.5 text-xs text-amber-400 font-mono font-bold">
                      🪙 COINS
                    </div>
                  </div>
                </div>

                {/* Arrow */}
                <div className="flex items-center justify-center py-1">
                  <div className="w-7 h-7 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center">
                    <ArrowDownLeft className="w-4 h-4 rotate-45" />
                  </div>
                </div>

                {/* Diamonds Output */}
                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                  <span className="text-xs text-neutral-400 font-medium">You Will Receive:</span>
                  <div className="text-right">
                    <span className="text-base font-black text-rose-400 font-mono">
                      +{Math.floor(Number(exchangeAmount || 0) * rate).toLocaleString()} 💎
                    </span>
                    <span className="text-[10px] text-neutral-400 font-mono block">
                      ≈ ${(Math.floor(Number(exchangeAmount || 0) * rate) / 1000).toFixed(2)} USD
                    </span>
                  </div>
                </div>
              </div>

              {/* Error Box */}
              {exchangeError && (
                <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{exchangeError}</span>
                </div>
              )}

              {/* Submit Exchange */}
              <button
                id="execute-exchange-btn"
                type="submit"
                disabled={exchangeLoading || !isExchangeEnabled}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 hover:from-rose-500 hover:to-amber-400 disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-rose-950/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {exchangeLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>Exchanging...</span>
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4" />
                    <span>Convert {Number(exchangeAmount || 0).toLocaleString()} Coins to Diamonds</span>
                  </>
                )}
              </button>

            </form>
          )}

          {/* TAB 4: WITHDRAWALS & LEDGER */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              
              {/* Active Withdrawals History */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Banknote className="w-3.5 h-3.5 text-emerald-400" /> Real Money Withdrawal Requests
                  </span>
                  <span className="text-[10px] font-mono text-neutral-400">{withdrawalsList.length} Requests</span>
                </div>

                {withdrawalsList && withdrawalsList.length > 0 ? (
                  <div className="space-y-2.5">
                    {withdrawalsList.map((wd) => (
                      <div key={wd.id} className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2 hover:border-emerald-500/40 transition-colors">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-white flex items-center gap-1.5">
                              {wd.method === 'ESEWA' && '📱 eSewa'}
                              {wd.method === 'BANK' && '🏦 Direct Bank'}
                              {wd.method === 'EPAY' && '💳 ePay'}
                              {wd.method === 'USD' && '💵 USD USDT'}
                            </span>
                            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-300">
                              {wd.referenceCode}
                            </span>
                          </div>

                          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                            wd.status === 'COMPLETED'
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                              : wd.status === 'PROCESSING' || wd.status === 'PENDING'
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                              : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                          }`}>
                            {wd.status}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-xs">
                          <div className="text-neutral-400">
                            <p className="text-[11px] text-neutral-300 font-medium">{wd.methodLabel}</p>
                            <p className="text-[10px] text-neutral-500 font-mono mt-0.5">{wd.submittedAt}</p>
                          </div>

                          <div className="text-right font-mono">
                            <p className="font-black text-emerald-400 text-sm">
                              ${(wd.netPayoutUSD ?? 0).toFixed(2)} USD
                            </p>
                            {wd.currency === 'NPR' && (
                              <p className="text-[10px] text-neutral-300">
                                Rs. {(wd.netPayoutLocal ?? 0).toLocaleString()} NPR
                              </p>
                            )}
                            <p className="text-[10px] text-neutral-400 font-mono">
                              -{(wd.diamondAmount ?? 0).toLocaleString()} 💎
                            </p>
                          </div>
                        </div>

                        {/* Cancel Action if still processing */}
                        {(wd.status === 'PROCESSING' || wd.status === 'PENDING') && (
                          <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between">
                            <span className="text-[10px] text-amber-400 flex items-center gap-1">
                              <Clock className="w-3 h-3" /> In Settlement Queue
                            </span>
                            <button
                              type="button"
                              onClick={() => handleCancelWithdrawal(wd.id)}
                              disabled={cancelLoadingId === wd.id}
                              className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-rose-950/60 text-neutral-300 hover:text-rose-400 border border-neutral-700 text-[10px] font-bold transition-all cursor-pointer"
                            >
                              {cancelLoadingId === wd.id ? 'Cancelling...' : 'Cancel & Refund Diamonds'}
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-neutral-500 text-xs rounded-2xl bg-neutral-900/40 border border-neutral-800">
                    No withdrawal requests submitted yet.
                  </div>
                )}
              </div>

              {/* General Wallet Ledger Filter Header */}
              <div className="flex items-center justify-between pt-3 border-t border-neutral-800">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Wallet Transactions Ledger
                </span>
                
                {/* Filter Chips */}
                <div className="flex items-center gap-1 text-[10px] font-mono bg-neutral-900 p-1 rounded-xl border border-neutral-800">
                  {[
                    { key: 'ALL', label: 'All' },
                    { key: 'WITHDRAW', label: 'Withdraw' },
                    { key: 'RECEIVED', label: 'Received' },
                    { key: 'SENT', label: 'Sent' },
                    { key: 'EXCHANGE', label: 'Exchange' },
                    { key: 'RECHARGE', label: 'Top-Up' }
                  ].map((f) => (
                    <button
                      key={f.key}
                      onClick={() => { setHistoryFilter(f.key as any); playSoundFX('click'); }}
                      className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                        historyFilter === f.key
                          ? 'bg-neutral-800 text-white shadow-sm'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* History List */}
              <div className="space-y-2.5">
                {filteredTxs && filteredTxs.length > 0 ? (
                  filteredTxs.map((tx) => (
                    <div key={tx.id} className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between text-xs hover:border-neutral-700 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${
                          tx.type === 'Payout'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : tx.type === 'VIRTUAL_EXCHANGE' 
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            : tx.amountCoins > 0 
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}>
                          {tx.type === 'Payout' ? (
                            <Banknote className="w-4 h-4" />
                          ) : tx.type === 'VIRTUAL_EXCHANGE' ? (
                            <RefreshCw className="w-4 h-4" />
                          ) : tx.amountCoins > 0 ? (
                            <ArrowDownLeft className="w-4 h-4" />
                          ) : (
                            <ArrowUpRight className="w-4 h-4" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-bold text-white">{tx.notes || tx.type}</p>
                          </div>
                          <p className="text-[10px] text-neutral-400 font-mono mt-0.5">
                            {tx.id} • {tx.timestamp}
                          </p>
                        </div>
                      </div>

                      <div className="text-right font-mono flex-shrink-0">
                        {tx.amountCoins != null && tx.amountCoins !== 0 && (
                          <p className={`font-black ${tx.amountCoins > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {tx.amountCoins > 0 ? `+${(tx.amountCoins ?? 0).toLocaleString()}` : `${(tx.amountCoins ?? 0).toLocaleString()}`} 🪙
                          </p>
                        )}
                        {tx.amountDiamonds != null && tx.amountDiamonds !== 0 && (
                          <p className={`text-[11px] font-bold ${tx.amountDiamonds > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {tx.amountDiamonds > 0 ? `+${(tx.amountDiamonds ?? 0).toLocaleString()}` : `${(tx.amountDiamonds ?? 0).toLocaleString()}`} 💎
                          </p>
                        )}
                        {tx.fiatAmountUSD != null && (
                          <p className="text-[10px] font-mono text-emerald-400 font-bold">
                            ${Number(tx.fiatAmountUSD || 0).toFixed(2)} USD
                          </p>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-10 text-neutral-500 text-xs rounded-2xl bg-neutral-900/40 border border-neutral-800">
                    No transactions matching this filter.
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB 5: FREE COIN TOP-UP */}
          {activeTab === 'recharge' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
                  Select Sandbox Top-Up Package
                </span>
                <span className="text-[11px] text-emerald-400 font-mono font-bold">
                  $0.00 Cost (Free Injections)
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {rechargePacks.map((pack) => {
                  const isSelected = selectedPack === pack.coins;
                  return (
                    <div
                      key={pack.coins}
                      onClick={() => {
                        setSelectedPack(pack.coins);
                        playSoundFX('click');
                      }}
                      className={`relative p-4 rounded-2xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-gradient-to-br from-amber-950/60 to-neutral-900 border-amber-500 shadow-lg shadow-amber-950/40 scale-[1.01]'
                          : 'bg-neutral-900/80 hover:bg-neutral-800/80 border-neutral-800'
                      }`}
                    >
                      {pack.tag && (
                        <span className={`absolute top-2.5 right-2.5 text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                          pack.isHot 
                            ? 'bg-rose-600 text-white' 
                            : pack.isVip
                            ? 'bg-amber-500 text-neutral-950 font-bold'
                            : 'bg-neutral-800 text-neutral-300'
                        }`}>
                          {pack.tag}
                        </span>
                      )}

                      <div className="flex items-center gap-2">
                        <span className="text-xl font-black text-white font-mono">
                          {(pack.coins ?? 0).toLocaleString()}
                        </span>
                        <span className="text-amber-400">🪙</span>
                      </div>

                      {pack.bonus > 0 && (
                        <p className="text-[11px] text-emerald-400 font-semibold mt-1">
                          +{(pack.bonus ?? 0).toLocaleString()} Free Bonus Coins
                        </p>
                      )}

                      <div className="mt-3 pt-2 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                        <span className="text-neutral-400">Top-Up Cost:</span>
                        <span className="font-mono font-bold text-emerald-400">$0.00 (Sandbox Instant)</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Action Button */}
              <button
                id="execute-free-recharge-btn"
                onClick={() => handleExecuteRecharge(selectedPack)}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-neutral-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-950/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Zap className="w-4 h-4 fill-neutral-950" />
                <span>Inject +{(selectedPack ?? 0).toLocaleString()} LIVE COINS Now</span>
              </button>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
