import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { VipBadge } from '../badges/VipBadge.js';
import { Sparkles, Crown, Zap, Flame } from 'lucide-react';
import { VipEntranceEffect } from '../../types/vipTypes.js';

export interface VipEntranceEvent {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  vipLevel: number;
  effect: VipEntranceEffect;
  timestamp: number;
}

interface VipEntranceBannerProps {
  event: VipEntranceEvent | null;
  onComplete?: () => void;
}

export const VipEntranceBanner: React.FC<VipEntranceBannerProps> = ({ event, onComplete }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (event) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
        if (onComplete) {
          setTimeout(onComplete, 500);
        }
      }, 4500);
      return () => clearTimeout(timer);
    } else {
      setVisible(false);
    }
  }, [event, onComplete]);

  if (!event || !visible) return null;

  const { vipLevel, userName, userAvatar, effect } = event;

  return (
    <AnimatePresence>
      <div className="fixed top-20 left-0 right-0 z-50 pointer-events-none flex justify-center px-4 overflow-hidden">
        <motion.div
          initial={{ x: '-100%', opacity: 0, scale: 0.8 }}
          animate={{ x: '0%', opacity: 1, scale: 1 }}
          exit={{ x: '100%', opacity: 0, scale: 0.9 }}
          transition={{ type: 'spring', damping: 20, stiffness: 120 }}
          className="relative max-w-lg w-full"
        >
          {/* Background Glow Aura */}
          <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-amber-500 via-pink-500 to-indigo-500 opacity-70 blur-md animate-pulse" />

          {/* Main Card Container */}
          <div className={`relative flex items-center gap-3.5 p-3.5 rounded-2xl bg-gradient-to-r ${effect.bannerGradient || 'from-neutral-900 via-amber-950 to-neutral-900'} border-2 border-amber-300/80 shadow-[0_10px_30px_rgba(0,0,0,0.8)] backdrop-blur-xl overflow-hidden`}>
            
            {/* Shimmer Light Sweeper */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full animate-[shimmer_1.8s_infinite] pointer-events-none" />

            {/* Left Entrance Vehicle / Mascot with Bounce */}
            <motion.div 
              animate={{ 
                x: [0, 8, 0],
                rotate: [0, -3, 3, 0],
                scale: [1, 1.15, 1] 
              }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="relative flex-shrink-0 w-14 h-14 rounded-2xl bg-black/40 border border-white/20 flex items-center justify-center text-3xl shadow-inner"
            >
              <span>{effect.emoji}</span>
              <div className="absolute -bottom-1 -right-1">
                <VipBadge level={vipLevel} size="xs" showLabel={false} />
              </div>
            </motion.div>

            {/* Middle: User Info & Entrance Message */}
            <div className="flex-1 min-w-0 pr-2">
              <div className="flex items-center gap-2 mb-0.5">
                <img 
                  src={userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'} 
                  alt={userName} 
                  className="w-5 h-5 rounded-full border border-amber-300 object-cover"
                />
                <span className="font-black text-sm text-white tracking-wide truncate drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                  {userName}
                </span>
                <VipBadge level={vipLevel} size="xs" glow />
              </div>

              <div className="flex items-center gap-1.5 text-xs text-amber-200 font-bold truncate drop-shadow">
                <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-spin flex-shrink-0" style={{ animationDuration: '3s' }} />
                <span className="truncate">
                  Cruising in <span className="text-white font-extrabold underline decoration-amber-400">{effect.name}</span>
                </span>
              </div>
            </div>

            {/* Right: Nobility Seal */}
            <div className="flex-shrink-0 flex flex-col items-center justify-center pl-2 border-l border-white/20 text-amber-300">
              <Crown className="w-5 h-5 fill-amber-400 text-yellow-300 animate-bounce" style={{ animationDuration: '2s' }} />
              <span className="text-[9px] font-black uppercase tracking-wider text-amber-200">
                VIP {vipLevel}
              </span>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
