import React, { useState } from 'react';
import { 
  Coins, 
  Zap, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Send, 
  History, 
  CreditCard, 
  Gift, 
  ShieldCheck, 
  Sparkles, 
  Search, 
  RefreshCw, 
  CheckCircle, 
  ChevronRight,
  Filter,
  Flame,
  Award,
  Wallet as WalletIcon,
  Download,
  CheckCircle2,
  Clock,
  Building2,
  QrCode,
  X,
  AlertCircle,
  ExternalLink,
  DollarSign,
  Smartphone,
  Globe,
  ArrowLeft
} from 'lucide-react';
import { UserAccount, WalletTransaction, PlatformWalletSettings, WithdrawalItem, PayoutMethod } from '../../types/ownerTypes';
import { SUPPORTED_COUNTRIES, getCountryFlag } from '../../data/countryData';
import { playSoundFX } from '../../utils/audioSynth';
import confetti from 'canvas-confetti';

interface WalletScreenProps {
  currentUser: UserAccount;
  transactions: WalletTransaction[];
  onUpdateUserBalance?: (newCoins: number, newDiamonds: number) => void;
  onUpdateBalance?: (newCoins: number, newDiamonds: number) => void;
  onTransferCoins: (recipientId: string, amount: number, note?: string) => Promise<{ success: boolean; error?: string; message?: string } | boolean> | boolean;
  onExchangeCoins?: (amount: number) => Promise<{ success: boolean; error?: string; message?: string } | boolean> | void;
  onWithdrawDiamonds?: (withdrawalData: {
    diamonds: number;
    payoutMethod: string;
    payoutMethodName: string;
    payoutDetails: string;
    accountHolderName: string;
    netUSD: number;
    localAmount: number;
    localCurrency: string;
  }) => Promise<{ success: boolean; error?: string; withdrawal?: WithdrawalItem } | boolean> | boolean;
  walletSettings?: PlatformWalletSettings;
  platformUsers?: UserAccount[];
  onBack?: () => void;
}

const RECHARGE_PACKAGES = [
  { id: 'pkg-1', coins: 10000, bolts: 1000, priceUSD: '0.99', popular: false, badge: 'Starter' },
  { id: 'pkg-2', coins: 50000, bolts: 6000, priceUSD: '4.99', popular: false, badge: '+20% Extra' },
  { id: 'pkg-3', coins: 120000, bolts: 15000, priceUSD: '9.99', popular: true, badge: '🔥 Most Popular' },
  { id: 'pkg-4', coins: 300000, bolts: 45000, priceUSD: '24.99', popular: false, badge: '+50% Extra' },
  { id: 'pkg-5', coins: 650000, bolts: 100000, priceUSD: '49.99', popular: false, badge: '⚡ Super Value' },
  { id: 'pkg-6', coins: 1500000, bolts: 250000, priceUSD: '99.99', popular: false, badge: '👑 VIP Royal' }
];

export const WalletScreen: React.FC<WalletScreenProps> = ({
  currentUser,
  transactions,
  onUpdateUserBalance,
  onUpdateBalance,
  onTransferCoins,
  onExchangeCoins,
  onWithdrawDiamonds,
  walletSettings,
  platformUsers = [],
  onBack
}) => {
  const updateBalance = onUpdateUserBalance || onUpdateBalance || (() => {});
  const isHostWithoutAgency = (currentUser.role === 'HOST' || (currentUser as any).hostTag) && (!currentUser.agencyId || currentUser.agencyId.trim() === '');
  const [activeSubTab, setActiveSubTab] = useState<'withdraw' | 'earnings' | 'recharge' | 'transfer' | 'exchange' | 'history'>(isHostWithoutAgency ? 'earnings' : 'withdraw');
  
  // WITHDRAWAL REAL MONEY CASHOUT STATE
  const [withdrawCountry, setWithdrawCountry] = useState<'IN' | 'NP' | 'BD' | 'PK' | 'PH' | 'GLOBAL'>('IN');
  const [withdrawMethod, setWithdrawMethod] = useState<string>('UPI');
  const [withdrawDiamondsAmount, setWithdrawDiamondsAmount] = useState<string>('10000');
  const [accountHolderName, setAccountHolderName] = useState<string>(currentUser.name || 'Aarav Mehta');
  const [accountNumberOrId, setAccountNumberOrId] = useState<string>('aarav.mehta@oksbi');
  const [bankName, setBankName] = useState<string>('State Bank of India');
  const [bankIfscSwift, setBankIfscSwift] = useState<string>('SBIN0001842');
  const [withdrawLoading, setWithdrawLoading] = useState<boolean>(false);
  const [withdrawError, setWithdrawError] = useState<string | null>(null);
  const [withdrawReceipt, setWithdrawReceipt] = useState<WithdrawalItem | null>(null);
  const [withdrawalStatusFilter, setWithdrawalStatusFilter] = useState<'ALL' | 'Pending' | 'Approved' | 'Rejected' | 'Completed'>('ALL');
  const [withdrawalsList, setWithdrawalsList] = useState<WithdrawalItem[]>([
    {
      id: 'WD-IN-98124',
      userId: currentUser.id,
      userName: currentUser.name,
      amountDiamonds: 25000,
      payoutAmountUSD: 25.0,
      currency: 'INR',
      targetCurrency: 'INR',
      method: 'UPI' as any,
      payoutMethod: 'UPI' as any,
      status: 'Approved',
      recipientDetails: 'aarav.mehta@okaxis (Aarav Mehta)',
      accountDetails: 'aarav.mehta@okaxis (Aarav Mehta)',
      requestedAt: '2 hours ago',
      processedAt: '1 hour ago',
      timestamp: '2 hours ago',
      transactionRef: 'UPI-RR-889102941',
      referenceNumber: 'UPI-RR-889102941'
    },
    {
      id: 'WD-IN-98119',
      userId: currentUser.id,
      userName: currentUser.name,
      amountDiamonds: 50000,
      payoutAmountUSD: 50.0,
      currency: 'INR',
      targetCurrency: 'INR',
      method: 'BANK_TRANSFER' as any,
      payoutMethod: 'BANK_TRANSFER' as any,
      status: 'Completed',
      recipientDetails: 'State Bank of India (SBIN0001842)',
      accountDetails: 'State Bank of India (SBIN0001842)',
      requestedAt: 'Yesterday',
      processedAt: 'Yesterday',
      timestamp: 'Yesterday',
      transactionRef: 'NEFT-8890214812',
      referenceNumber: 'NEFT-8890214812'
    },
    {
      id: 'WD-IN-98110',
      userId: currentUser.id,
      userName: currentUser.name,
      amountDiamonds: 10000,
      payoutAmountUSD: 10.0,
      currency: 'INR',
      targetCurrency: 'INR',
      method: 'UPI' as any,
      payoutMethod: 'UPI' as any,
      status: 'Pending',
      recipientDetails: 'aarav.mehta@paytm',
      accountDetails: 'aarav.mehta@paytm',
      requestedAt: '10 mins ago',
      timestamp: '10 mins ago',
      transactionRef: 'UPI-PEND-491024',
      referenceNumber: 'UPI-PEND-491024'
    }
  ]);

  // Host Gift Earnings List
  const [giftEarningsList, setGiftEarningsList] = useState<Array<{
    id: string;
    giftName: string;
    giftIcon: string;
    senderName: string;
    senderId: string;
    quantity: number;
    totalCostCoins: number;
    hostEarningCoins: number;
    hostEarningDiamonds: number;
    commissionRate: number;
    timestamp: string;
    status: 'Completed';
  }>>([
    {
      id: 'GE-9081',
      giftName: 'Super Rocket',
      giftIcon: '🚀',
      senderName: 'Vikram Rajput',
      senderId: 'USR-8002',
      quantity: 2,
      totalCostCoins: 100000,
      hostEarningCoins: 70000,
      hostEarningDiamonds: 70000,
      commissionRate: 70,
      timestamp: '5 mins ago',
      status: 'Completed'
    },
    {
      id: 'GE-9080',
      giftName: 'Mega Jackpot Wheel',
      giftIcon: '🎰',
      senderName: 'Pooja Verma',
      senderId: 'USR-8003',
      quantity: 1,
      totalCostCoins: 25000,
      hostEarningCoins: 17500,
      hostEarningDiamonds: 17500,
      commissionRate: 70,
      timestamp: '15 mins ago',
      status: 'Completed'
    },
    {
      id: 'GE-9079',
      giftName: 'Diamond Crown',
      giftIcon: '👑',
      senderName: 'Kabir Khan',
      senderId: 'USR-8004',
      quantity: 5,
      totalCostCoins: 50000,
      hostEarningCoins: 35000,
      hostEarningDiamonds: 35000,
      commissionRate: 70,
      timestamp: '32 mins ago',
      status: 'Completed'
    },
    {
      id: 'GE-9078',
      giftName: 'Lucky Rose',
      giftIcon: '🌹',
      senderName: 'Ananya Sharma',
      senderId: 'USR-8005',
      quantity: 10,
      totalCostCoins: 10000,
      hostEarningCoins: 7000,
      hostEarningDiamonds: 7000,
      commissionRate: 70,
      timestamp: '1 hour ago',
      status: 'Completed'
    }
  ]);

  const [giftEarningsSearch, setGiftEarningsSearch] = useState('');

  // Transfer Form State
  const [transferRecipientId, setTransferRecipientId] = useState('');
  const [transferAmount, setTransferAmount] = useState('10000');
  const [transferNote, setTransferNote] = useState('Gift coins for live stream');
  const [transferSuccessMsg, setTransferSuccessMsg] = useState<string | null>(null);
  const [transferErrorMsg, setTransferErrorMsg] = useState<string | null>(null);

  // Exchange Form State
  const [exchangeCoinsAmount, setExchangeCoinsAmount] = useState('50000');
  const [exchangeSuccessMsg, setExchangeSuccessMsg] = useState<string | null>(null);

  // History Filter
  const [historyFilter, setHistoryFilter] = useState<'ALL' | 'WITHDRAW' | 'RECHARGE' | 'GIFT' | 'TRANSFER' | 'GAME'>('ALL');

  // WITHDRAWAL CALCULATION RATES
  const diamondCount = Math.max(0, parseInt(withdrawDiamondsAmount || '0', 10));
  const grossUSD = Number((diamondCount / 10000).toFixed(2)); // 10,000 Diamonds = $1.00 USD (100k = $10)
  
  // Real-time conversion rates
  const rates = {
    IN: { rate: 88.0, currency: 'INR', symbol: '₹', name: 'Indian Rupee' },
    NP: { rate: 135.0, currency: 'NPR', symbol: 'रू', name: 'Nepalese Rupee' },
    BD: { rate: 115.0, currency: 'BDT', symbol: '৳', name: 'Bangladeshi Taka' },
    PK: { rate: 280.0, currency: 'PKR', symbol: 'Rs', name: 'Pakistani Rupee' },
    PH: { rate: 58.0, currency: 'PHP', symbol: '₱', name: 'Philippine Peso' },
    GLOBAL: { rate: 1.0, currency: 'USD', symbol: '$', name: 'US Dollar / USDT' }
  };

  const currentCountryConfig = rates[withdrawCountry] || rates.IN;
  const netLocalAmount = Number((grossUSD * currentCountryConfig.rate).toFixed(2));

  // Quick select preset diamonds
  const presetDiamondAmounts = [5000, 10000, 25000, 50000, 100000, 500000];

  // Submit Diamond Withdrawal Handler
  const handleExecuteDiamondWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError(null);

    if (diamondCount < 1000) {
      setWithdrawError('Minimum withdrawal is 1,000 Diamonds ($1.00 USD).');
      playSoundFX('alert');
      return;
    }

    if (diamondCount > currentUser.diamondBalance) {
      setWithdrawError(`Insufficient Diamond Balance! You have ${currentUser.diamondBalance.toLocaleString()} 💎 available.`);
      playSoundFX('alert');
      return;
    }

    if (!accountHolderName.trim()) {
      setWithdrawError('Please enter Account Holder / Beneficiary Name.');
      return;
    }

    if (!accountNumberOrId.trim()) {
      setWithdrawError('Please enter valid Account / Wallet ID / Number.');
      return;
    }

    setWithdrawLoading(true);

    const payoutDetailsString = `${withdrawMethod}: ${accountNumberOrId.trim()} (${accountHolderName.trim()}) ${
      withdrawMethod.includes('BANK') ? `| Bank: ${bankName} | IFSC/Branch: ${bankIfscSwift}` : ''
    }`;

    try {
      // 1. Try backend API
      const res = await fetch('/api/wallet/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          userName: currentUser.name,
          amountDiamonds: diamondCount,
          payoutAmountUSD: grossUSD,
          currency: currentCountryConfig.currency,
          targetCurrency: currentCountryConfig.currency,
          payoutMethod: withdrawMethod,
          accountDetails: payoutDetailsString,
          country: withdrawCountry
        })
      });
      const data = await res.json();
      if (data.success && data.withdrawal) {
        setWithdrawReceipt(data.withdrawal);
        setWithdrawalsList(prev => [data.withdrawal, ...prev]);
        if (data.user?.diamondBalance !== undefined) {
          updateBalance(currentUser.coinBalance, data.user.diamondBalance);
        } else {
          updateBalance(currentUser.coinBalance, currentUser.diamondBalance - diamondCount);
        }
        playSoundFX('win');
        confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
        setWithdrawLoading(false);
        return;
      }
    } catch (e) {
      // Local seamless fallback
    }

    // Client fallback simulation
    const newTxId = `WD-${withdrawCountry}-${Math.floor(100000 + Math.random() * 900000)}`;
    const newWithdrawal: WithdrawalItem = {
      id: newTxId,
      userId: currentUser.id,
      userName: currentUser.name,
      amountDiamonds: diamondCount,
      payoutAmountUSD: grossUSD,
      currency: currentCountryConfig.currency,
      targetCurrency: currentCountryConfig.currency,
      method: withdrawMethod as any,
      payoutMethod: withdrawMethod as any,
      status: 'Approved',
      recipientDetails: payoutDetailsString,
      accountDetails: payoutDetailsString,
      requestedAt: 'Just now',
      processedAt: 'Just now',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' UTC',
      transactionRef: `SR-PAY-${Date.now()}`,
      referenceNumber: `SR-PAY-${Date.now()}`
    };

    updateBalance(currentUser.coinBalance, currentUser.diamondBalance - diamondCount);
    setWithdrawReceipt(newWithdrawal);
    setWithdrawalsList(prev => [newWithdrawal, ...prev]);
    setWithdrawLoading(false);
    playSoundFX('win');
    confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
  };

  // Recharge Handler (Simulated Sandbox / Test Economy)
  const handleRechargePackage = (pkg: typeof RECHARGE_PACKAGES[0]) => {
    playSoundFX('superchat');
    const newCoins = currentUser.coinBalance + pkg.coins;
    const newDiamonds = currentUser.diamondBalance;
    updateBalance(newCoins, newDiamonds);
    alert(`🎉 Successfully added +${pkg.coins.toLocaleString()} Virtual Coins and +${pkg.bolts.toLocaleString()} ⚡ Energy to your DIYO LIVE Wallet! (Test Sandbox Simulation)`);
  };

  // Transfer Handler
  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setTransferSuccessMsg(null);
    setTransferErrorMsg(null);

    const amount = parseInt(transferAmount, 10);
    if (isNaN(amount) || amount <= 0) {
      setTransferErrorMsg('Please enter a valid coin transfer amount');
      return;
    }

    if (amount > currentUser.coinBalance) {
      setTransferErrorMsg(`Insufficient coin balance. You only have ${currentUser.coinBalance.toLocaleString()} coins.`);
      return;
    }

    try {
      const res = onTransferCoins(transferRecipientId.trim(), amount, transferNote);
      let isSuccess = false;
      let errMsg = 'Recipient ID not found or transfer limit exceeded.';

      if (res && typeof res === 'object' && 'then' in res) {
        const asyncRes = await res;
        if (typeof asyncRes === 'boolean') {
          isSuccess = asyncRes;
        } else if (asyncRes && typeof asyncRes === 'object') {
          isSuccess = !!asyncRes.success;
          if (asyncRes.error) errMsg = asyncRes.error;
        }
      } else {
        isSuccess = !!res;
      }

      if (isSuccess) {
        playSoundFX('reward');
        setTransferSuccessMsg(`Successfully transferred ${amount.toLocaleString()} coins to ${transferRecipientId}!`);
        setTransferAmount('10000');
        setTimeout(() => setTransferSuccessMsg(null), 4000);
      } else {
        setTransferErrorMsg(errMsg);
      }
    } catch (err: any) {
      setTransferErrorMsg(err?.message || 'Transfer could not be completed');
    }
  };

  // Exchange Coins to Diamonds / Energy
  const handleExchange = async () => {
    const coins = parseInt(exchangeCoinsAmount, 10);
    if (isNaN(coins) || coins <= 0) return;
    if (coins > currentUser.coinBalance) {
      alert('Insufficient coin balance to convert.');
      return;
    }

    if (onExchangeCoins) {
      try {
        await onExchangeCoins(coins);
        playSoundFX('win');
        setExchangeSuccessMsg(`Exchanged ${coins.toLocaleString()} Coins for Diamonds!`);
        setTimeout(() => setExchangeSuccessMsg(null), 3000);
        return;
      } catch (_) {}
    }

    const diamondsToAdd = Math.floor(coins / 10);
    updateBalance(currentUser.coinBalance - coins, currentUser.diamondBalance + diamondsToAdd);
    playSoundFX('win');
    setExchangeSuccessMsg(`Exchanged ${coins.toLocaleString()} Coins for +${diamondsToAdd.toLocaleString()} Diamonds 💎`);
    setTimeout(() => setExchangeSuccessMsg(null), 3000);
  };

  const filteredTxs = (transactions || []).filter(t => {
    if (!t) return false;
    const type = (t.type || '').toLowerCase();
    if (historyFilter === 'ALL') return true;
    if (historyFilter === 'WITHDRAW') return type.includes('withdraw');
    if (historyFilter === 'RECHARGE') return type.includes('deposit') || type.includes('recharge');
    if (historyFilter === 'GIFT') return type.includes('gift');
    if (historyFilter === 'TRANSFER') return type.includes('transfer');
    if (historyFilter === 'GAME') return type.includes('game') || type.includes('bet');
    return true;
  });

  return (
    <div className="space-y-6 pb-nav-safe animate-in fade-in">
      
      {/* Wallet Master Header Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-neutral-900 via-neutral-900/90 to-neutral-950 border border-amber-500/30 p-6 shadow-2xl shadow-amber-950/20">
        
        {/* Decorative background aura */}
        <div className="absolute -top-16 -right-16 w-64 h-64 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          
          {/* User ID & Balances */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 p-0.5 shadow-lg shadow-amber-500/30">
                <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center">
                  <WalletIcon className="w-6 h-6 text-amber-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="font-['Outfit'] text-xl font-black text-white">DIYO LIVE Wallet</h1>
                  <span className="text-sm">{getCountryFlag(currentUser.countryCode || 'IN')}</span>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black">
                    VIP {currentUser.vipLevel}
                  </span>
                </div>
                <p className="text-xs text-neutral-400 font-mono">User ID: {currentUser.id} • {currentUser.name}</p>
              </div>
            </div>

            {/* Currency Badges Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              
              {/* 1. Virtual Coins */}
              <div className="bg-neutral-950/80 border border-amber-500/30 rounded-2xl p-3.5 shadow-inner">
                <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold mb-1">
                  <Coins className="w-4 h-4" />
                  <span>Coins Balance</span>
                </div>
                <div className="text-xl font-black text-white font-mono tracking-tight">
                  🪙 {currentUser.coinBalance.toLocaleString()}
                </div>
                <div className="text-[10px] text-neutral-400 mt-0.5">Primary live stream currency</div>
              </div>

              {/* 2. Bolt / Energy */}
              <div className="bg-neutral-950/80 border border-teal-500/30 rounded-2xl p-3.5 shadow-inner">
                <div className="flex items-center gap-1.5 text-xs text-teal-400 font-bold mb-1">
                  <Zap className="w-4 h-4" />
                  <span>Bolt / Energy</span>
                </div>
                <div className="text-xl font-black text-teal-200 font-mono tracking-tight">
                  ⚡ {(currentUser.boltBalance || 18500).toLocaleString()}
                </div>
                <div className="text-[10px] text-neutral-400 mt-0.5">Stream boost & VIP perks</div>
              </div>

              {/* 3. Diamonds / Earnings */}
              <div className="bg-neutral-950/80 border border-purple-500/30 rounded-2xl p-3.5 shadow-inner col-span-2 sm:col-span-1">
                <div className="flex items-center gap-1.5 text-xs text-purple-400 font-bold mb-1">
                  <Sparkles className="w-4 h-4" />
                  <span>Diamonds</span>
                </div>
                <div className="text-xl font-black text-purple-200 font-mono tracking-tight">
                  💎 {currentUser.diamondBalance.toLocaleString()}
                </div>
                <div className="text-[10px] text-neutral-400 mt-0.5">Gift earnings & cashout</div>
              </div>

            </div>
          </div>

          {/* Quick Actions Navigator */}
          <div className="flex flex-wrap md:flex-col gap-2 shrink-0">
            {!isHostWithoutAgency ? (
              <button
                onClick={() => setActiveSubTab('withdraw')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 border ${
                  activeSubTab === 'withdraw'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-neutral-950 border-emerald-400 shadow-lg shadow-emerald-950/60 ring-2 ring-emerald-400/50'
                    : 'bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 border-emerald-500/40'
                }`}
              >
                <DollarSign className="w-4 h-4 text-emerald-300 stroke-[3]" />
                <span>💎 Withdraw / Cashout</span>
              </button>
            ) : (
              <div 
                onClick={() => {
                  playSoundFX('alert');
                  alert('🔒 Withdrawal Section Locked: You must join an approved talent agency before you can withdraw earnings.');
                }}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-neutral-900/60 text-neutral-400 border border-neutral-800 flex items-center gap-2 cursor-pointer hover:border-amber-500/50 transition-colors"
                title="Join an agency to unlock withdrawals"
              >
                <span>🔒 Withdraw (Agency Required)</span>
              </div>
            )}
            <button
              onClick={() => setActiveSubTab('earnings')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                activeSubTab === 'earnings'
                  ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white border-pink-400 shadow-md shadow-pink-950/50 ring-2 ring-pink-400/40'
                  : 'bg-pink-950/30 hover:bg-pink-900/40 text-pink-300 border-pink-500/30'
              }`}
            >
              <Gift className="w-4 h-4 text-pink-400" />
              <span>🎁 Gift Earnings</span>
            </button>
            <button
              onClick={() => setActiveSubTab('recharge')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                activeSubTab === 'recharge'
                  ? 'bg-amber-500 text-neutral-950 border-amber-400 shadow-md shadow-amber-950/50'
                  : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>Recharge Coins</span>
            </button>
            <button
              onClick={() => setActiveSubTab('transfer')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                activeSubTab === 'transfer'
                  ? 'bg-emerald-500 text-neutral-950 border-emerald-400 shadow-md shadow-emerald-950/50'
                  : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>Send / Transfer</span>
            </button>
            <button
              onClick={() => setActiveSubTab('exchange')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                activeSubTab === 'exchange'
                  ? 'bg-purple-500 text-white border-purple-400 shadow-md shadow-purple-950/50'
                  : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
              }`}
            >
              <RefreshCw className="w-4 h-4" />
              <span>Exchange 💎</span>
            </button>
            <button
              onClick={() => setActiveSubTab('history')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                activeSubTab === 'history'
                  ? 'bg-neutral-700 text-white border-neutral-600'
                  : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
              }`}
            >
              <History className="w-4 h-4" />
              <span>History Ledger</span>
            </button>
          </div>

        </div>
      </div>

      {/* SubTab 0: Real-Money Diamond Withdrawal (Screenshot Match) */}
      {activeSubTab === 'withdraw' && (
        <div className="space-y-6 max-w-2xl mx-auto animate-in fade-in pb-8">
          {isHostWithoutAgency ? (
            <div className="bg-[#1b1424] border-2 border-amber-500/50 rounded-3xl p-8 text-center space-y-4 my-8 shadow-2xl">
              <div className="w-14 h-14 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300 mx-auto text-2xl">
                🔒
              </div>
              <h3 className="text-lg font-black text-amber-300 font-['Outfit']">Withdrawal Section Locked</h3>
              <p className="text-xs text-neutral-300 max-w-md mx-auto leading-relaxed">
                You are registered as a Host on DIYO LIVE, but you have <strong>not joined an agency</strong> yet. As per platform policy, cash withdrawals are strictly hidden until you join an approved talent agency.
              </p>
              <div className="pt-2">
                <span className="inline-block px-4 py-2 rounded-xl bg-amber-500/15 text-amber-300 text-xs font-bold border border-amber-500/30">
                  Please join an agency to unlock your withdrawal section.
                </span>
              </div>
            </div>
          ) : (
            <>
          {/* Top Header */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (onBack) onBack();
                else setActiveSubTab('earnings');
                playSoundFX('click');
              }}
              className="w-10 h-10 rounded-2xl bg-neutral-900 hover:bg-neutral-800 flex items-center justify-center text-white border border-neutral-800 transition-colors shadow-md"
              title="Back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-purple-950/50">
                💎
              </div>
              <h2 className="text-xl font-black text-white font-['Outfit'] tracking-wide">Withdraw</h2>
            </div>
          </div>

          {/* Diamond Balance Card */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1d1436] via-[#14102b] to-[#0d0e23] border border-[#3b2a63] p-7 shadow-2xl space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold text-purple-300">
              <span>💎</span>
              <span>Diamond Balance</span>
            </div>
            
            <div className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
              {currentUser.diamondBalance.toLocaleString()}
            </div>

            <div className="text-xs text-purple-300/80 font-medium">
              Available for withdrawal
            </div>

            <div className="flex items-center gap-3 pt-3">
              <button
                onClick={() => {
                  setWithdrawMethod('UPI');
                  playSoundFX('superchat');
                }}
                className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:opacity-90 text-white font-black text-xs shadow-lg shadow-purple-950/80 transition-transform active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <span>Withdraw Now</span>
              </button>
              <button
                onClick={() => {
                  setActiveSubTab('history');
                  playSoundFX('click');
                }}
                className="px-6 py-2.5 rounded-2xl bg-neutral-800/90 hover:bg-neutral-700 text-neutral-200 font-bold text-xs border border-neutral-700 shadow-md transition-transform active:scale-95 cursor-pointer"
              >
                History
              </button>
            </div>
          </div>

          {/* Select Withdrawal Method & Request Form */}
          <div className="space-y-4 pt-2">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-widest px-1">
              Select Withdrawal Method
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { id: 'IMPS_BANK', name: 'Bank Account', desc: 'Direct bank transfer', icon: Building2, gradient: 'from-cyan-500 to-blue-600', country: 'IN' },
                { id: 'ESEWA', name: 'eSewa', desc: 'eSewa digital wallet', icon: Smartphone, gradient: 'from-emerald-400 to-green-600', country: 'NP' },
                { id: 'UPI', name: 'UPI', desc: 'Unified Payments Interface', icon: Smartphone, gradient: 'from-purple-500 to-indigo-600', country: 'IN' },
                { id: 'USDT_TRC20', name: 'Global', desc: 'International USDT / Crypto', icon: Globe, gradient: 'from-amber-500 to-orange-600', country: 'GLOBAL' }
              ].map((m) => {
                const IconComponent = m.icon;
                const isSelected = withdrawMethod === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      setWithdrawMethod(m.id as any);
                      setWithdrawCountry(m.country as any);
                      playSoundFX('click');
                    }}
                    className={`p-4 rounded-3xl border text-left transition-all flex items-center justify-between group cursor-pointer ${
                      isSelected
                        ? 'bg-purple-950/40 border-purple-500 shadow-xl shadow-purple-950/50 scale-[1.01]'
                        : 'bg-neutral-900/90 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${m.gradient} flex items-center justify-center text-white shadow-lg shadow-black/40 group-hover:scale-105 transition-transform`}>
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-white font-['Outfit']">{m.name}</h4>
                        <p className="text-xs text-neutral-400">{m.desc}</p>
                      </div>
                    </div>
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center border transition-colors ${
                      isSelected ? 'bg-purple-500 border-purple-400 text-white' : 'border-neutral-700 text-neutral-600'
                    }`}>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Payout Request Execution Card */}
            <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-2xl mt-4">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                <span className="text-xs font-bold text-white flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-emerald-400" />
                  <span>Request Payout via {withdrawMethod}</span>
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-xl border border-emerald-500/30">
                  0% Payout Fee
                </span>
              </div>

              {withdrawError && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/40 rounded-2xl flex items-center gap-2 text-xs font-bold text-rose-300">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{withdrawError}</span>
                </div>
              )}

              <form onSubmit={handleExecuteDiamondWithdrawal} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-neutral-300">Diamonds to Withdraw (Min 1,000):</label>
                  <div className="relative">
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-400 font-bold">💎</div>
                    <input
                      type="number"
                      value={withdrawDiamondsAmount}
                      onChange={(e) => setWithdrawDiamondsAmount(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-2xl pl-10 pr-4 py-3 text-sm text-white font-mono focus:outline-none focus:border-emerald-500"
                      placeholder="10000"
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1">
                    <span>Available: {currentUser.diamondBalance.toLocaleString()} 💎</span>
                    <button
                      type="button"
                      onClick={() => setWithdrawDiamondsAmount(currentUser.diamondBalance.toString())}
                      className="text-emerald-400 font-bold hover:underline"
                    >
                      Max All
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-neutral-300">Account / UPI ID / Wallet Number / IBAN:</label>
                  <input
                    type="text"
                    value={accountNumberOrId}
                    onChange={(e) => setAccountNumberOrId(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-2xl px-4 py-3 text-sm text-white font-mono focus:outline-none focus:border-emerald-500"
                    placeholder="e.g. user@oksbi or 9841234567"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-neutral-300">Account Holder / Full Name:</label>
                  <input
                    type="text"
                    value={accountHolderName}
                    onChange={(e) => setAccountHolderName(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-emerald-500"
                    placeholder="e.g. Aarav Mehta"
                  />
                </div>

                <div className="pt-2 flex items-center justify-between gap-4">
                  <div className="text-xs text-neutral-400">
                    Net Payout: <strong className="text-emerald-400 font-mono">${(Number(withdrawDiamondsAmount || 0) / 1000).toFixed(2)} USD</strong>
                  </div>
                  <button
                    type="submit"
                    disabled={withdrawLoading || Number(withdrawDiamondsAmount) <= 0}
                    className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:opacity-90 text-neutral-950 font-black text-xs shadow-lg shadow-emerald-950/60 transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
                  >
                    {withdrawLoading ? 'Processing...' : 'Confirm & Withdraw Now'}
                  </button>
                </div>
              </form>
            </div>

          </div>






      {/* Recent Withdrawals History Table */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-black text-white">Your Cashout History & Status</h3>
              </div>
              
              {/* Status Filter Buttons */}
              <div className="flex items-center gap-1.5 overflow-x-auto">
                {(['ALL', 'Pending', 'Approved', 'Completed', 'Rejected'] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setWithdrawalStatusFilter(st)}
                    className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all ${
                      withdrawalStatusFilter === st
                        ? 'bg-emerald-500 text-neutral-950 font-black shadow-sm'
                        : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            <div className="divide-y divide-neutral-800">
              {withdrawalsList
                .filter(w => withdrawalStatusFilter === 'ALL' || w.status === withdrawalStatusFilter)
                .map((w) => (
                <div key={w.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-neutral-850/40 transition-colors rounded-2xl px-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold text-sm">
                      {w.currency === 'INR' ? '₹' : w.currency === 'NPR' ? 'रू' : w.currency === 'BDT' ? '৳' : w.currency === 'PKR' ? 'Rs' : '$'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{w.method || w.payoutMethod} Cashout</span>
                        <span className="text-[10px] font-mono text-neutral-500">#{w.id}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold border ${
                          w.status === 'Completed' ? 'bg-teal-500/20 text-teal-300 border-teal-500/40' :
                          w.status === 'Approved' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' :
                          w.status === 'Rejected' ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' :
                          'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        }`}>
                          {w.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-400 truncate max-w-md">
                        To: {w.recipientDetails || w.accountDetails} • Ref: {w.transactionRef || w.referenceNumber}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-sm font-black text-emerald-400 font-mono">
                      +${(w.payoutAmountUSD ?? 0).toFixed(2)} USD ({w.currency})
                    </div>
                    <div className="text-[10px] text-neutral-500 font-mono">
                      -{(w.amountDiamonds ?? 0).toLocaleString()} 💎 • {w.timestamp || w.requestedAt}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
            </>
          )}

        </div>
      )}

      {/* SubTab 0.5: Host Gift Earnings Ledger & Breakdown */}
      {activeSubTab === 'earnings' && (
        <div className="space-y-6 animate-in fade-in">
          
          {/* Top Host Earning Stats Banner */}
          <div className="p-5 rounded-3xl bg-gradient-to-r from-pink-950/90 via-purple-950/80 to-neutral-900 border border-pink-500/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-14 h-14 rounded-2xl bg-pink-500/20 border border-pink-500/40 flex items-center justify-center text-3xl shadow-inner">
                🎁
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-black text-white">Host Received Gift Earnings</h2>
                  <span className="px-2.5 py-0.5 rounded-full bg-pink-500/20 text-pink-300 text-[10px] font-black border border-pink-500/40">
                    70% Direct Host Share
                  </span>
                </div>
                <p className="text-xs text-neutral-300 mt-0.5">
                  Real-time ledger of all virtual gifts received from viewers during live video & party voice streams.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="px-4 py-2 rounded-2xl bg-neutral-950/80 border border-pink-500/30 text-right">
                <div className="text-[10px] text-neutral-400 font-bold uppercase">Total Gift Income</div>
                <div className="text-sm font-black text-pink-300 font-mono">
                  💎 {currentUser.diamondBalance.toLocaleString()} (≈ ${(currentUser.diamondBalance / 1000).toFixed(2)} USD)
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActiveSubTab('withdraw');
                  playSoundFX('click');
                }}
                className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-neutral-950 font-black text-xs transition-transform active:scale-95 shadow-lg shadow-emerald-950/50 flex items-center gap-2"
              >
                <DollarSign className="w-4 h-4 stroke-[3]" />
                <span>Withdraw Earnings</span>
              </button>
            </div>
          </div>

          {/* 4 Category Breakdown Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 space-y-1">
              <div className="text-xl">🌹</div>
              <div className="text-xs font-bold text-neutral-400">Normal & Flags</div>
              <div className="text-lg font-black text-white font-mono">54,000 💎</div>
              <div className="text-[10px] text-emerald-400 font-semibold">+70% Direct Earning</div>
            </div>

            <div className="bg-neutral-900 border border-amber-500/30 rounded-3xl p-4 space-y-1 bg-gradient-to-b from-neutral-900 to-amber-950/20">
              <div className="text-xl">🎰</div>
              <div className="text-xs font-bold text-amber-300">Lucky Gifts</div>
              <div className="text-lg font-black text-amber-300 font-mono">62,500 💎</div>
              <div className="text-[10px] text-amber-400 font-semibold">+Multiplier Drops</div>
            </div>

            <div className="bg-neutral-900 border border-rose-500/30 rounded-3xl p-4 space-y-1 bg-gradient-to-b from-neutral-900 to-rose-950/20">
              <div className="text-xl">🧧</div>
              <div className="text-xs font-bold text-rose-300">Red Packets</div>
              <div className="text-lg font-black text-rose-300 font-mono">18,500 💎</div>
              <div className="text-[10px] text-rose-400 font-semibold">100% P2P Share</div>
            </div>

            <div className="bg-neutral-900 border border-purple-500/30 rounded-3xl p-4 space-y-1 bg-gradient-to-b from-neutral-900 to-purple-950/20">
              <div className="text-xl">🎙️</div>
              <div className="text-xs font-bold text-purple-300">Party Voice Seats</div>
              <div className="text-lg font-black text-purple-300 font-mono">10,000 💎</div>
              <div className="text-[10px] text-purple-400 font-semibold">20-Seat Room Splits</div>
            </div>
          </div>

          {/* Detailed Gift Earnings Transaction Table */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Gift className="w-4 h-4 text-pink-400" />
                  <span>Received Gifts History & Creator Ledger</span>
                </h3>
                <p className="text-xs text-neutral-400">All gifts sent to your host profile with sender details and net earnings</p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search sender or gift..."
                  value={giftEarningsSearch}
                  onChange={(e) => setGiftEarningsSearch(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
                  <tr>
                    <th className="p-3">Gift Item</th>
                    <th className="p-3">Sender Details</th>
                    <th className="p-3">Gross Coins</th>
                    <th className="p-3">Host Earning (Diamonds)</th>
                    <th className="p-3">Rate</th>
                    <th className="p-3">Date & Time</th>
                    <th className="p-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800 font-mono">
                  {giftEarningsList
                    .filter(g => {
                      const q = (giftEarningsSearch || '').toLowerCase();
                      return g.giftName.toLowerCase().includes(q) || g.senderName.toLowerCase().includes(q) || g.id.toLowerCase().includes(q);
                    })
                    .map((g) => (
                      <tr key={g.id} className="hover:bg-neutral-850/50 transition-colors">
                        <td className="p-3">
                          <div className="flex items-center gap-2 font-sans">
                            <span className="text-xl">{g.giftIcon}</span>
                            <div>
                              <span className="font-bold text-white block">{g.quantity}x {g.giftName}</span>
                              <span className="text-[10px] font-mono text-neutral-500">#{g.id}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-3 font-sans">
                          <span className="font-bold text-white block">{g.senderName}</span>
                          <span className="text-[10px] font-mono text-neutral-400">{g.senderId}</span>
                        </td>
                        <td className="p-3 text-amber-400 font-bold">
                          🪙 {g.totalCostCoins.toLocaleString()}
                        </td>
                        <td className="p-3 text-pink-400 font-bold">
                          💎 +{g.hostEarningDiamonds.toLocaleString()}
                        </td>
                        <td className="p-3 text-neutral-400">
                          {g.commissionRate}%
                        </td>
                        <td className="p-3 text-neutral-400 font-sans text-[11px]">
                          {g.timestamp}
                        </td>
                        <td className="p-3 text-right">
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px] border border-emerald-500/40">
                            {g.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* WITHDRAWAL SUCCESS RECEIPT MODAL */}
      {withdrawReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-neutral-900 border border-emerald-500/50 rounded-3xl p-6 shadow-2xl shadow-emerald-950/60 space-y-5">
            
            <button
              onClick={() => setWithdrawReceipt(null)}
              className="absolute top-4 right-4 p-1 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-2 pt-2">
              <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-2xl shadow-lg shadow-emerald-500/30 animate-bounce">
                ✅
              </div>
              <h3 className="text-lg font-black text-white">Cashout Request Approved!</h3>
              <p className="text-xs text-emerald-300">
                Your diamond withdrawal has been verified and registered on the DIYO LIVE network.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-400">Receipt ID:</span>
                <span className="text-white font-bold">{withdrawReceipt.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Diamonds Redeemed:</span>
                <span className="text-white font-bold">💎 {withdrawReceipt.amountDiamonds.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Net Amount:</span>
                <span className="text-emerald-400 font-bold">${withdrawReceipt.payoutAmountUSD.toFixed(2)} USD ({withdrawReceipt.currency})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Recipient Account:</span>
                <span className="text-neutral-200 truncate max-w-[200px]">{withdrawReceipt.recipientDetails}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Status:</span>
                <span className="text-emerald-400 font-bold">⚡ Dispatched (Instant)</span>
              </div>
            </div>

            <button
              onClick={() => {
                setWithdrawReceipt(null);
                playSoundFX('click');
              }}
              className="w-full py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg"
            >
              Done / Return to Wallet
            </button>
          </div>
        </div>
      )}

      {/* SubTab 1: Recharge Notice & Authorized Coin Seller Hub */}
      {activeSubTab === 'recharge' && (
        <div className="space-y-4 animate-in fade-in">
          {/* Official Notice: Online Recharge OFF */}
          <div className="p-5 rounded-3xl bg-neutral-900 border border-amber-500/40 shadow-2xl space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-['Outfit'] text-base font-black text-white flex items-center gap-2">
                  <span>Online Top-Up / Payment Gateways: OFF</span>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                    TESTING MODE
                  </span>
                </h2>
                <p className="text-xs text-neutral-400">
                  Direct online payment gateways, fake recharge forms, and first-recharge bonuses are strictly disabled in this test environment.
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2 text-xs text-neutral-300 font-mono">
              <div className="text-amber-400 font-bold font-sans">📌 Authorized Coin Distribution Rules:</div>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-neutral-400 font-sans">
                <li>Coins can only be distributed by Authorized <strong className="text-white">Coin Sellers</strong> or <strong className="text-white">Super Admins</strong>.</li>
                <li>Designated Official Coin Seller has <strong className="text-amber-400">10,000,000,000 TEST Coins</strong> allocated for testing.</li>
                <li>Owner / Super Admin reserve holds <strong className="text-amber-400">500,000,000 TEST Coins</strong>.</li>
                <li>New users start with strictly <strong className="text-white">0 Coins & 0 Diamonds</strong>.</li>
              </ul>
            </div>

            {/* If user is Coin Seller or Admin, provide quick link to Transfer/Distribute */}
            {['COIN_SELLER', 'SUPER_ADMIN', 'ADMIN', 'MANAGER'].includes(currentUser.role) ? (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setActiveSubTab('transfer')}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-[0.99]"
                >
                  <Send className="w-4 h-4 text-neutral-950" />
                  <span>Open Coin Distribution Desk (Give Coins to User ID)</span>
                </button>
              </div>
            ) : (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setActiveSubTab('transfer')}
                  className="w-full py-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
                >
                  <Send className="w-4 h-4 text-emerald-400" />
                  <span>P2P Coin Transfer Between Users</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SubTab 2: Send / Transfer Coins */}
      {activeSubTab === 'transfer' && (
        <div className="max-w-xl mx-auto bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl space-y-5 animate-in fade-in">
          <div className="flex items-center gap-3 border-b border-neutral-800 pb-4">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-['Outfit'] text-base font-black text-white">Transfer Virtual Coins</h2>
              <p className="text-xs text-neutral-400">Send coins directly to any DIYO LIVE user or streamer ID</p>
            </div>
          </div>

          {transferSuccessMsg && (
            <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/40 rounded-2xl flex items-center gap-3 text-xs font-bold text-emerald-300 animate-in zoom-in-95">
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{transferSuccessMsg}</span>
            </div>
          )}

          {transferErrorMsg && (
            <div className="p-3.5 bg-rose-500/10 border border-rose-500/40 rounded-2xl text-xs font-bold text-rose-300">
              {transferErrorMsg}
            </div>
          )}

          <form onSubmit={handleExecuteTransfer} className="space-y-4">
            
            {/* Recipient Field */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-neutral-300">Recipient User ID or Username:</label>
              <input
                type="text"
                value={transferRecipientId}
                onChange={(e) => setTransferRecipientId(e.target.value)}
                placeholder="e.g. USR-8001, HST-901, or rohan_vip"
                required
                className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-2xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none font-mono"
              />
            </div>

            {/* Quick Pick Contacts */}
            <div className="space-y-1">
              <label className="text-[11px] text-neutral-400">Quick Select Suggested Recipients:</label>
              <div className="flex flex-wrap gap-2">
                {[
                  { id: 'HST-901', name: 'DJ Anya (India 🇮🇳)' },
                  { id: 'HST-902', name: 'Pooja (Nepal 🇳🇵)' },
                  { id: 'HST-903', name: 'Tanvir (Bangladesh 🇧🇩)' },
                  { id: 'USR-8001', name: 'Aarav Mehta' }
                ].map((user) => (
                  <button
                    key={user.id}
                    type="button"
                    onClick={() => setTransferRecipientId(user.id)}
                    className="px-2.5 py-1 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px] font-semibold transition-colors"
                  >
                    {user.name} ({user.id})
                  </button>
                ))}
              </div>
            </div>

            {/* Amount Field */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-neutral-300">Coin Amount to Transfer:</label>
                <span className="text-[11px] text-amber-400 font-mono">Max: {currentUser.coinBalance.toLocaleString()}</span>
              </div>
              <input
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                min="100"
                max={currentUser.coinBalance}
                step="100"
                required
                className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-2xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none font-mono text-lg font-bold"
              />
            </div>

            {/* Note Field */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-neutral-300">Transfer Note (Optional):</label>
              <input
                type="text"
                value={transferNote}
                onChange={(e) => setTransferNote(e.target.value)}
                placeholder="Message for recipient"
                className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-2xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-neutral-950 text-xs font-black uppercase tracking-wider shadow-lg shadow-emerald-950/60 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Send className="w-4 h-4" />
              <span>Confirm Instant Coin Transfer</span>
            </button>
          </form>
        </div>
      )}

      {/* SubTab 3: Exchange Coins to Diamonds */}
      {activeSubTab === 'exchange' && (
        <div className="max-w-xl mx-auto bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl space-y-5 animate-in fade-in">
          <div className="flex items-center gap-3 border-b border-neutral-800 pb-4">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-['Outfit'] text-base font-black text-white">Exchange Coins & Diamonds</h2>
              <p className="text-xs text-neutral-400">Convert Virtual Coins into Creator Diamonds</p>
            </div>
          </div>

          {exchangeSuccessMsg && (
            <div className="p-3.5 bg-purple-500/10 border border-purple-500/40 rounded-2xl text-xs font-bold text-purple-300">
              {exchangeSuccessMsg}
            </div>
          )}

          <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
            <div className="text-xs text-neutral-400">Conversion Rate:</div>
            <div className="text-sm font-bold text-white flex items-center gap-2 font-mono">
              <span>🪙 10 Coins</span>
              <span>=</span>
              <span>💎 1 Diamond</span>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-xs font-bold text-neutral-300">Amount of Coins to Convert:</label>
            <input
              type="number"
              value={exchangeCoinsAmount}
              onChange={(e) => setExchangeCoinsAmount(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-700 focus:border-purple-500 rounded-2xl px-4 py-3 text-xs text-white font-mono text-lg font-bold"
            />
            <div className="text-xs text-purple-400 font-mono">
              You will receive: 💎 {Math.floor(parseInt(exchangeCoinsAmount || '0', 10) / 10).toLocaleString()} Diamonds
            </div>

            <button
              onClick={handleExchange}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white text-xs font-black uppercase tracking-wider shadow-lg shadow-purple-950/60 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Convert Now</span>
            </button>
          </div>
        </div>
      )}

      {/* SubTab 4: Transaction History Ledger */}
      {activeSubTab === 'history' && (
        <div className="space-y-4 animate-in fade-in">
          
          {/* Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {(['ALL', 'WITHDRAW', 'GIFT', 'RECHARGE', 'TRANSFER', 'GAME'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setHistoryFilter(filter)}
                className={`px-3.5 py-1.5 rounded-2xl text-xs font-bold transition-all border ${
                  historyFilter === filter
                    ? 'bg-neutral-200 text-neutral-950 border-white'
                    : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 border-neutral-800'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          {/* Transactions List */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl">
            {filteredTxs.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-500">
                No transactions recorded for this filter category.
              </div>
            ) : (
              <div className="divide-y divide-neutral-800">
                {filteredTxs.map((tx) => {
                  const isPositive = tx.amountCoins > 0;
                  return (
                    <div key={tx.id} className="p-4 flex items-center justify-between hover:bg-neutral-800/40 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                          isPositive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {isPositive ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-2">
                            <span>{tx.type}</span>
                            <span className="text-[10px] font-mono text-neutral-500">#{tx.id}</span>
                          </div>
                          <p className="text-[11px] text-neutral-400">{tx.notes || 'In-App Transaction'} • {tx.timestamp}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-xs font-black font-mono ${isPositive ? 'text-emerald-400' : 'text-neutral-200'}`}>
                          {isPositive ? '+' : ''}{tx.amountCoins.toLocaleString()} Coins
                        </div>
                        <span className="text-[10px] text-emerald-500 font-bold">{tx.status}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
