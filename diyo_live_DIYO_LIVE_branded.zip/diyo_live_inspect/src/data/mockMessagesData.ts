export interface DirectMessageConversation {
  id: string;
  senderName: string;
  senderAvatar: string;
  senderRole: string;
  senderVipLevel?: number;
  isVerified?: boolean;
  isOfficial?: boolean;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  isOnline?: boolean;
  messages: {
    id: string;
    sender: 'them' | 'me';
    text: string;
    time: string;
    giftSent?: {
      name: string;
      icon: string;
      coins: number;
    };
  }[];
}

export const INITIAL_CONVERSATIONS: DirectMessageConversation[] = [
  {
    id: 'CONV-01',
    senderName: 'DIYO LIVE Official Team',
    senderAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    senderRole: 'System Broadcaster',
    isOfficial: true,
    lastMessage: '🎉 Welcome to DIYO LIVE VIP Tier 8! Your 24/7 dedicated concierge is now online.',
    lastMessageTime: '10:45 AM',
    unreadCount: 1,
    messages: [
      {
        id: 'm1',
        sender: 'them',
        text: 'Welcome to DIYO LIVE! Your account has been credited with initial sandbox test liquidity.',
        time: 'Yesterday'
      },
      {
        id: 'm2',
        sender: 'them',
        text: '🎉 Welcome to DIYO LIVE VIP Tier 8! Your 24/7 dedicated concierge is now online.',
        time: '10:45 AM'
      }
    ]
  },
  {
    id: 'CONV-02',
    senderName: 'DJ Anya',
    senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    senderRole: 'Host • Starlight Media',
    senderVipLevel: 7,
    isVerified: true,
    isOnline: true,
    lastMessage: 'Thank you so much for the Galaxy Cruiser gift today! 🚀✨',
    lastMessageTime: 'Just now',
    unreadCount: 2,
    messages: [
      {
        id: 'm3',
        sender: 'them',
        text: 'Hey Aarav! Loved having you in the front row of the stream today!',
        time: '11:15 AM'
      },
      {
        id: 'm4',
        sender: 'them',
        text: 'Thank you so much for the Galaxy Cruiser gift today! 🚀✨',
        time: '11:18 AM'
      }
    ]
  },
  {
    id: 'CONV-03',
    senderName: 'Starlight Agency Guild',
    senderAvatar: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=150&auto=format&fit=crop&q=80',
    senderRole: 'Official Agency #1',
    isOfficial: true,
    lastMessage: 'Weekly Agency Diamond Ranking rewards have been distributed to your wallet.',
    lastMessageTime: 'Yesterday',
    unreadCount: 0,
    messages: [
      {
        id: 'm5',
        sender: 'them',
        text: 'Weekly Agency Diamond Ranking rewards have been distributed to your wallet.',
        time: 'Yesterday'
      }
    ]
  }
];
