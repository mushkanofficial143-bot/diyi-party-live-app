export interface MomentPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorRole: string;
  authorVipLevel: number;
  isVerified?: boolean;
  timeAgo: string;
  content: string;
  mediaType: 'image' | 'video';
  mediaUrl: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  isLiked?: boolean;
  tags: string[];
  comments: {
    id: string;
    userName: string;
    avatar: string;
    vipLevel: number;
    text: string;
    timeAgo: string;
  }[];
}

export const INITIAL_MOMENTS: MomentPost[] = [
  {
    id: 'MOM-01',
    authorId: 'HST-901',
    authorName: 'DJ Anya',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    authorRole: 'Live Host',
    authorVipLevel: 7,
    isVerified: true,
    timeAgo: '15m ago',
    content: 'Soundcheck done for tonight’s Sunset Synthwave 4K live set! 🎧✨ Drop your song requests in the comments below, see you all in the room at 8 PM UTC! 💎',
    mediaType: 'image',
    mediaUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80',
    likesCount: 1420,
    commentsCount: 89,
    sharesCount: 34,
    tags: ['#SRLive', '#DJSet', '#ElectronicVibes'],
    comments: [
      {
        id: 'c1',
        userName: 'Aarav Mehta',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        vipLevel: 8,
        text: 'Ready with the Royal Dragons! 🐉 Let’s break the diamond record tonight!',
        timeAgo: '10m ago'
      },
      {
        id: 'c2',
        userName: 'Ananya Gupta',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
        vipLevel: 6,
        text: 'Cannot wait for the new VIP remix! 🔥',
        timeAgo: '5m ago'
      }
    ]
  },
  {
    id: 'MOM-02',
    authorId: 'HST-902',
    authorName: 'Kavita Roy',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    authorRole: 'Esports Pro Host',
    authorVipLevel: 6,
    isVerified: true,
    timeAgo: '1h ago',
    content: 'GGs! We just secured 1st place in the CyberStrike Semi-Finals live on stream! Thank you to my Starlight Family for the incredible Lucky Boxes! 🚀🏆',
    mediaType: 'image',
    mediaUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80',
    likesCount: 2890,
    commentsCount: 164,
    sharesCount: 78,
    tags: ['#Esports', '#CyberStrike', '#SRChampions'],
    comments: [
      {
        id: 'c3',
        userName: 'Rishi Kapoor',
        avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
        vipLevel: 4,
        text: 'Insane clutch in round 14! You deserved this win 👑',
        timeAgo: '45m ago'
      }
    ]
  },
  {
    id: 'MOM-03',
    authorId: 'HST-903',
    authorName: 'Devansh Kapoor',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    authorRole: 'Sports Analyst',
    authorVipLevel: 5,
    isVerified: true,
    timeAgo: '3h ago',
    content: 'Tactical breakdown of tonight\'s Super Derby clash! Will the underdog counter-attack pay off? Tune in to my live commentary room now! ⚽⚡',
    mediaType: 'image',
    mediaUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&auto=format&fit=crop&q=80',
    likesCount: 980,
    commentsCount: 42,
    sharesCount: 19,
    tags: ['#FootballLive', '#Matchday', '#SRSports'],
    comments: []
  }
];
