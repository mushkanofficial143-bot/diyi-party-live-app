import {
  SuperAdminAccount,
  AdminAccount,
  ManagerAccount,
  AgencyAccount,
  HostAccount,
  UserAccount,
  LiveRoomSession,
  GiftItem,
  WalletTransaction,
  VipTierConfig,
  GameItem,
  CasinoTestTransaction,
  WithdrawalRequest,
  ModerationReport,
  SystemNotification,
  AuditLogEntry,
  PlatformSettings,
  OwnerDashboardStats,
  CoinSellerAccount,
  CoinSellerTransaction,
  OwnerToSellerTransaction,
  PartyLiveRoomSession,
  AvatarFrameItem,
  PkBattleItem,
  HostTypeDefinition,
  HostTagType,
  HostEarningsLedgerEntry,
  HostEarningsWallet
} from '../types/ownerTypes';
import { CATALOG_17_GAMES } from './allGamesData';

export const HOST_TYPE_DEFINITIONS: HostTypeDefinition[] = [
  {
    id: 'HT-CELEBRATE',
    tag: 'CELEBRATE',
    name: 'Celebrate Host',
    tagLabel: '🎉 CELEBRATE HOST',
    badgeIcon: '🎉',
    badgeBg: 'bg-gradient-to-r from-amber-500/25 via-yellow-500/20 to-rose-500/25',
    badgeBorder: 'border-amber-400/60 shadow-[0_0_15px_rgba(251,191,36,0.35)]',
    badgeText: 'text-amber-300 font-black tracking-wider',
    gradient: 'from-amber-500 via-rose-500 to-yellow-400',
    description: 'Premier celebratory & festival party hosts with sparkling golden royal crown party aura and VIP confetti fanfare.',
    frameId: 'FRM-HT-01',
    frameName: 'Celebrate Host Frame',
    frameBorderClass: 'ring-2 ring-amber-400 shadow-lg shadow-amber-500/50',
    liveRoomFrameClass: 'border-2 border-amber-400 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-amber-500/10',
    entryEffect: '🎉 Golden Confetti & Fireworks Blast with Royal Trumpet Fanfare',
    status: 'Active',
    commissionRateDefault: 75,
    isEnabled: true
  },
  {
    id: 'HT-TALENT',
    tag: 'TALENT',
    name: 'Talent Host',
    tagLabel: '⭐ TALENT HOST',
    badgeIcon: '⭐',
    badgeBg: 'bg-gradient-to-r from-purple-600/25 via-fuchsia-600/25 to-pink-600/25',
    badgeBorder: 'border-purple-400/60 shadow-[0_0_15px_rgba(192,132,252,0.35)]',
    badgeText: 'text-purple-200 font-black tracking-wider',
    gradient: 'from-purple-600 via-fuchsia-500 to-pink-500',
    description: 'Creative variety creators, elite dancers, gaming pros and interactive entertainers with electric neon cyber spotlight.',
    frameId: 'FRM-HT-02',
    frameName: 'Talent Host Frame',
    frameBorderClass: 'ring-2 ring-purple-400 shadow-lg shadow-purple-500/50',
    liveRoomFrameClass: 'border-2 border-purple-400 bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-indigo-500/10',
    entryEffect: '⭐ Cyber Neon Spotlight & Laser Beams with Synth Stinger',
    status: 'Active',
    commissionRateDefault: 70,
    isEnabled: true
  },
  {
    id: 'HT-SINGER',
    tag: 'SINGER',
    name: 'Singer Host',
    tagLabel: '🎤 SINGER HOST',
    badgeIcon: '🎤',
    badgeBg: 'bg-gradient-to-r from-cyan-500/25 via-blue-600/25 to-indigo-600/25',
    badgeBorder: 'border-cyan-400/60 shadow-[0_0_15px_rgba(34,211,238,0.35)]',
    badgeText: 'text-cyan-200 font-black tracking-wider',
    gradient: 'from-cyan-500 via-blue-500 to-teal-400',
    description: 'Acoustic vocalists, karaoke leaders, indie bands and live musicians with pulsating harmonic soundwave melody ring.',
    frameId: 'FRM-HT-03',
    frameName: 'Singer Host Frame',
    frameBorderClass: 'ring-2 ring-cyan-400 shadow-lg shadow-cyan-500/50',
    liveRoomFrameClass: 'border-2 border-cyan-400 bg-gradient-to-r from-cyan-500/10 via-blue-500/10 to-teal-500/10',
    entryEffect: '🎤 Harmonic Melody Soundwaves & Musical Notes Floating',
    status: 'Active',
    commissionRateDefault: 70,
    isEnabled: true
  },
  {
    id: 'HT-NORMAL',
    tag: 'NORMAL',
    name: 'Normal Host',
    tagLabel: '👤 NORMAL HOST',
    badgeIcon: '👤',
    badgeBg: 'bg-gradient-to-r from-emerald-500/25 via-teal-600/25 to-slate-700/30',
    badgeBorder: 'border-emerald-400/60 shadow-[0_0_15px_rgba(52,211,153,0.35)]',
    badgeText: 'text-emerald-200 font-black tracking-wider',
    gradient: 'from-emerald-500 via-teal-500 to-green-400',
    description: 'Verified live broadcaster roster with polished emerald crest border and official verified broadcaster identity.',
    frameId: 'FRM-HT-04',
    frameName: 'Normal Host Frame',
    frameBorderClass: 'ring-2 ring-emerald-400 shadow-lg shadow-emerald-500/40',
    liveRoomFrameClass: 'border-2 border-emerald-400 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-emerald-500/10',
    entryEffect: '👤 Verified Broadcaster Shield Glow Entry',
    status: 'Active',
    commissionRateDefault: 65,
    isEnabled: true
  }
];

export const INITIAL_SUPER_ADMINS: SuperAdminAccount[] = [
  {
    id: 'SA-001',
    name: 'Salam Star Master Super Admin',
    username: 'salamstar_owner',
    email: 'salamstarhotel@gmail.com',
    phone: '+977 98000 00001',
    status: 'Active',
    createdDate: '2025-01-01',
    lastLogin: 'Just now (Active)',
    assignedPermissions: [
      'ALL_ACCESS',
      'USER_BAN',
      'USER_UNBAN',
      'ADMIN_MANAGE',
      'MANAGER_MANAGE',
      'COIN_SELLER_MANAGE',
      'FINANCE_APPROVE',
      'USER_MODERATION',
      'AGENCY_GOVERNANCE',
      'SECURITY_AUDIT',
      'ROLE_ASSIGN'
    ],
    assignedArea: 'Global Platform Master Authority',
    activityLogsCount: 1250,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_ADMINS: AdminAccount[] = [];

export const INITIAL_MANAGERS: ManagerAccount[] = [];

export const INITIAL_AGENCIES: AgencyAccount[] = [];

export const INITIAL_HOSTS: HostAccount[] = [
  {
    id: 'HST-901',
    name: 'Anya Sharma (DJ Anya)',
    username: 'dj_anya_live',
    agencyId: 'AG-01',
    agencyName: 'Starlight Media Global',
    managerId: 'MGR-301',
    managerName: 'Rahul Verma',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 142000,
    giftsReceived: 28400,
    diamonds: 1850000,
    earningsUSD: 1850.00,
    totalLiveHours: 320,
    lastLive: '2026-08-15 05:55 UTC (NOW)',
    verificationStatus: 'Verified',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-401',
    bio: 'Electronic Music Producer & resident DIYO LIVE 4K DJ. Nightly synthwave and melodic techno sets.',
    hostTag: 'CELEBRATE',
    hostTypeId: 'HT-CELEBRATE',
    avatarFrameId: 'FRM-HT-01',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150',
    hostLevel: 9,
    xp: 88500,
    earningsWallet: {
      totalEarnedCoins: 1850000,
      availableEarnings: 1850000,
      pendingEarnings: 0,
      giftEarnings: 1520000,
      luckyGiftEarnings: 280000,
      redPacketEarnings: 50000,
      commissionRate: 75,
      history: [
        {
          id: 'HL-TX-001',
          transactionId: 'TX-GFT-9912',
          senderId: 'USR-882941',
          senderName: 'Aarav Mehta (VIP 8)',
          receiverHostId: 'HST-901',
          receiverHostName: 'Anya Sharma (DJ Anya)',
          giftId: 'g4',
          giftName: 'Lucky Castle',
          giftIcon: '🏰',
          giftPrice: 100000,
          multiplier: 1,
          senderPrevBalance: 345000,
          senderNewBalance: 245000,
          hostEarningAmount: 75000,
          hostPrevEarnings: 1775000,
          hostNewEarnings: 1850000,
          sourceType: 'LUCKY_GIFT',
          timestamp: '2026-08-15 05:50:12 UTC',
          liveRoomId: 'ROOM-401',
          status: 'COMPLETED',
          TEST_MODE: true
        },
        {
          id: 'HL-TX-002',
          transactionId: 'TX-GFT-9908',
          senderId: 'USR-8001',
          senderName: 'Rohan Joshi',
          receiverHostId: 'HST-901',
          receiverHostName: 'Anya Sharma (DJ Anya)',
          giftId: 'g2',
          giftName: 'Super Rocket',
          giftIcon: '🚀',
          giftPrice: 50000,
          multiplier: 1,
          senderPrevBalance: 170000,
          senderNewBalance: 120000,
          hostEarningAmount: 37500,
          hostPrevEarnings: 1737500,
          hostNewEarnings: 1775000,
          sourceType: 'GIFT',
          timestamp: '2026-08-15 05:32:45 UTC',
          liveRoomId: 'ROOM-401',
          status: 'COMPLETED',
          TEST_MODE: true
        }
      ]
    },
    liveHistory: [
      { id: 'LH-1', title: 'Sunset Cyberpunk Melodic Live', date: '2026-08-14', durationMinutes: 180, peakViewers: 12400, diamondsEarned: 95000, category: 'music' },
      { id: 'LH-2', title: 'Late Night Studio Jam & Remixes', date: '2026-08-13', durationMinutes: 210, peakViewers: 14800, diamondsEarned: 120000, category: 'music' }
    ],
    giftHistory: [
      { id: 'GH-1', giftName: 'Royal Dragon Palace', senderName: 'Aarav Mehta', coinsValue: 9999, diamondsReceived: 6999, time: '10 min ago' },
      { id: 'GH-2', giftName: 'Super Rocket 4K', senderName: 'VIP_Gamer99', coinsValue: 4999, diamondsReceived: 3499, time: '25 min ago' }
    ]
  },
  {
    id: 'HST-902',
    name: 'Kavita Roy',
    username: 'kavita_esports',
    agencyId: 'AG-02',
    agencyName: 'Nexus Talent Network',
    managerId: 'MGR-302',
    managerName: 'Jessica Chen',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 89000,
    giftsReceived: 19500,
    diamonds: 1240000,
    earningsUSD: 1240.00,
    totalLiveHours: 245,
    lastLive: '2026-08-15 05:40 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'gaming',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-402',
    bio: 'Professional FPS Champion & Grandmaster. Daily tournament commentary and viewer custom lobbies.',
    hostTag: 'TALENT',
    hostTypeId: 'HT-TALENT',
    avatarFrameId: 'FRM-HT-02',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150',
    hostLevel: 8,
    xp: 64200,
    earningsWallet: {
      totalEarnedCoins: 1240000,
      availableEarnings: 1240000,
      pendingEarnings: 0,
      giftEarnings: 980000,
      luckyGiftEarnings: 210000,
      redPacketEarnings: 50000,
      commissionRate: 70,
      history: []
    }
  },
  {
    id: 'HST-903',
    name: 'Devansh Kapoor',
    username: 'devansh_singer',
    agencyId: 'AG-01',
    agencyName: 'Starlight Media Global',
    managerId: 'MGR-301',
    managerName: 'Rahul Verma',
    status: 'Active',
    onlineStatus: 'Online',
    liveStatus: 'Live',
    followers: 210000,
    giftsReceived: 42000,
    diamonds: 2900000,
    earningsUSD: 2900.00,
    totalLiveHours: 410,
    lastLive: '2026-08-15 05:50 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    liveRoomId: 'ROOM-403',
    bio: 'Live acoustic sessions, vocal impressions, and Bollywood fusion vocalist.',
    hostTag: 'SINGER',
    hostTypeId: 'HT-SINGER',
    avatarFrameId: 'FRM-HT-03',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150',
    hostLevel: 10,
    xp: 145000,
    earningsWallet: {
      totalEarnedCoins: 2900000,
      availableEarnings: 2900000,
      pendingEarnings: 0,
      giftEarnings: 2400000,
      luckyGiftEarnings: 400000,
      redPacketEarnings: 100000,
      commissionRate: 70,
      history: []
    }
  },
  {
    id: 'HST-904',
    name: 'Meera Patel',
    username: 'meera_tech_space',
    agencyId: 'AG-02',
    agencyName: 'Nexus Talent Network',
    managerId: 'MGR-302',
    managerName: 'Jessica Chen',
    status: 'Active',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 67000,
    giftsReceived: 11200,
    diamonds: 780000,
    earningsUSD: 780.00,
    totalLiveHours: 180,
    lastLive: '2026-08-14 20:30 UTC',
    verificationStatus: 'Verified',
    streamCategory: 'tech',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    bio: 'Aerospace engineer exploring next-generation AI breakthroughs and space launches.',
    hostTag: 'NORMAL',
    hostTypeId: 'HT-NORMAL',
    avatarFrameId: 'FRM-HT-04',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150',
    hostLevel: 6,
    xp: 32000,
    earningsWallet: {
      totalEarnedCoins: 780000,
      availableEarnings: 780000,
      pendingEarnings: 0,
      giftEarnings: 620000,
      luckyGiftEarnings: 120000,
      redPacketEarnings: 40000,
      commissionRate: 65,
      history: []
    }
  },
  {
    id: 'HST-905',
    name: 'Rohan Joshi',
    username: 'rohan_acoustic',
    agencyId: '',
    agencyName: '',
    managerId: '',
    managerName: '',
    status: 'Pending',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 1200,
    giftsReceived: 80,
    diamonds: 4500,
    earningsUSD: 4.50,
    totalLiveHours: 12,
    lastLive: '2026-08-10 14:00 UTC',
    verificationStatus: 'Pending',
    streamCategory: 'music',
    avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&auto=format&fit=crop&q=80',
    bio: 'Acoustic indie guitarist and songwriter applying for official verified broadcaster status.',
    hostTag: 'SINGER',
    hostTypeId: 'HT-SINGER',
    avatarFrameId: 'FRM-HT-03',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150',
    hostLevel: 2,
    xp: 4500,
    earningsWallet: {
      totalEarnedCoins: 4500,
      availableEarnings: 4500,
      pendingEarnings: 0,
      giftEarnings: 4500,
      luckyGiftEarnings: 0,
      redPacketEarnings: 0,
      commissionRate: 70,
      history: []
    }
  },
  {
    id: 'HST-906',
    name: 'Zack Thorne',
    username: 'zack_shadow',
    agencyId: 'AG-04',
    agencyName: 'Solaris Entertainment',
    managerId: 'MGR-303',
    managerName: 'Carlos Fernandez',
    status: 'Banned',
    onlineStatus: 'Offline',
    liveStatus: 'Off-Air',
    followers: 15400,
    giftsReceived: 3200,
    diamonds: 180000,
    earningsUSD: 180.00,
    totalLiveHours: 65,
    lastLive: '2026-07-20 18:00 UTC',
    verificationStatus: 'Rejected',
    streamCategory: 'gaming',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    bio: 'Account permanently suspended due to repeated copyright infringement and TOS violation.',
    hostTag: 'TALENT',
    hostTypeId: 'HT-TALENT',
    avatarFrameId: 'FRM-HT-02',
    avatarFrameUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150',
    hostLevel: 4,
    xp: 18000,
    earningsWallet: {
      totalEarnedCoins: 180000,
      availableEarnings: 180000,
      pendingEarnings: 0,
      giftEarnings: 150000,
      luckyGiftEarnings: 30000,
      redPacketEarnings: 0,
      commissionRate: 70,
      history: []
    }
  }
];

export const INITIAL_USERS: UserAccount[] = [
  {
    id: 'USR-1001',
    name: 'Aarav Mehta',
    username: 'aarav_prime',
    email: 'aarav.m@gmail.com',
    vipLevel: 8,
    svipLevel: 2,
    userLevel: 42,
    role: 'USER',
    coinBalance: 5700000,
    diamondBalance: 286500,
    status: 'Active',
    joinedDate: '2025-01-20',
    lastActive: 'Just now',
    totalSpentCoins: 3500000,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'USR-1002',
    name: 'Ananya Gupta',
    username: 'ananya_queen',
    email: 'ananya.g@yahoo.com',
    vipLevel: 6,
    userLevel: 28,
    coinBalance: 120000,
    diamondBalance: 8500,
    status: 'Active',
    joinedDate: '2025-02-14',
    lastActive: '5 min ago',
    totalSpentCoins: 650000,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'USR-1003',
    name: 'Rishi Kapoor',
    username: 'rishi_vip',
    email: 'rishi.k@outlook.com',
    vipLevel: 4,
    userLevel: 35,
    coinBalance: 85000,
    diamondBalance: 12000,
    status: 'Active',
    joinedDate: '2025-03-22',
    lastActive: '15 min ago',
    totalSpentCoins: 890000,
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'USR-1004',
    name: 'Zoya Khan',
    username: 'zoya_live',
    email: 'zoya.khan@gmail.com',
    vipLevel: 7,
    userLevel: 39,
    coinBalance: 450000,
    diamondBalance: 35000,
    status: 'Active',
    joinedDate: '2025-02-10',
    lastActive: '25 min ago',
    totalSpentCoins: 2100000,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'USR-1005',
    name: 'David Miller',
    username: 'david_gamer',
    email: 'david.miller@gmail.com',
    vipLevel: 3,
    userLevel: 15,
    coinBalance: 15000,
    diamondBalance: 1200,
    status: 'Active',
    joinedDate: '2025-02-15',
    lastActive: '40 min ago',
    totalSpentCoins: 45000,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_LIVE_ROOMS: LiveRoomSession[] = [
  {
    id: 'ROOM-401',
    title: 'Electronic Sunset Beats & Synthwave 4K',
    hostId: 'HST-901',
    hostName: 'DJ Anya',
    hostAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    category: 'Music & DJ',
    viewersCount: 3840,
    diamondsEarned: 94200,
    startedAt: '2h 15m ago',
    resolution: '3840x2160 (4K UHD)',
    bitrate: '14.8 Mbps AV1',
    status: 'Active'
  },
  {
    id: 'ROOM-402',
    title: 'CyberStrike 2: World Pro Championship Finals',
    hostId: 'HST-902',
    hostName: 'Kavita Roy',
    hostAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    category: 'Gaming Esports',
    viewersCount: 8920,
    diamondsEarned: 145000,
    startedAt: '3h 40m ago',
    resolution: '1920x1080 (60FPS HDR)',
    bitrate: '9.2 Mbps',
    status: 'Active'
  },
  {
    id: 'ROOM-403',
    title: 'Premier Super Cup Derby Live Tactical Watchparty',
    hostId: 'HST-903',
    hostName: 'Devansh Kapoor',
    hostAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    category: 'Sports Live',
    viewersCount: 14200,
    diamondsEarned: 210000,
    startedAt: '1h 05m ago',
    resolution: '3840x2160 (4K UHD)',
    bitrate: '15.2 Mbps',
    status: 'Active'
  }
];

import { DEFAULT_GIFTS_CATALOG } from './platformFeaturesData';

export const INITIAL_GIFTS: GiftItem[] = [...DEFAULT_GIFTS_CATALOG];

export const INITIAL_TRANSACTIONS: WalletTransaction[] = [
  { id: 'TXN-9941', type: 'Deposit', userId: 'USR-8001', userName: 'Aarav Mehta', role: 'USER', amountCoins: 100000, amountDiamonds: 0, fiatAmountUSD: 100.00, paymentMethod: 'UPI / Razorpay', status: 'Completed', timestamp: '2026-08-15 05:30 UTC', notes: 'Coin Topup Pack #5' },
  { id: 'TXN-9942', type: 'Gift_Send', userId: 'USR-8001', userName: 'Aarav Mehta', role: 'USER', amountCoins: -9999, amountDiamonds: 7000, status: 'Completed', timestamp: '2026-08-15 05:35 UTC', notes: 'Sent Royal Dragon Palace to DJ Anya' },
  { id: 'TXN-9943', type: 'Payout', userId: 'HST-901', userName: 'DJ Anya', role: 'USER', amountCoins: 0, amountDiamonds: -500000, fiatAmountUSD: 500.00, paymentMethod: 'Bank Wire', status: 'Pending', timestamp: '2026-08-15 04:10 UTC', notes: 'Weekly earnings withdrawal' },
  { id: 'TXN-9944', type: 'Test_Transaction', userId: 'OWNER-001', userName: 'Owner Admin', role: 'OWNER', amountCoins: 50000, amountDiamonds: 25000, status: 'Completed', timestamp: '2026-08-15 02:00 UTC', notes: 'Owner Sandbox QA Liquidity test' },
  { id: 'TXN-9945', type: 'Admin_Adjustment', userId: 'USR-8002', userName: 'Ananya Gupta', role: 'USER', amountCoins: 2000, amountDiamonds: 0, status: 'Completed', timestamp: '2026-08-14 18:20 UTC', notes: 'Promotional loyalty VIP coin airdrop' }
];

export const INITIAL_VIP_TIERS: VipTierConfig[] = [
  { level: 1, title: 'Bronze Explorer', minCoinsSpent: 1000, monthlyCoinsRequired: 1000, storeDiscountPercent: 2, badgeColor: 'bg-amber-700/30 border-amber-600/40 text-amber-300', textColor: 'text-amber-300', perks: ['Bronze VIP Badge', 'Exclusive Chat Emoji Pack'], totalMembers: 1420 },
  { level: 2, title: 'Silver Knight', minCoinsSpent: 5000, monthlyCoinsRequired: 5000, storeDiscountPercent: 5, badgeColor: 'bg-slate-500/30 border-slate-400/40 text-slate-200', textColor: 'text-slate-200', perks: ['Silver Badge', 'Custom Chat Bubble', '1.05x Lucky Gift Boost'], totalMembers: 840 },
  { level: 3, title: 'Gold Champion', minCoinsSpent: 20000, monthlyCoinsRequired: 20000, storeDiscountPercent: 8, badgeColor: 'bg-yellow-500/30 border-yellow-400/40 text-yellow-300', textColor: 'text-yellow-300', perks: ['Gold Badge', 'Highlighted Username', 'Room Entrance Banner'], totalMembers: 420 },
  { level: 4, title: 'Platinum Elite', minCoinsSpent: 50000, monthlyCoinsRequired: 50000, storeDiscountPercent: 12, badgeColor: 'bg-cyan-500/30 border-cyan-400/40 text-cyan-300', textColor: 'text-cyan-300', perks: ['Platinum Frame', 'Dedicated Support', 'Direct Host DM'], totalMembers: 190 },
  { level: 5, title: 'Ruby Sovereign', minCoinsSpent: 150000, monthlyCoinsRequired: 150000, storeDiscountPercent: 15, badgeColor: 'bg-rose-500/30 border-rose-400/40 text-rose-300', textColor: 'text-rose-300', perks: ['Ruby Glow Aura', 'Kick Protection', 'Custom Entrance Sound'], totalMembers: 75 },
  { level: 6, title: 'Diamond Warlord', minCoinsSpent: 400000, monthlyCoinsRequired: 400000, storeDiscountPercent: 20, badgeColor: 'bg-sky-400/30 border-sky-300/40 text-sky-200', textColor: 'text-sky-200', perks: ['Diamond Avatar Ring', 'Fly-in Super Car Animation', 'VIP Room Creation'], totalMembers: 32 },
  { level: 7, title: 'Obsidian Overlord', minCoinsSpent: 800000, monthlyCoinsRequired: 800000, storeDiscountPercent: 25, badgeColor: 'bg-purple-600/30 border-purple-500/40 text-purple-200', textColor: 'text-purple-200', perks: ['Full Screen Entrance Notice', 'Custom 3D Gift Access', 'Zero Commission Fee'], totalMembers: 14 },
  { level: 8, title: 'Imperial Monarch', minCoinsSpent: 1500000, monthlyCoinsRequired: 1500000, storeDiscountPercent: 30, badgeColor: 'bg-amber-400/40 border-amber-300/60 text-amber-100', textColor: 'text-amber-100', perks: ['Global Server Announcement', 'Owner Concierge VIP Support', 'Exclusive 3D Avatar Halo', 'Permanent Seat at Grand VIP Table'], totalMembers: 5 }
];

export const INITIAL_GAMES: GameItem[] = CATALOG_17_GAMES.map((g) => ({
  id: g.id,
  name: g.name,
  category: g.category,
  status: "Active",
  isActive: true,
  rtpRate: g.rtpRate,
  minBet: g.minBet,
  maxBet: g.maxBet || 5000000,
  maxMultiplier: g.maxMultiplier,
  isHot: g.isHot,
  isNew: g.isNew,
  totalPlaysCount: g.totalPlays,
  totalPlayedSessions: g.totalPlays,
  poolCoins: 8500000,
  prizePoolCoins: 8500000,
  revenueCoins: 595000,
  revenueUSD: 595.0,
  icon: g.icon,
  banner: g.banner,
  description: g.description
}));

export const INITIAL_CASINO_TRANSACTIONS: CasinoTestTransaction[] = [
  {
    id: 'CTX-1001',
    userId: 'USR-8001',
    userName: 'Aarav Mehta',
    gameId: 'GM-01',
    gameName: 'OlympusSlot',
    category: 'Slots',
    betCoins: 500,
    multiplier: 4.5,
    payoutCoins: 2250,
    outcome: 'WIN',
    timestamp: '2026-08-15 05:42:10 UTC',
    rtpSetting: 96.5,
    isTestMode: true
  },
  {
    id: 'CTX-1002',
    userId: 'USR-8002',
    userName: 'Ananya Gupta',
    gameId: 'GM-09',
    gameName: 'DiceRolling',
    category: 'Dice',
    betCoins: 200,
    multiplier: 0,
    payoutCoins: 0,
    outcome: 'LOSS',
    timestamp: '2026-08-15 05:38:45 UTC',
    rtpSetting: 97.5,
    isTestMode: true
  },
  {
    id: 'CTX-1003',
    userId: 'USR-8001',
    userName: 'Aarav Mehta',
    gameId: 'GM-02',
    gameName: 'TeenPattiPro',
    category: 'Cards',
    betCoins: 1000,
    multiplier: 2.8,
    payoutCoins: 2800,
    outcome: 'WIN',
    timestamp: '2026-08-15 05:25:30 UTC',
    rtpSetting: 97.2,
    isTestMode: true
  },
  {
    id: 'CTX-1004',
    userId: 'USR-8003',
    userName: 'Rishi Kapoor',
    gameId: 'GM-17',
    gameName: 'Rocket',
    category: 'Crash',
    betCoins: 400,
    multiplier: 12.4,
    payoutCoins: 4960,
    outcome: 'WIN',
    timestamp: '2026-08-15 05:14:02 UTC',
    rtpSetting: 97.5,
    isTestMode: true
  },
  {
    id: 'CTX-1005',
    userId: 'USR-8002',
    userName: 'Ananya Gupta',
    gameId: 'GM-03',
    gameName: 'Lucky77Pro',
    category: 'Slots',
    betCoins: 300,
    multiplier: 0,
    payoutCoins: 0,
    outcome: 'LOSS',
    timestamp: '2026-08-15 04:55:18 UTC',
    rtpSetting: 96.8,
    isTestMode: true
  }
];

export const INITIAL_WITHDRAWALS: WithdrawalRequest[] = [
  { id: 'WTH-501', requesterId: 'HST-901', requesterName: 'DJ Anya', requesterRole: 'HOST', diamondsAmount: 500000, cashPayoutUSD: 500.00, payoutAmountUSD: 500.00, paymentMethod: 'Bank_Transfer', accountDetails: 'HDFC Bank - A/C 50100492819 - IFSC HDFC0001234', status: 'Pending', requestDate: '2026-08-15 04:10 UTC' },
  { id: 'WTH-502', requesterId: 'AG-01', requesterName: 'Starlight Media Global', requesterRole: 'AGENCY', diamondsAmount: 2000000, cashPayoutUSD: 2000.00, payoutAmountUSD: 2000.00, paymentMethod: 'USDT_TRC20', accountDetails: 'TXj49hKLms9102klmsd09123891klmsTRC20', status: 'Approved', requestDate: '2026-08-14 18:30 UTC', processedBy: 'Vikramaditya Rao (SA-1001)' },
  { id: 'WTH-503', requesterId: 'HST-902', requesterName: 'Kavita Roy', requesterRole: 'HOST', diamondsAmount: 300000, cashPayoutUSD: 300.00, payoutAmountUSD: 300.00, paymentMethod: 'UPI', accountDetails: 'kavita.roy@okaxis', status: 'Paid', requestDate: '2026-08-13 12:15 UTC', processedBy: 'Owner Admin', transactionHash: 'UPI-98421948120' }
];

export const INITIAL_REPORTS: ModerationReport[] = [
  { id: 'REP-701', reportedTargetId: 'USR-8004', reportedTargetName: 'TrollBot9000', reportedTargetType: 'User', reporterName: 'Aarav Mehta', reporterId: 'USR-8001', reason: 'Harassment', description: 'Continuous abusive messages and spamming during DJ Anya live performance.', status: 'Investigating', timestamp: '2026-08-15 05:10 UTC', internalNote: 'Assigned to Official Sarah for review' },
  { id: 'REP-702', reportedTargetId: 'HST-906', reportedTargetName: 'Zack Thorne', reportedTargetType: 'Host', reporterName: 'Priya Sharma (ADM-201)', reporterId: 'ADM-201', reason: 'Copyright', description: 'Unauthorized rebroadcast of private boxing pay-per-view feed.', status: 'Resolved', timestamp: '2026-08-14 16:40 UTC', internalNote: 'Stream terminated and warning issued.' }
];

export const INITIAL_NOTIFICATIONS: SystemNotification[] = [
  { id: 'NOTIF-01', title: 'DIYO LIVE 4K AV1 Broadcast Upgrade Complete', message: 'All ultra-low latency ingest nodes are upgraded to AV1 60FPS. Broadcasters enjoy 40% bandwidth savings.', targetAudience: 'All', type: 'Announcement', sentAt: '2026-08-15 00:00 UTC', status: 'Sent', reachCount: 420000 },
  { id: 'NOTIF-02', title: 'Weekend Mega Diamond Ranking Challenge', message: 'Top 3 hosts in diamonds received this weekend win 200,000 bonus coins + verified golden trophy badge.', targetAudience: 'Hosts', type: 'Reward', sentAt: '2026-08-14 12:00 UTC', status: 'Sent', reachCount: 240 }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  { id: 'LOG-8801', timestamp: '2026-08-15 05:45:12 UTC', actorId: 'OWNER-001', actorName: 'Owner Superuser', actorRole: 'OWNER', actionType: 'LOGIN', targetEntity: 'OWNER_PANEL', details: 'Owner logged in with biometric 2FA authentication', ipAddress: '103.21.44.12', status: 'SUCCESS' },
  { id: 'LOG-8802', timestamp: '2026-08-15 05:30:20 UTC', actorId: 'ADM-201', actorName: 'Vikramaditya Rao', actorRole: 'ADMIN', actionType: 'HOST_MANAGEMENT', targetEntity: 'USR-905 (Rohan Joshi)', details: 'Reviewed user verification application', ipAddress: '103.21.44.89', status: 'SUCCESS' },
  { id: 'LOG-8803', timestamp: '2026-08-15 05:15:00 UTC', actorId: 'ADM-201', actorName: 'Priya Sharma', actorRole: 'ADMIN', actionType: 'LIVE_MODERATION', targetEntity: 'ROOM-401', details: 'Muted user USR-8004 for 24h due to harassment report REP-701', ipAddress: '103.21.55.19', status: 'SUCCESS' },
  { id: 'LOG-8804', timestamp: '2026-08-15 04:50:33 UTC', actorId: 'MGR-301', actorName: 'Rahul Verma', actorRole: 'MANAGER', actionType: 'AGENCY_ASSIGNMENT', targetEntity: 'AG-01 & USR-901', details: 'Confirmed user roster renewal under Starlight Media Global', ipAddress: '103.21.60.22', status: 'SUCCESS' },
  { id: 'LOG-8805', timestamp: '2026-08-15 03:20:10 UTC', actorId: 'USR-902', actorName: 'Kavita Roy', actorRole: 'USER', actionType: 'SECURITY_BLOCKED', targetEntity: 'AGENCY_PANEL', details: 'Blocked attempt by User account to modify agency revenue split', ipAddress: '103.21.80.99', status: 'DENIED' },
  { id: 'LOG-8806', timestamp: '2026-08-14 23:10:44 UTC', actorId: 'OWNER-001', actorName: 'Owner Superuser', actorRole: 'OWNER', actionType: 'COIN_ADJUSTMENT', targetEntity: 'SYSTEM_TREASURY', details: 'Added 50,000 QA test liquidity coins to sandbox test wallet', ipAddress: '103.21.44.12', status: 'SUCCESS' }
];

export const INITIAL_PLATFORM_SETTINGS: PlatformSettings = {
  platformCommissionRate: 15,
  diamondToUSDRate: 10000,
  coinPriceUSD: 100,
  diamondRedemptionRateUSD: 200,
  minWithdrawalDiamonds: 50000,
  hostDefaultCommissionRate: 70,
  agencyDefaultCommissionRate: 15,
  defaultAgencyCommissionRate: 15,
  maintenanceMode: false,
  antiFraudAIEnabled: true,
  antiFraudEnabled: true,
  autoApproveHosts: false,
  allowMultiCamStreaming: true,
  maxTestTransactionAmount: 100000
};

export const INITIAL_COIN_SELLERS: CoinSellerAccount[] = [];

export const INITIAL_OWNER_TO_SELLER_TRANSACTIONS: OwnerToSellerTransaction[] = [];

export const INITIAL_SELLER_TO_USER_TRANSACTIONS: CoinSellerTransaction[] = [];

export const INITIAL_PARTY_LIVE_ROOM: PartyLiveRoomSession = {
  id: 'PARTY-2001',
  title: '🎉 DIYO LIVE Royal 20-Seat Lounge & Musical Party',
  ownerId: 'USR-882941',
  ownerName: 'Aarav Mehta (SR Creator)',
  ownerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  crownHolderId: 'USR-882941',
  crownHolderName: 'Aarav Mehta',
  crownTitle: '👑 SIR CROWN',
  totalSeats: 20,
  viewerCount: 2480,
  totalGiftsReceivedCoins: 890000,
  startedAt: '2026-08-15 04:00 UTC',
  status: 'Active',
  category: 'Music & Hangout',
  bgTheme: 'royal-purple',
  isTestRoom: false,
  isLive: true,
  seats: [
    { seatNumber: 1, userId: 'USR-882941', userName: 'Aarav Mehta', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80', isOwner: true, hasSirCrown: true, isMuted: false, isCameraOn: true, isMicOn: true, isLocked: false, vipLevel: 8, diamondsEarned: 45000, joinedAt: 'Room Start' },
    { seatNumber: 2, userId: 'USR-8002', userName: 'Meera Patel', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: true, isMicOn: true, isLocked: false, vipLevel: 6, diamondsEarned: 18000, joinedAt: '12m ago' },
    { seatNumber: 3, userId: 'HST-901', userName: 'Ananya Sharma', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80', isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: true, isLocked: false, vipLevel: 7, diamondsEarned: 32000, joinedAt: '25m ago' },
    { seatNumber: 4, userId: 'USR-8004', userName: 'David Miller', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', isOwner: false, hasSirCrown: false, isMuted: true, isCameraOn: false, isMicOn: false, isLocked: false, vipLevel: 4, diamondsEarned: 5200, joinedAt: '40m ago' },
    { seatNumber: 5, userId: 'HST-904', userName: 'Elena Rostova', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80', isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: true, isMicOn: true, isLocked: false, vipLevel: 5, diamondsEarned: 12400, joinedAt: '8m ago' },
    { seatNumber: 6, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 7, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 8, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 9, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 10, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 11, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 12, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 13, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 14, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 15, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 16, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 17, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 18, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 19, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false },
    { seatNumber: 20, isOwner: false, hasSirCrown: false, isMuted: false, isCameraOn: false, isMicOn: false, isLocked: false }
  ]
};

export const INITIAL_AVATAR_FRAMES: AvatarFrameItem[] = [
  { id: 'FRM-HT-01', name: 'Celebrate Host Frame', rarity: 'Royalty', previewUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150', coinPrice: 100000, vipLevelRequired: 1, activeUsersCount: 120, isAnimated: true },
  { id: 'FRM-HT-02', name: 'Talent Host Frame', rarity: 'Legendary', previewUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150', coinPrice: 80000, vipLevelRequired: 1, activeUsersCount: 240, isAnimated: true },
  { id: 'FRM-HT-03', name: 'Singer Host Frame', rarity: 'Epic', previewUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150', coinPrice: 60000, vipLevelRequired: 1, activeUsersCount: 310, isAnimated: true },
  { id: 'FRM-HT-04', name: 'Normal Host Frame', rarity: 'Rare', previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150', coinPrice: 30000, vipLevelRequired: 1, activeUsersCount: 890, isAnimated: true },
  { id: 'FRM-01', name: '👑 Imperial Gold Crown', rarity: 'Royalty', previewUrl: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=150', coinPrice: 50000, vipLevelRequired: 8, activeUsersCount: 1420, isAnimated: true },
  { id: 'FRM-02', name: '🔥 Blazing Dragon Fire', rarity: 'Legendary', previewUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=150', coinPrice: 25000, vipLevelRequired: 6, activeUsersCount: 3890, isAnimated: true },
  { id: 'FRM-03', name: '💎 Cyberpunk Neon Glow', rarity: 'Epic', previewUrl: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=150', coinPrice: 10000, vipLevelRequired: 4, activeUsersCount: 8200, isAnimated: false },
  { id: 'FRM-04', name: '🌸 Cherry Blossom Petals', rarity: 'Rare', previewUrl: 'https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?w=150', coinPrice: 5000, vipLevelRequired: 2, activeUsersCount: 15400, isAnimated: true },
  { id: 'FRM-05', name: '⭐ Classic Star Aura', rarity: 'Common', previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150', coinPrice: 1000, vipLevelRequired: 1, activeUsersCount: 34100, isAnimated: false }
];

export const INITIAL_PK_BATTLES: PkBattleItem[] = [
  {
    id: 'PK-501',
    host1Id: 'HST-901',
    host1Name: 'Ananya Sharma',
    host1Avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    host1Score: 482500,
    host2Id: 'HST-902',
    host2Name: 'Kavita Roy',
    host2Avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    host2Score: 412000,
    durationSeconds: 300,
    remainingSeconds: 84,
    status: 'Live',
    mvpGifterName: 'Aarav Mehta (👑 VIP 8)',
    startedAt: '4 mins ago'
  },
  {
    id: 'PK-502',
    host1Id: 'HST-903',
    host1Name: 'Liam O\'Connor',
    host1Avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
    host1Score: 620000,
    host2Id: 'HST-905',
    host2Name: 'Rohan Joshi',
    host2Avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    host2Score: 598000,
    durationSeconds: 300,
    remainingSeconds: 0,
    status: 'Ended',
    mvpGifterName: 'Starlight Royal VIP',
    startedAt: '15 mins ago'
  }
];

export const INITIAL_DASHBOARD_STATS: OwnerDashboardStats = {
  superAdminsCount: 1,
  adminsCount: 0,
  managersCount: 0,
  agenciesCount: 0,
  coinSellersCount: 0,
  hostsCount: 6,
  onlineHostsCount: 3,
  usersCount: 4,
  liveRoomsCount: 3,
  totalCoinsCirculation: 0,
  totalDiamondsMinted: 0,
  totalGiftsSent: 0,
  totalTestTransactions: 0,
  totalRevenueUSD: 0,
  pendingWithdrawalsUSD: 0,
  ownerTestCoinBalance: 500000000
};

// Aliases for MOCK_* exports used throughout the application
export const MOCK_OWNER_STATS = INITIAL_DASHBOARD_STATS;
export const MOCK_SUPER_ADMINS = INITIAL_SUPER_ADMINS;
export const MOCK_ADMINS = INITIAL_ADMINS;
export const MOCK_MANAGERS = INITIAL_MANAGERS;
export const MOCK_AGENCIES = INITIAL_AGENCIES;
export const MOCK_COIN_SELLERS = INITIAL_COIN_SELLERS;
export const MOCK_OWNER_TO_SELLER_TRANSACTIONS = INITIAL_OWNER_TO_SELLER_TRANSACTIONS;
export const MOCK_SELLER_TO_USER_TRANSACTIONS = INITIAL_SELLER_TO_USER_TRANSACTIONS;
export const MOCK_PARTY_LIVE_ROOM = INITIAL_PARTY_LIVE_ROOM;
export const MOCK_AVATAR_FRAMES = INITIAL_AVATAR_FRAMES;
export const MOCK_PK_BATTLES = INITIAL_PK_BATTLES;
export const MOCK_HOSTS = INITIAL_HOSTS;
export const MOCK_USERS = INITIAL_USERS;
export const MOCK_LIVE_ROOMS = INITIAL_LIVE_ROOMS;
export const MOCK_GIFTS = INITIAL_GIFTS;
export const MOCK_WALLET_TRANSACTIONS = INITIAL_TRANSACTIONS;
export const MOCK_VIP_CONFIGS = INITIAL_VIP_TIERS;
export const MOCK_GAMES = INITIAL_GAMES;
export const MOCK_WITHDRAWALS = INITIAL_WITHDRAWALS;
export const MOCK_REPORTS = INITIAL_REPORTS;
export const MOCK_NOTIFICATIONS = INITIAL_NOTIFICATIONS;
export const MOCK_AUDIT_LOGS = INITIAL_AUDIT_LOGS;
export const MOCK_CASINO_TRANSACTIONS = INITIAL_CASINO_TRANSACTIONS;
export const MOCK_PLATFORM_SETTINGS = INITIAL_PLATFORM_SETTINGS;
export const MOCK_HOST_TYPES = HOST_TYPE_DEFINITIONS;
