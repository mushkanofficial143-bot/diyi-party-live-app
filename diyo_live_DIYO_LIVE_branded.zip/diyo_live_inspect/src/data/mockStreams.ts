import { StreamChannel, ScheduledEvent, VideoHighlight, ChatMessage } from '../types';

export const INITIAL_STREAMS: StreamChannel[] = [];

export const MOCK_SCHEDULE: ScheduledEvent[] = [];

export const MOCK_HIGHLIGHTS: VideoHighlight[] = [];

export const CHAT_GENERATION_BANK: string[] = [
  "Hello everyone! Welcome to the stream! 🔥",
  "So amazing! Keep rocking! 💎",
  "Greetings from Nepal! 🇳🇵"
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    user: 'SR System',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
    badge: 'Mod',
    role: 'ADMIN',
    message: 'Welcome to DIYO LIVE! Please keep the chat respectful and supportive.',
    timestamp: 'Just now',
    type: 'system'
  }
];
