import { 
  GiftItem, 
  LuckyBoxConfig, 
  RedPacketSettings, 
  LevelSettings, 
  LevelConfigItem, 
  GameBetSettings,
  LuckyBoxItem,
  RedPacketItem
} from '../types/ownerTypes';

// ==========================================
// 1. VIRTUAL GIFTS CATALOG WITH ALL CATEGORIES
// Categories: ALL, FLAGS, POPULAR, VIP, SPECIAL, LUCKY, RED PACKET
// ==========================================
export const DEFAULT_GIFTS_CATALOG: GiftItem[] = [
  // FLAGS (10k TC Country Flag Gifts)
  {
    id: 'GFT-FLG-01',
    name: '🇮🇳 India Flag',
    icon: '🇮🇳',
    coinPrice: 10000,
    diamondValue: 7000,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'FLAGS',
    totalSent: 68000,
    isActive: true
  },
  {
    id: 'GFT-FLG-02',
    name: '🇳🇵 Nepal Flag',
    icon: '🇳🇵',
    coinPrice: 10000,
    diamondValue: 7000,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'FLAGS',
    totalSent: 42000,
    isActive: true
  },
  {
    id: 'GFT-FLG-03',
    name: '🇧🇩 Bangladesh Flag',
    icon: '🇧🇩',
    coinPrice: 10000,
    diamondValue: 7000,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'FLAGS',
    totalSent: 39000,
    isActive: true
  },
  {
    id: 'GFT-FLG-04',
    name: '🇵🇰 Pakistan Flag',
    icon: '🇵🇰',
    coinPrice: 10000,
    diamondValue: 7000,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'FLAGS',
    totalSent: 45000,
    isActive: true
  },
  {
    id: 'GFT-FLG-05',
    name: '🇵🇭 Philippines Flag',
    icon: '🇵🇭',
    coinPrice: 10000,
    diamondValue: 7000,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'FLAGS',
    totalSent: 31000,
    isActive: true
  },

  // POPULAR
  {
    id: 'GFT-POP-01',
    name: '🌹 Velvet Rose',
    icon: '🌹',
    coinPrice: 500,
    diamondValue: 350,
    isLucky: false,
    animationType: 'rain',
    category: 'POPULAR',
    totalSent: 125000,
    isActive: true
  },
  {
    id: 'GFT-POP-02',
    name: '💖 Heart Confetti',
    icon: '💖',
    coinPrice: 1000,
    diamondValue: 700,
    isLucky: false,
    animationType: 'confetti',
    category: 'POPULAR',
    totalSent: 89000,
    isActive: true
  },
  {
    id: 'GFT-POP-03',
    name: '🔥 Mega Flame Bomb',
    icon: '🔥',
    coinPrice: 2500,
    diamondValue: 1750,
    isLucky: false,
    animationType: 'pop',
    category: 'POPULAR',
    totalSent: 64000,
    isActive: true
  },
  {
    id: 'GFT-POP-04',
    name: '⭐ Superstar Starlet',
    icon: '⭐',
    coinPrice: 3000,
    diamondValue: 2100,
    isLucky: false,
    animationType: 'sparkle',
    category: 'POPULAR',
    totalSent: 45000,
    isActive: true
  },

  // VIP
  {
    id: 'GFT-VIP-01',
    name: '👑 Imperial Gold Crown',
    icon: '👑',
    coinPrice: 20000,
    diamondValue: 14000,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'VIP',
    totalSent: 14200,
    isActive: true
  },
  {
    id: 'GFT-VIP-02',
    name: '💎 Diamond Heart Scepter',
    icon: '💎',
    coinPrice: 50000,
    diamondValue: 35000,
    isLucky: false,
    animationType: 'sparkle',
    category: 'VIP',
    totalSent: 7800,
    isActive: true
  },
  {
    id: 'GFT-VIP-03',
    name: '🏰 Crystal Palace Throne',
    icon: '🏰',
    coinPrice: 100000,
    diamondValue: 70000,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'VIP',
    totalSent: 3400,
    isActive: true
  },

  // SPECIAL
  {
    id: 'GFT-SPC-01',
    name: '🚀 Space Galaxy Cruiser',
    icon: '🚀',
    coinPrice: 75000,
    diamondValue: 52500,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'SPECIAL',
    totalSent: 9200,
    isActive: true
  },
  {
    id: 'GFT-SPC-02',
    name: '🏎️ Neon Cyber Hypercar',
    icon: '🏎️',
    coinPrice: 150000,
    diamondValue: 105000,
    isLucky: false,
    animationType: 'fullscreen',
    category: 'SPECIAL',
    totalSent: 4100,
    isActive: true
  },
  {
    id: 'GFT-SPC-03',
    name: '🐉 Celestial Golden Dragon',
    icon: '🐉',
    coinPrice: 250000,
    diamondValue: 175000,
    isLucky: false,
    animationType: 'dragon',
    category: 'SPECIAL',
    totalSent: 1850,
    isActive: true
  },
  {
    id: 'GFT-SPC-04',
    name: '🎆 Grand Fireworks Festival',
    icon: '🎆',
    coinPrice: 30000,
    diamondValue: 21000,
    isLucky: false,
    animationType: 'fireworks',
    category: 'SPECIAL',
    totalSent: 22000,
    isActive: true
  },

  // LUCKY (Exact 7 denominations requested by Owner: 100, 200, 500, 1000, 2000, 5000, 10000)
  {
    id: 'GFT-LCK-100',
    name: '🌟 Lucky Sparkle Star (Up to 10X)',
    icon: '🌟',
    coinPrice: 100,
    diamondValue: 70,
    isLucky: true,
    luckyMultiplierMax: 10,
    animationType: 'sparkle',
    category: 'LUCKY',
    totalSent: 154000,
    isActive: true
  },
  {
    id: 'GFT-LCK-200',
    name: '🍀 Lucky Emerald Clover (Up to 20X)',
    icon: '🍀',
    coinPrice: 200,
    diamondValue: 140,
    isLucky: true,
    luckyMultiplierMax: 20,
    animationType: 'sparkle',
    category: 'LUCKY',
    totalSent: 128000,
    isActive: true
  },
  {
    id: 'GFT-LCK-500',
    name: '🔮 Mystical Fortune Orb (Up to 50X)',
    icon: '🔮',
    coinPrice: 500,
    diamondValue: 350,
    isLucky: true,
    luckyMultiplierMax: 50,
    animationType: 'pop',
    category: 'LUCKY',
    totalSent: 96000,
    isActive: true
  },
  {
    id: 'GFT-LCK-1000',
    name: '🧧 SR Golden Lucky Packet (Up to 100X)',
    icon: '🧧',
    coinPrice: 1000,
    diamondValue: 700,
    isLucky: true,
    luckyMultiplierMax: 100,
    animationType: 'pop',
    category: 'LUCKY',
    totalSent: 84000,
    isActive: true
  },
  {
    id: 'GFT-LCK-2000',
    name: '🎁 Royal Mystery Lucky Box (Up to 200X)',
    icon: '🎁',
    coinPrice: 2000,
    diamondValue: 1400,
    isLucky: true,
    isLuckyBox: true,
    luckyMultiplierMax: 200,
    animationType: 'pop',
    category: 'LUCKY',
    totalSent: 72000,
    isActive: true
  },
  {
    id: 'GFT-LCK-5000',
    name: '🎰 Grand Jackpot Lucky Wheel (Up to 300X)',
    icon: '🎰',
    coinPrice: 5000,
    diamondValue: 3500,
    isLucky: true,
    luckyMultiplierMax: 300,
    animationType: 'fullscreen',
    category: 'LUCKY',
    totalSent: 61000,
    isActive: true
  },
  {
    id: 'GFT-LCK-10000',
    name: '👑 Sovereign Lucky Treasure Chest (Up to 500X)',
    icon: '🏆',
    coinPrice: 10000,
    diamondValue: 7000,
    isLucky: true,
    isLuckyBox: true,
    luckyMultiplierMax: 500,
    animationType: 'fullscreen',
    category: 'LUCKY',
    totalSent: 45000,
    isActive: true
  },

  // RED PACKET
  {
    id: 'GFT-RED-01',
    name: '🧧 Royal Lucky Red Packet',
    icon: '🧧',
    coinPrice: 10000,
    diamondValue: 7000,
    isLucky: false,
    isRedPacket: true,
    animationType: 'confetti',
    category: 'RED PACKET',
    totalSent: 34000,
    isActive: true
  },
  {
    id: 'GFT-RED-02',
    name: '🧧 Multi-Receiver Wealth Packet',
    icon: '🧧',
    coinPrice: 50000,
    diamondValue: 35000,
    isLucky: false,
    isRedPacket: true,
    animationType: 'confetti',
    category: 'RED PACKET',
    totalSent: 16000,
    isActive: true
  },
  {
    id: 'GFT-RED-03',
    name: '🧧 Grand Celebration Super Envelope',
    icon: '🧧',
    coinPrice: 100000,
    diamondValue: 70000,
    isLucky: false,
    isRedPacket: true,
    animationType: 'fireworks',
    category: 'RED PACKET',
    totalSent: 8200,
    isActive: true
  }
];

// ==========================================
// 2. LUCKY BOX CONFIGURATION (10X, 20X, 30X, 50X, 100X)
// ==========================================
export const DEFAULT_LUCKY_BOX_CONFIG: LuckyBoxConfig = {
  enabled: true,
  basePriceCoins: 1000,
  multipliers: {
    '10X': true,
    '20X': true,
    '30X': true,
    '50X': true,
    '100X': true
  },
  rtpRate: 96.5
};

export const INITIAL_LUCKY_BOX_HISTORY: LuckyBoxItem[] = [
  {
    id: 'LB-9021',
    senderId: 'USR-8001',
    senderName: 'Aarav Mehta',
    receiverId: 'HST-901',
    receiverName: 'Ananya Sharma',
    multiplier: '100X',
    multiplierNumber: 100,
    costCoins: 100000,
    potentialMaxRewardCoins: 10000000,
    opened: true,
    wonRewardCoins: 4850000,
    createdAt: '10:15:20 AM',
    openedAt: '10:15:24 AM',
    TEST_MODE: true
  },
  {
    id: 'LB-9022',
    senderId: 'USR-8002',
    senderName: 'Meera Patel',
    receiverId: 'HST-904',
    receiverName: 'Elena Rostova',
    multiplier: '50X',
    multiplierNumber: 50,
    costCoins: 50000,
    potentialMaxRewardCoins: 2500000,
    opened: true,
    wonRewardCoins: 1850000,
    createdAt: '10:12:05 AM',
    openedAt: '10:12:10 AM',
    TEST_MODE: true
  },
  {
    id: 'LB-9023',
    senderId: 'USR-8004',
    senderName: 'David Miller',
    receiverId: 'USR-882941',
    receiverName: 'Aarav Mehta',
    multiplier: '20X',
    multiplierNumber: 20,
    costCoins: 20000,
    potentialMaxRewardCoins: 400000,
    opened: false,
    createdAt: '10:18:45 AM',
    TEST_MODE: true
  }
];

// ==========================================
// 3. RED PACKET CONFIGURATION
// ==========================================
export const DEFAULT_RED_PACKET_SETTINGS: RedPacketSettings = {
  enabled: true,
  minAmountCoins: 5000,
  maxAmountCoins: 1000000,
  minReceivers: 1,
  maxReceivers: 20,
  defaultExpiryMinutes: 30
};

export const INITIAL_RED_PACKETS: RedPacketItem[] = [
  {
    id: 'RP-7001',
    senderId: 'USR-882941',
    senderName: 'Aarav Mehta (Broadcaster)',
    senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    totalCoins: 50000,
    totalPackets: 5,
    remainingCoins: 18400,
    remainingPackets: 2,
    message: '🎉 Welcome to DIYO LIVE Test Mode! Enjoy Free Coins!',
    createdAt: '10:10:00 AM',
    expiresAt: '10:40:00 AM',
    isExpired: false,
    status: 'ACTIVE',
    TEST_MODE: true,
    claims: [
      {
        id: 'RPC-1',
        userId: 'USR-8002',
        userName: 'Meera Patel',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        amountCoins: 12400,
        claimedAt: '10:11:15 AM'
      },
      {
        id: 'RPC-2',
        userId: 'USR-8004',
        userName: 'David Miller',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        amountCoins: 9800,
        claimedAt: '10:12:00 AM'
      },
      {
        id: 'RPC-3',
        userId: 'HST-901',
        userName: 'Ananya Sharma',
        userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
        amountCoins: 9400,
        claimedAt: '10:13:40 AM'
      }
    ]
  },
  {
    id: 'RP-7002',
    senderId: 'USR-8002',
    senderName: 'Meera Patel',
    senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    totalCoins: 20000,
    totalPackets: 2,
    remainingCoins: 0,
    remainingPackets: 0,
    message: 'Good luck on the stream everyone! 🧧',
    createdAt: '09:45:00 AM',
    expiresAt: '10:15:00 AM',
    isExpired: false,
    status: 'COMPLETED',
    TEST_MODE: true,
    claims: [
      {
        id: 'RPC-4',
        userId: 'USR-882941',
        userName: 'Aarav Mehta',
        amountCoins: 11500,
        claimedAt: '09:46:10 AM'
      },
      {
        id: 'RPC-5',
        userId: 'HST-904',
        userName: 'Elena Rostova',
        amountCoins: 8500,
        claimedAt: '09:47:05 AM'
      }
    ]
  }
];

// ==========================================
// 4. LEVEL SYSTEM 1–100 GENERATOR & CONFIG
// ==========================================
function generate100Levels(): LevelConfigItem[] {
  const levels: LevelConfigItem[] = [];
  let cumXp = 0;

  for (let lvl = 1; lvl <= 100; lvl++) {
    // Smooth mathematical XP growth curve (Base ~1,000 XP at lvl 1, increasing with quadratic progression)
    const required = Math.round(1000 * Math.pow(lvl, 1.45));
    cumXp += required;

    let title = 'Novice Explorer';
    let badgeColor = 'from-amber-700 to-amber-900 text-amber-200 border-amber-600/50';
    let badgeIcon = '🌱';
    let borderStyle = 'border-amber-700';
    let perk = 'Basic Chat & Standard Reactions';

    if (lvl >= 96) {
      title = '👑 Imperial Grand Sovereign';
      badgeColor = 'from-yellow-400 via-amber-300 to-yellow-600 text-neutral-950 border-yellow-300';
      badgeIcon = '👑';
      borderStyle = 'border-yellow-400 shadow-yellow-500/50';
      perk = 'Global Hologram Avatar Ring, 2.0x EXP Boost & Supreme Host Seat';
    } else if (lvl >= 86) {
      title = '🌌 Divine Mythic Overlord';
      badgeColor = 'from-purple-600 via-pink-500 to-indigo-600 text-white border-purple-400';
      badgeIcon = '🌌';
      borderStyle = 'border-purple-500 shadow-purple-500/50';
      perk = 'Custom 3D Room Entrance Sound & Ultra Holographic Badge';
    } else if (lvl >= 71) {
      title = '⚔️ Grandmaster Warlord';
      badgeColor = 'from-rose-600 via-red-500 to-orange-600 text-white border-rose-400';
      badgeIcon = '⚔️';
      borderStyle = 'border-rose-500';
      perk = 'VIP Lounge Priority Speaker Access & 1.5x Virtual Gift Boost';
    } else if (lvl >= 56) {
      title = '💎 Diamond Vanguard';
      badgeColor = 'from-cyan-500 via-sky-400 to-blue-600 text-neutral-950 border-cyan-300';
      badgeIcon = '💎';
      borderStyle = 'border-cyan-400';
      perk = 'Exclusive Animated Diamond Chat Frame & Flying Car Entrance';
    } else if (lvl >= 41) {
      title = '🛡️ Platinum Paladin';
      badgeColor = 'from-slate-400 via-slate-200 to-neutral-400 text-neutral-950 border-slate-300';
      badgeIcon = '🛡️';
      borderStyle = 'border-slate-300';
      perk = 'Speaker Seat Priority & Customized Room Kick Immunity';
    } else if (lvl >= 26) {
      title = '🥇 Gold Champion';
      badgeColor = 'from-yellow-500 via-amber-500 to-yellow-600 text-neutral-950 border-yellow-400';
      badgeIcon = '🥇';
      borderStyle = 'border-yellow-400';
      perk = 'Golden Username Highlight & Audio Lounge Fast Pass';
    } else if (lvl >= 11) {
      title = '🥈 Silver Knight';
      badgeColor = 'from-neutral-400 via-neutral-300 to-slate-400 text-neutral-950 border-neutral-300';
      badgeIcon = '🥈';
      borderStyle = 'border-neutral-400';
      perk = 'Silver Flame Entrance Effect & Custom Bubble Colors';
    } else if (lvl >= 5) {
      title = '🥉 Bronze Pioneer';
      badgeColor = 'from-amber-600 via-amber-700 to-amber-800 text-amber-100 border-amber-500';
      badgeIcon = '🥉';
      borderStyle = 'border-amber-600';
      perk = 'Custom Chat Emoji Badge & Member Tag';
    }

    levels.push({
      level: lvl,
      requiredXp: required,
      cumulativeXp: cumXp,
      title,
      badgeColor,
      badgeIcon,
      borderStyle,
      perk,
      unlockedGiftsCount: Math.min(18, Math.floor(lvl / 5) + 3)
    });
  }

  return levels;
}

export const DEFAULT_LEVELS_CONFIG: LevelSettings = {
  maxLevel: 100,
  baseXpMultiplier: 1.0,
  growthRate: 1.45,
  xpPerCoinSpent: 0.1, // 1 XP per 10 TEST COINS spent
  levels: generate100Levels()
};

// ==========================================
// 5. GAME BET SETTINGS (10K, 50K, 100K)
// ==========================================
export const DEFAULT_GAME_BET_SETTINGS: GameBetSettings = {
  minBet: 10000,
  maxBet: 500000,
  allowedBetButtons: [10000, 50000, 100000], // 10K, 50K, 100K
  enforceButtonsOnly: true
};
