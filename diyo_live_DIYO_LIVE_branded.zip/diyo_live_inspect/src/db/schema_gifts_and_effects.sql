-- ==============================================================================
-- DIYO LIVE: gifts_and_effects SQL Table Schema & Seed Data
-- ==============================================================================

CREATE TABLE IF NOT EXISTS gifts_and_effects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category ENUM('gift', 'entrance_ride', 'frame', 'special_effect') DEFAULT 'gift',
    item_type VARCHAR(50) NOT NULL,       -- Example: 'car', 'motorbike', 'dragon', 'crown', 'rocket'
    price_coins INT NOT NULL DEFAULT 0,
    icon_url VARCHAR(500) NOT NULL,        -- PNG/WEBP thumbnail image
    svga_url VARCHAR(500) NOT NULL,        -- .svga animation file CDN link
    animation_duration INT DEFAULT 5,      -- Playback duration in seconds
    is_vip_only TINYINT(1) DEFAULT 0,      -- 1 = VIP Only, 0 = Normal
    status ENUM('active', 'inactive') DEFAULT 'active',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed Initial Data for Gifts, Entrance Rides, Frames, and Special Effects
INSERT INTO gifts_and_effects (name, category, item_type, price_coins, icon_url, svga_url, animation_duration, is_vip_only, status, sort_order) VALUES
('Super Sports Car', 'entrance_ride', 'car', 50000, 'https://cdn-icons-png.flaticon.com/512/741/741407.png', 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/car_ride.svga', 8, 1, 'active', 1),
('Golden Dragon', 'special_effect', 'dragon', 100000, 'https://cdn-icons-png.flaticon.com/512/3069/3069186.png', 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/dragon_effect.svga', 10, 1, 'active', 2),
('Royal Crown Frame', 'frame', 'crown', 20000, 'https://cdn-icons-png.flaticon.com/512/2539/2539824.png', 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/crown_frame.svga', 5, 0, 'active', 3),
('Diamond Rocket', 'gift', 'rocket', 10000, 'https://cdn-icons-png.flaticon.com/512/1356/1356479.png', 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/rocket.svga', 5, 0, 'active', 4),
('Luxury Yacht', 'entrance_ride', 'yacht', 80000, 'https://cdn-icons-png.flaticon.com/512/2933/2933116.png', 'https://cdn.jsdelivr.net/gh/svgaio/svgas@master/yacht_ride.svga', 8, 1, 'active', 5);
