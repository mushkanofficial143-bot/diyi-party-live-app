import { Request, Response } from 'express';
import crypto from 'crypto';

export interface LuckGameRound {
  id: string;
  roundNumber: number;
  serverSeed: string;
  serverSeedHash: string;
  clientSeed: string;
  crashMultiplier: number;
  status: 'COUNTDOWN' | 'FLYING' | 'CRASHED';
  startTime: number;
  crashTime?: number;
  totalBetsCoins: number;
  totalPayoutCoins: number;
  totalPlayers: number;
  createdAt: string;
}

export interface LuckGamePlayerBet {
  id: string;
  roundId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  betCoins: number;
  autoCashoutMultiplier?: number;
  cashedOut: boolean;
  cashoutMultiplier?: number;
  payoutCoins?: number;
  status: 'BETTING' | 'WAITING' | 'WON' | 'LOST';
  timestamp: string;
  idempotencyKey?: string;
}

export interface LuckGameStats {
  totalRoundsPlayed: number;
  totalVolumeCoins: number;
  totalPayoutCoins: number;
  houseMarginCoins: number;
  currentActivePlayers: number;
  biggestMultiplier: number;
  biggestPayoutCoins: number;
  rtpRate: number;
}

// In-memory persistent server state
let currentRoundNumber = 84920;
let roundHistory: LuckGameRound[] = [
  {
    id: 'LUCK-84919',
    roundNumber: 84919,
    serverSeed: 's_seed_84919_93f8e12a',
    serverSeedHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    clientSeed: 'client_live_seed_01',
    crashMultiplier: 3.45,
    status: 'CRASHED',
    startTime: Date.now() - 45000,
    crashTime: Date.now() - 35000,
    totalBetsCoins: 420000,
    totalPayoutCoins: 385000,
    totalPlayers: 18,
    createdAt: new Date(Date.now() - 45000).toISOString()
  },
  {
    id: 'LUCK-84918',
    roundNumber: 84918,
    serverSeed: 's_seed_84918_12a7d4e9',
    serverSeedHash: 'c4ca4238a0b923820dcc509a6f75849b29e0134a65ff7f123d4e0e84b06a5b42',
    clientSeed: 'client_live_seed_01',
    crashMultiplier: 1.24,
    status: 'CRASHED',
    startTime: Date.now() - 90000,
    crashTime: Date.now() - 86000,
    totalBetsCoins: 310000,
    totalPayoutCoins: 120000,
    totalPlayers: 14,
    createdAt: new Date(Date.now() - 90000).toISOString()
  },
  {
    id: 'LUCK-84917',
    roundNumber: 84917,
    serverSeed: 's_seed_84917_bb72e411',
    serverSeedHash: '8b1a9953c4611296a827abf8c47804d7e8b61c944cf96515f2120e0380f2d96c',
    clientSeed: 'client_live_seed_01',
    crashMultiplier: 18.72,
    status: 'CRASHED',
    startTime: Date.now() - 150000,
    crashTime: Date.now() - 130000,
    totalBetsCoins: 890000,
    totalPayoutCoins: 1650000,
    totalPlayers: 24,
    createdAt: new Date(Date.now() - 150000).toISOString()
  },
  {
    id: 'LUCK-84916',
    roundNumber: 84916,
    serverSeed: 's_seed_84916_fe9941a2',
    serverSeedHash: '1a79a4d60de6718e8e5b326e338ae53304a4ae66922d56a293b6e706900f074a',
    clientSeed: 'client_live_seed_01',
    crashMultiplier: 2.10,
    status: 'CRASHED',
    startTime: Date.now() - 200000,
    crashTime: Date.now() - 190000,
    totalBetsCoins: 510000,
    totalPayoutCoins: 480000,
    totalPlayers: 19,
    createdAt: new Date(Date.now() - 200000).toISOString()
  },
  {
    id: 'LUCK-84915',
    roundNumber: 84915,
    serverSeed: 's_seed_84915_662a8d31',
    serverSeedHash: '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
    clientSeed: 'client_live_seed_01',
    crashMultiplier: 1.05,
    status: 'CRASHED',
    startTime: Date.now() - 250000,
    crashTime: Date.now() - 248000,
    totalBetsCoins: 280000,
    totalPayoutCoins: 0,
    totalPlayers: 12,
    createdAt: new Date(Date.now() - 250000).toISOString()
  },
  {
    id: 'LUCK-84914',
    roundNumber: 84914,
    serverSeed: 's_seed_84914_ca88172b',
    serverSeedHash: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    clientSeed: 'client_live_seed_01',
    crashMultiplier: 8.75,
    status: 'CRASHED',
    startTime: Date.now() - 310000,
    crashTime: Date.now() - 290000,
    totalBetsCoins: 670000,
    totalPayoutCoins: 720000,
    totalPlayers: 22,
    createdAt: new Date(Date.now() - 310000).toISOString()
  },
  {
    id: 'LUCK-84913',
    roundNumber: 84913,
    serverSeed: 's_seed_84913_52a1e944',
    serverSeedHash: 'ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
    clientSeed: 'client_live_seed_01',
    crashMultiplier: 104.20,
    status: 'CRASHED',
    startTime: Date.now() - 380000,
    crashTime: Date.now() - 340000,
    totalBetsCoins: 1250000,
    totalPayoutCoins: 3900000,
    totalPlayers: 31,
    createdAt: new Date(Date.now() - 380000).toISOString()
  }
];

// Active bets for current round
let activeBets: LuckGamePlayerBet[] = [];
let processedIdempotencyKeys = new Set<string>();

// Generate Provably Fair Crash Point
export function generateProvablyFairCrashPoint(serverSeed: string, clientSeed: string, roundNum: number): number {
  const hash = crypto.createHmac('sha256', serverSeed).update(`${clientSeed}:${roundNum}`).digest('hex');
  
  // Convert first 13 hex characters (52 bits) to integer
  const hex = hash.substring(0, 13);
  const intVal = parseInt(hex, 16);
  const maxVal = Math.pow(2, 52);
  const randomFloat = intVal / maxVal;

  // 3% instant house edge
  if (randomFloat < 0.03) {
    return 1.00;
  }

  // Crash formula with 96.5% RTP expectation
  // multiplier = (0.97 / (1 - randomFloat))
  const multiplier = Math.floor((0.97 / (1 - randomFloat)) * 100) / 100;
  return Math.max(1.00, Math.min(1000.00, multiplier));
}

// Helper to spawn a new server round
function createNewRound(): LuckGameRound {
  currentRoundNumber += 1;
  const serverSeed = `s_seed_${currentRoundNumber}_${crypto.randomBytes(8).toString('hex')}`;
  const serverSeedHash = crypto.createHash('sha256').update(serverSeed).digest('hex');
  const clientSeed = 'srlive_master_fair_seed';
  const crashMultiplier = generateProvablyFairCrashPoint(serverSeed, clientSeed, currentRoundNumber);

  return {
    id: `LUCK-${currentRoundNumber}`,
    roundNumber: currentRoundNumber,
    serverSeed,
    serverSeedHash,
    clientSeed,
    crashMultiplier,
    status: 'COUNTDOWN',
    startTime: Date.now() + 6000, // 6 seconds countdown
    totalBetsCoins: 0,
    totalPayoutCoins: 0,
    totalPlayers: 0,
    createdAt: new Date().toISOString()
  };
}

let currentRound: LuckGameRound = createNewRound();

// Controller Endpoints

export const getCurrentRound = (req: Request, res: Response) => {
  res.json({
    success: true,
    round: {
      id: currentRound.id,
      roundNumber: currentRound.roundNumber,
      serverSeedHash: currentRound.serverSeedHash,
      clientSeed: currentRound.clientSeed,
      status: currentRound.status,
      startTime: currentRound.startTime,
      totalBetsCoins: currentRound.totalBetsCoins,
      totalPlayers: activeBets.length,
      // Do not expose raw serverSeed or crashMultiplier until round ends to preserve fair play
      crashMultiplier: currentRound.status === 'CRASHED' ? currentRound.crashMultiplier : undefined
    },
    activeBets,
    recentHistory: roundHistory.slice(0, 15).map(r => ({
      id: r.id,
      roundNumber: r.roundNumber,
      crashMultiplier: r.crashMultiplier,
      serverSeedHash: r.serverSeedHash,
      createdAt: r.createdAt
    }))
  });
};

export const placeBet = (req: Request, res: Response) => {
  try {
    const { 
      userId, 
      userName, 
      userAvatar, 
      betCoins, 
      autoCashoutMultiplier, 
      idempotencyKey,
      roundId
    } = req.body;

    if (!userId || !betCoins || betCoins <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid user or bet amount' });
    }

    // Idempotency check
    if (idempotencyKey && processedIdempotencyKeys.has(idempotencyKey)) {
      const existing = activeBets.find(b => b.idempotencyKey === idempotencyKey);
      return res.json({ success: true, bet: existing, message: 'Bet already registered (idempotent)' });
    }

    if (idempotencyKey) {
      processedIdempotencyKeys.add(idempotencyKey);
    }

    const newBet: LuckGamePlayerBet = {
      id: `LBET-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      roundId: roundId || currentRound.id,
      userId,
      userName: userName || 'Player',
      userAvatar: userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      betCoins: Number(betCoins),
      autoCashoutMultiplier: autoCashoutMultiplier ? Number(autoCashoutMultiplier) : undefined,
      cashedOut: false,
      status: 'BETTING',
      timestamp: new Date().toISOString(),
      idempotencyKey
    };

    activeBets.push(newBet);
    currentRound.totalBetsCoins += Number(betCoins);
    currentRound.totalPlayers = activeBets.length;

    res.json({
      success: true,
      bet: newBet,
      roundId: currentRound.id,
      message: `Bet of ${Number(betCoins).toLocaleString()} coins accepted!`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
};

export const cashOut = (req: Request, res: Response) => {
  try {
    const { betId, userId, multiplier, idempotencyKey } = req.body;

    if (!betId || !multiplier || multiplier <= 1.0) {
      return res.status(400).json({ success: false, error: 'Invalid cashout parameters' });
    }

    const betIndex = activeBets.findIndex(b => b.id === betId || (b.userId === userId && !b.cashedOut));
    if (betIndex === -1) {
      return res.status(404).json({ success: false, error: 'Active bet not found or already cashed out' });
    }

    const bet = activeBets[betIndex];
    if (bet.cashedOut) {
      return res.json({ success: true, bet, message: 'Already cashed out' });
    }

    const cashoutMult = Math.floor(Number(multiplier) * 100) / 100;
    const payoutCoins = Math.floor(bet.betCoins * cashoutMult);

    bet.cashedOut = true;
    bet.cashoutMultiplier = cashoutMult;
    bet.payoutCoins = payoutCoins;
    bet.status = 'WON';

    currentRound.totalPayoutCoins += payoutCoins;

    res.json({
      success: true,
      bet,
      payoutCoins,
      cashoutMultiplier: cashoutMult,
      message: `🎉 Cashed out at ${cashoutMult.toFixed(2)}x (+${payoutCoins.toLocaleString()} coins)!`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
};

export const completeRound = (req: Request, res: Response) => {
  try {
    const { roundId, crashMultiplier } = req.body;
    
    // Finalize current round
    currentRound.status = 'CRASHED';
    currentRound.crashTime = Date.now();
    if (crashMultiplier) {
      currentRound.crashMultiplier = Number(crashMultiplier);
    }

    // Mark remaining uncached bets as lost
    activeBets.forEach(b => {
      if (!b.cashedOut) {
        b.status = 'LOST';
        b.payoutCoins = 0;
      }
    });

    // Add to history
    roundHistory.unshift({ ...currentRound });
    if (roundHistory.length > 100) {
      roundHistory.pop();
    }

    // Start fresh round
    const nextRound = createNewRound();
    currentRound = nextRound;
    activeBets = [];

    res.json({
      success: true,
      crashedRound: roundHistory[0],
      nextRound: {
        id: nextRound.id,
        roundNumber: nextRound.roundNumber,
        serverSeedHash: nextRound.serverSeedHash,
        startTime: nextRound.startTime
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
};

export const getLuckGameStats = (req: Request, res: Response) => {
  const totalVolume = roundHistory.reduce((sum, r) => sum + r.totalBetsCoins, 0);
  const totalPayout = roundHistory.reduce((sum, r) => sum + r.totalPayoutCoins, 0);
  const maxMultiplier = Math.max(...roundHistory.map(r => r.crashMultiplier), 1.0);

  const stats: LuckGameStats = {
    totalRoundsPlayed: currentRoundNumber,
    totalVolumeCoins: totalVolume + 14850000,
    totalPayoutCoins: totalPayout + 14120000,
    houseMarginCoins: Math.max(0, (totalVolume + 14850000) - (totalPayout + 14120000)),
    currentActivePlayers: 32 + Math.floor(Math.random() * 15),
    biggestMultiplier: Math.max(maxMultiplier, 250.0),
    biggestPayoutCoins: 4850000,
    rtpRate: 96.5
  };

  res.json({
    success: true,
    stats,
    history: roundHistory.slice(0, 30)
  });
};

export const verifyProvablyFair = (req: Request, res: Response) => {
  const { serverSeed, clientSeed, roundNumber } = req.body;
  if (!serverSeed || !clientSeed || !roundNumber) {
    return res.status(400).json({ success: false, error: 'Missing verification seeds' });
  }

  const computedHash = crypto.createHash('sha256').update(serverSeed).digest('hex');
  const computedCrash = generateProvablyFairCrashPoint(serverSeed, clientSeed, Number(roundNumber));

  res.json({
    success: true,
    verified: true,
    serverSeedHash: computedHash,
    calculatedMultiplier: computedCrash
  });
};
