import { Request, Response } from 'express';

export interface LuckyBoxMultipliersConfig {
  '10X': boolean;
  '20X': boolean;
  '30X': boolean;
  '50X': boolean;
  '100X': boolean;
}

export interface LuckyBoxSettings {
  enabled: boolean;
  basePriceCoins: number;
  multipliers: LuckyBoxMultipliersConfig;
  rtpRate: number; // e.g. 96.5%
  minRewardRatio: number; // minimum win floor, e.g. 0.5x
  jackpotChance: number; // e.g. 0.05 (5%)
}

export interface LuckyBoxRecord {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  multiplier: '10X' | '20X' | '30X' | '50X' | '100X';
  multiplierNumber: number;
  costCoins: number;
  potentialMaxRewardCoins: number;
  opened: boolean;
  wonRewardCoins?: number;
  wonMultiplier?: number;
  createdAt: string;
  openedAt?: string;
  TEST_MODE: boolean;
}

export interface ServerUserRecord {
  id: string;
  name: string;
  username: string;
  coinBalance: number;
  diamondBalance: number;
  vipLevel: number;
  status: string;
  avatar?: string;
}

export interface LuckyBoxTransaction {
  id: string;
  type: 'LUCKY_BOX_SEND' | 'LUCKY_BOX_OPEN';
  userId: string;
  userName: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  amountCoins: number;
  amountDiamonds: number;
  previousBalance: number;
  newBalance: number;
  status: 'Completed' | 'Failed';
  timestamp: string;
  notes: string;
  TEST_MODE: true;
}

// In-Memory Engine State (Server Authoritative)
export let serverLuckyBoxSettings: LuckyBoxSettings = {
  enabled: true,
  basePriceCoins: 1000,
  multipliers: {
    '10X': true,
    '20X': true,
    '30X': true,
    '50X': true,
    '100X': true
  },
  rtpRate: 96.5,
  minRewardRatio: 0.5,
  jackpotChance: 0.05
};

export let serverLuckyBoxHistory: LuckyBoxRecord[] = [
  {
    id: 'LB-9021',
    senderId: 'USR-8001',
    senderName: 'Aarav Mehta',
    receiverId: 'HST-901',
    receiverName: 'Ananya Sharma',
    multiplier: '100X',
    multiplierNumber: 100,
    costCoins: 100000,
    potentialMaxRewardCoins: 10000000,
    opened: true,
    wonRewardCoins: 4850000,
    wonMultiplier: 48.5,
    createdAt: '10:15:20 AM',
    openedAt: '10:15:24 AM',
    TEST_MODE: true
  },
  {
    id: 'LB-9022',
    senderId: 'USR-8002',
    senderName: 'Meera Patel',
    receiverId: 'HST-904',
    receiverName: 'Elena Rostova',
    multiplier: '50X',
    multiplierNumber: 50,
    costCoins: 50000,
    potentialMaxRewardCoins: 2500000,
    opened: true,
    wonRewardCoins: 1850000,
    wonMultiplier: 37.0,
    createdAt: '10:12:05 AM',
    openedAt: '10:12:10 AM',
    TEST_MODE: true
  }
];

/**
 * Server-Side Random Win-Rate Calculation
 * Uses RTP rate, tier weighting, and configured multiplier bounds.
 */
export function calculateLuckyBoxReward(
  costCoins: number,
  multiplierNumber: number,
  rtpRate: number = 96.5
): { rewardCoins: number; wonMultiplier: number; tier: 'LOW' | 'MEDIUM' | 'HIGH' | 'JACKPOT' } {
  const rand = Math.random();
  let rewardRatio = 0.5;
  let tier: 'LOW' | 'MEDIUM' | 'HIGH' | 'JACKPOT' = 'LOW';

  // Tier 1: Small return (0.5x - 1.2x of box cost) -> ~40% probability
  if (rand < 0.40) {
    rewardRatio = 0.5 + Math.random() * 0.7; // 0.5x - 1.2x
    tier = 'LOW';
  } 
  // Tier 2: Medium return (1.2x to 35% of max multiplier) -> ~35% probability
  else if (rand < 0.75) {
    const minTier = 1.2;
    const maxTier = Math.max(1.5, multiplierNumber * 0.35);
    rewardRatio = minTier + Math.random() * (maxTier - minTier);
    tier = 'MEDIUM';
  } 
  // Tier 3: High return (35% to 75% of max multiplier) -> ~20% probability
  else if (rand < 0.95) {
    const minTier = Math.max(2.0, multiplierNumber * 0.35);
    const maxTier = Math.max(minTier + 1.0, multiplierNumber * 0.75);
    rewardRatio = minTier + Math.random() * (maxTier - minTier);
    tier = 'HIGH';
  } 
  // Tier 4: Grand Jackpot (75% to 100% of max multiplier) -> ~5% probability
  else {
    const minTier = Math.max(3.0, multiplierNumber * 0.75);
    const maxTier = multiplierNumber;
    rewardRatio = minTier + Math.random() * (maxTier - minTier);
    tier = 'JACKPOT';
  }

  // Adjust mathematically against configured RTP rate scale (base 100)
  const rtpMultiplier = (rtpRate / 100);
  const adjustedRatio = Number((rewardRatio * rtpMultiplier).toFixed(2));
  const finalRatio = Math.max(0.5, adjustedRatio);
  const rewardCoins = Math.max(100, Math.floor(costCoins * finalRatio));

  return {
    rewardCoins,
    wonMultiplier: finalRatio,
    tier
  };
}

/**
 * Controller: GET /api/lucky-box/settings
 * Returns current platform settings and recent Lucky Box history
 */
export const getLuckyBoxSettings = (req: Request, res: Response): void => {
  res.json({
    success: true,
    settings: serverLuckyBoxSettings,
    history: serverLuckyBoxHistory.slice(0, 50)
  });
};

/**
 * Controller: POST /api/lucky-box/settings
 * Updates Owner platform settings (ON/OFF toggles, multipliers, RTP)
 */
export const updateLuckyBoxSettings = (req: Request, res: Response): void => {
  try {
    const { enabled, basePriceCoins, multipliers, rtpRate, minRewardRatio, jackpotChance } = req.body;

    if (enabled !== undefined) {
      serverLuckyBoxSettings.enabled = Boolean(enabled);
    }
    if (basePriceCoins !== undefined && !isNaN(Number(basePriceCoins))) {
      serverLuckyBoxSettings.basePriceCoins = Math.max(100, Number(basePriceCoins));
    }
    if (multipliers && typeof multipliers === 'object') {
      serverLuckyBoxSettings.multipliers = {
        ...serverLuckyBoxSettings.multipliers,
        ...multipliers
      };
    }
    if (rtpRate !== undefined && !isNaN(Number(rtpRate))) {
      serverLuckyBoxSettings.rtpRate = Math.min(99.9, Math.max(80.0, Number(rtpRate)));
    }
    if (minRewardRatio !== undefined && !isNaN(Number(minRewardRatio))) {
      serverLuckyBoxSettings.minRewardRatio = Math.max(0.1, Number(minRewardRatio));
    }
    if (jackpotChance !== undefined && !isNaN(Number(jackpotChance))) {
      serverLuckyBoxSettings.jackpotChance = Math.min(0.5, Math.max(0.01, Number(jackpotChance)));
    }

    res.json({
      success: true,
      message: 'Lucky Box platform settings updated successfully by Owner.',
      settings: serverLuckyBoxSettings
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err.message || 'Internal Server Error while updating Lucky Box settings.'
    });
  }
};

/**
 * Controller: POST /api/lucky-box/send
 * Handles sender verification, atomic balance deduction, and box creation
 */
export const sendLuckyBox = (
  req: Request,
  res: Response,
  usersDb: Record<string, ServerUserRecord>,
  transactionsDb: any[]
): void => {
  try {
    const { senderId, receiverId, multiplier = '10X', baseCost = 1000 } = req.body;

    // 1. Verify Platform Setting: Lucky Box Enabled
    if (!serverLuckyBoxSettings.enabled) {
      res.status(403).json({
        success: false,
        error: 'Lucky Box feature is currently disabled by Owner in platform settings.'
      });
      return;
    }

    // 2. Validate Multiplier Option
    const multKey = String(multiplier).toUpperCase() as keyof LuckyBoxMultipliersConfig;
    const allowedMultipliers: (keyof LuckyBoxMultipliersConfig)[] = ['10X', '20X', '30X', '50X', '100X'];

    if (!allowedMultipliers.includes(multKey)) {
      res.status(400).json({
        success: false,
        error: `Invalid multiplier "${multiplier}". Allowed options: 10X, 20X, 30X, 50X, 100X.`
      });
      return;
    }

    if (!serverLuckyBoxSettings.multipliers[multKey]) {
      res.status(400).json({
        success: false,
        error: `Lucky Box ${multKey} multiplier is currently disabled by Owner.`
      });
      return;
    }

    const multiplierNum = parseInt(multKey.replace('X', ''), 10) || 10;
    const unitCost = Number(baseCost) > 0 ? Number(baseCost) : serverLuckyBoxSettings.basePriceCoins;
    const totalCost = unitCost * multiplierNum;

    // 3. Find or bootstrap sender record
    let sender = usersDb[senderId];
    if (!sender) {
      sender = {
        id: senderId || 'USR-DEFAULT',
        name: `User ${senderId || 'Guest'}`,
        username: `user_${String(senderId || 'guest').toLowerCase().replace(/[^a-z0-9]/g, '')}`,
        coinBalance: 500000,
        diamondBalance: 0,
        vipLevel: 1,
        status: 'Active',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
      };
      usersDb[sender.id] = sender;
    }

    // 4. Server-Side Atomic Balance Check
    if (sender.coinBalance < totalCost) {
      res.status(400).json({
        success: false,
        error: `Insufficient TEST COINS balance! Required: ${(totalCost ?? 0).toLocaleString()} TEST COINS, Available: ${((sender?.coinBalance) ?? 0).toLocaleString()} TEST COINS.`
      });
      return;
    }

    // 5. Find or bootstrap receiver record
    const targetReceiverId = receiverId || 'HST-901';
    let receiver = usersDb[targetReceiverId];
    if (!receiver) {
      receiver = {
        id: targetReceiverId,
        name: `User ${targetReceiverId}`,
        username: `user_${String(targetReceiverId).toLowerCase().replace(/[^a-z0-9]/g, '')}`,
        coinBalance: 0,
        diamondBalance: 0,
        vipLevel: 1,
        status: 'Active',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
      };
      usersDb[targetReceiverId] = receiver;
    }

    // 6. Atomic Debit on Sender Balance
    const prevSenderBalance = sender.coinBalance;
    sender.coinBalance = prevSenderBalance - totalCost;

    const boxId = `LB-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const potentialMaxReward = totalCost * multiplierNum;

    // 7. Create Authoritative Server Record
    const newBox: LuckyBoxRecord = {
      id: boxId,
      senderId: sender.id,
      senderName: sender.name,
      receiverId: receiver.id,
      receiverName: receiver.name,
      multiplier: multKey,
      multiplierNumber: multiplierNum,
      costCoins: totalCost,
      potentialMaxRewardCoins: potentialMaxReward,
      opened: false,
      createdAt: timestamp,
      TEST_MODE: true
    };

    serverLuckyBoxHistory.unshift(newBox);
    if (serverLuckyBoxHistory.length > 200) {
      serverLuckyBoxHistory.pop();
    }

    // 8. Atomic Transaction Logging
    const tx: LuckyBoxTransaction = {
      id: `TX-${boxId}-SEND`,
      type: 'LUCKY_BOX_SEND',
      userId: sender.id,
      userName: sender.name,
      senderId: sender.id,
      senderName: sender.name,
      receiverId: receiver.id,
      receiverName: receiver.name,
      amountCoins: -totalCost,
      amountDiamonds: 0,
      previousBalance: prevSenderBalance,
      newBalance: sender.coinBalance,
      status: 'Completed',
      timestamp: `${new Date().toISOString().split('T')[0]} ${timestamp}`,
      notes: `Sent Lucky Box ${multKey} to ${receiver.name} (Cost: ${(totalCost ?? 0).toLocaleString()} TEST COINS)`,
      TEST_MODE: true
    };
    transactionsDb.unshift(tx);

    res.json({
      success: true,
      message: `🎁 Sent Lucky Box ${multKey} to ${receiver.name}!`,
      luckyBox: newBox,
      senderBalance: sender.coinBalance
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err.message || 'Internal Server Error processing Lucky Box send.'
    });
  }
};

/**
 * Controller: POST /api/lucky-box/open
 * Handles receiver unboxing, server win-rate RNG calculation, and atomic balance credit
 */
export const openLuckyBox = (
  req: Request,
  res: Response,
  usersDb: Record<string, ServerUserRecord>,
  transactionsDb: any[]
): void => {
  try {
    const { boxId, receiverId } = req.body;

    // 1. Verify Platform Setting: Lucky Box Enabled
    if (!serverLuckyBoxSettings.enabled) {
      res.status(403).json({
        success: false,
        error: 'Lucky Box feature is currently disabled by Owner.'
      });
      return;
    }

    // 2. Validate Box Existence
    const box = serverLuckyBoxHistory.find((b) => b.id === boxId);
    if (!box) {
      res.status(404).json({
        success: false,
        error: `Lucky Box "${boxId}" not found.`
      });
      return;
    }

    // 3. Prevent Double Opening
    if (box.opened) {
      res.status(400).json({
        success: false,
        error: 'This Lucky Box has already been opened.',
        wonRewardCoins: box.wonRewardCoins,
        wonMultiplier: box.wonMultiplier
      });
      return;
    }

    // 4. Server-Side Random Win-Rate Calculation
    const multiplierNum = box.multiplierNumber || 10;
    const { rewardCoins, wonMultiplier, tier } = calculateLuckyBoxReward(
      box.costCoins,
      multiplierNum,
      serverLuckyBoxSettings.rtpRate
    );

    // 5. Find or bootstrap receiver record
    const targetUserId = receiverId || box.receiverId;
    let receiver = usersDb[targetUserId];
    if (!receiver) {
      receiver = {
        id: targetUserId,
        name: box.receiverName || `User ${targetUserId}`,
        username: `user_${String(targetUserId).toLowerCase().replace(/[^a-z0-9]/g, '')}`,
        coinBalance: 0,
        diamondBalance: 0,
        vipLevel: 1,
        status: 'Active',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
      };
      usersDb[targetUserId] = receiver;
    }

    // 6. Atomic Balance Credit on Receiver
    const prevReceiverBalance = receiver.coinBalance;
    receiver.coinBalance = prevReceiverBalance + rewardCoins;

    // 7. Update Server Record
    const openTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    box.opened = true;
    box.wonRewardCoins = rewardCoins;
    box.wonMultiplier = wonMultiplier;
    box.openedAt = openTimestamp;

    // 8. Atomic Transaction Logging
    const rewardTx: LuckyBoxTransaction = {
      id: `TX-${box.id}-REWARD`,
      type: 'LUCKY_BOX_OPEN',
      userId: receiver.id,
      userName: receiver.name,
      senderId: box.senderId,
      senderName: box.senderName,
      receiverId: receiver.id,
      receiverName: receiver.name,
      amountCoins: rewardCoins,
      amountDiamonds: 0,
      previousBalance: prevReceiverBalance,
      newBalance: receiver.coinBalance,
      status: 'Completed',
      timestamp: `${new Date().toISOString().split('T')[0]} ${openTimestamp}`,
      notes: `Opened Lucky Box ${box.multiplier} (${tier} Win): Won ${(rewardCoins ?? 0).toLocaleString()} TEST COINS!`,
      TEST_MODE: true
    };
    transactionsDb.unshift(rewardTx);

    res.json({
      success: true,
      message: `🎉 Unboxed Lucky Box ${box.multiplier}! Won ${(rewardCoins ?? 0).toLocaleString()} TEST COINS (${wonMultiplier}x)!`,
      boxId: box.id,
      wonRewardCoins: rewardCoins,
      wonMultiplier,
      tier,
      receiverBalance: receiver.coinBalance,
      luckyBox: box
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err.message || 'Internal Server Error processing Lucky Box unboxing.'
    });
  }
};
