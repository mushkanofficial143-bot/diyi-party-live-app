import { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';

const STORE_PATH = path.join(process.cwd(), 'data', 'wallet_store.json');

interface UserWalletData {
  userId: string;
  coinBalance: number;
  diamondBalance: number;
  updatedAt: string;
}

interface WalletTxRecord {
  id: string;
  userId: string;
  previousBalance: number;
  winAmount: number;
  finalBalance: number;
  source: 'Game' | 'Lucky Me' | 'Gift' | 'Deposit' | 'Withdraw';
  description: string;
  timestamp: string;
}

interface StoreSchema {
  wallets: Record<string, UserWalletData>;
  transactions: WalletTxRecord[];
}

function loadStore(): StoreSchema {
  try {
    if (fs.existsSync(STORE_PATH)) {
      const content = fs.readFileSync(STORE_PATH, 'utf-8');
      return JSON.parse(content);
    }
  } catch (e) {
    console.error('Error loading wallet store:', e);
  }
  return { wallets: {}, transactions: [] };
}

function saveStore(store: StoreSchema) {
  try {
    const dir = path.dirname(STORE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error saving wallet store:', e);
  }
}

export const getWalletData = (req: Request, res: Response) => {
  const userId = req.params.userId || 'USR-3456789';
  const store = loadStore();

  let wallet = store.wallets[userId];
  if (!wallet) {
    wallet = {
      userId,
      coinBalance: 5700000,
      diamondBalance: 286500,
      updatedAt: new Date().toISOString()
    };
    store.wallets[userId] = wallet;
    saveStore(store);
  }

  const userTxs = store.transactions.filter(t => t.userId === userId);

  return res.json({
    success: true,
    wallet,
    transactions: userTxs
  });
};

export const updateWalletBalance = (req: Request, res: Response) => {
  const { userId = 'USR-3456789', coinDelta = 0, diamondDelta = 0, source = 'Game', description = 'Game Win Reward' } = req.body;
  
  const store = loadStore();
  let wallet = store.wallets[userId];
  if (!wallet) {
    wallet = {
      userId,
      coinBalance: 5700000,
      diamondBalance: 286500,
      updatedAt: new Date().toISOString()
    };
  }

  const previousBalance = wallet.coinBalance;
  const finalBalance = Math.max(0, previousBalance + coinDelta);
  
  wallet.coinBalance = finalBalance;
  wallet.diamondBalance = Math.max(0, wallet.diamondBalance + diamondDelta);
  wallet.updatedAt = new Date().toISOString();
  store.wallets[userId] = wallet;

  const txId = `TXN-${Date.now()}-${Math.floor(Math.random() * 90000 + 10000)}`;
  const txRecord: WalletTxRecord = {
    id: txId,
    userId,
    previousBalance,
    winAmount: coinDelta,
    finalBalance,
    source,
    description,
    timestamp: new Date().toISOString()
  };

  store.transactions.unshift(txRecord);
  saveStore(store);

  return res.json({
    success: true,
    previousBalance,
    finalBalance,
    transaction: txRecord,
    wallet
  });
};
