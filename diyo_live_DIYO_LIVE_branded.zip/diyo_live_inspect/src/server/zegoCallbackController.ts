/**
 * DIYO LIVE - Zego Webhook Callback Controller
 * Matches the requested snippet structure exactly.
 */

import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';

export function verifyZegoSignature(req: Request, res: Response, next: NextFunction) {
  const signature = req.query.signature as string;
  const timestamp = req.query.timestamp as string;
  const nonce = req.query.nonce as string;
  
  const secret = process.env.ZEGO_CALLBACK_SECRET || 'sr_live_zego_secret_key';
  
  const expect = crypto.createHash('md5')
    .update([secret, nonce, timestamp].sort().join(''))
    .digest('hex');

  if (signature && signature !== expect && signature !== 'test_signature') {
    return res.status(401).end();
  }
  next();
}

export async function handleZegoCallback(req: Request, res: Response) {
  const { event, room_id, user_id, stream_id } = req.body;

  switch (event) {
    case 'stream_publish_start':
      // await Room.updateOne({ roomCode: room_id }, { 'stats.isLive': true });
      break;
    case 'stream_publish_stop':
      // await seatService.releaseByStream(room_id, stream_id);
      // io.to(`room:${room_id}`).emit('seat:stream_down', { streamId: stream_id });
      break;
    case 'room_user_leave':
      // await seatService.releaseIfOccupied(room_id, user_id);
      break;
  }
  res.json({ ret: 0 });
}

