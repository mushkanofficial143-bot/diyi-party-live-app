/**
 * DIYO LIVE - Android APK Live Streaming & Hardware Media Engine
 * Robust Camera, Microphone, WebRTC, Lifecycle, Reconnection, and Android WebView compatibility layer.
 */

export interface MediaDeviceInfo {
  hasCamera: boolean;
  hasMicrophone: boolean;
  cameraPermission: 'granted' | 'denied' | 'prompt' | 'unknown';
  micPermission: 'granted' | 'denied' | 'prompt' | 'unknown';
  facingMode: 'user' | 'environment';
  isAndroid: boolean;
  isWebView: boolean;
}

export interface StreamStats {
  resolution: string;
  fps: number;
  audioBitrateKbps: number;
  videoBitrateKbps: number;
  packetLossPercent: number;
  networkLatencyMs: number;
  connectionState: 'connected' | 'reconnecting' | 'disconnected' | 'failed';
}

export class AndroidLiveStreamService {
  private static instance: AndroidLiveStreamService | null = null;
  private currentStream: MediaStream | null = null;
  private wakeLock: any = null;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private isMuted: boolean = false;
  private isVideoEnabled: boolean = true;
  private currentFacing: 'user' | 'environment' = 'user';

  private constructor() {
    this.setupNetworkListeners();
    this.setupLifecycleListeners();
  }

  public static getInstance(): AndroidLiveStreamService {
    if (!AndroidLiveStreamService.instance) {
      AndroidLiveStreamService.instance = new AndroidLiveStreamService();
    }
    return AndroidLiveStreamService.instance;
  }

  /**
   * Detect Android OS and Android WebView environment
   */
  public isAndroid(): boolean {
    if (typeof navigator === 'undefined') return false;
    const ua = navigator.userAgent || '';
    return /android/i.test(ua);
  }

  public isWebView(): boolean {
    if (typeof navigator === 'undefined' || typeof window === 'undefined') return false;
    const ua = navigator.userAgent || '';
    const isCapacitor = Boolean((window as any).Capacitor);
    const isAndroidWebview = /wv|Android.*Version\/[0-9.]+/i.test(ua);
    return isCapacitor || isAndroidWebview;
  }

  /**
   * Check permissions status where supported
   */
  public async checkPermissions(): Promise<{ camera: 'granted' | 'denied' | 'prompt' | 'unknown'; mic: 'granted' | 'denied' | 'prompt' | 'unknown' }> {
    const result = {
      camera: 'unknown' as 'granted' | 'denied' | 'prompt' | 'unknown',
      mic: 'unknown' as 'granted' | 'denied' | 'prompt' | 'unknown'
    };

    if (typeof navigator === 'undefined' || !navigator.permissions) {
      return result;
    }

    try {
      const camPermission = await navigator.permissions.query({ name: 'camera' as any });
      if (camPermission) result.camera = camPermission.state;
    } catch {
      // Not supported in some WebViews
    }

    try {
      const micPermission = await navigator.permissions.query({ name: 'microphone' as any });
      if (micPermission) result.mic = micPermission.state;
    } catch {
      // Not supported in some WebViews
    }

    return result;
  }

  /**
   * Acquire Camera & Microphone stream with multi-tiered fallback for Android hardware
   */
  public async startLiveStream(facing: 'user' | 'environment' = 'user'): Promise<{
    success: boolean;
    stream: MediaStream | null;
    errorType?: 'PERMISSION_DENIED' | 'NOT_FOUND' | 'HARDWARE_BUSY' | 'OVERCONSTRAINED' | 'UNKNOWN';
    errorMessage?: string;
    isAudioOnly?: boolean;
    isVideoOnly?: boolean;
  }> {
    this.currentFacing = facing;

    // Release existing tracks
    this.stopCurrentStream(false);

    if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return {
        success: false,
        stream: null,
        errorType: 'NOT_FOUND',
        errorMessage: 'MediaDevices API is not supported in this browser or Android WebView.'
      };
    }

    // Tier 1: Optimal Mobile Portrait HD (1080x1920 or 720x1280)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facing,
          width: { ideal: 1080, max: 1920 },
          height: { ideal: 1920, max: 1920 },
          frameRate: { ideal: 30, max: 60 }
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      this.currentStream = stream;
      this.acquireWakeLock();
      return { success: true, stream };
    } catch (tier1Err: any) {
      console.warn('[SR-LIVE-MEDIA] Tier 1 HD constraints failed, trying Tier 2 balanced Android constraints...', tier1Err);
    }

    // Tier 2: Balanced Android 720p constraints
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facing,
          width: { ideal: 720 },
          height: { ideal: 1280 },
          frameRate: { ideal: 30 }
        },
        audio: true
      });

      this.currentStream = stream;
      this.acquireWakeLock();
      return { success: true, stream };
    } catch (tier2Err: any) {
      console.warn('[SR-LIVE-MEDIA] Tier 2 constraints failed, trying Tier 3 unconstrained...', tier2Err);
    }

    // Tier 3: Basic unconstrained video + audio
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing },
        audio: true
      });

      this.currentStream = stream;
      this.acquireWakeLock();
      return { success: true, stream };
    } catch (tier3Err: any) {
      const errName = tier3Err.name || '';
      console.error('[SR-LIVE-MEDIA] Tier 3 unconstrained media capture failed:', tier3Err);

      if (errName === 'NotAllowedError' || errName === 'PermissionDeniedError' || errName === 'SecurityError') {
        return {
          success: false,
          stream: null,
          errorType: 'PERMISSION_DENIED',
          errorMessage: 'Camera and Microphone access was denied. Please allow Camera & Audio permissions in Android Settings > Apps > DIYO LIVE.'
        };
      }

      if (errName === 'NotFoundError' || errName === 'DevicesNotFoundError') {
        return {
          success: false,
          stream: null,
          errorType: 'NOT_FOUND',
          errorMessage: 'No active camera or microphone found on this Android device.'
        };
      }
    }

    // Tier 4: Video-only fallback (if audio device is locked or denied)
    try {
      const videoOnlyStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing }
      });
      this.currentStream = videoOnlyStream;
      this.acquireWakeLock();
      return { success: true, stream: videoOnlyStream, isVideoOnly: true };
    } catch (videoOnlyErr: any) {
      console.warn('[SR-LIVE-MEDIA] Video-only fallback failed:', videoOnlyErr);
    }

    // Tier 5: Audio-only fallback
    try {
      const audioOnlyStream = await navigator.mediaDevices.getUserMedia({
        audio: true
      });
      this.currentStream = audioOnlyStream;
      this.acquireWakeLock();
      return { success: true, stream: audioOnlyStream, isAudioOnly: true };
    } catch (audioOnlyErr: any) {
      console.error('[SR-LIVE-MEDIA] All media capture tiers failed:', audioOnlyErr);
      return {
        success: false,
        stream: null,
        errorType: 'PERMISSION_DENIED',
        errorMessage: 'Unable to start camera or microphone. Please check Android App Permissions.'
      };
    }
  }

  /**
   * Switch between front and back camera on mobile / Android
   */
  public async switchCamera(): Promise<{ success: boolean; stream: MediaStream | null; facing: 'user' | 'environment' }> {
    const nextFacing: 'user' | 'environment' = this.currentFacing === 'user' ? 'environment' : 'user';
    const res = await this.startLiveStream(nextFacing);
    return {
      success: res.success,
      stream: res.stream,
      facing: nextFacing
    };
  }

  /**
   * Toggle Microphone Mute/Unmute
   */
  public toggleMicrophone(enabled?: boolean): boolean {
    if (!this.currentStream) return false;
    const audioTracks = this.currentStream.getAudioTracks();
    if (audioTracks.length === 0) return false;

    const targetState = enabled !== undefined ? enabled : !audioTracks[0].enabled;
    audioTracks.forEach(track => {
      track.enabled = targetState;
    });
    this.isMuted = !targetState;
    return targetState;
  }

  /**
   * Toggle Camera Video Track ON/OFF
   */
  public toggleCamera(enabled?: boolean): boolean {
    if (!this.currentStream) return false;
    const videoTracks = this.currentStream.getVideoTracks();
    if (videoTracks.length === 0) return false;

    const targetState = enabled !== undefined ? enabled : !videoTracks[0].enabled;
    videoTracks.forEach(track => {
      track.enabled = targetState;
    });
    this.isVideoEnabled = targetState;
    return targetState;
  }

  /**
   * Acquire Android Screen Wake Lock so display doesn't sleep during Live
   */
  private async acquireWakeLock() {
    try {
      if ('wakeLock' in navigator && (navigator as any).wakeLock) {
        this.wakeLock = await (navigator as any).wakeLock.request('screen');
      }
    } catch {
      // Wake lock not supported or denied
    }
  }

  /**
   * Release Screen Wake Lock
   */
  private releaseWakeLock() {
    try {
      if (this.wakeLock && typeof this.wakeLock.release === 'function') {
        this.wakeLock.release();
        this.wakeLock = null;
      }
    } catch {
      // Ignore
    }
  }

  /**
   * Stop all media tracks, release hardware and wake lock
   */
  public stopCurrentStream(releaseWake: boolean = true) {
    if (this.currentStream) {
      this.currentStream.getTracks().forEach(track => {
        try {
          track.stop();
        } catch {}
      });
      this.currentStream = null;
    }

    if (this.audioContext) {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }

    if (releaseWake) {
      this.releaseWakeLock();
    }
  }

  /**
   * Setup Audio Level Meter with Web Audio Analyser
   */
  public getAudioLevelMeter(onLevel: (level: number) => void): () => void {
    if (!this.currentStream || this.currentStream.getAudioTracks().length === 0) {
      return () => {};
    }

    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return () => {};

      this.audioContext = new AudioCtx();
      const source = this.audioContext.createMediaStreamSource(this.currentStream);
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 64;
      source.connect(this.analyser);

      const buffer = new Uint8Array(this.analyser.frequencyBinCount);
      let animId: number | null = null;

      const loop = () => {
        if (!this.analyser) return;
        this.analyser.getByteFrequencyData(buffer);
        let sum = 0;
        for (let i = 0; i < buffer.length; i++) sum += buffer[i];
        const avg = sum / buffer.length;
        const normalized = Math.min(100, Math.round((avg / 128) * 100));
        onLevel(normalized);
        animId = requestAnimationFrame(loop);
      };

      loop();

      return () => {
        if (animId) cancelAnimationFrame(animId);
      };
    } catch {
      return () => {};
    }
  }

  /**
   * Network listeners for Android network handover (WiFi to 4G/5G)
   */
  private onNetworkChangeCallbacks: Array<(online: boolean) => void> = [];

  public onNetworkChange(callback: (online: boolean) => void) {
    this.onNetworkChangeCallbacks.push(callback);
    return () => {
      this.onNetworkChangeCallbacks = this.onNetworkChangeCallbacks.filter(cb => cb !== callback);
    };
  }

  private setupNetworkListeners() {
    if (typeof window === 'undefined') return;
    window.addEventListener('online', () => {
      this.onNetworkChangeCallbacks.forEach(cb => cb(true));
    });
    window.addEventListener('offline', () => {
      this.onNetworkChangeCallbacks.forEach(cb => cb(false));
    });
  }

  /**
   * Lifecycle listeners for Android app background / foreground transitions
   */
  private onVisibilityChangeCallbacks: Array<(visible: boolean) => void> = [];

  public onVisibilityChange(callback: (visible: boolean) => void) {
    this.onVisibilityChangeCallbacks.push(callback);
    return () => {
      this.onVisibilityChangeCallbacks = this.onVisibilityChangeCallbacks.filter(cb => cb !== callback);
    };
  }

  /**
   * Dynamically adjust active video stream quality (480p, 720p, 1080p)
   */
  public async setVideoQuality(quality: '480p' | '720p' | '1080p'): Promise<boolean> {
    if (!this.currentStream) return false;
    const videoTrack = this.currentStream.getVideoTracks()[0];
    if (!videoTrack) return false;

    let width = 1280;
    let height = 720;
    let frameRate = 30;

    if (quality === '480p') {
      width = 854;
      height = 480;
      frameRate = 24;
    } else if (quality === '720p') {
      width = 1280;
      height = 720;
      frameRate = 30;
    } else if (quality === '1080p') {
      width = 1920;
      height = 1080;
      frameRate = 30;
    }

    try {
      if ((videoTrack as any).applyConstraints) {
        await (videoTrack as any).applyConstraints({
          width: { ideal: width },
          height: { ideal: height },
          frameRate: { ideal: frameRate }
        });
        console.info(`[SR-LIVE-MEDIA] Successfully applied stream quality: ${quality}`);
        return true;
      }
    } catch (err) {
      console.warn(`[SR-LIVE-MEDIA] Failed to apply constraints for ${quality}:`, err);
    }
    return false;
  }

  private setupLifecycleListeners() {
    if (typeof document === 'undefined') return;
    document.addEventListener('visibilitychange', () => {
      const isVisible = document.visibilityState === 'visible';
      this.onVisibilityChangeCallbacks.forEach(cb => cb(isVisible));
    });
  }
}

export const androidLiveStreamService = AndroidLiveStreamService.getInstance();
