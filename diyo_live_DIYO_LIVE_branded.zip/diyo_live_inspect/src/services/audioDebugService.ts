/**
 * DIYO LIVE - Audio Debug Service & Structured Logger
 * Captures and logs all RTC and audio pipeline events:
 * - Microphone permission status
 * - Local audio track creation
 * - Local audio track publishing
 * - Remote user connection & track subscription
 * - Remote audio playback status & speaker output
 */

export type AudioEventCategory = 
  | 'PERMISSION' 
  | 'LOCAL_TRACK' 
  | 'PUBLISH' 
  | 'REMOTE_JOIN' 
  | 'SUBSCRIBE' 
  | 'PLAYBACK' 
  | 'ERROR' 
  | 'STATE_CHANGE';

export interface AudioDebugLogEntry {
  id: string;
  timestamp: string;
  category: AudioEventCategory;
  message: string;
  details?: any;
}

class AudioDebugService {
  private static instance: AudioDebugService | null = null;
  private logs: AudioDebugLogEntry[] = [];
  private listeners: ((logs: AudioDebugLogEntry[]) => void)[] = [];

  private constructor() {
    this.log('STATE_CHANGE', 'AudioDebugService initialized successfully.');
  }

  public static getInstance(): AudioDebugService {
    if (!AudioDebugService.instance) {
      AudioDebugService.instance = new AudioDebugService();
    }
    return AudioDebugService.instance;
  }

  public log(category: AudioEventCategory, message: string, details?: any) {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
    const entry: AudioDebugLogEntry = {
      id: `ADL-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp,
      category,
      message,
      details
    };

    this.logs.unshift(entry);
    if (this.logs.length > 200) {
      this.logs.pop();
    }

    // Console styled printing
    const badgeColor = 
      category === 'ERROR' ? 'background: #ef4444; color: white; padding: 2px 6px; border-radius: 4px;' :
      category === 'PERMISSION' ? 'background: #3b82f6; color: white; padding: 2px 6px; border-radius: 4px;' :
      category === 'PUBLISH' ? 'background: #10b981; color: white; padding: 2px 6px; border-radius: 4px;' :
      category === 'SUBSCRIBE' ? 'background: #8b5cf6; color: white; padding: 2px 6px; border-radius: 4px;' :
      category === 'PLAYBACK' ? 'background: #f59e0b; color: white; padding: 2px 6px; border-radius: 4px;' :
      'background: #6b7280; color: white; padding: 2px 6px; border-radius: 4px;';

    console.log(`%c[AUDIO_DEBUG:${category}]%c ${timestamp} - ${message}`, badgeColor, 'color: inherit;', details || '');

    // Notify listeners
    this.listeners.forEach(listener => listener([...this.logs]));
  }

  public getLogs(): AudioDebugLogEntry[] {
    return [...this.logs];
  }

  public subscribe(listener: (logs: AudioDebugLogEntry[]) => void): () => void {
    this.listeners.push(listener);
    listener([...this.logs]);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  public clearLogs() {
    this.logs = [];
    this.listeners.forEach(listener => listener([]));
  }
}

export const audioDebug = AudioDebugService.getInstance();
