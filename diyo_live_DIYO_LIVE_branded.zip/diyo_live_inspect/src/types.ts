export type StreamCategory = 'all' | 'sports' | 'music' | 'news' | 'gaming' | 'tech' | 'radio';

export interface MultiCamAngle {
  id: string;
  name: string;
  shortLabel: string;
  videoUrl: string;
  thumbnail: string;
  description: string;
}

export interface StreamPollOption {
  id: string;
  text: string;
  votes: number;
}

export interface StreamPoll {
  id: string;
  question: string;
  options: StreamPollOption[];
  totalVotes: number;
  userVotedOptionId?: string;
  isActive: boolean;
  endsInSeconds: number;
}

export interface QAItem {
  id: string;
  user: string;
  avatar: string;
  avatarFrameId?: string;
  avatarFrameUrl?: string;
  role?: string;
  hostTag?: string;
  vipLevel?: number;
  question: string;
  upvotes: number;
  userUpvoted: boolean;
  isAnswered: boolean;
  timestamp: string;
}

export interface StreamChannel {
  id: string;
  title: string;
  broadcasterName: string;
  broadcasterAvatar: string;
  broadcasterBadge: 'Verified' | 'Partner' | 'Official' | 'Pro';
  broadcasterFollowers: string;
  category: StreamCategory;
  viewersCount: number;
  likesCount: number;
  streamUrl: string;
  fallbackVideoUrl: string;
  isLive: boolean;
  startedAt: string;
  resolution: string;
  fps: number;
  bitrate: string;
  description: string;
  tags: string[];
  bannerUrl: string;
  thumbnailUrl: string;
  multiCamAngles: MultiCamAngle[];
  hostTag?: 'CELEBRATE' | 'TALENT' | 'SINGER' | 'NORMAL' | string;
  avatarFrameUrl?: string;
  avatarFrameId?: string;
  countryCode?: string;
  countryFlag?: string;
  countryName?: string;
  hostUserId?: string;
  boltBalance?: number;
  isTestRoom?: boolean;
  currentPoll?: StreamPoll;
  qaItems?: QAItem[];
  pinnedMessage?: {
    text: string;
    sender: string;
    time: string;
  };
}

export interface ChatMessage {
  id: string;
  user: string;
  avatar: string;
  avatarFrameId?: string;
  avatarFrameUrl?: string;
  role?: string;
  hostTag?: string;
  badge?: 'Host' | 'Mod' | 'VIP' | 'Sub' | 'TopFan';
  vipLevel?: number;
  message: string;
  timestamp: string;
  type: 'chat' | 'superchat' | 'system' | 'highlight' | 'gift';
  amount?: number;
  currency?: string;
  color?: string;
}

export interface ScheduledEvent {
  id: string;
  title: string;
  broadcasterName: string;
  broadcasterAvatar: string;
  category: StreamCategory;
  scheduledTime: string;
  thumbnailUrl: string;
  description: string;
  isReminderSet: boolean;
  tags: string[];
}

export interface VideoHighlight {
  id: string;
  title: string;
  channelName: string;
  duration: string;
  views: string;
  date: string;
  thumbnailUrl: string;
  videoUrl: string;
  category: StreamCategory;
  tags: string[];
}

export interface FloatingReaction {
  id: string;
  emoji: string;
  x: number;
  speed: number;
}
