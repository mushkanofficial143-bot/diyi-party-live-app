import { UserRole, HostTagType } from './ownerTypes';
import { SRLiveRoleType } from '../components/frames/SRLiveRoleFrame';

export type FrameCategory =
  | 'ALL'
  | 'FREE'
  | 'NEW'
  | 'HOT'
  | 'PREMIUM'
  | 'VIP'
  | 'LOVE'
  | 'ROYAL'
  | 'FIRE'
  | 'FLOWER'
  | 'COUNTRY'
  | 'HOST'
  | 'EVENT'
  | 'LIMITED'
  | 'ACHIEVEMENT';

export type FrameDurationType = '1D' | '3D' | '7D' | '30D' | '90D' | 'PERMANENT';

export interface FrameDurationOption {
  type: FrameDurationType;
  label: string;
  days: number; // -1 for permanent
  priceMultiplier: number; // e.g. 1.0 for 30D, 0.15 for 1D, 0.35 for 7D, 3.0 for permanent
}

export interface FrameItem {
  id: string;
  name: string;
  category: FrameCategory;
  rarity: 'Royalty' | 'Legendary' | 'Epic' | 'Rare' | 'Common';
  coinPrice: number; // Base price (usually 30 Days)
  duration: FrameDurationType;
  durationDays: number; // 30, -1, etc.
  vipLevelRequired?: number;
  hostTypeRequired?: HostTagType | string;
  countryRequired?: string;
  countryFlag?: string;
  roleType?: SRLiveRoleType;
  hostTag?: string;
  
  // Badges & Labels
  isNew?: boolean;
  isHot?: boolean;
  isFree?: boolean;
  isLimited?: boolean;
  limitedDaysRemaining?: number;
  limitedEndDate?: string;
  
  // Achievement Requirement (if category is ACHIEVEMENT)
  isAchievement?: boolean;
  achievementKey?: string;
  achievementTitle?: string;
  achievementDesc?: string;
  achievementTarget?: number;
  achievementProgress?: number;
  isUnlocked?: boolean;

  // Transfer & Gifting
  isTransferable: boolean;
  isPurchaseAllowed: boolean;
  status: 'Active' | 'Disabled';

  // Visual Assets & Styling
  previewUrl?: string;
  iconEmoji: string;
  badgeLabel?: string;
  description: string;
  glowColor: string; // e.g. 'rgba(234, 179, 8, 0.8)'
  borderStyle: string; // e.g. 'border-amber-400'
  gradientStyle: string; // e.g. 'from-amber-400 to-yellow-500'
  animationType: 'pulse' | 'spin-slow' | 'ping-slow' | 'flame' | 'sparkle' | 'equalizer' | 'wings' | 'none';
  topPlaqueText?: string;
  bottomNameplateText?: string;

  // Analytics
  totalPurchases?: number;
  totalGifts?: number;
  totalCoinsGenerated?: number;
  activeUsersCount?: number;
  createdAt?: string;
}

export interface UserOwnedFrame {
  id: string; // Unique inventory item ID (e.g. OWN-1001)
  frameId: string;
  frame: FrameItem;
  acquiredAt: string;
  expiresAt: string | null; // null for permanent, ISO string for temporary
  durationDays: number;
  isEquipped: boolean;
  isTransferable: boolean;
  obtainedFrom: 'PURCHASE' | 'GIFT' | 'ACHIEVEMENT' | 'VIP_REWARD' | 'DEFAULT' | 'ADMIN_GRANT';
  giftedBy?: {
    id: string;
    name: string;
    avatar: string;
  };
}

export interface FrameGiftTransaction {
  transactionId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  receiverId: string;
  receiverName: string;
  receiverAvatar: string;
  frameId: string;
  frameName: string;
  coinAmount: number;
  duration: FrameDurationType;
  timestamp: string;
  status: 'SUCCESS' | 'FAILED';
  note?: string;
}

export interface FrameAnalyticsSummary {
  totalFrames: number;
  activeFrames: number;
  totalPurchasesCount: number;
  totalGiftsCount: number;
  totalCoinsGenerated: number;
  activeFrameUsers: number;
  mostPopularFrame: string;
  mostGiftedFrame: string;
}
