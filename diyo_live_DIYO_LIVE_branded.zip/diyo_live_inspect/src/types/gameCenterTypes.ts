export type GameSectionCategory = 'favorite' | 'hot' | 'recommended' | 'new' | 'more' | 'all';

export type GameGenre = 
  | 'SLOTS'
  | 'CRASH'
  | 'TABLE'
  | 'CASINO_3D'
  | 'LOTTERY'
  | 'CASCADE'
  | 'ARCADE'
  | 'MYSTERY'
  | 'COMMUNITY';

export interface SRLiveGame {
  id: string;
  name: string;
  genre: GameGenre;
  tagline: string;
  description: string;
  icon3D: string; // Emoji / 3D Icon symbol
  bannerImage: string;
  coverImage: string;
  themeColor: string; // Tailwind gradient classes
  accentColor: string; // Hex or text color
  maxMultiplier: string;
  rtp: number; // e.g. 97.8
  minBet: number;
  maxBet: number;
  isHot?: boolean;
  isNew?: boolean;
  isRecommended?: boolean;
  isFavorite?: boolean;
  activePlayersCount: number;
  rating: number; // e.g. 4.9
  rules: string[];
  features: string[];
  isEnabled: boolean;
  displayOrder: number;
}

export interface GameTransactionRecord {
  id: string;
  gameId: string;
  gameName: string;
  userId: string;
  userName: string;
  betAmount: number;
  multiplier: number;
  payoutAmount: number;
  outcome: 'WIN' | 'LOSS' | 'BIG_WIN' | 'MEGA_JACKPOT';
  timestamp: string;
  serverSeedHash?: string;
  hashSeed?: string;
  balanceAfter?: number;
}

export interface PromoBannerItem {
  id: string;
  title: string;
  subtitle: string;
  bonusText: string;
  ctaText: string;
  badge: string;
  bgGradient: string;
  artType: 'coins' | 'tiger' | 'ocean' | 'princess' | 'vip' | 'mahjong';
  actionType: 'BONUS_CLAIM' | 'INVITE' | 'TOP_UP' | 'PLAY_GAME';
  targetGameId?: string;
  claimed?: boolean;
}

export interface GameCenterAdminSettings {
  isMaintenanceMode: boolean;
  globalRtpModifier: number;
  maxDailyWinCoinsPerUser: number;
  demoModeCoinsDefault: number;
  allowHighRollerTables: boolean;
  soundEffectsEnabled: boolean;
  graphicsQuality: 'LOW' | 'MEDIUM' | 'HIGH';
}
