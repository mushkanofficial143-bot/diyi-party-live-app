export interface VipDurationPricing {
  '7d': number;
  '30d': number;
  '90d': number;
  '365d': number;
}

export type VipPlanDuration = '7d' | '30d' | '90d' | '365d' | 'permanent' | 'custom';

export interface VipEntranceEffect {
  id: string;
  name: string;
  type: 'supercar' | 'dragon' | 'chariot' | 'aircraft' | 'celestial' | 'throne' | 'phoenix';
  emoji: string;
  soundFx: string;
  bannerGradient: string;
  description: string;
}

export interface VipChatStyle {
  bubbleGradient: string;
  bubbleBorder: string;
  textColor: string;
  nameGlow: string;
  badgeGlow: string;
}

export interface VipLevelConfig {
  level: number; // 1 to 10
  title: string;
  subtitle: string;
  badgeLabel: string;
  badgeIcon: string;
  badgeColor: string;
  textColor: string;
  gradient: string;
  frameId: string;
  frameName: string;
  frameBorderClass: string;
  monthlyCoinsRequired: number; // Spend requirement
  pricing: VipDurationPricing; // Direct buy price in coins
  entranceEffect: VipEntranceEffect;
  chatStyle: VipChatStyle;
  storeDiscountPercent: number;
  withdrawalTaxDiscountPercent: number;
  coinTransferTaxDiscountPercent: number;
  privileges: string[];
  unlockedGifts: string[];
  totalActiveMembers: number;
  isActive: boolean;
  isPopular?: boolean;
  isRoyalty?: boolean;
}

export interface UserVipRecord {
  userId: string;
  userName: string;
  userAvatar: string;
  vipLevel: number;
  status: 'ACTIVE' | 'EXPIRED' | 'INACTIVE';
  planDuration: VipPlanDuration;
  isPermanent?: boolean;
  activatedAt: string;
  expiresAt: string;
  remainingDays: number;
  remainingHours: number;
  autoRenew: boolean;
  totalCoinsSpentOnVip: number;
  renewalCount: number;
  grantedByAdmin?: boolean;
  adminId?: string;
  adminName?: string;
  adminNote?: string;
  lastUpdated?: string;
}

export interface VipTransaction {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  type: 'VIP_PURCHASE' | 'VIP_UPGRADE' | 'VIP_RENEWAL' | 'ADMIN_GRANT' | 'ADMIN_CHANGE' | 'ADMIN_REVOKE';
  level: number;
  previousLevel?: number;
  levelTitle: string;
  duration: VipPlanDuration;
  durationDays: number;
  isPermanent?: boolean;
  costCoins: number;
  prevBalance: number;
  newBalance: number;
  timestamp: string;
  status: 'COMPLETED' | 'REFUNDED' | 'FAILED';
  adminId?: string;
  adminName?: string;
  notes?: string;
}

export interface VipSystemStats {
  totalActiveVipMembers: number;
  totalVipRevenueCoins: number;
  vipMembersByLevel: { [level: number]: number };
  recentTransactions: VipTransaction[];
  topSpenders: {
    userId: string;
    userName: string;
    avatar: string;
    vipLevel: number;
    totalSpent: number;
  }[];
}
