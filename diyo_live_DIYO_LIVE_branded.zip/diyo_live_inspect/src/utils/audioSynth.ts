// Procedural Web Audio API Ambient Synthesizer & Sound FX Engine for DIYO LIVE

let audioCtx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let analyserNode: AnalyserNode | null = null;
let isRadioPlaying = false;
let radioTimer: any = null;

export function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
    masterGain = audioCtx.createGain();
    masterGain.gain.setValueAtTime(0.3, audioCtx.currentTime);

    analyserNode = audioCtx.createAnalyser();
    analyserNode.fftSize = 64;
    masterGain.connect(analyserNode);
    analyserNode.connect(audioCtx.destination);
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function getAnalyser(): AnalyserNode | null {
  getAudioContext();
  return analyserNode;
}

// Play pleasant UI sound effects
export function playSoundFX(type: 'reaction' | 'superchat' | 'notification' | 'click' | 'vote' | 'alert' | 'win' | 'success' | 'dice' | 'reward' | 'coin' | 'live_start' | 'stop' | 'spin' | 'magic' | 'roar' | 'lava' | 'cashout' | 'rocket') {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'rocket') {
      // Futuristic ascending rocket plasma thrust swoosh
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.6);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
      osc.start(now);
      osc.stop(now + 0.65);
    } else if (type === 'magic') {
      // Shimmering celestial magical chimes
      [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, now + i * 0.06);
        g.gain.setValueAtTime(0.12, now + i * 0.06);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.4);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + i * 0.06);
        o.stop(now + i * 0.06 + 0.4);
      });
    } else if (type === 'spin') {
      // Rapid ticking click for slot reel spin
      [700, 850, 950].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'triangle';
        o.frequency.setValueAtTime(freq, now + i * 0.04);
        g.gain.setValueAtTime(0.08, now + i * 0.04);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.04 + 0.05);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + i * 0.04);
        o.stop(now + i * 0.04 + 0.05);
      });
    } else if (type === 'roar' || type === 'lava') {
      // Deep bass rumble for tiger roar / volcano eruption
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(120, now);
      o.frequency.exponentialRampToValueAtTime(45, now + 0.4);
      g.gain.setValueAtTime(0.25, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      o.connect(g);
      g.connect(ctx.destination);
      o.start(now);
      o.stop(now + 0.45);
    } else if (type === 'cashout' || type === 'reward' || type === 'win' || type === 'success' || type === 'live_start') {
      [587.33, 739.99, 880, 1174.66, 1479.98].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'triangle';
        o.frequency.setValueAtTime(freq, now + i * 0.07);
        g.gain.setValueAtTime(0.18, now + i * 0.07);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.07 + 0.35);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + i * 0.07);
        o.stop(now + i * 0.07 + 0.35);
      });
    } else if (type === 'coin') {
      [987.77, 1318.51].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, now + i * 0.05);
        g.gain.setValueAtTime(0.15, now + i * 0.05);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.05 + 0.15);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + i * 0.05);
        o.stop(now + i * 0.05 + 0.15);
      });
    } else if (type === 'stop') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.linearRampToValueAtTime(220, now + 0.15);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'dice') {
      // Shaking dice rattle sound
      [320, 480, 260, 520].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, now + i * 0.05);
        g.gain.setValueAtTime(0.12, now + i * 0.05);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.05 + 0.08);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + i * 0.05);
        o.stop(now + i * 0.05 + 0.08);
      });
    } else if (type === 'alert') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.linearRampToValueAtTime(160, now + 0.2);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    } else if (type === 'reaction') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc.start(now);
      osc.stop(now + 0.12);
    } else if (type === 'superchat') {
      // Arpeggio chime
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'triangle';
        o.frequency.setValueAtTime(freq, now + i * 0.08);
        g.gain.setValueAtTime(0.2, now + i * 0.08);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.35);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + i * 0.08);
        o.stop(now + i * 0.08 + 0.35);
      });
    } else if (type === 'vote') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'notification') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(659.25, now);
      osc.frequency.setValueAtTime(880, now + 0.1);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === 'click') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
      osc.start(now);
      osc.stop(now + 0.04);
    }
  } catch {
    // Ignore audio autoplay restrictions gracefully
  }
}

// Procedural Lo-Fi Chords generator for 24/7 radio
const CHORD_PROGRESSIONS = [
  [261.63, 329.63, 392.00, 493.88], // Cmaj7
  [220.00, 261.63, 329.63, 392.00], // Am7
  [174.61, 220.00, 261.63, 329.63], // Fmaj7
  [196.00, 246.94, 293.66, 349.23], // G7
  [146.83, 174.61, 220.00, 261.63]  // Dm7
];

let currentChordIdx = 0;

export function startAmbientRadio(volume: number = 0.25): boolean {
  try {
    const ctx = getAudioContext();
    if (masterGain) {
      masterGain.gain.setValueAtTime(volume, ctx.currentTime);
    }
    isRadioPlaying = true;

    const playNextChord = () => {
      if (!isRadioPlaying) return;
      const chord = CHORD_PROGRESSIONS[currentChordIdx % CHORD_PROGRESSIONS.length];
      currentChordIdx++;
      const now = ctx.currentTime;
      const duration = 4.5;

      chord.forEach((freq) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        // Lowpass filter for warm cozy lo-fi timbre
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(800 + Math.random() * 400, now);
        filter.Q.setValueAtTime(2, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.04, now + 1.2);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

        osc.connect(filter);
        filter.connect(gain);
        if (masterGain) gain.connect(masterGain);

        osc.start(now);
        osc.stop(now + duration + 0.1);
      });

      radioTimer = setTimeout(playNextChord, 4000);
    };

    playNextChord();
    return true;
  } catch {
    return false;
  }
}

export function stopAmbientRadio() {
  isRadioPlaying = false;
  if (radioTimer) {
    clearTimeout(radioTimer);
    radioTimer = null;
  }
}

export function setRadioVolume(vol: number) {
  if (masterGain && audioCtx) {
    masterGain.gain.setValueAtTime(Math.max(0, Math.min(1, vol)), audioCtx.currentTime);
  }
}
