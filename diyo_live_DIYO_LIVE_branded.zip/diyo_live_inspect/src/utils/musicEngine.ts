import { MusicTrack, MUSIC_TRACKS_CATALOG } from './musicTracks';
import { getAudioContext, getAnalyser } from './audioSynth';

export type PlaybackMode = 'repeat-all' | 'repeat-one' | 'shuffle';

class MusicEngine {
  private currentTrack: MusicTrack | null = null;
  private isPlaying: boolean = false;
  private volume: number = 0.6;
  private currentTime: number = 0;
  private duration: number = 200;
  private playbackMode: PlaybackMode = 'repeat-all';
  private playlist: MusicTrack[] = [...MUSIC_TRACKS_CATALOG];
  private customTracks: MusicTrack[] = [];
  
  // Web Audio Synth internals
  private chordIndex: number = 0;
  private synthInterval: any = null;
  private timerInterval: any = null;
  private audioElement: HTMLAudioElement | null = null;
  private audioSourceNode: MediaElementAudioSourceNode | null = null;

  // Listeners
  private listeners: Set<(state: MusicEngineState) => void> = new Set();

  constructor() {
    // Default initial track
    if (this.playlist.length > 0) {
      this.currentTrack = this.playlist[0];
      this.duration = this.playlist[0].duration;
    }
  }

  public getState(): MusicEngineState {
    return {
      currentTrack: this.currentTrack,
      isPlaying: this.isPlaying,
      volume: this.volume,
      currentTime: this.currentTime,
      duration: this.duration,
      playbackMode: this.playbackMode,
      playlist: [...this.customTracks, ...this.playlist]
    };
  }

  public subscribe(callback: (state: MusicEngineState) => void): () => void {
    this.listeners.add(callback);
    callback(this.getState());
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify() {
    const state = this.getState();
    this.listeners.forEach((cb) => cb(state));
  }

  public playTrack(track: MusicTrack) {
    this.stopPlayback();
    this.currentTrack = track;
    this.currentTime = 0;
    this.duration = track.duration;
    this.startPlayback();
  }

  public togglePlay() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.resume();
    }
  }

  public pause() {
    this.isPlaying = false;
    this.stopPlayback();
    this.notify();
  }

  public resume() {
    if (!this.currentTrack && this.playlist.length > 0) {
      this.currentTrack = this.playlist[0];
    }
    if (this.currentTrack) {
      this.startPlayback();
    }
  }

  public nextTrack() {
    if (this.playlist.length === 0) return;
    const all = this.getAllTracks();
    if (this.playbackMode === 'shuffle') {
      const randomIdx = Math.floor(Math.random() * all.length);
      this.playTrack(all[randomIdx]);
      return;
    }

    const currentIdx = all.findIndex((t) => t.id === this.currentTrack?.id);
    const nextIdx = (currentIdx + 1) % all.length;
    this.playTrack(all[nextIdx]);
  }

  public prevTrack() {
    if (this.playlist.length === 0) return;
    const all = this.getAllTracks();
    const currentIdx = all.findIndex((t) => t.id === this.currentTrack?.id);
    const prevIdx = (currentIdx - 1 + all.length) % all.length;
    this.playTrack(all[prevIdx]);
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.audioElement) {
      this.audioElement.volume = this.volume;
    }
    this.notify();
  }

  public seek(seconds: number) {
    this.currentTime = Math.max(0, Math.min(this.duration, seconds));
    if (this.audioElement && this.currentTrack?.audioUrl) {
      this.audioElement.currentTime = this.currentTime;
    }
    this.notify();
  }

  public setPlaybackMode(mode: PlaybackMode) {
    this.playbackMode = mode;
    this.notify();
  }

  public addCustomTrack(file: File) {
    const objectUrl = URL.createObjectURL(file);
    const customTrack: MusicTrack = {
      id: `custom-${Date.now()}`,
      title: file.name.replace(/\.[^/.]+$/, ''),
      artist: 'Custom Upload / User Track',
      category: 'Party',
      duration: 180,
      bpm: 110,
      mood: 'Custom Audio Selection',
      coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
      audioUrl: objectUrl,
      color: '#f43f5e',
      chordProgression: [[261.63, 329.63, 392.00, 493.88]],
      drumStyle: 'edm',
      views: 1,
      likes: 1
    };

    this.customTracks.unshift(customTrack);
    this.playTrack(customTrack);
    this.notify();
  }

  public getAllTracks(): MusicTrack[] {
    return [...this.customTracks, ...this.playlist];
  }

  private startPlayback() {
    if (!this.currentTrack) return;
    this.isPlaying = true;

    // If track has a direct audio stream URL or user blob
    if (this.currentTrack.audioUrl) {
      try {
        if (!this.audioElement) {
          this.audioElement = new Audio();
          const ctx = getAudioContext();
          this.audioSourceNode = ctx.createMediaElementSource(this.audioElement);
          const analyser = getAnalyser();
          if (analyser) {
            this.audioSourceNode.connect(analyser);
            analyser.connect(ctx.destination);
          } else {
            this.audioSourceNode.connect(ctx.destination);
          }
        }

        this.audioElement.src = this.currentTrack.audioUrl;
        this.audioElement.volume = this.volume;
        this.audioElement.currentTime = this.currentTime;
        this.audioElement.play().catch(() => {
          // Fallback to procedural synth if audio file cannot be decoded
          this.startProceduralSynth();
        });

        this.audioElement.onended = () => {
          this.handleTrackEnd();
        };
      } catch {
        this.startProceduralSynth();
      }
    } else {
      // High-fidelity procedural Web Audio Synthesizer
      this.startProceduralSynth();
    }

    // Timer ticker
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      if (!this.isPlaying) return;
      this.currentTime += 1;
      if (this.currentTime >= this.duration) {
        this.handleTrackEnd();
      } else {
        this.notify();
      }
    }, 1000);

    this.notify();
  }

  private handleTrackEnd() {
    if (this.playbackMode === 'repeat-one' && this.currentTrack) {
      this.currentTime = 0;
      this.playTrack(this.currentTrack);
    } else {
      this.nextTrack();
    }
  }

  private startProceduralSynth() {
    try {
      const ctx = getAudioContext();
      const track = this.currentTrack;
      if (!track) return;

      const chordProg = track.chordProgression;
      const bpm = track.bpm || 90;
      const beatInterval = (60 / bpm) * 1000;
      const chordDuration = beatInterval * 4; // 1 measure per chord

      const playChordMeasure = () => {
        if (!this.isPlaying || !this.currentTrack) return;
        const now = ctx.currentTime;
        const chord = chordProg[this.chordIndex % chordProg.length];
        this.chordIndex++;

        // 1. Warm Harmonics Pad
        chord.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const filter = ctx.createBiquadFilter();

          osc.type = track.drumStyle === 'edm' ? 'sawtooth' : 'triangle';
          osc.frequency.setValueAtTime(freq, now);

          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(track.drumStyle === 'edm' ? 1400 : 750, now);
          filter.Q.setValueAtTime(1.5, now);

          const baseGain = (this.volume * 0.05) / chord.length;
          gain.gain.setValueAtTime(0.001, now);
          gain.gain.linearRampToValueAtTime(baseGain, now + 0.4);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + (chordDuration / 1000) * 0.95);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(ctx.destination);

          const analyser = getAnalyser();
          if (analyser) gain.connect(analyser);

          osc.start(now);
          osc.stop(now + (chordDuration / 1000));
        });

        // 2. Bassline Pulse
        if (track.bassline && track.bassline.length > 0) {
          const bassFreq = track.bassline[(this.chordIndex - 1) % track.bassline.length];
          const bassOsc = ctx.createOscillator();
          const bassGain = ctx.createGain();

          bassOsc.type = 'sine';
          bassOsc.frequency.setValueAtTime(bassFreq, now);

          bassGain.gain.setValueAtTime(this.volume * 0.08, now);
          bassGain.gain.exponentialRampToValueAtTime(0.001, now + (chordDuration / 1000) * 0.8);

          bassOsc.connect(bassGain);
          bassGain.connect(ctx.destination);
          const analyser = getAnalyser();
          if (analyser) bassGain.connect(analyser);

          bassOsc.start(now);
          bassOsc.stop(now + (chordDuration / 1000));
        }

        // 3. Rhythm Drum Beats
        if (track.drumStyle === 'bhangra' || track.drumStyle === 'edm' || track.drumStyle === 'lofi') {
          for (let step = 0; step < 4; step++) {
            const stepTime = now + (step * (beatInterval / 1000));
            // Kick drum on 1 and 3
            if (step === 0 || step === 2) {
              const kick = ctx.createOscillator();
              const kickGain = ctx.createGain();
              kick.type = 'sine';
              kick.frequency.setValueAtTime(150, stepTime);
              kick.frequency.exponentialRampToValueAtTime(35, stepTime + 0.12);

              kickGain.gain.setValueAtTime(this.volume * 0.12, stepTime);
              kickGain.gain.exponentialRampToValueAtTime(0.001, stepTime + 0.15);

              kick.connect(kickGain);
              kickGain.connect(ctx.destination);
              kick.start(stepTime);
              kick.stop(stepTime + 0.16);
            }

            // Snare / Rim on 2 and 4
            if (step === 1 || step === 3) {
              const snare = ctx.createOscillator();
              const snareGain = ctx.createGain();
              snare.type = 'triangle';
              snare.frequency.setValueAtTime(280, stepTime);
              snare.frequency.linearRampToValueAtTime(100, stepTime + 0.08);

              snareGain.gain.setValueAtTime(this.volume * 0.06, stepTime);
              snareGain.gain.exponentialRampToValueAtTime(0.001, stepTime + 0.1);

              snare.connect(snareGain);
              snareGain.connect(ctx.destination);
              snare.start(stepTime);
              snare.stop(stepTime + 0.11);
            }
          }
        }
      };

      playChordMeasure();
      this.synthInterval = setInterval(playChordMeasure, chordDuration);
    } catch {
      // Handle audio autoplay gracefully
    }
  }

  private stopPlayback() {
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
    if (this.audioElement) {
      this.audioElement.pause();
    }
  }
}

export interface MusicEngineState {
  currentTrack: MusicTrack | null;
  isPlaying: boolean;
  volume: number;
  currentTime: number;
  duration: number;
  playbackMode: PlaybackMode;
  playlist: MusicTrack[];
}

export const musicEngine = new MusicEngine();
