export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  category: 'Bollywood' | 'Punjabi' | 'LoFi' | 'EDM' | 'Sufi' | 'Party';
  duration: number; // in seconds
  bpm: number;
  mood: string;
  coverUrl: string;
  audioUrl?: string; // Optional custom/external audio stream or blob
  color: string;
  chordProgression: number[][];
  bassline?: number[];
  drumStyle: 'lofi' | 'bhangra' | 'edm' | 'acoustic' | 'ambient' | 'sufi';
  views: number;
  likes: number;
}

export const MUSIC_TRACKS_CATALOG: MusicTrack[] = [
  // --- BOLLYWOOD & ROMANTIC ---
  {
    id: 'trk-bol-01',
    title: 'Kesariya (Acoustic Unplugged)',
    artist: 'Arijit Vibes & SR Acoustic',
    category: 'Bollywood',
    duration: 215,
    bpm: 92,
    mood: 'Romantic & Soulful',
    coverUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&auto=format&fit=crop&q=80',
    color: '#f97316',
    chordProgression: [
      [261.63, 329.63, 392.00, 493.88], // Cmaj7
      [220.00, 261.63, 329.63, 392.00], // Am7
      [174.61, 220.00, 261.63, 329.63], // Fmaj7
      [196.00, 246.94, 293.66, 349.23]  // G7
    ],
    bassline: [65.41, 55.00, 43.65, 49.00],
    drumStyle: 'acoustic',
    views: 184500,
    likes: 42300
  },
  {
    id: 'trk-bol-02',
    title: 'Tum Hi Ho (Melodic Piano Chill)',
    artist: 'Mithoon & Studio Piano',
    category: 'Bollywood',
    duration: 230,
    bpm: 88,
    mood: 'Deep Love & Melodic',
    coverUrl: 'https://images.unsplash.com/photo-1520523839898-507127053c37?w=300&auto=format&fit=crop&q=80',
    color: '#ec4899',
    chordProgression: [
      [220.00, 261.63, 329.63, 392.00], // Am
      [174.61, 220.00, 261.63, 329.63], // F
      [261.63, 329.63, 392.00, 493.88], // C
      [196.00, 246.94, 293.66, 349.23]  // G
    ],
    bassline: [55.00, 43.65, 65.41, 49.00],
    drumStyle: 'lofi',
    views: 295000,
    likes: 68100
  },
  {
    id: 'trk-bol-03',
    title: 'Apna Bana Le (Lo-Fi Midnight Remix)',
    artist: 'Sachin-Jigar & Arijit Beats',
    category: 'Bollywood',
    duration: 200,
    bpm: 85,
    mood: 'Warm Cozy Heart',
    coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80',
    color: '#8b5cf6',
    chordProgression: [
      [174.61, 220.00, 261.63, 329.63], // Fmaj7
      [196.00, 246.94, 293.66, 349.23], // G
      [220.00, 261.63, 329.63, 392.00], // Am
      [261.63, 329.63, 392.00, 493.88]  // C
    ],
    bassline: [43.65, 49.00, 55.00, 65.41],
    drumStyle: 'lofi',
    views: 142000,
    likes: 31200
  },
  {
    id: 'trk-bol-04',
    title: 'Channa Mereya (Sufi Guitar Live)',
    artist: 'Pritam Acoustic Sessions',
    category: 'Bollywood',
    duration: 245,
    bpm: 90,
    mood: 'Soulful Nostalgia',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
    color: '#eab308',
    chordProgression: [
      [261.63, 329.63, 392.00, 523.25], // C
      [196.00, 246.94, 293.66, 392.00], // G
      [220.00, 261.63, 329.63, 440.00], // Am
      [174.61, 220.00, 261.63, 349.23]  // F
    ],
    bassline: [65.41, 49.00, 55.00, 43.65],
    drumStyle: 'sufi',
    views: 210000,
    likes: 54000
  },
  {
    id: 'trk-bol-05',
    title: 'Maan Meri Jaan (Synth Fusion)',
    artist: 'King X DIYO Mix',
    category: 'Bollywood',
    duration: 195,
    bpm: 98,
    mood: 'Sensual R&B Synth',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80',
    color: '#06b6d4',
    chordProgression: [
      [146.83, 174.61, 220.00, 261.63], // Dm
      [174.61, 220.00, 261.63, 329.63], // F
      [261.63, 329.63, 392.00, 493.88], // C
      [196.00, 246.94, 293.66, 349.23]  // G
    ],
    bassline: [36.71, 43.65, 65.41, 49.00],
    drumStyle: 'edm',
    views: 310000,
    likes: 82000
  },

  // --- PUNJABI & DESI PARTY ---
  {
    id: 'trk-pun-01',
    title: 'Brown Munde (Club Bass Drop)',
    artist: 'AP Dhillon & Gurinder Gill Style',
    category: 'Punjabi',
    duration: 180,
    bpm: 110,
    mood: 'High Energy Party',
    coverUrl: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=300&auto=format&fit=crop&q=80',
    color: '#ef4444',
    chordProgression: [
      [146.83, 174.61, 220.00, 293.66], // Dm
      [164.81, 196.00, 246.94, 329.63], // Em
      [174.61, 220.00, 261.63, 349.23], // F
      [196.00, 246.94, 293.66, 392.00]  // G
    ],
    bassline: [36.71, 41.20, 43.65, 49.00],
    drumStyle: 'bhangra',
    views: 450000,
    likes: 120000
  },
  {
    id: 'trk-pun-02',
    title: '295 (Tribute Anthem Beat)',
    artist: 'Sidhu Moosewala Tribute Beats',
    category: 'Punjabi',
    duration: 210,
    bpm: 104,
    mood: 'Legendary Bass & Flow',
    coverUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=300&auto=format&fit=crop&q=80',
    color: '#f59e0b',
    chordProgression: [
      [220.00, 261.63, 329.63, 392.00], // Am
      [174.61, 220.00, 261.63, 329.63], // F
      [146.83, 174.61, 220.00, 261.63], // Dm
      [164.81, 196.00, 246.94, 329.63]  // Em
    ],
    bassline: [55.00, 43.65, 36.71, 41.20],
    drumStyle: 'bhangra',
    views: 520000,
    likes: 154000
  },
  {
    id: 'trk-pun-03',
    title: 'Excuses (Late Night Drive Mix)',
    artist: 'Intense & AP Dhillon Groove',
    category: 'Punjabi',
    duration: 175,
    bpm: 100,
    mood: 'Midnight Cruiser',
    coverUrl: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=300&auto=format&fit=crop&q=80',
    color: '#10b981',
    chordProgression: [
      [196.00, 246.94, 293.66, 349.23], // G
      [220.00, 261.63, 329.63, 392.00], // Am
      [261.63, 329.63, 392.00, 493.88], // C
      [174.61, 220.00, 261.63, 329.63]  // F
    ],
    bassline: [49.00, 55.00, 65.41, 43.65],
    drumStyle: 'bhangra',
    views: 390000,
    likes: 98000
  },
  {
    id: 'trk-pun-04',
    title: 'Pasoori (Folk Fusion Fiesta)',
    artist: 'Ali Sethi & Shae Gill Remix',
    category: 'Punjabi',
    duration: 190,
    bpm: 108,
    mood: 'Euphoric Folk Energy',
    coverUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=300&auto=format&fit=crop&q=80',
    color: '#d946ef',
    chordProgression: [
      [220.00, 261.63, 329.63, 440.00], // Am
      [196.00, 246.94, 293.66, 392.00], // G
      [174.61, 220.00, 261.63, 349.23], // F
      [164.81, 196.00, 246.94, 329.63]  // Em
    ],
    bassline: [55.00, 49.00, 43.65, 41.20],
    drumStyle: 'bhangra',
    views: 380000,
    likes: 110000
  },

  // --- LO-FI, CHILLHOP & STUDY ---
  {
    id: 'trk-lofi-01',
    title: 'Midnight Sanctuary in Mumbai',
    artist: 'SR Chillhop Collective',
    category: 'LoFi',
    duration: 260,
    bpm: 78,
    mood: 'Cozy Rain & Night Sky',
    coverUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&auto=format&fit=crop&q=80',
    color: '#3b82f6',
    chordProgression: [
      [261.63, 329.63, 392.00, 493.88], // Cmaj7
      [220.00, 261.63, 329.63, 392.00], // Am7
      [174.61, 220.00, 261.63, 329.63], // Fmaj7
      [146.83, 174.61, 220.00, 261.63]  // Dm7
    ],
    bassline: [65.41, 55.00, 43.65, 36.71],
    drumStyle: 'lofi',
    views: 195000,
    likes: 47000
  },
  {
    id: 'trk-lofi-02',
    title: 'Rainy Tea Stall Reflections',
    artist: 'Analog Vinyl Sessions',
    category: 'LoFi',
    duration: 240,
    bpm: 74,
    mood: 'Peaceful Meditation',
    coverUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&auto=format&fit=crop&q=80',
    color: '#14b8a6',
    chordProgression: [
      [174.61, 220.00, 261.63, 329.63], // Fmaj7
      [196.00, 246.94, 293.66, 349.23], // G7
      [164.81, 196.00, 246.94, 293.66], // Em7
      [220.00, 261.63, 329.63, 392.00]  // Am7
    ],
    bassline: [43.65, 49.00, 41.20, 55.00],
    drumStyle: 'lofi',
    views: 168000,
    likes: 39000
  },
  {
    id: 'trk-lofi-03',
    title: 'Cyberpunk Sunset Drive',
    artist: 'Neon Synthesizer Lab',
    category: 'LoFi',
    duration: 220,
    bpm: 86,
    mood: 'Retro 80s Futuristic',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&auto=format&fit=crop&q=80',
    color: '#a855f7',
    chordProgression: [
      [220.00, 261.63, 329.63, 440.00], // Am
      [174.61, 220.00, 261.63, 349.23], // F
      [261.63, 329.63, 392.00, 523.25], // C
      [196.00, 246.94, 293.66, 392.00]  // G
    ],
    bassline: [55.00, 43.65, 65.41, 49.00],
    drumStyle: 'lofi',
    views: 220000,
    likes: 61000
  },
  {
    id: 'trk-lofi-04',
    title: '432Hz Calm Binaural Waves',
    artist: 'Healing Frequency Labs',
    category: 'LoFi',
    duration: 300,
    bpm: 60,
    mood: 'Deep Sleep & Healing',
    coverUrl: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=300&auto=format&fit=crop&q=80',
    color: '#6366f1',
    chordProgression: [
      [216.00, 272.00, 324.00, 432.00], // 432Hz harmonic
      [162.00, 216.00, 272.00, 324.00],
      [144.00, 180.00, 216.00, 288.00],
      [192.00, 240.00, 288.00, 384.00]
    ],
    bassline: [54.00, 40.50, 36.00, 48.00],
    drumStyle: 'ambient',
    views: 310000,
    likes: 92000
  },

  // --- EDM & CLUB PARTY ---
  {
    id: 'trk-edm-01',
    title: 'Club Ignition (Festival Peak Drop)',
    artist: 'DJ SR Anthem Crew',
    category: 'EDM',
    duration: 190,
    bpm: 128,
    mood: 'Peak Stage Bass & Lights',
    coverUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=300&auto=format&fit=crop&q=80',
    color: '#e11d48',
    chordProgression: [
      [146.83, 220.00, 293.66, 370.00], // Dm
      [174.61, 261.63, 349.23, 440.00], // F
      [196.00, 293.66, 392.00, 493.88], // G
      [220.00, 329.63, 440.00, 554.37]  // A
    ],
    bassline: [36.71, 43.65, 49.00, 55.00],
    drumStyle: 'edm',
    views: 480000,
    likes: 135000
  },
  {
    id: 'trk-edm-02',
    title: 'Laser Horizon (Euphoric Trance)',
    artist: 'Ultra Soundwave Project',
    category: 'EDM',
    duration: 210,
    bpm: 132,
    mood: 'Hypnotic Synth Arps',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80',
    color: '#0284c7',
    chordProgression: [
      [220.00, 261.63, 329.63, 392.00], // Am
      [174.61, 220.00, 261.63, 329.63], // F
      [261.63, 329.63, 392.00, 493.88], // C
      [196.00, 246.94, 293.66, 349.23]  // G
    ],
    bassline: [55.00, 43.65, 65.41, 49.00],
    drumStyle: 'edm',
    views: 290000,
    likes: 77000
  },
  {
    id: 'trk-edm-03',
    title: 'Bass Booster VIP (Sub Heavy 808)',
    artist: 'Sub-Zero Beats',
    category: 'EDM',
    duration: 170,
    bpm: 140,
    mood: 'Heavy Sub Rumble',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&auto=format&fit=crop&q=80',
    color: '#f43f5e',
    chordProgression: [
      [130.81, 164.81, 196.00, 261.63], // C
      [146.83, 174.61, 220.00, 293.66], // Dm
      [164.81, 196.00, 246.94, 329.63], // Em
      [174.61, 220.00, 261.63, 349.23]  // F
    ],
    bassline: [32.70, 36.71, 41.20, 43.65],
    drumStyle: 'edm',
    views: 340000,
    likes: 89000
  },

  // --- SUFI & MEDITATIVE ---
  {
    id: 'trk-suf-01',
    title: 'Kun Faya Kun (Divine Meditative Waves)',
    artist: 'A.R. Rahman Inspired Harmony',
    category: 'Sufi',
    duration: 280,
    bpm: 72,
    mood: 'Spiritual Peace & Grace',
    coverUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&auto=format&fit=crop&q=80',
    color: '#10b981',
    chordProgression: [
      [261.63, 329.63, 392.00, 523.25], // C
      [174.61, 220.00, 261.63, 349.23], // F
      [220.00, 261.63, 329.63, 440.00], // Am
      [196.00, 246.94, 293.66, 392.00]  // G
    ],
    bassline: [65.41, 43.65, 55.00, 49.00],
    drumStyle: 'sufi',
    views: 410000,
    likes: 125000
  },
  {
    id: 'trk-suf-02',
    title: 'Afreen Afreen (Acoustic Sitar & Strings)',
    artist: 'Nusrat & Rahat Legacy Strings',
    category: 'Sufi',
    duration: 250,
    bpm: 80,
    mood: 'Classical Sufi Passion',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
    color: '#d97706',
    chordProgression: [
      [220.00, 261.63, 329.63, 392.00], // Am
      [196.00, 246.94, 293.66, 349.23], // G
      [174.61, 220.00, 261.63, 329.63], // F
      [164.81, 207.65, 246.94, 329.63]  // E
    ],
    bassline: [55.00, 49.00, 43.65, 41.20],
    drumStyle: 'sufi',
    views: 375000,
    likes: 99000
  }
];

export const DJ_SOUND_EFFECTS = [
  { id: 'fx-applause', name: '👏 Huge Crowd Applause', icon: '👏', sound: 'success' },
  { id: 'fx-airhorn', name: '📢 Reggae DJ Airhorn', icon: '📢', sound: 'alert' },
  { id: 'fx-superchat', name: '✨ Magical Chime Drop', icon: '✨', sound: 'superchat' },
  { id: 'fx-dice', name: '🎲 Lucky Rattle Roll', icon: '🎲', sound: 'dice' },
  { id: 'fx-cheer', name: '🎉 Grand Celebration Win', icon: '🎉', sound: 'win' },
  { id: 'fx-laser', name: '⚡ Laser Synth Sweep', icon: '⚡', sound: 'reaction' }
];
