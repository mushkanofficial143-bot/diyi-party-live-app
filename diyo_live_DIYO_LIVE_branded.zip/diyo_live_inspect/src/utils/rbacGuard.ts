import { UserRole, AuditLogEntry } from '../types/ownerTypes';

export interface RBACCheckResult {
  allowed: boolean;
  reason?: string;
  statusCode: 200 | 403 | 401 | 400;
}

/**
 * Hierarchy rank definition:
 * 1. OWNER (6)
 * 2. MANAGER (5)
 * 3. ADMIN (4)
 * 4. COIN_SELLER (3)
 * 5. AGENCY (2)
 * 6. USER (1)
 */
export const ROLE_HIERARCHY_RANK: Record<UserRole, number> = {
  OWNER: 8,
  OFFICIAL: 7,
  MANAGER: 6,
  SUPER_ADMIN: 5,
  ADMIN: 4,
  ADMIN_BD: 4,
  COIN_SELLER: 3,
  AGENCY: 2,
  HOST: 1,
  USER: 1
};

export const ROLE_LABELS: Record<UserRole, string> = {
  OWNER: 'Master Owner',
  OFFICIAL: 'Official',
  MANAGER: 'Manager',
  SUPER_ADMIN: 'Super Admin',
  ADMIN: 'Admin / BD',
  ADMIN_BD: 'Admin / BD',
  COIN_SELLER: 'Coin Seller',
  AGENCY: 'Agency',
  HOST: 'Host',
  USER: 'User'
};

export const ROLE_BADGE_COLORS: Record<UserRole, string> = {
  OWNER: 'bg-amber-500/20 text-amber-300 border-amber-500/40 ring-amber-500/30',
  OFFICIAL: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
  MANAGER: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
  SUPER_ADMIN: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
  ADMIN: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
  ADMIN_BD: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
  COIN_SELLER: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40',
  AGENCY: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
  HOST: 'bg-pink-500/20 text-pink-300 border-pink-500/40',
  USER: 'bg-neutral-800 text-neutral-300 border-neutral-700'
};

/**
 * Enforce RBAC security checks on all actions.
 * Simulates server-side verification ensuring lower ranks cannot touch higher/unauthorized entities.
 */
export function checkRBACPermission(
  actorRole: UserRole,
  action: string,
  targetRole?: UserRole
): RBACCheckResult {
  // 1. Normal User or Host has 0 staff permissions
  if (actorRole === 'USER' || actorRole === 'HOST') {
    return {
      allowed: false,
      statusCode: 403,
      reason: 'SECURITY_DENIED: User and Host accounts are strictly prohibited from accessing administrative staff panels.'
    };
  }

  // 2. CRITICAL: Super Admin CANNOT UNBAN any ID
  if (actorRole === 'SUPER_ADMIN' && (action.toLowerCase().includes('unban') || action === 'USER_UNBAN')) {
    return {
      allowed: false,
      statusCode: 403,
      reason: 'SECURITY_DENIED: Super Admin role is strictly prohibited from unbanning users. Authorization rejected.'
    };
  }

  // 3. Coin Seller cannot hire or manage staff
  if (actorRole === 'COIN_SELLER') {
    if (['manage_manager', 'manage_admin', 'manage_owner', 'hire', 'ban', 'unban'].includes(action)) {
      return {
        allowed: false,
        statusCode: 403,
        reason: 'SECURITY_DENIED: Coin Seller role is strictly restricted to coin selling operations and cannot manage staff or ban users.'
      };
    }
  }

  // 4. Agency cannot manage Manager, Admin, or Owner
  if (actorRole === 'AGENCY') {
    if (['manage_manager', 'manage_admin', 'manage_owner', 'system_settings', 'ban', 'unban'].includes(action)) {
      return {
        allowed: false,
        statusCode: 403,
        reason: 'SECURITY_DENIED: Agency account cannot modify Managers, Admins, or perform user bans.'
      };
    }
  }

  // 5. If targeting another role, enforce strict hierarchy rank: actor must outrank target
  if (targetRole) {
    const actorRank = ROLE_HIERARCHY_RANK[actorRole];
    const targetRank = ROLE_HIERARCHY_RANK[targetRole];

    if (actorRole !== 'OWNER' && actorRank <= targetRank) {
      return {
        allowed: false,
        statusCode: 403,
        reason: `SECURITY_DENIED: ${actorRole} (Rank ${actorRank}) cannot modify ${targetRole} (Rank ${targetRank}). Strict hierarchy violation.`
      };
    }
  }

  // Owner has absolute authority
  return {
    allowed: true,
    statusCode: 200
  };
}

/**
 * Generate an audit log entry for any role/security action
 */
export function createAuditLog(
  arg1: string | UserRole,
  arg2: string,
  arg3: UserRole | string,
  arg4: string,
  arg5: string,
  arg6?: UserRole | string,
  arg7?: 'SUCCESS' | 'DENIED' | 'FLAGGED' | string,
  arg8?: string
): AuditLogEntry {
  const actorIds: Record<UserRole, string> = {
    OWNER: 'OWNER-001',
    OFFICIAL: 'OFF-001',
    MANAGER: 'MGR-301',
    SUPER_ADMIN: 'SADM-101',
    ADMIN: 'ADM-201',
    ADMIN_BD: 'ADM-202',
    COIN_SELLER: 'CS-101',
    AGENCY: 'AG-01',
    HOST: 'HOST-701',
    USER: 'USR-8001'
  };

  // If called with 8 arguments: (actorId, actorName, actorRole, actionType, targetEntity, targetRole, status, details)
  if (arg8 !== undefined || (typeof arg7 === 'string' && ['SUCCESS', 'DENIED', 'FLAGGED'].includes(arg7))) {
    const actorId = String(arg1);
    const actorName = String(arg2);
    const actorRole = (typeof arg3 === 'string' ? arg3 : 'OWNER') as UserRole;
    const actionType = String(arg4);
    const targetEntity = String(arg5);
    const targetRole = arg6 as UserRole | undefined;
    const status = (arg7 as ('SUCCESS' | 'DENIED' | 'FLAGGED')) || 'SUCCESS';
    const details = arg8 || (typeof arg6 === 'string' && !['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MANAGER', 'AGENCY', 'HOST', 'USER'].includes(arg6) ? arg6 : '');

    return {
      id: 'LOG-' + Math.floor(100000 + Math.random() * 900000),
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
      actorId,
      actorName,
      actorRole,
      actionType,
      targetEntity,
      targetRole,
      details,
      ipAddress: '103.21.' + Math.floor(10 + Math.random() * 80) + '.' + Math.floor(10 + Math.random() * 200),
      status
    };
  }

  // Otherwise called with standard (actorRole, actorName, actionType, targetEntity, details, status)
  const actorRole = (typeof arg1 === 'string' && ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MANAGER', 'AGENCY', 'HOST', 'USER'].includes(arg1) ? arg1 : 'OWNER') as UserRole;
  const actorName = String(arg2);
  const actionType = String(arg3);
  const targetEntity = String(arg4);
  const details = String(arg5 || '');
  const status = (arg6 as ('SUCCESS' | 'DENIED' | 'FLAGGED')) || 'SUCCESS';

  return {
    id: 'LOG-' + Math.floor(100000 + Math.random() * 900000),
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
    actorId: actorIds[actorRole] || (typeof arg1 === 'string' && arg1.includes('-') ? arg1 : 'ACTOR-001'),
    actorName,
    actorRole,
    actionType,
    targetEntity,
    details,
    ipAddress: '103.21.' + Math.floor(10 + Math.random() * 80) + '.' + Math.floor(10 + Math.random() * 200),
    status
  };
}
