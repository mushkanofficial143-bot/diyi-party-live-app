import { useState, useEffect } from 'react';

export interface AndroidInsetsState {
  safeBottom: number;
  safeTop: number;
  isKeyboardOpen: boolean;
  isGestureNav: boolean;
  viewportHeight: number;
  navLiftPx: number;
}

export function useAndroidInsets(): AndroidInsetsState {
  const [insets, setInsets] = useState<AndroidInsetsState>({
    safeBottom: 16,
    safeTop: 0,
    isKeyboardOpen: false,
    isGestureNav: true,
    viewportHeight: typeof window !== 'undefined' ? window.innerHeight : 800,
    navLiftPx: 20
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const updateInsets = () => {
      // 1. Check visualViewport to detect keyboard
      const vv = window.visualViewport;
      const windowHeight = window.innerHeight;
      const currentVvHeight = vv ? vv.height : windowHeight;
      
      // If visualViewport is significantly smaller than window.innerHeight (difference > 120px),
      // the virtual keyboard is open on Android / iOS
      const heightDifference = windowHeight - currentVvHeight;
      const activeEl = document.activeElement;
      const isInputFocused = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || (activeEl as HTMLElement).isContentEditable);
      const isKeyboardOpen = heightDifference > 120 || (Boolean(isInputFocused) && heightDifference > 60);

      // 2. Compute safe bottom from CSS computed styles
      const computedRoot = getComputedStyle(document.documentElement);
      const cssSab = parseFloat(computedRoot.getPropertyValue('--sab') || '0');
      
      // Fallback base lift: on Android without env support, 16px for gesture bar or 48px for 3-button bar
      const safeBottom = Math.max(cssSab, 16);
      const isGestureNav = safeBottom < 36;
      const navLiftPx = safeBottom + 6;

      // 3. Set dynamic CSS variables on document element for seamless CSS usage
      document.documentElement.style.setProperty('--safe-bottom-px', `${safeBottom}px`);
      document.documentElement.style.setProperty('--nav-lift-px', `${navLiftPx}px`);
      document.documentElement.style.setProperty('--is-keyboard-active', isKeyboardOpen ? '1' : '0');
      document.documentElement.style.setProperty(
        '--bottom-nav-safe-offset',
        `calc(max(env(safe-area-inset-bottom, 0px), 16px) + 8px)`
      );
      document.documentElement.style.setProperty(
        '--bottom-content-safe-padding',
        `calc(max(env(safe-area-inset-bottom, 0px), 16px) + 84px)`
      );

      setInsets({
        safeBottom,
        safeTop: 0,
        isKeyboardOpen,
        isGestureNav,
        viewportHeight: currentVvHeight,
        navLiftPx
      });
    };

    updateInsets();

    // Event listeners for window resize, orientation change, visualViewport resize & focus
    window.addEventListener('resize', updateInsets);
    window.addEventListener('orientationchange', updateInsets);
    
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', updateInsets);
      window.visualViewport.addEventListener('scroll', updateInsets);
    }

    document.addEventListener('focusin', updateInsets);
    document.addEventListener('focusout', updateInsets);

    return () => {
      window.removeEventListener('resize', updateInsets);
      window.removeEventListener('orientationchange', updateInsets);
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', updateInsets);
        window.visualViewport.removeEventListener('scroll', updateInsets);
      }
      document.removeEventListener('focusin', updateInsets);
      document.removeEventListener('focusout', updateInsets);
    };
  }, []);

  return insets;
}
